<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>忘记密码</title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <meta name="description" content="">
  <meta name="author" content="tongleer">
  <link rel="stylesheet" href="./views/ui/layui/css/layui.css" media="all">
  <link rel="stylesheet" href="./views/ui/style/admin.css" media="all">
  <link rel="stylesheet" href="./views/ui/style/login.css" media="all">
  <script type="text/javascript" src="../include/lib/js/jquery/jquery-1.11.0.js?v=<?php echo Option::EMLOG_VERSION; ?>"></script>
</head>

  <div class="layadmin-user-login layadmin-user-display-show" id="user-login" style="display: none;">
    <div class="layadmin-user-login-main">
      <div class="layadmin-user-login-box layadmin-user-login-header">
        <h2><a href="<?php echo Option::get('blogurl'); ?>"><?php echo Option::get('blogname'); ?></a></h2>
        <p><?php echo Option::get('bloginfo'); ?></p>
      </div>
      <div class="layadmin-user-login-box layadmin-user-login-body layui-form">
		<form name="f" method="post" action="./index.php?action=forget">
			<div class="layui-form-item">
			  <label class="layadmin-user-login-icon layui-icon layui-icon-username" for="user-login-username"></label>
			  <input type="text" name="user" id="user" lay-verify="email" placeholder="请输入邮箱账号" class="layui-input">
			</div>
			<div class="layui-form-item">
			  <div class="layui-row">
				<div class="layui-col-xs7">
				  <label class="layadmin-user-login-icon layui-icon layui-icon-vercode" for="user-login-vercode"></label>
				  <input type="text" name="vercode" id="vercode" lay-verify="required" placeholder="邮箱验证码" class="layui-input">
				</div>
				<div class="layui-col-xs5">
				  <div style="margin-left: 10px;">
					<button type="button" class="layui-btn layui-btn-primary layui-btn-fluid" id="user-getsmscode">获取验证码</button>
				  </div>
				</div>
			  </div>
			</div>
			<div class="layui-form-item">
			  <label class="layadmin-user-login-icon layui-icon layui-icon-password" for="user-login-password"></label>
			  <input type="password" name="pw" id="pw" lay-verify="required" placeholder="密码" class="layui-input">
			</div>
			<div class="layui-form-item">
			  <button class="layui-btn layui-btn-fluid" lay-submit lay-filter="user-forget-submit">重置密码</button>
			</div>
			<?php if(isset($_GET['error_notuser'])):?><blockquote class="actived layui-elem-quote">此账号不存在</blockquote><?php endif;?>
			<?php if(isset($_GET['error_code'])):?><blockquote class="actived layui-elem-quote">邮箱验证码不正确</blockquote><?php endif;?>
			<?php if(isset($_GET['error_pass'])):?><blockquote class="actived layui-elem-quote">密码长度不得小于6位</blockquote><?php endif;?>
			<?php if(isset($_GET['error_mis'])):?><blockquote class="actived layui-elem-quote">填写邮箱和发送验证码的邮箱不一致</blockquote><?php endif;?>
		</form>
      </div>
    </div>
    
    <div class="layui-trans layadmin-user-login-footer">
      <p>© <?=date("Y");?> Powered by <a href="https://www.tongleer.com/" class="blue-text" target="_blank">tongleer</a></p>
      <p>
        <span><a href="http://club.tongleer.com/" target="_blank">获取程序</a></span>
        <span><a href="http://club.tongleer.com/" target="_blank">论坛交流</a></span>
        <span><a href="https://www.tongleer.com/" target="_blank">前往博客</a></span>
      </p>
    </div>

  </div>

  <script src="./views/ui/layui/layui.js"></script>  
  <script>
	layui.config({
		base: './views/ui/' //静态资源所在路径
	}).extend({
		index: 'lib/index' //主入口模块
	}).use(['index', 'user'], function(){
		var $ = layui.$
		,setter = layui.setter
		,admin = layui.admin
		,form = layui.form
		,router = layui.router();

		form.render();
	});
	$("#user-getsmscode").click(function(){
		if(!/^(\w-*\.*)+@(\w-?)+(\.\w{2,})+$/.test($("input[name='user']").val())){
			layer.msg("电子邮件格式错误");
			return;
		}
		$.post("index.php?action=sendMailCode",{username:$("input[name='user']").val()},function(data){
			sendSmsCode();
		});
	});
	var timer;
	var countdown=60;
	function sendSmsCode() {
		if (countdown == 0) {
			$("#user-getsmscode").text('获取验证码');
			$("#user-getsmscode").attr('disabled',false);
			$("#user-getsmscode").removeClass("layui-btn-disabled");
			countdown = 60;
			clearTimeout(timer);
			return;
		} else {
			$("#user-getsmscode").text(countdown+"秒");
			$("#user-getsmscode").attr('disabled',true);
			$("#user-getsmscode").addClass("layui-btn-disabled");
			countdown--; 
		} 
		timer=setTimeout(function() { 
			sendSmsCode();
		},1000) 
	}
  </script>
</body>
</html>