<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
						</div>
						<?php doAction('adm_footer');?>
					</div>
				</div>
			</div>
		  <div class="layadmin-body-shade" layadmin-event="shade"></div>
		</div>
	  </div>
	<script src="./views/ui/layui/layui.js"></script>
	<script>
	  layui.config({
		base: './views/ui/'
	  }).extend({
		index: 'lib/index'
	  }).use('index');
	</script>
</body>
</html>