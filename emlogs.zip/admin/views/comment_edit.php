<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
	  <legend>编辑评论</legend>
	</fieldset>
</div>
<form class="layui-form" action="comment.php?action=doedit" method="post">
<div>
	<li>
		<div style="margin:10px 0px;">评论人</div>
		<input type="text" value="<?php echo $poster; ?>" name="name" style="width:200px;" class="layui-input" />
	</li>
    <li>
		<div style="margin:10px 0px;">电子邮件</div>
		<input type="text"  value="<?php echo $mail; ?>" name="mail" style="width:200px;" class="layui-input" />
	</li>
	<li>
		<div style="margin:10px 0px;">主页</div>
		<input type="text"  value="<?php echo $url; ?>" name="url" style="width:200px;" class="layui-input" />
	</li>
    <li>
		<div style="margin:10px 0px;">评论内容</div>
		<textarea name="comment" rows="8" cols="60" class="layui-textarea"><?php echo $comment; ?></textarea>
	</li>
	<li style="margin-top:10px;">
		<input type="hidden" value="<?php echo $cid; ?>" name="cid" />
		<input type="submit" value="保 存" class="layui-btn" />
		<input type="button" value="取 消" class="layui-btn layui-btn-primary" onclick="javascript: window.history.back();" />
	</li>
</div>
</form>
<script>
$("#menu_cm").addClass('layui-this');
$("#menu_cm").parent().parent().addClass('layui-nav-itemed');
</script>