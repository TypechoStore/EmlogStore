<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"  dir="ltr" lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>upload</title>
<link rel="stylesheet" href="./views/ui/layui/css/layui.css" media="all">
<script type="text/javascript" src="../include/lib/js/jquery/jquery-1.11.0.js"></script>
<script>
function showupload(multi){
	var as_logid = parent.document.getElementById('as_logid').value
	window.location.href="attachment.php?action=selectFile&logid="+as_logid+"&multi="+multi;	
}
function showattlib(){
	var as_logid = parent.document.getElementById('as_logid').value
	window.location.href="attachment.php?action=attlib&logid="+as_logid;	
}
</script>
<body>
<div>
	<span><button type="button" onclick="showupload(0);" class="layui-btn layui-btn-primary layui-btn-xs n layui-btn-disabled">上传附件</button></span>
	<span><button type="button" onclick="showupload(1);" class="layui-btn layui-btn-primary layui-btn-xs">批量上传</button></span>
	<span><button type="button" onclick="showattlib();" class="layui-btn layui-btn-primary layui-btn-xs">附件库（<?php echo $attachnum; ?>）</button></span>
</div>
<form enctype="multipart/form-data" method="post" name="upload" action="">
	<blockquote class="layui-elem-quote">
		(单个附件最大：<?php echo $maxsize ;?>，允许类型：<?php echo $att_type_str; ?>)
	</blockquote>
	<div class="layui-upload">
	  <button type="button" class="layui-btn layui-btn-primary layui-btn-xs" id="attachBtn">选择文件</button> 
	  <div class="layui-upload-list">
		<table class="layui-table">
		  <thead>
			<tr><th>文件名</th>
			<th>大小</th>
			<th>状态</th>
			<th>操作</th>
		  </tr></thead>
		  <tbody id="attachList"></tbody>
		</table>
	  </div>
	  <button type="button" class="layui-btn layui-btn-primary layui-btn-xs" id="attachListAction">开始上传</button>
	</div>
</form>
<script src="./views/ui/layui/layui.js"></script>
<script>
layui.use('upload', function(){
	var $ = layui.jquery,upload = layui.upload;
	
	var attachListView = $('#attachList');
	var uploadListIns = upload.render({
		elem: '#attachBtn'
		,url: "attachment.php?action=upload&logid="+parent.document.getElementById('as_logid').value
		,accept: 'file'
		,field:'attach'
		,auto: false
		,bindAction: '#attachListAction'
		,choose: function(obj){   
		  var files = this.files = obj.pushFile();
		  obj.preview(function(index, file, result){
			var tr = $(['<tr id="upload-'+ index +'">'
			  ,'<td>'+ file.name +'</td>'
			  ,'<td>'+ (file.size/1014).toFixed(1) +'kb</td>'
			  ,'<td>等待上传</td>'
			  ,'<td>'
				,'<button class="layui-btn layui-btn-primary layui-btn-xs attach-reload layui-hide">重传</button>'
				,'<button class="layui-btn layui-btn-primary layui-btn-xs attach-delete">删除</button>'
			  ,'</td>'
			,'</tr>'].join(''));
			tr.find('.attach-reload').on('click', function(){
			  obj.upload(index, file);
			});
			tr.find('.attach-delete').on('click', function(){
			  delete files[index];
			  tr.remove();
			  uploadListIns.config.elem.next()[0].value = '';
			});
			attachListView.append(tr);
		  });
		}
		,done: function(res, index, upload){
		  if(res.code == 0){
			var tr = attachListView.find('tr#upload-'+ index)
			,tds = tr.children();
			tds.eq(2).html('<span style="color: #5FB878;">上传成功</span>');
			var point = res.data.src.lastIndexOf("."); 
			var extension = res.data.src.substr(point); 
			var result="";
			var ed_imgpath=res.data.BLOG_URL+res.data.src.substring(3);
			if(extension==".jpg"||extension==".gif"||extension==".jpeg"||extension==".png"||extension==".bmp"||extension==".JPG"||extension==".GIF"||extension==".JPEG"||extension==".PNG"||extension==".BMP"){ 
				result = "<button onClick=\"parent.addattach_img('"+ed_imgpath+"', '"+ed_imgpath+"',"+res.data.aid+", '"+res.data.width+"', '"+res.data.height+"', '"+res.data.filename+"');\" type=\"button\" class=\"layui-btn layui-btn-primary layui-btn-xs\">原图</button>";
				if (res.data.thumsrc != "null") {
					var thum_url=res.data.BLOG_URL+res.data.thumsrc.substring(3);
					result += " <button onClick=\"parent.addattach_img('"+ed_imgpath+"', '"+thum_url+"',"+res.data.aid+", '"+res.data.width+"', '"+res.data.height+"', '"+res.data.filename+"');\" type=\"button\" class=\"layui-btn layui-btn-primary layui-btn-xs\">缩略图</button>";
				}
				if(res.data.blogtype=="blog"){
					result += " <button onClick=\"parent.insertThumb('"+ed_imgpath+"', 'pic');\" type=\"button\" class=\"layui-btn layui-btn-primary layui-btn-xs\">设为封面</button>";
				}
			}else if(extension==".zip"||extension==".rar"||extension==".ZIP"||extension==".RAR"){
				result = "<button onClick=\"parent.addattach_file('"+ed_imgpath+"', '"+res.data.filename+"',"+res.data.aid+");\" type=\"button\" class=\"layui-btn layui-btn-primary layui-btn-xs\">插入</button>";
			}else{
				result = "<button onClick=\"parent.addattach_file('"+ed_imgpath+"', '"+res.data.filename+"',"+res.data.aid+");\" type=\"button\" class=\"layui-btn layui-btn-primary layui-btn-xs\">插入</button>";
			}
			tds.eq(3).html(result);
			return delete this.files[index];
		  }
		  this.error(index, upload);
		}
		,error: function(index, upload){
		  var tr = attachListView.find('tr#upload-'+ index)
		  ,tds = tr.children();
		  tds.eq(2).html('<span style="color: #FF5722;">上传失败</span>');
		  tds.eq(3).find('.attach-reload').removeClass('layui-hide');
		}
	});
});
</script>
</body>
</html>
