<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
	  <legend><b>导航管理</b></legend>
	</fieldset>
<?php if(isset($_GET['active_taxis'])):?><blockquote class="actived layui-elem-quote">排序更新成功</span><?php endif;?>
<?php if(isset($_GET['active_del'])):?><blockquote class="actived layui-elem-quote">删除导航成功</blockquote><?php endif;?>
<?php if(isset($_GET['active_edit'])):?><blockquote class="actived layui-elem-quote">修改导航成功</blockquote><?php endif;?>
<?php if(isset($_GET['active_add'])):?><blockquote class="actived layui-elem-quote">添加导航成功</blockquote><?php endif;?>
<?php if(isset($_GET['error_a'])):?><blockquote class="error layui-elem-quote">导航名称和地址不能为空</blockquote><?php endif;?>
<?php if(isset($_GET['error_b'])):?><blockquote class="error layui-elem-quote">没有可排序的导航</blockquote><?php endif;?>
<?php if(isset($_GET['error_c'])):?><blockquote class="error layui-elem-quote">默认导航不能删除</blockquote><?php endif;?>
<?php if(isset($_GET['error_d'])):?><blockquote class="error layui-elem-quote">请选择要添加的分类</blockquote><?php endif;?>
<?php if(isset($_GET['error_e'])):?><blockquote class="error layui-elem-quote">请选择要添加的页面</blockquote><?php endif;?>
<?php if(isset($_GET['error_f'])):?><blockquote class="error layui-elem-quote">导航地址格式错误(需包含http等前缀)</blockquote><?php endif;?>
</div>
<form class="layui-form" action="navbar.php?action=taxis" method="post">
  <table class="layui-table" width="100%" id="adm_navi_list">
    <thead>
      <tr>
	  	<th width="50"><b>序号</b></th>
        <th width="230"><b>导航</b></th>
        <th width="60"><b>类型</b></th>
        <th width="60"><b>状态</b></th>
        <th width="50"><b>查看</b></th>
		<th width="360"><b>地址</b></th>
        <th width="100"></th>
      </tr>
    </thead>
    <tbody>
	<?php 
	if($navis):
	foreach($navis as $key=>$value):
        if ($value['pid'] != 0) {
            continue;
        }
        $value['type_name'] = '';
        switch ($value['type']) {
            case Navi_Model::navitype_home:
            case Navi_Model::navitype_t:
            case Navi_Model::navitype_admin:
                $value['type_name'] = '系统';
                break;
            case Navi_Model::navitype_sort:
                $value['type_name'] = '<font color="blue">分类</font>';
                break;
            case Navi_Model::navitype_page:
                $value['type_name'] = '<font color="#00A3A3">页面</font>';
                break;
            case Navi_Model::navitype_custom:
                $value['type_name'] = '<font color="#FF6633">自定</font>';
                break;
        }
        doAction('adm_navi_display');
    
	?>  
      <tr>
		<td><input class="layui-input" name="navi[<?php echo $value['id']; ?>]" value="<?php echo $value['taxis']; ?>" maxlength="4" style="width:30px;" /></td>
		<td><a href="navbar.php?action=mod&amp;navid=<?php echo $value['id']; ?>" title="编辑导航"><?php echo $value['naviname']; ?></a></td>
		<td><?php echo $value['type_name'];?></td>
		<td>
		<?php if ($value['hide'] == 'n'): ?>
		<a href="navbar.php?action=hide&amp;id=<?php echo $value['id']; ?>" title="点击隐藏导航">显示</a>
		<?php else: ?>
		<a href="navbar.php?action=show&amp;id=<?php echo $value['id']; ?>" title="点击显示导航" style="color:red;">隐藏</a>
		<?php endif;?>
		</td>
		<td>
	  	<a href="<?php if($value['type']==Navi_Model::navitype_home){echo BLOG_URL;}else if($value['type']==Navi_Model::navitype_t){echo BLOG_URL."t";}else if($value['type']==Navi_Model::navitype_admin){echo BLOG_URL.ADMIN_DIR;}else{echo $value['url'];} ?>" target="_blank">
	  	<img src="./views/images/<?php echo $value['newtab'] == 'y' ? 'vlog.gif' : 'vlog2.gif';?>" align="absbottom" border="0" /></a>
	  	</td>
        <td><?php echo $value['url']; ?></td>
        <td>
        <a href="navbar.php?action=mod&amp;navid=<?php echo $value['id']; ?>">编辑</a>
        <?php if($value['isdefault'] == 'n'):?>
        <a href="javascript: em_confirm(<?php echo $value['id']; ?>, 'navi', '<?php echo LoginAuth::genToken(); ?>');">删除</a>
        <?php endif;?>
        </td>
      </tr>
    <?php
		if(!empty($value['childnavi'])):
		foreach ($value['childnavi'] as $val):
	?>
        <tr>
		<td><input class="layui-input" name="navi[<?php echo $val['id']; ?>]" value="<?php echo $val['taxis']; ?>" maxlength="4" /></td>
		<td>---- <a href="navbar.php?action=mod&amp;navid=<?php echo $val['id']; ?>" title="编辑导航"><?php echo $val['naviname']; ?></a></td>
		<td><?php echo $value['type_name'];?></td>
		<td>
		<?php if ($val['hide'] == 'n'): ?>
		<a href="navbar.php?action=hide&amp;id=<?php echo $val['id']; ?>" title="点击隐藏导航">显示</a>
		<?php else: ?>
		<a href="navbar.php?action=show&amp;id=<?php echo $val['id']; ?>" title="点击显示导航" style="color:red;">隐藏</a>
		<?php endif;?>
		</td>
		<td>
	  	<a href="<?php if($val['type']==Navi_Model::navitype_home){echo BLOG_URL;}else if($val['type']==Navi_Model::navitype_t){echo BLOG_URL."t";}else if($val['type']==Navi_Model::navitype_admin){echo BLOG_URL.ADMIN_DIR;}else{echo $val['url'];} ?>" target="_blank">
	  	<img src="./views/images/<?php echo $val['newtab'] == 'y' ? 'vlog.gif' : 'vlog2.gif';?>" align="absbottom" border="0" /></a>
	  	</td>
        <td><?php echo $val['url']; ?></td>
        <td>
        <a href="navbar.php?action=mod&amp;navid=<?php echo $val['id']; ?>">编辑</a>
        <?php if($val['isdefault'] == 'n'):?>
        <a href="javascript: em_confirm(<?php echo $val['id']; ?>, 'navi', '<?php echo LoginAuth::genToken(); ?>');">删除</a>
        <?php endif;?>
        </td>
      </tr>
      <?php endforeach;endif; ?>
	<?php endforeach;else:?>
	  <tr><td colspan="4">还没有添加导航</td></tr>
	<?php endif;?>
    </tbody>
  </table>
  <div><input type="submit" value="改变排序" class="layui-btn layui-btn-primary layui-btn-xs" /></div>
</form>
<div class="layui-row layui-col-space15">
	<div class="layui-col-md4">
		<div class="layui-collapse" lay-filter="navi_custom">
		  <div class="layui-colla-item">
			<h2 class="layui-colla-title">添加自定义导航</h2>
			<div id="navi_add_custom" class="layui-colla-content">
				<form class="layui-form" action="navbar.php?action=add" method="post" name="navi" id="navi">
					<ul>
						<li>
							<div style="margin:10px 0px;">序号</div>
							<input maxlength="4" style="width:30px;" name="taxis" class="layui-input" />
						</li>
						<li>
							<div style="margin:10px 0px;">导航名称 <span style="color:red;">*</span></div>
							<input maxlength="200" style="width:100px;" name="naviname" class="layui-input" />
						</li>
						<li>
							<div style="margin:10px 0px;">地址(带http) <span style="color:red;">*</span></div>
							<input maxlength="200" style="width:168px;" name="url" id="url" class="layui-input" />
						</li>
						<li>
							<div style="margin:10px 0px;">父导航</div>
							<select name="pid" id="pid">
								<option value="0">无</option>
								<?php
									foreach($navis as $key=>$value):
										if($value['type'] != Navi_Model::navitype_custom || $value['pid'] != 0) {
											continue;
										}
								?>
								<option value="<?php echo $value['id']; ?>"><?php echo $value['naviname']; ?></option>
								<?php endforeach; ?>
							</select>
						</li>
						<li style="margin:10px 0px;">
							<input type="checkbox" style="vertical-align:middle;" value="y" name="newtab" lay-skin="primary" />在新窗口打开
						</li>
						<li style="margin:10px 0px;">
							<input type="submit" name="" value="添加" class="layui-btn layui-btn-primary layui-btn-xs" />
						</li>
					</ul>
				</form>
			</div>
		  </div>
		</div>
	</div>
	<div class="layui-col-md4">
		<div class="layui-collapse" lay-filter="navi_sort">
		  <div class="layui-colla-item">
			<h2 class="layui-colla-title">添加分类到导航</h2>
			<div id="navi_add_sort" class="layui-colla-content">
				<form class="layui-form" action="navbar.php?action=add_sort" method="post" name="navi" id="navi">
					<ul>
						<?php 
						if($sorts):
						foreach($sorts as $key=>$value):
						if ($value['pid'] != 0) {
							continue;
						}
						?>
						<li>
							<input type="checkbox" style="vertical-align:middle;width:30px;" name="sort_ids[]" value="<?php echo $value['sid']; ?>" lay-skin="primary" />
							<?php echo $value['sortname']; ?>
						</li>
						<?php
							$children = $value['children'];
							foreach ($children as $key):
							$value = $sorts[$key];
						?>
						<li>
							&nbsp; &nbsp; &nbsp;  <input type="checkbox" style="vertical-align:middle;" name="sort_ids[]" value="<?php echo $value['sid']; ?>" lay-skin="primary" />
							<?php echo $value['sortname']; ?>
						</li>
						<?php 
							endforeach;
					   endforeach;
					   ?>
						<li style="margin:10px 0px;"><input type="submit" name="" value="添加" class="layui-btn layui-btn-primary layui-btn-xs" /></li>
						<?php else:?>
						<li>还没有分类，<a href="sort.php">新建分类</a></li>
						<?php endif;?> 
					</ul>
				</form>
			</div>
		  </div>
		</div>
	</div>
	<div class="layui-col-md4">
		<div class="layui-collapse" lay-filter="navi_page">
		  <div class="layui-colla-item">
			<h2 class="layui-colla-title">添加页面到导航</h2>
			<div id="navi_add_page" class="layui-colla-content">
				<form class="layui-form" action="navbar.php?action=add_page" method="post" name="navi" id="navi">
					<ul>
						<?php 
						if($pages):
						foreach($pages as $key=>$value): 
						?>
						<li>
							<input type="checkbox" style="vertical-align:middle;" name="pages[<?php echo $value['gid']; ?>]" value="<?php echo $value['title']; ?>" lay-skin="primary" />
							<?php echo $value['title']; ?>
						</li>
						<?php endforeach;?>
						<li style="margin:10px 0px;"><input type="submit" name="" value="添加" class="layui-btn layui-btn-primary layui-btn-xs" /></li>
						<?php else:?>
						<li>还没页面，<a href="page.php">新建页面</a></li>
						<?php endif;?> 
					</ul>
				</form>
			</div>
		  </div>
		</div>
	</div>
</div>
<script>
$(function(){
	layui.use(['element', "laypage", "layer", "form"], function(){
		var form = layui.form;
		var element = layui.element;
		var layer = layui.layer;
		element.on('collapse(navi_custom)', function(data){
			if(data.show){
				$("#navi_add_custom").attr('class','layui-colla-content layui-show');
			}else{
				$("#navi_add_custom").attr('class','layui-colla-content');
			}
			$.cookie('em_navi_add_custom',$("#navi_add_custom").attr('class'));
		});
		element.on('collapse(navi_sort)', function(data){
			if(data.show){
				$("#navi_add_sort").attr('class','layui-colla-content layui-show');
			}else{
				$("#navi_add_sort").attr('class','layui-colla-content');
			}
			$.cookie('em_navi_add_sort',$("#navi_add_sort").attr('class'));
		});
		element.on('collapse(navi_page)', function(data){
			if(data.show){
				$("#navi_add_page").attr('class','layui-colla-content layui-show');
			}else{
				$("#navi_add_page").attr('class','layui-colla-content');
			}
			$.cookie('em_navi_add_page',$("#navi_add_page").attr('class'));
		});
	});
	$("#adm_navi_list tbody tr:odd").css("background-color","#F7F7F7");
	$("#adm_navi_list tbody tr")
		.mouseover(function(){$(this).css("background-color","#E9F1FA");$(this).find("span").show();})
		.mouseout(function(){$(this).css("background-color","#F7F7F7");$(this).find("span").hide();})
});
if($.cookie('em_navi_add_custom')=="layui-colla-content layui-show"){
	$("#navi_add_custom").addClass("layui-show");
}else{
	$("#navi_add_custom").removeClass("layui-show");
}
if($.cookie('em_navi_add_sort')=="layui-colla-content layui-show"){
	$("#navi_add_sort").addClass("layui-show layui-show");
}else{
	$("#navi_add_sort").removeClass("layui-show");
}
if($.cookie('em_navi_add_page')=="layui-colla-content layui-show"){
	$("#navi_add_page").addClass("layui-show");
}else{
	$("#navi_add_page").removeClass("layui-show");
}
setTimeout(hideActived,2600);
$("#menu_navbar").addClass('layui-this');
$("#menu_navbar").parent().parent().addClass('layui-nav-itemed');
</script>