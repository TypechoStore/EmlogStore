<?php
/**  
 * 此类为单例模式，取得实例方法: $cache = MCache::getInstance();
 * 适用于SAE
 * @author Star.Yu <vip@myxzy.com> and Diamond <android@tongleer.com>
 * @date 2014.5.25
 */
class MCache{
 private static $_instance;
 private static $_connect_type = '';
 private $_memcache;
 
 /**
  * 私有化构造函数，禁止使用关键字new来实例Mcache类
  */
 private function __construct() {
  if (!class_exists('Memcached')) {
   throw new Exception('Class Memcached not exists');
  } 
  $conn = self::$_connect_type;
  $this->_memcache = new Memcached();
 }
 
 /**
  * 克隆私有化，禁止克隆实例
  */
 private function __clone() {}
 
 /**
  * 类入口，通过此静态方法对类进行实例化
  */
 public static function getInstance($type = 'connect'){
  self::$_connect_type = ($type == 'connect') ? $type : 'pconnect';
  if (!self::$_instance instanceof self) {
   self::$_instance = new self();
  }
  return self::$_instance;
 }
 
 /**
  * 把数据添加到缓存
  * @param string $key 缓存的key
  * @param string|array|int... $value 缓存的数据
  * @param int $flag  使用zlib MEMCACHE_COMPRESSED
  * @param int $expire_time  缓存时间
  */
 public function set($key, $value,$flag = 0 ,$expire_time = 0){
   $this->_memcache->set($key, $value, $flag, $expire_time);   
 }

 /**
  * 替换缓存数据
  * @param string $key 缓存的key
  * @param string|array|int... $value 缓存的数据
  * @param int $flag  使用zlib MEMCACHE_COMPRESSED
  * @param int $expire_time  缓存时间
  */
 public function replace($key, $value,$flag = 0 , $expire_time = 0){
   $this->_memcache->replace($key, $value, $flag, $expire_time);   
 }
 
 /**
  * 从缓存读取数据
  * @param string|array|int... $key
  */
 public function get($key){
  return $this->_memcache->get($key); 
 }
 
 /**
  * 从缓存删除数据
  * @param string|array|int... $key
  */
 public function del($key,$expire_time = 0){
  $this->_memcache->delete($key, $expire_time);  
 }

 public function close(){
	return $this->_memcache->close();
 }
}
?>