<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div id="m" class="layui-row layui-col-space20 layadmin-homepage-list-imgtxt">
  <div id="mleft" class="layui-col-md12">
	<div class="grid-demo">
		<center>
		  <div class="layui-card">
			<div class="layui-card-header" style="background-color:#eee;">该文章需要密码才能访问，请输入密码</div>
			<div class="layui-card-body">
				<form class="layui-form" action="" method="post">
				<input class="layui-input" type="password" name="logpwd" />
				<input type="submit" class="layui-btn layui-btn-primary" value="确定" />
				<button type="button" onClick="location.href='./';" class="layui-btn layui-btn-primary">返回首页</button>
				</form>
			</div>
		  </div>
		</center>
	</div>
  </div>
</div>