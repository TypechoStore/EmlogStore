<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div id="m" class="layui-row layui-col-space20 layadmin-homepage-list-imgtxt">
  <style>
	.media-body img{
		display: block;max-width: 100%;height: auto;margin-top: 10px;
	}
  </style>
  <div id="mleft" class="layui-col-md12">
	<div class="grid-demo">
		<div class="panel-body layadmin-homepage-shadow">
			<div class="media-body">
			  <div class="pad-btm">
				<p class="fontColor">
					<?php echo $log_title; ?>
				</p>
				<p class="min-font">
				  <span class="layui-breadcrumb" lay-separator="-">
					<a href="javascript:;"><?php echo $user_cache[$author]['name'];?></a>
					<a href="javascript:;"><?php echo date('Y-n-j', $date); ?></a>
					<a href="javascript:;">
					  <i class="layui-icon layui-icon-reply-fill"></i>
					  <span><?php echo $comnum; ?></span>
					</a>
					<a href="javascript:;">
					  <i class="layui-icon layui-icon-fire"></i>
					  <span><?php echo $views; ?></span>
					</a>
					<?php if(ROLE == ROLE_ADMIN): ?>
					<a href="./?action=write&id=<?php echo $logid;?>">
					  <i class="layui-icon layui-icon-edit"></i>
					  <span>编辑</span>
					</a>
					<?php endif;?>
				  </span>
				</p>         
			  </div>
			  <?php echo nl2br($log_content); ?>
			  <div class="media-list">
				<?php if($allow_remark == 'y'){?>
				<div class="c">
					<form method="post" action="./index.php?action=addcom&gid=<?php echo $logid; ?>">
					<?php if(ISLOGIN == true):?>
					<fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
					  <legend>当前已登录为：<b><?php echo $user_cache[UID]['name']; ?></b></legend>
					</fieldset>
					<?php else: ?>
					<input placeholder="昵称" class="layui-input" type="text" name="comname" value="" />
					<input placeholder="邮件地址 (选填)" class="layui-input" type="text" name="commail" value="" />
					<input placeholder="个人主页 (选填)" class="layui-input" type="text" name="comurl" value="" />
					<?php endif; ?>
					<textarea class="layui-textarea" placeholder="内容" name="comment" rows="10"></textarea>
					<?php echo $verifyCode; ?>
					<input type="submit" class="layui-btn layui-btn-primary" value="发表评论" />
					</form>
				</div>
				<?php }?>
				<?php if(!empty($commentStacks)): ?>
				<fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
				  <legend><div class="t">评论</div></legend>
				</fieldset>
				<div class="c">
					<?php foreach($commentStacks as $cid):
						$comment = $comments[$cid];
						$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
					?>
					<div class="media-item comment">
						<div class="media-text l">
							<a href="javascript:;"><?php echo $comment['poster']; ?></a>
							<mdall class="info"><?php echo $comment['date']; ?></mdall>
							<a href="./?action=reply&cid=<?php echo $comment['cid'];?>">回复</a>
							<?php if(ROLE === ROLE_ADMIN): ?>
							<a href="./?action=delcom&id=<?php echo $comment['cid'];?>&gid=<?php echo $logid; ?>&token=<?php echo LoginAuth::genToken();?>">删除</a>
							<?php endif; ?>
							<div class="comcont"><?php echo $comment['content']; ?></div>
						</div>
					</div>
					<?php endforeach; ?>
					<div id="page"><?php echo $commentPageUrl;?></div>
				</div>
				<?php endif;?>
			  </div>
			</div>
		</div>
	</div>
  </div>
</div>