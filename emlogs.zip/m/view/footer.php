<div id="footer" style="background-color:#fff;word-wrap:break-word;padding:20px;">
	<center>
	Powered by <a href="http://www.emlog.net" title="采用emlog系统" target="_blank">emlog</a> Theme By <a href="http://www.tongleer.com" title="同乐儿" target="_blank">Tongleer</a>
	</center>
</div>
<script src="<?php echo BLOG_URL.ADMIN_DIR; ?>/views/ui/layui/layui.js"></script>  
<script>
$(function(){
	layui.use(['element','form'], function(){
	  var element = layui.element;
	  var form = layui.form;
	});
});
</script>
</body>
</html>