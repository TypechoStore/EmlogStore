<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div class="footer">
		CopyRight 2013 <?php echo $blogname;?> All Right Served.<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?><br/>
		Powered By <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">Emlog</a> , Designed By <a href="http://www.yilushang.net" target="_blank">Kurly</a>.
		<?php doAction('index_footer'); ?>
	</div>
</div>
<div id="gotop"></div>
<script type="text/javascript">
	$(function(){
		var baseTop = $("ul#sidebar").offset().top;
		var myTop = $("#floatbox").offset().top;
		$(window).scroll(function(){
			var moveLen = $(window).scrollTop();
			if(moveLen >= 150)
				$("#gotop").show().css("top", moveLen+500+"px");
			else
				$("#gotop").hide();
			
			if(moveLen >= myTop)
				$("#floatbox").css("position", "absolute").css("top", moveLen - baseTop+"px");
			else
				$("#floatbox").css("position", "static").css("top", "0px");
		});
		$("#gotop").click(function(){
			$("html,body").animate({scrollTop:0},500);
		});
	});
</script>
</body>
<script>prettyPrint();</script>
</html>