<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="wrap">
	<div class="mainleft">
		<div class="list content">
			<div class="item">
				<div class="l">
					<div class="date">
						<div class="t">
							<?php echo gmdate('j', $date); ?>
						</div>
						<div class="b"><?php echo gmdate('Y-n', $date); ?></div>
					</div>
					<div class="tags">
						<?php blogtags($logid); ?>
					</div>
				</div>
				<div class="r">
					<div class="m">
						<div class="t position"><span class="jiao"></span>
							<span class="inner"><a href="<?php echo BLOG_URL;?>" title="返回首页">首页</a> >> <?php getBlogSort($logid);?> >> <?php echo $log_title; ?></span>
						</div>
						<h3><?php topflg($top); ?><?php echo $log_title; ?><span class="e"><?php editflg($logid,$author); ?></span></h3>
						<div class="con">
							<?php echo $log_content; ?>
							<?php doAction('log_related', $logData); ?>
							<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
							<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
						</div>
						<div class="meta">
							<div class="tag">
								<span class="author">作者：<?php blog_author($author); ?></span>
								<span class="cat"><?php blog_sort($logid); ?></span>
							</div>
							<div class="view">
								<span class="v">浏览：<?php echo $views; ?></span>
								<span class="c">评论：<?php echo $comnum; ?></span>
							</div>
							<div class="clear"></div>
						</div>
					</div>
					<div class="b"></div>
				</div>
				<div class="clear"></div>
			</div><!--//item end-->
			<div class="item">
				<div class="l">
				</div>
				<div class="r">
					<div class="m">
						<div class="t"></div>
						<div class="con pinglun" id="pinglun">
							<?php blog_comments($comments); ?>
							<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
						</div>
					</div>
					<div class="b"></div>
				</div>
				<div class="clear"></div>
			</div><!--//item end-->
		</div><!--//list end-->
	</div>
	<div class="mainright">
		<?php
			include View::getView('side');
		?>
	</div><!-- //mainright end-->
	<div class="clear"></div>
<?php
 include View::getView('footer');
?>