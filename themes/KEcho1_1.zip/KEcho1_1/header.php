<?php
/*
Template Name:KECHO
Description:轻博客风格模板，致认真写博客的朋友 ……
Version:1.0
Author:一路上
Author Url:http://www.yilushang.net
Sidebar Amount:1
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
/*
$browserFlag = isIE6Or7();
if($browserFlag)
	exit('浏览器不支持');
*/
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>/style.css" />
<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script> 
<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<script type="text/javascript">
	$(function(){
		$("li.catbtn").hover(function(){
			$(this).children("#catlist").slideDown();
		},function(){
			$(this).children("#catlist").stop().slideUp();
		});
		$("li.catbtn #catlist li:eq(0)").css("border-top","none");
	});
</script>
</head>
<body>
<div class="header">
	<div class="inner">
		<div class="l">
			<div class="l-l">
				<div id="logo"><a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>"></a></div>
				<div class="desc">
					<?php echo $bloginfo;?> 
				</div>
				<div class="clear"></div>
			</div>
			<div class="l-r">
				<ul>
					<li <?php if(blog_tool_ishome()) echo 'class="current"';?>><a href="<?php echo BLOG_URL;?>">首页</a></li>
					<li <?php if(trim(Dispatcher::setPath(), '/')=='t') echo 'class="current"';?>><a href="<?php echo BLOG_URL;?>t/">微语</a></li>
					<li><a href="<?php echo BLOG_URL;?>admin/"><?php if(ROLE == 'admin' || ROLE == 'writer') echo '管理'; else echo '登录'; ?></a></li>
					<li class="catbtn">
						<a href="#">目录</a>
						<?php topsorts();?>
					</li>
				</ul>
				<div class="clear"></div>
			</div>
			<div class="clear"></div>
		</div>
		<div class="r">
			<div id="search">
				<form action="<?php echo BLOG_URL;?>"><input type="text" class="bar" value="搜索：输入关键词后按回车" onfocus="this.value=''" name="keyword" /></form>
			</div>
		</div>
		<div class="clear"></div>
	</div>
</div><!--//header end-->
