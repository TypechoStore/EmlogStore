<?php 
/**
 * 侧边栏
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="catalog">
			<div class="inner">
				<h3><span>自定义侧边栏</span></h3>
				<ul>
					<li><a href="">此处可以是您网站推荐的内容</a></li>
					<li><a href="">也可以是独立页面链接</a></li>
					<li><a href="">本段内容存在于side.php</a></li>
					<li><a href="">您需要手动对此处进行修改</a></li>
					<li class="bottom">这里还可以写几个字</li>
				</ul>
			</div>
		</div>
<ul id="sidebar">
<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>
	<li id="floatbox">
		<h3><span>侧栏固定显示</span></h3>
		<div class="rightbox">
			这里的内容将会跟随浏览器滚动而固定显示，兼容IE6浏览器。
		</div>
	</li>
</ul><!--end #siderbar-->