<?php
/*
 *首页日志列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="frame_content">
<div id="content">
<?php doAction('index_loglist_top'); ?>
<?php if ($LogList_mod == 0): ?>
    <?php foreach($logs as $value): ?>
    <div class="content-box">
     <div class="title">
      <h2 class="logs"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
      <p class="date">作者：<?php blog_author($value['author']); ?> &nbsp; 发布于：<?php echo gmdate('Y-n-j G:i l', $value['date']); ?> &nbsp; <?php blog_sort($value['logid']); ?> &nbsp; <?php editflg($value['logid'],$value['author']); ?></p>
     </div>
     <div class="log_desc">
      <?php echo $value['log_description']; ?>
      <div class="clear"></div>
     </div>
     <!--非图形附件列表，5.0己非必须-->
     <!--<div class="att"><?php //blog_att($value['logid']); ?></div>-->
    </div>
    <?php endforeach; ?>
<?php else: ?>
    <div class="content-box">
    <?php foreach($logs as $value):
     preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
     $imgsrc = !empty($img[1]) ? $img[1][0] : ''; ?>
     <div class="box">
      <div class="box_abs" <?php if($imgsrc){echo 'style="text-align:center;"';} ?>>
       <a href="<?php echo $value['log_url']; ?>">
       <div style="height:27px; line-height:27px; overflow:hidden;">
       &nbsp;<font class="top"><?php topflg($value['top']); ?></font>
       <font style="font-weight:bold;"><?php echo $value['log_title']; ?></font>
       </div>
       <?php if($imgsrc): ?>
        <img src="<?php echo $imgsrc; ?>" />
       <?php else: ?>
        <?php echo $value['log_description']; ?>
        <div class="clear"></div>
       <?php endif; ?>
       </a>
      </div>
      <div class="box_ps">
       <a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a> &nbsp;
       <a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a> &nbsp;
      </div>
     </div>
    <?php endforeach; ?>
    </div>
    <div class="clear"></div>
<?php endif; ?>
<div id="pagenavi"><?php echo $page_url; ?></div>
</div><!--#content.End-->
</div><!--#frame_content.End-->
<?php
	include View::getView('side');
	include View::getView('footer');
?>
