<?php
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div class="clear"></div>
</div><!--#frame.End-->
</div><!--#wrap.End-->
<div id="footerbar">
	<a name="bottom"></a><!--设置底部锚点-->
	&nbsp; &nbsp;Powered by <a href="http://www.emlog.net/" title="Emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">Emlog</a> &nbsp; Designed by <a href="http://emlog8.sinaapp.com/" target="_blank">Emlog吧</a> &nbsp; <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> &nbsp; <?php doAction('index_footer'); ?> &nbsp; <?php echo $footer_info; ?>
	<div id="logon">
		<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
		<a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a>
		<a href="<?php echo BLOG_URL; ?>admin/">管理</a>
		<a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a>&nbsp;
		<?php else: ?>
		<a href="<?php echo BLOG_URL; ?>admin/">登录</a>&nbsp;
		<?php endif; ?>
	</div>
</div>
</body>
</html>
