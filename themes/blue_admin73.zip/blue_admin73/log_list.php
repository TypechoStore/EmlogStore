<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
  <?php doAction('index_loglist_top'); ?>
  <div id="main">
   <?php foreach($logs as $value): ?>
     <div class="post cate0 auth1">
      <div class="post_time">
        <h5><?php echo gmdate('d', $value['date']); ?></h5><h6><?php echo gmdate('M', $value['date']); ?><br /><?php echo gmdate('Y', $value['date']); ?></h6>
      </div>
      <div class="post_r">
        <div class="post_body">
          <h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2><?php blog_tag($value['logid']); ?>
          <div class="post_content">
           <?php echo $value['log_description']; ?>
          </div>
          <div class="post_info">
            <a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a>
	<a href="<?php echo $value['log_url']; ?>#tb">引用(<?php echo $value['tbcount']; ?>)</a>
	<a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a>
	<?php blog_sort($value['logid']); ?>
          </div>
        </div>
      </div>
     <div class="clear"></div>
    </div>
    <?php endforeach; ?>
    <div class="pagebar">
	<?php echo $page_url;?>
    </div>
  </div>
  <div id="sidebar">
  <?php include View::getView('side');?></div>
  <div class="clear"></div>
</div>
  <?php include View::getView('footer');?>