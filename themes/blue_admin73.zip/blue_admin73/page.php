<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
  <div id="main">
    <div class="post cate0 auth1">
      <div class="post_time">
        <h5><?php echo gmdate('d', $date); ?></h5><h6><?php echo gmdate('M', $date); ?><br /><?php echo gmdate('Y', $date); ?></h6>
      </div>
      <div class="post_r">
        <div class="post_body">
          <h2><?php echo $log_title; ?></h2>
          <div class="post_content">
		 <?php echo $log_content; ?>
          </div>
          <div class="post_tags"><?php blog_tag($logid); ?></div>
          <div class="post_info">
            作者：<?php blog_author($author); ?> | 评论:<?php echo $comnum; ?> | 浏览:<span id="spn4"><?php echo $views; ?></span> | <?php blog_sort($logid); ?>
          </div>
        </div>
        <!-- <div class="post_nav"></div>
      <div class="mutuality">
          <h4>相关文章:</h4>
          <div class="mutuality_body">
          </div>
        </div>-->
        <div class="commentlist" >
          <h4>评论列表:</h4>
         <?php blog_comments($comments); ?>
        </div>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
      </div>
     <div class="clear"></div>
    </div>
  </div>
    <div id="sidebar">
   <?php include View::getView('side');?>
  </div>
  <div class="clear"></div>
</div>
 <?php include View::getView('footer');?>