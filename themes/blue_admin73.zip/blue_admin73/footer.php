<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="footer">
<div id="footer_n">
  <div class="copyright">
  <p><?php echo $footer_info; ?></p>
    <p> Powered By <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">Emlog</a> Designed by <a href="http://www.htmlit.com.cn/" target="_blank">HTMLIT</a>&amp;<a href="http://www.admin73.com" target="_blank">Admin73</a><a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a></p>
 <p><?php doAction('index_footer'); ?></p>
  </div>
  <div id="goTopBtn">
    <a onclick="pageScroll()"><span>返回顶部</span></a>
  </div>
  <div class="clear"></div>
</div>
</div>
</body>
</html>