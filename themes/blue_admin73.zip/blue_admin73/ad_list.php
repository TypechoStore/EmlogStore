<?php 
/*
* 广告投放位置统计
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
代码一位置log_list 百度ad
<?php if($i==1){include View::getView('log_list_ad_baidu_640_60_list');}?>
代码二位置side
<?php include View::getView('side_ad_baidu_200_200_list');?>