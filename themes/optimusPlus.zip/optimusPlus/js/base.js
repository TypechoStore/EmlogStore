$(function() {
	$(window).scroll(function() {

		// topBar fixed
		if ($(this).scrollTop() > 30) {
			$(".topBar").css({
				"backgroundColor":"rgba(45,45,45,0.9)"
			});
		}

		// goTop action
		if ($(this).scrollTop() > 120) {
			$("#goTop").fadeIn("500");
		} else {
			$("#goTop").fadeOut("500");
		}
	});

	// goTop animate
	$("#goTop").click(function () {
		$("body, html").animate({scrollTop: 0}, 800);
		return false;
	});

	// commentform
	var $comments = $("#comments");
	if ($comments.find(".comment").length > 0) {
		// @reply
		var $reply = $(".reply");
		$reply.each(function() {
			var id = $(this).parents(".comment").attr("id");
			var idNum = parseFloat(id.replace(/[^0-9]/ig, ""));
			var name = $("#"+id+"").find(".fn").text();
			var value = "";

			// if no thread comment, add reply button
			if ($(this).find("a").length <= 0) {
				$(this).append("<a href=\"?replytocom="+idNum+"#respond\" rel=\"nofollow\">Reply</a>");
			}

			$(this).find("a").click(function(e) {
				$("#comment").attr({"value": value}).focus();
				$("#cancel-comment-reply-link").show();
				e.preventDefault();
			});
		});
		$("#cancel-comment-reply-link").click(function() {
			$("#comment").attr({value: ""});
			$(this).hide();
			return false;
		});
	}

	if ($("#respond").length > 0) {
		// ctrl+enter to submit comment
		$("#comment").keydown(function(e) {
			if (e.ctrlKey && e.keyCode == 13) {
				$("#submit").click();
				return false;
			}
		});
	}

	// share item tooltips
	$(".shareItem").hover(
		function() {
			shareTips = this.title;
			this.title = "";
			$(this).append("<span id=\"shareTips\">"+shareTips+"</span>");
		},
		function() {
			$("#shareTips").remove();
			this.title = shareTips;
		}
	);
});


