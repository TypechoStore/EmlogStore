// input placeholder
$(function(){
	inputTips("search", "search...");
	if ($("#comments").length > 0) {
		inputTips("author", "Name(required)");
		inputTips("email", "Email(required)");
		inputTips("url", "Website");
		// show labels
		var $textInput = $("#user_info").find(".input");
		$textInput.focus(function() {
			$(this).next(".label").fadeIn("200");
		}).blur(function() {
			$(this).next(".label").hide();
		});
	}
});
function inputTips(theInput, val) {
	var $input = $("#"+theInput+"");
	var val = val;
	$input.attr({value:val});
	$input.focus(function() {
		if ($input.val() == val) {
			$(this).attr({value:""});
		}
	}).blur(function() {
		if ($input.val() == "") {
			$(this).attr({value:val});
		}
	});
}
// search width
$(function() {
	$("#search").focus(function() {
		$(this).css({"width":"90px"});
	}).blur(function() {
		$(this).css({"width":"80px"});
	});
})

