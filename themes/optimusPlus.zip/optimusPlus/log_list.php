<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<section class="content">
	<?php doAction('index_loglist_top'); ?>
		<?php foreach($logs as $value): ?>
		<article class="post postWrap commonWrap">
			<div class="postContainer commonContainer">
				<header class="header">
					<h1 class="postTitle title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h1>
				</header>
				<time class="time" datetime="<?php echo gmdate('Y-m-d', $value['date']); ?>" pubdate>
					<span class="metaDate"><?php echo gmdate('M j, Y', $value['date']); ?><br></span>
					<span class="metaTime"><?php echo gmdate('G:i l', $value['date']); ?></span>
				</time>
				<div class="postContent">
					<?php echo $value['log_description']; ?><div style="clear:both;"></div>
				</div><!-- post content end -->
				<footer class="meta">
					<p class="clearfix">
						<span class="leftCol metaCategory">Categories:<?php blog_sort($value['logid']); ?></span>
						<span class="rightCol metaCategory"><a href="<?php echo $value['log_url']; ?>#comments" class="CommentsNumber"><?php if($value['comnum']==0){echo 'No Comments';}elseif($value['comnum']==1){echo '1 Comment';}else{echo $value['comnum'].' Comments';} ?></a></span>
					</p>
					<p class="clearfix">
						<span class="leftCol metaTags">Tags:<?php blog_tag($value['logid']); ?></span>
						<span class="rightCol metaEdit"><?php editflg($value['logid'],$value['author']); ?></span>
					</p>
				</footer>
			</div><!-- post container end -->
		</article>
		<?php endforeach; ?>
		<div id="pagenavi">
		<nav class="pagenavi">
<?php /*列表分页*/ ?>
<?php if($page_url): ?>
	<?php $pre = $page - 1;$next = $page + 1;$page_all = ceil($lognum / $index_lognum);$pre_url = $pageurl.$pre;$next_url = $pageurl.$next; ?>
	<?php if ($page != $page_all): ?>
		<div class="prev"><a href="<?php echo $next_url; ?>">« Older</a></div>
	<?php endif; ?>
	<?php if ($page != 1): ?>
		<div class="next"><a href="<?php echo $pre_url; ?>">Newer »</a></div>
	<?php endif; ?>
<?php endif; ?>
			<div style="clear:both;"></div>
			</nav>
		</div>
	</section><!-- content -->
<?php
 include View::getView('footer');
?>
