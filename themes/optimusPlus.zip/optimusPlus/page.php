<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<section class="content">
		<article class="post postWrap commonWrap">
			<div class="postContainer commonContainer">
				<header class="header">
					<h1 class="postTitle title"><?php echo $log_title; ?></h1>
				</header>
				<time class="time" datetime="<?php echo gmdate('Y-m-d', $date); ?>" pubdate>
					<span class="metaDate"><?php echo gmdate('M j, Y', $date); ?><br></span>
					<span class="metaTime"><?php echo gmdate('G:i l', $date); ?></span>
				</time>
				<div class="postContent">
					<?php echo $log_content; ?><div style="clear:both;"></div>
				</div><!-- post content end -->
			</div><!-- post container end -->
		</article>
<div id="comments" class="comment_box clearfix">
	<div class="commonWrap">
     	<?php blog_comments($comments,$params); ?>
	    <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
</div><!-- #comments -->
		<div style="clear:both;"></div>
	</section><!-- content -->
<?php
 include View::getView('footer');
?>
