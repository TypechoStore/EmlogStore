<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<section class="content">
		<article class="post postWrap commonWrap">
			<div class="postContainer commonContainer">
				<header class="header">
					<h1 class="postTitle title"><?php topflg($top); ?><?php echo $log_title; ?></h1>
				</header>
				<time class="time" datetime="<?php echo gmdate('Y-m-d', $date); ?>" pubdate>
					<span class="metaDate"><?php echo gmdate('M j, Y', $date); ?><br></span>
					<span class="metaTime"><?php echo gmdate('G:i l', $date); ?></span>
				</time>
				<div class="postContent">
					<?php echo $log_content; ?><div style="clear:both;"></div>
				</div><!-- post content end -->
				<footer class="meta">
					<p class="clearfix">
						<span class="rightCol metaCategory">Categories:<?php blog_sort($logid); ?></span>
					</p>
					<p class="clearfix">
						<span class="leftCol metaTags">Tags:<?php blog_tag($logid); ?></span>
						<span class="rightCol metaEdit"><?php editflg($value['logid'],$value['author']); ?></span>
					</p>
					<p class="clearfix"><?php neighbor_log($neighborLog); ?></p>
				</footer>
			</div><!-- post container end -->
			<div class="att"><?php blog_att($logid); ?></div>
	        <div class="postContainer commonContainer"><?php doAction('log_related', $logData); ?></div>
		</article>
<div id="comments" class="comment_box clearfix">
	<div class="commonWrap">
     	<?php blog_comments($comments,$params); ?>
	    <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
</div><!-- #comments -->
		<div style="clear:both;"></div>
	</section><!-- content -->
<?php
 include View::getView('footer');
?>
