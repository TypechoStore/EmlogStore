<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>
<div style="clear:both;"></div>
<footer class="theFooter clearfix pageFooter">
	<p class="copyright"><a href="<?php echo BLOG_URL; ?>rss.php" title="RSS" target="_blank">RSS</a> | Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>│统计位置<?php echo $footer_info; ?></br> Theme <a class="themeName" href="http://www.alanoy.com/" title="Optimus+" target="_blank">optimus+</a> design by <a href="http://jamiebicknell.tumblr.com/" rel="nofollow" title="J.Bicknell" target="_blank">J.Bicknell</a> 移植 by <a href="http://lixox.net" title="好基友,好盆油" target="_blank">ooxx</a></p>
</footer>
<!--[if lte IE 9]><script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/js/ie.js"></script><![endif]-->
<!--[if gt IE 6]><!--><script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/js/base.js"></script><!--<![endif]-->
<?php doAction('index_footer'); ?>
</body>
</html>
