<?php 
/**
 * 自定义404页面
 * Template Name:LR_em v1.0
 * Description:移植修改自牧师Typecho.us
 * Author:叶雨梧桐
 * Author Url:http://blog.gt520.com
 * Sidebar Amount:1
 * update:20131217
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>404 NOT FOUND</title>
<center>
<style type="text/css">
<!--
body {
color:#333333;
font-family:tahoma,arial,宋体,helvetica,sans-serif;
}
.links {color: #009900}
#main {
	margin-right: auto;
	margin-left: auto;
	width: 920px;
}
-->
</style>
</head>
<body>
<iframe scrolling='no' frameborder='0' src='http://yibo.iyiyun.com/js/yibo404/key/8089' width='640' height='462' style='display:block;'></iframe>
</body></center>
</html>