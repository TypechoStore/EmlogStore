<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
      <div id="content">
         <div id="content-inner">
             <div class="topic-post">
                  <div class="topic-content">
                     <dl id="post-468">
                          <dt>
                                 <?php neighbor_log($neighborLog); ?>
                                 <div class="post-date">
							         <small><?php echo gmdate('M', $date); ?></small>
									 <span><?php echo gmdate('d', $date); ?></span>
							     </div>
                                 <div class="post-title">
                                     <h4>时间：<?php echo gmdate('Y-n-j G:i', $date); ?></h4>
                                     <h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
                                     <h6>
									     <?php blog_sort($logid); ?>&nbsp;&nbsp;|&nbsp;&nbsp;浏览: <em id="spn468"><?php echo $views; ?></em>&nbsp;&nbsp;|&nbsp;&nbsp;
                                         <a href="<?php echo $value['log_url']; ?>#respond"><?php echo $value['comnum']; ?>评论</a>	&nbsp;&nbsp;|&nbsp;&nbsp;<?php editflg($logid,$author); ?>
                                      </h6>
                                </div>
                           </dt>
                           <dd class="post-info">
                             <?php echo $log_content; ?>

                          </dd>	
						  
                     </dl>
		             <?php doAction('log_related', $logData); ?>
                  </div>
            </div>
            <div class="comment_box">
               <?php blog_comments($comments); ?>
	           <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	         </div>
	
	     </div>
	  </div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>