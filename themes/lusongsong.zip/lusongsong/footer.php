<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
 </div><!--end #container-->

<div id="footer">
    <ul>
       <li class="copyright">
             <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> 
            |  Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> 
             <br>
            <a href="http://meitu.skyguo.com/" title="鬼鬼">THeME BY 鬼鬼</a>
       </li>
       <li><?php echo $footer_info; ?></li>
       <li><?php doAction('index_footer'); ?></li>
        <li><a title="鬼鬼" target="_blank" rel="nofollow" href="http://meitu.skyguo.com/">【广告服务】</a></li>
     </ul>
</div><!--end #footer-->
</div><!--end #wrapper-->
	  <div >
 <a class="scroll-to-top">返回顶部</a> 

</div>
</body>
</html>