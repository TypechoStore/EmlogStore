<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
     <div id="content">
         <div id="content-inner">
             <?php doAction('index_loglist_top'); ?>
             <?php foreach($logs as $value): ?>
             <div class="post-list">
                  <div class="topic-content">
                      <div class="post-date">
                          <small><?php echo gmdate('M', $value['date']); ?></small>
                          <span><?php echo gmdate('d', $value['date']); ?></span>
					  </div><!--end 结束日期-->
                      <div class="post-title">
                            <h2>
						          <?php topflg($value['top']); ?>
						          <a href="<?php echo $value['log_url']; ?>">
						          <?php echo $value['log_title']; ?></a>
						     </h2>
                            <span class="comments">
	                             <a href="<?php echo $value['log_url']; ?>#comments">
                                 <em><?php echo $value['comnum']; ?></em> 人评论</a>
                            </span>
                            <h6>&nbsp;&nbsp;作者: <?php blog_author($value['author']); ?>&nbsp;&nbsp; 
                                <?php blog_sort($value['logid']); ?>&nbsp;&nbsp;浏览:<span><?php echo $value['views']; ?></span>
                            </h6>
                       </div>
                       <div class="post-list-info">
                             <?php echo $value['log_description']; ?>
                       </div>
                      <div class="the-comment-tags">
                             <span><?php blog_tag($value['logid']); ?>&nbsp;&nbsp;</span>
                             <em><a title="<?php echo $value['log_title']; ?> 上的评论" href="<?php echo $value['log_url']; ?>#comment">评论人数<?php echo $value['comnum']; ?>人 【我来说两句】</a></em>
                       </div>
                   </div>
            </div>
            <?php endforeach; ?>
            <div class="pagenavi">
	        <?php echo $page_url;?>
            </div>
        </div>
     </div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>