<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
    <div id="content">
         <div id="content-inner">
             <div class="topic-post">
                 <div class="topic-content">
                     <dl id="post-468">
                         <dt>
                              <div class="post-nav">
                                 <br>
                              </div>
                              <div class="post-title">
                                     <h4>时间：<?php echo gmdate('Y-n-j G:i l', $date); ?></h4>
                                     <h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
                                     <h6>
									     <a href="<?php echo $value['log_url']; ?>#respond"><?php echo $value['comnum']; ?>评论</a>&nbsp;&nbsp;
                                          <?php editflg($logid,$author); ?>
                                     </h6>
                             </div>
                         </dt>
                         <dd class="post-info">
                             <?php echo $log_content; ?>

                         </dd>
                     </dl>

	
                 </div>
             </div><!-- end #topic-post-->
            <?php blog_comments($comments); ?>
	        <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
         </div><!-- end #content-inner-->
	</div><!-- end #content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>