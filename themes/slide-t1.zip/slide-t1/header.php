<?php
/*
Template Name: Slide-T1 (单栏)
Description: 独头阿道-荣誉出品
Version: 1.5.0
Author: yuadao
Author Url: http://emlog8.sinaapp.com/
Sidebar Amount: 1
ForEmlog: 5.0.x
*/
if (!defined('EMLOG_ROOT')) {exit('error!');}
require_once (View::getView('module')); //模板核心函数
require_once (View::getView('user-defined')); //自定义函数
if (function_exists('emLoadJQuery')) {emLoadJQuery();} //JQ库函数
//模板设置
$template_mode = 0; //模板分栏样式：0 - 单栏；1 - 仅首页单栏
$bloginfo_mode = 0; //博客名称样式：0 - 博客名称；1 - LOGO图标
$friends_display = 0; //首页底部是否显示友情链接：0 - 不显示；1 - 显示
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<link rel="icon" href="favicon.gif" type="image/gif" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<?php if ($template_mode != 0): ?>
    <style type="text/css">img {max-width:520px;}</style>
<?php endif; ?>
<script type="text/javascript" src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/myfunction.js"></script>
<?php doAction('index_head'); ?>
</head>

<body>
<div id="topbar">
    <div id="top">
    <div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare">
        <a class="bds_qzone"></a>
        <a class="bds_tsina"></a>
        <a class="bds_tqq"></a>
        <a class="bds_renren"></a>
        <span class="bds_more"></span>
        <!--<a class="shareCount"></a>-->
    </div>
    </div>
</div>
<div id="anchor"><a name="top"></a><!--设置顶部锚点--></div>
<div id="wrap-border">
<div id="wrap"><!--内容外框-->
    <div id="header">
        <div id="bloginfo">
        <?php
        if ($bloginfo_mode == 0): ?>
            <div id="blog-name"><!--博客名称-->
                <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>&nbsp;<a href="<?php echo BLOG_URL; ?>rss.php" title="订阅本站RSS"><img src="<?php echo TEMPLATE_URL; ?>images/rss2.gif" alt="订阅Rss" class="rss" /></a>
            </div>
            <div id="blog-desc">── <?php echo $bloginfo; ?></div>
        <?php else: ?>
            <div id="logo"><!--LOGO图标，默认大小为：240x60-->
            <a href="<?php echo BLOG_URL; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/logo.gif" /></a>
            </div>
        <?php endif; ?>
        </div>
        <div id="banner"><!--图片尺寸：468x60，可作广告位-->
            <a href="#"><img src="<?php echo TEMPLATE_URL.'images/banner.jpg'; ?>" /></a>
        </div>
        <div class="clear" /></div>
    </div>
    <div class="hr1"></div>
    <div id="navbar">
        <div id="nav"><?php blog_navi();?></div>
        <div id="logsearch" style="width:165px;"><!--搜索框-->
            <form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
                <input name="keyword" type="text" class="search" style="width:110px; margin:4px auto;" />
            </form>
        </div>
        <div class="clear" /></div>
    </div>
    <div class="hr2"></div>
    <div id="frame"<?php if(($curpage != CURPAGE_HOME)&&($template_mode != 0)){echo ' style="background:url('.TEMPLATE_URL.'images/bg_midline.gif) repeat-y;"';} ?> />
<!--herder.End-->
