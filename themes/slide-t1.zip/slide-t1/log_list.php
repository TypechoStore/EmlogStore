<?php
/*
 *首页日志列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="content">
<?php doAction('index_loglist_top'); ?>
<div class="content-box" style="margin-top:0px;">
    <div id="top-loglist">
        <div id="list-tit1" class="list-title">
            <div class="list-titles">分类-标签</div>
            <div id="list-cont1" class="list-content">
            <div class="list-cont-box">
                <div class="loglist-sort-box">
                    <?php
                    //获取分类
                    global $CACHE;
                    $sort_cache = $CACHE->readCache('sort');
                    foreach($CACHE->readCache('sort') as $value): ?>
                    <div class="loglist-sort"><img src="<?php echo TEMPLATE_URL; ?>images/sort.gif"><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?></a></div>
                    <?php endforeach; ?>
                </div>
                <?php getColorTags(0); ?>
                <div class="clear"></div>
            </div>
            </div>
        </div>
        <div id="list-tit2" class="list-title">
            <div class="list-titles">推荐日志</div>
            <div id="list-cont2" class="list-content">
            <div class="list-cont-box">
                <?php getTopLogs(10); ?>
            </div>
            </div>
        </div>
        <div id="list-tit3" class="list-title">
            <div class="list-titles">热评日志</div>
            <div id="list-cont3" class="list-content">
            <div class="list-cont-box">
                <?php getHotLogs(10); ?>
            </div>
            </div>
        </div>
        <div id="list-tit4" class="list-title">
            <div class="list-titles">热门日志</div>
            <div id="list-cont4" class="list-content">
            <div class="list-cont-box">
                <?php getHotViewLogs(10); ?>
            </div>
            </div>
        </div>
        <div id="list-tit5" class="list-title">
            <div class="list-titles">随机日志</div>
            <div id="list-cont5" class="list-content">
            <div class="list-cont-box">
                <?php getRandLogs(10); ?>
            </div>
            </div>
        </div>
        <div class="clear"></div>
    </div>
    <div id="top-imgplay">
        <div id="photo">
            <?php top_imgplay(5,1); ?>
        </div>
    </div>
    <div class="clear"></div>
</div>
<div class="line2"></div>
<?php foreach($logs as $value): ?>
<div class="content-box">
    <div class="thum">
        <div class="thum-pho">
            <?php
            //-获取缩略图
            $template_name = str_replace(BLOG_URL,"",TEMPLATE_URL);
            $template_name = str_replace("content/templates/","",$template_name);
            $template_name = str_replace("/","",$template_name);
            //以上三句代码获取模板目录名称
            $thum_file = EMLOG_ROOT.'/content/templates/'.$template_name.'/thumbnail/gid/'.$value['gid'].'.jpg';
            if (is_file($thum_file)) {
                $thum_src = TEMPLATE_URL.'/thumbnail/gid/'.$value['gid'].'.jpg';
                //ID编号配图
            }else{
                $thum_src = get_Attachment_img($value['logid'],0); //附件第一张图片
                if (empty($thum_src)) {
                    $rand_num = 12; //随机图片数量，按实际数量设置
                    if ($rand_num == 0) {
                        $thum_src = TEMPLATE_URL."thumbnail/0.jpg";
                        //默认图片，须命名为"0.jpg"
                    }else{
                        $thum_src = TEMPLATE_URL."thumbnail/random/".rand(1,$rand_num).".jpg";
                        //随机图片，须按"1.jpg","2.jpg","3.jpg"...的顺序命名
                    }
                }
            }
            //ID编号配图(gid目录)、默认图片(0.jpg)、随机图片(random目录)，都保存在模板目录中的"thumbnail"目录下，以便于集中管理
            ?>
            <a href="<?php echo $value['log_url']; ?>"><img src="<?php echo $thum_src; ?>" /></a>
        </div>
        <div class="thum-comm">
            <a href="<?php echo $value['log_url']; ?>">浏览 (<?php echo $value['views']; ?>)</a> &nbsp;
            <a href="<?php echo $value['log_url']; ?>#comments">评论 (<?php echo $value['comnum']; ?>)</a>
            <!--<a href="<?php //echo $log_url; ?>#tb">引用(<?php //echo $tbcount; ?>)</a> &nbsp;-->
        </div>
    </div>
    <div class="desc">
        <div class="desc-tit">
            <font class="top"><?php topflg($value['top']); ?></font><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
        </div>
        <div class="desc-data">
            <i>本文由 &nbsp;<?php echo blog_author($value['author']); ?> 发布于 <?php echo gmdate('Y-n-j', $value['date']); ?></i> &nbsp; <?php editflg($value['logid'],$value['author']); ?>
        </div>
	       <div class="desc-txt">
            <?php echo $value['log_description']; ?>
            <div class="clear"></div>
        </div>
        <!--非图形附件列表，5.0己非必须-->
        <!--<div class="att"><?php //blog_att($value['logid']); ?></div>-->
    </div>
    <div class="addi">
        <div class="addi-sort"><img src="<?php echo TEMPLATE_URL; ?>images/sort.gif"><?php blog_sort($value['logid']); ?></div>
        <div class="addi-tag">&nbsp; <?php blog_tag($value['logid']); ?></div>
    </div>
    <div class="clear"></div>
</div>
<div class="line2"></div>
<?php endforeach; ?>
<div class="clear" style="height:7px;"></div>
<div id="pagenavi"><?php echo $page_url; ?></div>
<div class="blank"></div>
<!-- 友情链接 -->
<?php if ($friends_display != 0): ?>
<div class="content-box">
    <div id="friends">
        <span class="title" style="margin-bottom:8px">友情链接</span> &nbsp;
        <?php
        global $CACHE; 
        $link_cache = $CACHE->readCache('link'); ?>
        <?php foreach($link_cache as $value): ?>
            <?php if(!strstr($value['link'],'#')): ?>
            <a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a> &nbsp;
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>
<!-- 友情链接.End -->
</div><!--#content.End-->

<?php
    //include View::getView('side'); //首页无侧栏
    include View::getView('footer');
?>
