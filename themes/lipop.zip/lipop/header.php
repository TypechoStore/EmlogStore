<?php
/*
Template Name:Lipop移植模版
Description:lipop移植
Version:1.0
Author:svch0st
Author Url:http://www.dosec.pw
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='ajax-comment-css'  href='<?php echo TEMPLATE_URL; ?>/includes/ajax-comment.css?ver=4.2.2' type='text/css' media='all' />
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>/includes/ajax-comment.js?ver=4.2.2'></script>
<link rel="shortcut icon" href="<?php echo TEMPLATE_URL; ?>/images/favicon.ico" />
<link rel="stylesheet" type="text/css" media="all" href="<?php echo TEMPLATE_URL; ?>/main.css">
<link rel="stylesheet" type="text/css" media="all" href="<?php echo TEMPLATE_URL; ?>/css/font-awesome.min.css" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/lipop.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/ajax.js"></script>
<?php doAction('index_head'); ?>
</head>
<body>
	<script src="<?php echo TEMPLATE_URL; ?>js/js.js" data-no-instant></script>
<script data-no-instant>InstantClick.init();</script>
<div class="wrap">
<div class="header">
<div class="hidelist">
	<i class="fa fa-bars fa-2x"></i>
	<div style="display:none;" ><a href="www.dosec.pw">Svch0st's Blog</a></div>
</div>
<div class="search">
<form class="searchform themeform" method="get" action="<?php echo BLOG_URL; ?>index.php" class="searchform themeform">
	<input name="keyword" type="text" onblur="if(this.value=='')this.value='按回车键搜索...';" onfocus="if(this.value=='按回车键搜索...')this.value='';" value="按回车键搜索..." placeholder="按回车键搜索" style="display: inline-block; width: 120px;"/>
	</form>
        </div>
        <div id="nav">
		<?php blog_navi();?>
			</div>
</div>
	
<div class="author">
<img class="avatar" src="<?php echo TEMPLATE_URL; ?>/images/avatar.jpg">
<div class="titleright">
<p class="title"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></p>
<p class="description"><?php echo $bloginfo; ?></p>
<span class="call">
<a href="<?php echo BLOG_URL; ?>rss.php"><i class="fa fa-2x fa-rss"></i></a>
<a href="#"><i class="fa fa-2x fa-qq"></i></a>
<a href="#"><i class="fa fa-2x fa-weibo"></i></a>
<a href="javascript:"><i class="fa fa-2x fa-weixin"></i></a>
<a href="#" target="_blank" title="github"><i class="fa fa-github-square fa-2x"></i></a>
<span>
</span></span></div>
</div>