<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="container">
			<?php doAction('index_loglist_top'); ?>
			<?php
foreach($logs as $value): ?>

		<div class="block">
             <h1><?php topflg($top); ?>
            <a href="<?php echo $value['log_url']; ?>">
            	<?php echo $value['log_title']; ?>
            </a>
        </h1>
          <div class="text">
		              <p>
            <?php echo $value['log_description']; ?>
            </p>
          </div>
			<span class="post-time"> <?php echo gmdate('Y-n-j', $value['date']); ?> 
				| <?php echo $value['views']; ?>阅读 |  
				<a href="<?php echo $value['log_url']; ?>#comments">
					<?php echo $value['comnum']; ?> 条评论
				</a>
			</span>
		    <span class="post-more">
		    	<a target="_blank" href="<?php echo $value['log_url']; ?>">阅读全文
		    	</a>
		    </span>
        </div>
         <?php endforeach; ?>
         <div class="page"></div>
         </div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>