<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
      <div class="article">
          <div class="titles">
      <h1><?php topflg($top); ?><?php echo $log_title; ?></h1>
      <div class="info">
        <span><?php echo gmdate('Y-n-j', $date); ?> | 
          <?php echo $views; ?> 阅读 | 
          <?php blog_sort($logid); ?>
        </span>
        </div> 
      </div>
<?php extract($neighborLog);if($prevLog){
echo '<div id="prevlog"><a href="'.Url::log($prevLog['gid']).'" title="'.$prevLog['title'].'"></a></div>';}
else{
echo '<div id="prevlog"><a href="#" title="没有上一篇了"></a></div>';};
if($nextLog){
echo '<div id="nextlog"><a href="'.Url::log($nextLog['gid']).'" title="'.$nextLog['title'].'"></a></div>';}
else{
echo '<div id="nextlog"><a href="#" title="没有下一篇了"></a></div>';};?>
    </div>
    </div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>