<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="footer"> 
	&copy; 20<?php echo date('y',time());?> <?php echo $blogname;?>. All Rights Reserved.
	<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>
	<?php echo $footer_info; ?>
	<div class="floattop"><i class="fa fa-arrow-circle-up fa-3x"></i></div>
	<?php doAction('index_footer'); ?>
</div></div>
</body>
</html>