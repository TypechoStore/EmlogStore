<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
      <div class="article">
      	  <div class="titles">
      <h1><?php topflg($top); ?><?php echo $log_title; ?></h1>
      <div class="info">
        <span><?php echo gmdate('Y-n-j', $date); ?> | 
        	<?php echo $views; ?> 阅读 | 
        	<a href="<?php echo $log_url; ?>#comments"><?php echo $comnum; ?> 条评论</a> |
        	<?php blog_sort($logid); ?>
        </span>
        </div> 
      </div>
		<div class="text">
      <p class="post-tag">
         &nbsp;&nbsp;关键字:<?php blog_tag($logid); ?></p><br>
        <?php echo $log_content; ?>
          </div><br>
        <p class="post-copyright">转载请注明出处 : <a href="<?php echo BLOG_URL; ?>">Svch0st's Blog</a> >>
            <a href="<?php echo $value['log_url']; ?>"><?php echo $log_title?></a>
        </p>
<?php extract($neighborLog);if($prevLog){
echo '<div id="prevlog"><a href="'.Url::log($prevLog['gid']).'" title="'.$prevLog['title'].'"></a></div>';}
else{
echo '<div id="prevlog"><a href="#" title="没有上一篇了"></a></div>';};
if($nextLog){
echo '<div id="nextlog"><a href="'.Url::log($nextLog['gid']).'" title="'.$nextLog['title'].'"></a></div>';}
else{
echo '<div id="nextlog"><a href="#" title="没有下一篇了"></a></div>';};?>
      
<div id="comments"><span><?php echo $comnum; ?> 条评论</span></div>
<br>
            <div class="con pinglun" id="pinglun">
              <?php blog_comments($comments); ?>
              <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
            </div>
    </div>
    </div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>
