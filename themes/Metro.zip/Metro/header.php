<?php
/*
Template Name:Metro5.1.2(LaoLuo升级版)
Description:魔法基佬的Win Metro主题1.2版升级，LaoLuo升级并修改了下，喜欢的拿走。
Version:1.3
Author:星星水(LaoLuo升级)
Author Url:http://www.xxshui.com/
Sidebar Amount:0
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
if(function_exists('emLoadJQuery')) {
    emLoadJQuery();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php if($url == Url::log($logid)){;?><?php blog_tag($logid); ?> <?php echo $site_key;?>
    <?php }else{?><?php echo $site_key;}?>" />
	<meta name="description" content="<?php if($url == Url::log($logid)){subString(strip_tags($log_content),0,80);
    }else{echo''.$site_description.'';}?>" />
	<meta name="generator" content="emlog" />
	<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
	<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
	<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
    <link type="text/css" href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" />
	<?php doAction('index_head'); ?>
	<!--[if lt IE 9]>
	<script src="<?php echo TEMPLATE_URL; ?>js/ie.js"></script>
	<script src="//cdn.bootcss.com/html5shiv/r29/html5.min.js"></script>
	<![endif]-->
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/lazyload.js"></script>
<script type="text/javascript">
jQuery(document).ready(function($){
  if (navigator.platform == "iPad") return;
  jQuery("img").lazyload({
    effect:"fadeIn",
    placeholder: "<?php echo TEMPLATE_URL; ?>images/grey.gif"
  });
});
</script>
</head>
	<body>
	<div id="wrap">
	<div id="header">
 <div class="logo">
<h1><a href="<?php echo BLOG_URL; ?>about.html" title="关于站长">
<?php global $CACHE;
        $user_cache = $CACHE->readCache('user');
$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
<?php if (!empty($user_cache[1]['photo']['src'])): ?>
        <img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="200" height="200" alt="blogger" />
<?php endif;?>
</a></h1>
<span class="vpbg"></span>
<span class="vinf"><h3><?php echo $bloginfo; ?></h3></span>
</div>
    <!--MenuNav Stard-->
	<div id="nav"><?php blog_navi();?></div>
    <!--MenuNav End-->
  </div>
    <!--conment Stard-->
  <div id="bomb">
  <?php {
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
  <ul class="recentcomments">
    <h3>Comments</h3>
    <?php
	foreach($com_cache as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	?>
    <li><img src="http://www.gravatar.com/avatar/<?php  echo md5($value['mail']); ?>" width="34" height="34" class="avatar" title="<?php echo $value['name']; ?>" /><?php echo $value['name']; ?> <br />
      <a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a></li>
    <?php endforeach; ?>
  </ul>
  <?php }?>
  <div class="arrow"></div>
	    	<?php doAction('diff_side'); ?>
</div>
    <!--conment End-->
  <!-- end #header-->