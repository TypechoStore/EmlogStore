<?php
/*
Template Name:Metro
Description:魔法基佬的Win Metro主题1.1版修复，所以就叫做1.2版
Version:1.3
Author:星星水
Author Url:http://www.xxshui.com/
Sidebar Amount:0
ForEmlog:4.2.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
if(function_exists('emLoadJQuery')) {
    emLoadJQuery();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php if($url == Url::log($logid)){;?><?php blog_tag($logid); ?> <?php echo $site_key;?>
    <?php }else{?><?php echo $site_key;}?>" />
	<meta name="description" content="<?php if($url == Url::log($logid)){subString(strip_tags($log_content),0,80);
    }else{echo''.$description.'';}?>" />
	<meta name="generator" content="emlog" />
	<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
	<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
	<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
    <link type="text/css" href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" />
	<?php doAction('index_head'); ?>
	<!--[if lt IE 9]>
	<script src="<?php echo TEMPLATE_URL; ?>js/ie.js"></script>
	<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/lazyload.js"></script>
<script type="text/javascript">
jQuery(document).ready(function($){
  if (navigator.platform == "iPad") return;
  jQuery("img").lazyload({
    effect:"fadeIn",
    placeholder: "<?php echo TEMPLATE_URL; ?>images/grey.gif"
  });
});
</script>
	</head>
	<body>
	<div id="wrap">
	<div id="header">
 <div class="logo">
<h1><a href="<?php echo BLOG_URL; ?>about.html" title="关于站长">
<?php global $CACHE;
        $user_cache = $CACHE->readCache('user');
$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
<?php if (!empty($user_cache[1]['photo']['src'])): ?>
        <img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="200" height="200" alt="blogger" />
<?php endif;?>
</a></h1>
<span class="vpbg"></span>
<span class="vinf"><h3><?php echo $bloginfo; ?></h3></span>
</div>
    <!--MenuNav Stard-->
    <div id="nav">
	<div id="navhead">
	  <ul id="menu" class="menu">
        <li class="home"><a title="首页" href="<?php echo BLOG_URL; ?>">Home</a></li>
        <?php if($istwitter == 'y'):?><li class="twi"><a href="<?php echo BLOG_URL; ?>t/">微语</a></li><?php endif;?>
		<li class="host"><a title="推荐主机" href="<?php echo BLOG_URL; ?>host-sugarhosts-sihost-emlog.html">Host</a></li>
        <li class="archive"><a title="归档" href="<?php echo BLOG_URL; ?>?plugin=archiver">Archive</a></li>
		<li class="guestbook"><a title="留言" href="<?php echo BLOG_URL; ?>guestbook.html">Guestbook</a></li>
		      <!-- 
			  <li class="friend "></li>
              -->		
  <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
  <li class="write"><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
  <li class="admin"><a href="<?php echo BLOG_URL; ?>admin/" target="_blank">管理中心</a></li>
  <li class="logout"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
  <?php else: ?>
  <li class="login"><a href="<?php echo BLOG_URL; ?>admin/" rel="nofollow">Login</a></li>
  <?php endif; ?>
      </ul>
    </div>
	</div>
    <!--MenuNav End-->
  </div>
    <!--conment Stard-->
  <div id="bomb">
  <?php {
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
  <ul class="recentcomments">
    <h3>Comments</h3>
    <?php
	foreach($com_cache as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	?>
    <li><img src="http://www.gravatar.com/avatar/<?php  echo md5($value['mail']); ?>" width="34" height="34" class="avatar" title="<?php echo $value['name']; ?>" /><?php echo $value['name']; ?> <br />
      <a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a></li>
    <?php endforeach; ?>
  </ul>
  <?php }?>
  <div class="arrow"></div>
	    	<?php doAction('diff_side'); ?>
</div>
    <!--conment End-->
  <!-- end #header-->