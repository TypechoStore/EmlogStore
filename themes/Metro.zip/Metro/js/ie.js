document.write('<style>nav,#content,#overlay,#ie_alert{z-index:999;filter:alpha(opacity=80)}#ie_alert{color:#f60;text-align:center;position:absolute;width:100%;background:#111;padding:5px;top:0;left:0}#close_alert{position:absolute;top:5px;right:1em;font:14px/1em arial;border:solid 1px #f60;padding:2px 5px;cursor:pointer}</style>');
'abbr article aside audio canvas datalist details figcaption figure footer header hgroup mark meter nav output progress section summary time video'.replace(/[^ ]+/g,function(s){document.createElement(s)});
~function R(f){
	/in/.test(document.readyState)?
	setTimeout('R('+f+')',9):f();
}(function(){
	var d=document,b=d.body,oDiv=d.createElement('div'),iDiv=d.createElement('div');
	oDiv.innerHTML='亲！建议使用WebKit内核浏览器, 效果更佳!推荐您升级到<a href="http://apple.com/safari" target="_blank">Safari</a>, <a href="http://chrome.google.com">Chrome</a>, <a href="http://windows.microsoft.com/zh-CN/internet-explorer/downloads/ie-9/worldwide-languages" target="_blank">IE9</a>及以上或<a href="http://www.getfirefox.com" target="_blank">Firefox</a>, <a href="http://opera.com" target="_blank">Opera</a>等浏览器！如果你换用搜狗/遨游3/360极速版等双核浏览器，建议切换到高速模式！';
	iDiv.innerText='X';iDiv.id='close_alert';
	iDiv.onclick=function(){
		b.removeChild(oDiv);
		iDiv.onclick=null;
		return false;
	};
	oDiv.id='ie_alert';
	oDiv.appendChild(iDiv);
	b.insertBefore(oDiv,b.firstChild);
});