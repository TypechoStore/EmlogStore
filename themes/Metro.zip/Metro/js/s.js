   var m=14;
    var n=Math.floor(Math.random()*m+1) 
    switch(n)
    { 
    case 1:    
document.write('<div class="magenta">');
    break;   
    case 2: 
document.write('<div class="purple">');
    break;    
    case 3: 
document.write('<div class="teal">');
    break;     
    case 4:    
document.write('<div class="lime">');
    break;   
    case 5:    
document.write('<div class="brown">');
    break;   
    case 6:    
document.write('<div class="pink">');
    break;   
    case 7:    
document.write('<div class="orange">');
    break;   
    case 8:    
document.write('<div class="b1ue">');
    break;   
    case 9:    
document.write('<div class="red">');
    break;   
    case 10:    
document.write('<div class="green">');
    break;   
    case 11:    
document.write('<div class="marine">');
    break;   
    case 12:    
document.write('<div class="purple2">');
    break;   
    case 13:    
document.write('<div class="teal2">');
    break;   
    case 14:    
document.write('<div class="dark">');
    break;   
    } 