﻿<?php 
/*
* 自定义404页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Orz,404......</title>
<style type="text/css">
a {
-webkit-transition-property: color, background-color;
-moz-transition-property: color, background-color;
-o-transition-property: color;
-ms-transition-property: color;
transition-property: color;
-webkit-transition-duration: 0.3s;
-moz-transition-duration: 0.3s;
-o-transition-duration: 0.3s;
-ms-transition-duration: 0.3s;
transition-duration: 0.3s;
-webkit-transition-timing-function: ease;
-moz-transition-timing-function: ease;
-o-transition-timing-function: ease;
-ms-transition-timing-function: ease;
transition-timing-function: ease;
}
.sfbody{ text-align:center; background:#1273aa;}
.head { margin:100px auto 0; background:url(http://img26.wal8.com/img26/294697_20121019235029/135066184515.png) no-repeat; width:720px; height:260px;}
.foot {margin:50px auto 0;width:720px;}
.home,.search { border:2px solid #FFFFFF; padding:5px 20px; float:right; color:#FFF; margin:0 10px 0 0; font-weight:bold; font-size:12px; text-decoration:none;}
.home:hover,.search:hover { background:#1FAEFF;}

</style>
</head>

<body class="sfbody">
<div><div class="head"></div><div class="foot"><a href="http://niandailu.com/" class="home"><div>回到主页</div></a><a href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=1rq3ubqjub63tb2zpJagv6b4p6f4tbm7" class="search"><div>找我反馈</div></a></div></div>
</body>
</html>