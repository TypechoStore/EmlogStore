<?php 
/*
底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!--wumi stard-->
<?php
if ($type == 'blog') { echo <<<LOADSCRIPT

<script type="text/javascript">
    var wumiiParams = "&num=5&mode=3&pf=emlog";
</script>
<script type="text/javascript" id="wumiiRelatedItems" src="http://widget.wumii.com/ext/relatedItemsWidget"></script>
<a href="http://www.wumii.com/widget/relatedItems" style="border:0;">
    <img src="http://static.wumii.com/images/pixel.png" alt="无觅相关文章插件，快速提升流量" style="border:0;padding:0;margin:0;" />
</a>
LOADSCRIPT;
}
?>
<!--wumi End-->
<div id="footer">
   <div id="tool_bar"><form name="keyform" method="get" id="searchform" action="<?php echo BLOG_URL; ?>index.php">
      <input type="text" name="keyword" class="s" placeholder="Search" x-webkit-speech>
    </form>
<div id="contact">
    <ul>
<li><a href="<?php echo BLOG_URL; ?>rss.php" class="rssfeed" target="_blank" title="RSS订阅"></a></li>
<li><a href="mailto:mail@xxshui.com" class="mail" title="给我发邮件" rel="external nofollow">给我发邮件</a></li>
<li><a href="http://t.qq.com/xxshui2010" class="tqq" title="腾讯微薄" target="_blank" rel="external nofollow">腾讯微薄</a></li>
<li><a href="http://weibo.com/525855671" class="weibo" title="新浪微博" target="_blank" rel="external nofollow">新浪微博</a></li>
<li><script>var online= new Array();</script> 
<script src="http://webpresence.qq.com/getonline?Type=1&356281742:"></script>
<script>if(online[0]==0){document.write('<a class="QQ" alt="离线留言" title="离线留言" target="_blank" href="http://wpa.qq.com/msgrd?v=1&uin=356281742&site=qq&menu=yes" rel="external nofollow"></a>')}else{document.write('<a class="QQ" target="_blank" alt="QQ聊天" title="QQ在线" href="http://wpa.qq.com/msgrd?v=1&uin=356281742&site=qq&menu=yes" rel="external nofollow"></a>')} </script></li>
    </ul>
  </div>
<div id="go-top"><a title="回顶部" href="javascript:void()">回顶部</a></div></div>
    <div class="credits"> 
	&copy; <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>
	由<a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank" rel="external nofollow">EMLOG</a>驱动<br/>
	<a href="http://hmoe.me/" target="_blank" title="Theme by 魔法基佬">Hmoe</a> And
	<a href="http://www.xxshui.com/" target="_blank" title="To alter 星星水">Xxs</a>伪装 <!--这里是统计代码 开始--><?php echo $footer_info; ?><!--这里是统计代码 结束--><br/>
	<?php doAction('index_footer'); ?>
	<a href="http://www.miibeian.gov.cn" target="_blank"  rel="nofollow"><?php echo $icp; ?></a>
    </div>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/common_tpl.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/x.js"></script>
  </div><!--end #footerbar-->
<?php if(isset($ckmail) && empty($ckmail)): ?>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/realgravatar.js"></script>
<?php endif; ?>
</body>
</html>