<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div class="post div">
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/s.js"></script>
<h2><?php topflg($top); ?><?php echo $log_title; ?></h2></div>
    <div class="data">
    <span class="post-time"><?php blog_author($author); ?> post by：<?php echo gmdate('Y-n-j G:i l', $date); ?></span>
    <span class="post-sort">Posted in <?php blog_sort($logid); ?></span>
    <span class="post-count" id="go-comments"><a title="点我查看 <?php echo $log_title; ?> 上的评论" href="javascript:void()"><?php echo $comnum; ?></a></span> <span class="post-views"><?php echo $views; ?></span>
	      <?php editflg($logid,$author); ?>
    </div>
     <div class="post-content">
     <ul><?php echo $log_content; ?></ul>
     <div class="post-footer"> <span class="post-tag">Tags: <?php blog_tag($logid); ?></span>
     </div>
     <div id="copyright">»版权所有：《<a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>"><?php echo $blogname; ?></a>》 → 《<a title="<?php echo $log_title; ?>" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];?>"><?php echo $log_title; ?></a>》；<br>
      »本文网址：<a title="<?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];?>" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];?>"><?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];?></a> ；<br>
      »除特别标注,本博客所有文章均为原创. 互联分享,尊重版权,转载请以链接形式标明本文地址；    
    </div>
    <div class="baidudiv"><!-- Baidu Button BEGIN -->
    <div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare">
        <a class="bds_tsina"></a>
        <a class="bds_tqq"></a>
        <a class="bds_qzone"></a>
        <a class="bds_tqf"></a>
        <a class="bds_douban"></a>
        <a class="bds_renren"></a>
        <a class="bds_t163"></a>
        <a class="bds_tsohu"></a>
        <a class="bds_hi"></a>
        <a class="bds_kaixin001"></a>
        <a class="bds_zx"></a>
        <a class="bds_fx"></a>
        <a class="bds_ty"></a>
        <a class="bds_taobao"></a>
        <a class="bds_ff"></a>
        <a class="bds_fbook"></a>
        <a class="bds_twi"></a>
        <a class="bds_baidu"></a>
        <a class="bds_qq"></a>
        <a class="bds_copy"></a>
        <span class="bds_more">更多</span>
		<a class="shareCount"></a>
    </div>
<script type="text/javascript" id="bdshare_js" data="type=tools&uid=711059" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
	document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + new Date().getHours();
</script>
<!-- Baidu Button END -->
		     <?php blog_att($logid); ?>
                  </div>
     </div>
</div>
  <div id="neigh">
          <div class="nex div">
          <?php neighbor_log($neighborLog); ?>
        </div>
		</div>
  <div class="shui div">
  <!-- 热门、相关开始 -->
<div style="float:right; width:49%; word-break:keep-all;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
<h3>热门文章</h3>
<?php $date = time() - 3600 * 24 * 360;
      $Log_Model = new Log_Model();
	  $viewslogs = $Log_Model->getLogsForHome("AND date > {$date} ORDER BY views DESC,date DESC", 1, 5);?>
<ul>
<?php foreach($viewslogs as $value): ?>
<li><a href="<?php echo $value['log_url']; ?>" title="查看文章:<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></li>
<?php endforeach; ?>
</ul>
</div>
<div style="float:left; width:49%; word-break:keep-all;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
<h3>相关文章</h3>
<?php $Log_Model = new Log_Model();
	  $randlogs = $Log_Model->getLogsForHome("AND sortid = {$sortid} ORDER BY rand() DESC,date DESC", 1, 5);?>
<ul>
<?php foreach($randlogs as $value): ?>
<li><a href="<?php echo $value['log_url']; ?>" title="查看文章:<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></li>
<?php endforeach; ?>
</ul>
</div>
  <!-- 热门、相关结束 -->
<div style="text-align:center;width:100%; max-height:165px; word-break:keep-all;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><!-- app.wumii.com-->					  
<div class="wumii-hook">
<input type="hidden" name="wurl" value="<?php echo Url::log($logid); ?>" />
<input type="hidden" name="wtitle" value="<?php echo $log_title; ?>" />
</div>
<script>
    var wumiiSitePrefix = "<?php echo BLOG_URL; ?>";
</script>
<!-- app.wumii.com-->
</div>
</div>
  <div class="gg div">
      <?php doAction('log_related', $logData); ?>
       </div>
	<?php blog_comments($comments,$params); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
<?php
 include View::getView('footer');
?>