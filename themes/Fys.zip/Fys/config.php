<?php
				 $timedate = '2016-8-1';
				 $timehide = '1';
				 $logo_url = 'http://0d077ef9e74d8.cdn.sohucs.com/qzLPWJx_png';
				 $bg_url = 'http://0d077ef9e74d8.cdn.sohucs.com/qzRPMPA_jpg';
				 $nexqq = '1444762288';
	 			 $new_log_num = '2017</br>FYS二开大前端';
				 $web_method = '3';
				 $navhide = '2';
				 $home_text = '<ul>
<li><time>11-2</time><a target="_blank" href="http://www.17uw.cn/i/323">大前端DUX主题二开Fys1.0版本更新、免费开源下载</a></li>
					
</ul>';
		         $radio_zhiding = '2';
		         $heightkeycolor = '';
		         $top_title = '大前端DUX主题二开Fys1.0免费开源下载';
		         $top_titleurl = 'http://www.17uw.cn/i/323';				 
		         $top_content = '模板介绍: 本模板是由dux4.0版本二次开发，具有简单易懂、主题鲜明、美观大方、功能丰富等有点，更有强劲的整体格局全部整改，整个页面更加美观，更加漂亮！ 设计理念: 用心打造出中国最独具特色的EMLOS模板，不求最好只求更好！';
				 $heightkey = '[置顶]';
				 $home_toptext = '<ul class="site-nav topmenu">
			<li><a href="http://www.17uw.cn/"><i class="fa fa-link"></i> 会飞的鱼</a></li>
				<li class="menusns">
					<a href="javascript:;"><i class="fa fa-comments-o"></i> 联系本站 <i class="fa fa-angle-down"></i></a>
					<ul class="sub-menu">
						<li><a class="sns-wechat" href="javascript:;" title="我的微信" data-src="http://0d077ef9e74d8.cdn.sohucs.com/qzM05EE_png"><i class="fa fa-wechat"></i> 微信交谈</a></li>				
						<li><a target="_blank" rel="external nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=1444762288&site=qq&menu=yes"><i class="fa fa-qq"></i> QQ联系</a></li>						<li><a target="_blank" rel="external nofollow" href="#"><i class="fa fa-tencent-weibo"></i> 腾讯微博</a></li>																		<li><a target="_blank" href="#"><i class="fa fa-weibo"></i> 微博</a></li>					</ul>
				</li>
			</ul>';				 
				 $ppt_zhiding= '2';	
                 $Sorts= '1';
				 $newsj= '2';
				 $cbads= '1';
                 $nrads= '1';						 
			     $ppt_picurl = 'http://0d077ef9e74d8.cdn.sohucs.com/qzMooc5_jpg';
			     $ppt_titleurl = 'http://www.17uw.cn/i/323';
			 	 $ppt_picur2 = 'http://0d077ef9e74d8.cdn.sohucs.com/qzMooc5_jpg';
			 	 $ppt_titleur2 = 'http://www.17uw.cn/i/323';
			     $ppt_titleur3 = 'http://www.17uw.cn/i/323';
				 $cbbt1 = '这是一个广告位';
				 $cbbt2 = '这是一个广告位';
				 $cbbt3 = '这是一个广告位';
				 $cbbt4 = '这是一个广告位';
				 $cbts1 = '联系QQ1444762288';
				 $cbts2 = '联系QQ1444762288';
				 $cbts3 = '联系QQ1444762288';
				 $cbts4 = '联系QQ1444762288';
				 $nrbt = 'FYS模板1.0版本增加手机PC不同自适应';
				 $cdurl1 = 'tencent://message/?uin=1444762288';
				 $cdurl2 = 'tencent://message/?uin=1444762288';
				 $cdurl3 = 'tencent://message/?uin=1444762288';
				 $cdurl4 = 'tencent://message/?uin=1444762288';
				 $Sorth1 = '相册图库';
				 $Sorth2 = '文章归档';
				 $Sorth3 = '微言碎语';
				 $Sorth4 = '留言互动';
				 $Sorth5 = '我的邻居';
				 $Sortp1 = '相册图库介绍';
				 $Sortp2 = '所有文章都搁着';
				 $Sortp3 = '网站的公告';
				 $Sortp4 = '不要打广告哦';
				 $Sortp5 = '我的小伙们';
				 $Sorta1 = '/album.html';
				 $Sorta2 = '/archives.html';
				 $Sorta3 = '/t';
				 $Sorta4 = '/links.html';
				 $Sorta5 = '/links.html';
				 $nrurl = 'http://www.f162.cn/i/323';
			 	 $ppt_picur3 = 'http://0d077ef9e74d8.cdn.sohucs.com/qzMooc5_jpg';
				 $arr_navico = 'a:5:{i:24;s:0:"";i:1;s:10:"fa fa-home";i:2;s:0:"";i:25;s:0:"";i:3;s:0:"";}';
				 $arr_sortico = 'a:2:{i:1;s:9:"fa fa-rss";i:9;s:0:"";}';
				 $side_title = 'a:20:{i:1;s:12:"友情链接";i:2;s:9:"留言板";i:3;s:9:"关于我";i:4;s:6:"微语";i:5;s:1:"-";i:6;s:6:"微语";i:7;s:12:"文章归档";i:8;s:0:"";i:9;s:0:"";i:10;s:0:"";i:11;s:0:"";i:12;s:0:"";i:13;s:0:"";i:14;s:0:"";i:15;s:0:"";i:16;s:0:"";i:17;s:0:"";i:18;s:0:"";i:19;s:0:"";i:20;s:0:"";}';
				 $side_url = 'a:20:{i:1;s:11:"/links.html";i:2;s:10:"/gust.html";i:3;s:11:"/about.html";i:4;s:3:"/t/";i:5;s:0:"";i:6;s:3:"/t/";i:7;s:9:"/?post=27";i:8;s:0:"";i:9;s:0:"";i:10;s:0:"";i:11;s:0:"";i:12;s:0:"";i:13;s:0:"";i:14;s:0:"";i:15;s:0:"";i:16;s:0:"";i:17;s:0:"";i:18;s:0:"";i:19;s:0:"";i:20;s:0:"";}';				 
				 $css = '';
				 $theme_skin = '';
				 $m_cms_pci = '2';
				 $m_cms_page = '1,2,3,4,5,6';
				 $imgnum_all = '40';
				 $pjax = '';
				 $tip = '墙上还没人，快抢沙发啦~';
				 $type_wall = 'week';
				 $ad_side = '';
				 $ad_page = '';
				 $ad_page_down = '';
				 $userhide = '1';
				 $firstblood = '1';
				 $webcompress = '0';				 
				 $module_thum = '0';				 
				 $down_next = '0';
				 $m_zazhi_config = '1,2,3,4,5,6,7';
				 $m_zazhi_config1 = '1';
				 $m_zazhi_config2 = '1';
				 $cdn_css = '0';
                 $m_gfs_tuijian = '0';
                 $m_gfs_div = '1,2,3,4,5,6,7,8,9';
	    ?>