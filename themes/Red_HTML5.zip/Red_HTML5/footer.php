<?php 
/*
* 底部信息
*
**************** Qzz 在此恳请各位博主不要删除我的链接 ****************
**************** 如有需求,欢迎大家到我博客相互交换友链 ****************
**************** 一直努力免费为大家制作模板,希望大家喜欢! ****************
*
*
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
    </div><!--end content -->

    <div id="content_footer"></div>
    <div id="footer"> 
		&copy; <?php echo $blogname; ?> | Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> | <a href="http://validator.w3.org/check?uri=referer">HTML5</a> & <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> <br> <a href="http://www.qzee.net">Theme by Qzz</a> & Design by <a href="http://HTML5webtemplates.co.uk/">HTML5webtemplates</a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
    </div>
  </div>
<?php doAction('index_footer'); ?></body>
</html>
