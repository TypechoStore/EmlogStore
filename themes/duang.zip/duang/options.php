<?php
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
    'logo' => array(
        'type' => 'image',
        'name' => 'logo',
        'values' => array(
            TEMPLATE_URL . 'images/logo.png',
        ),
        'description' => '站点左侧头像，建议png格式，大小正方形。不能上传请手动ftp',
    ),
    'main_color' => array(
        'type' => 'text',
        'name' => '全局主题色',
        'default' => '#FF5E52',
    ),
    'huandeng_open' => array(
        'type' => 'radio',
        'name' => '是否开启自定义首页幻灯',
        'values' => array(
            '1' => '开启',
            '0' => '关闭',
        ),
        'default' => '1',
    ),
    'order_open' => array(
        'type' => 'radio',
        'name' => '是否开启首页热门排行',
        'values' => array(
            '1' => '开启',
            '0' => '关闭',
        ),
        'default' => '1',
    ),
    'tuijian_open' => array(
        'type' => 'radio',
        'name' => '是否开启首页五宫格推荐文章',
        'values' => array(
            '1' => '开启',
            '0' => '关闭',
        ),
        'default' => '1',
    ),
    'tuijian' => array(
        'type' => 'text',
        'name' => '首页五宫格推荐文章',
        'default' => '1,2,3,4,5',
        'description' => '填写文章的编号，必须用英文 , 间隔！',
    ),
    'index_hot_tuijian_open' => array(
        'type' => 'radio',
        'name' => '是否开启首页热门推荐',
        'values' => array(
            '1' => '开启',
            '0' => '关闭',
        ),
        'default' => '1',
    ),
    'index_hot_tuijian' => array(
        'type' => 'text',
        'name' => '首页热门推荐',
        'default' => '1,2,3,4',
        'description' => '填写文章的编号，必须用英文 , 间隔！',
    ),
    'related_open' => array(
        'type' => 'radio',
        'name' => '是否开启内容页相关文章显示',
        'values' => array(
            '1' => '开启',
            '0' => '关闭',
        ),
        'default' => '1',
    ),
    'related_type' => array(
        'type' => 'radio',
        'name' => '设置相关文章显示类型',
        'values' => array(
            'sort' => '分类',
            'tag' => '标签',
        ),
        'default' => 'sort',
    ),
    'related_desc' => array(
        'type' => 'radio',
        'name' => '设置相关文章排列方式',
        'values' => array(
            'rand' => '随机排列',
            'views_desc' => '点击数(降序)',
            'views_asc' => '点击数(升序)',
            'comnum_desc' => '评论数(升序)',
            'comnum_asc' => '评论数(升序)',
        ),
        'default' => 'rand',
    ),
    'related_num' => array(
        'type' => 'text',
        'name' => '设置相关文章显示数量',
        'values' => array('8'),
        'description' => '设置相关文章显示数量，直接填写数字即可。'
    ),
    'admin_qq' => array(
        'type' => 'text',
        'name' => '设置站长QQ号码',
        'values' => array('8589561'),
        'description' => '此处填写站长的QQ号码。'
    ),
    'custom1img' =>array(
        'type' => 'image',
        'name' => '自定义1-幻灯片图片',
        'values' => array(
            TEMPLATE_URL . 'images/banner.jpg',
        ),
    ),
    'custom1url_blank' => array(
        'type' => 'radio',
        'name' => '新窗口打开',
        'description' => '外链必须开启新窗口打开[否则Pjax无法加载外链]',
        'values' => array(
            '1' => '开启',
            '2' => '关闭',
        ),
        'default' => '1',
    ),
    'custom1url' => array(
        'type' => 'text',
        'name' => '自定义1-幻灯片链接',
        'values' => array(
            'http://www.ilt.me',
        ),
    ),
    'custom1name' => array(
        'type' => 'text',
        'name' => '自定义1-幻灯片名称',
        'values' => array(
            'DUANG',
        ),
    ),
    'custom2img' =>array(
        'type' => 'image',
        'name' => '自定义2-幻灯片图片',
        'values' => array(
            TEMPLATE_URL . 'images/banner.jpg',
        ),
    ),
    'custom2url_blank' => array(
        'type' => 'radio',
        'name' => '新窗口打开',
        'description' => '外链必须开启新窗口打开[否则Pjax无法加载外链]',
        'values' => array(
            '1' => '开启',
            '2' => '关闭',
        ),
        'default' => '1',
    ),
    'custom2url' => array(
        'type' => 'text',
        'name' => '自定义2-幻灯片链接',
        'values' => array(
            'http://www.ilt.me',
        ),
    ),
    'custom2name' => array(
        'type' => 'text',
        'name' => '自定义2-幻灯片名称',
        'values' => array(
            'DUANG',
        ),
    ),
    'custom3img' =>array(
        'type' => 'image',
        'name' => '自定义3-幻灯片图片',
        'values' => array(
            TEMPLATE_URL . 'images/banner.jpg',
        ),
    ),
    'custom3url_blank' => array(
        'type' => 'radio',
        'name' => '新窗口打开',
        'description' => '外链必须开启新窗口打开[否则Pjax无法加载外链]',
        'values' => array(
            '1' => '开启',
            '2' => '关闭',
        ),
        'default' => '1',
    ),
    'custom3url' => array(
        'type' => 'text',
        'name' => '自定义3-幻灯片链接',
        'values' => array(
            'http://www.ilt.me',
        ),
    ),
    'custom3name' => array(
        'type' => 'text',
        'name' => '自定义3-幻灯片名称',
        'values' => array(
            'DUANG',
        ),
    )
);

