<footer class="footer">
    &copy; 2018
    本站主题由
    <a href="http://www.ilt.me" target="_blank">IT技术宅</a>提供 &nbsp;
</footer>
</section>
<script>
    window.jui = {
        uri: '<?php echo TEMPLATE_URL; ?>',
        roll: '1 2',
        ajaxpager: '0'
    }
</script>
<script type='text/javascript'
        src='<?php echo TEMPLATE_URL; ?>js/bootstrap.js?ver=6.0'></script>
<script type='text/javascript'
        src='<?php echo TEMPLATE_URL; ?>js/hammer.min.js?ver=6.0'></script>
<script type='text/javascript'
        src='<?php echo TEMPLATE_URL; ?>js/custom.js?ver=6.0'></script>
<?php doAction('index_footer'); ?>
</body>

</html>