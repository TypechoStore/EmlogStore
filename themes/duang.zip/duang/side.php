<div class="sidebar">
    <div class="widget widget_textssr">
        <a class="style02" >
            <strong>介绍</strong>
            <h2>Duang</h2>
            <p>扁平化、简洁风、多设备支持、多功能配置，适用于图片展示站点和个人博客，响应式布局，不同设备不同展示效果...</p>
        </a>
    </div>
    <?php
    $widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
//    doAction('diff_side');
    foreach ($widgets as $val)
    {
        $widget_title = @unserialize($options_cache['widget_title']);
        $custom_widget = @unserialize($options_cache['custom_widget']);
        if(strpos($val, 'custom_wg_') === 0)
        {
            $callback = 'widget_custom_text';
            if(function_exists($callback))
            {
                call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
            }
        }else{
            $callback = 'widget_'.$val;
            if(function_exists($callback))
            {
                preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
                $wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
                call_user_func($callback, htmlspecialchars($wgTitle));
            }
        }
    }
    ?>
</div>