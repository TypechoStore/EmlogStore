<div class="content-wrap">
    <div class="content">
        <header class="article-header">
            <div class="breadcrumbs"><span class="text-muted">当前位置：</span><a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a>
                <small>></small>
                <?php echo_blog_sorts($logid); ?>
                <small>></small>
                <span class="text-muted"><?php echo $log_title; ?></span></div>
            <h1 class="article-title"><a href="http://demo.themebetter.com/xiu/120.html"><?php echo $log_title; ?></a></h1>
            <ul class="article-meta">
                <li><?php blog_author($author); ?> 发布于 <?php echo gmdate('20y年m月d日',$date); ?></li>
                <li>分类：<?php echo_blog_sorts($logid); ?></li>
                <li><span class="post-views">阅读(<?php echo $views; ?>)</span></li>
                <li>评论(<?php echo $comnum; ?>)</li>
                <li></li>
            </ul>
        </header>
        <article class="article-content">
            <?php echo $log_content; ?>
        </article>
        <?php doAction('log_related', $logData); ?>
        <div class="article-tags">
            标签：<?php blog_tag($logid); ?>
        </div>
        <nav class="article-nav">
            <?php neighbor_log($neighborLog) ?>
        </nav>

        <?php if(_g('related_open') == '1'){ related_logs($logData);} ?>

        <h3 class="title" id="comments">
            <strong>评论 <b> <?php echo $comnum; ?> </b></strong>
        </h3>
        <div class="ajax_comment">
            <div class="commt_box">
                <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
                <?php blog_comments($comments); ?>
            </div>
        </div>


    </div>
</div>
<!-- 引入侧边 -->
<?php include View::getView('side'); ?>
</div>
<!--主题框架结束-->
<!-- 引入底部 -->
<?php include View::getView('footer'); ?>