<?php
/*
Template Name:Duang
Description:三栏主题，自由配色<br>移植修改xiu6.0
Version:1.0
Author:Zing
Author Url:http://www.ilt.me
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE HTML>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=11,IE=10,IE=9,IE=8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-transform">
    <meta http-equiv="Cache-Control" content="no-siteapp">
    <title><?php echo $site_title; ?></title>
    <meta name='robots' content='noindex,follow'/>
    <link rel='dns-prefetch' href='//s.w.org'/>
    <link rel='stylesheet' id='main-css' href='<?php echo TEMPLATE_URL; ?>css/style.css' type='text/css' media='all'/>
    <link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/font-awesome.min.css">
    <script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>js/jquery.js'></script>
    <style>
        .container {
            max-width: 800px
        }
        body{
            --mainColor:<?php echo _g('main_color') ?> !important;
        }
    </style>
    <meta name="keywords" content="<?php echo $site_key; ?>">
    <meta name="description" content="<?php echo $site_description; ?>">
    <link rel="shortcut icon" href="<?php echo TEMPLATE_URL; ?>favicon.ico">
    <!--[if lt IE 9]>
    <script src="<?php echo TEMPLATE_URL; ?>js/html5.js"></script>
    <![endif]-->
</head>

<body class="home blog m-home-most focusslide_s_m uimo ui-c3 left_header">
<section class="container">
    <header class="header">
        <h1 class="logo">
            <a href="<?php echo BLOG_URL; ?>" title="<?php echo $site_title; ?>">
                <img src="<?php echo _g('logo'); ?>" alt="<?php echo $site_title; ?>">
                <?php echo $site_title; ?></a>
        </h1>
        <ul class="nav">
            <li class="navmore"></li>
            <?php blog_navi() ?>
        </ul>
        <form method="get" class="search-form" action="<?php echo BLOG_URL; ?>index.php">
            <input class="form-control" name="keyword" type="text" placeholder="输入关键字" value="">
            <input class="btn" type="submit" value="搜索"></form>
        <span class="glyphicon glyphicon-search m-search"></span>

<!--        <div class="slinks">-->
<!--            <a href="#" title="链接01">链接01</a>|-->
<!--            <a href="#" title="链接02">链接02</a>-->
<!--            <br>-->
<!--            <a href="#" title="链接03">链接03</a>-->
<!--        </div>-->
    </header>