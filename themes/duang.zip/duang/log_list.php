<div class="content-wrap">
    <div class="content">
        <?php if ($page == 1 && blog_tool_ishome()): ?>
        <?php if(_g('huandeng_open') == '1'): ?>
            <!--幻灯箱-->
            <div id="slider" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#slider" data-slide-to="0" class="active"></li>
                    <li data-target="#slider" data-slide-to="1"></li>
                    <li data-target="#slider" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="item active">
                        <a <?php echo _g("custom1url_blank") == '1' ? 'target="_blank"' : '' ?>
                                href="<?php echo _g('custom1url') ?>">
                            <img src="<?php echo _g('custom1img') ?>">
                            <span class="carousel-caption"><?php echo _g('custom1name') ?></span>
                            <span class="carousel-bg"></span>
                        </a>
                    </div>
                    <div class="item">
                        <a <?php echo _g("custom2url_blank") == '1' ? 'target="_blank"' : '' ?>
                                href="<?php echo _g('custom2url') ?>">
                            <img src="<?php echo _g('custom2img') ?>">
                            <span class="carousel-caption"><?php echo _g('custom2name') ?></span>
                            <span class="carousel-bg"></span>
                        </a>
                    </div>
                    <div class="item">
                        <a <?php echo _g("custom3url_blank") == '1' ? 'target="_blank"' : '' ?>
                                href="<?php echo _g('custom3url') ?>">
                            <img src="<?php echo _g('custom3img') ?>">
                            <span class="carousel-caption"><?php echo _g('custom3name') ?></span>
                            <span class="carousel-bg"></span>
                        </a>
                    </div>
                </div>
                <a class="left carousel-control" href="#slider" role="button" data-slide="prev">
                    <i class="fa fa-chevron-left" aria-hidden="true"></i>
                </a>
                <a class="right carousel-control" href="#slider" role="button" data-slide="next">
                    <i class="fa fa-chevron-right" aria-hidden="true"></i>
                </a>
            </div>
        <?php endif;?>
            <!--推荐文章 5个-->
        <?php if(_g('tuijian_open') == '1'): ?>
            <div class="focusmo">
                <ul>
                    <?php
                    if (_g('tuijian') != 0 && _g('tuijian') != "") {
                        $cmsid = explode(',', _g('tuijian'));
                        $cmsnum = count($cmsid);
                        for ($x = 0; $x < $cmsnum; $x++) {
                            $iblog = find_blog($cmsid[$x]);
                            ?>
                            <li <?php echo $x == 0 ? 'class="large"' : '' ?>>
                                <a href="<?php echo Url::log($iblog['gid']); ?>">
                                    <img class="thumb"
                                         data-original="<?php get_imgsrc($iblog['content']); ?>">
                                    <h4><?php echo $iblog['title']; ?></h4></a>
                            </li>
                            <?php
                        }
                    }
                    ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(_g('order_open') == '1'): ?>
            <div class="most-comment-posts">
                <h3 class="title">
                    <strong>热门排行</strong></h3>
                <ul>
                    <?php hot_index_blog() ?>
                </ul>
            </div>
        <?php endif;?>
        <?php if(_g('index_hot_tuijian_open') == '1'):
                $cmsid = explode(',', _g('index_hot_tuijian'));
                $cmsnum = count($cmsid); ?>
                <!--热门推荐-->
                <div class="sticky">
                <h3 class="title">
                    <strong>热门推荐</strong></h3>
                <ul>
        <?php for ($x = 0; $x < $cmsnum; $x++) :
                    $iblog = find_blog($cmsid[$x]); ?>
                    <li class="item">
                        <a href="<?php echo Url::log($iblog['gid']); ?>">
                            <img data-original="<?php get_imgsrc($iblog['content']); ?>"
                                 class="thumb"/><?php echo $iblog['title']; ?></a>
                    </li>
        <?php endfor;?>
                </ul>
                </div>
        <?php endif;endif; ?>
        <!--最新发布-->
        <h3 class="title">
            <strong>
                <?php if ($params[1] == 'sort') { ?>
                    <?php echo '<a href="' . Url::sort($sortid) . '">' . $sortName . '</a>'; ?>
                <?php } elseif ($params[1] == 'page') { ?>
                    所有文章
                <?php } elseif ($params[1] == 'tag') { ?>
                    包含标签 <b><?php echo urldecode($params[2]); ?></b> 的所有文章
                <?php } elseif ($params[1] == 'author') { ?>
                    作者 <b><?php echo blog_author($author); ?></b> 的所有文章
                <?php } elseif ($params[1] == 'keyword') { ?>
                    搜索 <b><?php echo urldecode($params[2]); ?></b> 的结果
                <?php } else { ?>最新文章<?php } ?>
            </strong></h3>
        <?php foreach ($logs as $value): ?>
            <?php $logImgCount = img_count($value['content']); ?>
            <article class="excerpt <?php echo $logImgCount <= 1 ? 'excerpt-one' : 'excerpt-multi' ?>">
                <header>
                    <?php blog_sorts($value['logid']); ?>
                    <h2>
                        <a href="<?php echo $value['log_url']; ?>"
                           title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></h2>

                    <?php if ($logImgCount > 0): ?>
                        <small class="text-muted">
                            <span class="glyphicon glyphicon-picture"></span>
                            <i class="fa fa-picture-o" aria-hidden="true"></i>
                            <?php echo $logImgCount ?>
                        </small>
                    <?php endif; ?>
                </header>
                <p class="text-muted time"><?php blog_author($value['author']); ?>
                    发布于 <?php echo gmdate('n-j', $value['date']); ?></p>
                <p class="focus">
                    <a target="_blank" href="<?php echo $value['log_url']; ?>" class="thumbnail">
                        <?php if ($logImgCount == 0): ?>
                            <span class="item">
                  <span class="thumb-span">
                    <img data-original="<?php echo TEMPLATE_URL . 'images/articleImg/' . rand(1, 20) . '.jpg'; ?>"
                         class="thumb"/>
                  </span>
                </span>
                        <?php elseif ($logImgCount == 1):
                            $logImg = img_array($value['content'])[0];
                            ?>
                            <span class="item">
                              <span class="thumb-span">
                                <img data-original="<?php echo $logImg; ?>"
                                     class="thumb"/>
                              </span>
                            </span>
                        <?php else:
                            $logImgArray = img_array($value['content']);
                            $imgIndex = 0;
                            foreach ($logImgArray as $img):
                                if ($imgIndex > 3) {
                                    break;
                                }
                                ?>
                                <span class="item">
                              <span class="thumb-span">
                                <img data-original="<?php echo $img; ?>"
                                     class="thumb"/>
                              </span>
                            </span>

                                <?php $imgIndex++; endforeach;endif; ?>
                    </a>
                </p>
                <p class="note">
                    <?php echo subString(DeleteHtml(strip_tags($value['content'])), 0, 174); //文章简述 ?></p>
                <p class="text-muted views">
                    <span class="post-views"><i class="fa fa-eye"></i> 阅读(<?php echo $value['views']; ?>)</span>
                    <span class="post-comments"><i class="fa fa-comments-o"></i> 评论(<?php echo $value['comnum']; ?>
                        )</span>
                    <!--<a href="javascript:;" class="post-like" data-pid="46" data-event="like">
                        <i class="glyphicon glyphicon-thumbs-up"></i>赞 (
                        <span>226</span>)</a-->
                    <?php index_blog_tag($value['logid']); ?>
                </p>
            </article>
        <?php endforeach; ?>

        <!--分页-->
        <div id="pagenavi">
            <?php echo $page_url; ?>
        </div>
    </div>
</div>

<!-- 引入侧边 -->
<?php include View::getView('side'); ?>
</div>
<!--主题框架结束-->
<!-- 引入底部 -->
<?php include View::getView('footer'); ?>