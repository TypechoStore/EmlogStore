<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div class="content">
<div class="content_left">
<?php doAction('index_loglist_top'); ?>
<?php if (!empty($logs)): foreach($logs as $value): ?>
<div class="content_body">
<div class="content_left_title"><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></div>
<div class="content_left_des"><?php echo $value['log_description']; ?></div>
<div class="content_left_info">
<span class="left_info_date"><?php echo gmdate('Y年n月j日', $value['date']); ?></span>
<?php blog_sort($value['logid']); ?> 
<span class="left_info_view">浏览（<?php echo $value['views']; ?>）</span>
<span class="left_info_com">评论（<a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?></a>）</span>
<?php blog_tag($value['logid']); ?>
<span class="left_info_edit"><?php editflg($value['logid'],$value['author']); ?></span>
<div class="c"></div>
</div>
</div>
<?php endforeach; else: ?>
<h2>未找到</h2>
<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
<?php if(!empty($page_url)){echo '<div class="page_navi">'.$page_url.'</div>';} ?>
</div>
<?php include View::getView('side'); include View::getView('footer'); ?>