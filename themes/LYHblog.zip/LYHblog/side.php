<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="pright mt1">
	<div class="pbox">
		<div class="p_tit_03"><h3>关注我们</h3></div>
		<!--以下是QQ邮件列表订阅嵌入代码--><script >var nId = "3da5d9dd8af54e99a2cf98603d1d7879f97b4a51d8a246e5",nWidth="auto",sColor="light",sText="填写您的邮件地址，订阅我们的精彩内容：" ;</script><script src="http://list.qq.com/zh_CN/htmledition/js/qf/page/qfcode.js" charset="gb18030"></script>
		<div class="pbox_lm">
<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>
			<?php if("http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] == BLOG_URL):?>
			<div style="border: 1px solid #BBD7E6;padding:5px;margin:10px 0px 10px 0px;background-color:#F7F4ED;" align="left">
<li>日志数量：<?php echo $sta_cache['lognum'];?>篇文章</li>
<li>评论数量：<?php echo $sta_cache['comnum_all'];?>条评论</li>
<li>微博数量：<?php echo $sta_cache['twnum'];?>条微博</li>
<li>建站日期：2012-09-13</li>
<li>运行时间：已安全运行<?php echo floor((time()-strtotime("2012-09-13"))/86400); ?>天</li>
</div>
			<?php endif;?>


		</div>
	</div>	
</div>