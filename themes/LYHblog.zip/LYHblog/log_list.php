<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php doAction('index_loglist_top'); ?>
<div class="pleft mt1">
	<?php
	$nowurl='http://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
	if($nowurl == BLOG_URL){
	?>
	
	<?php } ?>
	<?php foreach($logs as $value): ?>
	<div class="topic-content">
		<div class="post-date"><small><?php echo gmdate('n月', $value['date']); ?></small><span><?php echo gmdate('j日', $value['date']); ?></span></div>
		<div class="post-title">
			<h2><a title="<?php echo $value['log_title']; ?>" href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
			<h6>作者: <?php blog_author($value['author']); ?> | <?php blog_sort($value['logid']); ?> | 评论：<?php echo $value['comnum']; ?>人 | 浏览:<span><?php echo $value['views']; ?></span></h6>
		</div>
		<div class="post-list-img">
			<img src="<?php echo pic_thumb($value['log_description']); ?>" width="80" height="80"/>
		</div>
		<div class="post-list-info"><p><?php echo strip_tags($value['log_description']); ?></p></div>
	</div>
	<?php endforeach; ?>
	<div class="c mt10 list_page" id="pagenavi"><?php echo $page_url;?></div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>