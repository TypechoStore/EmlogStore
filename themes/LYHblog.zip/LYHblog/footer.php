<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="cle"></div>
<?php if("http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] == BLOG_URL):?> 
<div class="link mt1">
 
	<ul>
		<li><strong>友情链接：</strong></li>
		<?php
		$link_cache = $CACHE->readCache('link');
		foreach($link_cache as $value):
		?>
		<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
		<?php endforeach; ?>
	</ul>	
</div>
<?php endif;?> 
<div class="cle"></div>
<div class="foot" id="footerbar">
	<P><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a> Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>  Theme Designed by<a href="http://www.caihongjia.net">彩虹之家博客</a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?></P>
	<?php doAction('index_footer'); ?>
</div>
</div>
<script src="<?php echo TEMPLATE_URL; ?>js/util.js" type="text/javascript"></script>
</body>
</html>