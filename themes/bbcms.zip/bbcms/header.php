<?php
/*
Template Name:百变Cms 
Description:<br /><font color=red>＊</font>本主题由舍力设计和维护（<font color=red>制作日期12-22</font>）<br><font color=red>＊</font>模板修改后出现的任何问题均请自行解决<br><font color=red>＊</font>发现主题Bug请到说明中留言<br><br><a href="http://www.shuyong.net/564.html" target="_blank">使用说明、更新日志及意见反馈</a>
Version:V1.0
Author:舍力博客
Author Url:http://www.shuyong.net
Sidebar Amount:4
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}require_once View::getView('module');ob_clean();?>