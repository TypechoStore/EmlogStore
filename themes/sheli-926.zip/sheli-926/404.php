<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>对不起，您所访问的页出现面错误</title>
<style type="text/css">
<!--
body{background:#F7F7F7;font-family: Arial;font-size:12px;line-height:150%;}
.main{background:#FFFFFF;color: #666666;max-width:800px;margin:100px auto;padding:10px;list-style:none;border:#DFDFDF 1px solid;overflow:hidden; clear:both;}
#bt{text-align:center; line-height:50px; font-size:14px; font-family:"微软雅黑"; font-weight:bold;}
#nr{font-size:14px; font-family:"微软雅黑"; margin:0 0 10px 20px; line-height:25px;}
#right{clear:both; overflow:hidden;margin:0 0 10px 20px;}
#jz{ text-align:center;}-->
</style>
</head>
<body>
<div class="main">
<p id="bt">对不起，您所访问的页出现面错误，可能由以下原因造成：</p>
<p id="nr">1、页面不存在；<br />2、页面被删除或已经转移到其它页面<br /><a href="javascript:history.back(-1);">返回上一次浏览页面继续浏览</a></p>
<center><script  charset="utf-8" src="http://daohang.shuyong.net/daohang.js" type="text/javascript"></script></center> 

</div>
</body>
</html>