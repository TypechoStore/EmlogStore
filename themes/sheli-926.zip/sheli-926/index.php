<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div id="right">
<?php doAction('index_loglist_top'); ?>
<?php if (!empty($logs)):foreach($logs as $value): ?>
<div id="log-list">
<div id="log-list-tt"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a><?php if(((date('Ymd',time())-date('Ymd',$value['date']))<=2)&&($value['top']=='n')){echo "<i class='new-arrow'></i><span class='new-label'>News</span>";}else if($value['views']>=300){echo "<i class='hot-arrow'></i><span class='hot-label'>热门</span>";};?><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?></div>
<div id="log-list-nr"><p><img src="<?php if (_g('img') == "fjimg"): ?><?php sheli_fjimg($value['logid']);?><?php else:endif; ?><?php if (_g('img') == "zwimg"): ?><?php sheli_zwimg($value['content']); ?><?php else: endif; ?>" alt="<?php echo $value['log_title']; ?>" /></p><span><?php echo subString(strip_tags($value['content']),0,220);?></span></div>
<div id="log-list-bq"><i class="icon-users"></i><?php blog_author($value['author']); ?> &nbsp; 
<i class="icon-clock"></i><?php echo gmdate('Y年n月j日', $value['date']); ?> &nbsp; 
<i class="icon-folder-open"></i><?php blog_sort($value['logid']); ?> &nbsp; 
<i class="icon-bubbles"></i><a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a> &nbsp; 
<i class="icon-file"></i>浏览(<?php echo $value['views']; ?>) &nbsp; 
<?php blog_tag($value['logid']); ?>
<span id="qw"><a href="<?php echo $value['log_url']; ?>" title="阅读全文">阅读全文</a></span>
</div></div><?php //----#log-list enf----?><?php endforeach;?>
<div id="pagenavi"><?php echo $page_url;?></div>
<?php else:endif;?>
</div><?php //----#right enf----?>
<div id="left"><div id="sheli-hotlog"><div id="sheli-hotlog-tt">本月热门文章排行榜</div><ul><?php sheli_hotlog(_g('hotlog'));?></ul></div>
<?php include View::getView('side');?>
<?php if (_g('blogtj-kg') == "yes"): ?><div id="sheli-blogtj"><div id="sheli-blogtj-tt">博客统计</div><ul>
<li>文章数量：<?php echo $sta_cache['lognum'];?>篇</li>
<li>草稿文章：<?php echo $sta_cache['draftnum'];?>篇</li>
<li>已审评论：<?php echo $sta_cache['comnum'];?>条</li>
<li>微语数量：<?php echo $sta_cache['twnum'];?>条</li>
<li>待审评论：<?php echo $sta_cache['hidecomnum'];?>条</li>
<li>页面数量：<?php echo count_page_all();?>篇</li>
<li>分类数量：<?php echo count_sort_all();?>个</li>
<li>标签数量：<?php echo count_tag_all();?>个</li>
<li>友链数量：<?php echo count_link_all();?>条</li>
<li>附件数量：<?php echo count_att_all();?>个</li>
<p>最后更新：<small><?php echo last_post_log();?></small></p>
</ul></div><?php else: ?><?php endif; ?>
</div>