// 百度分享代码
function bdfx() {
document.writeln("<div class=\"bdsharebuttonbox\">");
document.writeln("<a title=\"分享到QQ空间\" href=\"#\" class=\"bds_qzone\" data-cmd=\"qzone\"></a>");
document.writeln("<a title=\"分享到新浪微博\" href=\"#\" class=\"bds_tsina\" data-cmd=\"tsina\"></a>");
document.writeln("<a title=\"分享到腾讯微博\" href=\"#\" class=\"bds_tqq\" data-cmd=\"tqq\"></a>");
document.writeln("<a title=\"分享到搜狐微博\" href=\"#\" class=\"bds_tsohu\" data-cmd=\"tsohu\"></a>");
document.writeln("<a title=\"分享到网易微博\" href=\"#\" class=\"bds_t163\" data-cmd=\"t163\"></a>");
document.writeln("<a title=\"分享到微信\" href=\"#\" class=\"bds_weixin\" data-cmd=\"weixin\"></a>");
document.writeln("<a title=\"分享到百度空间\" href=\"#\" class=\"bds_hi\" data-cmd=\"hi\"></a>");
document.writeln("<a title=\"分享到人人网\" href=\"#\" class=\"bds_renren\" data-cmd=\"renren\"></a>");
document.writeln("<a title=\"分享到美丽说\" href=\"#\" class=\"bds_meilishuo\" data-cmd=\"meilishuo\"></a>");
document.writeln("<a title=\"分享到天涯社区\" href=\"#\" class=\"bds_ty\" data-cmd=\"ty\"></a>");
document.writeln("<a title=\"分享到腾讯朋友\" href=\"#\" class=\"bds_tqf\" data-cmd=\"tqf\"></a>");
document.writeln("<a href=\"#\" class=\"bds_more\" data-cmd=\"more\"></a>");
document.writeln("</div>");
document.writeln("<script>window._bd_share_config={\"common\":{\"bdSnsKey\":{},\"bdText\":\"\",\"bdMini\":\"2\",\"bdMiniList\":false,\"bdPic\":\"\",\"bdStyle\":\"0\",\"bdSize\":\"24\"},\"share\":{}};with(document)0[(getElementsByTagName(\'head\')[0]||body).appendChild(createElement(\'script\')).src=\'http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion=\'+~(-new Date()/36e5)];</script>");
}

function left_gg() {
document.writeln("<a href=\"http://www.west263.com?ReferenceID=812373\" target=\"_blank\"><img src=\"http://www.west263.com/vcp/vcp_img/free6/F/300x250_F.jpg\"></a>");
}
function log_gg() {
document.writeln("<a href=\"http://www.west263.com?ReferenceID=812373\" target=\"_blank\"><img src=\"http://www.west263.com/vcp/vcp_img/free6/F/728x90_F.jpg\"\"></a>");
}

//时间格式：今天是xx年x月x日
function sjdm1() {
var day=""; 
var month=""; 
var year=""; 
mydate=new Date(); 
mymonth=mydate.getMonth()+1; 
myday= mydate.getDate(); 
myyear= mydate.getYear(); 
year=(myyear > 200) ? myyear : 1900 + myyear; 
document.write(year+"年"+mymonth+"月"+myday+"日")
}

function sjdm2() {
var urodz= new Date("1/31/2014");
var s="<font style=\"font-size:18px;color:#FF0000;font-weight:bold\">春节</font>";
var now = new Date();
var ile = urodz.getTime() - now.getTime();
var dni = Math.floor(ile / (1000 * 60 * 60 * 24))+1;
if (dni > 1)
document.write("还有<font style=\"font-size:18px;color:#FF0000;font-weight:bold\">"+dni +"</font>天"+"就是"+s+"啦！")
else if (dni == 1)
document.write("<font style=\"font-size:18px;color:#FF0000;font-weight:bold\">除夕</font>，明天就是"+s+"啦！")
else if (dni == 0)
document.write("农历正月初一("+s+")")
else
document.write("")
}


//网址导航
function daohang(){
document.writeln("<center><script  charset=\"utf-8\" src=\"http://daohang.shuyong.net/daohang.js\" type=\"text/javascript\"></script></center> ");
}
