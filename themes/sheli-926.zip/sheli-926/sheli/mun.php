<?php
if(!defined('EMLOG_ROOT')) {exit('error!');}
$newlog_mun = _g('newlog_mun'); 
$sortlog_mun = _g('sortlog_mun'); 
?>
