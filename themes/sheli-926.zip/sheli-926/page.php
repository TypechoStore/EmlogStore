<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div id="right">
<div id="sheli-page">
<div id="sheli-page-tt"><?php echo $log_title; ?></div>
<div id="sheli-page-nr"><?php echo $log_content; ?></div>
<?php blog_comments($comments); ?><?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div><?php //----#sheli-log enf----?>
</div><?php //----#right enf----?>
<div id="left"><?php include View::getView('side');?></div>
<?php include View::getView('footer');?>