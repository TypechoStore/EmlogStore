<?php
/*
Template Name:sheli-926
Description:<br /><font color=red>＊</font>本主题由舍力设计和维护<br><font color=red>＊</font>模板修改后出现的任何问题请自行解决<br><br><a href="http://www.shuyong.net/447.html" target="_blank">意见反馈及使用说明</a>
Version:v1.0
Author:舍力博客
Author Url:http://www.shuyong.net
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}require_once View::getView('module');include View::getView('sheli/sheli');?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title;page_tit($page);?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>sheli/sheli.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="top">
<div id="topnav"><ul><?php echo _g('topnav'); ?></ul></div><?php //----#topnav end -----?>
<div id="logo-wz"><p id="logo-wz-max"><?php echo $blogname; ?></p>
<p id="logo-wz-min"><?php echo $bloginfo; ?></p></div>
</div><?php //----#top end -----?>
<div id="sheli-nav"><div id="nav"><?php blog_navi();?></div></div>
<div id="main">