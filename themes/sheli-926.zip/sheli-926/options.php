<?php
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(

'hotlog' => array(
'type' =>'text',
'name' =>'热门文章排行榜数量',
'default' =>'10',
),

'img' => array(
'type' =>'radio',
'name' =>'文章缩略图调用方式',
'values' => array(
'zwimg' =>'调用正文第一张图片',
'fjimg' =>'调用附件第一张图片',
),
'default' =>'zwimg',
),

'blogtj-kg' => array(
'type' =>'radio',
'name' =>'博客统计',
'values' => array(
'yes' =>'显示',
'no' =>'隐藏',
),
'default' =>'yes',
),

'topnav' => array(
'type' =>'text',
'name' =>'顶部导航',
'multi' => true,
'default' =>'
<a href="about.html" title="关于我">关于我</a>
<a href="contact.html" title="联系我">联系我</a>
<a href="sitemap.xml" title="网站地图">网站地图</a>',
),

'daohang-kg' => array(
'type' =>'radio',
'name' =>'博客导航开关',
'values' => array(
'yes' =>'显示',
'no' =>'隐藏',
),
'default' =>'yes',
),


);