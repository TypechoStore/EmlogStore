<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="templatemo_content_wrapper">
    <div id="templatemo_content">
        <div id="templatemo_content_top"></div>
        <div id="templatemo_content_middle">
        <div class="post_section">
            <h2><?php echo $log_title; ?></h2>
            <?php blog_sort($logid); ?> <?php editflg($logid,$author); ?>
            <div class="post_content">
            <?php echo $log_content; ?>
            </p>
            <?php blog_comments($comments); ?>
			<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
            </div>
        </div>
        </div>
        <div id="templatemo_content_bottom"></div>
	</div> <!-- end of templatemo_content -->
    <div id="templatemo_sidebar">
    	<?php include View::getView('side');;?>
    </div>
    <div class="cleaner"></div>
</div>
<?php
 include View::getView('footer');
?>