<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="page">
<div id="page-bgtop">
<div id="page-bgbtm">
		    <div id="content">
			<div class="post">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
				<h2 class="title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
				<p class="meta"><span class="date"><?php echo gmdate('Y-n-j G:i l', $value['date']); ?></span><span class="posted">Posted by <?php blog_author($value['author']); ?></span></p>
				<div style="clear: both;">&nbsp;</div>
				<div class="entry">
				<p><?php echo $value['log_description']; ?></p>
	<p><?php blog_att($value['logid']); ?></p>
	<p><?php blog_tag($value['logid']); ?></p>
					<p class="links"><a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a>|<a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a>|<?php editflg($value['logid'],$value['author']); ?></p>
				</div>
<div style="clear: both;">&nbsp;</div>
<?php endforeach; ?>
<div id="pagenavi">
<?php echo $page_url;?>
</div>
</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>