<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="page">
<div id="page-bgtop">
<div id="page-bgbtm">
 <div id="content">
 <div class="post">
	<h2><?php echo $log_title; ?></h2>
	<div style="clear: both;">&nbsp;</div>
				<div class="entry">
	<p>
	<?php echo $log_content; ?>
	</p>
	<p class="att"><?php blog_att($logid); ?></p>
	</div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>