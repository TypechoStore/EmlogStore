<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="page">
<div id="page-bgtop">
<div id="page-bgbtm">
 <div id="content">
 <div class="post">
    <h2 class="title"><?php topflg($top); ?><?php echo $log_title; ?></h2>
	<p class="meta"><span class="date"><?php echo gmdate('Y-n-j G:i l', $date); ?> 
	</span><span class="posted">Posted by <?php blog_author($author); ?></span></p>
	<div style="clear: both;">&nbsp;</div>
	<div class="entry">
	<p>
	<?php echo $log_content; ?></p>
	<p class="att"><?php blog_att($logid); ?></p>
	<p class="tag"><?php blog_tag($logid); ?></p>
	</div>
	<?php doAction('log_related', $logData); ?>
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>