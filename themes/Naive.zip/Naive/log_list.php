<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<section>
  <article class="contentleft">
    <?php doAction('index_loglist_top'); ?>
      <?php
if(isset($sortName)){
  echo '<div class="pagetitle">▨&nbsp;分类为《<span>'.$sortName.'</span>》下的文章:</div>';
}
if(isset($tag)) echo '<div class="pagetitle">▨&nbsp;标签为《<span>'.$tag.'</span>》下的文章:</div>';
if(isset($keyword)) echo '<div class="pagetitle">▨&nbsp;搜索关键词为『<span>'.$keyword.'</span>』的文章:</div>';
if(isset($author)) echo '<div class="pagetitle">▨&nbsp;作者"<span>'.$user_cache[$author]['name'].'</span>"的文章:</div>';
?>
    <?php foreach($logs as $value): ?>
    <div class="post"><h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
      <div class="data">
	  <span><?php echo gmdate('Y/n/j', $value['date']); ?></span>|
	  <span>分类：<?php blog_sort($value['logid']); ?></span>|
	  <span><a href="<?php echo $value['log_url']; ?>#comments" title="查看<?php echo $value['log_title']; ?>上的评论"><?php echo $value['comnum']; ?></a> 条评论</span>|
      <span><?php echo $value['views']; ?> 次查看</span>
      <?php editflg($value['logid'],$value['author']); ?>
    </div>
	<?php echo ''.subString(strip_tags($value['log_description'],$img),0,200).''; ?>...
       </div>
    <?php endforeach; ?>
    <div id="pagenavi"> <?php echo $page_url;?> </div>
  </article>
</section>
<?php
 include View::getView('footer');
?>
