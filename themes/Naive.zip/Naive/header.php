<?php
/*
Template Name:Naive
Description:你们呀！Naive！
Version:2.0
Author:魔法基佬MKⅡ
Author Url:http://hmoe.me
Sidebar Amount:0
ForEmlog:5.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="Emlog" />
<meta name="author" content="魔法基佬MKⅡ" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="<?php echo $blogname; ?> - RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>style.css"/>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>phZoom/phzoom.css" />
<script src="http://lib.sinaapp.com/js/jquery/1.7.2/jquery.min.js"></script>
<?php doAction('index_head'); ?>
<!--[if lt IE 9]>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
</head>
<body id="home">
  <header>
    <div class="headercontent">
     <h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
	 <span><?php echo $bloginfo; ?></span>
<nav>
  <?php blog_navi();?>
  </ul>
</nav>
    </div>
  </header>
