<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="main">
<div id="container">
<div id="content" role="main">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
	<h2 class="entry-title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
	<div class="entry-meta">
	<span class="meta-prep meta-prep-author">发表于：</span><span class="entry-date"><?php echo gmdate('Y-n-j G:i l', $value['date']); ?></span><span class="meta-sep">|作者：</span> <span class="author vcard"><?php blog_author($value['author']); ?></span>|	 
		<?php blog_sort($value['logid']); ?> |
		<?php editflg($value['logid'],$value['author']); ?>
	</div><!-- .entry-meta -->
	<div class="entry-content">
	<?php echo $value['log_description']; ?>
	<p class="att"><?php blog_att($value['logid']); ?></p>
	</div><!-- .entry-content -->
	<div class="entry-utility">
					<span class="meta-sep"></span>
								<span class="tag-links"><span class="entry-utility-prep entry-utility-prep-tag-links"></span> <?php blog_tag($value['logid']); ?></span>
					<span class="meta-sep">|</span>
								<span class="comments-link"><a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a></span>
					<span class="meta-sep">|</span>
								<span class="comments-link"><a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a></span>
	</div><!-- .entry-utility -->

	<div style="clear:both;"></div>
<?php endforeach; ?>

<div id="pagination">
	<?php echo $page_url;?>
</div>
</div><!-- #content -->
</div><!-- #container -->
<?php
 include View::getView('side');
 include View::getView('footer');
?>
	