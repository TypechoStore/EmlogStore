<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>  
<div id="main">
<div id="container">
<div id="content" role="main">
	<h2 class="entry-title"><?php topflg($top); ?><?php echo $log_title; ?></h2>
	<div class="entry-meta">
	<span class="meta-prep meta-prep-author">发表于：</span><span class="entry-date"><?php echo gmdate('Y-n-j G:i l', $date); ?></span>
	<span class="meta-sep">|作者：</span> <span class="author vcard"><?php blog_author($author); ?></span>|
		<?php blog_sort($logid); ?> |<?php editflg($logid,$author); ?>
	</div><!-- .entry-meta -->
	<div class="entry-content">
	<?php echo $log_content; ?>
	<p class="att"><?php blog_att($logid); ?></p>
	</div><!-- .entry-content -->
	<div class="social-links-single">
							<div class="twitter-single">
							
							</div><!-- .twitter-single -->
							
							<div class="facebook-single">
								
							</div><!-- .facebook-single -->
							
	</div><!-- .social-links-single -->
		<div class="entry-utility">
					<span class="meta-sep"></span>
								<span class="tag-links"><span class="entry-utility-prep entry-utility-prep-tag-links"></span><?php blog_tag($logid); ?></span>
		</div><!-- .entry-utility -->
	<?php doAction('log_related', $logData); ?>
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
</div><!--#content-->
</div><!-- #container -->
<?php
 include View::getView('side');
 include View::getView('footer');
?>