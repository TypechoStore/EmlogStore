<?php
/*
Template Name:spring春意
Description:小清新
Version:1.0
Author:emlog
Author Url:http://blog.purstar.net
Sidebar Amount:1
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/window.js"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="wrap">
  <div id="header">
    <h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
    <h3><?php echo $bloginfo; ?></h3>
  </div>

  <div id="banner"><a href="<?php echo BLOG_URL; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/top/<?php echo rand(1,5);?>.jpg" height="134" width="960" title="<?php echo $blogname; ?>|<?php echo $bloginfo; ?>"/></a>
	<div class="right_nav">
	<a href="<?php echo BLOG_URL; ?>rss.php" title="RSS订阅" class="rss">RSS订阅</a>
	<a href="javascript:window.external.AddFavorite('<?php echo BLOG_URL; ?>','<?php echo $blogname; ?>')" class="fav" title="加入收藏夹">加入收藏</a>
</div>
  </div>
  <div id="nav"><?php blog_navi();?></div>
  <!-- end #nav-->
<script>
(function() {
	var $backToTopTxt = "返回顶部", $backToTopEle = $('<div class="backToTop"></div>').appendTo($("body"))
		.text($backToTopTxt).attr("title", $backToTopTxt).click(function() {
			$("html, body").animate({ scrollTop: 0 }, 120);
	}), $backToTopFun = function() {
		var st = $(document).scrollTop(), winh = $(window).height();
		(st > 0)? $backToTopEle.show(): $backToTopEle.hide();	
		//IE6下的定位
		if (!window.XMLHttpRequest) {
			$backToTopEle.css("top", st + winh - 166);	
		}
	};
	$(window).bind("scroll", $backToTopFun);
	$(function() { $backToTopFun(); });
})();
</script>
  <div class="backToTop"></div>
  <?php if("http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']==BLOG_URL):?>
  <div class="window" id="right">
			<div class="title">
				<img src="<?php echo TEMPLATE_URL;?>images/close.gif" alt="关闭"  title="关闭窗口" />
				<h2>欢迎光临<a href="<?php echo BLOG_URL;?>" title="<?php echo $blogdescription;?>"><?php echo $blogname; ?></a></h2>
			</div>
			<div class="contentbox">
				<ol><strong>最新公告</strong>
					<li>交换链接请到留言板，目前本站只招收同类型友情链接，PR>=2</li>
					<li>如果有意同本站交换链接，请先添加本站，我会在最快时间内为你站添加上链接</li>		
				</ol>
			</div>
	</div>
	<?php endif; ?>