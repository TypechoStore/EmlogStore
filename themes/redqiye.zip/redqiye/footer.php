<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div id="mainBody">
<div class="logoBox"><dl><dt></dt>
<dd><?php index_flinks();?></dd></dl></div><div class="clear"></div>
<div class="bottomMenu">
<p><a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?></p>
<p><?php copyright();?></p>
<p><?php doAction('index_footer'); ?></p>
</div>
</div>
</div>
<script>prettyPrint();</script>
</body>
</html>