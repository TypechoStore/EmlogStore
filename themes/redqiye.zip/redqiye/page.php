<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="searchBox list"><ul><li class="a">
现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; <?php blog_sort($logid); ?> &raquo; <?php echo $log_title; ?>
</li></ul>
</div><div class="clear"></div>
<div id="mainBody">
<div class="areaL">
<div class="pageBox">
<dl>
<dt id="areaName"><?php echo $log_title; ?></dt>
<dd class="webBox">
<div class="a">
<h1><?php echo $log_title; ?></h1>

<div class="clear"></div>
</div>
<div class="b">
<div id="newsContent">
<p><?php echo $log_content; ?></p>

</div>

</div>

</dd>
</dl>
</div>
<div class="replyBox">
<dl>
<dt>相关评论</dt>
<dd>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?></dd>
</dl>
</div>
<div class="clear"></div>
</div>
<?php include View::getView('side');?>
<div class="clear"></div>
</div>
<?php include View::getView('footer');?>