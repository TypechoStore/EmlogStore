<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>

<div class="searchBox list"><ul><li class="a"><marquee id='marInfo' direction='left' style='width:958px;' loop='-1' class='disClass' scrollamount='3' scrolldelay='30' onmouseover='this.stop()' onmouseout='this.start()'>
滚动公告

</marquee>
</li></ul>
</div><div class="clear"></div>
<div id="mainBody">

<div class="areaL">

<div class="areaL1">
<div id="saySlide"><?php home_slide();?></div></div>

<div class="areaL2"><div class="newBox">
<dl>
<dt><div class="more"><a href="#"></a></div></dt>
<dd class="listArrow0"><ul><?php getNewLogs(9);?>
</ul>
</dd></dl></div><div class='clear'></div></div></div>

<div class="areaR">
<div class="recomBox"><dl><dt>精彩推荐</dt>
<dd class="listArrow2"><ul>
<?php echo getTopLogs(9);?>
</ul>
</dd></dl></div>
</div><div class="clear"></div></div>
<!--滚动图文-->
<div class="imgBox list">
<div id="caseMarX" style="overflow:hidden;margin:0px;white-space:nowrap;width:100%; height:130px;">
<ul>
<table><tr><td id="td1">
<?php get_rand_log();?>
</td>
</tr>
</table>
<table><tr><td id="td2"></td></tr></table>
</ul>
</div>
</div>
<!--滚动图文结束-->
<div class="clear"></div>
<div id="mainBody1">

<div class="areaL">
<!--演示栏目列表开始-->
<div class="itemBox">
<dl>
<dt><div class="more"><a href="http://lanyes.org"></a></div><span class="pointer" onclick="document.location.href="http://lanyes.org";">随便谢谢<!--栏目名称请手动修改,链接也请手动制定--></span></dt>
<dd class="listArrow3">
<ul>
<?php index_tablist('1','new','5');?><!--此处说明：这是调用列表函数，括号里面的代码含义为，1是指栏目ID，new不用管，5是调用条数-->
</ul>
</dd>
</dl>
</div>
<!--演示栏目列表结束-->
<!--如要自行添加更多栏目列表，请复制上边演示栏目列表注释里的代码然后粘贴到下方即可-->
<!--如你不懂可以加QQ：84953409咨询-->
<div class="itemBox">
<dl>
<dt><div class="more"><a href="#"></a></div><span class="pointer" onclick="document.location.href="#";">网页设计</span></dt>
<dd class="listArrow3">
<ul>
<?php index_tablist('4','new','5');?>
</ul>
</dd>
</dl>
</div>
<div class="clear"></div>
<div class="itemBox">
<dl>
<dt><div class="more"><a href="#"></a></div><span class="pointer" onclick="document.location.href="#";">网站推广</span></dt>
<dd class="listArrow3">
<ul>
<?php index_tablist('5','new','5');?>
</ul>
</dd>
</dl>
</div>
<div class="itemBox">
<dl>
<dt><div class="more"><a href="#"></a></div><span class="pointer" onclick="document.location.href="#";">绿色软件</span></dt>
<dd class="listArrow3">
<ul>
<?php index_tablist('2','new','5');?>
</ul>
</dd>
</dl>
</div>
<div class="clear"></div></div>

<div class="areaR"><div class="typeBox"><dl><dt>热门文章</dt>
<dd class="listArrow1"><ul>
<?php getHotLogs(13);?>
</ul>
</dd></dl></div><div class="clear"></div></div>
</div>
<div class="clear"></div>
<?php include View::getView('footer');?>
