<?php
/*
Template Name:红色文章模板
Description:红色调简单文章模板
Version:1.0
Author:蓝叶
Author Url:http://lanyes.org
Sidebar Amount:1
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>images/red.css" rel="stylesheet" type="text/css" />
<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<script src="<?php echo TEMPLATE_URL; ?>jquery.saySlide.js" type="text/javascript" ></script>
<script>
$(function(){
$("#saySlide").saySlide({isTitle:true,isBottombg:true,autodir:'left'});
})
</script>
<script>
function scrollLeft(id_div,id_td1,id_td2){
s_div = $("#"+id_div);
s_td = $("#"+id_td1);
s_td2 = $("#"+id_td2);
s_td2.html(s_td.html());
s_wdiv = parseInt(s_div.css("width"));
s_wtd =  parseInt(s_td2.css("width"));
s_iwtd =  s_wtd;
s_icontent = s_td.html();
if(s_wtd > s_wdiv){
setInterval(function(){
if( s_wtd > s_wdiv && (s_wtd - s_wdiv) <= s_div[0].scrollLeft ){
s_td.html(s_td.html() + s_icontent);
s_wtd = s_wtd + s_iwtd;
}
s_div[0].scrollLeft++;
},30);
}
}
$(function(){
scrollLeft("caseMarX","td1","td2");
});
</script>
</head>
<body>
<div id="wrap">
<div id="topBody">
<div class="topMenu list">
<ul><li class="a list">欢迎光临<!--此处欢迎语，自行添加--></li><li class="b">加入收藏&nbsp;&nbsp;设为首页<!--此处代码自行添加--></li></ul></div><div class="clear"></div>
<div class="topLogo list">
<img src="http://lanyes.org/content/templates/qinxinlv/images/logo.png" alt="" /><!--此处为LOGO，也可以放广告代码，可以自行添加，如果不懂如何加可以咨询蓝叶QQ:84953409--></div>
<div class="clear"></div>
<div class="mainMenu">
<ul class="topnav"><?php blog_navi();?></ul>
</div><div class="clear"></div>
