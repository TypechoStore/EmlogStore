<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="searchBox list"><ul><li class="a">
现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; <?php rizhi_sort($logid); ?> &raquo; <?php echo $log_title; ?>
</li></ul>
</div><div class="clear"></div>
<div id="mainBody">
<div class="areaL">
<div class="pageBox">
<dl>
<dt id="areaName"><?php rizhi_sort($logid); ?></dt>
<dd class="webBox">
<div class="a">
<h1><?php echo $log_title; ?></h1>
<div class="addi2">
时间：<?php echo gmdate('Y-n-j G:i', $date); ?>&nbsp;&nbsp;作者：<?php blog_author($author); ?>&nbsp;&nbsp;来源：本站原创&nbsp;&nbsp;查看：<span id="infoReadNum"><?php echo $views; ?></span>&nbsp;&nbsp;评论：<span id="infoReplyNum"><?php echo $comnum; ?></span>
</div>
<div class="clear"></div>
</div>
<div class="b">
<div id="newsContent">
<p><?php echo $log_content; ?></p>
<p><?php blog_tag($logid); ?></p>
</div>
<div class="mark"><center>
<!-- Baidu Button BEGIN -->
<div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
<a class="bds_qzone"></a>
<a class="bds_tsina"></a>
<a class="bds_tqq"></a>
<a class="bds_renren"></a>
<a class="bds_t163"></a>
<span class="bds_more"></span>
<a class="shareCount"></a>
</div>
<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=636112" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
</script>
<!-- Baidu Button END --></center>
<div class="clear"></div>
</div>
</div>
<div class="c">
<?php neighbor_log($neighborLog); ?>
</div>
</dd>
</dl>
</div>
<div class="replyBox">
<dl>
<dt>相关评论</dt>
<dd>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?></dd>
</dl>
</div>
<div class="clear"></div>
</div>
<?php include View::getView('side');?>
<div class="clear"></div>
</div>
<?php include View::getView('footer');?>