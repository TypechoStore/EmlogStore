<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div class="c"></div>
</div>
<div class="footer">
<div class="footer_left">
<span class="footer_left_copy">All Rights Copy By <?php echo $blogname; ?></span>
<span class="footer_left_sys">博客程序：<a href="http://www.emlog.net" title="采用emlog系统" target="_blank">EMLOG</a></span>
主题修改：<a href="http://www.wangshizhao.cn/" title="王小刀的博客。（一个大神）" target="_blank">行走的沙骆</a>
<?php theme();?>
<?php if(!empty($icp)){echo '<span class="footer_left_ba">备案信息：<a href="http://www.miibeian.gov.cn" target="_blank">'.$icp.'</a></span>';} ?>
</div>
<div class="footer_right"><?php echo $footer_info; ?></div>
<div class="c"></div>
<?php doAction('index_footer'); ?>
</div>
<div class="top"></div>
</div>
<script>prettyPrint();</script>
</body>
</html>