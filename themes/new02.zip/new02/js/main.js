jQuery(document).ready(function(){
jQuery(".top").hide();
jQuery(window).scroll(function(){
if(jQuery(window).scrollTop() > 100){
jQuery(".top").fadeIn(500);
}else{
jQuery(".top").fadeOut(500);
};
});
jQuery(".top").click(function(){
jQuery("body,html").animate({scrollTop:0},1000);
});
});

jQuery(document).ready(function(){
jQuery('#vistor_mail').bind('input propertychange',function(){
var smd = jQuery.md5(jQuery('#vistor_mail').val());
jQuery('#vistor_img').attr("src","http://www.gravatar.com/avatar/"+smd+"?s=80&d=mm&r=g");
});
});

jQuery(document).ready(function(){ 
var loaded = true; 
var top = jQuery(".navi").offset().top; 
function Add_Data() 
{ 
var scrolla=jQuery(window).scrollTop(); 
var cha=parseInt(top)-parseInt( scrolla); 
if(loaded && cha<=0) 
{ 
jQuery(".navi").addClass("ftop"); 
loaded=false; 
} 
if(!loaded && cha>0) 
{ 
jQuery(".navi").removeClass("ftop");
loaded=true; 
} 
} 
jQuery(window).scroll(Add_Data); 
}); 

jQuery(document).ready(function(){
jQuery('.read_wall ul li a').simpletooltip();
});

(function(jQuery){ jQuery.fn.simpletooltip = function(){
    return this.each(function() {
        var text = jQuery(this).attr("title");
        jQuery(this).attr("title", "");
        if(text != undefined) {
            jQuery(this).hover(function(e){
                var tipX = e.pageX + 12;
                var tipY = e.pageY + 12;
                jQuery(this).attr("title", ""); 
                jQuery("body").append("<div id='simpleTooltip' style='position: absolute; z-index: 100; display: none;'>" + text + "</div>");
                if(jQuery.browser.msie) var tipWidth = jQuery("#simpleTooltip").outerWidth(true)
                else var tipWidth = jQuery("#simpleTooltip").width()
                jQuery("#simpleTooltip").width(tipWidth);
                jQuery("#simpleTooltip").css("left", tipX).css("top", tipY).fadeIn("medium");
            }, function(){
                jQuery("#simpleTooltip").remove();
                jQuery(this).attr("title", text);
            });
            jQuery(this).mousemove(function(e){
                var tipX = e.pageX + 12;
                var tipY = e.pageY + 12;
                var tipWidth = jQuery("#simpleTooltip").outerWidth(true);
                var tipHeight = jQuery("#simpleTooltip").outerHeight(true);
                if(tipX + tipWidth > jQuery(window).scrollLeft() + jQuery(window).width()) tipX = e.pageX - tipWidth;
                if(jQuery(window).height()+jQuery(window).scrollTop() < tipY + tipHeight) tipY = e.pageY - tipHeight;
                jQuery("#simpleTooltip").css("left", tipX).css("top", tipY).fadeIn("medium");
            });
        }
    });
}})(jQuery);