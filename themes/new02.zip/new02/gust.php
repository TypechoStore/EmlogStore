<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div class="content">
<div class="content_left">
<div class="log_title"><?php echo $log_title; ?></div>
<div class="log_content"><?php echo $log_content; ?></div>
<?php read_wall();?>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
<?php include View::getView('side'); include View::getView('footer');?>