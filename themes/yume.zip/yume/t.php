<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="wrapper">
  <div class="columns clearit">
    <div id="pageHeader">
      <h1></h1>
    </div>
    <div id="columnHomeA" class="column">
	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
    <div class="top"><a href="<?php echo BLOG_URL . 'admin/twitter.php' ?>">写碎语</a></div>
    <?php endif; ?>
	 <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?> 
      <div class="entry clearit">
        <div class="dreamer"><img class="avatarMedium" src="<?php echo $avatar; ?>" width="52px" height="52px" /><!--<span class="avatarMedium" style="background-image:url('<?php echo $avatar; ?>?r=1345005582');background-size:72px;"></span> -->
		<a title="<?php echo $author; ?>" class="name" style="margin-left:8px;"><?php echo $author; ?></a>
		</div>
        <!-- <div class="widget">
			<p class="date">< ?php echo date(Y年m月j日); ?></a></p>
		</div> -->
        <div id="twitter_<?php echo $tid;?>" class="entryMain">
          <div class="dream clearit">
            <h2><?php echo $val['date'];?></h2>
            <div class="content"> 
			<?php echo $val['t'].'<br/>'.$img;?>
			<div class="clear"></div>
			<ul id="r_<?php echo $tid;?>" class="r">

			</ul>
			<?php if ($istreply == 'y'):?>
			<div class="huifu" id="rp_<?php echo $tid;?>">
			<textarea id="rtext_<?php echo $tid; ?>"></textarea>
			<div class="tbutton">
				<div class="tinfo" style="display:<?php if(ROLE == 'admin' || ROLE == 'writer'){echo 'none';}?>">
				昵称：<input type="text" id="rname_<?php echo $tid; ?>" value="" />
				<span style="display:<?php if($reply_code == 'n'){echo 'none';}?>">验证码：<input type="text" id="rcode_<?php echo $tid; ?>" value="" /><?php echo $rcode; ?></span>        
				</div>
				<input class="button_p" type="button" onclick="reply('<?php echo DYNAMIC_BLOGURL; ?>index.php?action=reply',<?php echo $tid;?>);" value="回复" /> 
				<div class="msg"><span id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></span></div>
			</div>
			</div>
			<?php endif;?>
			<div style="float:right;"><a href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">回复(<span id="rn_<?php echo $tid;?>"><?php echo $val['replynum'];?></span>)</a></div>
			</div>
			  
          </div>
        </div>
      </div>

	<?php endforeach;?>
    <div class="page_inner">
		<?php echo $pageurl;?>
	</div>
    </div>
<?php include View::getView('side'); ?>
  </div>
</div>
<?php include View::getView('footer');?>
</body>
</html>