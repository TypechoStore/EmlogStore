<?php
/*
Template Name: Yume
Author: Theme Sai
Author URI: http://cong5.net
Description: 本主题版权并不是我的，<strong><a href="http://cong5.net/" target="_balck">Mr.柿子</a></strong>我只做了仿制和修改工作，主题的所有权归原作者 <strong><a href="http://saicn.com/me/" target="_balck">Sai</a></strong> 所有
Version: 1.0
Sidebar Amount:1
ForEmlog:4.2.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="<?php echo TEMPLATE_URL; ?>favicon.ico" type="image/x-icon" />
<link rel="apple-touch-icon" href="<?php echo TEMPLATE_URL; ?>ico_ios.png" />
<link rel="apple-touch-icon" sizes="72x72" href="<?php echo TEMPLATE_URL; ?>touch-icon-ipad.png" />
<link rel="apple-touch-icon" sizes="114x114" href="<?php echo TEMPLATE_URL; ?>touch-icon-iphone4.png" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<!--[if lte IE 6]>
<script src="<?php echo TEMPLATE_URL; ?>js/pngfixed.js" type="text/javascript"></script>
<script>
  DD_belatedPNG.fix('.png_bg,img,#wrapper');
</script>
<![endif]-->
<?php doAction('index_head'); ?>
</head>
<body>
<div id="header">
  <div id="nav" class="clearit">
    <ul class="clearit">
		<li class="logo"><a href="<?php echo BLOG_URL; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/logo.png" alt=""></a></li>
		<div class="menu-top-container">
			<?php blog_navi();?>
		</div>
    </ul>
  </div>
</div>