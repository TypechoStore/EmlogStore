<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="footer"> &copy 2013 Mr.柿子 | <a href="/about">关于 Mr.Cong</a> <?php echo $icp; ?><?php doAction('index_footer'); ?> Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> </div>
<div id="meihua"></div>
<link href="<?php echo TEMPLATE_URL; ?>images/leaves/leaves.css" rel="stylesheet" type="text/css" />
<script src="<?php echo TEMPLATE_URL; ?>images/leaves/leaves.js" type="text/javascript"></script>