<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="wrapper">
  <div class="columns clearit">
    <div id="pageHeader">
      <h1></h1>
    </div>
    <div id="columnHomeA" class="column">
	
      <div class="entry clearit">
        <div class="dreamer"> <a href="<?php echo $value['log_url']; ?>"><span class="avatarMedium" style="background-image:url('<?php echo TEMPLATE_URL; ?>images/Mr.Cong.jpg?r=1345005582');"></span></a> <?php blog_author($value['author']); ?> </div>
        <div class="widget">
			<p class="date"><?php echo gmdate('Y-n-j', $date); ?></p>
		</div>
        <div id="entry_<?php echo $value['logid']; ?>" class="entryMain">
          <div class="dream clearit">
            <h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>" title="<?php echo $log_title; ?>"><?php echo $log_title; ?></a></h2>
            <div class="content"> 
			<?php echo $log_content; ?>
			<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
			<div class="trackback"><?php blog_trackback($tb, $tb_url, $allow_tb); ?></div>
			<br/>
			<?php doAction('log_related', $logData); ?>
			<br/>
			<!-- Baidu Button BEGIN -->
			<div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare">
			<a class="bds_tsina"></a>
			<a class="bds_qzone"></a>
			<a class="bds_tqq"></a>
			<a class="bds_renren"></a>
			<a class="bds_tqf"></a>
			<span class="bds_more">更多</span>
			<a class="shareCount"></a>
			</div>
			<script type="text/javascript" id="bdshare_js" data="type=tools&uid=589313" ></script>
			<script type="text/javascript" id="bdshell_js"></script>
			<script type="text/javascript">
			document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
			</script>
			<!-- Baidu Button END -->
			<br/>
            <div class="tags"><?php blog_tag($logid); ?></div>
			</div>
			  
          </div>
          <div id="comments" class="comments">
            <ul id="commentsContainer">
				<?php blog_comments($comments); ?>
				<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
            </ul>
          </div>
        </div>
      </div>
	  
    </div>
<?php include View::getView('side'); ?>
  </div>
</div>
<?php include View::getView('footer'); ?>
</body>
</html>