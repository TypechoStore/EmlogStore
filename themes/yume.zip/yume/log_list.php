<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="wrapper">
  <div class="columns clearit">
    <div id="pageHeader">
      <h1></h1>
    </div>
    <div id="columnHomeA" class="column">
	<?php doAction('index_loglist_top'); ?>
	<?php foreach($logs as $value): ?>
      <div class="entry clearit">
        <div class="dreamer"> <a href="<?php echo $value['log_url']; ?>"><span class="avatarMedium" style="background-image:url('<?php echo TEMPLATE_URL; ?>images/Mr.Cong.jpg?r=1345005582');"></span></a> <?php blog_author($value['author']); ?> </div>
        <div class="widget">
			<p class="date"><?php echo gmdate('Y-n-j', $value['date']); ?></p>
		</div>
        <div id="entry_<?php echo $value['logid']; ?>" class="entryMain">
          <div class="dream clearit">
            <h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></h2>
            <div class="content"> 
				<?php echo $value['log_description']; ?>
				<span class="read-more"><a href="<?php echo $value['log_url']; ?>" title="阅读 <?php echo $value['log_title']; ?> 全文">[阅读…]</a></span>
			</div>
			
			<div class="tags"><?php blog_tag($value['logid']); ?></div>			
          </div>
          <div id="comments_<?php echo $value['logid']; ?>" class="comments">
            <div class="stats"><a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a></div>
          </div>
        </div>
      </div>
	<?php endforeach; ?>
	  
    <div class="page_inner">
		<?php echo $page_url;?>
	</div>
    </div>
<?php include View::getView('side'); ?>
  </div>
	<!-- <div class="links">
	<ul class='xoxo blogroll'>
	<li>M y 邻 居：</li>
			< ?php wp_list_bookmarks('categorize=0&category=&
		category_orderby=id&before=<li>&after=</li>&show_images=0&
		show_description=1&orderby=name&title_li='); ?>
	</ul>
	</div> -->
</div>
<?php include View::getView('footer'); ?>
</body>
</html>