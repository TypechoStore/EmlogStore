<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div class="container">
	<div class="content-wtap">
		<div class="content">
			<?php doAction('index_loglist_top'); ?>
			<?php if (!empty($logs)): foreach($logs as $value): ?>
			<div class="post_list">
				<div class="img_box">
				
				<a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><img src="<?php get_imgsrc($value['content']); ?>"/></a>
				</div>
				<div class="post_box">
					<h2 class="tit"><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
					<p class="date"><span class="sort"><?php blog_sort($value['logid']); ?></span> <span class=""><?php blog_tag($value['logid']); ?></span></p>
					<p class="info"><?php echo extractHtmlData($value['content'],140);?> <span class="readmore"><a href="<?php echo $value['log_url']; ?>">阅读全文</a></span></p>
				</div>
			</div>
			<?php 
			endforeach;
			else: ?>
			<div class="post_list">
				<div class="img_box">
				<img src="<?php echo TEMPLATE_URL; ?>images/no-f.png" />
				</div>
				<div class="post_box">
					<h2 class="tit">没找到</h2>
					<p class="info">没有符合条件的内容可以显示！</p>
				</div>
			</div>
			<?php endif;?>
			<div class="pagebar"><?php echo $page_url;?></div>
			
		</div>
	</div>
	<div class="sidebar">
		<?php 
			include View::getView('side');
		?>
	</div>
</div>
<?php
 include View::getView('footer');
?>
