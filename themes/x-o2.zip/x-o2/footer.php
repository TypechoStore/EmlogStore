<!-- 以下为本模板的版权信息，尊重作者劳动成果，请自觉保留内容，谢谢支持 -->
<div class="footer">
	<div class="">
		<dt></dt>
		<dd></dd>
	</div>
	<div class=""></div>
	<div class=""></div>
	<div class="">Powered by  <a href="http://www.emlog.net/" target="_blank"> Emlog  </a>   Theme  by  <a href="http://www.x123.cc/" target="_blank"> X世界  </a>  </div>
</div>
</body>
</html>