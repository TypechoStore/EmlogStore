<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--end #content-->
<div style="clear:both;"></div>
  <div class="fbg">
    <div class="fbg_resize">
      <div class="col c1">
        <h2><span>特色服务</span></h2>
        <a href="<?php echo BLOG_URL; ?>"><img src="/content/templates/defaultEC2.0/images/pix1.jpg" width="58" height="58" title="网站建设" alt="网站建设" /></a>
        <a href="<?php echo BLOG_URL; ?>"><img src="/content/templates/defaultEC2.0/images/pix4.jpg" width="58" height="58" title="B2B推广" alt="B2B推广" /></a>
        <a href="<?php echo BLOG_URL; ?>"><img src="/content/templates/defaultEC2.0/images/pix5.jpg" width="58" height="58" title="博客运营" alt="博客运营" /></a>
      </div>
      <div class="col c2">
        <h2><span>关于博客</span></h2>
        <p>Powered by <a href="http://www.emlog.net" target="_blank" rel="nofollow" title="采用emlog系统">emlog</a><?php echo $footer_info; ?></p>
        <p>备案信息<a href="http://www.miibeian.gov.cn" rel="nofollow" target="_blank"><?php echo $icp; ?></a></p>
        <p>Copyright © 2014 by <a href="<?php echo BLOG_URL; ?>" title="沈军">沈军</a>.All rights reserved.</p>
      </div>
      <div class="col c3">
        <h2><span>联系我们</span></h2>
        <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=375405748&site=qq&menu=yes" rel="nofollow" style="font-size:14px;line-height:1.5;">Q:375405748</a>
        <p>18523488524</p>
        <p>Address: ChongQing</p>
      </div>
      <div class="clr"></div>
    </div>
  </div>
</div><!--end #footerbar-->
<a name="bottom">&#160;</a>
<div class="go">
	<a title="返回顶部" class="top" href="#top"></a>
	<a title="如果您有意见，请反馈给我们！" class="feedback" href="http://www.cqshenjun.com/guestbook" target="_blank"></a>
	<a title="返回底部" class="bottom" href="#bottom"></a>
</div>
</div><!--end #wrap-->
<script>prettyPrint();</script>
</body>
</html>