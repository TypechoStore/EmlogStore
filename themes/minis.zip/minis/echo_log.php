<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
 <div class="clear"></div>
 
 
 <div id="main">
	<div class="posts">
		<div class="poboxs">
		<div class="bnav"><?php echo $blogname; ?>  » <?php blog_sort($logid); ?> » <?php echo $log_title; ?> 正文</div>
								<div class="potitles"><?php topflg($top); ?><?php echo $log_title; ?></div>
					<div class="info">
					<?php echo gmdate('Y-n-j', $date); ?> <span class="line">|</span> <?php blog_author($author); ?><span class="line">|</span> <?php blog_sort($logid); ?><span class="line">|</span> <?php editflg($logid,$author); ?></div>
			<div id="content" class="content"><?php echo $log_content; ?></div>
	        	        			<div class="minitags"><span class="zhuantag">请继续阅读有关&nbsp;</span> <?php blog_tag($logid); ?><span class="zhuantag">&nbsp;的文章</span></div>
	 		<div class="clear"></div>
		</div>
	<div class="navigation">
		<?php neighbor_log($neighborLog); ?>
		<div class="clear"></div>
	</div>
<div class="quotes">
<div class="quotet">猜你可能喜欢的文章：</div>
						<li></li><?php art_random_log($title); ?>
				
			</div>	<div class="clear"></div>
			<?php include View::getView('pl'); ?>
			

			
</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>
