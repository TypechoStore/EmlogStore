<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
 <div class="clear"></div>
 
 
 <div id="main">
	<div class="posts">
		<div class="poboxs">
								<div class="potitles"><?php echo $log_title; ?></div>
			<div id="content" class="content"><?php echo $log_content; ?></div>
		</div><div class="clear"></div>
</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>
