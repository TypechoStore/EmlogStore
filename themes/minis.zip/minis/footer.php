<div class="footer">
<!-- 以下为本模板的版权信息，尊重作者劳动成果，请自觉保留内容，谢谢支持 -->
© <?php echo $footer_info; ?>  Powered by   <a href="http://www.x123.cc/post-5.html"target="_blank" >MiNi's For </a> <a href="http://www.emlog.net" target="_blank" title="采用emlog系统">emlog</a>
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>
	<?php doAction('index_footer'); ?>

<span id="cnzz_stat_icon_4758807"></span><span class="totop"><a href="javascript:scroll(0,0)">▲</a></span>
</div><div class="clear"></div>