<a class="co1" title="欢迎您在本站投放广告！" href="">空虚的广告位</a>
<a class="co2" title="欢迎您在本站投放广告！" href="">空虚的广告位</a>
<a class="co3" title="欢迎您在本站投放广告！" href="">空虚的广告位</a>
<a class="co4" title="欢迎您在本站投放广告！" href="">空虚的广告位</a>