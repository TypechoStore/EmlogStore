<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<?php doAction('index_loglist_top'); ?>


 <div class="clear"></div>
 <div id="main">
 <div class="posts">
 <?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
				<div class="pobox">
				<div class="potitle"><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></div>
			<div class="info">
			<?php echo gmdate('Y-n-j', $value['date']); ?> <?php blog_author($value['author']); ?> 
	<?php blog_sort($value['logid']); ?> 
	<?php editflg($value['logid'],$value['author']); ?><span class="line">|</span>
			</div>
			<div class="content"><?php echo $value['log_description']; ?></div>
		</div>
		<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
				
				
				<div class="pagenav"><?php echo $page_url;?></div>
				</div> 
        	</div>


<?php
 include View::getView('side');
 include View::getView('footer');
?>
