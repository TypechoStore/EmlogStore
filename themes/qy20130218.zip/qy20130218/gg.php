<div id="listen">关于我们</div>
<div id="gonggao"> 
欢迎光临本站</br>
技术团队核心：奇遇 老妖</br>
开放VIP2群：227952320加入条件：</br>
捐助用户，主机用户，emlog用户（书写版权）</br>
<div  id="zfb"><a  href="http://me.alipay.com/vruan" rel="nofollow" target="_blank"></a></div>

</div>