<?php
/*
Template Name:BBCMS2.0 for emlog v5
Description:老妖工作室倾情奉献，为纪念那段迷失的日子，特发布免费的商业主题，希望保留此处注释，希望使用者能正确书写emlog版权。
Version:2.0
Author:老妖工作室
Author Url:http://vruan.net
Sidebar Amount:1
ForEmlog:5.0.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
emLoadJquery();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>default.css" rel="stylesheet" type="text/css" />
<?php doAction('index_head'); ?>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/Sean_flash.js" language="javascript" type="text/javascript"></script>
<SCRIPT language="javascript" src="<?php echo TEMPLATE_URL; ?>js/Kurly_kv.js" type="text/javascript"></SCRIPT>

</head>
<body>
<!-- 顶部 开始 -->
<div id="header">
<!-- 导航菜单 开始 -->
<div id="nav">
<ul id="menus" class="menus"><?php blog_navi();?></ul>
<span><a href="<?php echo BLOG_URL; ?>rss.php" title="RSS订阅">RSS订阅</a></span>
</div>
<!-- 导航菜单 结束 -->
<!-- Logo banner 开始 -->
<div id="logobanner">
<a href="#"><img src="<?php echo TEMPLATE_URL; ?>images/logo.gif" width="200px" height="100px" alt="<?php echo $site_title; ?>" title="<?php echo $site_title; ?>" /></a>
<div class="fr">
<a href="#" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/banner.jpg" width="770px" height="100px" alt="" /></a>
</div>
</div>
<!-- Logo banner 结束 -->
<!-- 公告牌 开始 -->
<div id="placard">
<div id="announcement"><h4>公告牌: </h4>
<!--滚动公告 开始--->
<div id="anno_list">
<div id="marqueebox">
<div class="listbg">
<?php echo twitter1($title); ?>
</div>
</div>
</div>
<script>
function startmarquee(lh,speed,delay) {
var p=false;
var t;
var o=document.getElementById("marqueebox");
o.innerHTML+=o.innerHTML;
o.style.marginTop=0;
o.onmouseover=function(){p=true;}
o.onmouseout=function(){p=false;}
function start(){
t=setInterval(scrolling,speed);
if(!p) o.style.marginTop=parseInt(o.style.marginTop)-1+"px";
}
function scrolling(){
if(parseInt(o.style.marginTop)%lh!=0){
o.style.marginTop=parseInt(o.style.marginTop)-1+"px";
if(Math.abs(parseInt(o.style.marginTop))>=o.scrollHeight/2) o.style.marginTop=0;
}else{
clearInterval(t);
setTimeout(start,delay);
}
}
setTimeout(start,delay);
}
startmarquee(20,19,3000);
</script>
<!--滚动公告 结束-->
</div>
<div id="so"><form name="keyform" id="searchform"  method="get" action="<?php echo BLOG_URL; ?>index.php">
<div>
<input type="text" name="keyword" class="searchInput" value="请输入您要搜索的关键词" onblur="if(this.value==''){this.value='请输入您要搜索的关键词';}else{};" onFocus="this.value='';" id="s"/>   
<input class="searchBtn" type="submit" value="搜 索" id="searchsubmit">
</div>
</div>
</form>
</div>
</div>
<!-- 公告牌 结束 -->
</div>
<!-- 顶部 结束 -->
<div id="wrapper">



