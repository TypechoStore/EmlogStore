<?php 
/*
* 首页
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!-- 顶部自定义 开始 -->

<!-- 图片幻灯 开始 -->
<div id="picswitch">

<div style='visibility:hidden' id=KinSlideshow> 
<?php home_slide(); ?>


</DIV>
</div>
<!-- 图片幻灯 结束 -->
<div id="txtnews">
<!-- 最新头条 开始 -->
<div id="toplist">

<div class="b_l">
<ul id="J_setTabBNav">
<li>最新发布</li><li>热门推荐</li><li>随机推荐</li><li>站长推荐</li>
</ul>
<div id="J_setTabBBox">
<div>
<ul>
<?php index_tablist('', 'new', $num="7"); ?>
</ul>
</div>
<div>
<ul>
<?php index_tablist('', 'view', $num="7", $long="360"); ?>
</ul>
</div>
<div>
<ul>
<?php index_tablist('', 'rand', $num="7"); ?>
</ul>
</div>
<div>
<ul>
<?php index_rand_log();?>
</ul>
</div>
</div>
</div>
</div>
</div>

<!-- 最新头条 结束 -->
<!-- 热评文章 [ 评论最多 ] 开始 -->
<div id="recommend">

<?php include View::getView('gg'); ?>



</div>

<!-- 顶部自定义 结束 -->
<!-- 左侧 开始 -->
<div class="con_left">
<!-- 左侧通栏广告 开始-->

<div class="leftad">
<img src="<?php echo TEMPLATE_URL; ?>images/leftad.jpg" /></div>
<!-- 左侧通栏广告 结束-->
<?php get_list('1');?>
<?php get_list('4');?>
<?php get_list('2');?>
<?php get_list('6');?>
<div class="entry">
<H4>置顶文章</H4>
<UL id="TOP_ART" CLASS="TOP_ARTICLES">
<?php
//推荐文章
$db = MySql::getInstance();
$sql = 	"SELECT gid,title,content FROM ".DB_PREFIX."blog WHERE type='blog' and top='y' ORDER BY `top` DESC LIMIT 0,8";
$list = $db->query($sql);
$row = $db->fetch_array($list);
?>
<DIV class='T'>

<a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>"><?php echo $row['title']; ?></a></DIV>

<DIV class='TS'><?php echo subString(strip_tags($row['content']),0,350); ?>
</DIV>
<?php
//推荐文章
$db = MySql::getInstance();
$sql = 	"SELECT gid,title,content FROM ".DB_PREFIX."blog WHERE type='blog' and top='y' ORDER BY `top` DESC LIMIT 1,20";
$list = $db->query($sql);
while($row = $db->fetch_array($list)){
?>
<li><a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>" rel="bookmark"><?php echo $row['title']; ?></a></li>
<?php } ?>
</DIV>

<!-- 最新文章列表 开始 -->
<div class="entry">
<h4>更新列表</h4>
<?php get_newlog();?>


</div>
</div><!-- 左侧 结束 -->

<!-- 右侧 开始 -->
<div class="con_right">
<?php include View::getView('side'); ?>
</div>
<!-- 右侧 结束 -->

<!-- 友情链接 开始 -->
<div id="footer">
<h2>友情链接</h2>
<ul class="flink">
<?php frd_link(); ?>
</ul>
</div>
<!-- 友情链接 结束 -->


</div>

