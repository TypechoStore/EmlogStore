<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!-- 左侧 开始 -->
<!-- 正文 开始 -->

<div class="site-navi">
<div id="topnav">
<span>当前位置</span>
<a  title="返回首页" href="<?php echo BLOG_URL; ?>">首页 &raquo;</a> 
<?php echo $log_title; ?>
</div>
</div>
<!-- 左侧 开始 -->
<!-- 左侧通栏广告 开始-->
<!-- 最新文章列表 开始 -->
<div class="entry">
<h4><?php echo $log_title; ?>正文</h4>
<div class="post1" >
<h2 class="mid_single"><?php topflg($top); ?><?php echo $log_title; ?></h2>
<div class="describe">作者：<?php blog_author($author); ?>&nbsp;|&nbsp;
日期：<?php echo gmdate('Y-n-j', $date); ?>&nbsp;|&nbsp;
阅读：<?php echo $views; ?>次&nbsp;|&nbsp;
评论：<a href="#respond"><?php echo $comnum; ?>人</a>&nbsp;|&nbsp;
<?php blog_sort($logid); ?>
</div>
<div class="clean"></div>
<div class="zhenwen">
<?php echo $log_content; ?>
</div>
<?php doAction('log_related', $logData); ?>
<div class="content-footer">
<!-- Baidu Button BEGIN -->
<div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
<a class="bds_qzone"></a>
<a class="bds_tsina"></a>
<a class="bds_tqq"></a>
<a class="bds_renren"></a>
<a class="bds_t163"></a>
<span class="bds_more"></span>
<a class="shareCount"></a>
</div>
<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=0" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
</script>
<!-- Baidu Button END -->
</br></br>
<?php blog_tag($logid); ?>
</br>
相邻文章：<?php neighbor_log($neighborLog); ?></br>
该日志于&nbsp;<?php echo gmdate('Y-n-j H:i', $date); ?>&nbsp;由&nbsp;<?php blog_author($author); ?>&nbsp;发表在&nbsp;<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>&nbsp;网站上，你除了可以发表评论外，还可以转载"<?php echo $log_title;?>"日志到你的网站或博客，但是请保留源地址及作者信息，谢谢!!（尊重他人劳动，你我共同努力）</br> 
<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
</div>
<div id="contentleft">
<p class="comment-header"><a name="comment"></a></p>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);?>
</div>  
</li>
</ul><!--end #contentleft-->
</div>
</div>
<!-- 左侧 结束 -->

<!-- 右侧 开始 -->
<div class="con_right">
<?php include View::getView('side'); ?>
</div>
<!-- 右侧 结束 -->
<?php include View::getView('footer'); ?>












