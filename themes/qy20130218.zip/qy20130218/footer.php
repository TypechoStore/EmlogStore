<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="spacebox"></div>
<!-- 底部功能菜单 开始 -->
	<div id="foot_about">
	    			<a href="<?php echo BLOG_URL; ?>">返回首页<?php echo $langblog;?></a> | 
                <a href="#">关于我们</a> | 
                <a href="#">联系我们</a> | 
                <a href="#">广告合作</a> | 
                <a href="#">友情链接</a> | 
                <a href="#">版权声明</a> | 
                <a href="http://vruan.net/">模板设计</a> 
			    </div>
					
	<!-- 底部功能菜单 结束 -->
<!-- 底部版权 开始 -->
<div id="foot_copyright">
<p>Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> |
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> | <?php echo $footer_info; ?> |
<?php doAction('index_footer'); ?><span><a href="#header">返回顶部</a></span></p>
 
</div>
<!-- 底部版权 结束 -->
</div>
</body>
</html>