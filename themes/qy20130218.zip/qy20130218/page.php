<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!-- 左侧 开始 -->
<!-- 正文 开始 -->

<div class="site-navi">
<div id="topnav">
		<span>当前位置</span>
<a  title="返回首页" href="<?php echo BLOG_URL; ?>">首页 &raquo;</a> 
<?php echo $log_title; ?>
</div>
</div>
<!-- 左侧 开始 -->
<!-- 左侧通栏广告 开始-->
<!-- 最新文章列表 开始 -->
<div class="entry">
<h4><?php echo $log_title; ?></h4>
<div class="post1" >
<div class="clean"></div>
<div class="zhenwen">
	<?php echo $log_content; ?>
	</div>
	<div id="contentleft">
	<p class="comment-header"><a name="comment"></a></p>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
</div>
</div>
<!-- 左侧 结束 -->

<!-- 右侧 开始 -->
<div class="con_right">
<?php include View::getView('side'); ?>
</div>
<!-- 右侧 结束 -->

<?php include View::getView('footer'); ?>













