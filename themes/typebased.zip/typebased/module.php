<?php 
/*
* 侧边栏组件、页面模块
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
	<div class="block widget">
	<h2><?php echo $title; ?></h2>
	<ul id="blogger">
	<div id="bloggerinfoimg">
	<?php if (!empty($user_cache[1]['photo']['src'])): ?>
	<img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="<?php echo $user_cache[1]['photo']['width']; ?>" height="<?php echo $user_cache[1]['photo']['height']; ?>" alt="blogger" />
	<?php endif;?>
	</div>
	<b><?php echo $name; ?></b><br />
	<?php echo $user_cache[1]['des']; ?>
	</ul>
	</div>
<?php }?>
<?php
//widget：日历
function widget_calendar($title){
?>
	<div class="block widget">
	<h2><?php echo $title; ?></h2>
	<div id="calendar">
	</div>
	<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
	</div>
<?php }?>
<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
	<div id="tag_cloud" class="block widget">
	<h2><?php echo $title; ?></h2>
	<?php foreach($tag_cache as $value): ?>
		<span style="font-size:<?php echo $value['fontsize']; ?>pt; height:30px;">
		<a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇日志"><?php echo $value['tagname']; ?></a></span>
	<?php endforeach; ?>
	</div>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort');?>
	<div class="widget_categories block widget">
	<h2><?php echo $title; ?></h2>
	<ul id="blogsort">
	<?php foreach($sort_cache as $value): ?>
	<li>
	<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
	<a href="<?php echo BLOG_URL; ?>rss.php?sort=<?php echo $value['sid']; ?>"><img align="absmiddle" src="<?php echo TEMPLATE_URL; ?>images/icon_rss.gif" alt="订阅该分类"/></a>
	</li>
	<?php endforeach; ?>
	</ul>
	</div>
<?php }?>
<?php
//widget：最新碎语
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter'); ?>
	<div class="block widget">
	<h2><?php echo $title; ?></h2>
	<ul id="twitter">
	<?php foreach($newtws_cache as $value): ?>
	<li><?php echo $value['t']; ?><p><?php echo smartDate($value['date']); ?> </p></li>
	<?php endforeach; ?>
    <?php if ($istwitter == 'y') :?>
	<p style="text-align:right"><a href="<?php echo BLOG_URL . 't/'; ?>">更多&raquo;</a></p>
	<?php endif;?>
	</ul>
	</div>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE;
	$com_cache = $CACHE->readCache('comment');?>
	<div class="block widget">
	<h2><?php echo $title; ?></h2>
	<ul id="newcomment">
	<?php
	foreach($com_cache as $value):
	$url = Url::log($value['gid']).'#'.$value['cid'];
	?>
	<li id="comment"><?php echo $value['name']; ?>
	<br /><a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</div>
<?php }?>
<?php
//widget：最新日志
function widget_newlog($title){
	global $CACHE;
	$newLogs_cache = $CACHE->readCache('newlog');?>
	<div class="block widget">
	<h2><?php echo $title; ?></h2>
	<ul id="newlog">
	<?php foreach($newLogs_cache as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</div>
<?php }?>
<?php
//widget：随机日志
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	<div class="block widget">
	<h2><?php echo $title; ?></h2>
	<ul id="randlog">
	<?php foreach($randLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</div>
<?php }?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE;
	$dang_cache = $CACHE->readCache('record');?>
	<div class="block widget">
	<h2><?php echo $title; ?></h2>
	<ul id="record">
	<?php foreach($dang_cache as $value): ?>
	<li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
	<?php endforeach; ?>
	</ul>
	</div>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content, $id){ ?>
	<div class="block widget">
	<h2><?php echo $title; ?></h2>
	<?php echo $content; ?>
	</div>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE;
	$link_cache = $CACHE->readCache('link');?>
	<div class="block widget widget_links">
	<h2><?php echo $title; ?></h2>
	<ul id="link">
	<?php foreach($link_cache as $value): ?>
	<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</div>
<?php }?>
<?php
//blog：置顶
function topflg($istop){
	$topflg = $istop == 'y' ? "<img src=\"".TEMPLATE_URL."/images/import.gif\" align=\"absmiddle\"  title=\"置顶日志\" /> " : '';
	echo $topflg;
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == 'admin' || $author == UID ? '<h4 class="edit"><a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'">编辑</a></h4>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
	[<a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>]
	<?php endif;?>
<?php }?>
<?php
//blog：文件附件
function blog_att($blogid){
	global $CACHE;
	$log_cache_atts = $CACHE->readCache('logatts');
	$att = '<p>';
	if(!empty($log_cache_atts[$blogid])){
		$att .= '<b>附件下载：</b>';
		foreach($log_cache_atts[$blogid] as $val){
			$att .= '<br /><a href="'.BLOG_URL.$val['url'].'" target="_blank">'.$val['filename'].'</a> '.$val['size'];
		}
	}
	$att .= '</p>';
	echo $att;
}
?>
<?php
//blog：日志标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid]))
	{
		$tag = '<p><b>标签：</b>';
		foreach ($log_cache_tags[$blogid] as $value)
		{
			$tag .= "	<a href=\"".BLOG_URL."?tag=".$value['tagurl']."\">".$value['tagname'].'</a>';
		}
		$tag .= '</p>';
		echo $tag;
	}
}
?>
<?php
//blog：日志作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻日志
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog):?>
	<div class="alignleft"><a href="<?php echo Url::log($prevLog['gid']) ?>"><?php echo $prevLog['title'];?></a></div>
	<?php endif;?>
	<?php if($nextLog):?>
	<div class="alignright"><a href="<?php echo Url::log($nextLog['gid']) ?>"><?php echo $nextLog['title'];?></a></div>
	<?php endif;?>
	<div class="fix"></div>
<?php }?>
<?php
//blog：引用通告
function blog_trackback($tb, $tb_url, $allow_tb){
	 ?>
	<?php if($allow_tb == 'y'):?>
	<div id="trackback_address">
	<p>引用地址: <input type="text" style="width:350px" class="input" value="<?php echo $tb_url; ?>">
	<a name="tb"></a></p>
	</div>
	<?php endif; ?>
	<?php foreach($tb as $key=>$value):?>
		<ul id="trackback">
		<li><a href="<?php echo $value['url'];?>" target="_blank"><?php echo $value['title'];?></a></li>
		<li>BLOG: <?php echo $value['blog_name'];?></li><li><?php echo $value['date'];?></li>
		</ul>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：博客评论列表
function blog_comments($comments){
    extract($comments);
	 ?>
	<?php if($comments): ?>
	<div id="comments_wrap">
	<h3 id="comments">评论：<a name="comment"></a></h3>
	<ol class="commentlist">
	<?php
	foreach($comments as $key=>$value):
	$value['poster'] = $value['url'] ? '<a href="'.$value['url'].'" target="_blank">'.$value['poster'].'</a>' : $value['poster'];
	?>
	<li class="comments_wrap wrap">
	<a name="<?php echo $value['cid']; ?>"></a>
	<div class="left">
		<img src="http://www.gravatar.com/avatar/<?php echo md5($value['mail']); ?>" class="avatar photo" height="35" width="35" />
	</div>
    <div class="right">
        <h4><b><?php echo $value['poster']; ?></b>&nbsp; on <?php echo $value['date']; ?> </h4>
        <?php echo $value['content']; ?>
    </div>
	</li>
	<?php endforeach; ?>
	</ol>
	</div>
	<?php endif; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){?>
	<?php if($allow_remark == 'y'): ?>
	<div id="respond">
	<h3 class="lc">发表评论：<a name="comments"></a></h3>
	<form method="post"  name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
	<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
	<?php if(ROLE == 'visitor'): ?>
	<label for="author">昵称 (必填) ：<br />
	<input type="text" name="comname" id="author" value="<?php echo $ckname; ?>" size="27" tabindex="1" /></label> 
	<label for="email">Email (选填) ：<br />
	<input type="text" name="commail" id="email" value="<?php echo $ckmail; ?>" size="27" tabindex="2" /></label> 
	<label for="url">个人主页 （选填）：<br />
	<input type="text" name="comurl" id="url" value="<?php echo $ckurl; ?>" size="27" tabindex="3" /></label> 
	<?php endif; ?>
	<label for="comment">评论 ：<br /></label> 
	<textarea name="comment" id="comment" cols="50" rows="8" tabindex="4"></textarea>
	<?php echo $verifyCode; ?><input name="submit" type="submit" id="submit" tabindex="5" value="发表" class="sb" />
	</form>
	</div>
	<?php endif; ?>
<?php }?>