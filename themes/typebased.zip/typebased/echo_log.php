<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="wrap background">
	<div id="content" class="left-col wrap">
	<div class="post wrap page">
		<div class="post-meta left-col">
			<h3 class="wrap"><span class="month"><?php echo gmdate('m', $date); ?><span class="year"><?php echo gmdate('Y', $date); ?></span></span><span class="day"><?php echo gmdate('j', $date); ?></span></h3>
			<h4 class="author"><?php blog_author($author); ?></h4>
			<h4 class="comments"><a href="<?php echo Url::log($logid); ?>#comments"><?php echo $comnum; ?></a></h4>
			<?php editflg($logid,$author); ?>
		</div>
		<div class="post-content right-col">
			<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
			<?php echo $log_content; ?>
			<?php blog_att($logid); ?>
			<?php blog_tag($logid); ?>
		<?php doAction('log_related', $logData); ?>
		<div class="navigation"><?php neighbor_log($neighborLog); ?></div>
		<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
		<?php blog_comments($comments); ?>
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);?>
		</div>
	</div>
	</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>