<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="wrap background">
	<div id="content" class="left-col wrap">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
	<div class="post wrap">
		<div class="post-meta left-col">
			<h3 class="wrap"><span class="month"><?php echo gmdate('m', $value['date']); ?><span class="year"><?php echo gmdate('Y', $value['date']); ?></span></span><span class="day"><?php echo gmdate('j', $value['date']); ?></span></h3>
			<h4 class="author"><?php blog_author($value['author']); ?></h4>
			<h4 class="comments"><a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?></a></h4>
			<?php editflg($value['logid'],$value['author']); ?>
		</div>
		<div class="post-content right-col">
			<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
			<?php echo $value['log_description']; ?>
			<?php blog_tag($value['logid']); ?>
		</div>
	</div>
<?php endforeach; ?>
	<div id="pagenavi">
	<?php echo $page_url;?>
	</div>
	</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>