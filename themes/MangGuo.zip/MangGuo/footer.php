<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="footer">
	<div class="copyright">
	Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">emlog</a> 
    <?php echo $icp; ?> <?php echo $footer_info; ?> 
	<a href="sitemap.xml" target="_blank">网站地图</a>
	</div>
	<div class="about clearfix">
		<ul class="sitemap clearfix">
	<?php 
	foreach ($navibar as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	?>
	<li class="<?php echo isset($logid) && $key == $logid ? 'current' : 'common';?>"><a href="<?php echo $val['url']; ?>" target="<?php echo $val['is_blank']; ?>"><?php echo $val['title']; ?></a></li>
	<?php endforeach;?>
	<?php doAction('navbar', '<li class="common">', '</li>'); ?>
		</ul>
		<a href="<?php echo BLOG_URL; ?>" class="licence">&copy; <?php echo $blogname; ?></a>
	</div>
</div>
<?php doAction('index_footer'); ?>
<script charset="utf-8" src="<?php echo TEMPLATE_URL; ?>js/wnin.js"></script>
<span style="display:none;">
</span>
</body>
</html>