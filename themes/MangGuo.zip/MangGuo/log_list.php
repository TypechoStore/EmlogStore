<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div class="grid-m0s5 clearfix">
		<div class="col-main">
			<div class="main-wrap">
			<?php doAction('index_loglist_top'); ?>
				<ul class="section clearfix">
				<?php foreach($logs as $value): ?>
					<li class="post clearfix">
						<div class="review">
							<a title="热度：<?php echo $value['views']; ?>℃" href="<?php echo $value['log_url']; ?>"><?php echo $value['views']; ?>℃</a>
						</div>
						<div class="entry">
							<h2><?php topflg($value['top']); ?><a rel="bookmark" title="<?php echo $value['log_title']; ?>" href="<?php echo $value['log_url']; ?>"><font color="green"><?php echo $value['log_title']; ?></font></a></h2>
                        <ul class="tag clear">
							<?php blog_tag($value['logid']); ?>
						</ul>
							<div class="desc">编辑：<?php blog_author($value['author']); ?> <s>/</s><?php blog_sort($value['logid']); ?><s>/</s>发布于  <?php echo gmdate('Y年-n月-j日  ', $value['date']); ?> </div>
							<div class="view">
							<a href="<?php echo $value['log_url']; ?>#comments" title="已有 <?php echo $value['comnum']; ?> 条评论"><?php echo $value['comnum']; ?></a>
							</div>
						</div>
					</li>
					<div style="clear:both;"></div>
					<?php endforeach; ?>
				</ul>
				<div class="pagenavi clearfix">
				<?php echo $page_url;?></div>
			</div>
		</div>
		<div class="col-sub">
		<div class="sidebar">
			<div class="random-post">
				<div class="hd">随机推荐</div>
				<div class="bd">
					<ul class="clearfix">
						<?php widget_random_log($title); ?>
					</ul>
				</div>
			</div>
			<div class="latest-comment">
				<div class="hd">最新评论</div>
				<div class="bd">
					<ul class="clearfix">
						<?php widget_newcomm($title); ?>						
					</ul>
				</div>
			</div>
			<div class="site-link">
				<div class="permalink">
					<div class="hd">文章分类</div>
					<div class="bd">
						<ul class="clearfix">
						<?php widget_sort($title); ?>
						</ul>
					</div>
				</div>
				<div class="random-link">
					<div class="hd">文章归档</div>
					<div class="bd">
						<ul class="clearfix">
						<?php widget_archive($title); ?>
						</ul>
					</div>
				</div>
			</div>
		</div>		</div>
	</div>
	<div id="links"><ul><li>友情链接:</li>
<?php {global $CACHE; $link_cache = $CACHE->readCache('link');?>
<?php foreach($link_cache as $value): ?>
<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
<?php endforeach; ?>
<?php }?>
</ul>
</div>
<?php include View::getView('footer'); ?>