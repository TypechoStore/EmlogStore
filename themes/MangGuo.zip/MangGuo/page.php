<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="grid-m0s5 clearfix">
		<div class="col-main">
			<div class="main-wrap">
				<div class="article clearfix">
					<div class="post clearfix">
						<div class="review">
							<a href="<?php echo $value['log_url']; ?>#comments" title="共 <?php echo $comnum; ?> 条评论"><?php echo $comnum; ?></a>
						</div>
						<div class="entry">
							<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
							<div class="tag">
								<?php blog_tag($logid); ?>
							</div>
							<div class="desc">编辑：<?php blog_author($author); ?><?php editflg($logid,$author); ?><s>/</s>发布于：<?php echo gmdate('Y年-n月-j日 G时:i分 ', $date); ?> </div>
							<div class="view2">
							<!-- JiaThis Button BEGIN -->
                            <div class="jiathis_style">
                            	<a class="jiathis_button_qzone"></a>
                            	<a class="jiathis_button_tsina"></a>
                            	<a class="jiathis_button_tqq"></a>
                            	<a class="jiathis_button_renren"></a>
                            	<a class="jiathis_button_qq"></a>
                            	<a class="jiathis_button_copy"></a>
                            	<a href="http://www.jiathis.com/share" class="jiathis jiathis_txt jtico jtico_jiathis" target="_blank"></a>
                            	<a class="jiathis_counter_style"></a>
                            </div>
							<script type="text/javascript" src="http://v3.jiathis.com/code/jia.js?uid=1362210256937725" charset="utf-8"></script>
                            <!-- JiaThis Button END -->
							</div></div></div>
					<?php doAction('log_related', $logData); ?>
					<div class="text">
					<p><?php echo $log_content; ?></p>
					</div>
					<div class="comment">
						<?php blog_comments($comments); ?>
						<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
					</div></div></div></div>
		<div class="col-sub">
		<div class="sidebar">
		<!-- 这里是广告 -->
		<div class="widget"><img src="<?php echo TEMPLATE_URL; ?>css/img/ad.jpg"></div>
		<!-- 广告结束了 -->
				<div class="random-post">
				<div class="hd">随机推荐</div>
				<div class="bd">
					<ul class="clearfix">
						<?php widget_random_log($title); ?>
					</ul>
				</div>
			</div>
			<div class="latest-comment">
				<div class="hd">最新评论</div>
				<div class="bd">
					<ul class="clearfix">
						<?php widget_newcomm($title); ?>
						
					</ul>
				</div>
			</div>
			<div class="site-link">
				<div class="permalink">
					<div class="hd">文章分类</div>
					<div class="bd">
						<ul class="clearfix">
						<?php widget_sort($title); ?>
						</ul>
					</div>
				</div>
				<div class="random-link">
					<div class="hd">文章归档</div>
					<div class="bd">
						<ul class="clearfix">
						<?php widget_archive($title); ?>
						</ul>
					</div>
				</div>
			</div>
		</div></div></div></div>
<?php include View::getView('footer'); ?>