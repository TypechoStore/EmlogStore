<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="grid-m0s5 clearfix">
		<div class="col-main">
			<div class="main-wrap">
				<div class="article clearfix">
					<div class="feed-me">
						<strong>如果喜欢这篇文章，欢迎<a target="_blank" href="<?php echo BLOG_URL; ?>rss.php">订阅<?php echo $blogname; ?></a>以获得最新内容。</strong>
					</div>
					<div class="comment twitter">
						<h3><?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
					<div class="top"><a href="<?php echo BLOG_URL . 'admin/twitter.php' ?>">发布碎语</a></div>
						<?php endif; ?></h3>
						<ol class="comment-list clearfix">
					<?php 
						foreach($tws as $val):
						$author = $user_cache[$val['author']]['name'];
						$avatar = empty($user_cache[$val['author']]['avatar']) ? 
						BLOG_URL . 'admin/views/images/avatar.jpg' : 
						BLOG_URL . $user_cache[$val['author']]['avatar'];
						$tid = (int)$val['id'];
                        $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
					?> 
						<li id="comment" class="item clearfix">
						<div class="gravatar"><img width="32" height="32" class="avatar avatar-32 photo" src="<?php echo $avatar; ?>" width="32px" height="32px" /></div>
						<dl>
						<dt><em><?php echo $author; ?></em> <s>/</s><?php echo $val['date'];?></dt>
						<dd><p><?php echo $val['t'];?> <a href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">回复(<span id="rn_<?php echo $tid;?>"><?php echo $val['replynum'];?></span>)</a></p></dd>
						</dl>
						<b class="floor">言</b>
						</li>
						<ul id="r_<?php echo $tid;?>" class="r"></ul>
					<div class="huifu" id="rp_<?php echo $tid;?>">   
						<textarea id="rtext_<?php echo $tid; ?>"></textarea>
		<div class="tbutton">
        <div class="tinfo" style="display:<?php if(ROLE == 'admin' || ROLE == 'writer'){echo 'none';}?>">
        昵称：<input type="text" id="rname_<?php echo $tid; ?>" value="" />
        <span style="display:<?php if($reply_code == 'n'){echo 'none';}?>">验证码：<input type="text" id="rcode_<?php echo $tid; ?>" value="" /><?php echo $rcode; ?></span>        
        </div>
        <input class="button_p" type="button" onclick="reply('<?php echo DYNAMIC_BLOGURL; ?>index.php?action=reply',<?php echo $tid;?>);" value="回复" /> 
        <div class="msg"><span id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></span></div>
    </div>
    </div>
    </li>
    <?php endforeach;?>
	<li id="pagenavi"><?php echo $pageurl;?><span></span></li>
    </ul></ol></div></div></div></div>
		<div class="col-sub">
		<div class="sidebar">
		<!-- 这里是广告 -->
		<div class="widget"><img src="<?php echo TEMPLATE_URL; ?>css/img/ad.jpg"></div>
		<!-- 广告结束了 -->
				<div class="random-post">
				<div class="hd">随机推荐</div>
				<div class="bd">
					<ul class="clearfix">
						<?php widget_random_log($title); ?>
					</ul>
				</div>
			</div>
			<div class="latest-comment">
				<div class="hd">最新评论</div>
				<div class="bd">
					<ul class="clearfix">
						<?php widget_newcomm($title); ?>
						
					</ul>
				</div>
			</div>
			<div class="site-link">
				<div class="permalink">
					<div class="hd">文章分类</div>
					<div class="bd">
						<ul class="clearfix">
						<?php widget_sort($title); ?>
						</ul>
					</div>
				</div>
				<div class="random-link">
					<div class="hd">文章归档</div>
					<div class="bd">
						<ul class="clearfix">
						<?php widget_archive($title); ?>
						</ul>
					</div>
				</div>
			</div>
		</div></div></div></div>
<?php include View::getView('footer'); ?>