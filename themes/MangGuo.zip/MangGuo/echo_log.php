<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="grid-m0s5 clearfix">
		<div class="col-main">
			<div class="main-wrap">
				<div class="article clearfix">
					<div class="post clearfix">
						<div class="review">
							<a href="<?php echo $value['log_url']; ?>#comments" title="共 <?php echo $comnum; ?> 条评论"><?php echo $comnum; ?></a>
						</div>
						<div class="entry">
							<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
							<div class="tag">
								<?php blog_tag($logid); ?>
							</div>
							<div class="desc">编辑：<?php blog_author($author); ?><?php editflg($logid,$author); ?><s>/</s><?php blog_sort($logid); ?><s>/</s>发布于：<?php echo gmdate('Y年-n月-j日  ', $date); ?> </div>
							<div class="view2">
							<!-- JiaThis Button BEGIN -->
                            <div class="jiathis_style">
                            	<a class="jiathis_button_qzone"></a>
                            	<a class="jiathis_button_tsina"></a>
                            	<a class="jiathis_button_tqq"></a>
                            	<a class="jiathis_button_renren"></a>
                            	<a class="jiathis_button_qq"></a>
                            	<a class="jiathis_button_copy"></a>
                            	<a href="http://www.jiathis.com/share" class="jiathis jiathis_txt jtico jtico_jiathis" target="_blank"></a>
                            	<a class="jiathis_counter_style"></a>
                            </div>
							<script type="text/javascript" src="http://v3.jiathis.com/code/jia.js?uid=1362210256937725" charset="utf-8"></script>
                            <!-- JiaThis Button END -->
							</div>
						</div>
					</div>
					<div class="text">
						<p><?php echo $log_content; ?></p>
					<?php doAction('log_related', $logData); ?>
					</div>
<div class="zhuanzai">
    <h3>本文由“<a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>"><?php echo $blogname; ?></a> &gt; <?php blog_author($author); ?>”整理编辑，若未标明内容为原创,则不用对其真实性负责</h3>
    页面标题：[ <a href="<?php echo Url::log($logid); ?>"title="<?php echo $log_title;?>"><?php echo $log_title;?></a> - <?php echo $blogname; ?> ]<br>
    <span>本文网址：</span><input id="this_url" type="text" value="<?php echo Url::log($logid); ?>"><input type="button" value="复制" onclick="copyurl('this_url');"><br>
	<h3>网站内容默认可进行非商业转载,转载者须保证文章的内容完整性和添加本站版权说明！</h3>
</div>
					<div class="sibling-posts">
						<?php neighbor_log($neighborLog); ?>
					</div>
					<div class="feed-me">
						<strong>如果喜欢这篇文章，欢迎<a href="<?php echo BLOG_URL; ?>rss.php" target="_blank">订阅<?php echo $blogname; ?></a>以获得最新内容。</strong>
					</div>
					<div class="comment">
						<h3>已经有 <?php echo $comnum; ?> 条群众意见</h3>
						<?php blog_comments($comments); ?>
						<h3>下面我简单说几句</h3>
						<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
					</div></div></div></div>
		<div class="col-sub">
		<div class="sidebar">
		<!-- 这里是广告 -->
		<div class="widget"><img src="<?php echo TEMPLATE_URL; ?>images/ad.jpg"></div>
		<!-- 广告结束了 -->
				<div class="random-post">
				<div class="hd">随机推荐</div>
				<div class="bd">
					<ul class="clearfix">
						<?php widget_random_log($title); ?>
					</ul>
				</div>
			</div>
			<div class="latest-comment">
				<div class="hd">最新评论</div>
				<div class="bd">
					<ul class="clearfix">
						<?php widget_newcomm($title); ?>
						
					</ul>
				</div>
			</div>
			<div class="site-link">
				<div class="permalink">
					<div class="hd">文章分类</div>
					<div class="bd">
						<ul class="clearfix">
						<?php widget_sort($title); ?>
						</ul>
					</div>
				</div>
				<div class="random-link">
					<div class="hd">文章归档</div>
					<div class="bd">
						<ul class="clearfix">
						<?php widget_archive($title); ?>
						</ul>
					</div>
				</div>
			</div>
		</div></div></div></div>
<?php include View::getView('footer'); ?>