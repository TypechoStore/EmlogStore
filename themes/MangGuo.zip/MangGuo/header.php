<?php
/*
Template Name:MangGuo
Description:MangGuo
Version:1.0
Author:wnin
Author Url:http://www.wnin.cn
Sidebar Amount:1
ForEmlog:5.0.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>main.css">
<style>
.header, .content, .footer {
	width: 990px;
}
</style>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div class="header">
	<h1 class="logo"><a href="<?php echo BLOG_URL; ?>">" title="<?php echo $blogname; ?></a></h1>
	<ul class="quick-menu clearfix">
		<li><span>成功的法则极为简单,但简单并不代表容易!</span></li>
		<li class="subscribe"><a href="<?php echo BLOG_URL; ?>rss.php" target="_blank">RSS订阅</a></li>
		<li class="random"><a href="<?php echo BLOG_URL; ?>t/">碎语</a></li>
	</ul>
</div>
<div class="content">
	<div id="slide" class="slide">
		<ol class="slide-content">
			<li style="display:block;">
				<h3><a target="_blank" href="#">emlog 是 every memory log 的简称</a></h3>
				<p>致力于为您提供快速、稳定，且在使用上又极其简单、舒适的内容创作及站点搭建服务。</p>
				<p><a target="_blank" href="#">猛击这里查看</a></p>
			</li>
			<li style="display:none;">
				<h3><a target="_blank" href="#">emlog 是 every memory log 的简称</a></h3>
				<p>致力于为您提供快速、稳定，且在使用上又极其简单、舒适的内容创作及站点搭建服务。</p>
				<p><a target="_blank" href="#">猛击这里查看</a></p>
			</li>
			<li style="display:none;">
				<h3><a target="_blank" href="#">emlog 是 every memory log 的简称</a></h3>
				<p>致力于为您提供快速、稳定，且在使用上又极其简单、舒适的内容创作及站点搭建服务。</p>
				<p><a target="_blank" href="#">猛击这里查看</a></p>
			</li>
		</ol>
		<ul class="slide-nav clearfix">
			<li class="active">1</li>
			<li>2</li>
			<li>3</li>
		</ul>
		<span class="prev"></span>
		<span class="next"></span>
	</div>
	<div id="slide-toggle" class="slide-toggle clearfix">
		<span class="toggle">切换到精简模式</span>
	</div>
	<div class="search">
		<div class="message"><b><?php echo $blogname; ?></b>：<?php echo $bloginfo; ?></div>
		<form action="<?php echo BLOG_URL; ?>" method="get" class="searchform clearfix">
			<span class="s">
			<input type="text" name="keyword" id="s" onblur="if(this.value =='')this.value='写上关键词...按“回车”搜索';"
					onfocus="this.value='';"
					onclick="if(this.value=='写上关键词...按“回车”搜索')this.value=''"
					value="写上关键词...按“回车”搜索" /></span>
			<span class="searchsubmit"><button type="submit"></button></span>
		</form>
	</div>	<div class="tab">
		<ul class="clearfix">
			<?php blog_navi();?>
	</div>
	<div class="outline">
		<div class="text-links">
        <a href="http://jifen.2345.com/?i5896130" title="2345王牌技术员联盟" style="color:dodgerblue;" rel="nofollow" target="_blank">亲,免费加入2345技术员联盟,终身领工资</a><s>/</s>
		<a href="http://chrome.2345.com/freecall/?k248845" title="2345加速浏览器" style="color:orange;" rel="nofollow" target="_blank">2345加速浏览器,可以免费打电话的极速浏览器</a><s>/</s>
		<a href="http://www.kusu.asia/" title="酷速网" style="color:green;" rel="nofollow" target="_blank">酷速博客 - 志不强者智不达</a><s>/</s>
		<a href="http://www.90qh.com/huodong/youhuima.asp" title="免费PHP,ASP空间" style="color:red;" rel="nofollow" target="_blank">无须任务费用,立刻获得1000M香港免备案空间</a>
		</div>
		<div class="clearfix">
			<ul class="category-list clearfix">
			<?php widget_tag($title); ?>
			</ul>
			<div class="counter"><a href="#"><b><?php echo $blogname; ?></b></a></div>
		</div>
	</div>