<?php 
/**
 * banner页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="info">
    <figure> <img src="<?php echo TEMPLATE_URL; ?>images/art.jpg"  alt="Panama Hat">
      <figcaption><strong>渡人如渡己，渡已，亦是渡</strong> 当我们被误解时，会花很多时间去辩白。 但没有用，没人愿意听，大家习惯按自己的所闻、理解做出判别，每个人其实都很固执。与其努力且痛苦的试图扭转别人的评判，不如默默承受，给大家多一点时间和空间去了解。而我们省下辩解的功夫，去实现自身更久远的人生价值。其实，渡人如渡己，渡已，亦是渡人。</figcaption>
    </figure>
    <div class="card">
      <h1>我的名片</h1>
      <p>网名：似醉人心 | 黑色星期天</p>
      <p>职业：电子工程师、网页设计</p>
      <p>Q  Q：821266862</p>
      <p>Email：chenziwen@lantk.com</p>
      <ul class="linkmore">
        <li><a href="<?php echo BLOG_URL; ?>" class="talk" title="给我留言"></a></li>
        <li><a href="<?php echo BLOG_URL; ?>" class="address" title="联系地址"></a></li>
        <li><a href="<?php echo BLOG_URL; ?>" class="email" title="给我写信"></a></li>
        <li><a href="<?php echo BLOG_URL; ?>" class="photos" title="生活照片"></a></li>
        <li><a href="<?php echo BLOG_URL; ?>" class="heart" title="关注我"></a></li>
      </ul>
    </div>
  </div>
  <!--info 结束-->
