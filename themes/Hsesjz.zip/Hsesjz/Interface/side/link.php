<?php 
/**
 * 侧边栏友情链接
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
      <div class="clicks">
      <?php links("友情链接");?>
	  </div>