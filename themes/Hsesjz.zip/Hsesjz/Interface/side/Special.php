<?php 
/**
 * 侧边栏分类专栏模块
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
 <div class="tuijian">
        <h2>EMLOG专栏</h2>
        <ol>
        <?php get_list('1');?>
        </ol>
      </div>