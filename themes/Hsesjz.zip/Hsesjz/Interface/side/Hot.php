<?php 
/**
 * 侧边栏热门点击
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
      <div class="clicks">
      <?php widget_hotlog("热门点击");?>
	  </div>