<?php 
/**
 * 侧边栏首页置顶模块
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
      <div class="toppic">
        <h2>首页置顶</h2>
        <ul>
<?php index_show();?>
        </ul>
      </div>
