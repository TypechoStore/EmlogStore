<?php 
/**
 * 侧边栏CD专辑
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
      <div class="viny">
        <dl>
          <dt class="art"><img alt="专辑" src="<?php echo TEMPLATE_URL; ?>images/artwork.png"></dt>
          <dd class="icon-song"><span></span>南方姑娘</dd>
          <dd class="icon-artist"><span></span>歌手：赵雷</dd>
          <dd class="icon-album"><span></span>所属专辑：《赵小雷》</dd>
          <dd class="icon-like"><span></span><a href="/">喜欢</a></dd>
          <dd class="music">
            <audio controls="" src="<?php echo TEMPLATE_URL; ?>images/nf.mp3"></audio>
          </dd>
        </dl>
      </div>