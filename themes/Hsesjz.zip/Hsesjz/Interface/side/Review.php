<?php 
/**
 * 侧边栏最新评论，可选择多说评论和系统自带评论
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
   <div class="clicks">
<?php widget_newcomm("最新评论");?>
</div>