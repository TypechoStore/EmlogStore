<?php 
/*
自定义404页面
Template Name:流年、酷V2014
Description:流年、酷，酷炫
Version:V1.0
Author:缪汶臻
Author Url:http://www.ln920.cn
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>站长温馨提示404ERROR-PAGE NOT FOUND-<?php echo BLOG_URL; ?></title>
<style type="text/css">
body {background-color:#fff;font-family: "微软雅黑",Tahoma,Arial;font-size:12px;}
.main {font-size: 12px;	color: #666666;width:512px;height:312px;margin:0 auto;*padding:150px 0 0 220px;list-style:none;*background-image: url(<?php echo TEMPLATE_URL; ?>404.gif);background-repeat: no-repeat;}
.main p {font-size:16px;text-align:center;}
.main img{float:right;}
.main p a {text-decoration: none;font-size: 16px;color: red;}
.main p a:hover{color: #0099FF;}
</style>
</head>
<body>
<div class="main">
<p><img src="<?php echo TEMPLATE_URL; ?>4041.gif" width="520" height="320" /></p>
<p>非常抱歉，你所请求的页面被外星人绑架了！</p>
<p>此页您输入的网址错误了，您可以点击以下链接进行相关操作。</p>
<p><a href="javascript:history.back(-1);" title="返回上一页">点击返回</a> <a href="<?php echo BLOG_URL; ?>" title="进入首页">网站首页</a></p>
</div>
<!-- zp520.cn Baidu tongji analytics -->
<script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F33ad4d18dda1a56ff80f8eb07aeac69b' type='text/javascript'%3E%3C/script%3E"));
</script>
</body>
</html>