	<?php 
/**
阅读文章页面
Template Name:流年、酷V2014
Description:流年、酷，酷炫
Version:V1.0
Author:缪汶臻
Author Url:http://www.ln920.cn
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<script type="text/javascript">
function fontResizer(smallFont,medFont,largeFont){
	
	function clearSelected(){
		$(".smallFont").removeClass("curFont");
		$(".medFont").removeClass("curFont");
		$(".largeFont").removeClass("curFont");
	}
	
	function saveState(curSize){
		var date = new Date();
		date.setTime(date.getTime()+(7*24*60*60*1000));
		var expires = "; expires="+date.toGMTString();
		document.cookie = "fontSizer"+"="+curSize+expires+"; path=/";
	}

	$(".smallFont").click(function(){
		$('.fontsizebox').css('font-size', smallFont);
		clearSelected();
		$(".smallFont").addClass("curFont");
		saveState(smallFont);
	});

	$(".medFont").click(function(){
		$('.fontsizebox').css('font-size', medFont);
		clearSelected();
		$(".medFont").addClass("curFont");
		saveState(medFont);
	});

	$(".largeFont").click(function(){
		$('.fontsizebox').css('font-size', largeFont);
		clearSelected();
		$(".largeFont").addClass("curFont");
		saveState(largeFont);
	});

	function getCookie(c_name){
		if(document.cookie.length>0){
			c_start=document.cookie.indexOf(c_name + "=");
			if (c_start!=-1){
				c_start=c_start + c_name.length+1;
				c_end=document.cookie.indexOf(";",c_start); 
				if(c_end==-1)c_end=document.cookie.length;
				return unescape(document.cookie.substring(c_start,c_end));
			}
		} 
		return "";
	}

	var savedSize = getCookie('fontSizer');

	if(savedSize!=""){
		$('.fontsizebox').css('font-size', savedSize);
		switch(savedSize){
			case smallFont: $(".smallFont").addClass("curFont");
			break;
			case medFont: $(".medFont").addClass("curFont");
			break;
			case largeFont: $(".largeFont").addClass("curFont");
			break;
			default: $(".medFont").addClass("curFont");
		}
	}else {
		$('.fontsizebox').css('font-size', medFont);
		$(".medFont").addClass("curFont");
	}
	
}
</script>

<script type="text/javascript">
$(document).ready(function() {
	fontResizer('12px','14px','20px');
});
</script>
<style type="text/css">
/* fontsizebox */
.fontsizebox p{line-height:22px;margin:20px 0 0 0;text-indent:2em;}
/* fontResizer */
.fontResizer{margin:10px 0;height:24px;}
.fontResizer a{display:block;float:left;width:17px;height:17px;text-align:center;border:1px solid #ccc;line-height:17px;color:#666;text-decoration:none;}
.fontResizer a:hover{color:#000;text-decoration:none;}
.smallFont{font-size:10px;}
.medFont{font-size:12px;}
.largeFont{font-size:14px;}
.curFont{background:#EEEEF7;}
</style>
	<!-- layout-container -->
	<div id="layout" class="clearfix sidebar1 sidebar-left">
	<!-- content -->
		<div id="content" class="list-post">
<div id="post-472" class="post-472 post type-post status-publish format-standard hentry category-wordpress category-skill category-single category-mv category-tools category-mood category-amuse category-movie category-society category-word category-vision category-music tag-html5 tag-wordpress clearfix">
<div class="post-content">
					<p class="post-date">
				<span class="month"><a style="display: block;margin-left: -20px;"><?php echo gmdate('n', $date); ?></a></span>
				<span class="day"><?php echo gmdate('j', $date); ?></span>
				<span class="year"><?php echo gmdate('Y', $date); ?></span>
			</p><h1 class="post-title"><a href="<?php echo $value['log_url']; ?>"><?php echo $log_title; ?></a></h1>
	<div class="fontResizer">
		<a href="javascript:void(0);" class="smallFont">小</a><a href="javascript:void(0);" class="medFont">中</a><a href="javascript:void(0);" class="largeFont">大</a>
	</div>
            <div id="contentleft" class="fontsizebox" style="width:auto;"><?php echo $log_content; ?><p><?php doAction('log_related', $logData); ?></p></div>
					<p class="post-meta"> 
				<span class="post-author">作者： <?php blog_author($author); ?>  &bull;</span>
				<span class="post-author">时间： <?php echo gmdate('Y-n-j', $date); ?>   &bull;</span>
				<span class="post-author">浏览： <?php echo $views; ?>   &bull;</span>			
				<span class="post-category">分类：<a href="" rel="category tag"><?php blog_sort($value['logid']); ?> </a></span>
				<span class="post-category"><?php blog_sort($logid); ?>  &bull;</span>
								 <span class="post-tag">标签: <?php blog_tag($value['logid']); ?></span>	
								 <span class="post-author">&bull;<?php editflg($logid,$author); ?></span>
								 </p>
		    
		
	</div>
	<!-- /.post-content -->		
	
</div>
<!--/post -->	
<div class="loc_link"><ul>
 <li>欢迎访问 <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>，本站致力于与您共同成长。如果有任何疑问欢迎与我联系</li>
<li>本文固定链接: <a href="<?php echo Url::log($logid);?>"><?php echo Url::log($logid);?></a></li>
<li>转载请注明: : <?php blog_author($author); ?> <?php echo gmdate('Y年n月j日', $date); ?> 于 <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a> 发表</li>

</ul>
</div>	
 <br><?php neighbor_log($neighborLog); ?>
  <br>
<div class="relatedposts"><h3 class="widget-title"><i class="icon-warning-sign"></i> 您可能还会对这些文章感兴趣！</h3><ul>
<?php if ($ganxq == "yes"): ?>
<?php related_logs($logData);?> 
<?php else: ?>	
<?php $index_hotlognum = Option::get('index_hotlognum');	$Log_Model = new Log_Model();	$randLogs = $Log_Model->getHotLog(8);?> <?php foreach($randLogs as $value): ?><li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
<?php endforeach; ?>
<?php endif; ?>
</ul></div> 
<br />

<!-- Baidu Button BEGIN -->
<div id="bdshare" style="
    margin-left: 150px;
    float: left;
" class="bdsharebuttonbox bdshare-button-style" ><a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a> <a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a> <a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a> <a href="#" class="bds_sqq" data-cmd="sqq" title="分享到QQ好友"></a> <a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a> <a href="#" class="bds_fbook" data-cmd="fbook" title="分享到Facebook"></a> <a href="#" class="bds_twi" data-cmd="twi" title="分享到Twitter"></a> <a href="#" class="bds_more" data-cmd="more"></a></div><br /><script>
window._bd_share_config = {
	"common": {
		"bdSnsKey": {
			"tsina": "271055334",
			"tqq": "mwz747512353"
		},
		"bdText": "",
		"bdMini": "2",
		"bdMiniList": false,
		"bdPic": "",
		"bdStyle": "0",
		"bdSize": "32"
	},
	"share": {},
	"image": {
		
	},
	
};

with(document) 0[(getElementsByTagName('head')[0] || body).appendChild(createElement('script')).src = 'http://bdimg.share.baidu.com/static/api/js/share.js?v=86835285.js?cdnversion=' + ~ (-new Date() / 36e5)];
</script>
<!-- Baidu Button END -->
 <div id="comments" class="commentwrap">
   <h4 class="comment-title">	网友评论(<?php echo $comnum;?>)</h4>   <ol class="commentlist ">
<?php blog_comments($comments,$comnum); ?>
</div>

<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>		</ol>
</div>	
<!-- /.commentwrap -->	 
		  <?php
 include View::getView('side');
 include View::getView('footer');
?>