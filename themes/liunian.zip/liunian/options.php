<?php

/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
	'happy_new' => array(
		'type' => 'radio',
		'name' => '开启下雪代码',
		'values' => array(
            'yes' => '开启',
            'no' => '关闭',
        ),
		'default' => 'no',
	),
	'fuzhi'=> array(
	'type'=> 'radio',
	'name'=> '开启全站复制加版权',
	'values' => array(
            'yes' => '开启',
            'no' => '关闭',
        ),
		'default' => 'no',
	),
	'tishi'=> array(
	'type'=> 'radio',
	'name'=>'开启全站链接浮动提示',
	'values' => array(
            'yes' => '开启',
            'no' => '关闭',
        ),
		'default' => 'no',
	),
'newyear' => array(
		'type' => 'radio',
		'name' => '更换背景',
		'values' => array(
            'no' => '默认',
            'red' => '红色',
			'ka'=>'卡通',
			'wan'=>'万圣',
			'yi'=>'一年级',
			'green'=>'护眼绿',
			'feng'=>'护眼粉',
			'nv'=>'日本女人',
        ),
		'default' => 'no',
	),
'zhiding'=>array(
'type'=>'radio',
'name'=>'置顶文章是否隐藏',
'values'=>array(
'yes'=>'不隐藏',
'no'=>'隐藏',
),
'default'=>'yes',
),
'zhiding_num'=>array(
'type'=>'radio',
'name'=>'置顶显示条数',
'values'=>array(
'2'=>'两条',
'3'=>'三条'
),
'default'=>'2',
),
'tongji'=>array(
     'type'=>'radio',
	 'name'=>'是否开启站点统计',
	 'values'=>array(
	     'yes'=>'是',
		 'no'=>'否',
	 ),
	 'default'=>array(
	 'yes',
	 ),
),
'yes'=>array(
'type'=>'text',
'name'=>'建站时间',
'description'=>'请输入网站建站时间',
'default'=>'2014-08-20',
),
'tougao'=>array(
     'type'=>'radio',
	 'name'=>'是否开启匿名投稿',
	 'description'=>'开启需要安装匿名投稿插件：http://www.emlog.net/store/plugin/181下载安装',
	 'values'=>array(
	     'yestougao'=>'是',
		 'notougao'=>'否',
	 ),
	 'default'=>array(
	 'yestougao',
	 ),
),
'yestougao'=>array(
'type'=>'text',
'name'=>'匿名投稿链接',
'description'=>'请输入您的匿名投稿链接',
'default'=>'http://www.ln920.cn/?plugin=qiukong_submit',
),
'tool' => array(
		'type' => 'checkbox',
		'name' => '左边联系站长/关于本站/其他/RSS',
		'values' => array(
			'liunianQQ' => '联系站长',
			'about' => '关于本站',
			'contact' => '其他',
			'other' => 'RSS',
				),
		'default' => array(
			'liunianQQ',
		),
	),
		'liunianQQ' => array(
		'type' => 'text',
		'name' => '联系站长',
		'description' => '站长qq号码',
		'default' => '747512353',
	),
		'about' => array(
		'type' => 'text',
		'name' => '关于本站',
		'description' => '在页面管理新建一个关于页面，地址填写到这里',
		'default' => 'http://www.ln920.cn/3.html',
	),
	    'contact' => array(
		'type' => 'text',
		'name' => '其他',
		'description' => '在页面管理新建一个其他页面，地址填写到这里',
		'default' => 'http://www.ln920.cn/love/',
	),
		'other' => array(
		'type' => 'text',
		'name' => 'RSS',
		'description' => '填写站点RSS地址',
		'default' => 'http://www.ln920.cn/rss.php',
	),
'jianjie' => array(
		'type' => 'radio',
		'name' => '是否开启个人简介',
		'values' => array(
			'yes' => '是',
			'no' => '否',
				),
		'default' => 'yes',
		),
		'wname' => array(
		'type' => 'text',
		'name' => '网名',
		'default' => 'zzhen | 臻臻',
	),
		'name' => array(
		'type' => 'text',
		'name' => '姓名',
		'default' => '缪汶臻',
	),
	    'jiguan' => array(
		'type' => 'text',
		'name' => '籍贯',
		'default' => '甘肃省—白银市—景泰县',
	),
		'address' => array(
		'type' => 'text',
		'name' => '现居',
		'default' => '兰州市—城关区',
	),
	    'zhiye' => array(
		'type' => 'text',
		'name' => '职业',
		'default' => 'PHP程序猿、网站制作',
	),
		'book' => array(
		'type' => 'text',
		'name' => '喜欢的书',
		'default' => '细说php',
	),
	'music' => array(
		'type' => 'text',
		'name' => '喜欢的音乐',
		'default' => '你是我的眼',
	),
		'qqq' => array(
		'type' => 'text',
		'name' => 'QQ群',
		'description' => '在http://qun.qq.com/join.html页面复制群idkey',
		'default' => 'ec91fd07999c64cead4129ee3bc85313d2a15afd63fd87b5572df238bb1110da',
	),
		'qqjt' => array(
		'type' => 'text',
		'name' => 'QQ交谈',
		'description' => '在http://shang.qq.com/v3/widget.html页面复制idkey',
		'default' => '2c960122dc0be924d44f16c1c2c54811e62d18a56e94eb5f',
	),
 'blog_name'=>array(
 'type'=>'text',
 'name'=>'网站脚部名称',
 'description'=>'用于网站footer的站点名称显示',
 'default'=>'缪汶臻个人博客 ZP520.CN',
 ),
 'foot_liunian'=>array(
    'type'=>'text',
	'name'=>'网站底部信息',
	'description'=>'修改网站底部的信息,支持html代码',
	'default'=>'版权声明：凡注明本站原创文章、作品，未经本人许可，任何人或机构不得以任何形式对本站内容进行复制作商业用途.<br />本站部分文章、资源来自互联网，版权归原作者及网站所有，如果侵犯了您的权利，请及时致信告知我站.<br />• <a href="../sitemap.xml" title="百度地图" target="_blank">百度地图</a> • <a href="../rss.php" title="站点地图" target="_blank">站点地图</a>',
 ),
     'icp_liunian'=>array(
	 'type'=>'radio',
     'name'=>'是否开启icp备案信息',
	 'description'=>'如果开启，请在后台设置里面填写备案号信息',
	 'values'=>array(
	 'yes'=>'开启',
	 'no'=>'不开启',
	 ),
	 'default' => 'yes',
	 ),
'liunian_bq'=>array(
'type'=>'radio',
'name'=>'作者版权',
'description'=>'为了作者持续更新模板,请选择下面版权信息',
'values'=>array(
'url_y'=>'显示作者链接版权',
'url_n'=>'只显示文字版权',
),
'default'=>'url_y',
),
'footer_side'=>array(
'type'=>'radio',
'name'=>'是否开启右下角快捷菜单',
'values'=>array(
'yes'=>'开启',
'no'=>'不开启',
),
'default'=>'yes',
),
'side_weixin'=>array(
'type'=>'image',
'name'=>'快捷菜单微信图片',
'description'=>'图片大小138*138',
 'values' => array(
            BLOG_URL . 'content/uploadfile/tpl_options//side_weixin.jpg',
        ),
),
'side_weibo'=>array(
'type'=>'text',
'name'=>'输入微博账号',
'description'=>'请进入微博复制http://weibo.com/后面的一串数字',
'default'=>'271055334',
),
'side_email'=>array(
'type'=>'text',
'name'=>'输入Email',
'default'=>'admin@zp520.cn',
),
);