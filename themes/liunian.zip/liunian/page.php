<?php 
/**
自建页面模板
Template Name:流年、酷V2014
Description:流年、酷，酷炫
Version:V1.0
Author:缪汶臻
Author Url:http://www.ln920.cn
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="layout" class="clearfix sidebar1 sidebar-left">
	<!-- content -->
		<div id="content" class="list-post">
<div id="post-472" class="post-472 post type-post status-publish format-standard hentry category-wordpress category-skill category-single category-mv category-tools category-mood category-amuse category-movie category-society category-word category-vision category-music tag-html5 tag-wordpress clearfix">
<div class="post-content">
            <p style="width:600px;float:left;"><?php echo $log_content; ?></P>
 <div id="comments" class="commentwrap">
   <h4 class="comment-title">	网友评论(<?php echo $comnum;?>)</h4>   <ol class="commentlist ">
<?php blog_comments($comments,$comnum); ?>
</div>

<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>		</ol>
</div>	
<!-- /.commentwrap -->
</div>
</div>

		  <?php
 include View::getView('side');
 include View::getView('footer');
?>