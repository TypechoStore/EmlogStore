//侧栏固定跟随
//(function(){
//	var oDiv=document.getElementById("myfloat");
//	var H=0,iE6;
//	var Y=oDiv;
//	while(Y){H+=Y.offsetTop;Y=Y.offsetParent};
//	iE6=window.ActiveXObject&&!window.XMLHttpRequest;
//	if(!iE6){
//		window.onscroll=function()
//		{
//			var s=document.body.scrollTop||document.documentElement.scrollTop;
//			if(s>H){oDiv.className="gddiv1 gddiv2";if(iE6){oDiv.style.top=(s-H)+"px";}}
//			else{oDiv.className="gddiv1";}	
//
//		};
//	}
//})();


//侧栏滑动跟随
var documentHeight = 0;

if($.browser.msie && ($.browser.version=="7.0" || $.browser.version=="6.0")){var topPadding = 187;absolute=fixed; }
else{var topPadding = -10;absolute=fixed; }

$(function() {   
    var offset = $("#myfloat").offset();   
    documentHeight = $(document).height();   
    $(window).scroll(function() {   
        var sideBarHeight = $("#myfloat").height();   
        if ($(window).scrollTop() > offset.top) {   
            var newPosition = ($(window).scrollTop() - offset.top) + topPadding;   
            var maxPosition = documentHeight - (sideBarHeight - 0);   
            if (newPosition > maxPosition) {   
                newPosition = maxPosition;   
            }   
            $("#myfloat").stop().animate({   
                marginTop: newPosition   
            });   
        } else {   
            $("#myfloat").stop().animate({   
                marginTop: 0   
            });   
        };   
    });   
});   




//返回顶部底部
$(document).ready(function(){
	$('#roll').hide();
	$(window).scroll(function() {
		if($(window).scrollTop() >= 100){
			$('#roll').fadeIn(400);
    }
    else
    {
    $('#roll').fadeOut(200);
    }
  });
  $('#roll_top').click(function(){$('html,body').animate({scrollTop: '0px'}, 800);});
  $('#fall').click(function(){$('html,body').animate({scrollTop:$('#footer').offset().top}, 800);});
});

//超链接去掉点击时边框虚线
$(document).ready(
　　function(){
　　 　$("a").bind("focus",function(){if(this.blur)this.blur();});
　　});

