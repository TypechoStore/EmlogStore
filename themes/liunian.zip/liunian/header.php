<?php
/*
Template Name:流年、酷™2014贺岁版
Description:流年、酷
Version:V1.0
Author:缪汶臻
Author Url:http://www.ln920.cn
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
extract(_g());
require_once View::getView('module');
if(!defined('MWZ')){exit('error!');}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<title><?php echo $site_title; ?></title>

<meta name="keywords"  content="<?php echo $site_key; ?>" />
<meta name="description"  content="<?php echo $site_description; ?>">
<link rel="alternate" type="application/rss+xml" title="<?php echo $site_title; ?> RSS Feed" href="<?php echo BLOG_URL; ?>rss.php">
<!-- liunian_header -->
<link rel="alternate" type="application/rss+xml" title="<?php echo $site_title; ?> &raquo; Feed" href="<?php echo BLOG_URL; ?>sitemap.xml" />
<link rel="alternate" type="application/rss+xml" title="<?php echo $site_title; ?> &raquo; 评论Feed" href="<?php echo BLOG_URL; ?>sitemap.xml" />
<link rel='stylesheet' id='themify-shortcodes-css'  href='<?php echo TEMPLATE_URL; ?>content/themes/Shknn/themify/css/shortcodes.css?ver=1.2.2' type='text/css' media='all' />
<link rel='stylesheet' id='themify-styles-css'  href='<?php echo TEMPLATE_URL; ?>content/themes/Shknn/style.css?ver=5.4' type='text/css' media='all' />
<link rel='stylesheet' id='themify-media-queries-css'  href='<?php echo TEMPLATE_URL; ?>content/themes/Shknn/media-queries.css?ver=5.2' type='text/css' media='all' />
<link rel='stylesheet' id='pretty-photo-css'  href='<?php echo TEMPLATE_URL; ?>content/themes/Shknn/prettyPhoto.css?ver=4.1' type='text/css' media='all' />
<link rel='stylesheet' id='lightboxStyle-css'  href='<?php echo TEMPLATE_URL; ?>content/plugins/lightbox-plus/css/elegant-white/colorbox.css?ver=2.8' type='text/css' media='screen' />
<style type="text/css">
<?php if(_g('newyear') == 'no'): ?>
body {
	background: #0d1424 url(<?php echo TEMPLATE_URL; ?>content/themes/Shknn/images/body-bg.png) repeat center top;
	font: .81em/150%  "Microsoft YaHei","΢���ź�","Lucida Grande", Arial, "Lucida Sans Unicode", sans-serif;
	color: #070707;
}
<?php else: ?>	
<?php endif; ?>
<?php if(_g('newyear') == 'red'): ?>
body {
	background: #0d1424 url(<?php echo TEMPLATE_URL; ?>content/themes/Shknn/images/redbg.jpg) repeat center top;
	font: .81em/150%  "Microsoft YaHei","΢���ź�","Lucida Grande", Arial, "Lucida Sans Unicode", sans-serif;
	color: #070707;
}
<?php else: ?>	
<?php endif; ?>
<?php if(_g('newyear') == 'ka'): ?>
body {
	background: #FFFFFF url(<?php echo TEMPLATE_URL; ?>content/themes/Shknn/images/1fd02762001ea134c86ff9f1d376f966.jpg) repeat center top;
	background-attachment: fixed; 
	font: .81em/150%  "Microsoft YaHei","΢���ź�","Lucida Grande", Arial, "Lucida Sans Unicode", sans-serif;
	color: #070707;
}
<?php else: ?>	
<?php endif; ?>
<?php if(_g('newyear') == 'wan'): ?>
body {
	background: #0d1424 url(<?php echo TEMPLATE_URL; ?>content/themes/Shknn/images/991b7cf57ffd99024526809bb9364003.jpg) repeat center top;
	background-attachment: fixed; 
	font: .81em/150%  "Microsoft YaHei","΢���ź�","Lucida Grande", Arial, "Lucida Sans Unicode", sans-serif;
	color: #070707;
}
<?php else: ?>	
<?php endif; ?>
<?php if(_g('newyear') == 'yi'): ?>
body {
	background: #0d1424 url(<?php echo TEMPLATE_URL; ?>content/themes/Shknn/images/ca8892679d9df053c87e493f33771503.jpg) repeat center top;
	background-attachment: fixed; 
	font: .81em/150%  "Microsoft YaHei","΢���ź�","Lucida Grande", Arial, "Lucida Sans Unicode", sans-serif;
	color: #070707;
}
<?php else: ?>	
<?php endif; ?>
<?php if(_g('newyear') == 'green'): ?>
body {
	background: #BDEBCB url(<?php echo TEMPLATE_URL; ?>content/themes/Shknn/images/theme-green.jpg) repeat-x center top;
	background-attachment: fixed; 
	font: .81em/150%  "Microsoft YaHei","΢���ź�","Lucida Grande", Arial, "Lucida Sans Unicode", sans-serif;
	color: #070707;
}
<?php else: ?>	
<?php endif; ?>
<?php if(_g('newyear') == 'feng'): ?>
body {
	background: #FDF5F9 url(<?php echo TEMPLATE_URL; ?>content/themes/Shknn/images/theme_top_w.jpg) repeat center top;
	background-attachment: fixed; 
	font: .81em/150%  "Microsoft YaHei","΢���ź�","Lucida Grande", Arial, "Lucida Sans Unicode", sans-serif;
	color: #070707;
}
<?php else: ?>	
<?php endif; ?>
<?php if(_g('newyear') == 'nv'): ?>
body {
	background: #FFFFFF url(<?php echo TEMPLATE_URL; ?>content/themes/Shknn/images/theme_w.jpg) repeat-x center top;
	background-attachment: fixed; 
	font: .81em/150%  "Microsoft YaHei","΢���ź�","Lucida Grande", Arial, "Lucida Sans Unicode", sans-serif;
	color: #070707;
}
<?php else: ?>	
<?php endif; ?>
</style>
<style type="text/css">
#site-description {
color: #ffffff;
font-weight: normal;
font-style: normal;
position: absolute;
top: 98px;
left: 303px;
}
</style>
<!--[if lt IE 9]>
<script src='<?php echo TEMPLATE_URL; ?>content/themes/Shknn/js/jquery-1.10.1.min.js?ver=1.11.3'></script>
<![endif]-->
<!--[if gte IE 9]>
<script src='<?php echo TEMPLATE_URL; ?>content/themes/Shknn/js/jquery-2.0.3.min.js?ver=1.11.3'></script>
<![endif]-->
<script type='text/javascript'src='<?php echo TEMPLATE_URL; ?>content/themes/Shknn/js/jquery-1.10.1.min.js?ver=1.11.3'></script>

<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>content/themes/Shknn/js/jquery.js?ver=1.11.4'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>content/themes/Shknn/js/respond.js?ver=4.4'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>content/themes/Shknn/js/jquery.prettyPhoto.js?ver=4.3'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>content/themes/Shknn/js/carousel.min.js?ver=4.2'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>content/themes/Shknn/js/themify.script.js?ver=4.2'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>content/themes/Shknn/js/jquery.colorbox.1.5.9.js?ver=1.6.0'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>content/themes/Shknn/js/logger.js?ver=1.5.9'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>content/themes/Shknn/js/face.js?ver=1.5.9'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>content/themes/Shknn/js/jquery.slimbox.js?ver=1.11.4'></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>includes/js/jquery/jquery.lazyload.js"></script>
<?php if(_g('fuzhi') == "yes"): ?>
<script type="text/javascript">
function addLink() {
    var body_element = document.getElementsByTagName('body')[0];
    var selection;
    selection = window.getSelection();
    var pagelink = "<br /><br />本文于<?php echo date("Y-m-d H:i:s");?>转载于<?php echo $blogname; ?>, 原文链接<a href='"+document.location.href+"'>"+document.location.href+"</a>";
    var copy_text = selection + pagelink;
    var new_div = document.createElement('div');
    new_div.style.left='-99999px';
    new_div.style.position='absolute';
    body_element.appendChild(new_div );
    new_div.innerHTML = copy_text ;
    selection.selectAllChildren(new_div );
    window.setTimeout(function() {
        body_element.removeChild(new_div );
    },0);
}
document.oncopy = addLink;
</script>
<?php else: ?>
<?php endif; ?>
<?php if(_g('tishi') == "yes"): ?>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>content/themes/Shknn/js/tishi.js?ver=1.5.9'></script>
<?php else: ?>
<?php endif; ?>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>sitemap.xml" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>sitemap.xml" /> 

<meta name="generator" content="liunianku 4.0" />
<!-- Open Graph Tags -->
<meta property="og:site_name" content="<?php echo $site_key; ?>" />
<meta property="og:type" content="website" />
<meta property="og:description" content="<?php echo $site_description; ?>" />
<meta property="og:url" content="<?php echo Url::log($logid);?>" />
<!-- End Open Graph Tags -->
<!-- Themify Skin -->
<!-- End Themify Skin -->
<!-- Themify Styling -->
<!-- End Themify Styling -->
<link href="favicon.ico" rel="shortcut icon" /> 
    
 
<!-- media-queries.js -->
<!--[if IE]>
<style type="text/css">
/* 修正IE6振动bug */
html,body{background-image:url(about:blank);background-attachment:fixed;}
</style>
<![endif]-->
<!--[if lt IE 9]>
	<script src="<?php echo TEMPLATE_URL; ?>content/themes/Shknn/js/respond.js"></script>
<![endif]-->
</head>
<script type="text/javascript">
jQuery(document).ready(
function($){
$("img").lazyload({
     placeholder : "<?php echo TEMPLATE_URL; ?>content/themes/Shknn/images/grey.gif",
     effect      : "fadeIn"
});
});
</script>
<body class="home blog" >

<div id="pagewrap">
    <div id="headerwrap">
        <div id="header" class="pagewidth">
    
            <div id="site-logo">
                                    <a href='<?php echo BLOG_URL; ?>' TITLE='<?php echo $blogname; ?>'><b class='bclass'><?php echo $blogname; ?></b></a>                            </div>
    <div class="banner">
  <section class="box">
    <ul class="texts">
	<div class="w">
	<div class="x" height="20px">
      <p><?php echo $bloginfo; ?></p>
	  <div class="z">◆</div>
	<div class="y">◆</div>
	</div>
</div>
    </ul>
  </section>
</div>
                    
            <div class="social-widget">
                    
                                    <div class="rss">
									<?php if (in_array('liunianQQ', _g('tool'))):?>
				<dl style="top: 0px;">
				<dt><a href="http://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo _g('liunianQQ');?>&amp;site=qq&amp;menu=yes" title="联系站长" target="_blank" class="nav_button" style="opacity: 0.7;" rel="nofollow"><img src="<?php echo TEMPLATE_URL; ?>content/themes/Shknn/images/lxzz.gif" width="45" height="45"></a></dt>
				<dd>联系站长</dd>
			</dl>
			<?php else: ?>	
              <?php endif; ?>
			  <?php if (in_array('about', _g('tool'))):?>
			<dl style="top: 0px;">
           	<dt><a href="<?php echo _g('about'); ?>" title="关于本站" target="_self" class="nav_button" style="opacity: 0.7;" rel="nofollow"><img src="<?php echo TEMPLATE_URL; ?>content/themes/Shknn/images/nav_1.gif" width="45" height="45"></a></dt>
				<dd>关于本站</dd>
			</dl>
			   <?php else: ?>	
              <?php endif; ?>
			  <?php if (in_array('contact', _g('tool'))):?>
			<dl>
				<dt><a href="<?php echo _g('contact'); ?>" title="my love" target="_self" class="nav_button" style="opacity: 0.7;" rel=""><img src="<?php echo TEMPLATE_URL; ?>content/themes/Shknn/images/other.gif" width="45" height="45"></a></dt>
				<dd>my love</dd>
			</dl>
							 <?php else: ?>	
            <?php endif; ?>
			<?php if (in_array('other', _g('tool'))):?>
						<dl>
				<dt><a href="<?php echo _g('other'); ?>" title="RSS" target="_self" class="nav_button" style="opacity: 0.7;" rel="nofollow"><img src="<?php echo TEMPLATE_URL; ?>content/themes/Shknn/images/rss.png" width="45" height="45"></a></dt>
				<dd>RSS</dd>
			</dl>
			     <?php else: ?>	
<?php endif; ?>
</div>
                            </div>
            <!--/social widget --> 
    
            <!-- header wdiegt -->
            <div class="header-widget">
                            </div>
            <!--/header widget --> 
    
					<div id="searchform-wrap">
				<div id="search-icon" class="mobile-button"></div>
		<form role="search" method="get" id="searchform" action="<?php echo BLOG_URL; ?>index.php">
	<input type="text" name="keyword" id="s" class="input" placeholder="搜索一下又不怀孕"?>
</form>
			</div>
			<!-- /#searchform-wrap -->
		    
            <div id="main-nav-wrap">
                <div id="menu-icon" class="mobile-button"></div>
                <div id="nav-bar">
                    <ul id="main-nav" class="main-nav">
					<li class="home"><a href="/">首页</a></li>
					<?php blog_navi(); ?>
					</ul>               
					</div><!--/nav bar -->
			</div>
            <!-- /#main-nav-wrap -->
    
        </div>
        <!--/header -->
    </div>
    <!-- /headerwrap -->
	<div id="body" class="clearfix">	