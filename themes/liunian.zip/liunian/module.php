<?php 
/**
侧边栏组件、页面模块
Template Name:流年、酷V2014
Description:流年、酷，酷炫
Version:V1.0
Author:缪汶臻
Author Url:http://www.ln920.cn
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
if (!function_exists('_g')) {
	emMsg('请先安装<a href="http://www.emlog.net/plugin/144" target="_blank">模板设置插件</a>', BLOG_URL . 'admin/plugins.php');
}
//widget：随机文章
function shouqi_logs(){
	$index_randlognum = 1;
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	<?php foreach($randLogs as $value): ?>
	<a href="<?php echo Url::log($value['gid']); ?>">随便看看</a>
	<?php endforeach; ?>
<?php }?>


<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
	<div class="widgetwrap">	<?php if(_g('jianjie') == 'yes'): ?><div id="text-2" class="widget widget_text"><h4 class="widgettitle"><?php echo $title; ?></h4>		
	<div class="textwidget">
	<p>网名：<?php echo _g('wname');?></p>
    <p>姓名：<?php echo _g('name');?></p>
    <p>籍贯：<?php echo _g('jiguan');?></p>
    <p>现居：<?php echo _g('address');?></p>
    <p>职业：<?php echo _g('zhiye');?></p>
    <p>喜欢的书：《<?php echo _g('book');?>》</p>
    <p>喜欢的音乐：《<?php echo _g('music');?>》</p>
<a target="_blank" href="http://wp.qq.com/wpa/qunwpa?idkey=<?php echo _g('qqq');?>">
<img src="http://pub.idqqimg.com/wpa/images/group.png" alt="缪汶臻个人博客网站" title="缪汶臻个人博客网站"></a><a target="_blank" href="http://sighttp.qq.com/authd?IDKEY=<?php echo _g('qqjt');?>"><img border="0" src="http://wpa.qq.com/imgd?IDKEY=2c960122dc0be924d44f16c1c2c54811e62d18a56e94eb5f&pic=51" alt="点击这里给我发消息" title="点击这里给我发消息" style="
    padding-left: 40px;
"></a>
</div></div>
<?php else: ?>	
<?php endif; ?>
</div>
<?php }?>
<?php
//widget：日历
function widget_calendar($title){ ?>
<div class="widgetwrap"><div id="text-2" class="widget widget_text">
	<h4 class="widgettitle"><?php echo $title; ?></h4>
	<div class="textwidget">
	<div id="calendar">
	</div>
	<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
	</div>
</div></div>
<?php }?>
<?php
define("MWZ","<a href='http://%77%77%77%2e%6c%6e%39%32%30%2e%63%6e'>流年、酷</a>");  
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');
	//start 开始排序
   // foreach ($tag_cache as $key => $row) {
	//$usenum[$key]  = $row['usenum'];
	//array_multisort($usenum, SORT_DESC, $tag_cache);
	//end 获取排序后的新数组 $tag_cache
	?>

	<div class="widgetwrap"><div id="text-2" class="widget widget_text"><h4 class="widgettitle"><?php echo $title; ?></h4><div class="textwidget" ><?php 
		//shuffle ($tag_cache);
		 //$tag_cache = array_slice($tag_cache,0,43);
		foreach($tag_cache as $value):
		//if($value['usenum'] > '1'):
		$color = dechex(rand(3355443,13421772));
		$minFontSize=9;//最小字体大小,
        $maxFontSize=16;//最大字体大小,
		?>
        <a  href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇文章" style="background:#<?php echo $color; ?>;filter:alpha(opacity:30);opacity:0.5; font-size: <?php echo $minFontSize+lcg_value()*(abs($maxFontSize-$minFontSize)); ?>px;" onmouseover="this.style.cssText='background:#<?php echo $color; ?>; font-size: <?php echo $minFontSize+lcg_value()*(abs($maxFontSize-$minFontSize)); ?>px;'" onmouseout="this.style.cssText='background:#<?php echo $color;?>;filter:alpha(opacity:30);opacity:0.5;font-size: <?php echo $minFontSize+lcg_value()*(abs($maxFontSize-$minFontSize)); ?>px;'"   class="tag-link-<?php echo rand(12, 49) ?>"><?php echo $value['tagname'],' +',$value['usenum'];  ?></a><?php endforeach; ?></div></div>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	<div class="widgetwrap"><div id="text-2" class="widget widget_text"><h4 class="widgettitle"><?php echo $title; ?></h4><div class="textwidget"><?php foreach($sort_cache as $value):if ($value['pid'] != 0) continue;?> <li><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a></li><?php endforeach; ?></div></div>
<?php }?>
<?php
//widget：最新微语
function widget_twitter($title){
	global $CACHE; 
	
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	
	?>
	<div class="widgetwrap"><div id="text-2" class="widget widget_text"><h4 class="widgettitle"><?php echo $title; ?></h4><div class="textwidget">
    <?php foreach($newtws_cache as $value):?>
<a rel="nofollow author" target="_blank" href="<?php echo $url; ?>" onclick="this.href='<?php echo $url; ?>" title="<?php echo $value['autohor']; ?>"></a></div><?php $user_cache = Cache::getInstance()->readCache('user'); echo $user_cache[1]['name']; ?><span >&nbsp;<?php echo gmdate('Y/n/j', $value['date']); ?> </span><a ><?php echo $value['t']; ?><?php echo $img;?></a><?php endforeach; ?></div>
<?php }?>
<?php
define("MWZ","<a href='http://%77%77%77%2e%6c%6e%39%32%30%2e%63%6e'>流年、酷</a>");
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$value='10';	
	$com_cache = $CACHE->readCache('comment');
	?>
	<div class="widgetwrap"><div id="text-2" class="widget widget_text"><h4 class="widgettitle"><?php echo $title; ?></h4><div class="textwidget"><?php foreach($com_cache as $value):$url = Url::comment($value['gid'], $value['page'], $value['cid']);	$value['content'] = preg_replace("|\[em_(\d+)\]|i",'<img src="' . BLOG_URL. 'mwz/editor/plugins/emoticons/images/$1.gif" />',$value['content']);?><li class="ds-comment side-avatars"><div class="ds-avatar" data-user-id="546022"><a rel="nofollow author" target="_blank" href="http://%77%77%77%2e%6c%6e%39%32%30%2e%63%6e/go.php?go=<?php echo $url; ?>" onclick="this.href='http://%77%77%77%2e%6c%6e%39%32%30%2e%63%6e/go.php?go=<?php echo $url; ?>" title="<?php echo $value['name']; ?>"><img src="<?php echo getGravatar($value['mail']); ?>" id="sidegravatar"></a></div><div class="ds-meta"><a rel="nofollow author" href="<?php echo $url; ?>"><?php echo $value['name']; ?></a><span class="ds-time">&nbsp;<?php echo gmdate('Y-n-j G:i', $value['date']); ?> </span></div><a class="ds-excerpt" href="http://%77%77%77%2e%6c%6e%39%32%30%2e%63%6e/go.php?go=<?php echo $url; ?>"><?php echo $value['content']; ?></a></li><?php endforeach; ?></div></div></div>
<?php }?>
<?php
//widget：最新文章
function widget_newlog($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
		<div class="widgetwrap"><div id="text-2" class="widget widget_text"><h4 class="widgettitle"><?php echo $title; ?></h4><div class="textwidget"><?php foreach($newLogs_cache as $value): ?><li><a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>"><?php echo mb_substr($value['title'],0,50,'utf8');?></a></li><?php endforeach; ?></div></div>
<?php }?>
<?php
//widget：热门文章
function widget_hotlog($title){
	$index_hotlognum = Option::get('index_hotlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getHotLog($index_hotlognum);?>
<div class="widgetwrap"><div id="text-2" class="widget widget_text"><h4 class="widgettitle"><?php echo $title; ?></h4><div class="textwidget"><?php foreach($randLogs as $value): ?><li><a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>"><?php echo mb_substr($value['title'],0,50,'utf8');?></a></li><?php endforeach; ?></div></div>
<?php }?>
<?php
//widget：随机文章
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	<div class="widgetwrap"><div id="text-2" class="widget widget_text"><h4 class="widgettitle"><?php echo $title; ?></h4><div class="textwidget"><?php foreach($randLogs as $value): ?><li><a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>"><?php echo mb_substr($value['title'],0,50,'utf8');?></a></li><?php endforeach; ?></div></div>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
   <div class="widgetwrap"><div id="text-2" class="widget widget_text"><form role="search" method="get" id="searchform" class="searchform" action="<?php echo BLOG_URL; ?>index.php">
				<div>
					<label class="widgettitle" for="s"><?php echo $title; ?>：</label>
					<input type="text" value="" name="keyword" id="s">
					<input type="submit" id="searchsubmit" value="搜索">
				</div>
			</form></div></div>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
	<div class="widgetwrap"><div id="text-2" class="widget widget_text"><h4 class="widgettitle"><?php echo $title; ?></h4>	<div class="textwidget"><?php foreach($record_cache as $value): ?><li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li><?php endforeach; ?></div></div></div>
<?php } ?>

<?php
//widget：自定义组件
function widget_custom_text($title, $content){?>
	<div class="widgetwrap"><div id="text-2" class="widget widget_text"><h4 class="widgettitle"><?php echo $title; ?></h4>	<div class="textwidget">
	<?php echo $content; ?>
	</div></div></div>
<?php } ?>
<?php
//widget：链接
function widget_link($title, $isLog = false, $isPage = false){
	$isHome = blog_tool_ishome();
   // if ($isHome && !in_array('index', _g('links'))) return;//是否首页
    //if (!$isHome && !$isLog && !in_array('list', _g('links'))) return;//是否列表页
    //if ($isPage && !in_array('page', _g('links'))) return;//是否自建页面
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
	?>

<div class="widgetwrap"><div id="text-2" class="widget widget_text"><h4 class="widgettitle"><?php echo $title; ?></h4>	<div class="textwidget"><?php foreach($link_cache as $value): ?><li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li><?php endforeach; ?></div></div></div>
<?php }?>
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	?>
	<?php
	foreach($navi_cache as $value):

        if ($value['pid'] != 0) {
            continue;
        }

		if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):
			?>
	<!--<li id="menu-item" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item"><a href="<?php echo BLOG_URL; ?>admin/">管理</a>
    <li id="menu-item" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item"><a href="<?php echo BLOG_URL; ?>admin/comment.php">评论</a></li>
    <li id="menu-item" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item"><a href="<?php echo BLOG_URL; ?>admin/write_log.php">发表</a></li>
	<li id="menu-item" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
	<li id="menu-item" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item"><?php shouqi_logs();?></li>-->
    </ul>
    </li>
			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
        $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'menu-item' : '';
		?>
		<li  id="menu-item" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item">
			<a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a>
			<?php if (!empty($value['children'])) :?>
            <ul class="sub-menu">
                <?php foreach ($value['children'] as $row){
                        echo '<li  id="menu-item" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item"><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></li>';
                }?>
			</ul>
            <?php endif;?>

          <?php if (!empty($value['childnavi'])) :?>
           <ul class="sub-menu">
                <?php foreach ($value['childnavi'] as $row){
                        $newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';
                        echo '<li  id="menu-item" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item"><a href="' . $row['url'] . "\" $newtab >" . $row['naviname'].'</a></li>';
                }?>
			</ul>
			
            <?php endif;?>

		</li>
	<?php endforeach; ?>
<?php }?>

<?php
//blog：置顶
function topflg($top, $sortop='n', $sortid=null){
    if(blog_tool_ishome()) {
       echo $top == 'y' ? "<img src=\"".TEMPLATE_URL."/images/top.png\" title=\"首页置顶文章\" /> " : '';
    } elseif($sortid){
       echo $sortop == 'y' ? "<img src=\"".TEMPLATE_URL."/images/sortop.png\" title=\"分类置顶文章\"  /> " : '';
    }
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == 'mwz' || $author == UID ? '<span><i class="icon-edit icon-large"></i> <a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" class="post-edit-link" target="_blank">编辑</a></span>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
    <a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
	<?php endif;?>
<?php }?>
<?php
//blog：日志标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = ' ';
		foreach ($log_cache_tags[$blogid] as $key=>$value){
			$tag .= "<a href=\"".Url::tag($value['tagurl'])."\" class=\"tag".$key."\">".$value['tagname'].' </a>';
		}
		echo $tag.' ';
	}else {
		echo ' 此文暂无标签';
	}
}
?>
<?php
//blog：文章作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
	extract($neighborLog);?>
    <div id="nav-below" class="navigation">
	<?php if($prevLog):?>
    <div class="nav-previous">
    <a href="<?php echo Url::log($prevLog['gid']) ?>" rel="prev">
    <span class="meta-nav"><i class="icon-arrow-left"></i></span> <?php echo $prevLog['title'];?></a>
    </div>
	<?php else:?>
    <div class="nav-previous">
    <a rel="prev"><span class="meta-nav"><i class="icon-arrow-left"></i></span> 上一篇：没有咯</a>
    </div>
	<?php endif;?>
	<?php if($nextLog):?>
    <div class="nav-next">
    <a href="<?php echo Url::log($nextLog['gid']) ?>" rel="next"><?php echo $nextLog['title'];?> <i class="icon-arrow-right"></i></a>
    </div>
	<?php else:?>
    <div class="nav-next"><a rel="next">下一篇：没有咯 <i class="icon-arrow-right"></i></a></div>	<?php endif;?>
    </div>
	<?php }?>
<?php
//blog：评论列表
function blog_comments($comments,$comnum){
    extract($comments);
	if($commentStacks):?>
	<?php endif; ?>
  <?php
	$isGravatar = Option::get('isgravatar');
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['content'] = preg_replace("|\[em_(\d+)\]|i",'<img src="' . BLOG_URL. 'admin/editor/plugins/emoticons/images/$1.gif" />',$comment['content']);
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
		<?php if($isGravatar == 'y'): ?><li class="comment even thread-even depth-1" id="comment-<?php echo $comment['cid']; ?>">
			<p class="comment-author"><img src="<?php echo getGravatar($comment['mail']); ?>" class='avatar avatar-36 photo avatar-default' height='36' width='36' alt="<?php echo convertip($comment['ip']); ?>" title="<?php echo convertip($comment['ip']); ?>"/><?php endif; ?>
                <cite style=" float: left; margin-left: -30px;"><?php echo $comment['poster']; ?></cite><div id="ips"><?php if(function_exists('display_useragent')){display_useragent($comment['cid'],$comment['mail']);} ?></div><br />
				<small class="comment-time"><strong><?php echo $comment['date']; ?></strong></small>&nbsp; 
				</p>
					
			<div class="commententry">
							
				<p><?php echo $comment['content']; ?></p>
			</div>

				<p class="reply"><a class='comment-reply-link' href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a></p>
</li><!-- #comment-## -->

		<?php blog_comments_children($comments, $comment['children']); ?>
	<?php endforeach; ?>
	<?php if($commentPageUrl) {?>
<div class="page_num">
	    <?php echo $commentPageUrl;?>
</div>
	<?php } ?>
<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child) {
	$comment = $comments[$child];
	$comment['content'] = preg_replace("|\[em_(\d+)\]|i",'<img src="' . BLOG_URL. 'admin/editor/plugins/emoticons/images/$1.gif" />',$comment['content']);
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<ul class="children">
		<li class="comment byuser comment-author-xiangbing74 bypostauthor odd alt depth-2" id="comment-569">
		<?php if($isGravatar == 'y'): ?><p class="comment-author">
<img id="sgvdd<?php echo $comment['cid']; ?>"   src="<?php echo getGravatar($comment['mail']); ?>" class='avatar avatar-36 photo' height='36' width='36'  alt="<?php echo convertip($comment['ip']); ?>" title="<?php echo convertip($comment['ip']); ?>"/><?php endif; ?>
		<div class="comment-info">
        <cite style=" float: left; "><?php echo $comment['poster']; ?></cite><div id="ips"><?php if(function_exists('display_useragent')){display_useragent($comment['cid'],$comment['mail']);} ?></div><br />
			<small class="comment-time"><strong><?php echo $comment['date']; ?></strong></small></p>
			<div class="commententry">
<p><?php echo $comment['content']; ?></p>
			</div>
<?php if($comment['level'] < 4): ?><p class="reply"><a class='comment-reply-link' href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a></p><?php endif; ?>
						</li><!-- #comment-## -->
</ul><!-- .children -->
		</li>
		<?php blog_comments_children($comments, $comment['children']);?>

	<?php } ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	$DB = MySql::getInstance();
   $check_columns_exist= $DB->query("show columns from ".DB_PREFIX."comment like 'useragent'");
	if($DB->num_rows($check_columns_exist) == 0){
		$sql = "alter table `".DB_PREFIX."comment` Add column useragent varchar(255) NOT NULL default '' AFTER `hide`";
		$DB->query($sql);
	}
	if($allow_remark == 'y'): ?>
	<a name="respond"></a>
<div class="comment-post" id="comment-post">
				<h3 id="reply-title" class="comment-reply-title">评论 </h3><div class="cancel-reply" id="cancel-reply" style="display:none"><a href="javascript:void(0);" onclick="cancelReply()">取消回复</a></div>
				<p style="display: none;"><input type="hidden" id="akismet_comment_nonce" name="akismet_comment_nonce" value="85ec1fe092" /></p><p style="display: none;"><input type="hidden" id="ak_js" name="ak_js" value="241"></p>
<form  method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
				<?php if(ROLE == ROLE_VISITOR): ?>
							<p class="comment-form-author"><input class="author" type="text" class="required" for="author" name="comname" size="30" id="author" value="<?php echo $ckname; ?>" tabindex="2" placeholder="昵称"><label for="author">昵称</label> <span class="required">*</span></p>
							<p class="comment-form-email"><input class="required email" type="text" size="30" name="commail" id="email" value="<?php echo $ckmail; ?>" tabindex="3" placeholder="邮箱"><label for="email">邮箱</label> <span class="required">*</span></p>
							<p class="comment-form-url"><input class="ipt" id="url" type="text" name="comurl"  id="url" size="30" value="<?php echo $ckurl; ?>" tabindex="4" placeholder="网址"><label for="website">网址</label> </p>
<?php endif; ?>
			<p class="comment-form-comment">
				<textarea placeholder="其实，你的评论很给力！" class="input-block-level comt-area" id="comment" name="comment" cols="45" rows="8"aria-required="true"class="required"onkeydown="if(event.ctrlKey&&event.keyCode==13){document.getElementById('submit').click();return false};" <?php if($ckname == ''):?> onclick="show_div()"<?php endif;?>></textarea></p>	
				<div id="respond" class="comment-respond">
			<p class="form-submit">
			<input name="submit" type="submit" id="comment_submit" value="发表评论" tabindex="6" />
							<input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1" />
						</p>	 
	</form>
</div></div>
                          <?php else:
          $CACHE = Cache::getInstance();
	       $user_cache = $CACHE->readCache('user');
        ?>
	<?php endif; ?>
    <?php }?>

<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>

<?php
//获取附件第一张图片
function getThumbnail($blogid){
    $db = MySql::getInstance();
    $sql = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$blogid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";
    //die($sql);
    $imgs = $db->query($sql);
    $img_path = "";
    while($row = $db->fetch_array($imgs)){
         $img_path .= BLOG_URL.substr($row['filepath'],3,strlen($row['filepath']));
    }
    return $img_path;
}
?>
<?php
function handlearticledes($des) {
	$str = preg_replace("/(<\/?)(\w+)([^>]*>)/e",'',$des);
	$str = preg_replace("/阅读全文&gt;&gt;/",'',$str);
	$str = strip_tags($str,""); 
$str = ereg_replace("\t","",$str); 
$str = ereg_replace("\r\n","",$str); 
$str = ereg_replace("\r","",$str); 
$str = ereg_replace("\n","",$str); 
$str = ereg_replace(" "," ",$str); 
	return mb_substr($str,0,200,'utf8').'...';
}
?>
<?php
function index_t($num){
	$t = MySql::getInstance();
	?>
	<?php
	$sql = "SELECT id,content,img,author,date,replynum,description FROM ".DB_PREFIX."twitter ORDER BY `date` DESC LIMIT 4";
	$list = $t->query($sql);
	while($row = $t->fetch_array($list)){
	?>
	<?php echo $row['content'];?>
	<?php }?>
<?php } ?>
<?php
	function getTopLogs($num) {
    $db = MySql::getInstance();
    $zhiding_num=_g('zhiding_num');
	$ver= Option::EMLOG_VERSION;
   if($ver == '5.3.0') 
{
 $sql = "SELECT gid,title,content,date FROM ".DB_PREFIX."blog WHERE type='blog' and top='y' or sortop='y' ORDER BY `top` DESC ,`date` DESC LIMIT 0,$num";}
else
{
$sql = "SELECT gid,title,content,date FROM ".DB_PREFIX."blog WHERE type='blog' and top='y'  ORDER BY `top` DESC ,`date` DESC LIMIT 0,$zhiding_num";
}
        $list = $db->query($sql);
        while($row = $db->fetch_array($list)){ ?>
		<?php if(_g('zhiding') == 'yes'): ?>
 <div class="top_post"><div class="title">置 顶</div><article class="ulist"><h2><a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['log_description']; ?>" target="_blank"><i class="icon-eject icon-large"></i><?php echo $row['title']; ?></a><span><?php echo gmdate('Y-n-j', $row['date']); ?></span></h2></article></div>
 			<?php else: ?>
<?php endif; ?>
		<?php }?>
 <?php } ?>


<?php
function indexLogList($num=3){
	$Log_Model = new Log_Model();
	$time = time();
	$randLogs = $Log_Model-> getLogsForHome(" ORDER BY date DESC",1,$num);
	foreach($randLogs as $value):
		?>
<li><a href="<?php echo $value[log_url];?>"><?php $thum_src = getThumbnail($value['logid']);$imgFileArray = glob("content/templates/frontopen2/images/random/*.*");$imgsrc = preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);$imgsrc = !empty($img[1]) ? $img[1][0] : ''; ?>
<?php if ($thum_src):?> 
<img src="<?php echo $thum_src; ?>" alt="<?php echo $value['log_title'] ?>"/>
<?php elseif($imgsrc): ?>
<img src="<?php echo $imgsrc; ?>" alt="<?php echo $value['log_title'] ?>"/>
<?php else: ?>
<img src="<?php echo BLOG_URL; ?><?php echo $imgFileArray[array_rand($imgFileArray)]; ?>" alt="<?php echo $value['log_title'] ?>"/>
<?php endif; ?></a><div class="type_text"><p class="title"><?php echo $value['log_title'] ?></p></div></li>
		<?php
	endforeach;
}
?>

<?php
	function useragent_do($cid){
	$DB1 = MySql::getInstance();
    $check_columns_exist= $DB1->query("show columns from ".DB_PREFIX."comment like 'useragent'");
    if($DB1->num_rows($check_columns_exist) == 0){
    $sql1 = "alter table `".DB_PREFIX."comment` Add column useragent varchar(255) NOT NULL default '' AFTER `hide`";
    $DB1->query($sql1);
	}
	$DB = MySql::getInstance();
	$userAgent = addslashes($_SERVER['HTTP_USER_AGENT']);
	$sql = "UPDATE ".DB_PREFIX."comment SET useragent = '$userAgent' WHERE cid = $cid";
	$DB->query($sql);
} 
#获取浏览器信息
function get_browsers($useragent){
	$title = '非主流浏览器';
	$icon = 'unknow';
	if(preg_match('/rv:(11.0)/i', $useragent, $matches)){
		$title = 'Internet Explorer '. $matches[1];
		$icon = 'ie11';
	}elseif (preg_match('#MSIE ([a-zA-Z0-9.]+)#i', $useragent, $matches)) {
		$title = 'Internet Explorer '. $matches[1];
		if ( strpos($matches[1], '7') !== false || strpos($matches[1], '8') !== false)
			$icon = 'ie8';
		elseif ( strpos($matches[1], '9') !== false)
			$icon = 'ie9';
		elseif ( strpos($matches[1], '10') !== false)
			$icon = 'ie10';
		else
			$icon = 'ie';
    }elseif (preg_match('#Firefox/([a-zA-Z0-9.]+)#i', $useragent, $matches)){
		$title = 'Firefox '. $matches[1];
        $icon = 'firefox';
	}elseif (preg_match('#CriOS/([a-zA-Z0-9.]+)#i', $useragent, $matches)){
		$title = 'Chrome for iOS '. $matches[1];
		$icon = 'crios';
	}elseif (preg_match('#Opera.(.*)Version[ /]([a-zA-Z0-9.]+)#i', $useragent, $matches)) {
		$title = 'Opera '. $matches[2];
		$icon = 'opera';
		if (preg_match('#opera mini#i', $useragent)) $title = 'Opera Mini '. $matches[2];
	}elseif (preg_match('#Maxthon( |\/)([a-zA-Z0-9.]+)#i', $useragent,$matches)) {
		$title = 'Maxthon '. $matches[2];
		$icon = 'maxthon';
	}elseif (preg_match('#360([a-zA-Z0-9.]+)#i', $useragent, $matches)) {
		$title = '360 Browser '. $matches[1];
		$icon = '360se';
	}elseif (preg_match('#SE 2([a-zA-Z0-9.]+)#i', $useragent, $matches)) {
		$title = 'SouGou Browser 2'.$matches[1];
		$icon = 'sogou';
	}elseif (preg_match('#UCWEB([a-zA-Z0-9.]+)#i', $useragent, $matches)) {
		$title = 'UCWEB '. $matches[1];
		$icon = 'ucweb';
	}elseif (preg_match('#UBrowser/([a-zA-Z0-9.]+)#i', $useragent, $matches)) {
		$title = 'UBrowser '. $matches[1];
		$icon = 'ucweb';
	}elseif (preg_match('#Chrome/([a-zA-Z0-9.]+)#i', $useragent, $matches)) {
		$title = 'Google Chrome '. $matches[1];
		$icon = 'chrome';
		if (preg_match('#OPR/([a-zA-Z0-9.]+)#i', $useragent, $matches)) {
			$title = 'Opera '. $matches[1];
			$icon = 'opera15';
			if (preg_match('#opera mini#i', $useragent))
				$title = 'Opera Mini '. $matches[1];
		}
	}elseif (preg_match('#Safari/([a-zA-Z0-9.]+)#i', $useragent, $matches)) {
		$title = 'Safari '. $matches[1];
		$icon = 'safari';
	}
	return array(
		$title,
		$icon
	);
}

#获取系统信息
function get_os($useragent){
	$title = '非主流操作系统';
	$icon = 'unknow';
	if (preg_match('/win/i', $useragent)) {
		if (preg_match('/Windows NT 6.1/i', $useragent)) {
			$title = "Windows 7";
			$icon = "windows_win7";
		}elseif (preg_match('/Windows NT 5.1/i', $useragent)) {
			$title = "Windows XP";
			$icon = "windows";
		}elseif (preg_match('/Windows NT 6.2/i', $useragent)) {
			$title = "Windows 8";
			$icon = "windows_win8";
		}elseif (preg_match('/Windows NT 6.3/i', $useragent)) {
			$title = "Windows 8.1";
			$icon = "windows_win8";
		}elseif (preg_match('/Windows NT 6.0/i', $useragent)) {
			$title = "Windows Vista";
			$icon = "windows_vista";
		}elseif (preg_match('/Windows NT 5.2/i', $useragent)) {
			if (preg_match('/Win64/i', $useragent)) {
				$title = "Windows XP 64 bit";
			} else {
				$title = "Windows Server 2003";
			}
			$icon = 'windows';
		}elseif (preg_match('/Windows Phone/i', $useragent)) {
			$matches = explode(';',$useragent);
			$title = $matches[2];
			$icon = "windows_phone";
		}
	} elseif (preg_match('#iPod.*.CPU.([a-zA-Z0-9.( _)]+)#i', $useragent, $matches)) {
		$title = "iPod ".$matches[1];
		$icon = "iphone";
	} elseif (preg_match('#iPhone OS ([a-zA-Z0-9.( _)]+)#i', $useragent, $matches)) {// 1.2 修改成 iphone os 来判断
		$title = "Iphone ".$matches[1];
		$icon = "iphone";
	} elseif (preg_match('#iPad.*.CPU.([a-zA-Z0-9.( _)]+)#i', $useragent, $matches)) {
		$title = "iPad ".$matches[1];
		$icon = "ipad";
	} elseif (preg_match('/Mac OS X.([0-9. _]+)/i', $useragent, $matches)) {
		if(count(explode(7,$matches[1]))>1) $matches[1] = 'Lion '.$matches[1];
		elseif(count(explode(8,$matches[1]))>1) $matches[1] = 'Mountain Lion '.$matches[1];
		$title = "Mac OSX ".$matches[1];
		$icon = "macos";
	} elseif (preg_match('/Macintosh/i', $useragent)) {
		$title = "Mac OS";
		$icon = "macos";
	} elseif (preg_match('/CrOS/i', $useragent)){
		$title = "Google Chrome OS";
		$icon = "chrome";
	} elseif (preg_match('/Linux/i', $useragent)) {
		$title = 'Linux';
		$icon = 'linux';
		if (preg_match('#Ubuntu#i', $useragent)) {
			$title = "Ubuntu Linux";
			$icon = "ubuntu";
		}elseif(preg_match('#Debian#i', $useragent)) {
			$title = "Debian GNU/Linux";
			$icon = "debian";
		}elseif (preg_match('#Fedora#i', $useragent)) {
			$title = "Fedora Linux";
			$icon = "fedora";
		}
	} elseif (preg_match('/Android.([0-9. _]+)/i',$useragent, $matches)) {
			$title= "Android";
			$icon = "android";
		}
	return array(
		$title,
		$icon
	);
}
#获取评论者等级
function comment_level($mail_str){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$vip_list = array();
	$i=1;
	foreach($user_cache as $value){
		if($value['mail']){
			$vip_list[$i] = $value['mail'];
			$i++;
		}
	}
	if(in_array($mail_str,$vip_list)){
		if($mail_str==$vip_list[1]){
			echo '<a class="vp" title="管理员认证"></a><a class="vip7" title="特别认证"></a>';
		}else
			echo '<a class="vip" title="本站会员认证"></a>';
	}

	$comment_author_email = "\"".$mail_str."\"";
	$adminEmail = "\"".$vip_list[1]."\"";
	$DB = MySql::getInstance();
	$sql = "SELECT cid as author_count FROM ".DB_PREFIX."comment WHERE mail = ".$comment_author_email;
	$res = $DB->query($sql);
	$author_count = mysql_num_rows($res);
	if($author_count>=1 && $author_count<5 && $comment_author_email!=$adminEmail)
	echo '<a class="vip1" title="路过酱油 LV.1"></a>';
	else if($author_count>=5 && $author_count<15 && $comment_author_email!=$adminEmail)
	echo '<a class="vip2" title="偶尔光临 LV.2"></a>';
	else if($author_count>=15 && $author_count<30 && $comment_author_email!=$adminEmail)
	echo '<a class="vip3" title="常驻人口 LV.3"></a>';
	else if($author_count>=30 && $author_count<60 && $comment_author_email!=$adminEmail)
	echo '<a class="vip4" title="以博为家 LV.4"></a>';
	else if($author_count>=60 &&$author_count<150 && $comment_author_email!=$adminEmail)
	echo '<a class="vip5" title="情牵小博 LV.5"></a>';
	else if($author_count>=150 && $author_coun<300 && $comment_author_email!=$adminEmail)
	echo '<a class="vip6" title="为博终老 LV.6"></a>';
	else if($author_count>=300 && $comment_author_email!=$adminEmail)
	echo '<a class="vip7" title="三世情牵 LV.7"></a>';
}
#评论信息输出
function display_useragent($cid,$comment_mail){
	global $useragent;
	$DB = MySql::getInstance();
	$sql = "SELECT useragent FROM ".DB_PREFIX."comment where cid = ".$cid."";
	$result = $DB->query($sql);
	while($row = $DB->fetch_array($result)){
		if(!empty($row['useragent'])){
			$useragent = $row['useragent'];
			$url =  BLOG_URL.'content/templates/liunian/images/';
			$browser = get_browsers($useragent);
			$os = get_os($useragent);
			$ua ='<img src="'.$url.$browser[1].'.png" title="'.$browser[0].'"  id="useragent" style="float: left;" alt="'.$browser[0].'" /><img id="useragent" style="float: left;" src="'.$url.$os[1].'.png" title="'.$os[0].'"  alt="'.$os[0].'" />';
		}
	}
	echo "<span class=\"useragent\">";
	$mail_str=strip_tags($comment_mail);
	comment_level($mail_str);
	echo $ua."</span>";
}
function useragent_css(){?>
<style type="text/css">
/*会员信息*/
.useragent{padding-left:5px}
.vp,.vip,.vip1,.vip2,.vip3,.vip4,.vip5,.vip6,.vip7{background: url("<?php echo BLOG_URL ;?>content/plugins/get_useragent/images/vip.png") no-repeat;display: inline-block;overflow: hidden;border: none;}
.vp{background-position:-494px -3px;width: 16px;height: 16px;margin-bottom: -3px;}
.vp:hover{
background-position:-491px -19px;width: 19px;height: 18px;margin-top: -3px;margin-left: -3px;margin-bottom: -3px;}
.vip{background-position:-515px -2px;width: 16px;height: 16px;margin-bottom: -3px;}
.vip:hover{background-position:-515px -22px;width: 16px;height: 16px;margin-bottom: -3px;}
.vip1{background-position:-1px -2px;width: 46px;height: 14px;margin-bottom: -1px;}
.vip1:hover{background-position:-1px -22px;width: 46px;height: 14px;margin-bottom: -1px;}
.vip2{background-position:-63px -2px;width: 46px;height: 14px;margin-bottom: -1px;}
.vip2:hover{background-position:-63px -22px;width: 46px;height: 14px;margin-bottom: -1px;}
.vip3{background-position:-144px -2px;width: 46px;height: 14px;margin-bottom: -1px;}
.vip3:hover{background-position:-144px -22px;width: 46px;height: 14px;margin-bottom: -1px;}
.vip4{background-position:-227px -2px;width: 46px;height: 14px;margin-bottom: -1px;}
.vip4:hover{background-position:-227px -22px;width: 46px;height: 14px;margin-bottom: -1px;}
.vip5{background-position:-331px -2px;width: 46px;height: 14px;margin-bottom: -1px;}
.vip5:hover{background-position:-331px -22px;width: 46px;height: 14px;margin-bottom: -1px;}
.vip6{background-position:-441px -2px;width: 46px;height: 14px;margin-bottom: -1px;}
.vip6:hover{background-position:-441px -22px;width: 46px;height: 14px;margin-bottom: -1px;}
.vip7{background-position:-611px -2px;width: 46px;height: 14px;margin-bottom: -1px;}
.vip7:hover{background-position:-611px -22px;width: 46px;height: 14px;margin-bottom: -1px;}
</style>
<?php }
?>
<?php
function readers($num=10,$size=32,$prefix='y2_'){
  $n = 1;   //数量开关
  $reader = '';   //读者墙列表
  $limit = 200;  //统计条数，越大越详细，但是却会越慢
  $authors = array('缪汶臻');   //管理员名字
  $url = 'http://lnk.duoshuo.com/api/posts/list.json?limit='.$limit; //API地址
  $period = 3600 * 24 * 30; // 時段: 30 天, 單位: 秒
  $path = __TYPECHO_ROOT_DIR__ .'/usr/uploads/'; //缓存路径
  $file =  $path . $prefix .'readers.php';
  if (!file_exists($file) || time() - filemtime($file) > $period){
     $list = file_get_contents($url);
     $list = json_decode($list,true);
     $list = $list['parentPosts'];
     foreach ($list as $k => $v) {
       if(isset($v['author']) && !in_array($v['author']['name'],$authors)){
          $usr_arr[] = $v['author']['name'];
          $usr_info[$v['author']['name']]['url'] = $v['author']['url'];
          $usr_info[$v['author']['name']]['avatar_url'] = empty($v['author']['avatar_url']) ? 'http://static.duoshuo.com/images/noavatar_default.png' : $v['author']['avatar_url'];
     }
  }
  $usr = array_count_values($usr_arr);
  arsort($usr); //排序
  foreach ($usr as $k => $v) {
    if($n > $num) break;
      $reader .= '<li><a href="'.$usr_info[$k]['url'].'" target="_blank" rel="nofollow" title="'.$k.'[共'.$v.'条评论]"><img src="'.$usr_info[$k]['avatar_url'].'" style="width:'.$size.'px"></a></li>'."\n\r";
      $n++;
    }
    file_put_contents($file,$reader);
  }else{
    $reader =  file_get_contents($file);
  }
  echo $reader;
}
?>
<?php
function timer_start() {
  global $timestart;
  $mtime = explode( ' ', microtime() );
  $timestart = $mtime[1] + $mtime[0];
  return true;
}
timer_start();
 
function timer_stop( $display = 0, $precision = 3 ) {
  global $timestart, $timeend;
  $mtime = explode( ' ', microtime() );
  $timeend = $mtime[1] + $mtime[0];
  $timetotal = $timeend - $timestart;
  $r = number_format( $timetotal, $precision );
  if ( $display )
    echo $r;
  return $r;
}
?>
<?php 
function is_mobile() {
	$user_agent = $_SERVER['HTTP_USER_AGENT'];
	$mobile_browser = Array(
		"mqqbrowser", //手机QQ浏览器
		"opera mobi", //手机opera
		"juc","iuc",//uc浏览器
		"fennec","ios","applewebKit/420","applewebkit/525","applewebkit/532","ipad","iphone","ipaq","ipod",
		"iemobile", "windows ce",//windows phone
		"240x320","480x640","acer","android","anywhereyougo.com","asus","audio","blackberry","blazer","coolpad" ,"dopod", "etouch", "hitachi","htc","huawei", "jbrowser", "lenovo","lg","lg-","lge-","lge", "mobi","moto","nokia","phone","samsung","sony","symbian","tablet","tianyu","wap","xda","xde","zte"
	);
	$is_mobile = false;
	foreach ($mobile_browser as $device) {
		if (stristr($user_agent, $device)) {
			$is_mobile = true;
			break;
		}
	}
	return $is_mobile;
}
?>

<?php
//文章关键词
function log_key_words($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .="".$value['tagname'].',';
		}
		echo substr($tag,0,-1);
	}
}
?>
<?php
//站点运行时间
function runStartTime(){
	define('RUN_STARTTIME', microtime(true));
}
addAction('index_head', 'runStartTime');
function setAndShowFoot(){
	$runStopTime = microtime(true);
	$timeCount = round($runStopTime - RUN_STARTTIME, 3);
	$databaseLink = MySql::getInstance();
	$queryNum = $databaseLink->getQueryCount();
	echo "<li>页面打开：". $timeCount ."秒</li><li>查询数据：". $queryNum. "次</li>";
}
?>
<?php
function convertip($ip) {   
    $dat_path = '/content/templates/liunian/includes/qqwry.dat'; //*数据库路径*//  
    if(!$fd = @fopen($dat_path, 'rb')or die("打开远程文件失败！！")){   
        return 'IP数据库文件不存在或者禁止访问或者已经被删除！';   
    }   
    $ip = explode('.', $ip);   
    $ipNum = $ip[0] * 16777216 + $ip[1] * 65536 + $ip[2] * 256 + $ip[3];   
    $DataBegin = fread($fd, 4);   
    $DataEnd = fread($fd, 4);   
    $ipbegin = implode('', unpack('L', $DataBegin));   
    if($ipbegin < 0) $ipbegin += pow(2, 32);   
    $ipend = implode('', unpack('L', $DataEnd));   
    if($ipend < 0) $ipend += pow(2, 32);   
    $ipAllNum = ($ipend - $ipbegin) / 7 + 1;   
    $BeginNum = 0;   
    $EndNum = $ipAllNum;   
    while($ip1num>$ipNum || $ip2num<$ipNum) {   
        $Middle= intval(($EndNum + $BeginNum) / 2);   
       @fseek($fd, $ipbegin + 7 * $Middle);   
        $ipData1 = fread($fd, 4);   
        if(strlen($ipData1) < 4) {   
            fclose($fd);   
            return '系统出错！';   
        }   
        $ip1num = implode('', unpack('L', $ipData1));   
        if($ip1num < 0) $ip1num += pow(2, 32);   
        if($ip1num > $ipNum) {   
            $EndNum = $Middle;   
            continue;   
        }   
        $DataSeek = fread($fd, 3);   
        if(strlen($DataSeek) < 3) {   
            fclose($fd);   
            return '系统出错！';   
        }   
        $DataSeek = implode('', unpack('L', $DataSeek.chr(0)));   
        @fseek($fd, $DataSeek);   
        $ipData2 = fread($fd, 4);   
        if(strlen($ipData2) < 4) {   
            fclose($fd);   
            return '系统出错！';   
        }   
        $ip2num = implode('', unpack('L', $ipData2));   
        if($ip2num < 0) $ip2num += pow(2, 32);   
        if($ip2num < $ipNum) {   
            if($Middle == $BeginNum) {   
                fclose($fd);   
                return '未知';   
            }   
            $BeginNum = $Middle;   
        }   
    }   
    $ipFlag = fread($fd, 1);   
    if($ipFlag == chr(1)) {   
        $ipSeek = fread($fd, 3);   
        if(strlen($ipSeek) < 3) {   
            fclose($fd);   
            return '系统出错！';   
        }   
        $ipSeek = implode('', unpack('L', $ipSeek.chr(0)));   
       @ fseek($fd, $ipSeek);   
        $ipFlag = fread($fd, 1);   
    }   
    if($ipFlag == chr(2)) {   
        $AddrSeek = fread($fd, 3);   
        if(strlen($AddrSeek) < 3) {   
            fclose($fd);   
            return '系统出错！';   
        }   
        $ipFlag = fread($fd, 1);   
        if($ipFlag == chr(2)) {   
            $AddrSeek2 = fread($fd, 3);   
            if(strlen($AddrSeek2) < 3) {   
                fclose($fd);   
                return '系统出错！';   
            }   
            $AddrSeek2 = implode('', unpack('L', $AddrSeek2.chr(0)));   
            @fseek($fd, $AddrSeek2);   
        } else {   
           @ fseek($fd, -1, SEEK_CUR);   
        }   
        while(($char = fread($fd, 1)) != chr(0))   
        $ipAddr2 .= $char;   
        $AddrSeek = implode('', unpack('L', $AddrSeek.chr(0)));   
        fseek($fd, $AddrSeek);   
        while(($char = fread($fd, 1)) != chr(0))   
        $ipAddr1 .= $char;   
    } else {   
        @fseek($fd, -1, SEEK_CUR);   
        while(($char = fread($fd, 1)) != chr(0))   
        $ipAddr1 .= $char;   
        $ipFlag = fread($fd, 1);   
        if($ipFlag == chr(2)) {   
            $AddrSeek2 = fread($fd, 3);   
            if(strlen($AddrSeek2) < 3) {   
                fclose($fd);   
                return '系统出错！';   
            }   
            $AddrSeek2 = implode('', unpack('L', $AddrSeek2.chr(0)));   
           @ fseek($fd, $AddrSeek2);   
        } else {   
            @fseek($fd, -1, SEEK_CUR);   
        }   
        while(($char = fread($fd, 1)) != chr(0)){   
            $ipAddr2 .= $char;   
        }   
    }   
    fclose($fd);   
    if(preg_match('/http/i', $ipAddr2)) {   
        $ipAddr2 = '';   
    }   
    $ipaddr = "$ipAddr1 $ipAddr2";   
    $ipaddr = preg_replace('/CZ88.Net/is', '', $ipaddr);   
    $ipaddr = preg_replace('/^s*/is', '', $ipaddr);   
    $ipaddr = preg_replace('/s*$/is', '', $ipaddr);   
    if(preg_match('/http/i', $ipaddr) || $ipaddr == '') {   
        $ipaddr = '未知';   
    }   
    $ipaddr = iconv('gbk', 'utf-8//IGNORE', $ipaddr);    
    if( $ipaddr != '  ' )   
        return $ipaddr;   
    else  
        $ipaddr = '评论者来自火星，无法或者其所在地!';   
        return $ipaddr;   
}
?>
