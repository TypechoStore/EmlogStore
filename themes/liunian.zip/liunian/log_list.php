	<?php 
/**
站点首页模板
Template Name:流年、酷V2014
Description:流年、酷，酷炫
Version:V1.0
Author:缪汶臻
Author Url:http://www.ln920.cn
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!-- layout-container -->
<div id="layout" class="clearfix sidebar1 sidebar-left">
<?php doAction('index_loglist_top'); ?>
	<!-- content -->
	<div id="content" class="clearfix">					
			<!-- loops-wrapper -->
			<div class="loops-wrapper list-thumb-image">
			<?php if(_g('zhiding') == "yes"): ?>
			<?php echo getTopLogs('ggnum')?>
			<?php else: ?>
<?php endif; ?>
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
<div id="post-1099" class="post-1099 post type-post status-publish format-standard hentry category-vision tag-228 tag-227 clearfix">	
	<div class="post-content">
	<h2 class="post-title"><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a><?php
$t=time() - 3*24*60*60;
$log_t=gmdate('Y-m-d',$$value['date']);
$diy_t=date("Y-m-d",$t);
if($log_t > $diy_t) echo '<img src="/content/templates/liunian/images/new.png" alt="最新文章" />';
if ($value['views'] >= 100) echo '<img src="/content/templates/liunian/images/hot.gif" alt="最热文章" />';
?></h2>
<p><?php
$thum_src = getThumbnail($value['logid']);
 $imgFileArray = TEMPLATE_URL.'images/random/'.rand(1,33).'.jpg';?>
<?php if ($thum_src):?> 
 <img src="<?php echo $thum_src; ?>" alt="<?php echo $value['log_title']; ?>"  title="<?php echo $value['log_title'] ?>" style="
border: #A29B9B 1px solid; height: 135px;float: left;width: 183px;" />
<?php elseif($imgsrc): ?>
 <img src="<?php echo $imgsrc; ?>" alt="<?php echo $value['log_title']; ?>" title="<?php echo $value['log_title'] ?>" style="
    border: #A29B9B 1px solid;height: 135px;float: left;width: 183px;"/>
	<?php else: ?>
	 <img src="<?php echo $imgFileArray; ?>" alt="<?php echo $value['log_title']; ?>" title="<?php echo $value['log_title'] ?>" style="
    border: #A29B9B 1px solid;height: 135px;float: left;width: 183px;"/>
<?php endif; ?>
 <span style="
    line-height: 23px;
"><?php echo subString(strip_tags($value['log_description']),0,170,"..."); ?></span></P><br/>
	<p class="post-meta"> 
				<span class="post-author">作者： <?php blog_author($value['author']); ?>   &bull;</span>
				<span class="post-author">时间： <?php echo gmdate('Y-m-d h:s', $value['date']); ?>   &bull;</span>
				<span class="post-author">浏览： <?php echo $value['views']; ?>   &bull;</span>				
				<span class="post-category">分类：<a href="" rel="category tag"><?php blog_sort($value['logid']); ?> </a></span>
									<span class="post-comment"><a href="<?php echo $value['log_url']; ?>#comment" title="《<?php echo $value['log_title']; ?>》上的评论"><span style="margin-left: -23px;"><?php echo $value['comnum']; ?></span></a></span>
								 <span class="post-tag">&bull; 标签: <?php blog_tag($value['logid']); ?></span>			</p>
								 <a href="<?php echo $value['log_url']; ?>" class="more-link" style="width: 15%;" se_prerender_url="complete">阅 读 全 部 &gt;</a>
	</div>
	<!-- /.post-content -->			
</div>
<!--/post -->
<?php 
endforeach;
else:
?>
	<h2>暂时没有文章</h2>
	<p>
		抱歉，作者暂时没有发布此分类文章，您可以先看看别的。
	</p>
	<?php endif;?>
			</div>
			<!-- /loops-wrapper -->
				<div class="pagenav clearfix"> <?php echo $page_url;?></div> 
	</div>
	<!--/content -->
  <?php
 include View::getView('side');
 include View::getView('footer');
?>