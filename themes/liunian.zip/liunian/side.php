	<?php 
/**
侧边栏
Template Name:流年、酷V2014
Description:流年、酷，酷炫
Version:V1.0
Author:缪汶臻
Author Url:http://www.ln920.cn
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 

?>
	<div id="sidebar">
<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>
<?php if(_g('tongji') == "yes"): ?>
	<div id="float" class="div1"><div id="bd_random_post_widget-2" class="widget_bd_random_post_widget"><h4 class="widgettitle">站点统计</h4> <?php $sta_cache = Cache::getInstance()->readCache('sta');?><ul class="xoxo siteInfo"><li>文章总数：<?php echo $sta_cache['lognum']; ?>篇</li><li>微语总数：<?php echo $sta_cache['twnum']; ?>条</li><li>评论总数：<?php echo $sta_cache['comnum']; ?>条</li><?php echo setAndShowFoot();?><li><span id="showsectime" style="color:#FF0000;"></span></li>
<script type="text/javascript">
function NewDate(str) { 
	str = str.split('-'); 
	var date = new Date(); 
	date.setUTCFullYear(str[0], str[1] - 1, str[2]); 
	date.setUTCHours(0, 0, 0, 0); 
	return date; 
} 
function showsectime() {
	//var str=$starttime;
	var birthDay =NewDate('<?php echo _g('yes');	?>');
	var today=new Date();
	var timeold=today.getTime()-birthDay.getTime();
	
	var sectimeold=timeold/1000
	var secondsold=Math.floor(sectimeold);
	var msPerDay=24*60*60*1000;

	var e_daysold=timeold/msPerDay;
	var daysold=Math.floor(e_daysold);
	var e_hrsold=(daysold-e_daysold)*-24;
	var hrsold=Math.floor(e_hrsold);
	var e_minsold=(hrsold-e_hrsold)*-60;
	var minsold=Math.floor((hrsold-e_hrsold)*-60);

	var seconds=Math.floor((minsold-e_minsold)*-60).toString();
	document.getElementById("showsectime").innerHTML = "网站已安全运行"+daysold+"天"+hrsold+"小时"+minsold+"分"+seconds+"秒";
	setTimeout(showsectime, 1000);
}

showsectime();
</script>
</ul></li></section>
<script>
(function(){
    var oDiv=document.getElementById("float");
    var H=0,iE6;
    var Y=oDiv;
    while(Y){H+=Y.offsetTop;Y=Y.offsetParent};
    iE6=window.ActiveXObject&&!window.XMLHttpRequest;
    if(!iE6){
        window.onscroll=function()
        {
            var s=document.body.scrollTop||document.documentElement.scrollTop;
            if(s>H){oDiv.className="div1 div2";if(iE6){oDiv.style.top=(s-H)+"px";}}
            else{oDiv.className="div1";}
        };
    }

})();
</script>
</div>
<?php else: ?>	
              <?php endif; ?>
</div>
<!--/sidebar -->
</div>
</div></div>
<!-- layout-container -->
</div>
	</div><!--[if !IE]>div_body end<![endif]-->
	</div>
<!--[if !IE]>div_all end<![endif]-->
	<!--/body --> 
