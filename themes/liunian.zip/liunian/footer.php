	<?php 
/**
页面底部信息
Template Name:流年、酷V2014
Description:流年、酷，酷炫
Version:V1.0
Author:缪汶臻
Author Url:http://www.ln920.cn
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 

?>
<?php if(_g('tougao') == 'yestougao'): ?>
<script type="text/javascript">
$(document).ready(function(){
	$(".side ul li").hover(function(){
		$(this).find(".sidebox").stop().animate({"width":"124px"},200).css({"opacity":"1","filter":"Alpha(opacity=100)","background":"#ae1c1c"})	
	},function(){
		$(this).find(".sidebox").stop().animate({"width":"54px"},200).css({"opacity":"0.8","filter":"Alpha(opacity=80)","background":"#000"})	
	});
	
});
</script>
<div class="side">
	<ul>
		<li><a href="<?php echo _g('yestougao');?>" target="_blank"><div class="sidebox"><img src="http://www.ln920.cn/content/templates/liunian/images/side_icon01.png">我要投稿</div></a></li>、
	</ul>
</div>
<?php else: ?><?php endif; ?>
<div id="roll">
 <div title="回到顶部" id="roll_top"></div>
 <div title="转到底部" id="fall"></div>
</div>
<?php if(_g('footer_side') == 'yes'): ?>
<div class="side-bar"> 
	<a href="http://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo _g('liunianQQ');?>&amp;site=qq&amp;menu=yes" class="icon-qq" target="_blank">QQ在线咨询</a> 
	<a href="" class="icon-chat">微信<div class="chat-tips"><i></i><img style="width:138px;height:138px;" src="<?php echo _g('side_weixin');?>" alt="微信订阅号"></div></a> 
	<a target="_blank" href="http://weibo.com/<?php echo _g('side_weibo');?>" class="icon-blog">微博</a> 
	<a href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=<?php echo _g('side_email');?>" target="_blank" class="icon-mail">mail</a> 
</div>
<?php else: ?><?php endif; ?>
	<div id="footer" class="pagewidth clearfix">

						  																<div class="col col4-1 first">
							 						</div>
				  												<div class="col col4-1 ">
							 						</div>
				  												<div class="col col4-1 ">
							 						</div>
				  												<div class="col col4-1 ">
							 						</div>
				  				
	<div class="footer-text">
			<center>&copy;<?php if(_g('icp_liunian') == 'yes'): ?><a href="http://www.miitbeian.gov.cn" target="_blank"><?php echo $icp; ?></a> &bull;<?php else: ?><?php endif; ?>  Copyright © 2014 - <?php				 
			echo date('Y',time()); ?><?php echo _g('blog_name');?> All Rights Reserved.Powered By <?php if(_g('liunian_bq') == 'url_y'): ?><?php
				 echo constant('MWZ');?><?php else: ?><?php endif; ?><?php if(_g('liunian_bq') == 'url_n'): ?>Theme By  流年、酷<?php else: ?><?php endif; ?> </center><center><?php echo _g('foot_liunian');?></center></div>

		<!--/footer-text -->

<script>$(function() {   
    $('.post-title a,.slide-post-title,.cat-item a,.widget_bd_random_post_widget a,.widget_recent_entries a,.widget_archive a').click(function(e) {   
        e.preventDefault();   
        var htm = '动态加载中...',   
        i = 4,   
        t = $(this).html(htm).unbind('click'); (function ct() {   
            i < 0 ? (i = 4, t.html(htm), ct()) : (t[0].innerHTML += '.',    
i--, setTimeout(ct, 150))   
        })();   
        window.location = this.href   
    })   
});  
</script>
<script>jQuery(document).ready(function($){       
$('.post-title a,.slide-post-title,.menu-item a,.cat-item a,.widget_bd_random_post_widget a,.widget_links a,.widget_tag_cloud a,.widget_recent_entries a,.widget_archive a').hover(function() {    
//.entry-title a      
$(this).stop().animate({'marginLeft': '10px'}, 260);           
}, function() {       
$(this).stop().animate({'marginLeft': '0px'}, 200);           
});       
});  </script>


	</div>
	<!--/footer --> 
</div>
<!--/pagewrap -->

		</div>

<!-- wp_footer -->
		<script type='text/javascript'>
		/////////////////////////////////////////////
		// Slider	 							
		/////////////////////////////////////////////
		jQuery(window).load(function(){
			
			if(jQuery('#header-slider').length > 0){
				jQuery('#header-slider .slides').carouFredSel({
					responsive: true,
					prev: '#header-slider .carousel-prev',
					next: '#header-slider .carousel-next',
					width: '100%',
					circular: true,
					infinite: true,
					auto: {
						play : true,
						pauseDuration: 3000,
						duration: 1000					},
					scroll: {
						items: 1,
						duration: 1000,
						wipe: true
					},
					items: {
						visible: {
							min: 1,
							max: 5						},
						width: 150
					},
					onCreate : function (){
						jQuery('#header-slider').css( {
							'height': 'auto',
							'visibility' : 'visible'
						});
					}
				});
			}
			
		});
		</script>
        <!-- Lightbox Plus Colorbox v2.7/1.5.9 - 2013.01.24 - Message: 1-->
<script type="text/javascript">
jQuery(document).ready(function($){
  $("a[data-lightboxplus*=lightbox]").each(function(){
    $(this).colorbox({rel:$(this).attr("data-lightboxplus"),transition:"fade",speed:0,width:false,height:false,innerWidth:false,innerHeight:false,initialWidth:false,initialHeight:false,maxWidth:false,maxHeight:false,scalePhotos:false,opacity:0.25,preloading:false,current:" {current}  {total}",previous:"",next:"",close:"",overlayClose:false,loop:false,arrowKey:false,top:false,right:false,bottom:false,left:false});
  });
  $(".lbp_secondary").each(function(){
    $(this).colorbox({rel:$(this).attr("data-lightboxplus"),speed:300,innerWidth:"50%",innerHeight:"50%",initialWidth:"30%",initialHeight:"40%",maxWidth:"90%",maxHeight:"90%",opacity:0.8,iframe:true});
  });
});
</script>
<?php if(_g('happy_new') == "yes"): ?>
<script type="text/javascript" language="javascript">
(function() {
    function k(a, b, c) {
        if (a.addEventListener) a.addEventListener(b, c, false);
        else a.attachEvent && a.attachEvent("on" + b, c)
    }
    function g(a) {
        if (typeof window.onload != "function") window.onload = a;
        else {
            var b = window.onload;
            window.onload = function() {
                b();
                a()
            }
        }
    }
    function h() {
        var a = {};
        for (type in {
            Top: "",
            Left: ""
        }) {
            var b = type == "Top" ? "Y": "X";
            if (typeof window["page" + b + "Offset"] != "undefined") 
a[type.toLowerCase()] = window["page" + b + "Offset"];
            else {
b = document.documentElement.clientHeight ? document.documentElement: document.body;
                a[type.toLowerCase()] = b["scroll" + type]
            }
        }
        return a
    }
    function l() {
        var a = document.body,
        b;
        if (window.innerHeight) b = window.innerHeight;
        else if (a.parentElement.clientHeight) b = a.parentElement.clientHeight;
        else if (a && a.clientHeight) b = a.clientHeight;
        return b
    }
    function i(a) {
        this.parent = document.body;
        this.createEl(this.parent, a);
        this.size = Math.random() * 11 + 11;
        this.el.style.width = Math.round(this.size) + "px";
        this.el.style.height = Math.round(this.size) + "px";
        this.maxLeft = document.body.offsetWidth - this.size;
        this.maxTop = document.body.offsetHeight - this.size;
        this.left = Math.random() * this.maxLeft;
        this.top = h().top + 1;
        this.angle = 1.4 + 0.2 * Math.random();
        this.minAngle = 1.4;
        this.maxAngle = 1.6;
        this.angleDelta = 0.01 * Math.random();
        this.speed = 2 + Math.random()
    }
    var j = false;
    g(function() {
        j = true
    });
    var f = true;
    window.createSnow = function(a, b) {
        if (j) {
            var c = [],
            m = setInterval(function() {
                f && b > c.length && Math.random() 
< b * 0.0025 && c.push(new i(a)); ! f && !c.length && clearInterval(m);
                for (var e = h().top, n = l(), d = c.length - 1; d >= 0; d--) 
if (c[d]) if (c[d].top < e || c[d].top + c[d].size + 1 > e + n) {
                    c[d].remove();
                    c[d] = null;
                    c.splice(d, 1)
                } else {
                    c[d].move();
                    c[d].draw()
                }
            },
            40);
            k(window, "scroll",
            function() {
                for (var e = c.length - 1; e >= 0; e--) c[e].draw()
            })
        } else g(function() {
            createSnow(a, b)
        })
    };
    window.removeSnow = function() {
        f = false
    };
    i.prototype = {
        createEl: function(a, b) {
            this.el = document.createElement("img");
            this.el.setAttribute
("src", b + "../content/templates/liunian/images/snow.gif");
            this.el.style.position = "absolute";
            this.el.style.display = "block";
            this.el.style.zIndex = "99999";
            this.parent.appendChild(this.el)
        },
        move: function() {
            if (this.angle < this.minAngle || this.angle > this.maxAngle) 
this.angleDelta = -this.angleDelta;
            this.angle += this.angleDelta;
            this.left += this.speed * Math.cos(this.angle * Math.PI);
            this.top -= this.speed * Math.sin(this.angle * Math.PI);
            if (this.left < 0) this.left = this.maxLeft;
            else if (this.left > this.maxLeft) this.left = 0
        },
        draw: function() {
            this.el.style.top = Math.round(this.top) + "px";
            this.el.style.left = Math.round(this.left) + "px"
        },
        remove: function() {
            this.parent.removeChild(this.el);
            this.parent = this.el = null
        }
    }
})();
createSnow("", 40);
</script>

<?php else: ?>

<?php endif; ?>
<script type="text/javascript" src="http://api.ichaotu.com/widget/sign?v=1.0&i=2l2_A1"></script>
 <!-- zp520.cn Baidu tongji analytics -->
<script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F33ad4d18dda1a56ff80f8eb07aeac69b' type='text/javascript'%3E%3C/script%3E"));
</script>
</BODY>
</HTML>
