<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div id="main">
	<div id="main_left">
	<div id="ml_content" class="narrowcolumn">
			<div class="post" id="post-<?php echo $logid ?>">
          <div class="post_title">
              <h2<?php if($top=='y'){echo " class=\"topflg\"";} ?>><?php topflg($top); ?><?php echo $log_title;?></h2>
              <div class="postinfo"><?php blog_sort($logid); ?> post by <?php blog_author($author); ?> / <?php echo date('Y-n-j H:i l', $date); ?> <?php editflg($logid,$author); ?></div>
          </div>
          <div class="post_content clear">
              <?php echo $log_content; ?>
              <div class="fujian"><?php blog_att($logid); ?></div>
          </div>
          <div class="post_meta">
            <div class="post_tag"><?php blog_tag($logid); ?></div>
            <div class="pmetainfo">
                评论(<?php echo $comnum; ?>) 引用(<?php echo $tbcount; ?>) 浏览(<?php echo $views; ?>)
            </div>
            <div class="clear"></div>
          </div>
          <?php doAction('log_related', $logData); ?>
          <div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
          <div class="blog_tb"><?php blog_trackback($tb, $tb_url, $allow_tb); ?></div>
      </div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
  </div>
  </div>
<?php include View::getView('side');?><div class="clear"></div>
</div>
<?php include View::getView('footer'); ?>