

var stvar=0;
function getstvar(){
  if(document.documentElement.scrollTop){
    stvar=document.documentElement.scrollTop;
  }else{
    stvar=document.body.scrollTop;
  }
}

function movetop(){
  getstvar();
  if(stvar>=1){
    movetop_fc();
    sto = setTimeout('movetop()',20);
  }else{
    stvar=0;
    clearTimeout(sto);
  }
}
function movetop_fc(){
  if(document.documentElement.scrollTop){
    document.documentElement.scrollTop-=Math.ceil(stvar/5);
  }else{
    document.body.scrollTop-=Math.ceil(stvar/5);
  }
}


function colortags(){
  var colorarr=['#e050c3','#66b82b','#4646be','#406ecd','#098','#e97238','#4cb','#c55'];
  if(document.getElementById('blogtags')){
    var bt=document.getElementById('blogtags');
    if(bt.getElementsByTagName('a')){
    var bta=bt.getElementsByTagName('a');
      for(i=0;i<bta.length;i++){
        n=Math.floor(Math.random()*colorarr.length);
        bta[i].style.color=colorarr[n];
      }
    }
  }
}

function addfav(vtitle,vsite){
  vtitle=vtitle?vititle:document.title;
  vsite=vsite?vsite:window.location.href;
  if(document.all){
    window.external.addFavorite(vsite,vtitle);
  }else if(window.sidebar){
    window.sidebar.addPanel(vtitle,vsite,'');
  }else{
    alert('当前浏览器无法自动添加收藏，请手动添加');
  }
}

window.onload=function(){colortags();}