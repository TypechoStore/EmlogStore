<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
			<div id="contentleft">
<?php doAction('index_loglist_top'); ?>
<?php 
if (!empty($logs)):
foreach($logs as $key=>$value): 
$search_pattern = '%<img[^>]*?src=[\'\"]((?:(?!\/admin\/|>).)+?)[\'\"][^>]*?>%s';
preg_match($search_pattern, $value['content'], $img);
$value['img'] = isset($img[1])?$img[1]:TEMPLATE_URL.'pic/ap'.rand(1,15).'.jpg';
?>
				<div class="clist<?php if($key == 0){echo ' fbg';}; ?>">
                	<ul class="ainfo">
                        <li>Author:<br /><?php blog_author($value['author']); ?></li>
                    	<li><?php echo gmdate('n.j G:i', $value['date']); ?></li>
                        <li>发布在<br /><?php blog_sort($value['logid']); ?></li>
                        <li><a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?> Comments</a></li>				
                        <li><a href="<?php echo $value['log_url']; ?>" class="views"><?php echo $value['views']; ?></a>&nbsp;&nbsp;&nbsp;<?php editflg($value['logid'],$value['author']); ?></li>
                    </ul>
                    <dl class="apost">
                    	<dt><a href="<?php echo $value['log_url']; ?>"><img src="<?php echo $value['img']; ?>"/></a></dt>
                        <dd>
							<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
							<p><?php echo subString(strip_tags($value['log_description']),0,200,"..."); ?></p>
							<p class="tag"><?php blog_tag($value['logid']); ?></p>
						</dd>
					</dl>
				</div>
<?php 
endforeach;
else:
?>
				<div class="clist">
                    <h2>未找到</h2>
                    <p><br />抱歉，没有符合您查询条件的结果。</p>
				</div>
<?php endif;?>
                <div id="pagenavi">
                    <?php echo $page_url;?>
                </div>
				<dl id="ilink">
                    <?php index_link();?>
                </dl>
			</div><!-- end #contentleft-->
		</div><!--end #content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>