<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>
<div id="postpage">
	<div id="pagenav">
    	<?php blog_navi();?>
    </div>
	<h1><?php echo $log_title; ?></h1>
    <div id="pagebox">
		<?php echo $log_content; ?>
    </div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
<?php
 include View::getView('footer');
?>