<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
			<div id="contentleft">
            	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
                <div id="logbox">
                	<ul class="ainfo">
                        <li>Author:<br /><?php blog_author($author); ?></li>
                    	<li><?php echo gmdate('n.j G:i', $date); ?> </li>
                        <li>发布在<br />[<?php blog_sort($logid); ?>]</li>
                        <li class="tag"><?php blog_tag($logid); ?></li>
                        <li><a href="<?php echo $value['log_url']; ?>" class="views"><?php echo $views; ?></a>&nbsp;&nbsp;&nbsp;<?php editflg($logid,$author); ?></li>
                        <li><a href="<?php echo $value['log_url']; ?>#comments"><?php echo $comnum; ?> Comments</a></li>
                        <li class="tsize"><a href="javascript:void(0)" id="tbig">大字</a><a href="javascript:void(0)" id="noimg">去图</a><a href="javascript:void(0)" id="default">默认</a></li>
                    </ul>
                    <div id="ctmid">
						<h1><?php topflg($top); ?><a href="<?php echo Url::log($logid); ?>"><?php echo $log_title; ?></a></h1>
                        <div id="postlog">
							<?php echo $log_content; ?>
                        </div>
    				</div>
    			</div>
                <div class="logad728">
<?php echo $logbtad;?>
                </div>
                <ul class="logxlist">
                	<?php get_list($sortid);?>
                </ul>
	<?php doAction('log_related', $logData); ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
			</div><!--end #contentleft-->
		</div><!--end #content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>