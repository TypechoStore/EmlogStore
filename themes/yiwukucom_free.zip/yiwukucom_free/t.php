<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
			<div id="contentleft">
				<div id="tw">
    <ul>
	<li><br /><br />该模板[免费版]没有开启微语功能。</li>
    <li><br /><br />如有需要可以联系模板作者购买收费版，谢谢支持！</li>
    </ul>
				</div><!--end #tw-->
			</div><!--end #contentleft-->
		</div><!--end #content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>