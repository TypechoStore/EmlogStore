<?php
/*
Template Name:异物酷[免费版]
Description:异物酷黑时尚模板，源自www.yiwuku.com
Version:1.5
Author:qq77940140
Author Url:http://www.yiwuku.com
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
require_once View::getView('option');
if(function_exists('emLoadJQuery')) {
    emLoadJQuery();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<script type="text/javascript">
var datn = "js";
document.writeln(unescape("%3Cscript src='<?php echo TEMPLATE_URL; ?>js/ywk." + datn + "' type='text/javascript'%3E%3C/script%3E"));
</script>
<!--[if IE 6]><script src="<?php echo TEMPLATE_URL; ?>js/IE6_PNG.js"></script><![endif]-->
</head>
<body>
<div id="bigbox">
	<div id="wrap">
		<div id="content">
            <div id="topcake">
            	<?php top_random_log();?>
            </div>
            <div id="header">
                <div id="ylogo"><a href="<?php echo BLOG_URL; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/ylogo.png" alt="<?php echo $blogname; ?>" /></a></div>
                <div id="topnav">
    <a href="<?php echo $liuyanurl;?>"><img src="<?php echo TEMPLATE_URL; ?>images/chat.png" />交流</a><span class="gk"></span><a rel="nofollow" href="<?php echo $dmailurl;?>" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/mail.png" />邮件订阅</a><span class="gk"></span><a href="<?php echo BLOG_URL; ?>rss.php" title="RSS订阅" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/rss.gif" alt="订阅Rss" />RSS</a><span class="gk"></span><?php if(ROLE == 'admin' || ROLE == 'writer'): ?><a href="<?php echo BLOG_URL; ?>admin/">网站管理</a>&nbsp;&nbsp;<a href="<?php echo BLOG_URL; ?>admin/?action=logout">[退出]</a><?php else: ?><a href="<?php echo BLOG_URL; ?>admin/">登录</a><?php endif; ?>
                </div>
            </div>
            <div id="ibird" title="看看是什么？"></div>
