<?php
/*
 * 异物酷黑时尚模板配置文件
 * 如果您确定足够了解以下内容，则可以尝试自行修改，修改前务必仔细查看相关注释【注意：切勿用记事本编辑保存】
 */


//全局链接

$liuyanurl = "http://www.yiwuku.com/liuyan.html";//头部交流和页脚留言建议链接地址
$dmailurl = "http://www.yiwuku.com/";//头部邮件订阅地址
$fldname = "YIWUKU.COM";//页脚左边标志文字

$iqq = "12345678";//页脚QQ交流号码


//广告内容

$allrad = '
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- ewceo300 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-5564933136939792"
     data-ad-slot="6483030302"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>';//右侧边栏300*250广告

$logbtad = '
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- GG728 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-5564933136939792"
     data-ad-slot="4578849909"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>';//日志内容下方728*90广告




?>
