<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
		<div id="footerbar">
        	<div id="footbox">
                <p class="footdm"><?php echo $fldname;?></p>
<!--注意：当前模板免费版需要您保留模板作者信息，强行修改可能导致出错。支持收费版请联系Q77940140或见模板包内说明文件-->
                <p class="footerbox">
    <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="<?php echo BLOG_URL; ?>m">手机访问</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="<?php echo BLOG_URL; ?>rss.php">RSS信息</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="<?php echo $liuyanurl;?>">留言建议</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $iqq;?>&site=qq&menu=yes" title="点击Q我" rel="nofollow">QQ交流</a>&nbsp;&nbsp;|&nbsp;&nbsp;<?php echo $footer_info; ?><a rel="nofollow"><?php echo $icp; ?></a><br />
    <span>All Rights Reserved. Powered by <a rel="nofollow" href="http://bbs.emlog.net" target="_blank" title="emlog <?php echo Option::EMLOG_VERSION;?>">Emlog</a>&nbsp;&amp;&nbsp;<?php systemer();?></span><br />
                </p>
<?php doAction('index_footer'); ?>
			</div>
		</div><!--end #footerbar-->
	</div><!--end #wrap-->
</div><!--end #bigbox-->
<div id="backtop"><a href="javascript:scroll(0,0)">返回顶部</a></div>
</body>
</html>