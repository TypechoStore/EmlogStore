<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="main">
<div class="clear"></div>
<div class="content_text">
	<div class="content_header">
    	<h1><?php echo $log_title; ?></h1> 
    </div><!--end of content_header-->
    <div class="clear"></div>
    <div class="post_content" style="text-indent: 0em;;">
	<?php echo $log_content; ?>
	</div>
</div><!--content_text End-->
<div id="comments">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>

</div>
</div><!--end of main-->
<?php
 include View::getView('side');
?>
 </div><!--end of content-->
<?php
 include View::getView('footer');
?>