<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="main">
<div class="content_text">
	<div class="content_header">
    	<h1><?php topflg($top); ?><?php echo $log_title; ?></h1> 
    	<div class="meta">分类：<?php blog_sort($logid); ?><?php blog_tag($logid); ?> <span style="float:right">评论(<?php echo $comnum; ?>) 浏览(<?php echo $views; ?>)&nbsp;&nbsp;<?php editflg($logid,$author); ?></span></div>
    </div><!--end of content_header-->
    <div class="post_content">
	<?php echo $log_content; ?>
	</div>
</div><!--content_text End-->
	<div class="att"><?php blog_att($logid); ?></div>
	<?php doAction('log_related', $logData); ?>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
    <div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
    <div style="clear:both;"></div>
<div id="comments">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
</div>
</div><!--end of main-->
<?php
 include View::getView('side');
?>
 </div><!--end of content-->
<?php
 include View::getView('footer');
?>