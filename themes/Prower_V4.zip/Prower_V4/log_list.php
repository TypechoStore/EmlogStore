<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php doAction('index_loglist_top'); ?>
<div id="content">
<div id="main">
<ul id="post_list">
<?php foreach($logs as $value): ?>
    <li class="post">
	<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
	<div class="meta"><?php echo gmdate('Y-n-j G:i', $value['date']); ?><span style="float:right"><?php editflg($value['logid'],$value['author']); ?></span>
    </div>
        <div class="excerpt">
        <?php echo $value['log_description']; ?>
        	<div class="meta">
            分类:<?php blog_sort($value['logid']); ?> | <?php blog_tag($value['logid']); ?>
            </div>
        </div>
<?php endforeach; ?>
</ul><!--end of post_list-->

<div id="pagenavi">
	<?php echo $page_url;?>
</div>

</div><!--end of main-->

<?php
 include View::getView('side');
?>
 </div><!--end of content-->
<?php
 include View::getView('footer');
?>