<?php
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div style="clear:both;"></div>
<div id="footer">
<p>
&copy; <?php echo date(Y); ?> <a href=<?php echo BLOG_URL;?>><?php echo $blogname; ?></a>. Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">Emlog.</a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> Theme by <a href="http://www.prower.cn/"  target="_blank">Prower</a>, modified by <a href="http://yemaz.com/"  target="_blank">野马</a><?php echo $footer_info; ?><!--请保留emlog以及模板作者的链接，这也是对你自己的尊重！-->
<?php doAction('index_footer'); ?>
</p>
</div>
</div>
</body>
</html>