<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
$weekarr= array('星期日','星期一','星期二','星期三','星期四','星期五','星期六');
?>
<?php doAction('index_loglist_top'); ?>
<?php
if(isset($sortName)){
  echo '<div class="pagetitle">▨&nbsp;类别《<span>'.$sortName.'</span>》下的文章:</div>';
}
if(isset($record)) {
  if(strlen($record)>6){
    echo '<div class="pagetitle">▨&nbsp;写于<span>'.substr($record,0,4).'年'.substr($record,4,2).'月'.substr($record,6,2).'日</span>的文章:</div>';
  }else{
    echo '<div class="pagetitle">▨&nbsp;写于<span>'.substr($record,0,4).'年'.substr($record,4,2).'月</span>的文章:</div>';
  }
}
if(isset($tag)) echo '<div class="pagetitle">▨&nbsp;标签《<span>'.$tag.'</span>》下的文章:</div>';
if(isset($keyword)) echo '<div class="pagetitle">▨&nbsp;搜索关键词为『<span>'.$keyword.'</span>』的文章:</div>';
if(isset($author)) echo '<div class="pagetitle">▨&nbsp;作者"<span>'.$user_cache[$author]['name'].'</span>"的文章:</div>';
?>
<?php foreach($logs as $value): ?>

<div id="post" class="post-home">
  <div class="post-title">
    <h1>
      <?php topflg($value['top']); ?>
      <a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></h1>
  </div>
  <div class="post-content"> <?php echo $value['log_description']; ?> </div>
  <div class="post-messages">
    <div class="post-messages-1"><?php echo gmdate('Y-n-j G:i', $value['date']); ?> / 标签:
      <?php blog_tag($value['logid']); ?>
      / 分类:
      <?php blog_sort($value['logid']); ?>
    </div>
  </div>
  <div class="post-messages-2"><a href="<?php echo $value['log_url']; ?>#comments" title="<?php echo $value['log_title']; ?>上的评论"><?php echo $value['comnum']; ?>°</a></div>
</div>
<?php endforeach; ?>
<?php if($page_url) echo ' <div id="pagenav">'.$page_url.'</div>' ?>
<script type="text/javascript">$("#home-loading div").animate({width:"400px"})</script>
</div>
<!--end content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>
