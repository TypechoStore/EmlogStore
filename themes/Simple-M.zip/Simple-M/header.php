<?php
/*
Template Name:Simple-M
Description:WP经典主题Simple-M for Emlog
Version:2.0
Author:Sogei
Author Url:http://zld.me
Sidebar Amount:1
ForEmlog:4.1.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="stylesheet" type="text/css" media="all" href="<?php echo TEMPLATE_URL; ?>style.css" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.min.1.4.0.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/common_tpl.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/Simple-M.js"></script>
<?php doAction('index_head'); ?>
</head>

<body>
<div id="header">
  <div id="home-loading">
    <div></div>
  </div>
  <script type="text/javascript">$("#home-loading div").animate({width:"150px"})</script>
  <div id="logo"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>
    <div class="description"><?php echo $bloginfo; ?></div>
  </div>
  <div id="social" style="float:right; margin-top:10px;"><a class="rss" target="_blank" href="<?php echo BLOG_URL; ?>rss.php" title="订阅本站"></a></div>
</div>
<script type="text/javascript"> $("#home-loading div").animate({width:"200px"}) </script>
<div id="menu">
  <ul>
    <?php if(isset($curpage)){ ?>
    <li<?php echo $curpage == CURPAGE_HOME ? ' class="current-cat"' : ''; ?>><a href="<?php echo BLOG_URL; ?>">首页</a></li>
    <li<?php echo $curpage == CURPAGE_TW ? ' class="current-cat"' : ''; ?>><a href="<?php echo BLOG_URL; ?>t/">微语</a></li>
    <?php }else{ ?>
    <li<?php echo empty($_GET) ?  ' class="current-cat"' : ''; ?>><a href="<?php echo BLOG_URL; ?>">首页</a></li>
    <?php } ?>
    <?php
global $CACHE; 
$navi_cache = $CACHE->readCache('navi');
foreach ($navi_cache as $key => $val):
if ($val['hide'] == 'y'){continue;}
if (empty($val['url'])){$val['url'] = Url::log($key);}
$newtab = $val['newtab'] == 'y' ? 'target="_blank"' : '';
?>
    <li<?php echo isset($logid) && $logid == $key ? ' class="current-cat"' : ''; ?>><a href="<?php echo $val['url']; ?>" target="<?php echo $newtab; ?>"><?php echo $val['naviname']; ?></a></li>
    <?php endforeach;?>
    <?php doAction('navbar', '<li>', '</li>'); ?>
    <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
    <li><a href="<?php echo BLOG_URL; ?>admin/write_log.php"><span>写日志</span></a></li>
    <li><a href="<?php echo BLOG_URL; ?>admin/"><span>管理</span></a></li>
    <li><a href="<?php echo BLOG_URL; ?>admin/?action=logout"><span>退出</span></a></li>
	<?php else: ?>
	<li class="common"><a href="<?php echo BLOG_URL; ?>admin/">登录</a></li>
	<?php endif; ?>
    <div id="close-sidebar">
      <li class="close-bar" "current-cat" style="float:right;"><a rel="nofollow" href="#" title="隐藏侧边栏">隐藏侧边栏</a></li>
    </div>
  </ul>
</div>
<div id="content">
<script type="text/javascript">$("#home-loading div").animate({width:"300px"})</script>
<div id="postlist">