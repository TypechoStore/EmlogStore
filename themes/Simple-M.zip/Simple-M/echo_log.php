<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div class="post-single">
  <div class="post-title">
    <h1>
      <?php topflg($top); ?>
      <?php echo $log_title; ?></h1>
  </div>
  <div class="post-messages">
    <div class="post-messages-1"><?php echo gmdate('Y-n-j G:i', $date); ?> / 标签:
      <?php blog_tag($logid); ?>
      / 分类:
      <?php blog_sort($logid); ?>
    </div>
    <div class="post-messages-2">
      <?php blog_author($author); ?>
      <?php editflg($logid,$author); ?>
    </div>
  </div>
  <div class="post-content"> <?php echo $log_content; ?>
    <?php blog_att($logid); ?>
    <p class='crinfo'> 版权所有：<a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>"><?php echo $blogname; ?></a> <a rel="bookmark" title="<?php echo $log_title; ?>" href="<?php echo $value['log_url']; ?>">《 <?php echo $log_title; ?>》</a><br />
      <?php blog_trackback($tb, $tb_url, $allow_tb); ?>
      站长声明：除特别标注,本站所有文章均为原创. 互联分享,尊重版权,转载注明出处</p>
    <br />
    <div class="frontback">
      <?php neighbor_log($neighborLog); ?>
    </div>
    <div id="single-bottom">
      <div id="share" style="float: left;">赶快分享到: <a id="renren-share" title="人人网" rel="nofollow">人人网</a> <a id="tencent-share" title="腾讯微博" rel="nofollow">腾讯微博</a> <a id="sina-share" title="新浪微博" rel="nofollow">新浪微博</a> <a id="netease-share" title="网易微博" rel="nofollow">网易微博</a> <a id="douban-share" title="豆瓣" rel="nofollow">豆瓣</a> <a id="ico_mop" title="猫扑" rel="nofollow">猫扑</a> <a id="baidu-share" title="百度" rel="nofollow">百度</a> <a id="kaixin001-share" title="开心网" rel="nofollow">开心网</a> <a id="qzone-share" title="QQ空间" rel="nofollow">QQ空间</a> <a id="pengyou-share" title="腾讯朋友" rel="nofollow">腾讯朋友</a> <a id="facebook-share" title="facebook" rel="nofollow">facebook</a> <a id="twitter-share" title="twitter" rel="nofollow">twitter</a></div>
      <div id="single-rss" style="float: right;">订阅博文: <a class="rss-feed" title="订阅博客文章" rel="nofollow external" href="<?php echo BLOG_URL; ?>rss.php">RSS Feed</a></div>
    </div>
  </div>
  <div class="related_posts">
    <ul>
      <?php doAction('log_related', $logData); ?>
    </ul>
  </div>
</div>
<div id="comments">
  <div style="margin:.5em 0 1em" id="comment-path">
    <h3 style="font-weight: bold; color: #666;"><?php echo $views; ?> 人围观 / <?php echo $comnum; ?> 条评论 <a style="font-weight: bold;margin-left:1em;color:#FF6600" class="bling" href="#comment">↓快速评论↓</a> </h3>
  </div>
  <?php blog_comments($comments); ?>
  <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
</div>

<!--end content-->

<?php
 include View::getView('side');
 include View::getView('footer');
?>
