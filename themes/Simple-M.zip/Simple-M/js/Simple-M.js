﻿eval(function(p, a, c, k, e, d) {
	e = function(c) {
		return (c < a ? '': e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) : c.toString(36))
	};
	if (!''.replace(/^/, String)) {
		while (c--) {
			d[e(c)] = k[c] || e(c)
		}
		k = [function(e) {
			return d[e]
		}];
		e = function() {
			return '\\w+'
		};
		c = 1
	};
	while (c--) {
		if (k[c]) {
			p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c])
		}
	}
	return p
} ('1A(1h).2d(4($){$(".2V a").1f({2B:"2C"});$("a[10*=\'3n://\']:2q([10*=\'"+1S.2F+"\']),[10*=\'3o://\']:2q([10*=\'"+1S.2F+"\'])").1B("35").1f("2B","2C");$(".19-3S .19-1s").6(4(){7($(5).Y().42(":3Z")){$(5).15().15().1C("页面载入中……");1k.1S=$(5).15().15().1f("10")}1D{$(".19-2z").1V(1y),$("#1x .19-1s").1M("6");$("#1x .19-2D-1").1M("6");$("#1x .19-2D-2").1M("6"),$(5).1B("6");$(5).Y().Y().15().1B("6");$(5).Y().Y().Y().1B("6");$(5).Y().1Y(1y,4(){$12.14({Z:$(5).28().1e-3V},18)});9 1g}});$("#1x .19-1s 3W:45").6();$(".19-2z a:4e(4f)").1l();$("#49-1T a").1W(4(){$(5).1C("显示侧边栏");$("#1T").1P().2x().14({16:"3T"},23)},4(){$(5).1C("隐藏侧边栏");$("#1T").3D(2N).1v(0).2x().14({16:"3A"},2N)});$(".1n-12").3R(4(){7($(5).Y("#3N").1b>0){$("#2f-1n-1t a").6()}1D{$(5).15(".1t").15("a").6()}9 1g});$("#29 .3M 3J").1W(4(){$(5).1o().1o().Y().1V("1Z")},4(){$(5).1o().1o().Y().1Y("1Z")});$(".3H-3").15(".15").3w(".1t").6(4(){13 2h=$(5).1o().1f("X");13 2g=$(5).Y().1C();$("#1n").1f("2m","<a 10=\'#"+2h+"\'>@"+2g+"</a> ").48()});$("#2f-1n-1t-46").6(4(){$("#1n").1f("2m","")})});1A(1h).2d(4($){$12=(1k.3Q)?(1h.2Z=="2Y"?$("1q"):$("12")):$("1q,12");$("#33").2a(4(){1Q()}).2b(4(){2c(1w)}).6(4(){$12.14({Z:0},18)});$("#32").2a(4(){1R()}).2b(4(){2c(1w)}).6(4(){$12.14({Z:$(1h).1a()},18)});$("#2Q").6(4(){$12.14({Z:$("#29").28().1e},18)});$(4(){3q(24,23)});4 24(){$(".3f").2G(1y).1F(1y)}});4 1Q(){$1i=$(1k);$1i.Z($1i.Z()-1);1w=25("1Q()",26)};4 1R(){$1i=$(1k);$1i.Z($1i.Z()+1);1w=25("1R()",26)};(4(w){13 E=w(1k),u,f,F=-1,n,x,D,v,y,L,r,m=!1k.3j,s=[],l=1h.3s,k={},t=1G 1r(),J=1G 1r(),H,a,g,p,I,d,G,c,A,K;w(4(){w("12").1z(w([H=w("<17 X=\\"3p\\" />")[0],a=w("<17 X=\\"3m\\" />")[0],G=w("<17 X=\\"38\\" />")[0]]).11("1p","2J"));g=w("<17 X=\\"3u\\" />").2e(a).1z(p=w("<17 1c=\\"1N: 36;\\" />").1z([I=w("<a X=\\"2R\\" 10=\\"#\\" />").6(B)[0],d=w("<a X=\\"2S\\" 10=\\"#\\" />").6(e)[0]])[0])[0];c=w("<17 X=\\"2T\\" />").2e(G).1z([w("<a X=\\"2P\\" 10=\\"#\\" />").2o(H).6(C)[0],A=w("<17 X=\\"2U\\" />")[0],K=w("<17 X=\\"34\\" />")[0],w("<17 1c=\\"31: 30;\\" />")[0]])[0]});w.1l=4(O,N,M){u=w.2W({1m:1g,22:0.8,1O:18,1I:18,1E:"2X",2n:2l,2k:2l,2t:18,2s:18,2L:"1r {x} 3r {y}",20:[27,40,41],1X:[37,43],2p:[39,3Y]},M);7(3U O=="3v"){O=[[O,N]];N=0}y=E.Z()+(E.1a()/2);L=u.2n;r=u.2k;w(a).11({1e:2I.2v(0,y-(r/2)),16:L,1a:r,1K:-L/2}).1v();v=m||(H.2j&&(H.2j.1N!="3X"));7(v){H.1c.1N="44"}w(H).11("2u",u.22).1F(u.1O);z();j(1);f=O;u.1m=u.1m&&(f.1b>1);9 b(N)};w.4c.1l=4(M,P,O){P=P||4(Q){9[Q.10,Q.1s]};O=O||4(){9 2H};13 N=5;9 N.1U("6").6(4(){13 S=5,U=0,T,Q=0,R;T=w.4b(N,4(W,V){9 O.4a(S,W,V)});47(R=T.1b;Q<R;++Q){7(T[Q]==S){U=Q}T[Q]=P(T[Q],Q)}9 w.1l(T,U,M)})};4 z(){13 N=E.4d(),M=E.16();w([a,G]).11("2i",N+(M/2));7(v){w(H).11({2i:N,1e:E.Z(),16:M,1a:E.1a()})}};4 j(M){7(M){w("3C").2o(m?"3E":"3F").21(4(O,P){s[O]=[P,P.1c.1d];P.1c.1d="1L"})}1D{w.21(s,4(O,P){P[0].1c.1d=P[1]});s=[]}13 N=M?"3x":"1U";E[N]("3y 3z",z);w(1h)[N]("3G",o)};4 o(O){13 N=O.3O,M=w.3P;9(M(N,u.20)>=0)?C():(M(N,u.2p)>=0)?e():(M(N,u.1X)>=0)?B():1g};4 B(){9 b(x)};4 e(){9 b(D)};4 b(M){7(M>=0){F=M;n=f[F][0];x=(F||(u.1m?f.1b:0))-1;D=((F+1)%f.1b)||(u.1m?0:-1);q();a.2A="3L";k=1G 1r();k.2y=i;k.1j=n}9 1g};4 i(){a.2A="";w(g).11({3K:"3I("+n+")",1d:"1L",1p:""});w(p).16(k.16);w([p,I,d]).1a(k.1a);w(A).1q(f[F][1]||"");w(K).1q((((f.1b>1)&&u.2L)||"").2M(/{x}/,F+1).2M(/{y}/,f.1b));7(x>=0){t.1j=f[x][0]}7(D>=0){J.1j=f[D][0]}L=g.2w;r=g.1H;13 M=2I.2v(0,y-(r/2));7(a.1H!=r){w(a).14({1a:r,1e:M},u.1I,u.1E)}7(a.2w!=L){w(a).14({16:L,1K:-L/2},u.1I,u.1E)}w(a).3B(4(){w(G).11({16:L,1e:M+r,1K:-L/2,1d:"1L",1p:""});w(g).11({1p:"2J",1d:"",2u:""}).1F(u.2t,h)})};4 h(){7(x>=0){w(I).1v()}7(D>=0){w(d).1v()}w(c).11("2r",-c.1H).14({2r:0},u.2s);G.1c.1d=""};4 q(){k.2y=2K;k.1j=t.1j=J.1j=n;w([a,g,c]).2E(2H);w([I,d,g,G]).1P()};4 C(){7(F>=0){q();F=x=D=-1;w(a).1P();w(H).2E().2G(u.1O,j)}9 1g}})(1A);7(!/3k|3d|3b|3a|3e|3i 3h|3g/i.3c(3t.3l)){1A(4($){$("a[1u^=\'2O\']").1l({},2K,4(1J){9(5==1J)||((5.1u.1b>8)&&(5.1u==1J.1u))})})}', 62, 264, '||||function|this|click|if||return||||||||||||||||||||||||||||||||||||||||||||||||||id|next|scrollTop|href|css|body|var|animate|children|width|div|400|post|height|length|style|visibility|top|attr|false|document|wd|src|window|slimbox|loop|comment|parent|display|html|Image|title|reply|rel|show|fq|postlist|500|append|jQuery|addClass|text|else|resizeEasing|fadeIn|new|offsetHeight|resizeDuration|el|marginLeft|hidden|removeClass|position|overlayFadeDuration|hide|up|dn|location|sidebar|unbind|slideUp|toggle|previousKeys|slideDown|2000|closeKeys|each|overlayOpacity|1000|_3|setTimeout|50||offset|comments|mouseover|mouseout|clearTimeout|ready|appendTo|cancel|_2|_1|left|currentStyle|initialHeight|250|value|initialWidth|add|nextKeys|not|marginTop|captionAnimationDuration|imageFadeDuration|opacity|max|offsetWidth|prev|onload|content|className|target|_blank|messages|stop|hostname|fadeOut|true|Math|none|null|counterText|replace|800|lightbox|lbCloseLink|comt|lbPrevLink|lbNextLink|lbBottom|lbCaption|vcard|extend|swing|CSS1Compat|compatMode|both|clear|xia|shang|lbNumber|external|relative||lbBottomContainer||series60|ipod|test|iphone|symbian|bling|blackberry|ce|windows|XMLHttpRequest|android|userAgent|lbCenter|http|https|lbOverlay|setInterval|of|documentElement|navigator|lbImage|string|find|bind|scroll|resize|700px|queue|object|delay|select|embed|keydown|depth|url|span|backgroundImage|lbLoading|commentmetadata|respond|keyCode|inArray|opera|dblclick|home|960px|typeof|200|h1|fixed|78|visible|88|67|is|80|absolute|first|link|for|focus|close|call|grep|fn|scrollLeft|has'.split('|'), 0, {}))
$('#expand_collapse,.archives-yearmonth').css({
	cursor: "s-resize"
});
$('#archives ul li ul.archives-monthlisting').hide();
$('#archives ul li ul.archives-monthlisting:first').show();
$('#archives ul li span.archives-yearmonth').click(function() {
	$(this).next().slideToggle('fast');
	return false
});
$('#expand_collapse').toggle(function() {
	$('#archives ul li ul.archives-monthlisting').slideDown('fast')
},
function() {
	$('#archives ul li ul.archives-monthlisting').slideUp('fast')
});
jQuery(document).ready(function($) {
	function addListener(node, type, listener, obj) {
		var param = obj || {};
		if (node.addEventListener) {
			node.addEventListener(type,
			function(ev) {
				listener(ev, param)
			},
			false);
			return true
		} else if (node.attachEvent) {
			node['e' + type + listener] = listener;
			node[type + listener] = function() {
				node['e' + type + listener](window.event, param)
			};
			node.attachEvent('on' + type, node[type + listener]);
			return true
		}
		return false
	}
	function getParamsOfShareWindow(width, height) {
		return ['toolbar=0,status=0,resizable=1,width=' + width + ',height=' + height + ',left=', (screen.width - width) / 2, ',top=', (screen.height - height) / 2].join('')
	}
	function bindShareList() {
		var link = encodeURIComponent(document.location);
		var title = encodeURIComponent(document.title.substring(0, 76));
		var source = encodeURIComponent('自留地');
		var windowName = 'share';
		var site = 'http://www.zld.me/';
		
		addListener(document.getElementById('renren-share'), 'click',
		function() {
			var url = 'http://share.renren.com/share/buttonshare?link=' + link + '&title=' + title;
			var params = getParamsOfShareWindow(634, 468);
			window.open(url, windowName, params)
		});
		addListener(document.getElementById('tencent-share'), 'click',
		function() {
			var url = 'http://v.t.qq.com/share/share.php?title=' + title + '&source=' + source + '&url=' + link;
			var params = getParamsOfShareWindow(634, 468);
			window.open(url, windowName, params)
		});
		addListener(document.getElementById('sina-share'), 'click',
		function() {
			var url = 'http://v.t.sina.com.cn/share/share.php?url=' + link + '&amp;title=' + title + '&site=' + site;
			var params = getParamsOfShareWindow(634, 468);
			window.open(url, windowName, params)
		});
		addListener(document.getElementById('netease-share'), 'click',
		function() {
			var url = 'http://t.163.com/article/user/checkLogin.do?link=' + link + 'source=' + source + '&amp;info=' + title + ' ' + link;
			var params = getParamsOfShareWindow(642, 468);
			window.open(url, windowName, params)
		});
		addListener(document.getElementById('douban-share'), 'click',
		function() {
			var url = 'http://www.douban.com/recommend/?url=' + link + '&amp;title=' + title + '&site=' + site;
			var params = getParamsOfShareWindow(634, 468);
			window.open(url, windowName, params)
		});
		addListener(document.getElementById('ico_mop'), 'click',
		function() {
			var url = 'http://tt.mop.com/share/shareV.jsp?u=' + link + '&amp;t=' + title;
			var params = getParamsOfShareWindow(634, 468);
			window.open(url, windowName, params)
		});
		addListener(document.getElementById('baidu-share'), 'click',
		function() {
			var url = 'http://tieba.baidu.com/i/app/open_share_api?link=' + link + '&amp;t=' + title;
			var params = getParamsOfShareWindow(634, 468);
			window.open(url, windowName, params)
		});
		addListener(document.getElementById('kaixin001-share'), 'click',
		function() {
			var url = 'http://www.kaixin001.com/repaste/share.php?rurl=' + link + '&amp;rcontent=' + link + '&amp;rtitle=' + title;
			var params = getParamsOfShareWindow(634, 468);
			window.open(url, windowName, params)
		});
		addListener(document.getElementById('qzone-share'), 'click',
		function() {
			var url = 'http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=' + link + '&amp;t=' + title;
			var params = getParamsOfShareWindow(634, 468);
			window.open(url, windowName, params)
		});
		addListener(document.getElementById('pengyou-share'), 'click',
		function() {
			var url = 'http://www.pengyou.com/index.php?mod=usershare&act=onekey&to=pengyou&url=' + link + '&amp;t=' + title;
			var params = getParamsOfShareWindow(634, 468);
			window.open(url, windowName, params)
		});
		addListener(document.getElementById('facebook-share'), 'click',
		function() {
			var url = 'http://facebook.com/share.php?u=' + link + '&amp;t=' + title;
			var params = getParamsOfShareWindow(634, 468);
			window.open(url, windowName, params)
		});
		addListener(document.getElementById('twitter-share'), 'click',
		function() {
			var url = 'http://twitter.com/share?url=' + link + '&amp;text=' + title;
			var params = getParamsOfShareWindow(634, 634);
			window.open(url, windowName, params)
		})
	}
	bindShareList()
});