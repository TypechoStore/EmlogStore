<?php 
/*
* 侧边栏组件、页面模块
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//widget：blogger
function widget_blogger($title){

	global $CACHE;

	$user_cache = $CACHE->readCache('user');

	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>

<div class="widget_recent_entries">
  <h3><span><?php echo $title; ?></span></h3>
  <ul>
    <div class="blogger">
      <?php if (!empty($user_cache[1]['photo']['src'])): ?>
      <img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" alt="blogger" class="img" />
      <?php endif;?>
      <span><b>My Name：<?php echo $name; ?></b></span>
      <p><?php echo $user_cache[1]['des']; ?></p>
    </div>
  </ul>
</div>
<?php }?>
<?php

//widget：日历

function widget_calendar($title){ ?>
<div class="widget_recent_entries">
  <h3><span><?php echo $title; ?></span></h3>
  <ul>
    <div id="calendar"> </div>
    <script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
  </ul>
</div>
<?php }?>
<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');
	$colors = array("#333333","#FF0000","#CC0099","#E50066","#990099","#990000","#660099","#330099","#1919B2","#0033CC","#0066B2","#009999","#00B266","#00CC00","#33FF00","#8EB100","#DBC400","#FFB200","#FF8000","#FF3300","#6600FF","#CC6666","#FF00FF","#663399","#00CCFF");
    ?>
<div class="widget_tag_cloud">
  <h3><span><?php echo $title; ?></span></h3>
  <div class="tagcloud">
    <?php foreach($tag_cache as $value) {
        $color = $colors[rand(0,24)];
    ?>
    <a style="font-size:<?php echo $value['fontsize']>13? "13":$value['fontsize']; ?>pt;color:<?php echo $color; ?>" href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇日志"><?php echo $value['tagname']; ?></a>
    <?php } ?>
  </div>
</div>
<?php }?>
<?php

//widget：分类

function widget_sort($title){

	global $CACHE;

	$sort_cache = $CACHE->readCache('sort'); ?>
<div class="widget_categories">
  <h3><span><?php echo $title; ?></span></h3>
  <ul>
    <?php foreach($sort_cache as $value): ?>
    <li> <a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a> <br />
    </li>
    <?php endforeach; ?>
  </ul>
</div>
<?php }?>
<?php

//widget：最新碎语

function widget_twitter($title){

	global $CACHE; 

	$newtws_cache = $CACHE->readCache('newtw');

	$istwitter = Option::get('istwitter');

	?>
<div class="widget_recent_entries">
  <h3><span><?php echo $title; ?></span></h3>
  <ul class="recentcomments">
    <?php foreach($newtws_cache as $value): ?>
    <li><?php echo $value['t']; ?>
      <p><?php echo smartDate($value['date']); ?> </p>
    </li>
    <?php endforeach; ?>
    <?php if ($istwitter == 'y') :?>
    <p><a href="<?php echo BLOG_URL . 't/'; ?>">更多&raquo;</a></p>
    <?php endif;?>
  </ul>
</div>
<?php }?>
<?php

//widget：最新评论

function widget_newcomm($title){

	global $CACHE; 

	$com_cache = $CACHE->readCache('comment');

	?>
<div class="widget_recent_entries">
  <h3><span><?php echo $title; ?></span></h3>
  <ul class="recentcomments">
    <?php
	foreach($com_cache as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	?>
    <li><img src="http://www.gravatar.com/avatar/<?php  echo md5($value['mail']); ?>" title="<?php echo $value['name']; ?>"  class="avatar" /><?php echo $value['name']; ?> <br />
      <a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a></li>
    <?php endforeach; ?>
  </ul>
</div>
<?php }?>
<?php

//widget：最新日志

function widget_newlog($title){

	global $CACHE; 

	$newLogs_cache = $CACHE->readCache('newlog');

	?>
<div class="widget_recent_entries">
  <h3><span><?php echo $title; ?></span></h3>
  <ul>
    <?php foreach($newLogs_cache as $value): ?>
    <li><a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>"><?php echo $value['title']; ?></a></li>
    <?php endforeach; ?>
  </ul>
</div>
<?php }?>
<?php

//widget：随机日志

function widget_random_log($title){

	$index_randlognum = Option::get('index_randlognum');

	$Log_Model = new Log_Model();

	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
<div class="widget_recent_entries">
  <h3><span><?php echo $title; ?></span></h3>
  <ul>
    <?php foreach($randLogs as $value): ?>
    <li><a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>"><?php echo $value['title']; ?></a></li>
    <?php endforeach; ?>
  </ul>
</div>
<?php }?>
<?php

//widget：搜索

function widget_search($title){ ?>
<ul>
  <div id="search">
    <form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
      <input class="sinput" type="text" value="搜搜更健康~ ~" name="keyword" onFocus="this.value = this.value == this.defaultValue ? '' : this.value" onBlur="this.value = this.value == '' ? this.defaultValue : this.value"/>
    </form>
  </div>
</ul>
<?php } ?>
<?php

//widget：归档

function widget_archive($title){

	global $CACHE; 

	$record_cache = $CACHE->readCache('record');

	?>
<div class="widget_recent_entries">
  <h3><span><?php echo $title; ?></span></h3>
  <ul>
    <?php foreach($record_cache as $value): ?>
    <li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
    <?php endforeach; ?>
  </ul>
</div>
<?php } ?>
<?php

//widget：自定义组件

function widget_custom_text($title, $content){ ?>
<div class="widget_recent_entries">
  <h3><span><?php echo $title; ?></span></h3>
  <ul>
    <?php echo $content; ?>
  </ul>
</div>
<?php } ?>
<?php

//widget：链接

function widget_link($title){

	global $CACHE; 

	$link_cache = $CACHE->readCache('link');

	?>
<div class="widget_links">
  <h3><span><?php echo $title; ?></span></h3>
  <ul class='links'>
    <?php foreach($link_cache as $value): ?>
    <li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
    <?php endforeach; ?>
  </ul>
</div>
<?php }?>
<?php

//blog：置顶

function topflg($istop){

	$topflg = $istop == 'y' ? "<img src=\"".TEMPLATE_URL."/images/import.gif\" title=\"置顶日志\" /> " : '';

	echo $topflg;

}

?>
<?php

//blog：编辑

function editflg($logid,$author){

	$editflg = ROLE == 'admin' || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'">编辑</a>' : '';

	echo $editflg;

}

?>
<?php

//blog：分类

function blog_sort($blogid){

	global $CACHE; 

	$log_cache_sort = $CACHE->readCache('logsort');

	?>
<?php if(!empty($log_cache_sort[$blogid])): ?>
<a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
<?php endif;?>
<?php }?>
<?php

//blog：文件附件

function blog_att($blogid){

	global $CACHE;

	$log_cache_atts = $CACHE->readCache('logatts');

	$att = '';

	if(!empty($log_cache_atts[$blogid])){

		$att .= '<br /><b>附件下载：</b>';

		foreach($log_cache_atts[$blogid] as $val){

			$att .= '<br /><a href="'.BLOG_URL.$val['url'].'" target="_blank">'.$val['filename'].'</a> '.$val['size'];

		}

	}

	echo $att;

}

?>
<?php

//blog：日志标签

function blog_tag($blogid){

	global $CACHE;

	$log_cache_tags = $CACHE->readCache('logtags');

	if (!empty($log_cache_tags[$blogid])){

	

		foreach ($log_cache_tags[$blogid] as $value){

			$tag .= "	<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';

		}

		echo $tag;

	}

}

?>
<?php

//blog：日志作者

function blog_author($uid){

	global $CACHE;

	$user_cache = $CACHE->readCache('user');

	$author = $user_cache[$uid]['name'];

	$mail = $user_cache[$uid]['mail'];

	$des = $user_cache[$uid]['des'];

	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';

	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";

}

?>
<?php

//blog：相邻日志

function neighbor_log($neighborLog){

	extract($neighborLog);?>
<?php if($prevLog):?>
<div class="next">上一篇：<a href="<?php echo Url::log($prevLog['gid']) ?>"><?php echo $prevLog['title'];?></a></div>
<?php endif;?>
<?php if($nextLog && $prevLog):?>
<?php endif;?>
<?php if($nextLog):?>
<div class="pre">下一篇：<a href="<?php echo Url::log($nextLog['gid']) ?>"><?php echo $nextLog['title'];?></a></div>
<?php endif;?>
<?php }?>
<?php

//blog：引用通告

function blog_trackback($tb, $tb_url, $allow_tb){

    if($allow_tb == 'y' && Option::get('istrackback') == 'y'):?>
引用地址：<a href="<?php echo $tb_url; ?>"><?php echo $tb_url; ?></a> <a name="tb"></a><br />
<?php endif; ?>
<?php foreach($tb as $key=>$value):?>
<ul id="trackback">
  <li><a href="<?php echo $value['url'];?>" target="_blank"><?php echo $value['title'];?></a></li>
  <li>BLOG: <?php echo $value['blog_name'];?></li>
  <li><?php echo $value['date'];?></li>
</ul>
<?php endforeach; ?>
<?php }?>
<?php

//blog：博客评论列表

function blog_comments($comments){
   extract($comments);
   if($commentStacks): ?>
<?php endif; ?>
<?php
	$isGravatar = Option::get('isgravatar');
    foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];

	?>
<li class="comment"  id="li-comment-<?php echo $comment['cid']; ?>"> <a name="<?php echo $comment['cid']; ?>"></a>
  <div id="comment-<?php echo $comment['cid']; ?>" class="comment-body">
    <div id="comment_list">
      <?php if($isGravatar == 'y'): ?>
      <div class="commentmeta"><img src="<?php echo getGravatar($comment['mail']); ?>" class='avatar avatar-32 photo' height='32' width='32' /></div>
      <?php endif; ?>
      <div class="commentmetadata">&nbsp;&nbsp;<?php echo $comment['date']; ?>&nbsp;&nbsp;</div>
      <div class="reply"><a class='comment-reply-link' href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">Reply @</a></div>
      <div class="vcard"><?php echo $comment['poster']; ?>&nbsp;&nbsp;
        <?php if(function_exists('display_useragent')){display_useragent($comment['cid']);} ?>
      </div>
      <p><?php echo $comment['content']; ?></p>
    </div>
  </div>
</li>
<?php blog_comments_children($comments, $comment['children']); ?>
<?php endforeach; ?>
<div id="pagenavi">
            <?php echo $commentPageUrl;?>
</div>
<?php }?>
<?php

//blog：博客子评论列表

function blog_comments_children($comments, $children){

	$isGravatar = Option::get('isgravatar');

	foreach($children as $child):

	$comment = $comments[$child];

	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];

	?>
<ul class='children'>
  <li class="comment odd depth-2"  style="margin-left:40px;" id="li-comment-<?php echo $comment['cid']; ?>" ><a name="<?php echo $comment['cid']; ?>"></a>
    <div id="comment-<?php echo $comment['cid']; ?>" class="comment-body">
      <?php if($isGravatar == 'y'): ?>
      <div class="commentmeta"><img src="<?php echo getGravatar($comment['mail']); ?>" class='avatar avatar-32 photo' height='32' width='32' /></div>
      <?php endif; ?>
      <div class="commentmetadata">&nbsp;&nbsp;<?php echo $comment['date']; ?>&nbsp;&nbsp;</div>
      <div class="reply"><a class='comment-reply-link' href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">Reply @</a></div>
      <div class="vcard"><?php echo $comment['poster']; ?>&nbsp;&nbsp;
        <?php if(function_exists('display_useragent')){display_useragent($comment['cid']);} ?>
      </div>
      <p><?php echo $comment['content']; ?></p>
      <?php if($comment['level'] < 6): ?>
      <?php endif; ?>
    </div>
    <?php blog_comments_children($comments, $comment['children']);?>
  </li>
</ul>
<?php endforeach; ?>
<?php }?>
<?php

//blog：发表评论表单

function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){

	if($allow_remark == 'y'): ?>
<div id="comment-place">
  <div class="respond" id="respond">
    <div class="cancel-reply" id="cancel-reply" style="display:none"><a href="javascript:void(0);" onclick="cancelReply()">
      <h3 class="clearfix">点这里取消回复</h3>
      </a></div>
    <a name="respond"></a>
    <form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
      <input type="hidden" name="gid" value="<?php echo $logid; ?>" />
      <?php if(ROLE == 'visitor'): ?>
      <div id="author_info">
        <p>
          <input type="text" name="comname" id="author" value="<?php echo $ckname; ?>" tabindex="1"/>
          <label for="author"><small>昵称:</small></label>
        </p>
        <p>
          <input type="text" name="commail" id="email" value="<?php echo $ckmail; ?>" tabindex="2"/>
          <label for="email"><small>邮箱:</small></label>
        </p>
        <p>
          <input type="text" name="comurl" id="url" value="<?php echo $ckurl; ?>" tabindex="3" />
          <label for="url"><small>网址:</small></label>
        </p>
      </div>
      <?php endif; ?>
      <textarea name="comment" id="comment" cols="100" rows="14" tabindex="4" onkeydown="if(event.altKey &amp;&amp; window.event.keyCode == 83) {document.getElementById('submit').click();return false;}; if(event.ctrlKey&amp;&amp;event.keyCode==13){document.getElementById('submit').click();return false;};" >
</textarea>
      <?php echo $verifyCode; ?>
      <input name="submit" type="submit" id="submit" tabindex="5" value="确认提交（Ctrl+Enter / Alt+S）" />
      <input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/>
    </form>
  </div>
</div>
<?php endif; ?>
<?php }?>
