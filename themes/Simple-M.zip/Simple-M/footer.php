<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>
<div class="clear"></div>
<script type="text/javascript">$("#home-loading div").animate({width:"700px"})</script>
<div id="footer">
  <ul>
    <li><a>&copy; 2011 <?php echo $blogname; ?></a></li>
    <li><a href="http://www.emlog.net/" target="_blank" title="自豪的采用 Emlog <?php echo Option::EMLOG_VERSION; ?>">Emlog</a></li>
    <?php echo $footer_info; ?>
    <li style="float: right; margin-top: 0px; "><a href="http://www.microhu.com/" target="_blank" title="主题设计">Simple-M</a></li>
    <li style="float: right; margin-top: 0px; "><a href="http://zld.me/" target="_blank" title="主题移植，修改">ZLD.ME</a></li>
  </ul>
</div>
<script type="text/javascript">$("#loading div").animate({width:"800px"})</script>
<?php if ($curpage== CURPAGE_HOME) { ?>
<div id="goto">
  <div class="top" title="顶部"></div>
  <div class="bot" title="底部"></div>
</div>
<div id="top_bottom"></div>
<?php } 

else { ?>
<div id="goto">
  <div class="top" title="顶部"></div>
  <div class="comt" title="评论"></div>
  <div class="bot" title="底部"></div>
</div>
<div id="top_bottom"></div>
<?php } ?>
<script type="text/javascript">$("#home-loading div").animate({width:"960px"},function(){ setTimeout(function(){$("#home-loading div").animate({opacity:'toggle'},900);},900); });</script>
<?php doAction('index_footer'); ?>
</body></html>