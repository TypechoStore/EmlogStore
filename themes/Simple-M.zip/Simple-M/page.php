<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div class="post-single">
  <div class="post-title">
    <h1><?php echo $log_title; ?></h1>
  </div>
  <div class="post-content">
    <?php echo $log_content; ?>
    <?php blog_att($logid); ?>
  </div>
</div>
<div id="comments">
  <?php blog_comments($comments); ?>
  <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
</div>

<!--end content-->

<?php
 include View::getView('side');
 include View::getView('footer');
?>
