<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
$weekarr= array('星期日','星期一','星期二','星期三','星期四','星期五','星期六');
?>
<div id="content-inner">
			<div class="post">
<?php doAction('index_loglist_top'); ?>
<?php
if(isset($sortName)){
  echo '<div class="pagetitle">▨&nbsp;类别《<span>'.$sortName.'</span>》下的文章:</div>';
}
if(isset($record)) {
  if(strlen($record)>6){
    echo '<div class="pagetitle">▨&nbsp;写于<span>'.substr($record,0,4).'年'.substr($record,4,2).'月'.substr($record,6,2).'日</span>的文章:</div>';
  }else{
    echo '<div class="pagetitle">▨&nbsp;写于<span>'.substr($record,0,4).'年'.substr($record,4,2).'月</span>的文章:</div>';
  }
}
if(isset($tag)) echo '<div class="pagetitle">▨&nbsp;标签《<span>'.$tag.'</span>》下的文章:</div>';
if(isset($keyword)) echo '<div class="pagetitle">▨&nbsp;搜索关键词为『<span>'.$keyword.'</span>』的文章:</div>';
if(isset($author)) echo '<div class="pagetitle">▨&nbsp;作者"<span>'.$user_cache[$author]['name'].'</span>"的文章:</div>';
?>
<?php foreach($logs as $value): ?>
<div class="post-data" id="post-<?php echo $value['logid']; ?>">
<h2><?php topflg($value['top']); ?><a class="title" href="<?php echo $value['log_url']; ?>" rel="bookmark"><?php echo $value['log_title']; ?></a></h2>
<div class="post-messages-1"><?php echo gmdate('Y-n-j G:i', $value['date']); ?> / 标签:
      <?php blog_tag($value['logid']); ?>
      / 分类:
      <?php blog_sort($value['logid']); ?>
    </div>
            <span>作者: <?php blog_author($value['author']); ?></span><span>评论: <a href="<?php echo $value['log_url']; ?>#comments" rel="nofollow" ><?php echo $value['comnum']; ?> </a></span><span>浏览: <?php echo $value['views']; ?> </span></h3>
			
		</div>
		<div class="post-txt">
		<?php echo $value['log_description']; ?>
		</div>
		<div class="under"><?php blog_tag($value['logid']); ?></div>
<?php endforeach; ?>
	<div class='pagenavi en loop-pages'>
	<div class="pagenavi"><?php echo $page_url;?></div>
	</div>
</div>
	</div></div>
<!-- main END -->
<?php
 include View::getView('side');
 include View::getView('footer');
?>