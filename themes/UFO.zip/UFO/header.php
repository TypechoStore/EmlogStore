<?php
/*
Template Name:UFO
Description:CMS风格 ……
Author:Syan移植
Author Url:http://onoboy.com
Sidebar Amount:1
ForEmlog:4.1.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<HTML xmlns="http://www.w3.org/1999/xhtml">
<HEAD>
<META http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $blogtitle; ?></title>
<LINK rel="shortcut icon" href="<?php echo TEMPLATE_URL; ?>favicon.ico">
<LINK rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>themes/UFO_Cms/STYLE/UFO_Cms.css"/>
<SCRIPT language="javascript" src="<?php echo TEMPLATE_URL; ?>themes/UFO_Cms/SCRIPT/Sean_flash.js" type="text/javascript"></SCRIPT>
<SCRIPT language="javascript" src="<?php echo TEMPLATE_URL; ?>themes/UFO_Cms/SCRIPT/Sean_script.js" type="text/javascript"></SCRIPT>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="Bluefish 2.0.3" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</HEAD>
<BODY>

<DIV CLASS=TOP_HEADER>
<DIV CLASS=CONTENT>
   <UL>
 <?php if($istwitter == 'y'):?>
	<li class="page_item"><a href="<?php echo BLOG_URL; ?>t/"><?php echo Option::get('twnavi');?></a></li>
	<?php endif;?>
	<?php 
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach ($navi_cache as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	$newtab = $val['newtab'] == 'y' ? 'target="_blank"' : '';
    $val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
	?>
	<li class="page_item"><a href="<?php echo $val['url']; ?>" <?php echo $newtab; ?>><?php echo $val['naviname']; ?></a></li>
	<?php endforeach;?>
	<?php doAction('navbar', '<li class="page_item">', '</li>'); ?>
	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
	<li class="page_item"><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
	<li class="page_item"><a href="<?php echo BLOG_URL; ?>admin/">管理中心</a></li>
	<li class="page_item"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
	<?php else: ?>
	<li class="page_item"><a href="<?php echo BLOG_URL; ?>admin/">登录</a></li>
	<?php endif; ?>
   </UL>
<SPAN>这里不知道要放什么！！</SPAN>
</DIV>
</DIV>
<DIV CLASS="HEADER">
<DIV CLASS="CONTENT"><A HREF="<?php echo BLOG_URL; ?>" TITLE="<?php echo $blogname; ?>" CLASS="LOGO LEFT"></A>
<DIV CLASS="SEARCH_BOX RIGHT">
<SPAN>
<DIV ID="BLOG_SUB"><?php echo $bloginfo; ?></DIV>
</SPAN>
<DIV CLASS="SEARCH RIGHT">
<DIV CLASS="SEARCH_01 LEFT">
<form method='get' action='<?php echo BLOG_URL; ?>index.php' CLASS="SEARCHFORM">

  <DIV CLASS="LEFT"><input type="text" name="keyword" ID="s" size="23" value="请输入关键词" onblur="if(this.value=='') this.value='请输入关键词';" onfocus="if(this.value=='请输入关键词') this.value='';" CLASS="SEARCH_INPUT"/></DIV>
  <DIV CLASS="RIGHT"><img src="<?php echo TEMPLATE_URL; ?>themes/UFO_Cms/STYLE/UFO_img/btn_srch.gif"/></DIV>
</form>
</DIV>
  
<DIV CLASS="HOT_TAGS LEFT"> 
<?php 
  global $CACHE;
	$tag_cache = $CACHE->readCache('tags');
   for ($i=0; $i<=7; $i++){ ?>
	<a href="<?php echo Url::tag($tag_cache[$i]['tagurl']); ?>" title="<?php echo $tag_cache[$i]['usenum']; ?> 篇日志"><?php echo $tag_cache[$i]['tagname']; ?></a>		
			<?php } ?>	
</DIV></DIV>
</DIV>
</DIV>
<DIV CLASS="CLEAR CONTENT MENU">
   <UL>
     <li class="log_first"><a href="<?php echo BLOG_URL; ?>">首页</a></li>
     <?php $sort_cache = $CACHE->readCache('sort');?>
     <?php foreach($sort_cache as $value): ?>
	<li class="cat-item">
	<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?></a>
	</li>
	<?php endforeach; ?> 
    
   </UL><SPAN ID="MOOD"><FONT color="#1C86EE">
   <?php 
   $newtws_cache = $CACHE->readCache('newtw');
		echo $newtws_cache[0]['t'];
    ?></FONT></SPAN>
</SPAN>
</DIV>
</DIV>