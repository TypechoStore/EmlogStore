<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<DIV CLASS="FOOT CLEAR"><DIV CLASS="CONTENT">
<DIV CLASS="COPYRIGHT">Copyright 2010-2011 <?php echo $blogname; ?>. Some Rights Reserved.</DIV>
<DIV CLASS="POWERBY">Design By <A href="http://onoboy.com" target="_blank">Syan</A>移植自<A href="http://www.pakelab.com" target="_blank">pakelab</A> |  Power By <a href="http://emlog.net" >emlog</a> <?php echo $footer_info; ?>
</DIV>
</DIV></DIV>
<?php doAction('index_footer'); ?>
</BODY>
</HTML>
