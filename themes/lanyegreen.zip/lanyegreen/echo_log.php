﻿<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div id="content" class="xiepo">
<ul>
<li>
	<h2 class="content_h2"><?php topflg($top); ?><?php echo $log_title; ?></h2>
	<div class="act"><?php blog_sort($logid); ?> 作者：<?php blog_author($author); ?> 日期：<?php echo gmdate('Y-n-j', $date); ?></div>
	<div class="editor"><?php editflg($logid,$author); ?></div>
	<div class="clear line"></div>
   	<div class="post"><?php echo $log_content; ?></div>
	<div class="fujian"><?php blog_att($logid); ?></div>
    <div id="baidushare">
<div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
<a class="bds_baidu" style="width:145px; background-position:0 -9999px !important;height:60px;"></a>
</div>
<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=636112" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
</script>
<div class="bdlikebutton" style="float:left"></div>
<script id="bdlike_shell"></script>
<script>
var bdShare_config = {
	"type":"large",
	"color":"blue",
	"uid":"636112",
	"share":"yes",
	"likeText":"觉得好请顶起！",
	"likedText":"您已顶过，谢谢！"
};
document.getElementById("bdlike_shell").src="http://bdimg.share.baidu.com/static/js/like_shell.js?t=" + Math.ceil(new Date()/3600000);
</script>
</div>
	<div class="pageother">
	<ul>
	<li>文章说明：本文由<?php blog_author($author);?>原创或编辑，转载请注明出处。</li>
    <li>本文标签：<?php blog_tag($logid); ?></li>
    <li>访问次数：本文被访问<?php echo $views; ?>次</li>
	<li>评论数目：本文共有<?php echo $comnum; ?>次评论</li>
	<li>本文链接：<a href="<?php echo Url::log($logid); ?>"><?php echo Url::log($logid); ?></a></li>
</ul>
</div>

    
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);?>
</li>
</ul>
</div>
<!--end content-->
<?php 
include View::getView('side');
include View::getView('footer'); 
?>