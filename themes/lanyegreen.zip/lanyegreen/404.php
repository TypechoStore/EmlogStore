<?php 
/*
* 自定义404页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>404ERROR-PAGE NOT FOUND</title>
<style type="text/css">
body {background-color:#fff;font-family: "微软雅黑",Tahoma,Arial;font-size:12px;}
.main {font-size: 12px;	color: #666666;width:512px;height:312px;margin:100px auto;padding:150px 0 0 220px;list-style:none;background-image: url(<?php echo TEMPLATE_URL; ?>404.gif);background-repeat: no-repeat;}
.main p {font-size:16px;}
.main p a {text-decoration: none;font-size: 16px;color: red;}
.main p a:hover{color: #0099FF;}
</style>
</head>
<body>
<div class="main">
<p>非常抱歉，你所请求的页面不存在！</p>
<p>此页您输入的网址错误了，您可以点击以下链接进行相关操作。</p>
<p><a href="javascript:history.back(-1);" title="返回上一页">点击返回</a> <a href="<?php echo BLOG_URL; ?>" title="进入首页">网站首页</a> <a href="http://www.baidu.com/baidu?word=<?php echo BLOG_URL; ?>" title="百度搜索本站">百度搜索</a></p>
</div>
</body>
</html>