﻿<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div class="clear"></div>
</div>
<div class="footer-wrap" id="gobottom">
<div id="footer"><p><?php echo $footer_info; ?> 本站由<a href="http://bbs.emlog.net" target="_blank">Emlog</a>架设 Theme By <a href="http://lanyes.org" target="_blank">蓝叶</a> <a href="<?php echo BLOG_URL; ?>sitemap.xml" target="_blank" title="谷歌网站地图">谷歌地图</a>&nbsp;&nbsp;</P>
<div class="clear"></div>
</div>
<?php doAction('index_footer'); ?>
</div>
<div class="go">
<a title="返回顶部" class="top" href="#gotop">至顶</a>
<a title="留言评论" class="tocomment" href="#comment-place">发表评论</a>
<a title="返回底部" class="bottom" href="#gobottom">至底</a>
</div>
</body>
</html>