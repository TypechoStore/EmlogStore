<?php
/*
头部滚动公告，背景颜色请自行更改，滚动文字内容也自行更改。
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="led" style="background:#ffe;">
<div id="clock"><embed src="<?php echo TEMPLATE_URL; ?>images/clock.swf" type="application/x-shockwave-flash" wmode="transparent" width="170" height="58" quality="high" /></div>
<div id="textgg"><marquee scrollamount="6" width="780px" onmouseover=this.stop() onmouseout=this.start()>蓝叶博客将进行整改，请所有友情链接的朋友取消友链，等一切正常后再进行友情链接，时间有限不一一通知，还望海涵！</marquee></div>
</div>