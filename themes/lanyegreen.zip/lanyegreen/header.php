<?php
/*
Template Name:绿色模板
Description:绿色简单模板
Author:蓝叶
Author Url:http://lanyes.org
Sidebar Amount:1
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once (View::getView('module'));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<title><?php echo $site_title; ?></title>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<!--[if lt IE 7]>
<div style='border: 1px solid #F7941D; background: #FEEFDA; text-align: center; clear: both; height: 20px; position: relative;'>
<div style='width:auto; hight:auto; color:red; text-align: center; font-size: 14px; font-weight: bold; line-height: 2em;'>温馨提示：您的IE版本过低，蓝叶建议您升级至更快速安全 <strong style='color:#0099FF;'>Internet Explorer 8</strong>  <strong style='padding-right: 10px;padding-left: 10px;'>[<a style='color: #0099FF;text-decoration: underline; ' href='http://ie8.down.sandai.net/IE8-Setup-Full.exe' target='_blank'>立即下载升级IE8</a>]</strong>  <a style='color:#000' href='#' onclick='javascript:this.parentNode.parentNode.style.display="none"; return false;'>关闭提示</a></div>
</div>
</div>
<![endif]-->
</head>
<body id="gotop">
<div id="topbar">
<div id="topbox"><span style="float:left"><script type="text/javascript">
var now=(new Date()).getHours();
if(now>0&&now<=6){
document.write("午夜好，快睡觉去，妹纸等你久了会不耐烦的哦...");
}else if(now>6&&now<=11){
document.write("早上好，昨夜运动那么长时间还这么早起床，真爷们...");
}else if(now>11&&now<=14){
document.write("中午好，停下手中的工作，快去吃饭晚了就没的吃了...");
}else if(now>14&&now<=18){
document.write("下午好，累了一上午了，快去休息会扒根烟喝杯茶...");
}else{
document.write("晚上好，快睡觉吧别忙了，明天的日头照样红...");
}
</script></span> <span style="float:right">今天日期：<script type="text/javascript">
　today=new Date(); var tdate,tday, x,year; var x = new Array("星期日", "星期一", "星期二", "星期三", "星期四", "星期五","星期六");
　　var MSIE=navigator.userAgent.indexOf("MSIE");
　　if(MSIE != -1)
　　 year =(today.getFullYear());
　　else
　　 year = (today.getYear()+1900);
　　tdate= year+ "年" + (today.getMonth() + 1 ) + "月" + today.getDate() + "日" + " " + x[today.getDay()];
　　document.write(tdate); 
//-->
</script></span></div>
</div>
<div id="header">
<div id="logo"><a href="<?php echo BLOG_URL; ?>" title="<?php echo $site_description; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/logo.png" /></a></div>
<div id="right"><ul>
<li id="icorss"><a href="<?php echo BLOG_URL; ?>rss.php" title="<?php echo $blogname;?>RSS源地址" target="_blank"></a></li>
<li id="icomail"><a href="http://list.qq.com/cgi-bin/qf_invite?id=76346bb18630c869c0456c47a542522cdc896ca92bce235f" title="邮件订阅蓝叶博客" target="_blank" rel="nofollow"></a></li>
<li id="icotsina"><a href="http://t.sina.com.cn/hcwl" title="蓝叶的新浪微博" target="_blank" rel="nofollow"></a></li>
<li id="icotqq"><a href="http://t.qq.com/lanyesorg" title="蓝叶的腾讯微博" target="_blank" rel="nofollow"></a></li>
<li id="icoqq"><a href="http://wpa.qq.com/msgrd?v=3&uin=84953409&site=qq&menu=yes" title="联系蓝叶" target="_blank" rel="nofollow"></a></li>
<li id="icoyinyue"><a  href="http://lanyes.org/yinyue" target="_blank" title="蓝叶音乐盒" rel="nofollow"></a></li></ul></div>
<div class="clear"></div>
</div>
<div id="menu"><?php blog_navi();?></div>
<?php include View::getView('gonggao');?>
<div class="main">