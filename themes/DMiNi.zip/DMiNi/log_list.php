<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
<div id="content">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<div id="postlist">
<div class="post-div">
<div class="post-title">
<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
<span class="post-com"><a href="<?php echo $value['log_url']; ?>#comments"> <?php echo $value['comnum']; ?>+ </a></span></h2>
</div>
<div class="post-content">
<p><?php echo preg_replace("/<p class=\"readmore\"><a href=\"[^\"]+\">阅读全文&gt;&gt;<\/a><\/p>/i","",$value['log_description']); ?></p>
<p class="more"><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>">more...</a></p><p></p>
</div>
</div>
</div>
<?php endforeach; ?>
    <?php if($logs == NULL) { ?>
	<div id="postlist">
    <div class="error_page">
<img alt="face_sad" src="<?php echo TEMPLATE_URL; ?>images/404-page.jpg" />
<h1>We're sorry...</h1>
<p>The page or journal you are looking for cannot be found.</p>
</div>
</div>
    <?php } ?>
<ol class="page-navigator"><?php echo $page_url;?></ol></div>
<hr class="no">
<h3 class="no">Old Entries</h3>

<div id="oldentries">
		<div class="page_item" id="searchLink">
		<li><form name="keyform" method="get" id="searchform" action="/"><input type="text" value="请输入要搜索的关键字..." title="请输入要搜索的关键字" name="keyword" id="s" onfocus="this.value = this.value == this.defaultValue ? '' : this.value" onblur="this.value = this.value == '' ? this.defaultValue : this.value"><input type="submit" id="searchsubmit" value="搜 索"></form></li>
		</div>
</div>
<?php
 //include View::getView('side');
 include View::getView('footer');
?>