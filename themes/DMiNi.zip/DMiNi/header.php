<?php
/*
Template Name:DMiNi
Description:本主题由老王移植
Version:1.2
Author:老王
Author Url:http://lwllo.com
Sidebar Amount:1
ForEmlog:4.2.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>css/main.css" rel="stylesheet" type="text/css" />
<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="page">
<div id="logo"><h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1></div>
<div class="addfeeds">
    <a href="<?php echo BLOG_URL; ?>">首页</a>
    <?php 
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach ($navi_cache as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	$val['is_blank'] = $val['newtab'] == 'y' ? 'target="_blank"' : '';
    $val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
	?>
	<a href="<?php echo $val['url']; ?>" target="<?php echo $val['is_blank']; ?>"><?php echo $val['naviname']; ?></a>
	<?php endforeach;?>
	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
	<a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a>
	<a href="<?php echo BLOG_URL; ?>admin/">管理中心</a>
	<a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a>
	<?php else: ?>
	<a href="<?php echo BLOG_URL; ?>admin/">登录</a>
	<?php endif; ?>
    </div>
<div class="clear"></div>