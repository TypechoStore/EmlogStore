<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
<div id="content">
<div id="singlePost">
<?php if(isset($_GET['plugin'])){$log_title=$navibar[addslashes($_GET['plugin'])]['title'];} ?>
	<h2><?php echo $log_title; ?></h2>
	<?php echo $log_content; ?></div>		
    <hr class="no" />
</div>
<div id="comments-num"><h2><a href="#comment_form"><?php if($comnum == ''){echo 'No';}else{echo $comnum;} ?> Comments So Far</a> ！</h2></div>
    <?php blog_comments($comments,$params); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<?php
 //include View::getView('side');
 include View::getView('footer');
?>