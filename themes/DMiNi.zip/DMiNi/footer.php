<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="clear"></div>
<div id="footer">
<div style="clear:both"></div>
<p>Copyright © <a href="<?php echo BLOG_URL; ?>" rel="home"><?php echo $blogname; ?></a>. 2012 All rights reserved.<br>
Powered by  <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> | Theme is <a href="http://www.ise7en.me/dmini-v1-20-71.html" title="by：黑色De泪">DMiNi</a> | and <a href="http://lwllo.com/">老王移植</a>. <?php echo $footer_info; ?></p>
</div>
</div>
<div class="clear"></div>
</div>
<script type="text/javascript">var BLOG_URL = '<?php echo BLOG_URL; ?>',TEMPLATE_URL = '<?php echo TEMPLATE_URL; ?>';</script> 
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/all.js"></script>
<?php doAction('index_footer'); ?>
</body>
</html>