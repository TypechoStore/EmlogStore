﻿$(function() {
	$("a.reply_link").live("click",function() {
		var c = $(this).attr("data-cid"),
		pid = c.match(/\d+/g)[0];
		$("#respond").insertAfter($(this).parent().parent().parent().parent().parent());
		$("#pid").val(pid);
		$(".cancel-comment-reply").show(); 
		(~document.cookie.indexOf('commentposter')) ? $("#comment").focus() : $("#author").focus();
		return false
	});
	$(".cancel-comment-reply").live("click",function() {
		$("#respond").appendTo(".respond");
		$(this).hide();
		$("#comment").val("");
		$("#pid").val("0");
		return false
	});

});
/* MMGO */
(function($){  
		var topDistance = 300;
        var showDistance = 1;
        var goToTopButton = "<div id='goToTop'><a href='javascript:scroll(0,0)' title='老湿你能送我上去么？'>老湿你能送我上去么？</a></div>";
        var thisTop = $(window).scrollTop() + topDistance;
        $("#container").append(goToTopButton);
        if($(window).scrollTop() < showDistance) {
		$("#goToTop").hide();
        } 
        $(window).scroll(function(){
            if($(this).scrollTop() < showDistance) {
                $("#goToTop").fadeOut("fast");
            } else {
                $("#goToTop").fadeIn("fast");
            }
        });   
        $("#goToTop").click(function(){
            $("html,body").animate({scrollTop:0},"slow");
            return false;
        });
})(jQuery); 
	
Smilies = {
 dom : function(id) {
   return document.getElementById(id);
 },
 showBox : function () {
   this.dom('smiley').style.display = 'block';
   document.onclick = function() {
     Smilies.hideBox();
   }
 },
 hideBox : function () {
   this.dom('smiley').style.display = 'none';
 },
 grin : function (tag) { // 表情
   tag = ' ' + tag + ' '; myField = this.dom('comment');
   document.selection ? (myField.focus(), sel = document.selection.createRange(), sel.text = tag, myField.focus()) : this.insertTag(tag);
 },
 insertTag : function (tag) { // 插入评论中
   myField = Smilies.dom('comment');
   myField.selectionStart || myField.selectionStart == '0' ? (
     startPos = myField.selectionStart,
     endPos = myField.selectionEnd,
     cursorPos = startPos,
     myField.value = myField.value.substring(0, startPos)
                   + tag
                   + myField.value.substring(endPos, myField.value.length),
     cursorPos += tag.length,
     myField.focus(),
     myField.selectionStart = cursorPos,
     myField.selectionEnd = cursorPos
   ) : (
     myField.value += tag,
     myField.focus()
   );
   this.hideBox();
 }
} 