<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
<div id="content">
<?php ?>
	<div id="postlist-top">
	<div class="authorimg">
		<img alt="" src="<?php $user_cache = Cache::getInstance()->readCache('user');echo getGravatar($user_cache[$author]['mail'],50); ?>" class="avatar avatar-50 photo" height="50" width="50">
	</div>
	<div class="authortext">
	<?php echo gmdate('Y/n/j G:i', $date); ?>&nbsp;&nbsp;由&nbsp;<?php blog_author($author); ?>&nbsp;发表在 <strong>·</strong> <?php blog_sort($logid); ?> <br>
	<strong>·</strong> <a href="<?php echo Url::log($logid); ?>#comment"><?php echo $comnum; ?> 条评论</a><?php echo $user_cache[$uid]['mail']; ?>
	</div>
	</div>
<div id="singlePost">
	<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
	<?php echo $log_content; ?>
	</div>
<div class="post-tag">
<?php blog_tag($logid); ?>
<?php blog_att($logid); ?></div>
		<div id="postnavi">
		<?php neighbor_log($neighborLog); ?>
		</div>
<hr class="no">
</div>
<div id="comments-num"><h2><a href="#comment_form"><?php if($comnum == ''){echo 'No';}else{echo $comnum;} ?> Comments So Far</a> ！</h2></div>
    <?php blog_comments($comments,$params); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<?php
 //include View::getView('side');
 include View::getView('footer');
?>