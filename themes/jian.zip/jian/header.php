<?php
/*
Template Name:剪
Description:剪，极简
Version:1.0
Author:Loekman
Author Url:http://loek.us
Sidebar Amount:0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<!--[if IE 6]>
<script src="<?php echo TEMPLATE_URL; ?>iefix.js" type="text/javascript"></script>
<![endif]-->
<?php doAction('index_head'); ?>
<style>
body,.w-icon{background-color:#DFDBD5;}
.box{border-bottom-color:#DFDBD5;}
h1 a{color:#333;}
.m-nav a,.m-page a{color:#666;}
.cont{color:#666;}
.cont a:hover,.info a:hover{color:#903;}
.m-nav a:hover,.select,.m-page a:hover{color:#333;}
</style>
</head>
<body>
<div class="g-doc">
<!--head-->
<a name="head"></a>
<div class="g-hd">
	<div class="box m-tit">
    	<h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
        <a href="#" class="w-icon">查看个人介绍</a>
    </div>
    <div class="box box-do m-about">
    	<div class="logo">
<?php
//widget：blogger
	global $CACHE;
	$user_cache = $CACHE->readCache('user');?>
	<div id="bloggerinfoimg">
	<?php if (!empty($user_cache[1]['photo']['src'])): ?>
	<img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="<?php echo $user_cache[1]['photo']['width']; ?>" height="<?php echo $user_cache[1]['photo']['height']; ?>" alt="blogger" />
	<?php endif;?>
	</div>
    	</div>
    	<p><?php echo $user_cache[1]['des']; ?></p>
        <a href="#" class="w-icon">收起个人介绍</a>
    </div>
    <div class="box menu">
        <div class="m-sch">
            <form action="<?php echo BLOG_URL; ?>index.php" method="get"><input id="search_content" class="sch" type="text" name="keyword"/></form>
        </div>
    	<div class="m-nav">
    	<?php blog_navi();?>
        </div>
    </div>
</div>
<!--/head-->