<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="g-ft"><span title="Copyright">&copy;</span><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a> | Powered by <a href="http://www.emlog.net" title="采用emlog系统">emlog</a> | <a href="#head">返回顶部↑</a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?></div>
<?php doAction('index_footer'); ?>
</div><!--/content-->
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>images/jquery-1.6.2.min.js'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>images/jian.js'></script>
<script>prettyPrint();</script>
</body>
</html>