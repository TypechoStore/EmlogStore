<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!--content-->
<div class="g-mn">
<?php doAction('index_loglist_top'); ?>
<!--post-->
	<div class="posts">
    	<div class="postbg"></div>
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
        <div class="m-post box article">
			<a href="<?php echo $value['log_url']; ?>" class="w-icon w-icon-1">&nbsp;</a>
			<a href="<?php echo $value['log_url']; ?>" class="w-icon2">&nbsp;</a>
            <div class="info">
                <a href="<?php echo $value['log_url']; ?>"><?php echo gmdate('Y-n-j', $value['date']); ?></a><a href="<?php echo $value['log_url']; ?>">评论(<?php echo $value['comnum']; ?>)</a><?php editflg($value['logid'],$value['author']); ?>
            </div>
            <div class="cont ">
                <div class="text">
                    <h2><a href="<?php echo $value['log_url']; ?>"><?php topflg($value['top']); ?><?php echo $value['log_title']; ?></a></h2>
                    <p><?php echo $value['log_description']; ?></p>
                </div>
            </div>
            <div class="info info-1">
                <div class="tags"><?php blog_tag($value['logid']); ?></div>
            </div>
        </div>
<?php 
endforeach;
else:
?>
        <div class="m-post box article">
			<a href="javascript:;" class="w-icon w-icon-1">&nbsp;</a>
			<a href="javascript:;" class="w-icon2">&nbsp;</a>
            <div class="info"></div>
            <div class="cont ">
                <div class="text">
                    <h2>未找到</h2>
                    <p>抱歉，没有符合您查询条件的结果。</p>
                </div>
            </div>
        </div>
<?php endif;?>
    </div>
<!--/post-->
    <div class="box m-page box-do">
    	<div class="w-icon w-icon-2"></div>
        <div class="w-icon w-icon-3"></div>
   <div id="pagenavi">
<span>分页</span>
<?php echo $page_url;?>
    </div>
    </div>
</div>
<!--/content-->
<?php include View::getView('footer');?>