<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>
<div class="clear"></div>
<div class="clear"></div>
<div style="display: none;" id="gotop"></div>
<script type='text/javascript'>
    backTop=function (btnId){
        var btn=document.getElementById(btnId);
        var d=document.documentElement;
        var b=document.body;
        window.onscroll=set;
        btn.onclick=function (){
            btn.style.display="none";
            window.onscroll=null;
            this.timer=setInterval(function(){
                d.scrollTop-=Math.ceil((d.scrollTop+b.scrollTop)*0.1);
                b.scrollTop-=Math.ceil((d.scrollTop+b.scrollTop)*0.1);
                if((d.scrollTop+b.scrollTop)==0) clearInterval(btn.timer,window.onscroll=set);
            },10);
        };
        function set(){btn.style.display=(d.scrollTop+b.scrollTop>100)?'block':"none"}
    };
    backTop('gotop');
</script>
<div id="footer">
<div class="footer-top">
</div>Copyright 
&copy; lonewolf | <a href="http://www.miitbeian.gov.cn/" title="工信部网站备案" rel="external nofollow" target="_blank"><?php echo $icp; ?></a> | The theme by <a href="http://www.xlonewolf.net" title="主题由lonewolf制作" target="_blank">lonewolf</a> | Powered by <a href="http://www.emlog.net/" title="Emlog" target="_blank" rel="external nofollow">Emlog.</a><?php echo $footer_info; ?>
<p>
    <div class="bottomcopyright">
<center>今天是:<span><script language=Javascript type=text/Javascript> 
var day=""; 
var month=""; 
var ampm=""; 
var ampmhour=""; 
var myweekday=""; 
var year=""; 
mydate=new Date(); 
myweekday=mydate.getDay(); 
mymonth=mydate.getMonth()+1; 
myday= mydate.getDate(); 
myyear= mydate.getYear(); 
year=(myyear > 200) ? myyear : 1900 + myyear; 
if(myweekday == 0) 
weekday=" 星期日 "; 
else if(myweekday == 1) 
weekday=" 星期一 "; 
else if(myweekday == 2) 
weekday=" 星期二 "; 
else if(myweekday == 3) 
weekday=" 星期三 "; 
else if(myweekday == 4) 
weekday=" 星期四 "; 
else if(myweekday == 5) 
weekday=" 星期五 "; 
else if(myweekday == 6) 
weekday=" 星期六 "; 
document.write(year+"年"+mymonth+"月"+myday+"日 "+weekday); 
</script>
| 本站已经安全运行:
<span id="span_dt_dt"></span> 
<strong><script language="JavaScript" type="text/javascript">
var urodz= new Date("5/12/2013");
var now = new Date();
var ile = now.getTime() - urodz.getTime();
var dni = Math.floor(ile / (1000 * 60 * 60 * 24));
document.write(+dni)
</script>天
</strong>
<p>本网站资源来自网络和原创，如果侵犯了你的权益请联系我们，将在24小时内删除！</p>
</div>
<?php doAction('index_footer'); ?>
</div>
<script type="text/javascript">
jQuery(document).ready(function($) {
$('#nav li').hover(function() {
$('ul', this).slideDown(300)
},
function() {
$('ul', this).slideUp(300)
});
});
</script>

</body>
</html>