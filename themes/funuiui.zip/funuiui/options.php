<?php

/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
	'logo' =>array(
	'type' => 'image',
	'name' => '网站LOGO',
	'values' => array(
			TEMPLATE_URL . 'images/logo.png',
		),
	),
	
	'tuijian' => array(
		'type' => 'radio',
		'name' => '推荐显示隐藏',
		'values' => array(
			'block' => '显示',
			'none' => '隐藏',
		),
		'default' => 'block',
	),
	
	'sjwzbn' => array(
		'type' => 'radio',
		'name' => '随机+最新文章推荐下是否显示隐藏',
		'values' => array(
			'block' => '显示',
			'none' => '隐藏',
		),
		'default' => 'block',
	),
	
	'sjwz' => array(
		'type' => 'radio',
		'name' => '随机文章推荐下是否显示隐藏',
		'values' => array(
			'block' => '显示',
			'none' => '隐藏',
		),
		'default' => 'block',
	),
	
	'zxwz' => array(
		'type' => 'radio',
		'name' => '最新文章推荐下是否显示隐藏',
		'values' => array(
			'block' => '显示',
			'none' => '隐藏',
		),
		'default' => 'block',
	),
	
	'toolico_qq' => array(
		'type' => 'text',
		'name' => 'QQ号码设置',
		'values' => array(
			'877085893',
		),
	),
	
	'email' => array(
		'type' => 'text',
		'name' => '邮箱地址设置',
		'values' => array(
			'877085893@qq.com',
		),
	),
	
	'toolico_weibo' => array(
		'type' => 'text',
		'name' => '腾讯微博地址设置',
		'values' => array(
			'http://t.qq.com/?lonewolf',
		),
	),
	
	'toolico_sina' => array(
		'type' => 'text',
		'name' => '新浪微博地址设置',
		'values' => array(
			'http://weibo.com/',
		),
	),
	
	'slider' => array(
		'type' => 'radio',
		'name' => '全局顶部广告显示隐藏',
		'values' => array(
			'block' => '显示',
			'none' => '隐藏',
		),
		'default' => 'block',
	),
	'containertop1' => array(
		'type' => 'text',
		'name' => '全局顶部广告',
		'description' => '<a style="color:red;">这里填写页面顶部广告代码,么有即空</a>',
		'multi' => true,
		'default' => '<a href="http://www.xlonewolf.net" target="_blank" class="ads ads-your" style="line-height:116px;" se_prerender_url="complete">全站广告位合作</a>',
	),
	'navgg' => array(
		'type' => 'text',
		'name' => '导航下公告',
		'description' => '<a style="color:red;">这里填写公告信息,么有即空</a>',
		'multi' => true,
		'default' => '新增FunUIUI主题',
	),
);
