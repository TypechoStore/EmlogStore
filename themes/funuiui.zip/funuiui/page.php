<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
	<div id="map">
		<div class="site">
			<span class="e_i"></span>当前位置：<a href="<?php echo BLOG_URL; ?>" title="返回首页">首页</a> &gt; <?php echo $log_title; ?>
		</div>
	</div>
	<div class="main">
			<div class="article article_c">
	<div class="tith2"><?php echo $log_title; ?></div>
	<div class="clear">
	</div>
	<div class="clear"></div>
	<div class="context">
		<?php echo $log_content; ?>
		<div class="clear"></div>
		<div class="t1" style="text-align: center;"></div>
		<div class="clear"></div>
	</div>
</div>
			<div class="article article_c"><div id="authorarea_banquan"><?php doAction('log_related', $logData); ?></div></div>
			<div class="article article_c article_b">
				<div class="com" id="comments">屌丝快来吐槽吧！</div>
				<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
				<?php blog_comments($comments); ?>
			</div>
	</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>