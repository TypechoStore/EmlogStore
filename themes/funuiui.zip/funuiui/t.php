<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
	<div id="map">
		<div class="site">
			<span class="e_i"></span>当前位置：<a href="<?php echo BLOG_URL; ?>" title="返回首页">首页</a> &gt;<a href="/t">微语</a>
		</div>
	</div>
	<div class="main">
	 <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?> 
		<article class="excerpt excerpt-nothumbnail">
        <p class="note"><?php echo $val['t'].'<br/>'.$img;?><br></p>
		<p style="float:right">
        <span class="muted">
        <i class="iconfont">&#xf0296;</i>&nbsp;<?php echo $val['date'];?></span>
        <span class="muted">
        <i class="iconfont">󰂰</i><?php echo $author; ?></span>
        </p>
		</article>
    <?php endforeach;?>
	<div class="navigation"><ul><li><?php echo $page_url;?><li></ul></div>
	</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>