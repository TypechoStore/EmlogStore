<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
	<div id="map">
		<div class="site">
			<span class="e_i"></span>当前位置：<a href="<?php echo BLOG_URL; ?>" title="返回首页">首页</a> &gt;<?php sortbread($sortid); ?> &gt; <?php echo $log_title; ?>
		</div>
	</div>
	<div class="main">
			<div class="article article_c">
	<div class="tith2"><?php topflg($top); ?><?php echo $log_title; ?></div>
	<span class="h2span">浏览 <?php echo $views; ?>+</span>
	<div class="clear">
	</div>
	<div class="article_info">
		<i class="iconfont">󰂰</i> 作者：<?php blog_author($author); ?> &nbsp;
		<i class="iconfont">󰂰</i> 发布：<?php echo gmdate('Y-n-j', $date); ?> &nbsp; 
		<i class="iconfont">󰂰</i> 分类：<?php blog_sort($logid); ?>&nbsp;
	</div>
	<div class="clear"></div>
	<div class="context">
		<?php echo $log_content; ?>
		<div class="clear"></div>
		<div class="t1" style="text-align: center;"></div>
		<div class="clear"></div>
		<div id="baishare_wz"><?php blog_tag($logid); ?></div>
	</div>
</div>
			<div class="article article_c"><div id="authorarea_banquan"><?php doAction('log_related', $logData); ?></div></div>
			<div class="article article_c"><ul class="pre_nex"><?php neighbor_log($neighborLog); ?></ul></div>
			<div class="article article_c">
				<div id="authorarea">
					<img src="<?php echo TEMPLATE_URL; ?>images/blogger.jpg" width="100" height="100" alt="admin" class="avatar avatar-100 wp-user-avatar wp-user-avatar-100 alignnone photo">
					<div class="authorinfo">
						<h3><i class="iconfont">󰂰</i>&nbsp;&nbsp;<?php blog_author($author); ?></h3>
						<p><?php echo $site_title; ?>站长。</p>
						<p>
							<i class="iconfont">󰄸</i> <?php echo _g('email');?>&nbsp;&nbsp;
							<i class="iconfont">󰆯</i><a href="<?php echo _g('toolico_sina');?>" target="_blank"> 新浪微博</a>&nbsp;
							<i class="iconfont">󰆰</i><a href="<?php echo _g('toolico_weibo');?>" target="_blank"> 腾讯微博</a>&nbsp;
							<i class="iconfont">󰀅</i><a href="http://user.qzone.qq.com/<?php echo _g('toolico_qq');?>" target="_blank"> QQ空间</a>&nbsp;
						</p>
					</div>
				</div>
			</div>
			<div class="article article_c article_b">
				<div class="com" id="comments">屌丝快来吐槽吧！</div>
				<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
				<?php blog_comments($comments); ?>
			</div>
	</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>