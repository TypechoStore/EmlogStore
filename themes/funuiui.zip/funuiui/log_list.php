<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
	<div id="map">
		<div class="site"><i class="iconfont">&#x3458;</i> &nbsp;&nbsp;公告：<span><?php echo _g('navgg');?></span></div>
	</div>
	<div id="q" style="display:<?php echo _g('tuijian');?>">
		<div class="ql"><p class="qp">推荐</p></div>
		<?php
			$sql = 	"SELECT gid,title,content,date FROM ".DB_PREFIX."blog WHERE type='blog' and top='y' ORDER BY `top` DESC ,`date` DESC LIMIT 0,4";
			$list = mysql_query($sql);
			while($row = mysql_fetch_array($list)){
		?>
		<div class="suijiyanshi">
			<div class="thumbnail_boxb">
				<div class="thumbnailb">
				</div>
				<div class="thumbnailb">
					<a href="<?php echo Url::log($row['gid']);?>" rel="bookmark" title="<?php echo $row['title'];?>">
					<img class="home-thumb" src="<?php get_thum($row['gid']);?>" alt="<?php echo $row['title'];?>" width="320" height="155"/>
					</a>
				</div>
			</div>
		</div>
		<?php
			}
		?>
	</div>
	<div id="q" style="display:<?php echo _g('sjwzbn');?>">
		<div class="ql" style="display:<?php echo _g('sjwz');?>">
			<p class="qp">
				随机文章
			</p>
			<ul>
				<?php
				$index_hotlognum = Option::get('index_hotlognum');
				$Log_Model = new Log_Model();
				$randLogs = $Log_Model->getHotLog($index_hotlognum);?>
				<?php foreach($randLogs as $value): ?>
				<li><a class="nt to" href="<?php echo Url::log($value['gid']); ?>" rel="bookmark" title="详细阅读《<?php echo $value['title']; ?>》"><?php echo $value['title']; ?></a></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<div class="qr" style="display:<?php echo _g('zxwz');?>">
			<p class="qp">
				最新文章
			</p>
			<ul>
				<?php
					$index_randlognum = Option::get('index_randlognum');
					$Log_Model = new Log_Model();
					$randLogs = $Log_Model->getRandLog($index_randlognum);
				?>
				<?php foreach($randLogs as $value): ?>
				<li><a class="nt to" href="<?php echo Url::log($value['gid']); ?>" rel="bookmark" title="详细阅读 <?php echo $value['title']; ?>"><?php echo $value['title']; ?></a></li>
				<?php endforeach; ?>
			</ul>
		</div>
	</div>
	<div class="main">
		<div class="slider" style="display:<?php echo _g('slider');?>">
			<div class="widget">
			<div class="textwidget">
					<?php echo _g('containertop1');?>
				</div>
			</div>
		</div>
<?php doAction('index_loglist_top'); ?>

<?php 
if (!empty($logs)):
foreach($logs as $value):
$logdes = blog_tool_purecontent($value['content'], 178);
$imgsrc = TEMPLATE_URL.'images/random/tb'.rand(1,20).'.jpg';
?>
	<ul class="post1">
		<li>
		<div class="article1">
			<div class="thumbnail_box">
				<div class="thumbnail">
				</div>
				<div class="thumbnail">
					<a href="<?php echo $value['log_url']; ?>" rel="bookmark" title="<?php echo $value['log_title']; ?>">
					<img width="297" height="224" src="<?php echo $imgsrc; ?>" class="attachment-medium wp-post-image" title="<?php echo $value['log_title']; ?>"/>
					</a>
				</div>
			</div>
			<h2><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>" rel="bookmark" title="<?php echo $value['log_title']; ?>'"><?php echo $value['log_title']; ?></a>&nbsp;</h2>
			<div class="info1">
				<i class="iconfont">&#xf0161;</i> 分类：<?php blog_sort($value['logid']); ?> &nbsp; <i class="iconfont">&#xf0296;</i> 日期： <?php echo gmdate('Y-n-j', $value['date']); ?>  &nbsp <i class="iconfont">&#xf0048;</i> 浏览：<?php echo $value['views']; ?>+ &nbsp;<i class="iconfont">&#x343b;</i><a href="<?php echo $value['log_url']; ?>#comments" title="《<?php echo $value['log_title']; ?>》上的评论">评论(<?php echo $value['comnum']; ?>)</a>
			</div>
			<div class="entry_post">
				<p><?php echo $logdes; ?></p>
				<p><?php blog_tag($value['logid']); ?> </p>
			</div>
		</div>
		</li>
	</ul>
	<div class="clear"></div>
<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>

<div class="navigation">
	<?php echo $page_url;?>
</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>