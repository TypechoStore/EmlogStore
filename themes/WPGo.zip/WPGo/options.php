<?php

/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
	'header' =>array(
		'type' => 'image',
		'name' => 'LOGO背景',
		'values' => array(
			TEMPLATE_URL . 'images/header_img.jpg',
		),
	),
	'sssq_xz' => array(
		'type' => 'radio',
		'name' => '试试手气显示',
		'values' => array(
			'x' => '显示',
			'bx' => '不显示',
		),
		'default' => 'bx',
	),
	'bkgg_xz' => array(
		'type' => 'radio',
		'name' => '博客公告显示',
		'values' => array(
			'x' => '显示',
			'bx' => '不显示',
		),
		'default' => 'bx',
	),
	'bkgg_lr' => array(
		'type' => 'text',
		'name' => '博客公告内容',
		'multi' => 'true',
		'values' => array(
			'刚刚我找一位大师算命，大师说我有血光之灾，我一想完了，问大师怎么办，大师给了我一包卫生巾！！！',
		),
	), 
	'tgsbl_xz' => array(
		'type' => 'radio',
		'name' => '多个侧边栏显示',
		'values' => array(
			'x' => '显示',
			'bx' => '不显示',
		),
		'default' => 'x',
	),
);
