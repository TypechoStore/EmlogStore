<?php
/*
Template Name:WPGo
Description:左南博客专用个人博客主题
Version:1.1.0
Author:王少凯-移植
Author Url:http://kmiwz.com/
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<!-- <?php echo $site_title; ?>欢迎您！-->
<!-- ------感觉自己萌萌哒------ -->
<!-- saved from url=(0018)<?php echo BLOG_URL; ?> -->
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=no">
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="stylesheet" type="text/css" media="all" href="<?php echo TEMPLATE_URL; ?>style.css">
<link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>css/shCore.css">
<link rel="stylesheet" type="text/css" media="all" href="<?php echo TEMPLATE_URL; ?>css/jquery.fancybox-1.3.4.css">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<script src="<?php echo TEMPLATE_URL; ?>js/js.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/ajax_comment.js" type="text/javascript"></script>
<style type="text/css">
body { background-image: url('<?php echo TEMPLATE_URL; ?>images/wpgo_background.jpg'); background-color: #f1f1f1; background-repeat: repeat; background-position: top left; background-attachment: scroll; }
.header-image { height: 150px; max-width: 1100px; background: url('<?php echo _g('header') ; ?>') no-repeat; }
.header-image span { display: block; color: #ffffff; }
</style>
<?php doAction('index_head'); ?>
<?php doAction('index_yw_yl');?>
</head>
<body>
<div id="wrap">
<div id="header">
	<div class="header-image">
		<a title="<?php echo BLOG_URL; ?>"><span class="site-name"><?php echo $blogname; ?></span><span class="sub-title"><?php echo $site_key; ?></span></a>
	</div>
	<div class="header-nav">
		<ul id="menu-navigation" class="nav-menu">
            <?php blog_navi();?>
            <?php if (_g('sssq_xz') == "x"): ?>	
			<?php shouqi_logs();?>
            <?php endif;?>
        </ul>			
            <ul class="mobile-nav nav-menu">
                <li><a href="javascript:;" id="mobile_nav">菜单</a>
			        <ul class="sub-menu" id="mobile_nav_list">
			            <?php xblog_navi();?>
			        </ul>
		        </li>
	        </ul>
        </div>
	</div>
<div class="sns-list"></div>
<div class="clr"></div>