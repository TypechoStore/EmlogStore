<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>
<div class="clr"></div>	</div>
	<div id="footer">
		<div class="footer-info">
			<div class="copyright">
			Copyright ©<?php echo date('Y',time())?>-<?php echo $blogname; ?> | <?php echo $icp; ?> | 
			勉强运行：<?php echo floor((time()-strtotime("2016-01-08"))/86400); ?>天 | <?php echo strtoupper(runtime_display()); ?> |  
			<a href="http://www.rkidc.net/?refcode=kmy28giar"  target="_blank">锐壳科技</a> | 
	        <?php echo $footer_info; ?>
			</div>
		</div>
		<a href="javascript:;" id="totop" style="display: inline;"><span></span>返回顶部</a>
	</div>
</div>
<script type="text/javascript">/**王少凯**http://kmiwz.com/*/function warning(){ if(navigator.userAgent.indexOf("MSIE")>0) { art.dialog.alert('复制成功！若要转载请务必保留原文链接，申明来源，谢谢合作！'); } else { alert("复制成功！若要转载请务必保留原文链接，申明来源，谢谢合作！"); }}document.body.oncopy=function(){warning();}</script>
<script type="text/javascript">eval(function(p,a,c,k,e,d){e=function(c){return c.toString(36)};if(!''.replace(/^/,String)){while(c--){d[c.toString(a)]=k[c]||c.toString(a)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('g(0).h(e(){e d(){0.9=0[b]?"╰(￣▽￣)╭ ☞ 大爷常来玩啊 ☜":a}f b,c,a=0.9;"2"!=4 0.8?(b="8",c="k"):"2"!=4 0.5?(b="5",c="j"):"2"!=4 0.6&&(b="6",c="l"),("2"!=4 0.7||"2"!=4 0[b])&&0.7(c,d,!1)});',22,22,'document||undefined||typeof|mozHidden|webkitHidden|addEventListener|hidden|title|||||function|var|jQuery|ready|Hi|mozvisibilitychange|visibilitychange|webkitvisibilitychange'.split('|'),0,{}))</script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery-1.8.3.min.js"></script>
<script type="text/javascript">
	var is_ajax = 'Y';
	var homeurl = '<?php echo BLOG_URL; ?>';
	var bookmarks = {"single":[{"link_rel":"friend","link_visible":"Y","link_url":"<?php echo BLOG_URL; ?>\/","link_description":"","link_target":"","link_name":"soz.im","link_img":"<?php echo BLOG_URL; ?>\/content\/templates\/wpgo\/images\/wpgo_sc_error.png"}]};
	var is_lh = 'Y';
	var wpgo_cb = function() {
			};
</script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/lighterCode.js"></script>
<script type="text/javascript" id="wpgo_global_js" src="<?php echo TEMPLATE_URL; ?>js/wpgo_global.js"></script>
<?php doAction('index_footer'); ?>
<?php doAction('myhk_player'); ?>
</body>
</html>