<?php
//widget：最新文章
function widget_newlog2($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
	<?php foreach($newLogs_cache as $value):$li = idby_img($value['gid']); ?>
    <a href="<?php echo Url::log($value['gid']); ?>" class="_ajx ease sb-border">
	<img width="160" height="120" src="<?php echo $li[0]; ?>" class="attachment-post-thumbnail wp-post-image" alt="<?php echo $value['title']; ?>" />
	<span class="publish"><?php echo $li[1]; ?></span>
	<span><?php echo $value['title']; ?></span>
	</a>

	<?php endforeach; ?>
<?php }?>
<?php
//widget：随机文章
function widget_random_log2($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>

	<?php foreach($randLogs as $value):$li = idby_img($value['gid']); ?>
	    <a href="<?php echo Url::log($value['gid']); ?>" class="_ajx ease sb-border">
	<img width="160" height="120" src="<?php echo $li[0]; ?>" class="attachment-post-thumbnail wp-post-image" alt="<?php echo $value['title']; ?>" />
	<span class="publish"><?php echo $li[1]; ?></span>
	<span><?php echo $value['title']; ?></span>
	</a>
	<?php endforeach; ?>

<?php }?>
<?php //文章缩略图获取 返回地址
function is_img($str){
  preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $str, $match);
  if(!empty($match[1])){
    return $match[1][0];
  }else{
    return TEMPLATE_URL . 'images/random/'.rand(1,12).'.jpg';
  }
}
?>
<?php
//通过id在文章中获取图片
function idby_img($logid){
$db = MySql::getInstance();
$sql = 	"SELECT content,date,views,comnum FROM ".DB_PREFIX."blog WHERE gid=".$logid."";
$list = $db->query($sql);
while($row = $db->fetch_array($list)){ 
	$li=array(is_img($row['content']),date('20y年m月d日',$row['date']),$row['views'],$row['comnum']);
	return $li;
 }} ?>
<?php 
if (!isset($_SERVER['REQUEST_TIME_FLOAT'])) {
	$_SERVER['REQUEST_TIME_FLOAT'] = microtime(TRUE);
}
function runtime_display() {
	echo sprintf('%.2fms', (microtime(TRUE) - $_SERVER["REQUEST_TIME_FLOAT"]) * 1000);
}
?>
<?php
//统计文章总数
function count_log_all(){
$db = MySql::getInstance();
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "blog WHERE type = 'blog'");
return $data['total'];
}
//统计评论总数
function count_com_all(){
$db = MySql::getInstance();
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "comment");
return $data['total'];
}
//统计分类总数
function count_sort_all(){
$db = MySql::getInstance();
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "sort");
return $data['total'];
}
//最后发表文章时间 
function last_post_log(){
$db = MySql::getInstance();
$sql = "SELECT * FROM " . DB_PREFIX . "blog WHERE type='blog' ORDER BY date DESC LIMIT 0,1";
$res = $db->query($sql);
$row = $db->fetch_array($res);
$date = date('Y-n-j',$row['date']);
return $date;       
}
//统计管理员总数
function count_user_admin(){
$db = MySql::getInstance();
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "user WHERE role = 'admin'");
return $data['total'];
};?>

<?php 
/**
 * 侧边栏组件、页面模块
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
function rcolor() {   
    $rand = rand(0,255);//随机获取0--255的数字
     return sprintf("%02X","$rand");//输出十六进制的两个大写字母   
}   
function rand_color(){   
    return '#'.rcolor().rcolor().rcolor();//六个字母   
}
?>
<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
	<div class="slide-box new-comment">
    <h2 class="sb-comment-title"><?php echo $title; ?></h2>
<a class="author _ajx ease sb-border" target="_blank">
	<?php if (!empty($user_cache[1]['photo']['src'])): ?>
	<img alt="" src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" class="avatar avatar-30 photo" height="30" width="30">
	<?php endif;?>
	<p><?php echo $user_cache[1]['des']; ?></p>
</a>
	</div>
<?php }?>

<?php
//widget：日历
function widget_calendar($title){ ?>
	<div class="slide-box new-comment">
    <h2 class="sb-comment-title"><?php echo $title; ?></h2>
<a class="author _ajx ease sb-border" target="_blank">
    <script>sendinfo('<?php echo BLOG_URL; ?>?action=cal','calendar');</script>

</a>
	</div>
<?php }?>
<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
	<div class="slide-box">
	<h2><?php echo $title; ?></h2>
	<div class="sb-tags-wrap sb-border" id="sb-tags">
		<?php 
		$tag_cache = array_slice($tag_cache,0,43);
		foreach($tag_cache as $value): ?>
		<a href="<?php echo Url::tag($value['tagurl']); ?>" class="tag-link" title="<?php echo $value['usenum']; ?> 篇文章" ><?php echo $value['tagname']; ?></a>
		<?php endforeach; ?>
    </div>
    </div>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	<div class="slide-box sb-category">
	<h2><?php echo $title; ?></h2>
	<?php
	foreach($sort_cache as $value):
		if ($value['pid'] != 0) continue;
	?>
	<a title="<?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)" href="<?php echo Url::sort($value['sid']); ?>" class="_ajx ease sb-border"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
	<?php endforeach; ?>
	<?php if (!empty($value['children'])): ?>
		<?php
		$children = $value['children'];
		foreach ($children as $key):
			$value = $sort_cache[$key];
		?>
	<a title="<?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)" href="<?php echo Url::sort($value['sid']); ?>" class="_ajx ease sb-border"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a><?php endforeach; ?>
	<?php endif; ?>
	<div class="clr"></div>
	</div>
<?php }?>
<?php
//widget：最新微语
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	?>
	<div class="slide-box new-comment">
<h2 class="sb-comment-title"><?php echo $title; ?></h2>
			<?php foreach($newtws_cache as $value): ?>
             <a class="author _ajx ease sb-border" target="_blank"><i class="fa fa-chevron-right"></i>&nbsp;<?php echo $value['t']; ?></a>
			<?php endforeach; ?>
</div>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['name'];
	$com_cache = $CACHE->readCache('comment');
	?>
<div class="slide-box new-comment">
	<h2><i class="fa fa-comments"></i>&nbsp;<?php echo $title; ?></h2>
	<div>
	<ul>
		<?php
		$i = 0;
		foreach($com_cache as $value):
		//if($value['name']!=$name):
		$i++;
		$articleUrl = Url::log($value['gid']);
		$url = Url::comment($value['gid'], $value['page'], $value['cid']);
		$db = MySql::getInstance();
		$sql = "SELECT title FROM ".DB_PREFIX."blog WHERE gid=".$value['gid'];
		$ret = $db->query($sql);
		$row = $db->fetch_array($ret);
		$articleTitle = $row['title'];
		$db = MySql::getInstance();
		$sql = "SELECT url FROM ".DB_PREFIX."comment WHERE cid=".$value['cid'];
		$ret = $db->query($sql);
		$row = $db->fetch_array($ret);
		$value['content'] = preg_replace('/\[img=?\]*(.*?)(\[\/img)?\]/e', '"<a rel=\"example_group\" class=\"cboxElement\" href=\"$1\" title=\"这是一张图片，点击进行查看\">图片</a>"', $value['content']);
		$value['content']=preg_replace("/{smile:(([1-4]?[0-9])|50)}/",'<img class="lazy" src="' . TEMPLATE_URL. 'img/smilies/$1.gif" />',$value['content']) ?>
        <li class="sb-border ease"><a class="author _ajx" href="<?php echo $url; ?>" title="<?php echo $value['name']; ?>" ><img alt="评论者头像" src="<?php echo mygetGravatar($value['mail']); ?>" class="avatar avatar-30 photo" height="30" width="30"><p><span><?php echo $value['name']; ?></span><?php echo preg_replace("/\[S(([1-4]?[0-9])|50)\]/",'<img alt="face" src="'.TEMPLATE_URL.'images/face/$1.gif";  />',preg_replace("|\[code\]|",'',$value['content'])); ?></p></a></li>
		<?php if($i==6){break;}  /*endif*/;endforeach; ?>
</ul>
<div class="clr"></div>
</div>
</div>
<?php }?>

<?php
//widget：最新文章
function widget_newlog($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');?>
	<div class="slide-box sb-tab" id="sb_panel">
		<div class="panel post-items current">
<h2 class="sb-comment-title" ><i class="fa fa-paint-brush"></i>&nbsp;<?php echo $title; ?></h2>
	<?php foreach($newLogs_cache as $value):$li = idby_img($value['gid']); ?>
    <a href="<?php echo Url::log($value['gid']); ?>" class="_ajx ease sb-border" title="<?php echo $value['title']; ?>" >
	<img width="160" height="120" src="<?php echo $li[0]; ?>" class="attachment-post-thumbnail wp-post-image" alt="<?php echo $value['title']; ?>" />
	<span class="publish"><?php echo $li[1]; ?></span>
	<span><?php echo $value['title']; ?></span>
	</a>
	<?php endforeach; ?>
		</div></div>
<?php }?>
<?php
//widget：随机文章
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	<div class="slide-box sb-tab" id="sb_panel">
		<div class="panel post-items current">
<h2 class="sb-comment-title" ><i class="random fa fa-random"></i>&nbsp;<?php echo $title; ?></h2>
	<?php foreach($randLogs as $value):$li = idby_img($value['gid']); ?>
	    <a href="<?php echo Url::log($value['gid']); ?>" class="_ajx ease sb-border" title="<?php echo $value['title']; ?>" >
	<img width="160" height="120" src="<?php echo $li[0]; ?>" class="attachment-post-thumbnail wp-post-image" alt="<?php echo $value['title']; ?>" />
	<span class="publish"><?php echo $li[1]; ?></span>
	<span><?php echo $value['title']; ?></span>
	</a>
	<?php endforeach; ?>
	</div></div>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
		<div id="scroll_box">
		<div class="slide-box-scroll">
		<div class="slide-box">
		<h2><?php echo $title; ?></h2>
		<div class="sb-custom sb-search">
		<form action="<?php echo BLOG_URL; ?>index.php?keyword=" id="sch_form">
	    <input type="text"  name="keyword" id="sch_val" class="key" required="">
	    <input type="submit" value="" id="sch_btn" class="sub" title="搜索">
        </form>
		</div>
		</div>
		</div>
	    </div>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
	<div class="slide-box sb-category">
	<h2><?php echo $title; ?></h2>
		<?php foreach($record_cache as $value): ?>
		<a href="<?php echo Url::record($value['date']); ?>" class="_ajx ease sb-border" title="<?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)" ><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a>
		<?php endforeach; ?>
			<div class="clr"></div>
	</div>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
	<div class="widget widget_text">
        <div class="slide-box-scroll"><div class="slide-box"><h2><?php echo $title; ?></h2>
        <div class="textwidget"><?php echo $content; ?></div>
			 </div>		</div>
	</div>
<?php } ?>
<?php
//widget：自建链接模板
function zjwidget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
    //if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
	?>
	    <?php foreach($link_cache as $value): ?>
		<li><a href="<?php echo $value['url']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
		<?php endforeach; ?>
<?php }?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
    //if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
	?>
		<div class="slide-box sb-category">
	<h2><?php echo $title; ?></h2>
	    <?php foreach($link_cache as $value): ?>
		<a href="<?php echo $value['url']; ?>" class="_ajx ease sb-border" target="_blank" title="<?php echo $value['des']; ?>" ><i class="fa fa-link"></i>&nbsp;<?php echo $value['link']; ?></a>
		<?php endforeach; ?>
		<div class="clr"></div>
	</div>
<?php }?> 
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	?>
	<?php
	foreach($navi_cache as $value):

        if ($value['pid'] != 0) {
            continue;
        }

		if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):
			?>
			<li id="menu-item-104"><a href="<?php echo BLOG_URL; ?>admin/">管理站点</a></li>
			<li id="menu-item-104"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
        $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-103' : '';
		?>
        <li id="menu-item" class="<?php echo $current_tab;?>">
        <a href="<?php echo $value['url']; ?>"><?php echo $value['naviname']; ?></a>
			<?php if (!empty($value['children'])) :?>
            <ul class="sub-menu">
                <?php foreach ($value['children'] as $row){
                        echo '<li id="menu-item" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item"><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></li>';
                }?>
			</ul>
            <?php endif;?>
            <?php if (!empty($value['childnavi'])) :?>
            <ul class="sub-menu">
                <?php foreach ($value['childnavi'] as $row){
                        $newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';
                        echo '<li id="menu-item" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item"><a href="' . $row['url'] . "\" $newtab >" . $row['naviname'].'</a></li>';
                }?>
			</ul>
            <?php endif;?>
		</li>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：导航
function xblog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	?>
	<?php
	foreach($navi_cache as $value):

        if ($value['pid'] != 0) {
            continue;
        }

		if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):
			?>
			<li><a href="<?php echo BLOG_URL; ?>admin/">管理站点</a></li>
			<li><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
        $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-103' : '';
		?>
        <li><a href="<?php echo $value['url']; ?>"><?php echo $value['naviname']; ?></a></li>
			<?php if (!empty($value['children'])) :?>

                <?php foreach ($value['children'] as $row){
                        echo '<li><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></li>';
                }?>
            <?php endif;?>
            <?php if (!empty($value['childnavi'])) :?>
                <?php foreach ($value['childnavi'] as $row){
                        $newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';
                        echo '<li><a href="' . $row['url'] . "\" $newtab >" . $row['naviname'].'</a></li>';
                }?>
            <?php endif;?>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：置顶
function topflg($top, $sortop='n', $sortid=null){
    if(blog_tool_ishome()) {
       echo $top == 'y' ? "<img src=\"".TEMPLATE_URL."/images/top.png\" title=\"首页置顶文章\" /> " : '';
    } elseif($sortid){
       echo $sortop == 'y' ? "<img src=\"".TEMPLATE_URL."/images/sortop.png\" title=\"分类置顶文章\" /> " : '';
    }
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
    <a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>" class="category ease _ajx" ><?php echo $log_cache_sort[$blogid]['name']; ?><i class="ease"></i></a>
	<?php endif;?>
<?php }?>
<?php
//blog：分类
function blog_sort2($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
    <a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?><i class="ease"></i></a>
	<?php endif;?>
<?php }?>
<?php
//blog：文章标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "<i class=\"icon-tag\"></i><a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>&nbsp;';
		}
		echo $tag;
	}
}
?>
<?php
//blog：文章标签
function blog_tags($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '标签：';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
		}
		echo $tag;
	}
}
?>
<?php
//blog：文章作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<span><i class="icon-user"></i><a href="'.Url::author($uid)."\" $title>$author</a></span>";
}
?>
<?php
//blog：文章作者
function blog_authorout($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	echo '<li class="archive"><a target="_blank" href="'.Url::author($uid)."\" title=\"阅读 $author 的其他文章\">阅读 $author 的其他文章</a></li>";
}
?>
<?php
//blog：文章作者
function blog_authorurl($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	echo ''.Url::author($uid).'';
}
?>
<?php
//blog：文章作者
function blog_authors($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	echo $author;
}
?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog):?>
<a title="<?php echo $prevLog['title'];?>" href="<?php echo Url::log($prevLog['gid']) ?>" class="prev ease"><span>上一篇 </span><?php echo $prevLog['title'];?></a>
	<?php endif;?>
	<?php if($nextLog && $prevLog):?>
	<?php endif;?>
	<?php if($nextLog):?>
<a title="<?php echo $nextLog['title'];?>" href="<?php echo Url::log($nextLog['gid']) ?>" class="next ease"><?php echo $nextLog['title'];?><span> 下一篇</span></a>					
	<?php endif;?>
<?php }?>
<?php 
//blog:多说获取Gravatar头像
function mygetGravatar($email, $s = 80, $d = 'mm', $g = 'g') {
	$hash = md5($email);
	$avatar = "http://gravatar.duoshuo.com/avatar/$hash?s=$s&d=$d&r=$g";
	return $avatar;
}
?>
<?php
function echo_levels($comment_author_email,$comment_author_url){
  $DB = MySql::getInstance();
global $CACHE;
	$user_cache = $CACHE->readCache('user'); 
	$adminEmail = '"'.$user_cache[1]['mail'].'"';
  if($comment_author_email==$adminEmail)
  {
    echo '<span class="comment-time" style="background-color:#e94c3d; color:#fff; padding:2px 8px; display:inline-block; border-radius:5px;">管理员</span>&nbsp;';
  }
  $sql = "SELECT cid as author_count,mail FROM ".DB_PREFIX."comment WHERE mail != '' and mail in ($comment_author_email) and hide ='n'";
  $res = $DB->query($sql);
  $author_count = mysql_num_rows($res);
   if($author_count>=2 && $author_count<10 && $comment_author_email!=$adminEmail)
    echo '<span class="comment-time" style="background-color:#78ACE9; color:#fff; padding:2px 8px; display:inline-block; border-radius:5px;">路过酱油</span>&nbsp;';
  else if($author_count>=10 && $author_count<20 && $comment_author_email!=$adminEmail)
    echo '<span class="comment-time" style="background-color:#78ACE9; color:#fff; padding:2px 8px; display:inline-block; border-radius:5px;">偶尔光临</span>&nbsp;';
  else if($author_count>=20 && $author_count<40 && $comment_author_email!=$adminEmail)
    echo '<span class="comment-time" style="background-color:#78ACE9; color:#fff; padding:2px 8px; display:inline-block; border-radius:5px;">常驻人口</span>&nbsp;';
  else if($author_count>=40 && $author_count<80 && $comment_author_email!=$adminEmail)
    echo '<span class="comment-time" style="background-color:#78ACE9; color:#fff; padding:2px 8px; display:inline-block; border-radius:5px;">以博为家</span>&nbsp;';
  else if($author_count>=80 &&$author_count<160 && $comment_author_email!=$adminEmail)
    echo '<span class="comment-time" style="background-color:#78ACE9; color:#fff; padding:2px 8px; display:inline-block; border-radius:5px;">情牵小博</span>&nbsp;';
  else if($author_count>=160 && $author_coun<320 && $comment_author_email!=$adminEmail)
    echo '<span class="comment-time" style="background-color:#78ACE9; color:#fff; padding:2px 8px; display:inline-block; border-radius:5px;">为博终老</span>&nbsp;';
  else if($author_count>=50 && $author_coun<60 && $comment_author_email!=$adminEmail)
    echo '<span class="comment-time" style="background-color:#78ACE9; color:#fff; padding:2px 8px; display:inline-block; border-radius:5px;">三世情牵</span>&nbsp;';
}
?>
<?php
//blog：评论列表
function blog_comments($comments){extract($comments);if($commentStacks):?>
	<div class="comment-header"></div>
	<?php endif;?>
  <div class="comm_charu"></div>
  <div class="comment-list">
	<?php	$isGravatar = Option::get('isgravatar');$comnum = count($comments);foreach($comments as $value){if($value['pid'] != 0){$comnum--;}}$page = isset($params[5])?intval($params[5]):1;$i= $comnum - ($page - 1)*Option::get('comment_pnum');foreach($commentStacks as $cid):$comment = $comments[$cid];$comm_name = $comment['url'] ? '<a title="点击访问：'.$comment['url'].'" href="'.$comment['url'].'" target="_blank" rel="external nofollow">'.$comment['poster'].'</a>' : $comment['poster'];$comment['content'] = preg_replace("/\[S(([1-4]?[0-9])|50)\]/",'<img src="'.TEMPLATE_URL.'images/face/$1.gif" alt="左南博客" />',$comment['content']);$comment['content'] = preg_replace("/\{smile:(([1-4]?[0-9])|50)\}/",'<img src="'.TEMPLATE_URL.'images/face/$1.gif" alt="左南博客" />',$comment['content']);$comment['content'] = preg_replace("/\[img=?\]*(.*?)(\[\/img)?\]/e", '"<a href=\"$1\" target=\"_blank\" rel=\"nofollow\" title=\"新窗口查看图片\"><img style=\"width:20px;height:20px;margin:0 5px\" src=\"'.TEMPLATE_URL.'images/img.gif\" alt=\"" . basename("$1") . "\" /></a>"', $comment['content']);$comment['content'] = preg_replace("/\[code=?\]*(.*?)(\[\/code)?\]/e", '"<pre>$1</pre>"', $comment['content']);$comment['content'] = preg_replace("/\[link=?\]*(.*?)(\[\/link)?\]/e", '"<a href=\"$1\" target=\"_blank\" rel=\"external nofollow\">$1</a>"', $comment['content']);?>
	<div class="comment" id="comment-<?php echo $comment['cid']; ?>">
		<a name="<?php echo $comment['cid']; ?>"></a>
		<?php if($isGravatar == 'y'): ?><div class="avatar"><img src="<?php echo mygetGravatar($comment['mail']); ?>" width="48" height="48" alt="<?php echo $comment['poster'];?>" title="<?php echo $comment['poster'];?>" /></div><?php endif; ?>
		<div class="comment-info">
			<span class="poster"><?php echo $comm_name;?></span><?php $mail_str="\"".strip_tags($comment['mail'])."\"";echo_levels($mail_str,"\"".$comment['url']."\"");?><span class="comment-time" style="background-color:#00a3cf; color:#fff; padding:2px 8px; display:inline-block; border-radius:5px;" ><i class="fa fa-clock-o mar-r-4"></i>&nbsp;<?php echo $comment['date']; ?></span>&nbsp;<span class="comment-reply"><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)"><i class="fa fa-share mar-r-4"></i>回复</a></span><div class="louceng"><?php echo $i;?>L&nbsp;&nbsp;</div>
			<div class="comment-content"><?php echo $comment['content']; ?></div>			
		</div>
		<?php blog_comments_children($comments, $comment['children']); ?>
	</div>
	<?php $i--;endforeach;?></div><div class="clear"></div>
    <div id="pagenavi"><?php echo $commentPageUrl;?></div>
<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){$isGravatar = Option::get('isgravatar');foreach($children as $child):$comment = $comments[$child];$comm_name = $comment['url'] ? '<a title="点击访问：'.$comment['url'].'" href="'.$comment['url'].'" target="_blank" rel="external nofollow">'.$comment['poster'].'</a>' : $comment['poster'];$comment['content'] = preg_replace("/\{smile:(([1-4]?[0-9])|50)\}/",'<img src="'.TEMPLATE_URL.'images/face/$1.gif" alt="左南博客" />',$comment['content']);$comment['content'] = preg_replace("/\[S(([1-4]?[0-9])|50)\]/",'<img src="'.TEMPLATE_URL.'images/face/$1.gif" alt="左南博客" />',$comment['content']);$comment['content'] = preg_replace("/\[img=?\]*(.*?)(\[\/img)?\]/e", '"<a href=\"$1\" target=\"_blank\" rel=\"nofollow\" title=\"新窗口查看图片\"><img style=\"width:20px;height:20px;margin:0 5px\" src=\"'.TEMPLATE_URL.'images/img.gif\" alt=\"" . basename("$1") . "\" /></a>"', $comment['content']);$comment['content'] = preg_replace("/\[code=?\]*(.*?)(\[\/code)?\]/e", '"<pre>$1</pre>"', $comment['content']);$comment['content'] = preg_replace("/\[link=?\]*(.*?)(\[\/link)?\]/e", '"<a href=\"$1\" target=\"_blank\" rel=\"external nofollow\">$1</a>"', $comment['content']);?>
	<div class="comment-children" id="comment-<?php echo $comment['cid']; ?>">
		<a name="<?php echo $comment['cid']; ?>"></a>
		<?php if($isGravatar == 'y'): ?><div class="avatar"><img src="<?php echo mygetGravatar($comment['mail']); ?>" width="36" height="36" alt="<?php echo $comment['poster'];?>" title="<?php echo $comment['poster'];?>" /></div><?php endif;?>
		<div class="comment-info"><span class="poster"><?php echo $comm_name;?></span><?php $mail_str="\"".strip_tags($comment['mail'])."\"";echo_levels($mail_str,"\"".$comment['url']."\"");?><span class="comment-time" style="background-color:#00a3cf; color:#fff; padding:2px 8px; display:inline-block; border-radius:5px;"><i class="fa fa-clock-o mar-r-4"></i>&nbsp;<?php echo $comment['date']; ?></span>&nbsp;<?php if($comment['level'] < 4):?><span class="comment-reply"><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)"><i class="fa fa-share mar-r-4"></i>回复</a></span><?php endif;?>
			<div class="comment-content"><?php echo $comment['content']; ?></div>			
		</div>
		<?php blog_comments_children($comments, $comment['children']);?>
	</div>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'):?>
	<div id="comment-place">
	<div class="comment-post" id="comment-post">
<form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
<div class="textarea"><textarea name="comment" id="comment" rows="10" tabindex="4" placeholder="既然来了说点什么吧"></textarea></div>
<span class="comment-time" style="background-color:#00a3cf; color:#fff; padding:2px 8px; display:inline-block; border-radius:5px;"></span>
<div class="comm_toolbar">
  <div class="comm_tool">
  <div class="smilebg"><div class="smile"><div class="arrow"></div><?php include View::getView('smiley');?></div></div>
  <div title="插入表情" onclick="tool_bq()" class="tool_bq"><span class="tool_bq-icon"></span></div>
<div class="comm_tijiao"><input type="submit" id="comment_submit" value="来一发" tabindex="6" /></div>
<div class="cancel-reply" id="cancel-reply" style="display:none"><a href="javascript:void(0);" onclick="cancelReply()">取消回复</a></div>
</div>
</div>
    <?php if(ROLE == 'visitor'): ?>
	<div class="commt_cutline">
	<span>&nbsp;名&nbsp;&nbsp;字：<input class="commt_input" type="text" name="comname" id="comname" value="<?php echo $ckname; ?>" size="20" tabindex="1"></span>
	<span>&nbsp;邮&nbsp;&nbsp;箱：<input class="commt_input" type="text" name="commail" id="commail" value="<?php echo $ckmail; ?>" size="20" tabindex="2"></span>
	<span>&nbsp;网&nbsp;&nbsp;址：<input class="commt_input" type="text" name="comurl" id="comurl" value="<?php echo $ckurl; ?>" size="20" tabindex="3"></span>
    </div>
   <?php else:?>
	<?php endif; ?>
<input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/>
</form>
</div>
</div>

<?php endif; ?>
<?php }?>
<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>

<?php
//图片链接
function pic_thumb($content){
    preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $content, $img);
    $imgsrc = !empty($img[1]) ? $img[1][0] : '';
	if($imgsrc):
		return $imgsrc;
	endif;
}
?>
<?php
//格式化内容工具
function blog_tool_purecontent($content, $strlen = null){
        $content = str_replace('继续阅读&gt;&gt;', '', strip_tags($content));
        if ($strlen) {
            $content = subString($content, 0, $strlen);
        }
        return $content;
}
?>
<?php
//widget：随机文章
function shouqi_logs(){
	$index_randlognum = 1;
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	<?php foreach($randLogs as $value): ?>
	<li id="menu-item" class="">
	<a href="<?php echo Url::log($value['gid']); ?>">试试手气</a>
	</li>
	<?php endforeach; ?>
<?php }?>
<?php
//文章页路径获取分类
function sortbread($sortid){
	global $CACHE; 
	$sort_cache = $CACHE->readCache('sort');
	?>
	<?php if (isset($sort_cache[$sortid])): ?>
	<?php if (isset($sort_cache[$sort_cache[$sortid]['pid']])): ?>
	<i class="icon-angle-right"></i><a href="<?php echo Url::sort($sort_cache[$sortid]['pid']); ?>"><?php echo $sort_cache[$sort_cache[$sortid]['pid']]['sortname']; ?></a>
	<?php endif; ?>
	<i class="icon-angle-right"></i><a href="<?php echo Url::sort($sortid); ?>"><?php echo $sort_cache[$sortid]['sortname'];?></a>
	<?php endif;?>
<?php }?>
<?php //分页函数
function sheli_fy($count,$perlogs,$page,$url,$anchor=''){
$pnums = @ceil($count / $perlogs);
$page = @min($pnums,$page);
$prepg=$page-1;                 //shuyong.net上一页
$nextpg=($page==$pnums ? 0 : $page+1); //shuyong.net下一页
$urlHome = preg_replace("|[\?&/][^\./\?&=]*page[=/\-]|","",$url);
//开始分页导航内容
$re = "";
if($pnums<=1) return false;	//如果只有一页则跳出	
if($page!=1) $re .=" <a href=\"$urlHome$anchor\" class='c-nav ease' >首页</a> "; 
if($prepg) $re .=" <a href=\"$url$prepg$anchor\" class='c-nav ease' >前页</a> ";
for ($i = $page-2;$i <= $page+2 && $i <= $pnums; $i++){
if ($i > 0){if ($i == $page){$re .= "<a class='on'>$i</a> ";
}elseif($i == 1){$re .= " <a href=\"$urlHome$anchor\"class='ease'>$i</a> ";
}else{$re .= " <a href=\"$url$i$anchor\"class='ease'>$i</a> ";}
}}
if($nextpg) $re .=" <a href=\"$url$nextpg$anchor\"class='c-nav ease'>后页</a> "; 
if($page!=$pnums) $re.=" <a href=\"$url$pnums$anchor\"class='c-nav ease' title=\"尾页\">尾页</a>";
return $re;}
?>
<?php
//blog：分类
function blog_sorts($i){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort');
	?>
	<div class="widget-title"><h2><i class="icon-list"></i>&nbsp;<?php echo $sort_cache[$i]['sortname']; ?></h2></div>
<?php }?>