<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
<!--微语页面-->
<div id="left">
    <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?> 
    <div class="home-post home-post-avatar">
        <div class="post-avatar">
            <a><img width="50" height="50" src="<?php echo $avatar; ?>" class="attachment-post-thumbnail wp-post-image " alt="<?php echo $author; ?>"></a>
        </div>
        <div class="post-content">
	        <div class="post-avatar-info">
                <span style="color:#00c3b6;font-size:14px;"><strong><?php echo $author; ?>:</strong></span><span><?php echo $val['t'].'<br/>'.$img;?></span>
            </div>
        </div>
        <div class="clr"></div>
    </div>
    <?php endforeach;?>
    <div id="pagenavi">
        <?php echo $pageurl;?>
    </div>
</div>
<!--微语页面-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>