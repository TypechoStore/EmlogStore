﻿<?php 
/**
 * 评论表情管理
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<a href="javascript:grin('[S1]')" title="微笑"><img src="<?php echo TEMPLATE_URL; ?>images/face/1.gif" alt="微笑"/></a>
<a href="javascript:grin('[S2]')" title="大笑"><img src="<?php echo TEMPLATE_URL; ?>images/face/2.gif" alt="大笑"/></a>
<a href="javascript:grin('[S3]')" title="拽"><img src="<?php echo TEMPLATE_URL; ?>images/face/3.gif" alt="拽"/></a>
<a href="javascript:grin('[S4]')" title="大哭"><img src="<?php echo TEMPLATE_URL; ?>images/face/4.gif" alt="大哭"/></a>
<a href="javascript:grin('[S5]')" title="亲亲"><img src="<?php echo TEMPLATE_URL; ?>images/face/5.gif" alt="亲亲"/></a>
<a href="javascript:grin('[S6]')" title="流汗"><img src="<?php echo TEMPLATE_URL; ?>images/face/6.gif" alt="流汗"/></a>
<a href="javascript:grin('[S7]')" title="喷血"><img src="<?php echo TEMPLATE_URL; ?>images/face/7.gif" alt="喷血"/></a>
<a href="javascript:grin('[S8]')" title="奸笑"><img src="<?php echo TEMPLATE_URL; ?>images/face/8.gif" alt="奸笑"/></a>
<a href="javascript:grin('[S9]')" title="囧"><img src="<?php echo TEMPLATE_URL; ?>images/face/9.gif" alt="囧"/></a>
<a href="javascript:grin('[S10]')" title="不爽"><img src="<?php echo TEMPLATE_URL; ?>images/face/10.gif" alt="不爽"/></a>
<a href="javascript:grin('[S11]')" title="晕"><img src="<?php echo TEMPLATE_URL; ?>images/face/11.gif" alt="晕"/></a>
<a href="javascript:grin('[S12]')" title="示爱"><img src="<?php echo TEMPLATE_URL; ?>images/face/12.gif" alt="示爱"/></a>
<a href="javascript:grin('[S13]')" title="害羞"><img src="<?php echo TEMPLATE_URL; ?>images/face/13.gif" alt="害羞"/></a>
<a href="javascript:grin('[S14]')" title="吃惊"><img src="<?php echo TEMPLATE_URL; ?>images/face/14.gif" alt="吃惊"/></a>
<a href="javascript:grin('[S15]')" title="惊叹"><img src="<?php echo TEMPLATE_URL; ?>images/face/15.gif" alt="惊叹"/></a>
<a href="javascript:grin('[S16]')" title="爱你"><img src="<?php echo TEMPLATE_URL; ?>images/face/16.gif" alt="爱你"/></a>
<a href="javascript:grin('[S17]')" title="吓死了"><img src="<?php echo TEMPLATE_URL; ?>images/face/17.gif" alt="吓死了"/></a>
<a href="javascript:grin('[S18]')" title="呵呵"><img src="<?php echo TEMPLATE_URL; ?>images/face/18.gif" alt="呵呵"/></a>