<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
	<div id="left">
	    <div class="breadcrumb"><span class="home-icon"><a href="<?php echo BLOG_URL; ?>">&nbsp;返回首页</a>&nbsp;&gt;&nbsp;<a href="#"><?php topflg($top); ?><?php echo $log_title; ?></a></span></div>
			<div class="wp-content">
				<h3 class="sc_h"><span><?php topflg($top); ?><?php echo $log_title; ?></span></h3>
			    <div class="post-content">
                    <?php echo $log_content; ?>
                </div>
			</div>
            <!--评论-->
            <div class="commt_posts ">
                <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
                <?php blog_comments($comments); ?>	
            </div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>