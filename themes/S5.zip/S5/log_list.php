<?php 
/**
 * 日志列表
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');} 
?>
  <?php foreach($logs as $value): ?>
	<div class="desc">
  	<div class="logtitle"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></div>
    <div class="line sline"></div>
    <div class="logdate"><?php echo gmdate('Y-m-d', $value['date']); ?></div>
    <div class="logdesc"><?php echo $value['log_description']; ?></div>
  </div>
  <?php endforeach; ?>
 	<div class="logpage"><?php echo $logpage; ?></div>
<?php include View::getView('footer'); ?>