<?php 
/**
 * 输出日志
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');} 
?>
	<div class="echo">
  	<div class="logtitle echotitle"><?php echo $log_title; ?></div>
    <div class="line sline"></div>
    <div class="logdate"><?php echo gmdate('Y-m-d', $date); ?></div>
    <div class="logecho"><?php echo $log_content; ?></div>
  </div>
  <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
  <?php blog_comments($comments); ?>
<?php include View::getView('footer'); ?>