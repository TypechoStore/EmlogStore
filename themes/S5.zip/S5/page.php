<?php 
/**
 * 自定义页面
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');} 
?>
	<div class="echo">
  	<div class="logtitle echotitle"><?php echo $log_title; ?></div>
    <div class="logecho"><?php echo $log_content; ?></div>
  </div>
  <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
  <?php blog_comments($comments); ?>
<?php include View::getView('footer'); ?>