<?php 
/**
 * 尾部
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');} 
?>
	<div class="link">
  	<div class="linktitle">链接</div>
    <div class="line sline"></div>
		<div class="links"><?php widget_link(); ?></div>
  </div>
  <div class="footer">Powered by <a href="http://emlog.net">Emlog</a>. Written by <a href="http://sinkery.com">Sinkery</a>.</div>
</div>
<div class="why"></div>
<div class="gotop"><i class="fa fa-chevron-up"></i></div>
<script>
$(document).ready(function(){
$(window).scroll(function(){
if($(this).scrollTop()!=0){
$('.gotop').fadeIn();}
else{
$('.gotop').fadeOut();} });
$('.gotop').click(function(){
$('body,html').animate({scrollTop:0},1200);
});
});
$(document).ready(function(){
$(window).scroll(function(){
var h = $("body").scrollTop();
var j = 1 - h / 300;
if(h > 300){
	$(".header").css("opacity","0");
}else{
	$(".header").css("opacity",j);
}
})
});
$('#simple-menu').sidr({
	displace: false,	
});
</script>
</body>
</html>