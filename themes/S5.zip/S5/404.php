<?php 
/**
 * 自定义404页面
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>404 Not Found</title>
<style>
*{
	margin:0;
	padding:0;
	font-family:"微软雅黑";
}
.notfound{
	margin-top:250px;
	text-align:center;
}
.info{
	font-size:24px;
}
.back{
	display:inline-block;
	width:100px;
	height:50px;
	line-height:50px;
	text-align:center;
	color:#fff;
	margin-top:30px;
	font-size:14px;
	background:#8CD1A8;
	-moz-transition:all 0.4s;
	-webkit-transition:all 0.4s;
	transition:all 0.4s;
}
.back:hover{
	background:#9ED8B6;
	-moz-transition:all 0.4s;
	-webkit-transition:all 0.4s;
	transition:all 0.4s;
}
</style>
</head>
<body>
<div class="notfound">
	<div class="info">您所请求的页面未找到 :(</div>
  <a href="<?php echo BLOG_URL; ?>"><div class="back">返回首页</div></a>
</div>
</body>
</html>