<?php
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="frame_content">
<div id="content">
	<div class="title">
		<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
	</div>
	<div class="date">
		作者：<?php blog_author($author); ?> &nbsp; 发布于：<?php echo gmdate('Y-n-j G:i l', $date); ?> &nbsp; <?php blog_sort($logid); ?> &nbsp; <?php editflg($logid,$author); ?>
	</div>
	<div class="cont_content">
		<?php echo $log_content; ?>
		<div class="clear"></div>
	</div>
 <!--非图形附件列表，5.0己非必须-->
 <!--<div class="att"><?php //blog_att($logid); ?></div>-->
	<div class="under">
		<p class="tag"><?php blog_tag($logid); ?></p>
		<p class="count">
		<a href="<?php echo $log_url; ?>#comments">评论(<?php echo $comnum; ?>)</a> &nbsp;
		<a href="<?php echo $log_url; ?>#tb">引用(<?php echo $tbcount; ?>)</a> &nbsp;
		<a href="<?php echo $log_url; ?>">浏览(<?php echo $views; ?>)</a>
		</p>
	</div>
	<div class="blank" style="clear:both;"></div>
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	<div class="blank"></div>
	<?php doAction('log_related', $logData); ?>
	<div style="height:1px; overflow:hidden;">
		<p style="margin-top:-45px;"><a name="comm_respond"></a></p><!--设置评论输入框锚点-->
	</div>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<?php if ($comnum > 0) {blog_comments($comments,$params);} ?>
</div><!--#content.End-->
</div><!--#frame_content.End-->
<?php
	include View::getView('side');
	include View::getView('footer');
?>