<?php
/*
 *首页日志列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="frame_content">
<div id="content">
<div class="blank" style="height:10px;"></div>
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value):
	preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
	$imgsrc = !empty($img[1]) ? $img[1][0] : ''; ?>
	<div class="box">
		<div class="box_abstract" <?php if($imgsrc){echo 'style="text-align:center;"';} ?>>
			<a href="<?php echo $value['log_url']; ?>">
			<div style="height:27px; line-height:27px; overflow:hidden;">
			&nbsp;<font class="top"><?php topflg($value['top']); ?></font>
			<font style="font-weight:bold;"><?php echo $value['log_title']; ?></font>
			</div>
			<?php if($imgsrc): ?>
				<img src="<?php echo $imgsrc; ?>" />
			<?php else: ?>
				<?php echo $value['log_description']; ?>
		  <div class="clear"></div>
			<?php endif; ?>
			</a>
		</div>
  <!--非图形附件列表，5.0己非必须-->
  <!--<div class="att"><?php //blog_att($value['logid']); ?></div>-->
		<div class="box_ps">
			<p style="margin:2px 5px; padding:0px;">
			<a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a> &nbsp;
			<a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a> &nbsp;
			</p>
		</div>
	</div>
<?php endforeach; ?>
<div class="clear" style="height:7px;"></div>
<div id="pagenavi">
	<?php echo $page_url; ?>
</div>
</div><!--#content.End-->
</div><!--#frame_content.End-->
<?php
	include View::getView('side');
	include View::getView('footer');
?>