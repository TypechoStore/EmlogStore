<?php
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="frame_content">
<div id="content">
	<div style="width:100%; margin-bottom:8px;">
		<h2><?php echo $log_title; ?></h2>
	</div>
	<div class="cont_content">
		<?php echo $log_content; ?>
		<div class="clear"></div>
	</div>
 <!--非图形附件列表，5.0己非必须-->
 <!--<div class="att"><?php //blog_att($logid); ?></div>-->
	<div style="height:1px; overflow:hidden;">
		<p style="margin-top:-45px;"><a name="comm_respond"></a></p><!--设置评论输入框锚点-->
	</div>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<?php if ($comnum > 0) {blog_comments($comments,$params);} ?>
</div><!--#content.End-->
</div><!--#frame_content.End-->
<?php
	include View::getView('side');
	include View::getView('footer');
?>
