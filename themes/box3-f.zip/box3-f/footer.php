<?php
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
</div><!--#frame.End-->
<div class="clear" style="height:10px;"></div>
<div id="footerbar">
	<a name="bottom"></a><!--设置底部锚点-->
	<a href=# target=_self><?php echo $blogname; ?></a> &copy; 2011 &nbsp;  Powered by <a href="http://www.emlog.net" title="Emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">Emlog</a> &nbsp; Designed by <a href="http://emlog8.sinaapp.com/" target="_blank">Emlog吧</a> &nbsp; <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> &nbsp; <?php doAction('index_footer'); ?> &nbsp; <?php echo $footer_info; ?>
</div>
</div><!--#wrap.End-->
<!--[if lt IE 7]></div><![endif]--><!--#mybody.End-->
<!--========== JS调用 ==========-->
<!-- JiaThis分享条 -->
<script type="text/javascript" src="http://v2.jiathis.com/code_mini/jia.js" charset="utf-8"></script>
<!-- JiaThis分享条.End -->
<!--========== JS调用.End ==========-->
</body>
</html>
