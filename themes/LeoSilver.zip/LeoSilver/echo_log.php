﻿<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="wrapper">
<div id="content_post">
<div class="post">
    <div class="title">
      <h3><?php echo date('Y-n-j G:i', $date); ?> </h3>
      <h2><?php topflg($top); ?><?php echo $log_title; ?>	</h2>
      <span> by <?php blog_author($author); ?> , 发布时间：<span><?php echo date('Y-n-j G:i', $date); ?></span> , <?php blog_sort($logid); ?> , <span>已有<?php echo $comnum; ?>条评论</a></span></span> <h3><?php editflg($logid,$author); ?></h3>
    </div>
    <div class="entry">
	<?php echo $log_content; ?>
	    </div>
	<p class="att"><?php blog_att($logid); ?></p>
    <p class="postmetadata"><?php blog_tag($logid); ?></p>
    	
    	   <p align="right"><a href="#" class="gotop" onclick="goTop();return false;" title="返回顶部">返回顶部</a></p>
  </div>
  	  
  	  <?php doAction('log_related', $logData); ?>
  	  	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
    <?php blog_trackback($tb, $tb_url, $allow_tb); ?>
    	  	      	<div class="postcomments">
 <h3 id="comments">Responses to “<?php echo $log_title; ?>”</h3>
 		      <div id="comments">
    <div id="cmtswitcher">

 		     <a id="commenttab" class="curtab" href="<?php echo BLOG_URL; ?>index.php?action=#comments"></a> <span class="addcomment"><a href="#respond">Leave a comment</a></span>
      <div class="clear"></div>
	<?php blog_comments($comments); ?>
	<?php 
blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    <p align="right"><a href="#" class="gotop" onclick="goTop();return false;" title="返回顶部">返回顶部</a></p>
    </div>
	<div style="clear:both;"></div>
</div><!--end #contentleft-->
		</div>
 </div>
<?php
 include View::getView('footer');
?>