﻿<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="wrapper">
<div id="content_post">
<div class="post">
    <div class="title">
      <h2><?php echo $log_title; ?>	</h2>
    </div>
    <div class="entry">
	<?php echo $log_content; ?>
	    </div>
    	
    	   <p align="right"><a href="#" class="gotop" onclick="goTop();return false;" title="返回顶部">返回顶部</a></p>
  </div>
  	  
    	  	      	<div class="postcomments">
 <h3 id="comments">Responses to “<?php echo $log_title; ?>”</h3>
 		      <div id="comments">
    <div id="cmtswitcher">

 		     <a id="commenttab" class="curtab" href="<?php echo BLOG_URL; ?>index.php?action=#comments"></a> <span class="addcomment"><a href="#respond">Leave a comment</a></span>
      <div class="clear"></div>
	<?php blog_comments($comments); ?>
	<?php 
blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    
    <p align="right"><a href="#" class="gotop" onclick="goTop();return false;" title="返回顶部">返回顶部</a></p>
	<div style="clear:both;"></div>
</div><!--end #contentleft-->
 </div></div></div></div></div></div></div></div></div></div>
</div><!--end #contentleft-->
<?php
 include View::getView('footer');
?>