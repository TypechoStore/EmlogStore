<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="wrapper">
<div id="content">
<div class="postlist">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<div class="post">
  		<div class="title">
        <h3><?php echo gmdate('Y-n-j G:i', $value['date']); ?> </h3>
     	<h2><?php topflg($value['top']); ?>
<a href="<?php echo $value['log_url']; ?>" rel="bookmark" title="Permanent Link to <?php echo $value['log_title']; ?>">
<?php echo $value['log_title']; ?></a></h2>
<small>by <?php blog_author($value['author']); ?>  , 
<a href="<?php echo $value['log_url']; ?>#comments">
<?php echo $value['comnum']; ?> Comments</a> ,
<?php blog_sort($value['logid']); ?> 
<span>被围观<?php echo $value['views']; ?>次</span>
</small>	
		</div>
		<div class="entry">
		<?php echo $value['log_description']; ?>
		</div>
		<p class="postmetadata">
		<p class="tag"><?php blog_tag($value['logid']); ?></p></p>
		<p class="att"><?php blog_att($value['logid']); ?></p>
  </div>
    <?php endforeach; ?>
    </div>
    <?php include ('side.php');?>
	</div>	
	<div class="navigation">
          <ol class="pages">
            <li class="current">
    <?php echo $page_url;?>
    </li>
    </ol>   
	</div>
	<div class="clear"></div>  
</div>
	</div>
	</div>
<?php include ('footer.php');?>