<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="info">
			<div class="wrap">
				<div class="mpos" id="description">作者 <?php blog_author($author); ?>，发布于 <em><?php echo gmdate('Y-n-j G:i l', $date); ?></em>，分类 <?php blog_sort($logid); ?> <?php editflg($logid,$author); ?></div>
				<div class="lpos" id="type">日志</div>
                <div class="rpos" id="value"><?php echo $blogname; ?></div>
			</div>
		</div>
	</div>

<div id="cnt">
		<div class="wrap">
        	<div id="main" class="mpos">
				<div class="post">
					<h1 class="entry-title"><?php topflg($top); ?><?php echo $log_title; ?></h1>
						<div class="entry-content single">
	<?php echo $log_content; ?>
	<p class="att"><?php blog_att($logid); ?></p>
	<?php doAction('log_related', $logData); ?>
                        </div>
                        <div class="post-copyright" style="background-image: url(<?php get_blogavatarurl(); ?>);-o-background-size: 80px 80px;-webkit-background-size: 80px 80px;">
                        	<div class="post-licence">
                            	<a rel="license" href="http://creativecommons.org/licenses/by-sa/3.0/" title="知识共享许可协议" target="_blank"><img alt="知识共享许可协议" style="border-width:0" src="http://i.creativecommons.org/l/by-sa/3.0/80x15.png" /></a><br />评论(<?php echo $comnum; ?>) 浏览(<?php echo $views; ?>) 引用(<?php echo $tbcount; ?>)
                                </div>
                            <strong>引用地址:</strong><span class="post-permalink"><?php blog_trackback($tb, $tb_url, $allow_tb); ?></span><br /><strong>Tags:</strong><span class="post-tags"><?php blog_tag($logid); ?></span>           
                        </div>
                          <div class="clear"></div>
                        <div class="post-nav">
						<?php neighbor_log($neighborLog); ?>
                        </div>                   
                </div>
                <!--end post-->
                <div class="clear"></div>

	<div id="comments">
    	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    </div>
 </div>
        	<div id="lbar" class="lpos">
                <?php 
				widget_blogger('Blogger');
				widget_sort('分类目录');
                widget_archive('日志归档');
                widget_tag('主题标签');
                widget_getstat('数据统计');     
                widget_link('链接表');
				?>
                <div class="line"></div>
            </div> 
<div id="rbar" class="rpos">
<?php
 include View::getView('side');
?>
</div><!--end #siderbar-->
<?php
 include View::getView('footer');
?>