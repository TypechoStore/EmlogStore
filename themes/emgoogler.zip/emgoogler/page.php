<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="info">
			<div class="wrap">
				<div class="mpos" id="description">这里显示你的内容(在page.php中修改)</div>
                <div class="lpos" id="type">页面</div>
                <div class="rpos" id="value"><?php echo $blogname; ?></div>
			</div>
		</div>
	</div>
	<div id="cnt">
		<div class="wrap">
        	<div id="main" class="mpos">

				<div class="page post">

		<h1 class="entry-title"><?php echo $log_title; ?></h1>
		<div class="entry-content">
      <?php echo $log_content; ?>
	<p class="att"><?php blog_att($logid); ?></p>
		</div>
	</div>
	<!--end post-->
	<div class="clear"></div>
	<div id="comments">
    	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    </div>
 </div>
        	<div id="lbar" class="lpos">
                <?php 
				widget_blogger('Blogger');
				widget_sort('分类目录');
                widget_archive('日志归档');
                widget_tag('主题标签');
                widget_getstat('数据统计');     
                widget_link('链接表');
				?>
                <div class="line"></div>
            </div> 
<div id="rbar" class="rpos">
<?php
 include View::getView('side');
 ?>
</div><!--end #siderbar-->
<?php
 include View::getView('footer');
?>