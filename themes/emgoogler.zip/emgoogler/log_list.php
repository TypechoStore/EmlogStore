<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="info">
			<div class="wrap">
				<div class="mpos" id="description">这里显示你的内容(在log_list.php中修改)</div>
				<div class="lpos" id="type"><?php
        if(isset($sortName)){
		?>
        分类
		<?php
		}elseif(isset($tag)){
		?>
        标签
		<?php
		}elseif(isset($author)){
		?>
        作者
		<?php
		}elseif(isset($record)){
		?>
        归档
		<?php
		}elseif(isset($keyword)){
		?>
        搜索
		<?php
		}else{
		?>
        首页
        <?php
			} 
		?></div>
                <div class="rpos" id="value"><?php
        if(isset($sortName)){
		?>
        <?php echo $sortName; ?>
		<?php
		}elseif(isset($tag)){
		?>
        <?php echo $tag; ?>
		<?php
		}elseif(isset($author)){
		?>
        <?php echo $author_name; ?>
		<?php
		}elseif(isset($record)){
		?>
        <?php 
		if(strlen($record) == 6)
		{
			$rec_date = $record."16";
			$rec_sjc = (int)strtotime($rec_date);
			echo date("Y年m月",$rec_sjc);
		}
		else
		{
			$rec_date = $record;
			$rec_sjc = (int)strtotime($rec_date);
			echo date("Y年m月d日",$rec_sjc);
		}
		?>
		<?php
		}elseif(isset($keyword)){
		?>
        <?php echo $keyword; ?>
		<?php
		}else{
		?>
        <?php echo $blogname; ?>
        <?php
			} 
		?></div>
			</div>
		</div>
	</div>
	<div id="cnt">
		<div class="wrap">
        	<div id="main" class="mpos">
            <?php doAction('index_loglist_top'); ?>
            <?php foreach($logs as $value): ?>
				<div class="post">
                	<h2 class="entry-title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>" title="Permalink to <?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></h2>
                	<div class="entry-meta">
                		<span class="post-permalink"><?php echo $value['log_url']; ?></span>
                		<span>&nbsp;-&nbsp;</span>
                		<span class="post-date"><?php echo gmdate('Y年n月j日', $value['date']); ?></span>
                		<span>-</span>
                		<span><?php blog_sort($value['logid']); ?></span>
               			<span>-</span>
                		<span><a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a></span>
                		<span>-</span>
               			<span>浏览(<?php echo $value['views']; ?>)</span>
						<?php editflg($value['logid'],$value['author']); ?>
               		</div>
					<div class="entry-content">
            <?php echo $value['log_description']; ?>
	<p class="att"><?php blog_att($value['logid']); ?></p>
                    </div>
				</div>
            <?php endforeach; ?>
                        <?php if($logs == NULL) { ?>
            <div id="not-found" class="post">
		<h1 class="entry-title">没有找到结果</h1>
		<div class="entry-content">
			<div style="padding-right:200px; height:250px; background:url(<?php echo TEMPLATE_URL; ?>images/404.png) no-repeat top right;">
				<p>
					I'm sorry.
				</p>
				<p>
					The requested contents include <strong><u><i><?php echo $keyword; ?></i></u></strong>
					was not found on this site.
				</p>
				<p>建议您 精简关键词 再尝试搜索</p>
			</div>
		</div>
	</div>
    <?php } ?>
    			<div class="clear"></div>
                <div class="archives-navi">
                	<?php echo $page_url;?>
                </div>
        	</div>          
        	<div id="lbar" class="lpos">
                <?php 
				widget_blogger('Blogger');
				widget_sort('分类目录');
                widget_archive('日志归档');
                widget_tag('主题标签');
                widget_getstat('数据统计');     
                widget_link('链接表');
				?>
                <div class="line"></div>
            </div> 
<div id="rbar" class="rpos">
<?php 
 include View::getView('side');
 ?>
</div><!--end #siderbar-->
<?php
 include View::getView('footer');
?>