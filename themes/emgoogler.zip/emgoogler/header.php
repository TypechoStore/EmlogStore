<?php
/*
Template Name:emgoogler
Description:移植自wp模板igoogler
Version:1.0
Author:原作者：Willings 移植修改：YoMoXi
Author Url:http://www.yomoxi.com
Sidebar Amount:1
ForEmlog:4.1.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script type='text/javascript' src='http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.7.1.min.js?ver=3.3.1'></script>
<?php doAction('index_head'); ?>
</head>
<body>
	<div id="header">
		<div id="nav">
			<div class="menu website">
            	<ul>
            		<li class="<?php echo $curpage == CURPAGE_HOME ? 'current' : 'common';?>"><a href="<?php echo BLOG_URL; ?>">首页</a></li>
					<?php if($istwitter == 'y'):?>
                    <li class="<?php echo $curpage == CURPAGE_TW ? 'current' : 'common';?>"><a href="<?php echo BLOG_URL; ?>t/">微语</a></li>
					<?php endif;?>
					<?php 
					global $CACHE; 
					$navi_cache = $CACHE->readCache('navi');
					foreach ($navi_cache as $key => $val):
					if ($val['hide'] == 'y'){continue;}
					if (empty($val['url'])){$val['url'] = Url::log($key);}
					$newtab = $val['newtab'] == 'y' ? 'target="_blank"' : '';
					$val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
					?>
                    <li class="<?php echo isset($logid) && $key == $logid ? 'current' : 'common';?>"><a href="<?php echo $val['url']; ?>" <?php echo $newtab;?>><?php echo $val['naviname']; ?></a></li>
					<?php endforeach;?>
					<?php doAction('navbar', '<li class="common">', '</li>'); ?>
                </ul>
            </div> 
			<ul id="mood">
				<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
				<li class="common"><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
				<li class="common"><a href="<?php echo BLOG_URL; ?>admin/">管理中心</a></li>
				<li class="common"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
				<?php else: ?>
				<li class="common"><a href="<?php echo BLOG_URL; ?>admin/">登录</a></li>
				<?php endif; ?>
			</ul>
		</div>
		<div id="top">
			<div class="wrap">
				<div class="search_box mpos">
						<form class="search_box_form" action="<?php echo BLOG_URL; ?>index.php">
						<table>
							<tr>
								<td style="padding-right: 10px;"><div class="lst">
										<input name="keyword" type="text" value="" />
									</div></td>
								<td style="width: 70px;"><div class="lsb">
										<button type="submit">&nbsp;</button>
									</div></td>
							</tr>
						</table>
					    </form>
				</div>
				<div id="logo" class="lpos">
                <a href="<?php echo BLOG_URL; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/logo.png" alt="<?php echo $blogname; ?>" /></a>
				</div>
				<div class="rpos"><div id="header-plusone"></div></div>
			</div>
		</div>