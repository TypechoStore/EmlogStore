<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
        </div>
    </div>  
    <div id="footer">
    	<div class="wrap">
        	<div class="search_box mpos">
            	<form class="search_box_form" action="<?php echo BLOG_URL; ?>index.php">
                	<table>
                    	<tr>
                        	<td style="padding-right: 10px;"><div class="lst"><input name="keyword" type="text" value="" /></div></td>
							<td style="width: 70px;"><div class="lsb"><button type="submit">&nbsp;</button></div></td>
						</tr>
					</table>
				</form>
                <div id="copyright"><?php echo $blogname; ?> &copy; 2012 这里显示底部链接导航<br /> <small>Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">emlog</a> Theme by <a href="http://zyj.me/" target="_blank">Willings</a> & <a href="http://www.yomoxi.com/" target="_blank">YoMoXi</a> <?php echo $footer_info; ?></small></div>
            </div>
        </div>
    </div><a href="#top" id="top-link" title="返回顶部"></a>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>images/common.js"></script>
<?php doAction('index_footer'); ?>
</body>
</html>
