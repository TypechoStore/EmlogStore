<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--end #content--></div>
<div style="clear:both;"></div>
<div id="footer">
<div id="footerbar">
  Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>
  技术支持： <a href="http://www.guizai.net" title="鬼仔" target="_blank">鬼仔网络</a>
  <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
  <?php doAction('index_footer'); ?>
</div><!--end #footerbar--></div>
<!--end #wrap-->
</body>
</html>