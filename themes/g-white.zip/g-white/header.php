<?php
/*
Template Name:G-white
Description:简单模板，适合博客……本模版原作者主页为：http://www.alanoy.com/，由syan移植，FOR EMLOG5.0由蜗牛完成
Author:蜗牛修改，syan移植
Author Url:http://www.574auto.com
Sidebar Amount:1
ForEmlog:5.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml>
<head>
<meta http-equiv="content-type"  content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="Bluefish 2.0.3" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/all.js"></script>
<?php doAction('index_head'); ?>
</head>

<body>
<div id="wrapper" class="hfeed">
	<div id="header">
		<div id="masthead">
			<div id="branding">
				<div id="site-title">
					<span>
						<a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>" rel="home"><?php echo $blogname; ?></a>
					</span>
				</div>
			</div><!-- #branding -->

			<div id="access">
				<div class="skip-link screen-reader-text"><a href="" title=""></a></div>
				<div class="menu">
                <div id="nav"><?php blog_navi();?></div>
	            </div>
				<div id="rss"><a href="<?php echo BLOG_URL; ?>rss.php" title="Posts RSS feed" rel="alternate" type="application/rss+xml"><span>RSS</span></a></div>
			</div><!-- #access -->
		</div><!-- #masthead -->
	</div><!-- #header -->

	<div id="main">
