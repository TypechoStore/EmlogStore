<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
		<div id="container">
			<div id="content" role="main">
				<div class="page type-page status-publish hentry">
						<h1 class="entry-title"><?php echo $log_title; ?></h1>
					<div class="entry-content">
						<?php echo $log_content; ?>
						<span class="page-edit-link">
							<?php editflg($logid,$author); ?>						
						</span>
					</div><!-- .entry-content -->
				</div><!-- #post-## -->

			<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<?php blog_comments($comments); ?>


			</div><!-- #content -->
		</div><!-- #container -->

<?php
 include View::getView('side');
 include View::getView('footer');
?>