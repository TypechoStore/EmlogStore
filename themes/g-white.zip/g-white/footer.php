<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	</div><!-- #main -->

	<div id="footer" role="contentinfo">
		<div id="colophon">

			<div id="site-info">
				 Copyright &copy; 2007-2012 <a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>" rel="home"><?php echo $blogname; ?></a>. Powered By <a href="http://www.emlog.net"  rel="generator">emlog</a> | Theme by Alan Ouyang</a>. | <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> | <?php echo $footer_info; ?> | <?php doAction('index_footer'); ?>
			</div><!-- #site-info -->

			<div id="site-generator">
				<a href="#header" rel="nofollow" title="Go to the header">Go Top</a>
			</div><!-- #site-generator -->

		</div><!-- #colophon -->
	</div><!-- #footer -->

</div><!-- #wrapper -->

</body>
</html>
