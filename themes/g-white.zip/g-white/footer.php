﻿<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	</div><!-- #main -->

	<div id="footer" role="contentinfo">
		<div id="colophon">

			<div id="site-info">
				Powered By <a href="http://emlog.net"  rel="generator">emlog</a> | Copyright &copy; 2012 <a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>" rel="home"><?php echo $blogname; ?></a> - Theme simple-Green by <a href="http://blog.vsgoo.com">文竹</a><?php echo $footer_info; ?>
			</div><!-- #site-info -->

			<div id="site-generator">
			<a href=<?php echo BLOG_URL; ?>sitemap.xml>sitemap</a> 
			</div><!-- #site-generator -->

		</div><!-- #colophon -->
	</div><!-- #footer -->

</div><!-- #wrapper -->
<?php doAction('index_footer'); ?>
</body>
</html>
