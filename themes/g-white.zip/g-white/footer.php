<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	</div><!-- #main -->

	<div id="footer" role="contentinfo">
		<div id="colophon">

			<div id="site-info">
				Powered By <a href="http://emlog.net"  rel="generator">emlog</a> | Copyright &copy; 2011 <a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>" rel="home"><?php echo $blogname; ?></a>. Theme G-White by <a href="http://onoboy.com" title="Syan's Blog">Syan</a>移植<a href="http://www.alanoy.com/" title="Alan's World">Alan Ouyang</a>.<?php echo $footer_info; ?>
			</div><!-- #site-info -->

			<div id="site-generator">
				<a href="#header" rel="nofollow" title="Go to the header">Go Top</a>
			</div><!-- #site-generator -->

		</div><!-- #colophon -->
	</div><!-- #footer -->

</div><!-- #wrapper -->
<?php doAction('index_footer'); ?>
</body>
</html>
