<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
			<div id="content" role="main">
			
			<?php 
	if ($params[1]=='sort'){ 
		if(isset($_GET['sort'])){
			$sortname= $sort_cache[$_GET['sort']]['sortname'];
		}else{
			foreach($sort_cache as $val){
				if($val['alias']!='' && $params[2]==$val['alias']) $sortname= $val['sortname'];
			}
		}

	echo '<h1 class="page-title">分类"<span>'.$sortname.' </span>"下的文章</h1>';
 }elseif ($params[1]=='tag'){ 
	echo '<h1 class="page-title">包含标签"<span> '.urldecode($params[2]).'</span>"的文章</h1>';		
 }elseif($params[1]=='author'){ 
	echo '<h1 class="page-title">作者"<span>'.blog_author($author).'</span>"发表的文章</h1>';
 }elseif($params[1]=='keyword'){ 
 	echo '<h1 class="page-title">搜索"<span>'.urldecode($params[2]).'</span>"的结果</h1>';
 }elseif($params[1]=='record'){ 
 	echo '<h1 class="page-title">在"<span>'.substr($params[2],0,4).'年'.substr($params[2],4,2).'月</span>"发表的文章</h1>';         
 }
 ?>
			<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
		<div class="post type-post status-publish format-standard hentry">
			<h2 class="entry-title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>的永久链接" rel="bookmark"><?php echo $value['log_title']; ?></a></h2>

			<div class="entry-meta">
				<span class="entry-date"><?php echo gmdate('Y-n-j G:i l', $value['date']); ?></span> <span class="author vcard"><?php echo  blog_author($value['author']); ?></span> <span class="cat-links"><?php blog_sort($value['logid']); ?> </span>			</div><!-- .entry-meta -->

				<div class="entry-content">
				<p><?php echo $value['log_description']; ?></p>
							</div><!-- .entry-content -->
			<div class="entry-utility">
					
							<?php blog_tag($value['logid']); ?>									
					

					<span class="comments-link">
					<?php if($value['comnum']==0) { ?><a href="<?php echo $value['log_url']; ?>#respond" title="<?php echo $value['log_title']; ?>上的评论">抢沙发...</a><?php }else {?><a href="<?php echo $value['log_url']; ?>#respond" title="<?php echo $value['log_title']; ?>上的评论"><?php echo $value['comnum']; ?>条评论</a><?php } ?>
					</span>
				
				<?php editflg($value['logid'],$value['author']); ?>
						</div><!-- .entry-utility -->
				
		</div><!-- #post-## -->
		
<?php endforeach; ?>
		<div id="pagenavi">
	<?php echo $page_url;?>
		</div>	
			</div><!-- #content -->
		</div><!-- #container -->

<?php
 include View::getView('side');
 include View::getView('footer');
?>