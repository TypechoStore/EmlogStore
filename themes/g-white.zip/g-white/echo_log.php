<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
			<div id="content" role="main">

				<div id="nav-above" class="navigation">
						<?php neighbor_log($neighborLog); ?>
				</div><!-- #nav-above -->

				<div class="post type-post status-publish format-standard hentry single">
					<h1 class="entry-title"><?php echo $log_title; ?></h1>

					<div class="entry-meta">
						<span class="entry-date"><?php echo gmdate('Y-n-j G:i l', $date); ?></span> <span class="author vcard"><?php echo  blog_author($author); ?></span> <span class="cat-links"><?php blog_sort($logid); ?> </span>
						<span class="comments-link"><a href="#respond">Go to comment</a></span>
					</div><!-- .entry-meta -->

					<div class="entry-content">
						<?php echo $log_content; ?>
					</div><!-- .entry-content -->
						<p class="att"><?php blog_att($logid); ?></p>
					<div class="entry-utility">
							<?php blog_tag($logid); ?>
							
							<?php editflg($logid,$author); ?>
							
					</div><!-- .entry-utility -->
				</div><!-- #post-## -->

				<div id="nav-below" class="navigation">
					<?php neighbor_log($neighborLog); ?>
				</div><!-- #nav-below -->
					
	
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<?php blog_comments($comments); ?>
			</div><!-- #content -->
		</div><!-- #container -->
<?php
 include View::getView('side');
 include View::getView('footer');
?>
