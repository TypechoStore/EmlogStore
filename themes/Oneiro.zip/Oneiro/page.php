<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<article>
	<div id="article">
    <div class="xcontainer">
    <div class="layout">
    <div id="content">
    <div class="content-header"><div id="tip" style="top: 21px; "></div><div id="godown" style="top: 25px; "></div></div>

			<h2><?php echo $log_title; ?></h2>
			    <div class="post-meta-single">
                <span class="showclose" style="display: block">♤ 关闭侧边栏</span>
            </div><!--.postMeta-->

			<div id="fix" class="post-content">
				<?php echo $log_content; ?>
			</div>
            
             <div class="post-info">
					 <script> // 返回顶部的jquery
                     jQuery(document).ready(function($) {
                        $body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body');// 这行是 Opera 的补丁, 少了它 Opera 是直接用跳的而且画面闪烁 by willin
                        $('#content .gotop').click(function(){
                            $body.animate({scrollTop: $('#header').offset().top}, 1000);
                            return false;// 返回false可以避免在原链接后加上
                        });
                    });
                     </script>     
                 <span class="gotop">返回顶部</span> 
                 </div><!-- end .post-info -->
				 
	<!--pinglunys-->
				 <div id="comments1"> 

<script language="javascript">
//<![CDATA[
function to_reply(commentID,author) {
var nNd='@'+author+': ';
var myField;
if (document.getElementById('comment') && document.getElementById('comment').type == 'textarea') {
myField = document.getElementById('comment');
} else {
return false;
}
if (document.selection) {
myField.focus();
sel = document.selection.createRange();
sel.text = nNd;
myField.focus();
}
else if (myField.selectionStart || myField.selectionStart == '0') {
var startPos = myField.selectionStart;
var endPos = myField.selectionEnd;
var cursorPos = endPos;
myField.value = myField.value.substring(0, startPos)
+ nNd
+ myField.value.substring(endPos, myField.value.length);
cursorPos += nNd.length;
myField.focus();
myField.selectionStart = cursorPos;
myField.selectionEnd = cursorPos;
}
else {
myField.value += nNd;
myField.focus();
}
}
//]]>
</script>
 
<style>
li {list-style-type:none;}
</style>
    <!--pinglunys-->
				 
<div class="comments_warp">

	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
				 
</div>				 
</div>	
</div>			 
<?php
 include View::getView('side');
 include View::getView('footer');
?>

</div><!--#layout-->
	</div><!--.xcontainer-->
    </div><!--#article-->
</article>