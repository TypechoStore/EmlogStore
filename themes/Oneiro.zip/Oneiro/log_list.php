<?php 
/*<?php $logs = getLogThumb(); ?>
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?> 

<div id="article">
<div class="xcontainer">
<div class="layout">
	<div id="content">
    <div class="content-header"></div>
                <?php doAction('index_loglist_top'); ?>
                              <?php foreach($logs as $value): ?>  
				<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
			
            
            <div class="post-meta">
				<span class="com-writer">
					<?php blog_author($value['author']); ?>			
				</span>
				<span class="con-cate">
					<?php blog_sort($value['logid']); ?>				
				</span>                
 				<span class="con-commt">
					<a href="<?php echo $value['log_url']; ?>#comments">(<?php echo $value['comnum']; ?>)</a>
				</span>
				<span class="con-liulan">
					<a href="<?php echo $value['log_url']; ?>">(<?php echo $value['views']; ?>)</a>
				</span>
                <span class="con-edit"><?php editflg($value['logid'],$value['author']); ?>
                </span>
                <span class="con-time">
                　  <?php echo gmdate('Y-n-j G:i l', $value['date']); ?>    
				</span>
			</div><!--.postMeta-->
            
            
            
			<div id="fix" class="post-entry"> 
			<p><?php echo $value['log_description']; ?></p>
			</div>
            <a href="<?php echo $value['log_url']; ?>" class="more-link" style="left: 0px; ">Read more</a><!-- 此处为模版自带MORE图标 若不需要可以注释掉或删除 -->
            <div class="post-bottom"> </div>
            <div style="clear:both;"></div>
            <?php endforeach; ?>
		
					
					
		<div id="postnavigation">   
   			<div class="page_navi"> <?php echo $page_url;?> </div>     
    	</div>			
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>
</div><!--#layout-->
</div><!--.xcontainer-->
 </div>

  
	