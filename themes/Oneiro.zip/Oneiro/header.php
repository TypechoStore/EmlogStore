<?php
/*
Template Name:Oneiro
Description:由【Mr.J】移植于【良心发现】的WP模版,由<a href="http://www.wangleiseo.cn/" title="王磊SEO">王磊SEO</a>再次升级到支持EMLOG5.0。
Version:1.3
Author:良心发现
Author Url:http://ongakuer.com/
Sidebar Amount:1
ForEmlog:5.0.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo TEMPLATE_URL; ?>js/jquery.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/Oneirojs.js"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<!-- Canonical helps with SEO -->
<!-- 让IE8兼容 HTML5  -->
<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<!--[if IE 6]>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/DD_belatedPNG.js"></script>
<script type="text/javascript">
DD_belatedPNG.fix('#navbar,#header,.bokeh,#logo,#search-bg,.post-meta,.more-link,#sidebar-recent,#sidebar-commt,#sidebar-random,#sidebar-archives,#sidebar-link,#sidebar-ad,.fcontainer,.footertitleinfo,.footertitlepost,.footertags,#search-bg,background');
</script>
<![endif]-->
</head>
<body>
<div id="main"><!-- 最底层框架搭建 -->
	<header>
	<div id="header">
        <div class="tcontainer">
         	<div class="bokeh">	                    
                  <h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
                  <h3><?php echo $bloginfo; ?></h3>
                <!--.               <div id="logo">   
				<h1><a href="<?php echo BLOG_URL; ?>"></a></h1>
			    </div>                                -->
			</div><!--.bokeh-->
		</div><!--.container-->
	</div>
    </header>
<div id="navbar"><?php blog_navi();?></div>