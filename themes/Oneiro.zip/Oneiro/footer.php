<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	
	<div id="footerbg"></div><!--footerbg--> 
    <div id="footer">
	 <footer>
		 <div class="fcontainer">
         	<div class="footerbar">            
                <ul>
					<!--最新文章，非首页显示-->
					<li class="widgit-layout">
						<h4 class="footertitlepost">Recent Posts</h4>
									<?php
	                                global $CACHE; 
	                                $newLogs_cache = $CACHE->readCache('newlog');
	                                ?>
	                                <?php foreach($newLogs_cache as $value): ?>
	                                <ul>
									<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li></ul>
	                                <?php endforeach; ?>	                        
					</li>
        
                    <!--标签显示，非首页显示-->
					<li class="widgit-layout2">
						<h4 class="footertags">Tags</h4>
							    <?php	$index_randlognum = Option::get('index_randlognum');
	                            $Log_Model = new Log_Model();
								$randLogs = $Log_Model->getRandLog($index_randlognum);?>
								<?php foreach($randLogs as $value): ?>
								<ul><li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li> </ul>
								<?php endforeach; ?>										  
					</li>
					
				
		            <li class="footerinfo">
                	    <h4 class="footertitleinfo">　</h4>
					      <ul>
						       <li><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></li> 
						       <li><span class="rss"><a href="<?php echo BLOG_URL; ?>rss.php">RSS</a></span>&nbsp; <span class="twitter"><a href="<?php echo BLOG_URL; ?>t/">Twitter</a></span></li>
                               <li>Theme by <a href="http://ongakuer.com/">Ongakuer</a></li>
					           <li>Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a></li>
                               <li><a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?><?php doAction('index_footer'); ?></li>
                          </ul>
					</li>
				</ul>
			</div><!--.footbar-->	
            <div id="copyright"></div>            
     </div><!--.fcontainer 这个是用来页面居中的-->	
      </footer>
	  <script type="text/javascript"> // 这个是导航栏的动画
	      jQuery(document).ready(function() {
	      $("#nav ul").css({display: "none"}); // Opera Fix
	      $("#nav li").hover(function(){
			$(this).find('ul:first').css({visibility: "visible",display: "none"}).show(268);
			},function(){
			$(this).find('ul:first').fadeOut(200)
			});	
	      $("#nav a").hover(function(){
					$(this).stop().animate({marginTop:"2px"},100);}
				,function(){
					$(this).stop().animate({marginTop:"0px"},100);
			});
			$("#nav ul a").hover(function(){
					$(this).stop().animate({marginLeft:"10px"},200);}
				,function(){
					$(this).stop().animate({marginLeft:"0px"},200);
			});		
	      });
	</script>
  </div><!--footer--> 

</body></html>