<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="clear"></div>
<div id="footer">
	<hr style= "color:#006E57; width:950px; height:5px background-color:#006E57" />
&copy <a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>版权所有"><?php echo $blogname; ?></a>
<br />
	Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog </a><?php echo Option::EMLOG_VERSION;?>  |  Designed by <a href="http://www.gw269.com" title="GW's Life">GW</a> | <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>		 <a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a>
		| <a href="<?php echo BLOG_URL; ?>admin/">管理</a>
		| <a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a> |<?php else: ?>  <a href="<?php echo BLOG_URL; ?>admin/">管理</a> | <?php endif; ?> <a href="<?php echo BLOG_URL; ?>m/">WAP</a> | <a href="<?php echo BLOG_URL; ?>rss.php">RSS</a>|<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>
<?php echo $footer_info; ?>
<?php doAction('index_footer'); ?>
</div>
</div>
	<br /><br />
</body>
</html>