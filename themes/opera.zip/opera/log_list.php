<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="contentleft">
<?php doAction('index_loglist_top'); ?>
<div class="corner">
<div id="notice-t">
	<div class="tip">
	<div class="notice-title">网站公告：</div>
	<div id="notice">
		<?php get_twitter(); ?>
	</div>
	<div style="clear:both;"></div>
	</div>
</div>
</div>
<?php foreach($logs as $value): ?>
	<div class="corner">
		<h2><?php topflg($value['top']); ?><?php if(((date('Ymd',time())-date('Ymd',$value['date']))<=2)&&($value['top']=='n')){echo "<span class='new-label'>最近更新</span><i class='new-arrow'></i>";}else if($value['views']>=88){echo "<span class='hot-label'>热门</span><i class='hot-arrow'></i>";};?><a rel="bookmark" title="<?php echo $value['log_title']; ?>" href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
			<div class="date">Posted by <?php blog_author($value['author']); ?> on <?php echo gmdate('Y-n-j G:i l', $value['date']); ?>
				<?php editflg($value['logid'],$value['author']); ?><span class="views">热度：<?php echo $value['views']; ?>℃</span>
			</div>
			<div class="txt" style="text-indent:2em;"><?php echo $value['log_description']; ?>
			</div>
			<div class="list-part">
			<div class="tag"><?php blog_tag($value['logid']); ?></div>
			<div class="post-footer"><?php blog_sort($value['logid']); ?><span class="post-comments">评论：<a href="<?php echo $value['log_url']; ?>#comments"
			title="查看《<?php echo $value['log_title']; ?>》上的全部评论"><?php echo $value['comnum']; ?></a></span>
			</div>
			<div style="clear:both;"></div>
			</div>
	</div>
	<?php endforeach; ?>
<div id="pagenavi">
	<?php echo $page_url;?>
</div>
<div class="flink">
<strong>友情链接:</strong>
<?php global $CACHE; $link_cache = $CACHE->readCache('link'); ?>
<?php foreach($link_cache as $value): ?>
<a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a>
<?php endforeach; ?>
</div>
</div><!-- end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>