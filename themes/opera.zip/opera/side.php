<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<ul id="sidebar">
		<div id="h_serch">
			<form name="keyform" method="get" id="searchform" class="search"
				action="<?php echo BLOG_URL; ?>index.php">
				<input type="text" name="keyword" class="keyword"
					onblur="if(this.value =='')this.value='写上关键词...按“回车”搜索';"
					onfocus="this.value='';"
					onclick="if(this.value=='写上关键词...按“回车”搜索')this.value=''"
					value="写上关键词...按“回车”搜索" />
				<input type="submit" name="submit" value="搜索" class="submit" />
			</form>
		</div>
<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>
<div id="box">
<div id="float" class="div1">
<a href="http://chrome.2345.com/freecall/?k248845" title="免费打电话" rel="nofollow" target="_blank"><img src="http://www.kusu.asia/content/plugins/kl_album/upload/201408/33f5b257cc4a01e310a6e9105f55bb052014083116230216780.jpg" width="330" height="50" alt="免费打电话"></a>
</div>
</div>
<!--box end-->
<script>
(function(){
    var oDiv=document.getElementById("float");
    var H=0,iE6;
    var Y=oDiv;
    while(Y){H+=Y.offsetTop;Y=Y.offsetParent};
    iE6=window.ActiveXObject&&!window.XMLHttpRequest;
    if(!iE6){
        window.onscroll=function()
        {
            var s=document.body.scrollTop||document.documentElement.scrollTop;
            if(s>H){oDiv.className="div1 div2";if(iE6){oDiv.style.top=(s-H)+"px";}}
            else{oDiv.className="div1";}
        };
    }

})();
</script>
</ul>
<!--end #siderbar-->