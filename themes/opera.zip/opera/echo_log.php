<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="contentleft">
<div class="corner">
<div id="notice-t">
	<div class="tip">
	<div class="notice-title">博主呓语：</div>
	<div id="notice">
		<?php get_twitter(); ?>
	</div>
	<div style="clear:both;"></div>
	</div>
</div>
</div>
	<div class="corner">
	<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
			<div class="date">Posted by <?php blog_author($author); ?> on <?php echo gmdate('Y-n-j G:i l', $date); ?>
			<b class="fontsize">字号：<a href="javascript:doZoom(18)">大</a> <a href="javascript:doZoom(14)">中</a> <a href="javascript:doZoom(12)">小</a></b>
			<?php editflg($logid,$author); ?>
			</div>
	<script type=text/javaScript>
	function doZoom(size){
	document.getElementById('zoom').style.fontSize=size+'px'}
	</script>
	<div class="txt" id="zoom">
	<?php echo $log_content; ?>
	</div>
	<div class="list-part">
	<div class="tag"><?php blog_tag($logid); ?></div>
	<div class="post-footer"><?php blog_sort($logid); ?><?php blog_sort($value['logid']); ?><span class="post-comments">comment：<a href="#comments"
	title="<?php echo $log_title; ?>上的评论"><?php echo $comnum; ?></a>/<a href="#comment-post"><?php echo $views; ?></a></span>
	</div>
	</div>
	<div class="txt">
	<?php doAction('log_related', $logData); ?>
	<div> 文章除注明外均为原创，转载请注明出处：<a href="http://www.diysun.com/">冷猫的博客</a></br>
		本文地址：:<a href="<?php echo Url::log($logid); ?>"><?php echo Url::log($logid); ?></div>
<!-- JiaThis Button BEGIN -->
<div id="ckepop">
	<span class="jiathis_txt">分享到：</span>
	<a class="jiathis_button_qzone">QQ空间</a>
	<a class="jiathis_button_tsina">新浪微博</a>
	<a class="jiathis_button_tqq">腾讯微博</a>
	<a class="jiathis_button_renren">人人网</a>
	<a href="http://www.jiathis.com/share" class="jiathis jiathis_txt jiathis_separator jtico jtico_jiathis" target="_blank">更多</a>
	<a class="jiathis_counter_style"></a>
</div>
<!-- JiaThis Button END -->
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	</div><!--end .txt-->
	</div>
	<div id="comments_corner">
	<div class="txt">
	<?php blog_comments($comments,$params); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
	</div>
	<div style="clear:both;"></div>
</div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>