<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="contentleft">
<div class="corner">
<div id="notice-t">
<div class="tip" style="font-size: 12px;color: #CC0F16;">
<a href="<?php echo BLOG_URL; ?>" title="返回首页">网站首页</a>　》<!-- 首页 -->
<?php  
global $CACHE; 
$cache_sort = $CACHE->readCache('sort');
$log_cache_sort = $CACHE->readCache('logsort');
$mylogid = $log_cache_sort[$logid]['id'];
$pid = $cache_sort [$mylogid]['pid'];
 ?>
<?php if($pid != 0):?>
<a href="<?php echo Url::sort($pid); ?>">
<?php echo $cache_sort[$pid]['sortname'];?></a>　》<!-- 父分类 -->
<a href="<?php echo Url::sort($mylogid);?>"><?php echo $cache_sort[$mylogid]['sortname']; ?></a>　》<!-- 子分类 -->
<?php else:?>
<a href="<?php echo Url::sort($mylogid);?>"><?php echo $cache_sort[$mylogid]['sortname']; ?></a>　》<!-- 分类 -->
<?php endif;?>
<a><?php echo $log_title; ?></a><!-- 日志标题 -->
</div>
</div>
</div>
	<div class="corner">
	<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
			<div class="date">Posted by <?php blog_author($author); ?> on <?php echo gmdate('Y-n-j G:i l', $date); ?>
			<b class="fontsize">字号：<a href="javascript:doZoom(18)">大</a> <a href="javascript:doZoom(14)">中</a> <a href="javascript:doZoom(12)">小</a></b>
			<?php editflg($logid,$author); ?>
			</div>
	<script type=text/javaScript>
	function doZoom(size){
	document.getElementById('zoom').style.fontSize=size+'px'}
	</script>
	<div class="txt" id="zoom">
	<?php echo $log_content; ?>
	</div>
	<div class="list-part">
	<div class="tag"><?php blog_tag($logid); ?></div>
	</div>
	<div style="clear:both;"></div>
	<div class="txt">
	<?php doAction('log_related', $logData); ?>
<div class="zhuanzai">
    <h3>本文由“<a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>"><?php echo $blogname; ?></a> > <?php blog_author($author); ?>”整理编辑，若未标明内容为原创,则不对其真实性负责</h3>
    页面标题：[ <a href="<?php echo Url::log($logid); ?>"title="<?php echo $log_title;?>"><?php echo $log_title;?></a> - <?php echo $blogname; ?> ]<br>
	<span>本文网址：</span><input id="this_url" type="text" value="<?php echo Url::log($logid); ?>"><br>
	<div class="bdsharebuttonbox">
	<a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间">QQ空间</a>
	<a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博">新浪微博</a>
	<a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博">腾讯微博</a>
	<a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信">微信</a>
	<a href="#" class="bds_tieba" data-cmd="tieba" title="分享到百度贴吧">百度贴吧</a>
	<a href="#" class="bds_renren" data-cmd="renren" title="分享到人人网">人人网</a>
	<a href="#" class="bds_douban" data-cmd="douban" title="分享到豆瓣网">豆瓣网</a>
	<a href="#" class="bds_copy" data-cmd="copy" title="复制本文网址">复制网址</a>
	</div>
	<h3>网站内容默认可进行非商业转载,转载者须保证文章的内容完整性和添加本站版权说明！</h3>
</div>
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	</div><!--end .txt-->
	</div>
	<div id="comments_corner">
	<div class="txt">
	<?php blog_comments($comments,$params); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
	</div>
	<div style="clear:both;"></div>
</div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>