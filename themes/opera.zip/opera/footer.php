<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<script type="text/javascript"> 
	$("#loading div").animate({width:"100px"},function(){
		$('span:eq(0)').replaceWith('<span>加载完成...<\/span>');
		$("#loading").fadeOut(1000);
	});
</script>
</div><!--end #content-->
</div><!--end #wrap-->
<div style="clear:both;"></div>
<div id="footerbar">
<div class="copyright">
<p style="float:left">&copy; 2011 - 2013 <a href=# target=_self style="zoom:1;"><?php echo $blogname; ?></a>&nbsp;<span style="zoom:1;">版权所有.</span>
 | <a href="http://www.diysun.com/m/">手机版</a> 
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> | 
<?php doAction('index_footer'); ?>
Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>. Theme By Keef &<a href="http://aisheji.org/"> Tod </a>.
</p>
<script src="<?php echo TEMPLATE_URL; ?>scrolltop.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>slimbox2.js" type="text/javascript"></script>
<?php echo $footer_info; ?>
<div style="clear:both;"></div>
</div>
</div><!--end #footerbar-->
<!--jiathis JS代码-->
<script type="text/javascript" src="http://v2.jiathis.com/code/jia.js" charset="utf-8"></script>
<!--jiathis end-->
</body>
</html>