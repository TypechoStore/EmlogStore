<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<script type="text/javascript"> 
	$("#loading div").animate({width:"100px"},function(){
		$('span:eq(0)').replaceWith('<span>加载完成...<\/span>');
		$("#loading").fadeOut(1000);
	});
</script>
</div><!--end #content-->
</div><!--end #wrap-->
<div style="clear:both;"></div>
<div id="footerbar">
<div class="copyright">
		<p style="float:left">Copyright © <?php echo date('Y',time())?> <a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>"><?php echo $blogname; ?></a> All Rights Reserved.
		<?php echo $icp; ?> <?php echo $footer_info; ?> 
		网站程序：<a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?> 个人博客系统" rel="nofollow" target="_blank">EMLOG</a>　主题原作者：<a href="http://aisheji.org/" title="爱设计" rel="nofollow" target="_blank">Tod</a>　图片存储由<a href="https://portal.qiniu.com/signup?code=3lel8kyifh6j6" title="七牛云存储" rel="nofollow" target="_blank">七牛云存储</a>提供　<a href="./sitemap.xml" title="Google SiteMap" target="_blank">谷歌地图</a>　<a href="./BaiduSitemap.php" title="Baidu SiteMap" target="_blank">百度地图</a></p>
<script src="<?php echo TEMPLATE_URL; ?>js/function.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/scrolltop.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/slimbox2.js" type="text/javascript"></script>
<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"1","bdSize":"16"},"share":{"bdSize":16}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>
<?php doAction('index_footer'); ?>
<div style="clear:both;"></div>
</div>
</div><!--end #footerbar-->
</body>
</html>