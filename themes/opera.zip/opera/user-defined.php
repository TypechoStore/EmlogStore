<?php 
/*
* 自定义函数
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//Custom: 碎语轮播
function get_twitter(){
		global $CACHE; 
		$newtws_cache = $CACHE->readCache('newtw');
		$istwitter = Option::get('istwitter');
	?>
	<?php foreach($newtws_cache as $value): ?>
	<ul>
	<li>
			<a href="<?php echo BLOG_URL . 't/'; ?>"><?php echo substr($value['t'],0,102); ?></a>
	</li>
	</ul>
	<?php endforeach; ?>
	<script>
		var c, _ = Function;
		with( o = document.getElementById("notice")) {
			innerHTML += innerHTML;
			onmouseover = _("c=1");
			onmouseout = _("c=0");
		}( F = _("if(#%27||!c)#++,#%=o.scrollHeight>>1;setTimeout(F,#%27?10:4000);".replace(/#/g, "o.scrollTop")))();
	</script>
<?php }?>
<?php
//获取Gravatar头像
function MyGravatar($email, $s=64, $d='identicon', $r='g') {
    $f = md5($email);
    $a = TEMPLATE_URL.'avatar/'.$f.'.jpg';
    $e = EMLOG_ROOT.'/content/templates/opera/avatar/'.$f.'.jpg';
    $t = 1296000; //15天，单位：秒
    if (empty($d)) $d = TEMPLATE_URL.'avatar/default.jpg';
    if (!is_file($e) || (time() - filemtime($e)) > $t ) {
        //当头像不存在或者超过15天才更新
        $g = sprintf("http://%d.gravatar.com",(hexdec($f{0})%2)).'/avatar/'.$f.'?s=64&d='.$d.'&r='.$r;
        copy($g,$e); $a=$g; //新头像copy时, 取gravatar显示
    }
    if (filesize($e) < 500) copy($d,$e);
    return $a;
}
?>