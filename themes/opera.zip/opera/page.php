<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="contentleft">
<div class="corner">
<div id="notice-t">
	<div class="tip">
<a href="<?php echo BLOG_URL; ?>" title="返回首页">网站首页</a>　〉<!-- 首页 -->
<a><?php if(isset($_GET['plugin'])): 
              $log_title=$navibar[addslashes($_GET['plugin'])]['title'];
              endif; ?></a>　〉<!-- 插件页面 -->
<a><?php echo $log_title; ?></a><!-- 自建页面 -->
	</div>
</div>
</div>
<div class="corner">
	<h2><?php echo $log_title; ?></h2>
<div class="txt" style="padding-bottom:10px; padding-top:10px;">
	<?php echo $log_content; ?>
	<?php blog_comments($comments,$params); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
</div>
</div><!--end #contentleft-->
<?php include View::getView('side'); ?>
<?php include View::getView('footer'); ?>