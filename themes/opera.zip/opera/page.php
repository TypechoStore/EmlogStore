<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="contentleft">
<div class="corner">
<div id="notice-t">
	<div class="tip">
	<div class="notice-title">博主呓语：</div>
	<div id="notice">
		<?php get_twitter(); ?>
	</div>
	<div style="clear:both;"></div>
	</div>
</div>
</div>
<div class="corner">
	<h2><?php echo $log_title; ?></h2>
<div class="txt" style="padding-bottom:10px; padding-top:10px;">
	<?php echo $log_content; ?>
	<?php blog_comments($comments,$params); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
</div>
</div><!--end #contentleft-->
<?php include View::getView('side'); ?>
<?php include View::getView('footer'); ?>