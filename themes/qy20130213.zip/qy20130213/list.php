<?php 
/*
* 文章列表页
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="postnavi">
<div class="site-navi">
<a  title="返回首页" href="<?php echo BLOG_URL; ?>">首页 &raquo;</a> 
<?php if ($params[1]=='sort'){ ?>
		<?php echo '<a  href="'.Url::sort($sortid).'">'.$sortName.'</a>';?>
<?php }elseif ($params[1]=='tag'){ ?>
			包含标签 <b><?php echo urldecode($params[2]);?></b> 的所有文章
<?php }elseif($params[1]=='author'){ ?>
			作者 <b><?php echo blog_author($author);?></b> 的所有文章
<?php }elseif($params[1]=='keyword'){ ?>
            关键词 <b><?php echo urldecode($params[2]);?></b> 的搜索结果
<?php }elseif($params[1]=='record'){ ?>
           发表在 <b><?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?> </b>的所有文章
<?php }else{?><?php }?>
</div>
</div>
<!-- 左侧 开始 -->

<!-- 左侧通栏广告 开始-->

<!-- 最新文章列表 开始 -->
<div class="entry">
	<h4><?php echo '<a  href="'.Url::sort($sortid).'">'.$sortName.'列表</a>';?></h4>
		<div class="leftad">
<img src="<?php echo TEMPLATE_URL; ?>images/leftad.jpg" /></div>
	<div class="con_left">

	<?php foreach($logs as $value): ?>
	<div class="post"  onmouseover="this.className='post post_border'" onmouseout="this.className='post'" >
	<h2><?php topflg($value['top']); ?><span class="title"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></span></h2>
	</div>
<div class="small_desc"><a href="http://www.baidu.com/s?wd=<?php echo $value['log_title']; ?>" rel="nofollow" title="百度中查找：<?php echo $value['log_title']; ?>" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/so1416.gif" width="14" height="16" alt="bds" /></a></span>  <span class="postother">作者：<?php blog_author($value['author']); ?> 时间：<?php echo gmdate('Y-n-j', $value['date']); ?> 浏览：<a href="<?php echo $value['log_url']; ?>"><?php echo $value['views']; ?></a><span class="category"><?php blog_sort($value['logid']); ?></span><span class="postbg"><?php blog_tag($value['logid']); ?></span></span></div>
<div class="fl innerimg_box">
	<?php if(pic_thumb($value['content'])){
						$imgsrc = pic_thumb($value['content']);
					}else
						$imgsrc = TEMPLATE_URL.'images/random/'.rand(1,20).'.jpg';
					?>
						<a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><img src="<?php echo $imgsrc; ?>" /></a>
						</div>
					<div class="post_con">
					<?php echo subString(strip_tags($value['content']),0,400); ?><br>
					</div>

	<?php endforeach; ?>
</div>
			<div class="pagelink">
			<?php echo $page_url;?>

</div>
<!-- 最新文章列表 结束 -->
<div class="spacebox"></div>



</div>
<!-- 左侧 结束 -->

<!-- 右侧 开始 -->
<div class="con_right">
<?php include View::getView('side'); ?>
</div>
<!-- 右侧 结束 -->

<!-- 友情链接 开始 -->

<!-- 友情链接 结束 -->


</div>


		






