// JavaScript Document

// JavaScript Document
// JS of K-V for Emlog By Kurly
// http://blog.yilushang.net
// kurly@foxmail.com

//Tab切换功能
(function($){
	$.fn.WIT_SetTab=function(iSet){
		/*
		 * 多功能选项卡@Mr.Think
		 * Nav: 导航钩子；
		 * Field：切换区域
		 * K:初始化索引；
		 * CurCls：高亮样式；
		 * Auto：是否自动切换；
		 * AutoTime：自动切换时间；
		 * OutTime：淡入时间；
		 * InTime：淡出时间；
		 * CrossTime：鼠标无意识划过时间
		 * Ajax：是否开启ajax
		 * AjaxFun：开启ajax后执行的函数
		 */
		iSet=$.extend({Nav:null,Field:null,K:0,CurCls:'cur',Auto:false,AutoTime:7000,OutTime:100,InTime:150,CrossTime:60},iSet||{});
		var acrossFun=null,hasCls=false,autoSlide=null;
		//切换函数
		function changeFun(n){
			iSet.Field.filter(':visible').fadeOut(iSet.OutTime, function(){
				iSet.Field.eq(n).fadeIn(iSet.InTime).siblings().hide();
			});
			iSet.Nav.eq(n).addClass(iSet.CurCls).siblings().removeClass(iSet.CurCls);
		}
		//初始高亮第一个
		changeFun(iSet.K);
		//鼠标事件
		iSet.Nav.hover(function(){
			iSet.K=iSet.Nav.index(this);
			if(iSet.Auto){
				clearInterval(autoSlide);
			}
			hasCls = $(this).hasClass(iSet.CurCls);
			//避免无意识划过时触发
			acrossFun=setTimeout(function(){
				//避免当前高亮时划入再次触发
				if(!hasCls){
					changeFun(iSet.K);
				}
			},iSet.CrossTime);
		},function(){
			clearTimeout(acrossFun);
			//ajax调用
			if(iSet.Ajax){
				iSet.AjaxFun();
			}
			if(iSet.Auto){
				//自动切换
				autoSlide = setInterval(function(){
		            iSet.K++;
		            changeFun(iSet.K);
		            if (iSet.K == iSet.Field.size()) {
		                changeFun(0);
						iSet.K=0;
		            }
		        }, iSet.AutoTime)
			}
		}).eq(0).trigger('mouseleave');
	}
})(jQuery);
//使用方法
$(function(){
	//幻灯效果
	$(document).WIT_SetTab({
		Nav:$('ul#J_indexSlideNav>li'),
		Field:$('div#J_indexSlideBox>div.show'),
		Auto: true,
		CrossTime:120,
		OutTime:200,
		AutoTime:7000,
		InTime:300
	});
	//普通选项卡
	$(document).WIT_SetTab({
		Nav:$('#J_setTabANav>li'),
		Field:$('#J_setTabABox>div'),
		CurCls:'hover'
	});
	//普通选项卡
	$(document).WIT_SetTab({
		Nav:$('#J_setTabBNav>li'),
		Field:$('#J_setTabBBox>div'),
		Auto:true,
		CurCls:'hover'
	});
});
//sayslide
$(function(){
	$("#slide_show").saySlide({isTitle:true,isBottombg:true,autodir:'left',autoTime:3000,isLink:true,defaultColor:"#72B332"});
});
//透明
$(function(){
	$('.tm').css("opacity","0.6");
	$('.post_l ul.thumb_list li div.thumb_img img').hover(function(){$(this).css("opacity","0.6")},function(){$(this).css("opacity","1")});
});
