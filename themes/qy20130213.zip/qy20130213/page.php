<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!-- 左侧 开始 -->

<!-- 正文 开始 -->
<div class="postnavi">
<div class="site-navi">
<a  title="返回首页" href="<?php echo BLOG_URL; ?>">首页 &raquo;</a> 
<?php if ($params[1]=='sort'){ ?>
		<?php echo '<a  href="'.Url::sort($sortid).'">'.$sortName.'</a>';?>
<?php }elseif ($params[1]=='tag'){ ?>
			包含标签 <b><?php echo urldecode($params[2]);?></b> 的所有文章
<?php }elseif($params[1]=='author'){ ?>
			作者 <b><?php echo blog_author($author);?></b> 的所有文章
<?php }elseif($params[1]=='keyword'){ ?>
            关键词 <b><?php echo urldecode($params[2]);?></b> 的搜索结果
<?php }elseif($params[1]=='record'){ ?>
           发表在 <b><?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?> </b>的所有文章
<?php }else{?><?php }?>
</div>
</div>

<div class="con_left">
<div class="post1" >
	<h2 class="mid_single"><?php echo $log_title; ?></h2>
		<?php echo $log_content; ?>
	</div>
	
	<div id="contentleft">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
	</div>

<?php
 include View::getView('side');
 include View::getView('footer');
?>


