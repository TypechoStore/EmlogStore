<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!-- 左侧 开始 -->

<!-- 正文 开始 -->
<div class="postnavi">
<div class="site-navi">
<a  title="返回首页" href="<?php echo BLOG_URL; ?>">首页 </a>&raquo; 
<?php blog_sort($logid); ?>&raquo; ​<?php echo $log_title; ?>
</div>
</div>

<div class="con_left">
<div class="post1" >
	<h2 class="mid_single"><?php topflg($top); ?><?php echo $log_title; ?></h2>
	<div class="describe">作者：<?php blog_author($author); ?> 发布于：<?php echo gmdate('Y-n-j G:i l', $date); ?> 
	<?php blog_sort($logid); ?> <?php editflg($logid,$author); ?> 
	</div>
	<?php echo $log_content; ?>
	<div class="postbg"><?php blog_tag($logid); ?></div>
	<div class="navigation">
	<?php doAction('log_related', $logData); ?>
	<div class="alignright"><?php neighbor_log($neighborLog); ?></div>
	<div class="alignleft" ><?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	</div>
	</div>
	</div>
	<div id="contentleft">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	
	
	</div>
	<div clear="all"></div>
</div><!--end #contentleft-->
</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>