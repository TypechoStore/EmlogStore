<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>
</div>
<div style="clear:both;"></div>
<div id="footer-wrapper">
	<div id="three-columns">
	
		<!--<div id="column1">
		
			<?php echo widget_archive($title);?>
		</div>
		<div id="column2">
			
			<?php echo widget_random_log($title);?>
		</div>
		<div id="column3">
			
			<?php widget_tag($title);?>
		</div>
	</div>-->
<div id="footer">
<p>Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> 
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>|Themed By <a href="http://blog.purstar.net" title="五洋个人博客">五洋</a></p>
<?php doAction('index_footer'); ?>
</div>
</div>
</body>
</html>