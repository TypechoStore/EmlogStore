<?php
/*
Template Name:orchlian
Description:orchilan
Version:1.0
Author:依如星辰
Author Url:http://blog.purstar.net
Sidebar Amount:1
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" media="screen" />
<link href="<?php echo TEMPLATE_URL; ?>css/global.css" rel="stylesheet" type="text/css" media="screen" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL;?>js/jquery-1.4.4.min.js"></script>
<script src="<?php echo TEMPLATE_URL;?>js/slides.min.jquery.js"></script>
<script>
		$(function(){
			$('#slides').slides({
				preload: true,
				preloadImage: '<?php echo TEMPLATE_URL;?>img/loading.gif',
				play: 5000,
				pause: 2500,
				hoverPause: true,
				animationStart: function(){
					$('.caption').animate({
						bottom:-35
					},100);
				},
				animationComplete: function(current){
					$('.caption').animate({
						bottom:0
					},200);
					if (window.console && console.log) {
						// example return of current slide number
						console.log(current);
					};
				}
			});
		});
</script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="wrapper">
	<div id="menu"><?php blog_navi();?></div>
	<!-- end #menu -->
	<div id="header">
		<div id="logo">
			<h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
		</div>
		<div id="search">
		<?php widget_search($title);?>
		</div>
	</div><!-- end #header -->
	
