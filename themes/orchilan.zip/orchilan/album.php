<?php
/*
 * 模板tstyle首页相册模块调用，修改自kl_album插件
 * 本页面需要emlog相册插件：kl_album 的支持
 */
!defined('EMLOG_ROOT') && exit('access deined!');
$album = isset($_GET['album']) ? intval($_GET['album']) : '';
global $CACHE;
$options_cache = $CACHE->readCache('options');
$navibar = unserialize($options_cache['navibar']);
$DB = MySql::getInstance();
if(isset($navibar['kl_album'])){
	if($navibar['kl_album']['hide'] == 'y') emMsg('不存在的页面！');
	//显示单个相册里的照片
	if($album !== ''){
		$log_title = '';
		$log_content = '';
		$kl_album_info = Option::get('kl_album_info');
		$kl_album_info = unserialize($kl_album_info);
		$exist_album = false;
		if(is_array($kl_album_info)){
			foreach ($kl_album_info as $val){
				if($val['addtime'] == $album){
					$albumrestrict = $val['restrict'];
					$albumname = $val['name'];
					$albumpwd = isset($val['pwd']) ? $val['pwd'] : '';
					$exist_album = true;
				}
			}
			if($exist_album === false || ($albumrestrict == 'private' && ROLE != 'admin')){
				$log_content .= '不存在的相册';
			}else{
				if($albumrestrict == 'protect' && ROLE != 'admin'){
					$postpwd = isset($_POST['albumpwd']) ? addslashes(trim($_POST['albumpwd'])) : '';
					$cookiepwd = isset($_COOKIE['kl_albumpwd_'.$album]) ? addslashes(trim($_COOKIE['kl_albumpwd_'.$album])) : '';
					kl_album_AuthPassword($postpwd, $cookiepwd, $albumpwd, $album, BLOG_URL.'?plugin=kl_album', 'kl_albumpwd_');
				}
				$kl_album = Option::get('kl_album_'.$album);
				if(is_null($kl_album)){
					$condition = " and album={$album} order by id desc";
				}else{
					$idStr = empty($kl_album) ? 0 : $kl_album;
					$condition = " and id in({$idStr}) order by substring_index('{$idStr}', id, 1)";
				}
				$query = $DB->query("SELECT * FROM ".DB_PREFIX."kl_album WHERE 1 {$condition}");
				$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
				$page_all_no = $DB->num_rows($query);
				$page_num = isset($navibar['kl_album']['num_rows']) ? $navibar['kl_album']['num_rows'] : 20;
				$pageurl =  pagination($page_all_no, $page_num, $page, './?plugin=kl_album&album='.$album.'&page=');
				$start_num = !empty($page) ? ($page - 1) * $page_num : 0;
				$query = $DB->query("SELECT * FROM ".DB_PREFIX."kl_album WHERE 1 {$condition} LIMIT $start_num, $page_num");
				$photos = array();
				$log_content .= '
<div style="text-align:left; font-size:12px; padding:0px 20px;"> <a href="./?plugin=kl_album">&laquo;返回相册列表</a></div>
<div id="kl_album_photo_list" style="height:auto!important;min-height:150px;height:150px;margin-bottom:20px;"><ul style="list-style: none; font-size:12px;color: #666666;float:left;margin:5px; padding:0px; text-align:center;">';
				while($photo = $DB->fetch_array($query)){
					$log_content .=	'
<a href="'.str_replace('thum-', '', substr($photo['filename'], 1, strlen($photo['filename']))).'" title="相片名称：'.$photo['truename'].'　相片描述：'.$photo['description'].'">
<img  src="'.substr($photo['filename'], 1, strlen($photo['filename'])).'" /></a>';
				}
				$log_content .= '</ul></div><div id="pagenavi">'.$pageurl.'<span>(共有'.$page_all_no.'张相片)</span></div>';
			}
		}else{
			$log_content .= '参数错误。';
		}

		$allow_remark = 'n';
		$logid = '';
		echo $log_content;
	}
}
?>