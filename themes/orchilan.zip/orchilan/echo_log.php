<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="page">
		<div id="page-bgtop">
		<div id="sidebar">
			<?php
			include View::getView('side');
			?>
		</div>
			<div id="page-bgbtm">
				<div id="content">
					<div class="post">
					<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
	<p class="meta">
	作者：<?php blog_author($author); ?> 发布于：<?php echo gmdate('Y-n-j G:i l', $date); ?> 
	<?php blog_sort($logid); ?> <?php editflg($logid,$author); ?><?php blog_tag($logid); ?>
	</p>
	<div id="entry"><?php echo $log_content; ?></div>
	<?php doAction('log_related', $logData); ?>
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCodea,$allow_remark); ?>
	<div style="clear:both;"></div>
				</div><!-- end #content -->
				<div style="clear:both;"></div>
				</div>
				</div>
<?php include View::getView('footer');?>