<?php
/*
*自建页模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="page">
		<div id="page-bgtop">
		<div id="sidebar">
			<?php
			include View::getView('side');
			?>
		</div>
			<div id="page-bgbtm">
				<div id="content">
					<div class="post">
					<div id="entry">
	<h2><?php echo $log_title; ?></h2>
	<?php echo $log_content; ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div
	<div style="clear:both;"></div>
				</div><!-- end #content -->
				<div style="clear:both;"></div>
				</div>
				</div>
<?php include View::getView('footer');?>