<?php 
/******

*首页顶部滚动图片*

*****/

if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
					<div>
						<a href="http://localhost:8080/emlog4.2.1/?plugin=kl_album&album=1338962601" title="美女图片" target="_blank"><img src="<?php echo TEMPLATE_URL;?>img/slide-3.jpg" width="950" height="270" alt="Slide 3"></a>
						<div class="caption">
							<p>美女图片</p>
						</div>
					</div>
					<div>
						<a href="http://localhost:8080/emlog4.2.1/?plugin=kl_album&album=1338962554" title="美女图片" target="_blank"><img src="<?php echo TEMPLATE_URL;?>img/beauty/beauty<?php echo mt_rand(1,22);?>.jpg" width="950" height="270" alt="Slide 4"></a>
						<div class="caption">
							<p>还是美女图片</p>
						</div>
					</div>
					
			