<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
   	<?php doAction('index_loglist_top'); ?>
    <?php foreach($logs as $value): ?>
   <div class="post_wrap clearfix">
    <div class="post">
     <h3 class="title"><span class="import"><?php topflg($value['top']); ?></span><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h3>
     <div class="post_content">
      <?php echo $value['log_description']; ?>
     </div>
     <div class="post_meta clearfix">
      <ul class="clearfix">
      <li><?php blog_sort($value['logid']); ?></li>
      </ul>
      <?php blog_tag($value['logid']); ?>
     </div>
    </div>
    <div class="meta">
     <ul>
      <li class="post_date"><?php echo gmdate('Y/n/j G:i l', $value['date']); ?></li>
      <li class="post_author"><?php blog_author($value['author']); ?></li>
      <li class="post_comment"><a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?>条评论</a></li>
      <li class="post_edit"><?php editflg($value['logid'],$value['author']); ?></li>
     </ul>
    </div>
   </div><!-- END .post_wrap -->
   <?php endforeach; ?>
<div id="page_navi">
    <div class="page_navi clearfix">
<h4>页面导航</h4>
<ul class="page-numbers">
	<?php echo $page_url;?>
</ul>
</div>
   </div>
<?php
 include View::getView('footer');
?>