<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
  </div><!-- END #left_col -->
<?php
 include View::getView('side');
?>
  <div id="footer">
   <ul id="copyright">
    <li>版权所有 © <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></li>
    <li>主题由 <a class="target_blank" href="http://www.mono-lab.net/" target="_blank">mono-lab</a> 设计</li>
    <li class="last">由<a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>强力驱动</li>
	<li><a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a></li>
	<li><?php doAction('index_footer'); ?></li>
   </ul>
  </div>
 </div><!-- END #main_content -->
 <p id="return_top"><a href="#header">return top</a></p>
</body>
</html>