<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="bread_crumb">
    <ul class="clearfix">
     <li id="bc_home"><a title="首页" href="<?php echo BLOG_URL; ?>">首页</a></li>
     <li id="bc_cat"><?php blog_sort($logid); ?></li>
     <li class="last"><?php echo $log_title; ?></li>
    </ul>
   </div>

   <div class="post_wrap clearfix" id="single">
    <div class="post">
     <h3 class="title"><?php topflg($top); ?><?php echo $log_title; ?></h3>
     <div class="post_content">
      <?php echo $log_content; ?><?php doAction('log_related', $logData); ?>
           </div><!-- END .post_content -->
    </div>
    <div class="meta">
     <ul>
      <li class="post_date"><?php echo gmdate('Y/n/j G:i l', $date); ?></li>
      <li class="post_author"><?php blog_author($author); ?></li>      <li><?php blog_sort($logid); ?></li>
      <?php blog_tag($logid); ?>
	  <li class="post_comment"><a href="<?php echo $value['log_url']; ?>#comments"><?php echo $comnum; ?>条评论</a></li>
      <li class="post_edit"><?php editflg($logid,$author); ?></li>     </ul>
    </div>
   </div><!-- END .post_wrap -->
	<div id="comments_wrapper">
   	<div id="comment_header" class="clearfix">
 <ul id="comment_header_left">
  <li id="add_comment"><a href="#respond">发表评论</a></li>
 </ul>
 <ul id="comment_header_right">
   <li id="trackback_switch"><a href="javascript:void(0);">Trackback (<?php echo count($tb); ?>)</a></li>
   <li id="comment_switch" class="comment_switch_active"><a href="javascript:void(0);">评论 (<?php echo $comnum; ?>)</a></li>
 </ul>
</div><!-- END #comment_header -->
<div id="comments">
	<div id="comment_area">
  <!-- start commnet -->
 <?php blog_comments($comments); ?>
 </div>
  <div id="trackback_area">
 <?php blog_trackback($tb, $tb_url, $allow_tb); ?> 
 </div>
 <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
   </div>
   </div>
   <div id="previous_next_post">
    <div class="clearfix">
	<?php neighbor_log($neighborLog); ?>
    </div>
   </div>
<?php
 include View::getView('footer');
?>