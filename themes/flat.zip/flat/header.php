<?php
/*
Template Name:flat
Description:移植自nono-lab的flat
Version:2.0
Author:魔法基佬MKⅡ
Author Url:http://hmoe.me
Sidebar Amount:1
ForEmlog:5.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
if(function_exists('emLoadJQuery')) {
    emLoadJQuery();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<title><?php echo  $site_title; ?></title>
<meta name="description" content="<?php echo  $site_description; ?>" />
<link rel="alternate" type="application/rss+xml" title="<?php echo $blogname; ?> RSS Feed" href="<?php echo BLOG_URL; ?>rss.php" />
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>style.css" type="text/css" />
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>comment-style.css" type="text/css" />
<script src="<?php echo TEMPLATE_URL; ?>js/common_tpl.js" type="text/javascript"></script>
<!--[if lt IE 9]>
<script type="text/javascript" src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script>
<![endif]-->
<?php doAction('index_head'); ?>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/scroll.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jscript.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/comment.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/rollover.js"></script>
</head>

<body>

 <div id="header">
  <div class="header_menu">
    <?php blog_navi();?>
  </div>
  <h1 id="logo_text"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
  <h2 id="site_description"><?php echo $bloginfo; ?></h2>
 </div>

 <div id="main_content" class="clearfix">

  <div id="left_col">