<?php
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="frame-content">
<div id="content">
<div class="content-box">
    <div class="title">
        <h2 class="logs"><?php topflg($top); ?><?php echo $log_title; ?></h2>
        <p class="date"><i>本文由 <?php blog_author($author); ?> 发布于 <?php echo gmdate('Y-n-j G:i l', $date); ?></i> &nbsp; <?php editflg($logid,$author); ?>&nbsp; 『<?php blog_sort($logid); ?>』</p>
    </div>
    <div class="blank"></div>
    <div class="log-cont">
        <?php echo $log_content; ?>
        <div class="clear"></div>
    </div>
    <!--非图形附件列表，5.0己非必须-->
    <!--<div class="att"><?php //blog_att($logid); ?></div>-->
    <div class="under">
        <p class="tag"><?php blog_tag($logid); ?></p>
        <p class="count">
        <a href="<?php echo $log_url; ?>#comments">评论(<?php echo $comnum; ?>)</a> &nbsp;
        <a href="<?php echo $log_url; ?>#tb">引用(<?php echo $tbcount; ?>)</a> &nbsp;
        <a href="<?php echo $log_url; ?>">浏览(<?php echo $views; ?>)</a>
        </p>
    </div>
</div>
<div class="content-box">
    <div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
</div>
<div class="content-box">
    <?php doAction('log_related', $logData); ?>
</div>
<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
<?php if ($comnum > 0): ?>
    <div class="content-box">
        <?php blog_comments($comments,$params); ?>
    </div>
<?php endif; ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div><!--#content.End-->
</div><!--#frame_content.End-->
<?php
    include View::getView('side');
    include View::getView('footer');
?>
