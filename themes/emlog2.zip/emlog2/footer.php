<?php
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div class="clear"></div>
</div><!--#frame.End-->
</div><!--#wrap.End-->
<div id="footerbar">
    <a name="bottom"></a><!--设置底部锚点-->
    &nbsp; &nbsp;<a href=# target=_self><?php echo $blogname; ?></a> &copy; 2011 &nbsp; Powered by <a href="http://www.emlog.net/" title="Emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">Emlog</a> &nbsp; Designed by <a href="http://emlog8.sinaapp.com/" target="_blank">Emlog吧</a> &nbsp; <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> &nbsp; <?php doAction('index_footer'); ?> &nbsp; <?php echo $footer_info; ?>
    <div id="logon">
        <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
            <a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a>
            <a href="<?php echo BLOG_URL; ?>admin/">管理</a>
            <a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a> &nbsp;
        <?php else: ?>
            <a href="<?php echo BLOG_URL; ?>admin/">登录</a> &nbsp;
        <?php endif; ?>
    </div>
</div>
<!-- goTOP[返回顶部] -->
<div id="goTopBtn" style="display:none"><img src="<?php echo TEMPLATE_URL; ?>images/top.jpg"></div>
<script type=text/javascript>goTopEx();</script>
<!-- goTOP[返回顶部].End -->
<!-- 幻灯片脚本 -->
<script type="text/javascript">
    var tt = new ss.slider();
    tt.init({
    gallery: 'gal-wrap',
    control: "gal-panel",
    dir: false,
    index: 0,
    speed: 20,
    interval: 2500,
    type: 'mouseover'
    });
</script>
<!-- 幻灯片脚本.End -->
<!-- 百度分享条脚本 -->
<script type="text/javascript" id="bdshare_js" data="type=tools" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
	document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?t=" + new Date().getHours();
</script>
<!-- 百度分享条脚本.End -->
</body>
</html>
