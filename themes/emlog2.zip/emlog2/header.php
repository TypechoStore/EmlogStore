<?php
/*
Template Name: emlog2 (两栏)
Description: 仿EMLOG官方首页
Version: 1.5.0
Author: yuadao
Author Url: http://emlog8.sinaapp.com/
Sidebar Amount: 1
ForEmlog: 5.0.x
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once (View::getView('module'));
if(function_exists('emLoadJQuery')) {emLoadJQuery();}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<link rel="icon" href="favicon.gif" type="image/gif" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/myfunction.js"></script>
<script type="text/javascript" src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js"></script>
<?php doAction('index_head'); ?>
</head>

<body>
<div id="#anchor"><a name="top"></a><!--设置顶部锚点--></div>
<div id="header">
    <!--注意：LOGO图标和博客名称代码只能任选其一-->
    <div id="logo"><!--LOGO图标，默认大小为：240x60-->
        <a href="<?php echo BLOG_URL; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/logo.gif" /></a>
    </div>
    <!--<div id="bloginfo">--><!--博客名称-->
        <!--<div id="blog-name">
            &nbsp;<a href="<?php //echo BLOG_URL; ?>"><?php echo $blogname; ?></a>&nbsp;<a href="<?php //echo BLOG_URL; ?>rss.php" title="订阅本站RSS"><img src="<?php //echo TEMPLATE_URL; ?>images/rss.gif" alt="订阅Rss"/></a>
        </div>
        <div id="blog-desc">
            &nbsp;── <?php echo $bloginfo; ?>
        </div>
    </div>-->
    <div id="nav"><?php blog_navi();?></div><!--导航栏-->
    <div id="logsearch"><!--搜索框-->
        <form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
            <input name="keyword" type="text" class="search" style="width:110px; margin:3px auto;" />
        </form>
    </div>
    <div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare">
        <a class="bds_qzone"></a>
        <a class="bds_tsina"></a>
        <a class="bds_tqq"></a>
        <a class="bds_renren"></a>
        <span class="bds_more"></span>
        <!--<a class="shareCount"></a>-->
    </div>
    <br style="clear:both;" />
</div>
<div id="wrap"><!--内容外框-->
    <div id="frame"><!--内容-->
<!--herder.End-->
