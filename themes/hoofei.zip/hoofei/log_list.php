<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="main">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<div class="entry">
	<div class="content">
		<?php echo $value['log_description']; ?>	
		<div class="clear"></div>
	</div>
	<div class="from">
	
		<span class="mycome"><?php echo gmdate('F j, Y', $value['date']); ?></span><span class="option"><a href="<?php echo $value['log_url']; ?>">评论<span class="reply">(<?php echo $value['comnum']; ?>)</span></a></span>
	</div>
	<div class="clear"></div>
</div>
<?php endforeach; ?>


	<div id="pages"><?php echo $page_url;?></div>
	<div id="stat">
	<?php $sta_cache = Cache::getInstance()->readCache('sta');?>
						已唠叨 <strong><?php echo $sta_cache['lognum']; ?></strong> 次			</div>

		</div><!-- #main end -->
<?php
 include View::getView('footer');
?>
