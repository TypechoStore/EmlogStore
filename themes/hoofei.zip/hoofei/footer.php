<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!-- #wrapper end -->
<div id="footer">
	<span>&copy; 2012 <?php echo $blogname; ?></span>Powered by <a href="http://www.emlog.net">Emlog</a>,Theme <a href="http://bianjian.org/zh-hans/weibo4typecho">Hoofei</a>＆<a href="http://jingzipanda.com">Kami</a></div><!-- #footer end -->
<?php doAction('index_footer'); ?>
</body>
</html>