<?php 
/*
* �Խ�ҳ��ģ��
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
 <div id="main">

<div class="entry">
	<div class="content"><?php echo $log_content; ?><div class="clear"></div></div>

	<div class="from">
		<span class="mycome"><?php echo gmdate('F j, Y', $date); ?></span>
	</div>
	<div class="clear"></div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
		</div><!-- #main end -->
<?php
 include View::getView('footer');
?>