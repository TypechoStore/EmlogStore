<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
 <div id="main">

<div class="entry first">
	<div class="content"><?php echo $log_content; ?><div class="clear"></div></div>

	<div class="from">
		<span class="mycome"><?php echo gmdate('F j, Y', $date); ?></span><span class="option"><?php blog_tag($logid); ?></span>
	</div>
	<div class="clear"></div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
	<div id="stat">
	<?php $sta_cache = Cache::getInstance()->readCache('sta');?>
						已唠叨 <strong><?php echo $sta_cache['lognum']; ?></strong> 次			</div>

		</div><!-- #main end -->
<?php
 include View::getView('footer');
?>