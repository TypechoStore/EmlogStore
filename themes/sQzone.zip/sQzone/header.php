<?php
/*
Template Name:sQzone
Description: 黑色诱惑
Version:1.0
Author:死性不改
Author Url:http://www.iamzm.com
Sidebar Amount:0
ForEmlog:4.2.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<table width="1002" border="0" cellpadding="0" cellspacing="0" background="<?php echo BLOG_URL; ?>/content/templates/sQzone/images/top_bg.gif" align="center">
<tbody><tr>

<td width="129" align="center"><a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>"><img src="<?php echo BLOG_URL; ?>/content/templates/sQzone/images/top_logo.gif" width="129" height="25" border="0"></a></td>
<td align="center"><?php echo $bloginfo; ?></td>
<td align="right"><img src="<?php echo BLOG_URL; ?>/content/templates/sQzone/images/top_dian.gif" width="7" height="10"> <a href="javascript:window.open('http://shuqian.qq.com/post?from=3&title='+encodeURIComponent(document.title)+'&uri='+encodeURIComponent(document.location.href)+'&jumpback=2&noui=1','favit','width=930,height=470,left=50,top=50,toolbar=no,menubar=no,location=no,scrollbars=yes,status=yes,resizable=yes');void(0)">收藏书签</a> <img src="<?php echo BLOG_URL; ?>/content/templates/sQzone/images/top_dian.gif" width="7" height="10"> <a onclick="this.style.behavior='url(#default#homepage)';this.setHomePage('<?php echo BLOG_URL; ?>');" href="#"> 设为首页</a> <img src="<?php echo BLOG_URL; ?>/content/templates/sQzone/images/top_dian.gif" width="7" height="10"> <a href="<?php echo BLOG_URL; ?>" onmouseover="javascript:window.external.AddFavorite('<?php echo BLOG_URL; ?>', '<?php echo BLOG_URL; ?>：<?php echo BLOG_URL; ?>');" style="color: ffffff">加入收藏</a></td>
</tr>
</tbody></table>
<div class="big_box">

<table width="950" height="191" border="1" align="center" cellpadding="1" cellspacing="1" bordercolor="#333333" bgcolor="#000000"><tbody><tr><td align="center">
<table bordercolor="#ffffff" cellspacing="0" align="center" width="950" border="0"><tbody><tr><td><a href="<?php echo BLOG_URL; ?>"><img src="<?php echo BLOG_URL; ?>/content/templates/sQzone/images/logo.gif" border="0" width="950"></a></td></tr></tbody></table></td></tr></tbody></table>
<div class="daohang">
    <ul>
	<li class="<?php echo $curpage == CURPAGE_HOME ? 'current' : 'common';?>"><a href="<?php echo BLOG_URL; ?>">首页</a></li>
	<?php if($istwitter == 'y'):?>
	
	<?php endif;?>
	<?php 
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach ($navi_cache as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	$val['is_blank'] = $val['newtab'] == 'y' ? 'target="_blank"' : '';
    $val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
		
	?>
	<li class="<?php echo isset($logid) && $key == $logid ? 'current' : 'common';?>"><a href="<?php echo $val['url']; ?>" target="<?php echo $val['is_blank']; ?>"><?php echo $val['naviname']; ?></a></li>
	<?php endforeach;?>
	<?php doAction('navbar', '<li class="common">', '</li>'); ?>
	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
	<li class="common"><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
	<li class="common"><a href="<?php echo BLOG_URL; ?>admin/">管理中心</a></li>
	<li class="common"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
	<?php else: ?>
	<li class="common"><a href="<?php echo BLOG_URL; ?>admin/">登录</a></li>
	<?php endif; ?>
   	</ul>
</div>
</div>

