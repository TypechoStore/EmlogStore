<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--end #content-->



<div id="footerbarw">
<table bordercolor="#000000" cellspacing="1" cellpadding="0" width="970" align="center" bgcolor="#000000" border="1">
<tbody><tr align="center" bordercolor="#333333" bgcolor="#111111">
<td><a href="#" onclick="javascript:window.external.AddFavorite('<?php echo BLOG_URL; ?>', 'Qzone风云榜官方网')" target="_self">将本站添加到网页收藏夹</a> | <a href="#" onclick="this.style.behavior='url(#default#homepage)';this.setHomePage('<?php echo BLOG_URL; ?>');return(false);">每次上网自动访问本站</a> | <a href="javascript:window.open('http://shuqian.qq.com/post?from=3&title='+encodeURIComponent(document.title)+'&uri='+encodeURIComponent(document.location.href)+'&jumpback=2&noui=1','favit','width=930,height=470,left=50,top=50,toolbar=no,menubar=no,location=no,scrollbars=yes,status=yes,resizable=yes');void(0)">把本站添加到您的QQ书签</a><br>
<a href="#">关于本站</a> | <a href="#"><font color="#00ff00"><b>广告招租</b></font></a> | <a href="#">风格出售</a> | <a href="#"><font color="#FFFF00"><b>申请加入风云榜</b></font></a> | <a href="#">↑回到顶部</a><br>

Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>  <a href="http://www.miibeian.gov.cn/" target="_blank"><?php echo $icp; ?></a>
Style by <a href="http://www.iamzm.com" title="IAMZM emlog style">IAMZM</a> <br>


<?php echo $footer_info; ?></td>
</tr>
</tbody></table>
<?php doAction('index_footer'); ?>
</div><!--end #footerbar-->
</div><!--end #wrap-->
</body>
</html>