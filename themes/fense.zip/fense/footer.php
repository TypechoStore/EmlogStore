<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<!--主体内容区结束-->
<div id="footer">
<div id="innerFooter">
<div class="footer01"></div>
<div id="frlink">
<ul>
<li class="frtitle">友情链接：</li>
<?php index_flinks();?>
</ul>
</div>
<div id="footericp"><a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?></div>
</div>
</div><!--innerWrapper over-->
</div><!--wrapper over-->
<script>prettyPrint();</script>
</body>
</html>