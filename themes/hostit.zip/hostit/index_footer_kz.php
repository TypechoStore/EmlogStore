<?php 
/*
* 底部扩展页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!--底部扩展图文并茂是否显示-->

	  <div class="con_2">
	  	   <?php if (_g('index_foot_kz') == "yes"): ?>
    	   <div class="img_listbox">           
	            <h2>
		          <span class="block_cate">
			            <span class="block_cate">
			                  <a target="_blank" href="<?php echo Url::sort(_g('index_foot_img_sort')); ?>">
							  <?php echo $sort_cache[_g('index_foot_img_sort')]['sortname']; ?></a>
			            </span>
			            <span class="more">
			                  <a target="_blank" href="<?php echo Url::sort(_g('index_foot_img_sort')); ?>">更多...</a>
			            </span>
			      </span>
		        </h2>            
		        <ul>                
		           <?php thumbs_by_sort(_g('index_foot_img_sort'),_g('index_foot_img_num')); ?>
		        </ul>            
	       </div>
	       <?php else: ?>
		   <?php endif; ?>
<!--底部扩展图文并茂是否显示 end-->



<!--底部扩展分类是否显示-->
	  	   <?php if (_g('index_foot_sort') == "yes"): ?>
		   <div class="listbox">    
	            <h2>
		          <span class="block_cate">
		                <a target="_blank" href="<?php echo Url::sort(_g('index_foot_sort1_url')); ?>">
						<?php echo $sort_cache[_g('index_foot_sort1_url')]['sortname']; ?></a>
		          </span>
		          <span class="more">
		                <a target="_blank" href="<?php echo Url::sort(_g('index_foot_sort1_url')); ?>">更多...</a>
		          </span>
		        </h2>    
		        <ul>        
		           <?php echo get_foot(_g('index_foot_sort1_url'),_g('index_foot_nuw'));?>
		        </ul>            
           </div>
	
	       <div class="listbox box2">
	            <h2>
		           <span class="block_cate">
		                <a target="_blank" href="<?php echo Url::sort(_g('index_foot_sort2_url')); ?>">
						<?php echo $sort_cache[_g('index_foot_sort2_url')]['sortname']; ?></a>
			       </span>
			       <span class="more">
			             <a target="_blank" href="<?php echo Url::sort(_g('index_foot_sort2_url')); ?>">更多...</a>
			       </span>
		        </h2>
		        <ul>    
		           <?php echo get_foot(_g('index_foot_sort2_url'),_g('index_foot_nuw'));?>
		        </ul>
	       </div>



           <div class="listbox">    
	            <h2>
		          <span class="block_cate">
		                <a target="_blank" href="<?php echo Url::sort(_g('index_foot_sort3_url')); ?>">
						<?php echo $sort_cache[_g('index_foot_sort3_url')]['sortname']; ?></a>
		          </span>
		          <span class="more">
		                <a target="_blank" href="<?php echo Url::sort(_g('index_foot_sort3_url')); ?>">更多...</a>
		          </span>
		        </h2>    
		        <ul>        
		           <?php echo get_foot(_g('index_foot_sort3_url'),_g('index_foot_nuw'));?>
		        </ul>            
           </div>
	
	       <div class="listbox box2">
	            <h2>
		           <span class="block_cate">
		                <a target="_blank" href="<?php echo Url::sort(_g('index_foot_sort4_url')); ?>">
						<?php echo $sort_cache[_g('index_foot_sort4_url')]['sortname']; ?></a>
			       </span>
			       <span class="more">
			             <a target="_blank" href="<?php echo Url::sort(_g('index_foot_sort4_url')); ?>">更多...</a>
			       </span>
		        </h2>
		        <ul>    
		           <?php echo get_foot(_g('index_foot_sort4_url'),_g('index_foot_nuw'));?>
		        </ul>
	       </div>
	       <?php else: ?>
		   <?php endif; ?>
		   </div>
      </div>