<?php 
/*
* 首页
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>		        
           <?php if (_g('index_blog') == "yes"): ?>
           <?php $sort_cache = Cache::getInstance()->readCache('sort'); ?>
		   <div class="con-block">
                <div class="lf">     
                     <link href="<?php echo TEMPLATE_URL; ?>css/saySlide.css" type="text/css" rel="stylesheet" />
                     <script src="<?php echo TEMPLATE_URL; ?>js/jquery-1.7.1.min.js" type="text/javascript" ></script>
                     <script src="<?php echo TEMPLATE_URL; ?>js/jquery.saySlide.js" type="text/javascript" ></script>	
		             <style>
                         #saySlide{width:251px;height:321px;margin:0 auto;overflow:hidden;}
                         b{width:100px;text-align:right;display:inline-block;padding-right:10px;color:#2A730B;}
                     </style>		

		             <div class="bx1">
                          <div id="saySlide">
                                <!--调用数据获取函数开始-->
                                <?php get_flash_data(4); ?>
                          </div>
                         <script>
                            $(function(){
	                        $("#saySlide").saySlide({isTitle:true,isBottombg:true,autodir:'left'});
                            })
                         </script>
                     </div>
	                 <?php if (_g('index_xiazai') == "yes"): ?>
					 <?php include View::getView('left_ad'); ?> <!--载入左侧下载页面-->
	                 <?php else: ?>
		             <?php endif; ?>

                </div>	 
	            <div class="rt">
	                 <div class="focus_area">        
	                      <div class="focus">          
	                           <div class="block-title">焦点关注</div>          
	                                <ul>  
        	                           <?php index_show(3);?>
                                    </ul>        
                          </div>        
                          <div class="zhuant">          
	                           <div class="block-title">专题</div>          
	                                <ul>            
                                       <?php index_zt(_g('index_Special'));?>     
	                                </ul>        
	                      </div>      
	                 </div>      
		             <div class="nlst">        
	                      <div class="ct">          
	                           <ul>            
	                              <?php if (_g('index_xiazai') == "yes"): ?>
								  <li><a href="javascript:;" class="current">最新 - 随机</a></li>            
	                              <?php else: ?>
								  <li><a href="javascript:;" class="current">站点统计</a></li>            
		                          <?php endif; ?>

							   </ul>          
	                           <span>
					               本站共有文章
						           <strong><?php echo $sta_cache['lognum']; ?></strong>
							       篇，网友评论
							       <strong><?php echo $sta_cache['comnum']; ?></strong>
							       次
					           </span> 
	                      </div>
						  
	                      <?php if (_g('index_xiazai') == "yes"): ?>
						  <div style="display: block;" class="lst lst-1 new-list">           
	                           <div style="display: block;" class="block new-list-1">
	                                <ul><?php newlog();?></ul><!--首页分类最新文章-->
                                    <ul><?php randlog();?></ul><!--首页分类随机文章-->
                               </div>
	                      </div>
	                      <?php else: ?>
		                  <?php endif; ?>
                     
					 </div>
                </div><!--rt end-->      
                <div class="bx-recom2"></div>    
           </div><!--con-block end-->         
	  </div><!--con end-->
      <div class="con_2">
    	   <div class="img_listbox">           
	            <h2>
		          <span class="block_cate">
			            <span class="block_cate">
			                  <a target="_blank" href="<?php echo Url::sort(_g('index_pic')); ?>">
							  <?php echo $sort_cache[_g('index_pic')]['sortname']; ?></a>
			            </span>
			            <span class="more">
			                  <a target="_blank" href="<?php echo Url::sort(_g('index_pic')); ?>">更多...</a>
			            </span>
			      </span>
		        </h2>            
		        <ul>                
		           <?php thumbs_by_sort(_g('index_pic'),_g('index_img_num')); ?>
		        </ul>            
	       </div>
	       
		   <div class="listbox">    
	            <h2>
		          <span class="block_cate">
		                <a target="_blank" href="<?php echo Url::sort(_g('index_sort1')); ?>">
						<?php echo $sort_cache[_g('index_sort1')]['sortname']; ?></a>
		          </span>
		          <span class="more">
		                <a target="_blank" href="<?php echo Url::sort(_g('index_sort1')); ?>">更多...</a>
		          </span>
		        </h2>    
		        <ul>        
		           <?php echo get_list(_g('index_sort1'),_g('index_sort_num'));?>
		        </ul>            
           </div>
	
	       <div class="listbox box2">
	            <h2>
		           <span class="block_cate">
			             <a target="_blank" href="<?php echo Url::sort(_g('index_sort2')); ?>">
						 <?php echo $sort_cache[_g('index_sort2')]['sortname']; ?></a>
			       </span>
			       <span class="more">
			             <a target="_blank" href="<?php echo Url::sort(_g('index_sort2')); ?>">更多...</a>
			       </span>
		        </h2>
		        <ul>    
		           <?php echo get_list(_g('index_sort2'),_g('index_sort_num'));?>
		        </ul>
	       </div>
      </div>


      <?php include View::getView('index_footer_kz'); ?> <!--载入底部扩展页面-->


<!--以博客模式呈现-->

<?php else: ?>

<?php doAction('index_loglist_top'); ?>
           <div id="wrapper">    
	            <div class="content fl">      
	                 <div class="cate_list">        
	                      <ul class="ulcl">                                                                                                  
	                          <!--开始循环输出文章-->
	                          <?php foreach($logs as $value): ?>
                              <li>
							     <a class="list_thumbnail" target="blank" href="<?php echo $value['log_url']; ?>" class="thumbnail">
                                     <?php
                                        //拉取附件第一张图片，如果没有，则随机拉取random文件夹图片，图片名称任意
                                        $thum_src = getThumbnail($value['logid']);
                                        $imgFileArray = glob("content/templates/hostit/images/random/*.*");
                                        if(!empty($thum_src)){ ?>
                                           <img width="100" height="100" src="<?php echo $thum_src; ?>" alt="<?php echo $value['log_title']; ?>" title="<?php echo $value['log_title'] ?>" />
                                        <?php
                                           }else{
                                        ?>
                                           <img width="100" height="100" src="<?php echo BLOG_URL; ?><?php echo $imgFileArray[array_rand($imgFileArray)]; ?>" alt="<?php echo $value['log_title']; ?>" title="<?php echo $value['log_title'] ?>" />
                                        <?php
                                        }
                                     ?>
                                 </a> 
	                             <div class="block">                
	                                  <h2>
									     <?php topflg($value['top']); ?>
										 <a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
	                                     <span class="state tody"><?php echo gmdate('Y-n-j G:i', $value['date']); ?>日</span>
									  </h2>                
	                                  <div class="memo">
	                                       <p><?php echo subString(strip_tags($value['log_description']),0,210,"..."); ?></p>
									  </div>                
	                                  <span class="tags">
									        <strong>Tags：</strong>
                                            <?php blog_tag($value['logid']); ?>
		                              </span>
								 </div>          
							  </li>                                                            
	                          <?php endforeach; ?>
                          </ul>      
	                 </div>      
	                 <div class="page_nav">
	                      <span class="page_num">
                                          <?php echo $page_url;?>
						  </span>
					 </div>
				</div><!-- content End -->
                <?php include View::getView('side'); ?>
           </div>
      </div><!--con End-->
	  <?php endif; ?>
