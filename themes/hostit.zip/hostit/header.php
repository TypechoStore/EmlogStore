<?php
/*
Template Name:IThost_CMS
Description:移植自IT之家，全面整合模板设置插件，让您实现后台傻瓜式操作 ……首页多处采用if语句实现各类模块的开启和关闭，让您可以根据个人喜好配置界面，点击下面的设置按钮即可开始设置您的模板！如果您没看到下面的设置按钮则说明您没有安装模板设置插件，本模板必须安装模板设置插件才可以正常运行，请注意！！！
Version:5.0
Author:陈子文
Author Url:http://vps.lantk.com/?post=97
Sidebar Amount:1
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!--忽略因找不到JS对象所产生的网页错误-->
<script language="JavaScript">
<!-- Hide
function killErrors() {
return true;
}
window.onerror = killErrors;
// -->
</script> 
<!--忽略因找不到JS对象所产生的网页错误结束-->
<meta content="IE=9; IE=8; IE=7; IE=EDGE" http-equiv="X-UA-Compatible">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<link href="<?php echo TEMPLATE_URL; ?>css/style.css" rel="stylesheet" type="text/css" />
<link type="text/css" rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/stylev2.1.css">
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>	
<?php doAction('index_head'); ?>
</head>
<body class="index">
      <?php if (_g('index_top_nav') == "yes"): ?>  
	  <div id="tb">  
           <div class="tb-nav">  
                <div class="tb-nav-block-l">    
                      <div class="tb-item">        
                            <a class="item-link" href="<?php echo BLOG_URL; ?>"><?php echo $bloginfo; ?></a>       
                      </div>   
                </div>    
                <div class="tb-nav-block-r"> 
                     <iframe scrolling="no" align="absmiddle" frameborder="0" style="width:121px;height:23px;border:none;overflow:hidden;" border="0" allowtransparency="true" src="http://follow.v.t.qq.com/index.php?c=follow&a=quick&name=chenziwen918&style=5&t=1384867391695&f=1" id="sina_follow">
					 </iframe>
					 <div class="tb-item dm">
                           <a class="item-link item-link-2" href="<?php echo BLOG_URL; ?>?plugin=yls_reg">注册</a>        
                     </div>      
                     <div class="tb-item dm"> 
                           <a class="item-link item-link-3" href="<?php echo BLOG_URL; ?>admin">网站登录</a>        
                     </div>      
                </div>
           </div>
      </div>
	  <?php else: ?>
	  <?php endif; ?>
     
	  <div class="view_setting"> </div>
      <?php if (_g('index_top_nav') == "yes"): ?>        
	  <div id="hd">   
           <div id="nav">   
                <a class="logo" title="<?php echo $blogname; ?>" href="<?php echo BLOG_URL; ?>">
	            <img width="100" height="28" alt="<?php echo $blogname; ?>" src="<?php echo _g('index_logo'); ?>"></a>       
                <ul class="nav_list">      
	                <?php blog_navi();?>
	            </ul>
                <div class="sc">      
	                 <form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
	                       <input name="keyword" size="24" class="focus" id="searchTextbox">     
					       <button name="sa" type="submit">搜索</button> 
			         </form>      
			         <a title="百度搜索" class="js" target="_blank" href="http://www.baidu.com">百度搜索</a> 
		        </div>  
	       </div>
      </div>
      <?php else: ?>
	  <div id="hd1">   
           <div id="nav1">   
                <a class="logo" title="<?php echo $blogname; ?>" href="<?php echo BLOG_URL; ?>">
	            <img width="100" height="28" alt="<?php echo $blogname; ?>" src="<?php echo _g('index_logo'); ?>"></a>       
                <ul class="nav_list">      
	                <?php blog_navi();?>
	            </ul>
                <div class="sc">      
	                 <form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
	                       <input name="keyword" size="24" class="focus" id="searchTextbox">     
					       <button name="sa" type="submit">搜索</button> 
			         </form>      
			         <a title="百度搜索" class="js" target="_blank" href="http://www.baidu.com">百度搜索</a> 
		        </div>  
	       </div>
      </div>
	  <?php endif; ?>
	  <div id="con"><!--con-->   
           <?php if (_g('index_top_nav') == "yes"): ?>                   
		   <div id="hl">
                <div class="hl-960">
                     <h2><a target="_blank" href="<?php echo _g('index_headtxt_url'); ?>"><?php echo _g('index_headtxt'); ?></a></h2>
                </div>
           </div>
          <?php else: ?>
		   <div id="hl1">
                <div class="hl-960">
                     <h2><a target="_blank" href="<?php echo _g('index_headtxt_url'); ?>"><?php echo _g('index_headtxt'); ?></a></h2>
                </div>
           </div>
		   <?php endif; ?>

		   <div class="bx-recom">      
             	<?php if (_g('index_head_ad') == "yes"): ?>  
				<a href="<?php echo _g('index_headimg_url'); ?>"><img src="<?php echo _g('index_headimg'); ?>"></a>  
		        <?php else: ?>
			    <?php endif; ?>
           </div>
