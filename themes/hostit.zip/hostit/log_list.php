<?php 
/*
* 列表页
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php if($pageurl == Url::logPage()){ ?>
<?php include View::getView('index'); ?>
<?php }else{ ?>
<?php doAction('index_loglist_top'); ?>
           <div id="wrapper">    
	            <div class="content fl">      
	                 <div class="current_nav">
	                      <span class="cate_current">当前分类：</span><?php blog_sort($logid); ?> 
					 </div>      
	                 <div class="cate_list">        
	                      <ul class="ulcl">                                                                                                  
	                          <!--开始循环输出文章-->
	                     <?php foreach($logs as $value): ?>
                        <?php if(pic_thumb1($value['content'])){
						$imgsrc = pic_thumb1($value['content']);
					}else
						$imgsrc = TEMPLATE_URL.'images/random/'.rand(1,5).'.jpg';
					?>
						      <li>
							     <a class="list_thumbnail" target="blank" href="<?php echo $value['log_url']; ?>" class="thumbnail">
                                     <img width="100" height="100" src="<?php echo $imgsrc; ?>" />                                     
                                 </a> 
	                             <div class="block">                
	                                  <h2>
									     <?php topflg($value['top']); ?>
										 <a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
	                                     <span class="state tody"><?php echo gmdate('Y-n-j G:i', $value['date']); ?>日</span>
									  </h2>                
	                                  <div class="memo">
	                                       <p><?php echo subString(strip_tags($value['log_description']),0,210,"..."); ?></p>
									  </div>                
	                                  <span class="tags">
									        <strong>Tags：</strong>
                                            <?php blog_tag($value['logid']); ?>
		                              </span>
								 </div>          
							  </li>                                                            
	                          <?php endforeach; ?>
                          </ul>      
	                 </div>      
	                 <div class="page_nav">
	                      <span class="page_num">
                                          <?php echo $page_url;?>
						  </span>
					 </div>
				</div><!-- content End -->
                <?php include View::getView('side'); ?>
           </div>
      </div><!--con End-->
     <?php } ?>
	 <?php include View::getView('footer'); ?>   

