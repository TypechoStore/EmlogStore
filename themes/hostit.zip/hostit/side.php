<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div class="sidebar">      
     <link type="text/css" rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/block.css">
     <script src="<?php echo TEMPLATE_URL; ?>js/7hot.js" type="text/javascript"></script>	
     <div class="right_con post_right_con ">
          <br/>
		  <br/>
		  <?php if (_g('side_zh') == "yes"): ?>
		  <div class="top_news">
      	       <div class="bar">
                    <ul>
                       <li onmousemove="must()" class="" id="must">分类</li>
                       <li onmousemove="hot7()" id="hot7" class="">热门文章</li>
                       <li class="" onmousemove="comm7()" id="comm7">随机</li>
                       <li class="current" onmousemove="month()" id="month">最新</li>
                    </ul>
               </div>
               <div style="display: none;" class="list" id="con1">
            	    <ul>   
                       <?php echo widget_hotlog(""); ?>
                    </ul>
               </div>
               <div style="display: none;" class="list" id="con2">
            	    <ul>          
                       <?php echo widget_random_log(""); ?>
                    </ul>
               </div>
               <div style="" class="list" id="con3">
            	    <ul>
                       <?php echo widget_newlog(""); ?>
                    </ul>
               </div>
               <div class="list" id="con4" style="display: none;">
            	    <ul>
                       <?php echo widget_sort(""); ?>
                    </ul>
               </div>
          </div>
		  <br/>
		  <?php else: ?><!--否则-->
		  <br/>
		  <div class="top_news">
      	       <div class="bar">
                    <ul>
                       <li onmousemove="must()" class="" id="must">分类</li>
                    </ul>
               </div>
               <div class="list" id="con4">
            	    <ul>
                       <?php echo widget_sort(""); ?>
                    </ul>
               </div>
          </div>
		  <br/>
		  <div class="top_news">
      	       <div class="bar">
                    <ul>
                       <li onmousemove="must()" class="" id="must">最新文章</li>
                    </ul>
               </div>
               <div class="list" id="con4">
            	    <ul>
                       <?php echo widget_newlog(""); ?>
                    </ul>
               </div>
          </div>
		  <br/>
		  <div class="top_news">
      	       <div class="bar">
                    <ul>
                       <li onmousemove="must()" class="" id="must">随机文章</li>
                    </ul>
               </div>
               <div class="list" id="con4">
            	    <ul>
                       <?php echo widget_random_log(""); ?>
                    </ul>
               </div>
          </div>
		  <br/>
		  <div class="top_news">
      	       <div class="bar">
                    <ul>
                       <li onmousemove="must()" class="" id="must">热门文章</li>
                    </ul>
               </div>
               <div class="list" id="con4">
            	    <ul>
                       <?php echo widget_hotlog(""); ?>
                    </ul>
               </div>
          </div>
		  <br/>
		  <?php endif; ?>

          
		  <li id="hotcommentli" style="" class="sb_list sbb">            
		      <div class="rm_hot">最热评论</div>                
			       <ul id="hotcomment" class="side_comm sub_ul">
				       <?php echo widget_newcomm("最新评论"); ?>
				   </ul>       
	      </li>
    </div>
</div>
