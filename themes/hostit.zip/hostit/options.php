<?php

/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(

//首页logo设置开始
	'index_logo' => array(
		'type' => 'image',
		'name' => '首页logo设置,PS仅支持png格式图片,请注意',
		'default' => ''.TEMPLATE_URL.'images/logo.png',
	),
//首页logo设置结束


//头部文字广告设置开始
	'index_headtxt' => array(
		'type' => 'text',
		'name' => '头部文字广告',
		'default' => 'ITHOST_CMS主题发布,高端大气上档次,点击下载',
	),
	'index_headtxt_url' => array(
		'type' => 'text',
		'name' => '头部文字广告链接地址',
		'default' => 'http://vps.lantk.com/?post=75',
	),

//头部文字广告设置结束


//头部图片广告设置开始
	'index_headimg' => array(
		'type' => 'image',
		'name' => '头部图片广告图片',
		'default' => ''.TEMPLATE_URL.'images/top.jpg',
	),
	'index_headimg_url' => array(
		'type' => 'text',
		'name' => '头部图片广告链接地址',
		'default' => 'http://vps.lantk.com/?plugin=archiver',
	),
//头部图片广告设置结束


//焦点关注与专题设置开始
	'index_Special' => array(
		'type' => 'sort',
		'name' => '首页专题分类ID',
		'default' => '29',
	),
//焦点关注与专题设置结束


//首页图文并茂分类设置开始
	'index_pic' => array(
		'type' => 'sort',
		'name' => '首页图文并茂分类',
		'default' => '1',
	),
		'index_img_num' => array(
		'type' => 'text',
		'name' => '首页图文并茂调用数量',
		'default' => '7',
	),
//首页图文并茂分类设置结束


//首页盒子分类设置开始
	'index_sort1' => array(
		'type' => 'sort',
		'name' => '请选择第一分类',
		'default' => '1',
	),
		'index_sort2' => array(
		'type' => 'sort',
		'name' => '请选择第二分类',
		'default' => '10',
	),
	'index_sort_num' => array(
		'type' => 'text',
		'name' => '首页分类调用数量',
		'default' => '10',
	),
//首页盒子分类设置结束



//首页扩展图文开始
	'index_foot_kz' => array(
		'type' => 'radio',
		'name' => '是否开启底部扩展图文',
		'values' => array(
            'yes' => '开启',
            'no' => '关闭'
        ),
		'default' => 'no',
	),
	'index_foot_img_sort' => array(
		'type' => 'sort',
		'name' => '请选择底部扩展图文分类',
		'default' => '2',
	),
		'index_foot_img_num' => array(
		'type' => 'text',
		'name' => '请选择底部扩展图文数量',
		'default' => '14',
	),
//首页扩展图文结束


//首页扩展分类开始
	'index_foot_sort' => array(
		'type' => 'radio',
		'name' => '是否开启底部扩展分类显示',
		'values' => array(
            'yes' => '开启',
            'no' => '关闭'
        ),
		'default' => 'no',
	),
	'index_foot_sort1_url' => array(
		'type' => 'sort',
		'name' => '请选择底部扩展分类（1）',
		'default' => '10',
	),
	'index_foot_sort2_url' => array(
		'type' => 'sort',
		'name' => '请选择底部扩展分类（2）',
		'default' => '4',
	),
	'index_foot_sort3_url' => array(
		'type' => 'sort',
		'name' => '请选择底部扩展分类（3）',
		'default' => '10',
	),
	'index_foot_sort4_url' => array(
		'type' => 'sort',
		'name' => '请选择底部扩展分类（4）',
		'default' => '3',
	),
	'index_foot_nuw' => array(
		'type' => 'text',
		'name' => '分类调用数量',
		'default' => '4',
	),



//首页扩展分类结束



//底部banner开始
	'footer_banner' => array(
		'type' => 'radio',
		'name' => '是否开启底部banner',
		'values' => array(
            'yes' => '开启',
            'no' => '关闭'
        ),
		'default' => 'no',
	),

	'footerbanner1' => array(
		'type' => 'text',
		'name' => '底部banner1名称',
		'default' => '关于本站',
	),
	'footerbanner1_url' => array(
		'type' => 'text',
		'name' => '底部banner1连接',
		'default' => '#',
	),

	'footerbanner2' => array(
		'type' => 'text',
		'name' => '底部banner2名称',
		'default' => '关于本站',
	),
	'footerbanner2_url' => array(
		'type' => 'text',
		'name' => '底部banner2连接',
		'default' => '#',
	),

	'footerbanner3' => array(
		'type' => 'text',
		'name' => '底部banner3名称',
		'default' => '关于本站',
	),
	'footerbanner3_url' => array(
		'type' => 'text',
		'name' => '底部banner3连接',
		'default' => '#',
	),

	'footerbanner4' => array(
		'type' => 'text',
		'name' => '底部banner4名称',
		'default' => '关于本站',
	),
	'footerbanner4_url' => array(
		'type' => 'text',
		'name' => '底部banner4连接',
		'default' => '#',
	),

	'footerbanner5' => array(
		'type' => 'text',
		'name' => '底部banner5名称',
		'default' => '关于本站',
	),
	'footerbanner5_url' => array(
		'type' => 'text',
		'name' => '底部banner5连接',
		'default' => '#',
	),

	'footerbanner6' => array(
		'type' => 'text',
		'name' => '底部banner6名称',
		'default' => '关于本站',
	),
	'footerbanner6_url' => array(
		'type' => 'text',
		'name' => '底部banner6连接',
		'default' => '#',
	),

	'footerbanner7' => array(
		'type' => 'text',
		'name' => '底部banner7名称',
		'default' => '关于本站',
	),
	'footerbanner7_url' => array(
		'type' => 'text',
		'name' => '底部banner7连接',
		'default' => '#',
	),
//底部banner结束




//软件快速下载设置开始
	'index_xiazai' => array(
		'type' => 'radio',
		'name' => '是否开启左侧软件下载入口',
		'values' => array(
            'yes' => '开启',
            'no' => '关闭'
        ),
		'default' => 'no',
	),
//软件快速下载设置结束



//友情链接favicon开关
	'footer_favicon' => array(
		'type' => 'radio',
		'name' => '友情链接favicon图标开关',
		'values' => array(
            'yes' => '开启',
            'no' => '关闭'
        ),
		'default' => 'yes',
	),
//友情链接favicon开关


//首页幻灯片，焦点图，专题开关
	'index_head_ad' => array(
		'type' => 'radio',
		'name' => '首页文字图片广告开关',
		'values' => array(
            'yes' => '开启',
            'no' => '关闭'
        ),
		'default' => 'yes',
	),
//首页幻灯片，焦点图，专题开关


//首页顶部黑色条幅开关
	'index_top_nav' => array(
		'type' => 'radio',
		'name' => '首页顶部黑色条幅开关',
		'values' => array(
            'yes' => '开启',
            'no' => '关闭'
        ),
		'default' => 'yes',
	),
//首页顶部黑色条幅开关


//首页博客模式
	'index_blog' => array(
		'type' => 'radio',
		'name' => '首页博客模式',
		'values' => array(
            'yes' => '开启首页CMS模式',
            'no' => '开启首页博客模式'
        ),
		'default' => 'yes',
	),
//首页博客模式

//开启下雪代码
	'happy_new' => array(
		'type' => 'radio',
		'name' => '开启下雪代码',
		'values' => array(
            'yes' => '开启',
            'no' => '关闭'
        ),
		'default' => 'no',
	),
//开启下雪代码


//侧边栏组合显示
	'side_zh' => array(
		'type' => 'radio',
		'name' => '侧边栏组合显示是否开始',
		'values' => array(
            'yes' => '开启组合显示',
            'no' => '关闭组合显示'
        ),
		'default' => 'yes',
	),
//侧边栏组合显示





);
