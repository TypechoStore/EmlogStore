<?php 
/*
* 左侧下载页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="bx2">        
	            <div class="bx-title">软件快速下载中心</div>        
	            <ul>                  
                   <!--左侧下载栏第一列-->
                   <li>
	                  <img width="36" height="36" src="<?php echo TEMPLATE_URL; ?>images/1.gif">          <!--下载一图片地址-->         
	                  <p class="pro-name">
					      <a href="http://emlog.net" target="_blank">EMLOG5.20正式版</a>
					  </p>          
	                  <p>最后更新：2013.11.12</p>                                                         
 	                  <a href="http://emlog.net" target="_blank" class="down_btn">立即下载</a> 
					</li>
                    
					<!--左侧下载栏第二列-->
    	            <li>
					  <img width="36" height="36" src="<?php echo TEMPLATE_URL; ?>images/2.gif">
	                  <p class="pro-name">
					      <a href="http://chenziwen.ys168.com/note/fd.htm?http://ys-I.ys168.com/2.0/315551921/Siu8Rgi37461378IHOHM/8uftp.rar" target="_blank">FTP(8UFTP)</a>
					  </p>
	                  <p>最后更新：2014.01.22</p>
	                  <a href="http://chenziwen.ys168.com/note/fd.htm?http://ys-I.ys168.com/2.0/315551921/Siu8Rgi37461378IHOHM/8uftp.rar" target="_blank" class="down_btn">立即下载</a>
					</li>
                    
					<!--左侧下载栏第三列-->	 
	                <li> 
					   <img width="36" height="36" src="<?php echo TEMPLATE_URL; ?>images/3.gif">    
	                   <p class="pro-name">
	                       <a href="http://chenziwen.ys168.com/note/fd.htm?http://ys-F.ys168.com/2.0/315551941/Tjs5Wjk37461377I3O47/EditPlus.rar" target="_blank">EditPlus编辑器</a>
					   </p>            
	                   <p>最后更新：2014.01.23</p>            
	                   <a href="http://chenziwen.ys168.com/note/fd.htm?http://ys-F.ys168.com/2.0/315551941/Tjs5Wjk37461377I3O47/EditPlus.rar" target="_blank" class="down_btn">立即下载</a> 
					 </li>                    
                     
					 <!--左侧下载栏第四列-->	 
	                 <li>
					   <img width="36" height="36" src="<?php echo TEMPLATE_URL; ?>images/4.gif">
	                   <p class="pro-name">
					      <a href="http://soft.hao123.com/index.php?ct=stat&ac=aladdin&bd=1&id=883" target="_blank">火狐浏览器</a>
					   </p>            
	                   <p>最后更新：2014.01.23</p>            
	                   <a href="http://soft.hao123.com/index.php?ct=stat&ac=aladdin&bd=1&id=883" target="_blank" class="down_btn">立即下载</a> 
					 </li>                    
                   </ul>        
	               <div class="zj">
				        <a href="http://soft.hao123.com/index.php?ct=stat&ac=aladdin&bd=1&id=883" target="_blank">&gt;&gt; 更多软件下载..</a>
				   </div>      
	      </div>

