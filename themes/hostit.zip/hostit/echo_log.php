<?php 
/*
* 日志页
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
           
		   <div id="wrapper">    
	            <div class="content fl">      
	                 <div class="current_nav"> 
	                      <strong>首页-正文-<?php blog_sort($logid); ?>&nbsp;&nbsp;浏览(<?php echo $views; ?>)&nbsp;&nbsp;吐槽(<?php echo $comnum; ?>)</strong> 
					 </div>      
	                 <div class="post_title">        
	                      <h1><?php topflg($top); ?><?php echo $log_title; ?></h1> 
	                      <span class="pt_info pre1">发表日期：<span><?php echo gmdate('Y-n-j G:i', $date); ?>&nbsp;&nbsp;作者：<?php blog_author($author); ?></span>
                     </div>      
                     <div id="paragraph" class="post_content">                        
                          <?php echo $log_content; ?>
	                 </div>                  
					 <div class="hot_tags"> 
					      <span>本文标签：<?php blog_tag($logid); ?></span>
		             </div>       
	                 <div class="rela-post">
					      <div id="hm_t_11511"></div>
					 </div>       
	                 <div id="commentDiv">
	                      <div class="current_nav"></div>
	                      <?php doAction('log_related', $logData); ?><br/>
	                      <?php neighbor_log($neighborLog); ?>         
						  <?php blog_comments($comments); ?>
	                      <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>

                     </div>    
                </div>    
                <?php
                   include View::getView('side');
                ?>   	 
           </div>
      </div><!--con End-->
      <?php
         include View::getView('footer');
      ?>