<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!-- end #contentx -->
</div><!-- end #body -->
<footer id="footer" role="contentinfo">
	<?php echo $footer_info; ?>
</footer><!-- end #footer -->
<p id="back-to-top"><a href="javascript:;"><span class="glyphicon glyphicon-circle-arrow-up"></span></a></p>
<?php doAction('index_footer'); ?>
</body>
</html>