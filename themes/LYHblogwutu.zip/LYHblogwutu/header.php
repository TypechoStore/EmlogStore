<?php
/*
Template Name:LYHblog无图版
Description:LYH模板，简洁优雅 作者QQ：2254872142……
Version:1.2
Author:caihongjia.net
Author Url:http://www.caihongjia.net
Sidebar Amount:1
ForEmlog:5.1.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="warp">
	<div id="head">
		<h1 id="logo"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
		<div id="head_r">
			<div id="top">
				<ul>
					<li id="sw"><a href=""onclick="this.style.behavior='url(#default#homepage)';this.setHomePage('<?php echo BLOG_URL; ?>');">设为主页</a></li>
					<li id="sc"><a href="javascript:window.external.AddFavorite('<?php echo BLOG_URL; ?>','<?php echo $blogname; ?>')">收藏本站</a></li>
					<li id="rss"><a href="<?php echo BLOG_URL; ?>rss.php" target="_blank">RSS</a></li>
					<li id="tg"><a href="http://www.caihongjia.net/"><span>彩虹之家</span></a></li>
				</ul>
			</div>
			<div class="cle"></div>
			<div id="search">
			<div id="ss">
				<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
				<input name="keyword" type="text" class="text" id="search-keyword"  value="站内搜索" onblur="if(this.value=='') this.value='站内搜索';" onfocus="if(this.value=='站内搜索') this.value='';" />
				<button type="submit" class="btn">搜索</button>
				</form>
			</div>
			</div>
		</div>	
	</div>
	<div id="nav">
	<?php blog_navi();?>
	</div>

  