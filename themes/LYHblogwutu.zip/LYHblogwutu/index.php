<?php 
/*
* 首页部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="pleft mt1">
	<div class="p_video">
		<?php top_list(9,5);?>
	</div>
	<div class="tbox i_tbox mt1">
		<?php new_logs();?>
		<?php top_logs();?>
	</div>
	<div class="word_yy mt1" style="border:none;">
		<?php index_list(1,9);?>
		<?php index_list(2,9);?>
		<?php index_list(3,9);?>
		<?php index_list(4,9);?>
	</div>
</div>