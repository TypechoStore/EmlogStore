<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="site-container" class="clearfix">
<!-- #primary -->
<section id="primary" class="sidebar-off clearfix">
<!-- #content -->
<div id="content" role="main">
<ul id="timeline" class="ajax-posts clearfix">
    <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?> 
   <li class="ajax-post animated fadeInUp">
   <article id="post-2014" class="post-2014 post type-post status-publish format-aside hentry category-zhutigengxin post_format-post-format-aside clearfix">
   <span class="entry-date"><i class="fa fa-hashtag" style="color:black;"></i> &nbsp;<span class="entry-meta-date"><time datetime=""><?php echo $val['date'];?> </time></span></span>
   <div class="hentry-box">
   <div class="entry-wrap">
	<div class="entry-summary clearfix">
	<p><?php echo $val['t'].'<br/>'.$img;?></p>
	<div style="text-align: center;padding-right:10px; ">
    </div>
     <div class="more-posts"><a href="<?php echo $value['log_url']; ?>" title="更多">···</a> </div>
     <div class="content-footer">
          </div>
</div>
</div>
</div> 
<footer class="entry-footer">
</footer>
 </article>
 </li>
    <?php if ($istreply == 'y'):?>
    <div class="huifu" id="rp_<?php echo $tid;?>">
	<textarea id="rtext_<?php echo $tid; ?>"></textarea>
    <div class="tbutton">
        <div class="tinfo" style="display:<?php if(ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER){echo 'none';}?>">
        昵称：<input type="text" id="rname_<?php echo $tid; ?>" value="" />
        <span style="display:<?php if($reply_code == 'n'){echo 'none';}?>">验证码：<input type="text" id="rcode_<?php echo $tid; ?>" value="" /><?php echo $rcode; ?></span>        
        </div>
        <input class="button_p" type="button" onclick="reply('<?php echo DYNAMIC_BLOGURL; ?>index.php?action=reply',<?php echo $tid;?>);" value="回复" /> 
        <div class="msg"><span id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></span></div>
    </div>
    </div>
    <?php endif;?>
    </li>
    <?php endforeach;?>
	<nav role="navigation" id="nav-below" class="site-navigation paging-navigation clearfix">
<?php echo time_page($lognum,$index_lognum,$page,$pageurl);?>     
</nav>
</div>
</section>
</div>
<?php
 include View::getView('footer');
?>