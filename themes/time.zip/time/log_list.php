<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="site-container" class="clearfix">
<!-- #primary -->
<section id="primary" class="sidebar-off clearfix">
<!-- #content -->
<div id="content" role="main">
<ul id="timeline" class="ajax-posts clearfix">
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
<?php
    //去除文章摘要的“阅读全文”
    $value['log_description'] = strip_tags($value['log_description']);
    $value['log_description'] = str_replace('阅读全文&gt;&gt;','',$value['log_description']);
    //去除默认分页的首页和尾页
    $page_url = str_replace('&laquo;','首页',$page_url);
    $page_url = str_replace('&raquo;','尾页',$page_url);
 ?>
	<li class="ajax-post animated fadeInUp">
		<article id="post-2014" class="post-2014 post type-post status-publish format-aside hentry category-zhutigengxin post_format-post-format-aside clearfix">
 
<span class="entry-date"><i class="fa fa-pencil" style="color:black;"></i> &nbsp;<span class="entry-meta-date"><time datetime=""><?php echo gmdate('Y-n-j', $value['date']); ?></time></span></span>
<div class="hentry-box">
<div class="entry-wrap">

<div class="entry-header">
	<h2 class="entry-title"><a href="<?php echo $value['log_url']; ?>" rel="bookmark"><?php echo subString(strip_tags($value['title']),0,13);?></a></h2>
</div>
<div class="entry-summary clearfix">
	<p><?php echo $value['log_description']; ?><a href="<?php echo $value['log_url']; ?>">…</a></p>
<div style="text-align: center;padding-right:10px; ">
    </div>
     <div class="more-posts"><a href="<?php echo $value['log_url']; ?>" title="更多">···</a> </div>
     <div class="content-footer">
          </div>
</div>
</div>
</div> 
<footer class="entry-footer">
</footer>
 </article>
 </li>
<?php 
endforeach;
else:
?>
	<div class="hentry-box">
<p style="text-align: center;">你找到的东西不存在哟！</p>
</div>
<?php endif;?>
</ul>
<nav role="navigation" id="nav-below" class="site-navigation paging-navigation clearfix">
<?php echo time_page($lognum,$index_lognum,$page,$pageurl);?>     
</nav>
<!-- #nav-below -->
</div>
<!-- /#content -->
</section>
<!-- /#primary -->
</div> 
<?php
 include View::getView('footer');
?>