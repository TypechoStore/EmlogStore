<?php
/*
Template Name:time
Description:当前模板需配合模板设置<a href="http://www.emlog.net/plugin/144" title="点击前往下载" target="_blank">插件</a>使
Version:1.1
Author:WRZ
Author Url:http://whdhr.com
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="viewport" content="width=device-width">
<link rel="shortcut icon" href="">
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="<?php echo TEMPLATE_URL; ?>images/favicon.ico">
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<!-- css -->
<link rel="stylesheet" id="da-fontawesome-css" href="//cdn.bootcss.com/font-awesome/4.5.0/css/font-awesome.min.css?ver=6.0.5" type="text/css" media="all">
<link rel="stylesheet" type="text/css" media="all" href="<?php echo TEMPLATE_URL; ?>style.css">
<link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>css/comment.css">
<link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>css/tip.css">
<!-- js -->
<script src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/time.js" type="text/javascript"></script>
<?php if(_g('xiaxue')=="open"): ?>
<script>var BLOG_URL="<?=BLOG_URL;?>";</script>
<script src="<?php echo TEMPLATE_URL; ?>js/snowflake.js" type="text/javascript"></script>
<?php endif;?>
<script>
		createSnow('', 200);
</script>
</head>
<body>
<!-- 手机端左侧菜单 -->

<!-- 头部 -->
<header>
<nav class="central"><a class="m-navbar" href="javascript:;" onclick="javascript:OpenSideNav(event);"><i class="fa fa-bars"></i></a><a class="tu" href="<?php echo BLOG_URL; ?>"></a><ul id="nav" class="menu"><?php blog_navi();?></a></ul>
<ul class="rightli">
<li><a href="javascript:" onclick="javascript:doSearch(document.keyform);"><i class="fa fa-search"></i>搜索</a><form class="search-form" name="keyform" method="get" action="http://whdhr.com/index.php"><input placeholder="搜搜更健康..." name="keyword" class="search-input" onclick="javascript:stopProp(event);" type="text"></form></li>
<div id="fenlei"><li><a class="btn-arrow btn-headermenu" href="javascript:;"><?php topsorts();?></div>
</ul><a class="m-navbar-right" href="javascript:;" onclick="javascript:OpenSideNavRight(event);"><i class="fa fa-ellipsis-v"></i>
</a></nav>
</header>