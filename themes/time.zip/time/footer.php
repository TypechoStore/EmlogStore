<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!-- #site-footer -->
<footer id="site-footer" class="clearfix">
<?php if("http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] == BLOG_URL):?>
<div class="index_link"><ul>
<?php {global $CACHE;$link_cache = $CACHE->readCache('link');?>
<?php foreach($link_cache as $value): ?>
<a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a>&nbsp
<?php endforeach; ?>
<?php }?>
</a></ul></div>
<?php endif;?>
<div id="footer-bottom" class="clearfix">
<div class="container">
<small id="copyright" role="contentinfo"><center>2016-2017 WRZ·博客 <a href="http://www.miitbeian.gov.cn/" style="color:#999"><?php echo $icp; ?></a></center> </small>
  
 </div>
 </div> 
  <?php doAction('index_footer'); ?>
</footer>
<script>
$(".open2").on("click", function() {
$(".tijiao").slideDown(300), $(".blackground").fadeIn(100)
}); 
$(".close2 a").click(function() {
$(".tijiao").slideUp(300), $(".blackground").fadeOut(100)
});
 $(".smile").click(function() {
$(".smilebg").slideUp(200)
});
</script>
<script src="<?php echo TEMPLATE_URL; ?>js/bootstrap.min.js" type="text/javascript"></script>
</body>
</html>
<?php
if(_g('compress_html')=='open'){
        $html=ob_get_contents();
        ob_get_clean();
        echo em_compress_html_main($html);
}
?>