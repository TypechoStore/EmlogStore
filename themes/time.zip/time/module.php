<?php 
/**
 * 侧边栏组件、页面模块
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="bloggerinfo">
	<div id="bloggerinfoimg">
	<?php if (!empty($user_cache[1]['photo']['src'])): ?>
	<img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="<?php echo $user_cache[1]['photo']['width']; ?>" height="<?php echo $user_cache[1]['photo']['height']; ?>" alt="blogger" />
	<?php endif;?>
	</div>
	<p><b><?php echo $name; ?></b>
	<?php echo $user_cache[1]['des']; ?></p>
	</ul>
	</li>
<?php }?>
<?php
//widget：日历
function widget_calendar($title){ ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<div id="calendar">
	</div>
	<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
	</li>
<?php }?>
<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="blogtags">
	<?php foreach($tag_cache as $value): ?>
		<span style="font-size:<?php echo $value['fontsize']; ?>pt; line-height:30px;">
		<a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇文章"><?php echo $value['tagname']; ?></a></span>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="blogsort">
	<?php
	foreach($sort_cache as $value):
		if ($value['pid'] != 0) continue;
	?>
	<li>
	<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
	<?php if (!empty($value['children'])): ?>
		<ul>
		<?php
		$children = $value['children'];
		foreach ($children as $key):
			$value = $sort_cache[$key];
		?>
		<li>
			<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
		</li>
		<?php endforeach; ?>
		</ul>
	<?php endif; ?>
	</li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：最新微语
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="twitter">
	<?php foreach($newtws_cache as $value): ?>
	<?php $img = empty($value['img']) ? "" : '<a title="查看图片" class="t_img" href="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" target="_blank">&nbsp;</a>';?>
	<li><?php echo $value['t']; ?><?php echo $img;?><p><?php echo smartDate($value['date']); ?></p></li>
	<?php endforeach; ?>
    <?php if ($istwitter == 'y') :?>
	<p><a href="<?php echo BLOG_URL . 't/'; ?>">更多&raquo;</a></p>
	<?php endif;?>
	</ul>
	</li>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="newcomment">
	<?php
	foreach($com_cache as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	?>
	<li id="comment"><?php echo $value['name']; ?>
	<br /><a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：最新文章
function widget_newlog($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="newlog">
	<?php foreach($newLogs_cache as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：热门文章
function widget_hotlog($title){
	$index_hotlognum = Option::get('index_hotlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getHotLog($index_hotlognum);?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="hotlog">
	<?php foreach($randLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：随机文章
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="randlog">
	<?php foreach($randLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="logsearch">
	<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
	<input name="keyword" class="search" type="text" />
	</form>
	</ul>
	</li>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="record">
	<?php foreach($record_cache as $value): ?>
	<li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul>
	<?php echo $content; ?>
	</ul>
	</li>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
    //if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="link">
	<?php foreach($link_cache as $value): ?>
	<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?> 
<?php //导航
function blog_navi(){
    global $CACHE;
    $navi_cache = $CACHE->readCache('navi');
    foreach ($navi_cache as $value) {
        if ($value['pid'] != 0) {
            continue; }
        if ($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)) {
            continue;}
        $newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
        $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'current-' : '';?>
<li class="<?php echo $current_tab;?>menu-item
"><a href="<?php echo $value['url']; ?>
" <?php echo $newtab;?>
><?php if ($value['naviname'] == '首页') { ?>
<i class="fa fa-home"></i><?php 
} elseif ($value['naviname'] == '微语') { ?>
<i class="fa fa-twitter"></i><?php 
        } elseif ($value['naviname'] == '相册') {?>
<i class="fa fa-camera"></i><?php 
        } elseif ($value['naviname'] == '归档') {?>
<i class="fa fa-list"></i><?php 
        } elseif ($value['naviname'] == '留言' || $value['naviname'] == '留言板') { ?>
<i class="fa fa fa-comments"></i><?php 
        } elseif ($value['naviname'] == '邻居' || $value['naviname'] == '友链') {?>
 <i class="fa fa fa-link"></i> <?php 
        } elseif ($value['naviname'] == '作品') {?>
 <i class="fa fa-hdd-o"></i><?php 
        } elseif ($value['naviname'] == '登录') {?>
 <i class="fa fa-user"></i><?php 
        } elseif ($value['naviname'] == '投稿') { ?>
<i class="fa fa-share-alt"></i><?php 
        } elseif ($value['naviname'] == '手机版') { ?>
 <i class="fa fa-mobile"></i><?php 
        } elseif ($value['naviname'] == '登陆') { ?>
 <i class="fa fa-cog"></i>  <?php 
        } elseif ($value['naviname'] == '关于') {?>
<i class="fa fa-info-circle"></i><?php 
        } elseif ($value['naviname'] == '直播') {?>
<i class="fa fa-play"></i><?php 
        } else {?>
 <i class="fa fa-book"></i><?php 
        }?>
 <?php echo $value['naviname'];?>
</a><?php  if (!empty($value['children'])) { ?>
<ul class="sub-menu"> 
<?php  foreach ($value['children'] as $row) { echo '<li class="navto"><a href="' . Url::sort($row['sid']) . '">' . $row['sortname'] . '</a></li>';}?>
</ul><?php  }if (!empty($value['childnavi'])) { ?>
<ul class="sub-menu"><?php 
            foreach ($value['childnavi'] as $row) {
                $newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';
                echo '<li class="navto"><a href="' . $row['url'] . '" >' . $row['naviname'] . '</a></li>'; } ?>
</ul><?php } ?>
</li><?php }?>
<?php if (ROLE == 'admin' || ROLE == 'writer') {?>
<li class="navto-theme">
<a href="<?php echo BLOG_URL;?>?user&posts"><i class="fa fa-cog"></i> 会员中心 <i class="fa fa-angle-down"></i></a>
<ul class="sub-menu">
<li class="navto-d7"><a href="<?php echo BLOG_URL;?>?user&posts">个人首页</a></li>
<li class="navto-d7"><a href="<?php echo BLOG_URL; ?>?user&info">个人资料</a></li>
<li class="navto-d7"><a href="<?php echo BLOG_URL;?>admin/?action=logout">退出登陆</a></li></ul></li>
<?php }}?>
<?php
//blog：置顶
function topflg($top, $sortop='n', $sortid=null){
    if(blog_tool_ishome()) {
       echo $top == 'y' ? "<img src=\"".TEMPLATE_URL."/images/top.png\" title=\"首页置顶文章\" /> " : '';
    } elseif($sortid){
       echo $sortop == 'y' ? "<img src=\"".TEMPLATE_URL."/images/sortop.png\" title=\"分类置顶文章\" /> " : '';
    }
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
    <a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
	<?php endif;?>
<?php }?>
<?php
//blog：文章标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '标签:';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "	<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
		}
		echo $tag;
	}
}
?>
<?php
//blog：文章作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
	extract($neighborLog);?>
    <span class="article-nav-prev">
	<?php if($prevLog):?>
    <a>【上一篇】</a><br>
	<a href="<?php echo Url::log($prevLog['gid']) ?>" title="<?php echo $prevLog['title'];?>"><?php echo $prevLog['title'];?></a>
    <?php else: ?>
    <a>【上一篇】</a><br>
    <a title="没错这就是本分类第一篇文章">这就是第一篇了</a>
	<?php endif;?></span>
    <span class="article-nav-next">
	<?php if($nextLog):?>
    <a>【下一篇】</a><br>
	<a href="<?php echo Url::log($nextLog['gid']) ?>" title="<?php echo $nextLog['title'];?>"><?php echo $nextLog['title'];?></a>
    <?php else: ?>
    <a>【下一篇】</a><br>
    <a title="没错这就是本分类最后一篇文章">这就是最后一篇了</a>
	<?php endif;?></span>
    
<?php }?>
<?php
//blog：评论列表
function blog_comments($comments){
    extract($comments);
    if($commentStacks): ?>
	<section class="comments" id="comments">
	<div id="addnewcomment"></div>
	<?php endif; ?>
	<?php
	$isGravatar = Option::get('isgravatar');
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<article class="comment" id="comment-<?php echo $comment['cid']; ?>">
		<?php if($isGravatar == 'y'): ?><a href="" class="comment-img"><img src="<?php echo getGravatar($comment['mail']); ?>" /></a><?php endif; ?>
		<div class="comment-body">
		<div class="text"> 
		<k><a class="name" href="" target="_blank"><?php echo $comment['poster']; ?></a></k>&nbsp;<a title="<?php echo getaddress($comment['ip']);?> " class="os"><i class="fa fa-dot-circle-o"></i></a>&nbsp;<?php echo useragent($comment['useragent']); ?></div>
		 <div class="text1"><p></p><p><?php echo comcontent($comment['content']); ?></p><p></p></div>
		<div class="attribution"><k style="text-align: left;color:#a6a6a6;"><?php echo $comment['date']; ?><k><k style="float: right;">
		<a rel="nofollow" class="comment-reply-link" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a></k></div>
		</div>
		</article>
		<?php blog_comments_children($comments, $comment['children']); ?>

	<?php endforeach; ?>
    <nav role="navigation" id="nav-below" class="site-navigation paging-navigation clearfix">
 <?php echo $commentPageUrl;?>  
</nav>
<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<ul class="children">
	<article class="comment" id="comment-<?php echo $comment['cid']; ?>">
		<?php if($isGravatar == 'y'): ?><a href="" class="comment-img"><img src="<?php echo getGravatar($comment['mail']); ?>" /></a><?php endif; ?>
		<div class="comment-body">
		<div class="text">
		<k><a class="name" href="" target="_blank"><?php echo $comment['poster']; ?></a>
       </k>&nbsp;<a title="<?php echo getaddress($comment['ip']);?> " class="os"><i class="fa fa-dot-circle-o"></i></a></div><div class="text1"><p></p><p><font style="color:#ff0000;"><?php echo comcontent($comment['content']); ?></font></p><p></p></div>
	   <div class="attribution"><k style="text-align: left;color:#a6a6a6;"><?php echo $comment['date']; ?></k><k style="float: right;">
    
    <?php if($comment['level'] < 4): ?><a rel="nofollow" class="comment-reply-link"><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a></k></div><?php endif; ?>
		</div>
		</article>
	 </ul>
		<?php blog_comments_children($comments, $comment['children']);?>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ;?>
<div id="respond">
	<div class="mem_message lft"  id="comment-place">
      <div class="respond-a" id="comment-post">

    <div class="cancel-reply" id="cancel-reply" style="display:none"><a href="javascript:void(0);" onclick="cancelReply()"><i class="fa fa-share"></i>取消回复</a></div>
    <h5>
      <?php if(empty($ckname)){ echo "你肿么看？";}else if($ckname=='匿名'){ echo "匿名评论&nbsp;请叫我雷锋~";}else{echo $ckname;echo "欢迎回来...";} ?>
      <a name="respond"></a></h5>

    <form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
      <input type="hidden" name="gid" value="<?php echo $logid; ?>" />
      <?php if(ROLE == 'visitor'): ?>
		
      <?php endif; ?>
      <p class="num1">你还可以输入 <i id="num" class="num">250 </i> / 250 个字</p>
      <p>
        <textarea onkeyup="checkLength(this);" onkeydown="if(event.ctrlKey&&event.keyCode==13){document.getElementById('submit').click();return false};"name="comment" id="comment" class="post-area" rows="10" tabindex="99" placeholder="让评论变得如此简单。"></textarea>
      <div class="smilebg">
        <div class="smile">
          <div class="arrow"></div>
          <?php include View::getView('smiley');?>
        </div>
      </div>
      <div class="sbsb">
        <div title="插入表情" onclick="embedSmiley()" class="face"><i class="fa fa-smile-o"></i></div>
		<div title="插入粗体文字" onclick="strong()" class="zujian"><i class="fa fa-bold"></i></div>
		<div title="插入斜体文字" onclick="em()" class="zujian"><i class="fa fa-italic"></i></div>
		<div title="插入删除线文字" onclick="del()" class="zujian"><i class="fa fa-strikethrough"></i></div>
		<div title="插入下划线文字" onclick="underline()" class="zujian"><i class="fa fa-text-width"></i></div>
        <div title="插入图片" onclick="embedImage()" class="zujian"><i class="fa fa-image"></i></div>
        <div title="插入链接" onclick="url1()" class="zujian"><i class="fa fa-link"></i></div>
        <div title="签到" onclick="javascript:SIMPALED.Editor.qiandao();this.style.display='none'" class="zujian"><i class="fa fa-pencil"></i></div>
        <div title="赞一个" onclick="javascript:SIMPALED.Editor.good();this.style.display='none'" class="zujian"><i class="fa fa-thumbs-o-up"></i></div>
        <div title="踩一个" onclick="javascript:SIMPALED.Editor.bad();this.style.display='none'" class="zujian"><i class="fa fa-thumbs-o-down"></i></div>
        <?php echo $verifyCode; ?>
        <button class="open2" type="button" id="submit" tabindex="6"><i class="fa fa-check"></i> 提交评论</button>
        <button type="reset"  id="reset" name="reset" tabindex="7"><i class="fa fa-trash-o"></i> 清除</button>
      </div>
      </p>

<div class="tijiao" style="display: none;">
        <p class="close2">评论信息框<a href="javascript:;" title="关闭"></a> <br>
            <?php if(ROLE == 'admin' || ROLE == 'writer'):?>
            账户已登录，可直接发表评论！
            <?php else:?>
          <span><i class="fa fa-question-circle"></i> 你的评论一针见血!</span></p>
        <p>
          <input onkeydown="if(event.keyCode==13){event.returnValue=false;}" class="tex" type="text" id="nickname" name="comname" maxlength="49" value="<?php if(empty($ckname)){ echo "";}else{echo $ckname;} ?>" size="22" tabindex="2" placeholder="必填">
          <label for="author"><i class="fa fa-user"></i> 昵称:</label>
        </p>
        <p>
          <input onkeydown="if(event.keyCode==13){event.returnValue=false;}" class="tex" type="email" name="commail" id="email" maxlength="128" value="<?php echo $ckmail; ?>" size="22" tabindex="3" placeholder="选填">
          <label id="email" for="email"><img src="<?php echo TEMPLATE_URL; ?>images/avatar.jpeg" class="emailavatar" style="display: none;"><i class="fa fa-envelope-square"></i> 邮箱:</label>
        </p>
        <p>
          <input onkeydown="if(event.keyCode==13){event.returnValue=false;}" class="tex" type="text" id="comurl" name="comurl" maxlength="128" value="<?php echo $ckurl; ?>" size="22" tabindex="4" placeholder="选填" pattern="((http|https)://|)+([\w-]+\.)+[\w-]+(/[\w- ./?%&amp;=]*)?">
          <label for="url"><i class="fa fa-globe"></i> 网址:</label>
        </p><?php endif;?>
            <p>
        </p><div class="ajaxloading">吃奶的力气提交吐槽中...</div>
        <div class="error"></div>
        <p></p>
        <p>
          <button type="submit" id="usb" tabindex="5">发表评论</button>
        </p>
        <input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1">
      </div>
    </form>
   <div id="thread_list">
    </div>
       </div>
              </div> 
              </div><!-- 评论结束 -->
</div>
<?php endif; ?>
<?php }?>
<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>
<?php
//评论内容
function comcontent($sb){
	$patterns = array(
		"/\[F(([1-4]?[0-9])|50)\]/",
		"/\[img=?\]*(.*?)(\[\/img)?\]/e",
		"/\[blockquote]*(.*?)(\[\/blockquote)?\]/e",
		"/\[strong]*(.*?)(\[\/strong)?\]/e",
		"/\[em]*(.*?)(\[\/em)?\]/e",
		"/\[del]*(.*?)(\[\/del)?\]/e",
		"/\[underline]*(.*?)(\[\/underline)?\]/e",
		"/\[qq]*(.*?)(\[\/qq)?\]/e",
		"/\[url]*(.*?)(\[\/url)?\]/e",
		'/\[pre\]/',
		'/\[\/pre\]/',
		"/\[red\](.*?)\[\/red\]/",
		"/\[green\](.*?)\[\/green\]/",
		"/\[blue\](.*?)\[\/blue\]/",
		"/\[magenta\](.*?)\[\/magenta\]/",
		"/\[yellow\](.*?)\[\/yellow\]/",
		"/\[chocolate\](.*?)\[\/chocolate\]/",
		"/\[black\](.*?)\[\/black\]/",
		"/\[aquamarine\](.*?)\[\/aquamarine\]/",
		"/\[lime\](.*?)\[\/lime\]/",
		"/\[fuchsia\](.*?)\[\/fuchsia\]/",
		"/\[orange\](.*?)\[\/orange\]/",
		"/\[thistle\](.*?)\[\/thistle\]/",
		"/\[brown\](.*?)\[\/brown\]/",
		"/\[peru\](.*?)\[\/peru\]/",
		"/\[deeppink\](.*?)\[\/deeppink\]/",
		"/\[purple\](.*?)\[\/purple\]/",
		"/\[slategray\](.*?)\[\/slategray\]/",
		"/\[tomato\](.*?)\[\/tomato\]/"
	);
	$replace = array(
		'<img class="facer" src="'.TEMPLATE_URL.'images/face/$1.gif" alt="" />',
		'"<img class=\"contimg\" src=\"$1\" alt=\"" . basename("$1") . "\" />"',
		'"<blockquote>$1</blockquote>"',
		'"<strong>$1</strong>"',
		'"<em>$1</em>"',
		'"<del>$1</del>"',
		'"<u>$1</u>"',
		'"<a href=\"http://wpa.qq.com/msgrd?v=3&uin=$1&site=".BLOG_URL."&menu=yes\" target="_blank"><img border=\"0\" src=\"http://wpa.qq.com/pa?p=1:$1:42\" align=\"absmiddle\"></a>"',
		'"<a href=\"$1\" target=\"_blank\">$1</a>"',
		"<pre class=\"prettyprint\">",
		"</pre>",
		'<font color="red">$1</font>',
		'<font color="green">$1</font>',
		'<font color="blue">$1</font>',
		'<font color="magenta">$1</font>',
		'<font color="yellow">$1</font>',
		'<font color="chocolate">$1</font>',
		'<font color="black">$1</font>',
		'<font color="aquamarine">$1</font>',
		'<font color="lime">$1</font>',
		'<font color="fuchsia">$1</font>',
		'<font color="orange">$1</font>',
		'<font color="thistle">$1</font>',
		'<font color="brown">$1</font>',
		'<font color="peru">$1</font>',
		'<font color="deeppink">$1</font>',
		'<font color="purple">$1</font>',
		'<font color="slategray">$1</font>',
		'<font color="tomato">$1</font>'
	);
	$sb=preg_replace($patterns, $replace, $sb);
	return $sb;
}?>

<?php 
//分页函数
function time_page($count,$perlogs,$page,$url,$anchor=''){
$pnums = @ceil($count / $perlogs);
$page = @min($pnums,$page);
$prepg=$page-1;
$nextpg=($page==$pnums ? 0 : $page+1);
$urlHome = preg_replace("|[\?&/][^\./\?&=]*page[=/\-]|","",$url);
$re = "<ul class=\"clearfix\">";
if($pnums<=1) return false;		
if($prepg) $re .=" <li class=\"nav-previous\"><a href=\"$url$prepg$anchor\" ><i class=\"fa fa-chevron-left\"></i></a></li> ";
if($nextpg) $re .=" <li class=\"nav-next\"><a href=\"$url$nextpg$anchor\"><i class=\"fa fa-chevron-right\"></i></a></li> "; 
$re .="</ul>";
return $re;}
?>

<?php 
//压缩
function em_compress_html_main($buffer){
    $initial=strlen($buffer);
    $buffer=explode("<!--em-compress-html-->", $buffer);
    $count=count ($buffer);
    for ($i = 0; $i <= $count; $i++){
        if (stristr($buffer[$i], '<!--em-compress-html no compression-->')){
            $buffer[$i]=(str_replace("<!--em-compress-html no compression-->", " ", $buffer[$i]));
        }else{
            $buffer[$i]=(str_replace("\t", " ", $buffer[$i]));
            $buffer[$i]=(str_replace("\n\n", "\n", $buffer[$i]));
            $buffer[$i]=(str_replace("\n", "", $buffer[$i]));
            $buffer[$i]=(str_replace("\r", "", $buffer[$i]));
            while (stristr($buffer[$i], '  '))
            {
            $buffer[$i]=(str_replace("  ", " ", $buffer[$i]));
            }
        }
        $buffer_out.=$buffer[$i];
    }
    $final=strlen($buffer_out);
    $savings=($initial-$final)/$initial*100;
    $savings=round($savings, 2);
    $buffer_out.="\n<!--压缩前的大小: $initial bytes; 压缩后的大小: $final bytes; 节约：$savings% -->";
    return $buffer_out;
}
?>

<?php 
//不压缩
function unCompress($content){
    if(preg_match_all('/(crayon-|<\/pre>)/i', $content, $matches)) {
        $content = '<!--em-compress-html--><!--em-compress-html no compression-->'.$content;
        $content.= '<!--em-compress-html no compression--><!--em-compress-html-->';
    }
    return $content;
}
?>

<?php
//获取评论用户操作系统、浏览器等信息
function useragent($info){
	require_once 'useragent.class.php';
	$useragent = UserAgentFactory::analyze($info);
?>
<a title="<?php echo $useragent->platform['title']; ?>" class="os"><i class="fa fa fa-desktop"></i></a><span class="pipe">&nbsp;</span>
<a title="<?php echo $useragent->browser['title']; ?>" class="os"><i class="fa fa fa-chrome"></i></a>
<?php
}
?>

<?php
//获取IP地理地址
$data = '254.254.254.254';
class IpLocation {
     var $fp;
     var $firstip;
     var $lastip;
     var $totalip;
         
     function getlong() {
        $result = unpack('Vlong', fread($this->fp, 4));
        return $result['long'];
     }

    function getlong3() {
        $result = unpack('Vlong', fread($this->fp, 3).chr(0));
        return $result['long'];
     }

     function packip($ip) {
        return pack('N', intval(ip2long($ip)));
     }
         
     function getstring($data = "") {
        $char = fread($this->fp, 1);
        while (ord($char) > 0) {
            $data .= $char;
            $char = fread($this->fp, 1);
        }
        return $data;
     }
         
     function getarea() {
        $byte = fread($this->fp, 1);
        switch (ord($byte)) {
            case 0:
               $area = "";
               break;
            case 1:
            case 2:
               fseek($this->fp, $this->getlong3());
               $area = $this->getstring();
               break;
            default: 
               $area = $this->getstring($byte);
               break;
        }
        return $area;
        }
         
     function getlocation($ip) {
        
        if (!$this->fp) return null;
        $location['ip'] = gethostbyname($ip); 
        $ip = $this->packip($location['ip']);
        $l = 0; 
        $u = $this->totalip;
        $findip = $this->lastip;
        while ($l <= $u) { 
            $i = floor(($l + $u) / 2); 
            fseek($this->fp, $this->firstip + $i * 7);
            $beginip = strrev(fread($this->fp, 4));
            if ($ip < $beginip) {
               $u = $i - 1;
            }
            else {
               fseek($this->fp, $this->getlong3());
               $endip = strrev(fread($this->fp, 4));
               if ($ip > $endip) {
                   $l = $i + 1; 
               }
               else {
                   $findip = $this->firstip + $i * 7;
                   break;
               }
            }
        }
        fseek($this->fp, $findip);
        $location['beginip'] = long2ip($this->getlong()); 
        $offset = $this->getlong3();
        fseek($this->fp, $offset);
        $location['endip'] = long2ip($this->getlong());
        $byte = fread($this->fp, 1); 
        switch (ord($byte)) {
            case 1: 
               $countryOffset = $this->getlong3();
               fseek($this->fp, $countryOffset);
               $byte = fread($this->fp, 1);
               switch (ord($byte)) {
                   case 2: 
                      fseek($this->fp, $this->getlong3());
                      $location['country'] = $this->getstring();
                      fseek($this->fp, $countryOffset + 4);
                      $location['area'] = $this->getarea();
                      break;
                   default: 
                      $location['country'] = $this->getstring($byte);
                      $location['area'] = $this->getarea();
                      break;
               }
               break;
            case 2:
               fseek($this->fp, $this->getlong3());
               $location['country'] = $this->getstring();
               fseek($this->fp, $offset + 8);
               $location['area'] = $this->getarea();
               break;
            default: 
               $location['country'] = $this->getstring($byte);
               $location['area'] = $this->getarea();
               break;
        }
        if ($location['country'] == " CZNET") { 
            $location['country'] = "未知";
        }
        if ($location['area'] == " CZNET") {
            $location['area'] = "";
        }
        return $location;
     }
         
     function IpLocation($filename = "./content/templates/time/biu/ip.dat") {
        $this->fp = 0;
        if (($this->fp = @fopen($filename, 'rb')) !== false) {
            $this->firstip = $this->getlong();
            $this->lastip = $this->getlong();
            $this->totalip = ($this->lastip - $this->firstip) / 7;
            register_shutdown_function(array(&$this, '_IpLocation'));
        }
     }
         
     function _IpLocation() {
        if ($this->fp) {
            fclose($this->fp);
        }
        $this->fp = 0;
     }
}
function getaddress($myip){
$ipOrDomain=$myip;
$iplocation = new IpLocation();
$location = $iplocation->getlocation($ipOrDomain);
$address=mb_convert_encoding($location['country'].$location['area'], "utf-8", "gbk");
return $address;
}?>
<?php
//search：标签
function search_tag($title){
    global $CACHE;
    $tag_cache = $CACHE->readCache('tags');?>
        <?php shuffle ($tag_cache);
		$tag_cache = array_slice($tag_cache,0,30);foreach($tag_cache as $value): ?>
			<li class="search-go"><a href="<?php echo BLOG_URL; ?>tag/<?php echo $value['tagname']; ?>"><?php echo $value['tagname']; ?></a></li>
        <?php endforeach; ?>
<?php }?>

<?php 
//三合一
function article_index($content , $domain) {  
            global $CACHE;  
            $tag_cache = $CACHE->readCache('tags');  
            $matches = array();  
            $ul_li = '';  
            $r = "/<h2>([^<]+)<\/h2>/im";  
    if(preg_match_all($r,$content,$matches)) {  
           foreach($matches[1] as $num => $title) {  
           $content = str_replace($matches[0][$num], '<h2 id="title-'.$num.'">'.$title.'</h2>', $content);  
           $ul_li .= '<li><a href="#title-'.$num.'" title="'.$title.'">'.$title."</a></li>\n";  
             }  
 $content = "\n<div id=\"article-index\"> 
 <b>[文章目录]</b> 
 <ul id=\"index-ul\">\n" . $ul_li . "</ul> 
 </div>\n" . $content;  
 }  
 foreach($tag_cache as $value){  
                $tag_url = Url::tag($value['tagurl']);  
                $keyword = $value['tagname'];  
                $cleankeyword = stripslashes($keyword);  
                $url = "<a href=\"{$tag_url}\" title=\"浏览关于“{$cleankeyword}”的文章\" target=\"_blank\" >{$cleankeyword}</a>";  
                $regEx = '\'(?!((<.*?)|(<a.*?)))('. $cleankeyword . ')(?!(([^<>]*?)>)|([^>]*?</a>))\'s';  
                $content = preg_replace($regEx,$url,$content);          
}  
preg_match_all('/href="(.*?)"/', $log_content, $matches);  
    if ($matches) {  
        foreach ($matches[1] as $val) {  
            if (strpos($val, $domain) === false) {  
                $log_content = str_replace('href="' . $val . '"', 'href="' . $val . '" rel="external nofollow" ', $log_content);  
            }  
        }  
    }  
preg_match_all('/src="(.*?)"/', $log_content, $matches);  
    if ($matches) {  
        foreach ($matches[1] as $val) {  
            if (strpos($val, $domain) === false) {  
                $log_content = str_replace('src="' . $val . '"', 'src="' . $val . '" rel="external nofollow" ', $log_content);  
            }  
        }  
    }  
return $content;  
}  
?>

<?php
//文章分类
function topsorts(){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	<?php
	foreach($sort_cache as $value):
		if ($value['pid'] != 0) continue;
	?>
	<li class="menu-item">
	<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?></a>
	</li>
	<?php endforeach; ?>
<?php }?>

<?php
//图片链接
function pic_thumb($content){
    preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $content, $img);
    $imgsrc = !empty($img[1]) ? $img[1][0] : '';
	if($imgsrc):
		return $imgsrc;
	endif;
}
//获取附件第一张图片
function getThumbnail($blogid){
    $db = MySql::getInstance();
    $sql = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$blogid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";
    //die($sql);
    $imgs = $db->query($sql);
    $img_path = "";
	if(mysql_num_rows($imgs)){
		while($row = $db->fetch_array($imgs)){
			 $img_path .= BLOG_URL.substr($row['filepath'],3,strlen($row['filepath']));
		}
	}else{
		$img_path = false;
	}
    return $img_path;
}
//格式化内容工具
function blog_tool_purecontent($content, $strlen = null){
        $content = str_replace('继续阅读&gt;&gt;', '', strip_tags($content));
        if ($strlen) {
            $content = subString(preg_replace("/\[gsvideo url=(.*) w=(.*) h=(.*)\]/", '', $content), 0, $strlen);
        }
        return $content;
}
?>