<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="site-container" class="clearfix">
<section id="primary" class="clearfix">
<div id="content" class="single">
<article id="post-2014" class="post-2014 post type-post status-publish format-aside hentry category-zhutigengxin post_format-post-format-aside clearfix">
<div class="hentry-box">
<div class="entry-wrap">

<div class="entry-header">
	<h1 class="entry-title"><?php echo $log_title; ?></h1>
    <div class="entry-meta"><i class="fa fa-clock-o"></i> <?php echo gmdate('Y-n-j', $date); ?>&nbsp;&nbsp;/&nbsp;&nbsp;评论(<?php echo $comnum; ?>)&nbsp;&nbsp;/&nbsp;&nbsp;阅读（<?php echo $views; ?>）</div>
	<div class="cutline"></div>
</div>
<div class="entry-content clearfix">
<?php echo unCompress(article_index($log_content,$domain)); ?>
<div class="cutline"><span><?php doAction('ja_related', $logData); ?></span></div>
</br>
<div style="text-align: center;">
 </div>
</div>
</div>
</div>
</article>
<article id="xianglin">
<nav class="article-nav"> 
<?php neighbor_log($neighborLog) ?>
</nav>
</article>
			<article class="panel log_list panel-sort">
				<ul class="related-posts row">
				<?php
					$Log_Model = new Log_Model();
					$randlogs = $Log_Model->getLogsForHome("AND sortid = {$sortid} ORDER BY rand() DESC,date DESC", 1,3);
					foreach($randlogs as $value):
					if(pic_thumb($value['content'])){
                        $imgsrc = pic_thumb($value['content']);
	                }elseif(getThumbnail($value['logid'])){
	                    $imgsrc = getThumbnail($value['logid']);
	                }else{
	                    $imgsrc = TEMPLATE_URL.'images/random/'.substr($value['logid'],-1).'.jpg';
	                }
				?>
					<li class="col-sm-4">
						<div class="panel transparent related-posts-panel">
							<a href="<?php echo $value['log_url']; ?>" class="thumbnail-link" rel="bookmark" title="<?php echo $value['log_title']; ?>">
								<img src="<?php echo $imgsrc; ?>" class="thumbnailimg" width="175" height="80" title="<?php echo $value['log_title']; ?>" alt="<?php echo $value['log_title']; ?>">
								<div class="excerpt"><?php echo blog_tool_purecontent($value['content'], 92); ?></div>
							</a>
						<div class="bottom-box">
							<h4 class="post-title"><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" rel="bookmark"><?php echo $value['log_title']; ?></a></h4>
							<ul class="post-meta">
							<li class="author">
							<span class="fa fa-github"></span>
							<?php blog_author($author); ?>
							</li>
							<li class="date date-abb">
							<span class="fa fa-clock-o"></span>
							<a href="<?php echo $value['log_url']; ?>" title="发布于<?php echo gmdate('Y-n-j', $value['date']); ?>">
								<time><?php echo gmdate('Y-n-j', $value['date']); ?></time>
							</a>
							</li>
							</ul>
						</div>
						</div>
					</li>
					<?php endforeach; ?>
				</ul>
			</article>
<!-- 相关结束 -->				
<style type="text/css">
div#author_info {position: absolute;z-index: 99;right: 8px;top: -24px;}
div#author_info input{width: 140px;}
.cutline {
    margin: 20px 0 0 0;
    width: 100%;
    height: 1px;
    border-top: 1px #ccc dotted;
    text-align: center;
}
.cutline span {
    position: relative;
    top: -10px;
    padding: 8px 15px;
    border: 1px solid #d6d6d6;
    background-color: #f7f7f9;
    color: #d14;
    font: 12px Arial,Microsoft JhengHei;
}
</style>

	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<?php blog_comments($comments); ?>
</div></div>

<?php
 include View::getView('footer');
?>