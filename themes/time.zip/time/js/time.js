 /** 双击 **/
function b2top(a, b, c) {
	if (10 >= b && 0 <= b) {
		var d = 100 * b;
		$(a).css({
			backgroundPosition: "0 -" + d + "px"
		});
		setTimeout("b2top('" + a + "'," + (c ? b + 1 : b - 1) + "," + c + ")", 50)
	}
}
$(document).ready(function(a) {
	a(function() {
		a("body").dblclick(function() {
			var b = a(window),
				c = b.scrollTop(),
				d = (c - 0) / 5,
				f = c,
				h = setInterval(function() {
					0 >= (f - 0) * (c - 0) ? (clearInterval(h), c = f = 0, b.scrollTop(0)) : (f = c, b.scrollTop(c -= d))
				}, 20),
				e = a("#top").children(":first");
			e.stop().show().animate({}, function() {
				a(this).css({})
			});
			e.parent().append(e)
		});
		a("#top").dblclick(function(a) {
			a.stopPropagation()
		})
	})
});

/** ToolTip.js **/
$(function() {
	$('a').not('.close_login_box').each(function(b) {
		if (this.title) {
			var c = this.title;
			var a = 30;
			$(this).mouseover(function(d) {
				this.title = "";
				$("body").append('<div id="tooltip">' + c + "</div>");
				$("#tooltip").css({
					left: (d.pageX + a) + "px",
					top: d.pageY + "px",
					opacity: "0.8"
				}).show(250)
			}).mouseout(function() {
				this.title = c;
				$("#tooltip").remove()
			}).mousemove(function(d) {
				$("#tooltip").css({
					left: (d.pageX + a) + "px",
					top: d.pageY + "px"
				})
			})
		}
	})
});


/*评论框*/
function checkLength(e) {
	return 250 < e.value.length ? (wenkmTips.show("您填写的评论内容已经超出250个字！"), e.value = e.value.substring(0, 250), !1) : (e = 250 - e.value.length, document.getElementById("num").innerHTML = e.toString(), !0)
}
function embedImage() {
	var e = prompt("请输入图片的 URL 地址（包含http://）:", "http://");
	e && (document.getElementById("comment").value = document.getElementById("comment").value + "[img]" + e + "[/img]")
}
function strong() {
	var e = prompt("请输入需要加粗的文字:");
	e && (document.getElementById("comment").value = document.getElementById("comment").value + "[strong]" + e + "[/strong]")
}
function em() {
	var e = prompt("请输入需要斜体的文字:");
	e && (document.getElementById("comment").value = document.getElementById("comment").value + "[em]" + e + "[/em]")
}
function del() {
	var e = prompt("请输入需要删除线的文字:");
	e && (document.getElementById("comment").value = document.getElementById("comment").value + "[del]" + e + "[/del]")
}
function url1() {
	var e = prompt("请输入链接的 URL 地址（包含http://）:", "http://");
	e && (document.getElementById("comment").value = document.getElementById("comment").value + "[url]" + e + "[/url]")
}
function underline() {
	var e = prompt("请输入需要下划线的文字:");
	e && (document.getElementById("comment").value = document.getElementById("comment").value + "[u]" + e + "[/u]")
}
function code() {
	var e = prompt("请粘贴代码:");
	e && (document.getElementById("comment").value = document.getElementById("comment").value + "[code]" + e + "[/code]")
}
function quote() {
	var e = prompt("请粘贴引用内容:");
	e && (document.getElementById("comment").value = document.getElementById("comment").value + "[blockquote]" + e + "[/blockquote]")
}
function qq() {
	var e = prompt("请输入QQ号:");
	e && (document.getElementById("comment").value = document.getElementById("comment").value + "[qq]" + e + "[/qq]")
}
function embedSmiley() {
	"none" == $(".smilebg").css("display") ? $(".smilebg").slideDown(200) : $(".smilebg").slideUp(200)
}
function checkLength(e) {
	return 250 < e.value.length ? (wenkmTips.show("您填写的评论内容已经超出250个字！"), e.value = e.value.substring(0, 250), !1) : (e = 250 - e.value.length, document.getElementById("num").innerHTML = e.toString(), !0)
}
function showreply() {
	$(".form").slideToggle(500, "easeOutExpo")
}
function commentReply(e, t) {
	var n = document.getElementById("comment-post");
	t.style.display = "none", document.getElementById("cancel-reply").style.display = "", document.getElementById("comment-pid").value = e, t.parentNode.parentNode.appendChild(n)
}
function cancelReply() {
	var e = document.getElementById("comment-place"),
		t = document.getElementById("comment-post");
	document.getElementById("comment-pid").value = 0, $(".reply a").css({
		display: ""
	}), document.getElementById("cancel-reply").style.display = "none", e.appendChild(t)
}
function grin(e) {
	var t;
	if (e = " " + e + " ", !document.getElementById("comment") || "textarea" != document.getElementById("comment").type) return !1;
	if (t = document.getElementById("comment"), document.selection) t.focus(), sel = document.selection.createRange(), sel.text = e, t.focus();
	else if (t.selectionStart || "0" == t.selectionStart) {
		var n = t.selectionEnd,
			a = n;
		t.value = t.value.substring(0, t.selectionStart) + e + t.value.substring(n, t.value.length), a += e.length, t.focus(), t.selectionStart = a, t.selectionEnd = a
	} else t.value += e, t.focus()
}

$(".open2").on("click", function() {
$(".tijiao").slideDown(300), $(".blackground").fadeIn(100)
}); 
$(".close2 a").click(function() {
$(".tijiao").slideUp(300), $(".blackground").fadeOut(100)
});
 $(".smile").click(function() {
$(".smilebg").slideUp(200)
});
$("#commentform").submit(function() {
	var e = $("#commentform").serialize();
	return $("#comment").attr("disabled", "disabled"), $(".ajaxloading").show(), $("#usb,.nop").hide(), $.post($("#commentform").attr("action"), e, function(e) {
		$(".blackground").fadeOut(100);
		var t = /<div class=\"main\">[\r\n]*<p>(.*?)<\/p>/i;
		t.test(e) ? ($(".error").html(e.match(t)[1]).show().fadeOut(2500), $(".ajaxloading").hide(), $("#usb,.nop").show()) : (t = $("input[name=pid]").val(), cancelReply(), $("[name=comment]").val(""), $(".commentlist").html($(e).find(".commentlist").html()), 0 != t ? (e = window.opera ? "CSS1Compat" == document.compatMode ? $("html") : $("body") : $("html,body")).animate({
			scrollTop: $("#comment-" + t).offset().top - 20
		}, "normal", function() {
			$(".ajaxloading").hide(), $("#usb").show(), $(".tijiao").slideUp(300)
		}) : (e = window.opera ? "CSS1Compat" == document.compatMode ? $("html") : $("body") : $("html,body")).animate({
			scrollTop: $(".commentlist").offset().top - 20
		}, "normal", function() {
			$(".ajaxloading").hide(), $("#usb").show(), $(".tijiao").slideUp(300)
		})), $("a[href*=#comment]").click(function() {
			if (location.pathname.replace(/^\//, "") == this.pathname.replace(/^\//, "") && location.hostname == this.hostname) {
				var e = $(this.hash);
				if ((e = e.length && e || $("[name=" + this.hash.slice(1) + "]")).length) return e = e.offset().top, $("html,body").animate({
					scrollTop: e
				}), !1
			}
		}), $("#comment").attr("disabled", !1)
	}), !1
}),
jQuery(function() {
	function e(e, t, n) {
		if (document.selection) e.focus(), sel = document.selection.createRange(), sel.text = n ? t + sel.text + n : t, e.focus();
		else if (e.selectionStart || "0" == e.selectionStart) {
			var a = e.selectionStart,
				o = e.selectionEnd,
				i = o;
			e.value = n ? e.value.substring(0, a) + t + e.value.substring(a, o) + n + e.value.substring(o, e.value.length) : e.value.substring(0, a) + t + e.value.substring(o, e.value.length), i += n ? t.length + n.length : t.length - o + a, a == o && n && (i -= n.length), e.focus(), e.selectionStart = i, e.selectionEnd = i
		} else e.value += t + n, e.focus()
	}
	var t = (new Date).toLocaleTimeString(),
		n = document.getElementById("comment") || 0;
	window.SIMPALED = {}, window.SIMPALED.Editor = {
		qiandao: function() {
			e(n, "签到成功！签到时间：" + t, "，每日打卡，生活更精彩哦~")
		},
		good: function() {
			e(n, "[F1] 好羞射，文章真的好赞啊，顶博主！")
		},
		bad: function() {
			e(n, "[F14] 有点看不懂哦，希望下次写的简单易懂一点！")
		}
	}
}),
/* theme(mnavbar+flexslider+click+scrollLoading) */
$(document).click(function(event) {
	if ($('.m-navbar').hasClass('m-navbar-show')) {
		$('.m-navbar').removeClass('m-navbar-show');
		$('#nav').css({
			left: "-100%"
		})
	}
	if ($('.m-navbar-right').hasClass('m-navbar-right-show')) {
		$('.m-navbar-right').removeClass('m-navbar-right-show');
		$('.rightli').css({
			right: "-100%"
		})
	}
});

function OpenSideNav(event) {
	if ($('.m-navbar-right').hasClass('m-navbar-right-show')) {
		$('.m-navbar-right').removeClass('m-navbar-right-show');
		$('.rightli').css({
			right: "-100%"
		})
	}
	event.stopPropagation();
	if ($('.m-navbar').hasClass('m-navbar-show')) {
		$('.m-navbar').removeClass('m-navbar-show');
		$('#nav').css({
			left: "-100%"
		});
		return
	}
	$('#nav').css({
		left: "0"
	});
	$('.m-navbar').toggleClass('m-navbar-show');
	return
}
function stopProp(event) {
	event.stopPropagation()
}
function OpenSideNavRight(event) {
	if ($('.m-navbar').hasClass('m-navbar-show')) {
		$('.m-navbar').removeClass('m-navbar-show');
		$('#nav').css({
			left: "-100%"
		})
	}
	event.stopPropagation();
	if ($('.m-navbar-right').hasClass('m-navbar-right-show')) {
		$('.m-navbar-right').removeClass('m-navbar-right-show');
		$('.rightli').css({
			right: "-100%"
		});
		return
	}
	$('.rightli').css({
		right: "0"
	});
	$('.m-navbar-right').toggleClass('m-navbar-right-show');
	return
}

 /* search.js */
function doSearch(obj) {
	obj.submit();
}
 /* SubMenu.js */
$(function() {
	$("#nav li").hover(function() {
		$(this).find(".sub-menu:first").slideDown(120);
	}, function() {
		$(this).find(".sub-menu:first").slideUp(70);
	});
}); 
