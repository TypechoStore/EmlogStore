<?php
/*
 * WRZ博客
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(	
		
	'compress_html' => array(
        'type' => 'radio',
        'name' => '网站源码压缩',
        'description' => '',
        'values' => array('open' => '压缩','close' => '关闭'),
        'default' => 'open'
    ),
	'xiaxue' => array(
        'type' => 'radio',
        'name' => '下雪背景',
        'description' => '',
        'values' => array('open' => '开启','close' => '关闭'),
        'default' => 'open'
        ),
);