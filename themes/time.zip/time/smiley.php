﻿<?php 
?>
<a href="javascript:grin('[F1]')" title="嘻嘻"><img src="<?php echo TEMPLATE_URL; ?>images/face/1.gif" alt="嘻嘻"/></a>
<a href="javascript:grin('[F2]')" title="大笑"><img src="<?php echo TEMPLATE_URL; ?>images/face/2.gif" alt="大笑"/></a>
<a href="javascript:grin('[F3]')" title="可怜"><img src="<?php echo TEMPLATE_URL; ?>images/face/3.gif" alt="可怜"/></a>
<a href="javascript:grin('[F4]')" title="吃惊"><img src="<?php echo TEMPLATE_URL; ?>images/face/4.gif" alt="吃惊"/></a>
<a href="javascript:grin('[F5]')" title="害羞"><img src="<?php echo TEMPLATE_URL; ?>images/face/5.gif" alt="害羞"/></a>
<a href="javascript:grin('[F6]')" title="调皮"><img src="<?php echo TEMPLATE_URL; ?>images/face/6.gif" alt="调皮"/></a>
<a href="javascript:grin('[F7]')" title="鄙视"><img src="<?php echo TEMPLATE_URL; ?>images/face/7.gif" alt="鄙视"/></a>
<a href="javascript:grin('[F8]')" title="示爱"><img src="<?php echo TEMPLATE_URL; ?>images/face/8.gif" alt="示爱"/></a>
<a href="javascript:grin('[F9]')" title="大哭"><img src="<?php echo TEMPLATE_URL; ?>images/face/9.gif" alt="大哭"/></a>
<a href="javascript:grin('[F10]')" title="开心"><img src="<?php echo TEMPLATE_URL; ?>images/face/10.gif" alt="开心"/></a>
<a href="javascript:grin('[F11]')" title="偷笑"><img src="<?php echo TEMPLATE_URL; ?>images/face/11.gif" alt="偷笑"/></a>
<a href="javascript:grin('[F12]')" title="嘘"><img src="<?php echo TEMPLATE_URL; ?>images/face/12.gif" alt="嘘"/></a>
<a href="javascript:grin('[F13]')" title="奸笑"><img src="<?php echo TEMPLATE_URL; ?>images/face/13.gif" alt="奸笑"/></a>
<a href="javascript:grin('[F14]')" title="委屈"><img src="<?php echo TEMPLATE_URL; ?>images/face/14.gif" alt="委屈"/></a>
<a href="javascript:grin('[F15]')" title="抱抱"><img src="<?php echo TEMPLATE_URL; ?>images/face/15.gif" alt="抱抱"/></a>
<a href="javascript:grin('[F16]')" title="愤怒"><img src="<?php echo TEMPLATE_URL; ?>images/face/16.gif" alt="愤怒"/></a>
<a href="javascript:grin('[F17]')" title="思考"><img src="<?php echo TEMPLATE_URL; ?>images/face/17.gif" alt="思考"/></a>
<a href="javascript:grin('[F18]')" title="日了狗"><img src="<?php echo TEMPLATE_URL; ?>images/face/18.gif" alt="日了狗"/></a>