<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="site-container" class="clearfix">
<div id="primary" class=" clearfix">
<div id="content" role="main" class="page pagea">
<article id="post-263" class="post-263 page type-page status-publish hentry clearfix">
<div class="hentry-box">
<div class="entry-wrap">
<div id="page-header">
	<h1 class="page-title"><?php echo $log_title; ?></h1>
</div>
	<div class="entry-content clearfix">
<p style="text-align: center;"><?php echo $log_content; ?></p>
</div>
</div>  
</div>
</article>
<style type="text/css">
div#author_info {position: absolute;z-index: 99;right: 8px;top: -24px;}
div#author_info input{width: 140px;}
</style>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<?php blog_comments($comments); ?>
	</div>	</div>  
</div>
<?php
 include View::getView('footer');
?>