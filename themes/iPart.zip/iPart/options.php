<?php
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
    'welcome_tips_isopen' => array(
        'type' => 'radio',
        'name' => 'TIPS总开关',
        'description' => '能在访客浏览时，弹出一句话',
        'values' => array(
            'open' => '开启',
            'close' => '关闭'
        ),
        'default' => 'open',
    ),
	'welcome_tips_name' => array(
		'type' => 'text',
        'description' => '写个标题吧',
		'name' => '博客tips标题',
		'values'=> array(
			'iPart@Blog:Tips',
		)
	),
	'welcome_tips_connent' => array(
		'type' => 'text',
		'description' => '给你的访客写一句话吧~(支持HTML代码哦)',
		'name' => '博客tips内容(支持HTML代码)',
		'multi' => true,
		'rich' => true,
		'values'=> array(
			'这是你第一次访问本博客..',
		)
	),
	'blog_body_css3' => array(
        'type' => 'radio',
        'name' => '博客首页动画设置',
        'description' => '博客动画看腻了?不想要动画了?',
        'values' => array(
            'pullDown' => '下坠',
			'fadeIn' => '飞入',
            'slideRight' => '右滑动',
			'slideLeft' => '左滑动',
			'pulse' => '舞动(可设置背景音乐)',
            'float' => '浮动',
            'bounce'=> 'Q弹',
            'tossing'=>'摇呀摇',
            'null' => '取消动画'
        ),
        'default' => 'expandOpen',
    ),
    
    'blog_body_pulse_music' => array(
    'type' => 'text',
        'name' => '舞动背景音乐链接',
        'description' => '让您的博客舞动起来吧！！',
        'values' => array(
            '//7qn9xj.com1.z0.glb.clouddn.com/ipart_mexinzhedeaiguoyu.m4a'
        )
    ),
    
    'blog_weichat_icon' => array(
        'type' => 'image',
        'name' => '微信分享缩略图',
        'description' => '你可以选择一张blog的缩略图 但是尺寸建议不要超过 144 x 144',
        'values' => array( 
           TEMPLATE_URL . 'images/icon/weichat@128x128.png'
    )
        
    ),
    // 博客
    'blog_header_fixed' => array(
        'type' => '',
        'name' => '',
        'description' => '',
        
                )
);