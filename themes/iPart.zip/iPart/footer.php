<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
 <script type="text/javascript">
$("#loadingbar").animate({width:"80%"});
</script>
<div data-am-widget="gotop" class="am-gotop am-gotop-fixed">
  <p><a href="#top" title="回到顶部">
    <span class="am-gotop-title">回到顶部</span>
    <i class="am-gotop-icon am-icon-chevron-up"></i>
  </a>
  </p>
</div
</div>
<script src="<?php echo TEMPLATE_URL;?>js/wechat.min.js?v=1.2" type="text/javascript"></script>
<!-- 微博 or 微信分享功能-->
<script type="text/javascript">
// 单页面生成二维码
var get_Link = window.location.href;
$(".qrcode").qrcode({
    width : 240, //宽度 
    height: 240, //高度 
	text : get_Link
}
	);
	$(".qrcode > canvas").width("100%");
setTimeout(function(){
	$("#welcome").click();
},60000);
var data = {
	app : '',
	img: function() {
    return '<?php echo _g('blog_weichat_icon'); ?>';
  },
	link : '<?php echo blog_get_url();?>',
	desc : '<?php echo htmlspecialchars($site_description); ?>',
	title : '<?php echo htmlspecialchars($site_title); ?>'
};

wechat('friend', data, function(){});     // 朋友
wechat('timeline', data, function(){});   // 朋友圈
wechat('weibo', data, function(){});      // 微博
</script>
<?php if(_g('openwelcome_tips_isopen') == 'open') : ?>
<button style="display:none;" class="am-btn am-btn-primary" id="welcome" data-am-modal="{target: '#doc-modal-1'}">Hook</button>
<div class="am-modal am-modal-no-btn" tabindex="-1" id="doc-modal-1">
  <div class="am-modal-dialog">
    <div class="am-modal-hd"><?php echo _g('welcome_tips_name'); ?>
      <a href="javascript: void(0)" class="am-close am-close-spin" data-am-modal-close>&times;</a>
    </div>
    <div class="am-modal-bd">
     <?php echo _g('welcome_tips_connent'); ?>
    </div>
  </div>
</div>
<?php endif; ?>
<footer class="blog-footer">
  <p><br/>
    <small>© Copyright <a href="<?php echo BLOG_URL; ?>" title="<?php echo $site_description; ?>"><?php echo $blogname; ?></a></small>
	<small>Powered by <a href="http://www.emlog.net" title="采用emlog系统">emlog</a></small><br/>
	<small>Themes <a href="http://about.itsec.pw" title="本博客正在使用iPart主题">y0umer</a></small>
  </p>
  <?php echo $footer_info; ?>
  <?php doAction('index_footer'); ?>
</footer>
<script type="text/javascript">
var BLOG_URL = '<?php echo BLOG_URL; ?>';
var TEMPLATE_URL = '<?php echo TEMPLATE_URL; ?>';
</script>
<script src="<?php echo TEMPLATE_URL;?>js/zepto.min.js?v=2.0" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL;?>js/jquery.lazyload.js?v=2.0" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL;?>js/amazeui.basic.min.js?v=2.0" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL;?>js/basic.js?v=2.0"></script>
<script type="text/javascript">
// 全屏函数
(function($) {
  'use strict';
    $(function() {
        $('#openAll').on('click', function() {
              $.AMUI.fullscreen.toggle();
    });
  });
})(window.Zepto);
</script>
 <script type="text/javascript">
$("#loadingbar").animate({width:"100%"});
</script>
</body>
</html>