<?php 
/**
 * 侧边栏组件、页面模块
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="bloggerinfo">
	<div id="bloggerinfoimg">
	<?php if (!empty($user_cache[1]['photo']['src'])): ?>
	<img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="<?php echo $user_cache[1]['photo']['width']; ?>" height="<?php echo $user_cache[1]['photo']['height']; ?>" alt="blogger" />
	<?php endif;?>
	</div>
	<p><b><?php echo $name; ?></b>
	<?php echo $user_cache[1]['des']; ?></p>
	</ul>
	</li>
<?php }?>
<?php
//widget：日历
function widget_calendar($title){ ?>
	<section class="am-panel am-panel-default">
		<div class="am-panel-hd"><?php echo $title; ?></div>
	</div>
	</section>
<?php }?>
<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
	<section class="am-panel am-panel-default">
		<div class="am-panel-hd"><?php echo $title; ?></div>
	<?php foreach($tag_cache as $value): ?>
		<span class="am-badge am-radius am-badge-primary">
		<a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇文章"><?php echo $value['tagname']; ?></a></span>
	<?php endforeach; ?>
	</div>
	</section>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	<section class="am-panel am-panel-default">
	<div class="am-panel-hd"><?php echo $title; ?></div>
	<ul class="am-list blog-list hod">
	<?php
	foreach($sort_cache as $value):
		if ($value['pid'] != 0) continue;
	?>
	<li>
	<a title="该分类有<?php echo $value['lognum'] ?>文章" href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?><span class="am-badge am-badge-success am-round am-fr am-animation-shake"><?php echo $value['lognum'] ?></span></a>
	<?php if (!empty($value['children'])): ?>
		<ul>
		<?php
		$children = $value['children'];
		foreach ($children as $key):
			$value = $sort_cache[$key];
		?>
		<li>
			<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
		</li>
		<?php endforeach; ?>
		</ul>
	<?php endif; ?>
	</li>
	<?php endforeach; ?>
	</ul>
	</div>
	</section>
<?php }?>
<?php
//widget：最新微语
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="twitter">
	<?php foreach($newtws_cache as $value): ?>
	<?php $img = empty($value['img']) ? "" : '<a title="查看图片" class="t_img" href="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" target="_blank">&nbsp;</a>';?>
	<li><?php echo $value['t']; ?><?php echo $img;?><p><?php echo smartDate($value['date']); ?></p></li>
	<?php endforeach; ?>
    <?php if ($istwitter == 'y') :?>
	<p><a href="<?php echo BLOG_URL . 't/'; ?>">更多&raquo;</a></p>
	<?php endif;?>
	</ul>
	</li>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="newcomment">
	<?php
	foreach($com_cache as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	?>
	<li id="comment"><?php echo $value['name']; ?>
	<br /><a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：最新文章
function widget_newlog($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
	<section class="am-panel am-panel-default" >
	<div class="am-panel-hd news"><?php echo $title; ?><i class="am-icon-chevron-down am-fr"></i></div>
	<ul class="am-list blog-list">
	<?php foreach($newLogs_cache as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</section>
<?php }?>
<?php
//widget：热门文章
function widget_hotlog($title){
	$index_hotlognum = Option::get('index_hotlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getHotLog($index_hotlognum);?>
	<section class="am-panel am-panel-default">
		<div class="am-panel-hd" data-am-collapse="{target: '.hod'}"><?php echo $title; ?><i class="am-icon-chevron-down am-fr" ></i></div>
	<ul class="am-list blog-list hod">
	<?php foreach($randLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</section>
<?php }?>
<?php
//widget：随机文章
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="randlog">
	<?php foreach($randLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="logsearch">
	<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
	<input name="keyword" class="search" type="text" />
	</form>
	</ul>
	</li>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="record">
	<?php foreach($record_cache as $value): ?>
	<li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
	<section class="am-panel am-panel-default">
        <div class="am-panel-hd"  data-am-collapse="{target: '.option'}"><?php echo $title; ?><i class="am-icon-chevron-down am-fr"></i></div>
        <div class="am-panel-bd option">
          <?php echo $content; ?>
        </div>
      </section>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
    //if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
	?>
	<section class="am-panel am-panel-default">
	<div class="am-panel-hd" data-am-collapse="{target: '#links'}"><?php echo $title; ?><i class="am-icon-chevron-down am-fr"></i></div>
	<ul class="am-list blog-list" id="links">
	<?php foreach($link_cache as $value): ?>
	<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</section>
<?php }?> 
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	?>
	<ul class="am-nav am-nav-pills am-topbar-nav">
	<?php
	foreach($navi_cache as $value):
		 if ($value['pid'] != 0) {
            continue;
        }
		if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):
			?>
			<li><a href="<?php echo BLOG_URL; ?>admin/">管理站点</a></li>
			<li><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
        $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'current' : 'common';
		?>
			<?php if (!empty($value['children'])) :?>
			<li class="am-dropdown" data-am-dropdown>
				<a class="am-dropdown-toggle" data-am-dropdown-toggle href="javascript:;">
            <?php echo $value['naviname']; ?> <span class="am-icon-caret-down"></span>
				</a>
            <ul class="am-dropdown-content">
				 <?php foreach ($value['children'] as $row){
                        echo '<li><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></li>';
                }?>
			</ul>
        </li>
            <?php endif;?>
			 <li title="<?php echo $value['naviname']; ?>"><?php echo $newtab;?><a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a></li>
		  <?php if (!empty($value['childnavi'])) :?>
            <ul class="am-dropdown-content">
                <?php foreach ($value['childnavi'] as $row){
                        $newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';
                        echo '<li title="{$row["naviname"]}"><a href="' . $row['url'] . "\" $newtab >" . $row['naviname'].'</a></li>';
                }?>
			</ul>
            <?php endif;?>
	<?php endforeach; ?>
	</ul>
<?php }?>
<?php
//blog：置顶
function topflg($top, $sortop='n', $sortid=null){
    if(blog_tool_ishome()) {
       echo $top == 'y' ? "<img src=\"".TEMPLATE_URL."/images/top.png\" title=\"首页置顶文章\" /> " : '';
    } elseif($sortid){
       echo $sortop == 'y' ? "<img src=\"".TEMPLATE_URL."/images/sortop.png\" title=\"分类置顶文章\" /> " : '';
    }
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
    <a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
	<?php endif;?>
<?php }?>
<?php
//blog：分类
function log_blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
    <?php echo $log_cache_sort[$blogid]['name']; ?>
	<?php endif;?>
<?php }?>
<?php
//blog：文章标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '标签:';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "	<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
		}
		echo $tag;
	}
}
?>
<?php
//blog：文章作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：文章作者
function log_blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo $author;
}
?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog):?>
	&laquo; <a href="<?php echo Url::log($prevLog['gid']) ?>"><?php echo $prevLog['title'];?></a>
	<?php endif;?>
	<?php if($nextLog && $prevLog):?>
		|
	<?php endif;?>
	<?php if($nextLog):?>
		 <a href="<?php echo Url::log($nextLog['gid']) ?>"><?php echo $nextLog['title'];?></a>&raquo;
	<?php endif;?>
<?php }?>
<?php
//blog：评论列表
function blog_comments($comments){
    extract($comments);
    if($commentStacks): ?>	
	<span class="am-badge am-badge-secondary am-radius">TA们再说：</span>
	<hr/>
	<?php endif; ?>
	<?php $isGravatar = Option::get('isgravatar');?>
		<ul class="am-comments-list am-comments-list-flip">
	<?php
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	?>
  <a href="javascript:;">
    <img class="am-comment-avatar am-animation-spin" alt="<?php echo $comment['poster']; ?>" src="http://q.qlogo.cn/g?b=qq&nk=1963650354&s=100"/>
  </a>
  <li class="am-comment" id="comment-<?php echo $comment['cid']; ?>">
   <a name="<?php echo $comment['cid']; ?>"></a>
	<div class="am-comment-main"> <!-- 评论内容容器 -->
    <header class="am-comment-hd">
	<div class="am-comment-meta"> <!-- 评论元数据 -->
        <a href="<?php echo $comment['url']; ?>" class="am-comment-author" target="_blank"><?php echo $comment['poster']; ?></a> 
		<!-- 评论者 -->
		<strong class="am-fr commentList"><?php echo $comment['cid']; ?>#</strong>
        评论于 <time datetime="<?php echo $comment['date']; ?>"><?php echo $comment['date']; ?></time>
		<a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)" title="@<?php echo $comment['cid']; ?>#" class="am-icon-at am-fr"></a>
      </div>
    </header>
		<div class="am-comment-bd"><small><?php echo $comment['content']; ?></small></div>
	 </div>
	 </li>
	 <?php blog_comments_children($comments, $comment['children']); ?>
	<?php endforeach; ?>
	</ul>
	<hr/>
<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	// $comment['poster'] = $comment['url'] ? $comment['url']  $comment['poster'] : $comment['poster'];
	?>
	<a href="javascript:;">
		<img class="am-comment-avatar am-animation-spin am-fr" alt="" src="http://q2.qlogo.cn/headimg_dl?bs=qq&amp;dst_uin=1963650354&amp;src_uin=1963650354&amp;fid=1963650354&amp;spec=100&amp;url_enc=0&amp;referer=bu_interface&amp;term_type=PC"/>
  </a>
	<li class="am-comment am-comment-flip am-comment-success" id="comment-<?php echo $comment['cid']; ?>">
			<div class="am-comment-main"> <!-- 评论内容容器 -->
    <header class="am-comment-hd">
	<div class="am-comment-meta"> <!-- 评论元数据 -->
       <a href="<?php echo $comment['url']; ?>" class="am-comment-author" target="_blank"><?php echo $comment['poster']; ?></a>
	   <strong class="am-fr commentList"><?php echo $comment['cid']; ?>#</strong>
		<!-- 评论者 -->
        回复于 <time datetime="<?php echo $comment['date']; ?>"><?php echo $comment['date']; ?></time>
		 <a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)" title="回复<?php echo $comment['cid'];?>#" class=" am-icon-mail-forward am-fr"></a>
      </div>
    </header>
		<div class="am-comment-bd"><small><?php echo $comment['content']; ?></small></div>
	 </div>
	 </li>
		<?php blog_comments_children($comments, $comment['children']);?>
	<?php endforeach; ?>
<?php }?>
<?php 
//widget：移动客户端二维码
function widget_qrcode($title){ ?>
	<section class="am-panel am-panel-default">
        <div class="am-panel-hd" data-am-collapse="{target: '.qrcodes'}"><?php echo $title;?><i class="am-icon-chevron-down am-fr"></i></div>
        <div class="am-panel-bd qrcodes">
          <div class="qrcode expandOpen">
		</div>    
		</div>
      </section>
<?php } ?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
	<div id="comment-place">
	<div class="comment-post" id="comment-post">
		<p class="comment-header"><span class="am-badge am-badge-secondary am-radius">我要说：</span><a name="respond"></a></p>
		<form method="post" class="am-form am-form-horizontal" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
			<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
			<?php if(ROLE == ROLE_VISITOR): ?>
			<div class="am-form-group">
			<i class="am-icon-user"></i>
				<label for="comname">姓名</label>
				<input type="text" class="am-input-sm am-form-field am-round" id="comname" name="comname" value="<?php echo $ckname; ?>" placeholder="<?php echo $blogname;?>">
			</div>
			<div class="am-form-group">
			<i class="am-icon-envelope"></i>
				<label for="commail">电子邮箱(选填)</label>
				<input type="email" class="am-input-sm am-form-field am-round" id="commail" name="commail" value="<?php echo $ckmail; ?>" placeholder="blog@ipart.me">
			</div>
			<div class="am-form-group">
			<i class="am-icon-globe"></i>
				<label for="comurl">个人主页(选填)</label>
				<input type="url" class="am-input-sm am-form-field am-round" id="comurl" name="comurl" value="<?php echo $ckurl; ?>" placeholder="<?php echo BLOG_URL;?>">
			</div>
			<div class="am-form-group">
			<i class="am-icon-qq"></i>
				<label for="comqq">QQ号码(用于显示评论头像)</label>
				<input type="text" class="am-input-sm am-form-field am-round" id="comqq" name="comqq" placeholder="1963650354">
			</div>
			<?php endif; ?>
			<div class="am-form-group">
				<label for="comment">评论内容</label>
				<textarea class="am-input-sm am-round" name="comment" rows="6" id="comment" placeholder="是不是应该说点什么呢..."></textarea>
			</div>
			<p><?php echo $verifyCode; ?>
			<input type="submit" class="am-btn am-btn-success am-radius am-round am-input-sm" id="comment_submit" data-am-loading="{loadingText: '正在发布评论...'}" value="发表评论" tabindex="6" /></p>
			<input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/>
		</form>	
		</div>
	</div>
	<?php endif; ?>
<?php }?>
<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>
<?php
// 自定义分页函数
function blog_tool_page($count, $perlogs, $page, $url, $anchor = '') {
	 $pnums = @ceil($count / $perlogs);
	 $re = '';
	 $urlHome = preg_replace("|[\?&/][^\./\?&=]*page[=/\-]|", "", $url);
	 if($page > 1) {
	  	$i = $page - 1;
		 $re = " <li class=\"am-pagination-prev\"><a href=\"$url$i\">« 上一页</a></li> " . $re;
	 }
	 if($page < $pnums) {
	  	$i = $page + 1;
		 $re .= "<li class=\"am-pagination-next\"><a href=\"$url$i\">下一页 »</a></li>";
	 }
	 return $re;
}
?>
<?php 
// 获取当前地址
	function blog_get_url(){
	return 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	}
?>
<?php
// 判断插件模版设置是否存在
    function is_tpl_options_plus(){
        // if(function_)
    }
?>