<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="am-g am-g-fixed blog-g-fixed">
<div class="col-md-8">
<article class="blog-main">
	<h1 class="am-article-title blog-title" style="text-align:left;" title="<?php echo $log_title; ?>"><?php topflg($top); ?><?php echo $log_title; ?></h1>
	<ol class="am-breadcrumb">
  <li><a href="<?php echo BLOG_URL;?>" class="am-icon-home"><?php echo $blogname; ?></a></li>
  <li><?php blog_sort($logid); ?></li>
  <li class="am-active"><?php echo $log_title; ?></li>
</ol>
	<hr class="am-article-divider blog-hr">
	<div class="am-g blog-content">
		<div class="col-sm-11">
		<?php echo $log_content; ?>
		</div>
	</div>
	<p class="tag"><?php blog_tag($logid); ?></p>
	<?php doAction('log_related', $logData); ?>
</article>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
<link href="<?php echo TEMPLATE_URL;?>css/audioplayer.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo TEMPLATE_URL;?>js/audioplayer.js" type="text/javascript"></script>
<script type="text/javascript" charset="utf-8">
// html5 播放器hook
$( function()
{
   $('audio').audioPlayer();
});
</script>  
<link href="<?php echo BLOG_URL; ?>admin/ueditor/third-party/SyntaxHighlighter/shCoreDefault.css" rel="stylesheet" type="text/css" />  
<script type="text/javascript" src="<?php echo BLOG_URL; ?>admin/ueditor/third-party/SyntaxHighlighter/shCore.js"></script>  
<script type="text/javascript">      
SyntaxHighlighter.all();       
</script>
<?php
 include View::getView('side');
 include View::getView('footer');
?>