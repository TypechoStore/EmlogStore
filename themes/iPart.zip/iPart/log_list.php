<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="am-g am-g-fixed blog-g-fixed">
   <div class="col-md-8">
   <script type="text/javascript">
$("#loadingbar").animate({width:"60%"});
</script>
<?php doAction('index_loglist_top'); ?>
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
<?php $value['log_description'] = str_replace('阅读全文&gt;&gt;','',$value['log_description']);?>

	<section class="blog-main" id="log-id-<?php echo $value['logid']; ?>">
	<h3 class="am-article-title blog-title"><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></h3>

	<h4 class="am-article-meta blog-meta slideLeft">
        <span class="log_author" title="作者:<?php log_blog_author($value['author']); ?>"><i class="am-icon-user"></i>&nbsp;<?php blog_author($value['author']); ?></span>&nbsp; &nbsp;<span class="log_time" title="文章发表日期:<?php echo gmdate('Y/n/j', $value['date']); ?>"><i class="am-icon-calendar"></i>&nbsp;<?php echo gmdate('Y/n/j', $value['date']); ?></span>&nbsp; &nbsp;<span class="log_class" title="分类:<?php log_blog_sort($value['logid']);?>"><i class="am-icon-location-arrow"></i>&nbsp;<?php blog_sort($value['logid']);?></span>&nbsp;<span class="log_view" title="已被阅读 <?php echo $value['views']; ?>次"><i class="am-icon-angellist"></i>&nbsp;<?php echo $value['views']; ?></span><span class="commet" data-thread-key="<?php echo $value['logid']; ?>"></span>
	</h4>
	<div class="am-g blog-content">
		<div class="col-sm-11">
			<p title="文章摘要:<?php echo strip_tags($value['log_description'],"img"); ?>"><?php echo $value['log_description']; ?></p>
		</div>
	</div>
	 </section>
	 <hr class="am-article-divider blog-hr">
<?php 
endforeach;
else:
?>
	<h2>悲剧了 :(</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
<ul class="am-pagination blog-pagination">
      <?php 
	$page_loglist = blog_tool_page($lognum, $index_lognum, $page, $pageurl);
	echo $page_loglist;
	?>
</ul>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>