$(document).ready(function() {
	if (navigator.userAgent.match(/mobile/i)) {
// 移动访问隐藏侧边栏（影响阅读）
		$(".blog-sidebar").hide();
	}
	if (navigator.userAgent.match(/iPad/i)) {
// 移动访问隐藏侧边栏（影响阅读）
		$(".blog-sidebar").show();
	}
// 图片延迟加载
$(function(){
	$("img").lazyload({
     placeholder : TEMPLATE_URL + "images/loading.gif", //加载图片前的占位图片
	 effect      : "fadeIn" //加载图片使用的效果(淡入)

});
});

// $("img").addClass("bounce");
//首先将#back-to-top隐藏
	//当滚动条的位置处于距顶部200像素以下时，跳转链接出现，否则消失
    if (!navigator.userAgent.match(/mobile/i)) {
	// 移动访问隐藏侧边栏（影响阅读）
	$(function() {
        $(window).scroll(function() {
            if ($(window).scrollTop() > 200) {
                $("#back-to-top").fadeIn(1500);
            } else {
                $("#back-to-top").fadeOut(1500);
            }
        });

        //当点击跳转链接后，回到页面顶部位置
        $("#back-to-top").click(function() {
            $('body,html').animate({
                scrollTop: 0
            },
            1000);
            return false;
        });
    });
	}
// 博客标题
$(function(){
    $("h3 > a").hover(function(){
            $(this).addClass("expandOpen");
        },function(){
            $(this).removeClass("expandOpen");  
        })
  })
// 侧边栏划动
  $(function(){
    $(".am-list > li > a").hover(function(){
            $(this).addClass("stretchRight");
        },function(){
            $(this).removeClass("stretchRight");  
        })
  });
// 进度条消失
$("#loadingbar").animate({width:"100%"},800,function(){
	setTimeout(function(){$("#loadingbar").fadeOut(500);
});

});

function tips_alrt(title,connet){
	
}
});
