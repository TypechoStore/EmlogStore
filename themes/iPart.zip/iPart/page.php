<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="am-g am-g-fixed blog-g-fixed">
<div class="col-md-8">
<article class="blog-main">
	<h3 class="am-article-title blog-title" style="text-align:left;"><?php echo $log_title; ?></h3>
	<hr class="am-article-divider blog-hr">
	<div class="am-g blog-content">
		<div class="col-sm-11">
	<?php echo $log_content; ?>
		</div>
	</div>
	</article>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
<link href="<?php echo TEMPLATE_URL;?>css/audioplayer.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo TEMPLATE_URL;?>js/audioplayer.js" type="text/javascript"></script>
<script type="text/javascript" charset="utf-8">
// html5 播放器hook
$( function()
{
   $('audio').audioPlayer();
});
</script>
<?php
 include View::getView('side');
 include View::getView('footer');
?>