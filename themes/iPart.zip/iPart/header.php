<?php
/*
Template Name:iPart UI
Description:栅格布局模式，简洁配色风格，炫酷动画效果，低调中带着一丝尊贵，适合文字爱好者使用
Version:2.3
Author:y0umer
Author Url:http://about.itsec.pw
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
ob_clean();
?>
<?php if (isset($logid)) : ?>
<?php $site_description = trim(str_replace(" ","",str_replace("&nbsp;","",str_replace("\r","",str_replace("\n","",mb_strcut(strip_tags($log_content),0,256,'UTF-8')))))).'...';?>
<?php endif; ?>
<!DOCTYPE html>
<html>
<head lang="zh-cn">
<meta charset="UTF-8">
<title><?php echo $site_title; ?></title>
<link rel="dns-prefetch" href="//ipart-me.qiniudn.com">
<link rel="dns-prefetch" href="//www.ipart.me">
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="format-detection" content="telephone=no" />
<meta name="renderer" content="webkit" />
<meta http-equiv="Cache-Control" content="no-siteapp"/>
<meta name="apple-mobile-web-app-title" content="<?php echo $blogname; ?>" />
<link rel="apple-touch-icon-precomposed" sizes="128x128" href="<?php echo TEMPLATE_URL;?>images/weichat@128x128.png">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL;?>rss.php" />
<link rel="alternate icon" type="image/png" href="<?php echo TEMPLATE_URL;?>images/favicon.ico">
<link rel="stylesheet" href="<?php echo TEMPLATE_URL;?>css/amazeui.min.css?v=2.0"/>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL;?>css/blog.min.css?=v2.1"/>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL;?>css/animations.css?v=2.0"/>
<script type="text/javascript" src="<?php echo TEMPLATE_URL;?>js/jquery.min.js?v=2.0"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL;?>js/jquery.qrcode.min.js?v=2.0"></script>
<script src="<?php echo TEMPLATE_URL;?>js/amazeui.min.js?v=2.1" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js?=v2.0" type="text/javascript"></script>
<!--[if lte IE 9 ]><div class="am-alert am-alert-danger ie-warning" data-am-alert>
  <button type="button" class="am-close">&times;</button>
  <div class="am-container">
    365 安全卫士提醒：你的浏览器太古董了，妹子无爱，<a
    href="http://browsehappy.com/" target="_blank">还不速速换一个</a>！</div></div><![endif]-->
<?php //doAction('index_head'); ?>
<?php if(!function_exists("_g")):?>
<div class="am-alert am-alert-danger ie-warning" data-am-alert>
  <button type="button" class="am-close">&times;</button>
  <div class="am-container">
    iPart UI提示：本模版需要"tpl_options"插件支持，请
    <a href="http://www.emlog.net/plugin/144" target="_blank">立即安装</a>！
    </div>
</div>
<?php endif; ?>
<?php if(_g('blog_body_css3') == 'pulse'):?>
    <audio style="display:none;" id="music" src="<?php echo _g('blog_body_pulse_music'); ?>" autoplay></audio>
<?php endif;?>
</head>
<body class="<?php echo _g('blog_body_css3')?>">
<header class="am-topbar blog-nav">
  <h1 class="am-topbar-brand expandOpen">
    <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>
  </h1>
<button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-success am-show-sm-only"
          data-am-collapse="{target: '#doc-topbar-collapse'}"><span class="am-sr-only">导航切换</span> <i class="am-icon-bars"></i></button>
	<div class="am-collapse am-topbar-collapse" id="doc-topbar-collapse">
		<?php blog_navi();?>
<?php 
$keywords = BLOG_URL;
		// 搜索功能只允许在首页显示
		if(blog_tool_ishome() == true){
			echo "
			<form class=\"am-topbar-form am-topbar-left am-form-inline am-topbar-right\" role=\"search\" action=\"{$keywords}index.php\" method=\"GET\">
      <div class=\"am-form-group\">
        <input type=\"text\" name=\"keyword\" class=\"am-form-field am-input-sm\" placeholder=\"搜索文章\">
      </div>
      <button type=\"submit\" class=\"am-btn am-btn-default am-btn-sm\">搜索</button>
    </form>
	";
	}else{
		echo '<div class="am-topbar-form am-topbar-left am-form-inline am-topbar-right">';
		echo '<button type="button" class="am-btn am-btn-default am-btn-sm" id="openAll"><i class="am-icon-arrows-alt"></i>开启全屏</button>';
		echo '</div>';
	}
?>
</div>
</header>
<div id="loadingbar"></div><script>$("#loadingbar").animate({width:"20%"});</script>