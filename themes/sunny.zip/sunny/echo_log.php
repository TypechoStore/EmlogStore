<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="contentleft">
	<div class="post-box-header">
	<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
	</div>
	<div class="post-box">
		<p class="date">作者：<?php blog_author($author); ?> 发布于：<?php echo gmdate('Y-n-j G:i l', $date); ?> 
		<?php blog_sort($logid); ?> <?php editflg($logid,$author); ?>
		</p>
		<div class="log_comment"><?php echo $log_content; ?></div>
	</div>
	<div class="post-box-foot">
	<div class="att"><?php blog_att($logid); ?></div>
	<div class="tag"><?php blog_tag($logid); ?></div>
	</div>
	<?php doAction('log_related', $logData); ?>
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
</div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>