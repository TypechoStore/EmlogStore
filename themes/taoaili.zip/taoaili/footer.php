<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="clear"></div>
<div class="main" id="foot">
<?php
call_user_func('widget_newlog', htmlspecialchars('最新日志'));
call_user_func('widget_random_log', htmlspecialchars('随机日志'));
call_user_func('widget_hotlog', htmlspecialchars('热门日志'));
?>
</div>
<div id="copyright" class="main">
&copy; Powered by <a href="http://www.lvtao.net">LvTao.Net</a> 
<a href="http://www.miibeian.gov.cn" target="_blank" rel="nofollow"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
<?php doAction('index_footer'); ?>
</div>
</body>
</html>