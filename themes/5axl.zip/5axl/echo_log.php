<?php 
/**
 * 阅读文章页面
 */
if (BLOG_URL . trim(Dispatcher::setPath(), '/') != Url::log($logid)){
header('HTTP/1.1 301 Moved Permanently');echo sheli_cc();
header('Location:'.Url::log($logid));
}
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!--wrapper begin-->
<div class="wrapper clearfix pt10">
  <div class="con-left">
    <div class="positionbar">
      <ul  class="bread clearfix">
        <li class="ico"><img src="<?php echo TEMPLATE_URL; ?>images/ico_07.png" /></li>
        <li><a href="<?php echo BLOG_URL; ?>">首页</a></li>
        <li><?php blog_sort($logid); ?></li>
        <li class="last"><?php echo $log_title; ?>
      </ul>
    </div>
    <h1 class="main-tit2"><?php topflg($top); ?><span class="black f20 fb"><a href="<?php echo Url::log($logid); ?>"><?php echo $log_title; ?></a></span></h1>

	  <p class="icogroup lh180 loginfo"><span class="ico-list"><span class="icon icon-01"></span>发布：<?php blog_author($author); ?></span><span class="ico-list"><span class="icon icon-02"></span><c style="color:red"><?php echo gmdate('Y-n-j G:i', $date); ?></c></span><span class="ico-list"><span class="icon icon-03"></span>分类：<?php blog_sort($logid); ?></span><span class="sidetags"><?php blog_tag($logid);?></span>	<span class="ico-list"><span class="icon icon-06"> </span>浏览：<c style="color:blue"><?php echo $views; ?></c></span><span class="ico-list"><span class="icon icon-08"></span>字数：<?php echo mb_strlen(preg_replace(array("'<(.*?)>'is","'&nbsp;'","'\n\r'","' '","'\r'","'\n'"),'',$log_content),'UTF-8');?></span>&nbsp<span class="wuiso"><a href="#comment-post" style="color:#00aff0;border:#00aff0 1px solid;padding:1px 2px;margin-right:3px;border-radius:3px;">去评论(<?php echo $comnum; ?>)</a></span></p>
    <div class="art-content pt10 f16 lh200"><?php echo tag_link($log_content); ?><?php doAction('down_log',$logid); ?>
    </div><?php doAction('log_related', $logData);?><br><div class="cutline"><span style="color: #2196F3;padding:4px 3px;
  text-shadow: 0 0 8px #2196F3;
  border-color:  solid #2196F3;
  box-shadow: 0 0 15px #2196F3, inset 0 0 15px #2196F3;
 margin: 0 5px;

  letter-spacing: 1px;
  height: 2.25em;
  border-radius: 2.25em;

  font-weight: bold;
  text-transform: uppercase;
  transition: .5s;
  outline: none;
"> 正文到此结束</span></div>  
	  <div class="log_a" style="margin-bottom:32px;"> 
<span class="zd_1"><a href="#comment-post" > <i class="fa fa-comment"></i> 吐槽一下</a></span>


<span class="zd_3"><a href="https://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=<?php echo Url::log($logid); ?>&title=<?php echo $log_title; ?>&desc=<?php echo $log_title; ?>&summary=&site=" class="share"> <i class="fa fa-weixin"></i> 分享一下</a></span> 
 <span class="zd_4"><a href="https://wpa.qq.com/msgrd?v=3&uin=<?php echo _g('ctqq'); ?>&site=qq&menu=yes" > <i class="fa fa-qq"></i> 联系站长</a></span>
</div> <br>
     <?php doAction('log_wuiso', $logData);?><!--上一篇-下一篇--> <nav class="pager wow fadeInUp" role="navigation">

                     <?php neighbor_log($neighborLog, 'nextLog');?>
      </nav>&nbsp<!--上一篇-下一篇--><ul class="rtpica">
	  	  </ul>
     

  
	  	  
      
  
  <!-- 评论开始 -->
	<?php if($allow_remark == 'y'): ?>
	<article class="span12" id="comments" data-aos="<?php echo $aosxg;?>">
	<div id="comments2" class="panel-comments panel-sort">
			<div id="respond" class="comment-respond">
			<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
			</div>
			<?php blog_comments($comments); ?>	
			<!-- #respond -->
		</div>
	</article>
	<?php endif;?>
<!-- 评论结束 --></div>		
  <!--con-left end--><div class="con-right">
 <?php include View::getView('side'); ?>
  <!--con-left end--></div></div></div>
<!--wrapper end-->
<link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>js/lightbox/themes/default/jquery.lightbox.css" />
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/lightbox/jquery.lightbox.min.js"></script>
<script type="text/javascript">
$(function($){
	$(".art-content a").has("img").each(function() {
		$(this).lightbox();
		$(this).attr("rel","xygroup");
	});
});
</script>
<?php
include View::getView('footer');
?><div class="toolbar">
	<a href="#comment-post" class="toolbar-item toolbar-item-feedback"></a>
   <a href="javascript:scroll(0,0)" id="top" class="toolbar-item toolbar-item-top"></a>
</div>