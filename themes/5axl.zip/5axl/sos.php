<?php 
/**
 * 搜索页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<section class="container">
<div class="panel">
					<header class="panel-header">
								<h2 class="post-title"><i class="fa fa-info-circle"></i> 友情提示</h2>
						</header>
				<section class="context">
						<center> <p class="tips">输入关键词搜索即可，例如：emlog , 蓝优</p></center> 
        			
        				<form class="input-group" action="<?php echo BLOG_URL; ?>" method="get">
        					<input type="text" class="form-control search-texts" name="keyword" placeholder="输入关键词搜索..." >
        					<div class="input-group-btn">
        						<button class="btn btn-default">搜索</button>
        					</div>
						
        				</form>
        			
					</section>
				</div>

</section>
<?php include View::getView('footer');?>