<?php 
/**
 * 侧边栏组件、页面模块
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
if (!function_exists('_g')) {
	emMsg('请先下载并安装<a href="http://www.emlog.net/plugin/144" target="_blank">模板设置插件</a>', BLOG_URL . 'admin/plugins.php');
}
?>
<?php //文章访问路径标准化 
function gf_url($id){ 
if ($id){echo '<link rel="canonical" href="'.Url::log($id)."\" />";}
}?>
<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
    define('TEMROOT', EMLOG_ROOT.'/content/templates/'.get_template_name().'/inc');
    $config_file = TEMROOT.'/config.php';
    if (is_file($config_file)) {include $config_file;}
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];
	$db = MySql::getInstance();
    $sta_cache = array();
	$data = $db->once_fetch_array('SELECT COUNT(*) AS total FROM ' . DB_PREFIX . 'blog WHERE type = \'blog\'');
    $log_total = $data['total'];
    $data = $db->once_fetch_array('SELECT COUNT(*) AS total FROM ' . DB_PREFIX . 'comment');
    $log_com = $data['total'];
    $data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "twitter");
    $wei_yu = $data['total'];
	?>
	<li class="widdd widget_ui_blogger">
	    <article class="panel-side">
	        <div class="fly_weibo">
        	<ul class="blogger_side">
        	    <div id="weiboShow">
        	        <div class="grid-weibo-show shadow-hover">
        		        <header id="shead">&nbsp;</header>
        		        <div id="user-login" class="contentt">
        			        <div class="avatar">
        	                	  <img src="<?php if($user_cache[1]['photo']['src']){echo BLOG_URL.$user_cache[1]['photo']['src'];}else{echo TEMPLATE_URL.'img/avatar.png';}?>">
								  <i title="<?php echo $user_cache[1]['name']; ?>" class="author-ident"></i>
        	                	<div class="overlay">
                                    <a href="http://wpa.qq.com/msgrd?v=3&uin=78983438&site=qq&menu=yes" class="expand" data-target="#myLogin" data-toggle="modal" data-backdrop="static" target="_blank">Login</a>
                                </div>
        				        <span class="rank"></span>
        			        </div>
							<h4><?php echo $user_cache[1]['name']; ?></h4>
							<div class="author-social"><span class="author-weibo" style="backgroundd:#009688;border-radius: 6px;"> <a href="post/3"title="投稿奖励1-8元现金红包" rel="nofollow" target="_blank"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>我要投稿</a> </span> <br><br>
								<span class="author-weibo"> <a href="http://wpa.qq.com/msgrd?v=3&uin=78983438&site=qq&menu=yes" rel="nofollow" title="点我联系站长QQ" target="_blank"><i class="fa fa-qq"></i>接通博主</a> </span> </div>
        		        </div>
        		        <div id="user-div" class="contentt" style="display:none;">
        			        <div class="avatar">
        	                	  <img src="<?php if($user_cache[1]['photo']['src']){echo BLOG_URL.$user_cache[1]['photo']['src'];}else{echo TEMPLATE_URL.'img/avatar.png';}?>">
        				        <span class="rank"></span>
        			        </div>
							 <div class="sidebar-user row">
                            </div>
        		        </div>
        		        <footer>
        					<ul class="blogger_footer">
        						<li><strong><?php echo $log_total;?></strong><span>文章</span></li>
        						<li><strong><?php echo $log_com;?></strong><span>评论</span></li>
        						<li><strong><?php echo $wei_yu;?></strong><span>微语</span></li>
        					</ul>
        		        </footer>
        	        </div>
                </div>
            </ul>
            </div>
	    </article>
	</li><?php }?>
<?php //分页函数
function sheli_fy($count,$perlogs,$page,$url,$anchor=''){
$pnums = @ceil($count / $perlogs);
$page = @min($pnums,$page);
$prepg=$page-1;                 //shuyong.net上一页
$nextpg=($page==$pnums ? 0 : $page+1); //shuyong.net下一页
$urlHome = preg_replace("|[\?&/][^\./\?&=]*page[=/\-]|","",$url);
//开始分页导航内容
$re = "";
if($pnums<=1) return false;	//如果只有一页则跳出	
if($page!=1) $re .="<li class=\"next-page\"><a href=\"$urlHome$anchor\">首页</a></li>\n"; 
if($prepg) $re .="<li class=\"next-page\"><a href=\"$url$prepg$anchor\" >上一页</a></li>\n";
for ($i = $page-2;$i <= $page+2 && $i <= $pnums; $i++){
if ($i > 0){if ($i == $page){$re .= "<li class=\"active\"><span>$i</span></li>\n";
}elseif($i == 1){$re .= "<li><a href=\"$urlHome$anchor\">$i</a></li>\n";
}else{$re .= "<li><a href=\"$url$i$anchor\">$i</a></li>\n";}
}}
if($nextpg) $re .="<li class=\"next-page\"><a href=\"$url$nextpg$anchor\" class='nextpages'>下一页</a></li>\n"; 
if($page!=$pnums) $re.=" <li class=\"next-page\"><a href=\"$url$pnums$anchor\" title=\"尾页\">尾页</a></li>\n";
return $re;}
?>


<?php
//widget：日历
function widget_calendar($title){ ?>
	<li class="box-b mb20 p10">
    <span class="arrow-right"></span>
    <h3 class="title"><span><?php echo $title; ?></span></h3>
	<div id="calendar">
	</div>
	<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
	</li>
<?php }?>
<?php
//widget：彩色标签
function widget_tag($title){global $CACHE;$tag_cache = $CACHE->readCache('tags');?>
<div class="widget"> <h3 style="text-align: center;"><span class="icon"><i class="fa fa-tags"></i></span>
  <?php echo $title; ?></h3>
  <ul id="blogtags">
    <li>
      <?php shuffle ($tag_cache);
		$tag_cache = array_slice($tag_cache,0,28);foreach($tag_cache as $value):?>
      <a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?>篇文章">
      <?php if(empty($value['tagname'])){ echo "无标签";}else{echo $value['tagname'];}?>
      </a>
      <?php endforeach; ?>
    </li>
  </ul>
</div>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	<li class="box-b mb20">
    <span class="arrow-right"></span>
    <h3 class="title pt10 pl10"><span><?php echo $title; ?></span></h3>
	<ul class="ullist2 sidesort">
	<?php
	foreach($sort_cache as $value):
		if ($value['pid'] != 0) continue;
	?>
	<li>
 	<a href="<?php echo Url::sort($value['sid']);?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
	<?php if (!empty($value['children'])): ?>
		<ul style="display:none">
		<?php
		$children = $value['children'];
		foreach ($children as $key):
			$value = $sort_cache[$key];
		?>
		<li>
			<a  href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
		</li>
		<?php endforeach; ?>
		</ul>
    </li>
	<?php endif; ?>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：最新微语
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
    $color3 = '(3, 195, 102)';
	$color1 = '(255, 144, 136)';
	$color4 = '(0, 175, 240)';
	$color2 = '(255, 169, 0)';
	?>
	<li class="box-a mb20">
    <h3 class="title pt5 pl10"><span><?php echo $title; ?></span></h3>
	<ul class="newlist">
		<?php $i=1;foreach($newtws_cache as $value){?>
		<?php $img = empty($value['img']) ? "" : '<a title="查看图片"  class="t_img" href="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" target="_blank">&nbsp;</a>';?>
		<li>
		<p style="color:rgb<?php if($i==1){?><?php echo $color1;?>
	  <?php }else if($i==2){ ?><?php echo $color2;?>
      <?php }else if($i==3){ ?><?php echo $color3;?>
		 <?php }else{ ?><?php echo $color4;?>
		<?php }?>;"><?php if($i==1){?><c style="color:#fff;background:#ff9088;padding:1px 4px;border-radius:3px"><?php echo $i;?></c>.
			<?php }else if($i==2){ ?><c style="color:#fff;background:#ffa900;padding:1px 4px;border-radius:3px"><?php echo $i;?></c>.
      <?php }else if($i==3){ ?><c style="color:#fff;background:#03c366;padding:1px 4px;border-radius:3px"><?php echo $i;?></c>.
		 <?php }else{ ?><c style="color:#fff;background:#00aff0;padding:1px 4px;border-radius:3px"><?php echo $i;?></c>.
		<?php }?><?php echo preg_replace("/\[F(([1-4]?[0-9])|50)\]/",'<img alt="face" src="'.TEMPLATE_URL.'img/face/$1.gif"  />',$value['t']);echo date('（Y年n月j日）',$value['date']);?>
				</p><>
	<?php $i++; } ?>
	</ul>
	<>
<?php }?>
<?php
function commtent_title($gid){
 $db = MySql::getInstance();
 $sql = "SELECT title FROM ".DB_PREFIX."blog WHERE hide='n' and gid in ($gid) ORDER BY `date` DESC LIMIT 0,1";
 $list = $db->query($sql);while($row = $db->fetch_array($list)){return $row['title'];}}?>
<?php
//widget：最新评论
function widget_newcomm($title){
    global $CACHE; 
    $com_cache = $CACHE->readCache('comment');
    ?>
    <li class="widget span12 widget_recent_comments" data-aos="fade-down">
		<h3 class="widget h3" style="text-align: center;background:#fff"><c><i class="fa fa-comments-o">&nbsp;</i><?php echo $title; ?></c></h2>
		<ul class="sidebar-comments-list show-avatars side-ul">
        <?php
        foreach($com_cache as $value):
        $url = Url::comment($value['gid'], $value['page'], $value['cid']);
	    $title = commtent_title($value['gid']);
        ?>
        <li>
            <a href="<?php echo $url; ?>" title="【<?php echo $title; ?>】来自【<?php echo $value['name'];?>】的评论">
                <img alt="<?php echo $value['name'];?>" src="<?php echo getqqpic($value['mail']);?>" class="avatar avatar-36 photo" height="36" width="36" >
				<div class="right-box"><p class="comment-text"><?php echo sidecomcontent($value['content']); ?></p></div>
            </a>
        </li>
        <?php endforeach; ?>
    </ul>

</li>
<?php }?>
<?php
//widget：最新文章
function widget_newlog($title){
$index_newlognum = Option::get('index_newlognum');?>
<div class="widget widget_ui_posts wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;"><h3 class="title1 pt10 pl10" style="color:#FFFFFF;"><?php echo $title; ?></h3><ul>
<?php 
$db = MySql::getInstance();
$sql = $db->query ("SELECT * FROM ".DB_PREFIX."blog inner join ".DB_PREFIX."sort WHERE hide='n' AND type='blog' AND top='n' AND sortid=sid order by date DESC limit 0,$index_newlognum"); 
while($row = $db->fetch_array($sql)){
		$img_url = '';
        if(pic_thumb($row['content'])){
            $img_url = pic_thumb($row['content']);
        }
        elseif(picthumb($row['gid'])){
            $img_url = picthumb($row['gid']);
        }else{
            $img_url = TEMPLATE_URL.'pic/ap'.rand(1,49).'.jpg'; } 
?>
	<li><a href="<?php echo Url::log($row['gid']);?>"><span class="thumbnail"><img class="thumb" src="<?php echo $img_url; ?>" style="display: block;"></span><span class="text"><?php echo $row['title'];?></span><i class="fa fa-clock-o fa-fw"></i><span class="muted"><?php echo gmdate('Y-m-d', $row['date']);?></span>
	<i class="fa fa-eye"></i>
		<span class="muted"><?php echo $row['views'];?></span></a>
	</li>
	<?php }?>
</ul></div>
<?php }?>
<?php
//widget：热门文章
function widget_hotlog($title){$index_hotlognum = Option::get('index_hotlognum');$Log_Model = new Log_Model();$randLogs = $Log_Model->getHotLog($index_hotlognum);?>
<li class="box-b mb20">
    <span class="arrow-right"></span>
    <h3 class="title pt10 pl10"><span><i class="fa fa-fire"></i>&nbsp;<?php echo $title; ?></span></h3>
  <ul class="ullist2">
    <?php $i=1;foreach($randLogs as $value){?>
    <li>
      <?php if($i==1){?>
      <em><img src="http://www.5axl.com/content/templates/5axl/images/1.gif" width="13" height="13" alt="1" style="margin-right:4px;"></em>
      <?php }else if($i==2){ ?>
      <em><img src="http://www.5axl.com/content/templates/5axl/images/2.gif" width="13" height="13" alt="1" style="margin-right:4px;"></em>
      <?php }else if($i==3){ ?>
     <em><img src="http://www.5axl.com/content/templates/5axl/images/3.gif" width="13" height="13" alt="1" style="margin-right:4px;"></em>
		<?php }else if($i==4){ ?>
      <em><img src="http://www.5axl.com/content/templates/5axl/images/4.gif" width="13" height="13" alt="1" style="margin-right:4px;"></em>
		<?php }else if($i==5){ ?>
      <em><img src="http://www.5axl.com/content/templates/5axl/images/5.gif" width="13" height="13" alt="1" style="margin-right:4px;"></em>
		<?php }else if($i==6){ ?>
		<em><img src="http://www.5axl.com/content/templates/5axl/images/6.gif" width="13" height="13" alt="1" style="margin-right:4px;"></em>
      <?php }else{ ?>
      <em><img src="http://www.5axl.com/content/templates/5axl/images/4.gif" width="13" height="13" alt="1" style="margin-right:4px;"></em>
      <?php }?>
      <a title="<?php echo $value['title']; ?>" href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a> </li>
    <?php $i++; } ?>
  </ul>
</li>
<?php }?>
<?php
//widget：随机文章
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	<li class="box-b mb20">
    <span class="arrow-right"></span>
    <h3 class="title1 pt10 pl10"><span><i class="random fa fa-random current"></i>&nbsp;<?php echo $title; ?></span></h3>
	<ul class="ullist2">
		<?php $i=1;foreach($randLogs as $value){?>
    <li>
       <?php if($i==1){?>
		<em style="    width: 16px;
    height: 16px;
    border-radius: 10px;
    color: #fff;
    line-height: 18px;
    text-align: center;
    font-style: normal;
    padding: 0px 0px 1px 0px;
    display: inline-block;background-color: #ff5e5c;">1</em>
      <?php }else if($i==2){ ?>
      <em style=" width: 16px;
    height: 16px;
    border-radius: 10px;
    color: #fff;
    line-height: 18px;
    text-align: center;
    font-style: normal;
    padding: 0px 0px 1px 0px;
    display: inline-block;background-color:  #0cf;">2</em>
      <?php }else if($i==3){ ?>
     <em style=" width: 16px;
    height: 16px;
    border-radius: 10px;
    color: #fff;
    line-height: 18px;
    text-align: center;
    font-style: normal;
    padding: 0px 0px 1px 0px;
    display: inline-block;background-color: #03bf03;">3</em>
		<?php }else if($i==4){ ?>
      <em style=" width: 16px;
    height: 16px;
    border-radius: 10px;
    color: #fff;
    line-height: 18px;
    text-align: center;
    font-style: normal;
    padding: 0px 0px 1px 0px;
    display: inline-block;background-color: #ffa900;"><?php echo $i;?></em>
		<?php }else if($i==5){ ?>
      <em style=" width: 16px;
    height: 16px;
    border-radius: 10px;
    color: #fff;
    line-height: 18px;
    text-align: center;
    font-style: normal;
    padding: 0px 0px 1px 0px;    display: inline-block;background-color: #0fc;"><?php echo $i;?></em>
		<?php }else if($i==6){ ?>
  <em style=" width: 16px;
    height: 16px;
    border-radius: 10px;
    color: #fff;
    line-height: 18px;
    text-align: center;
    font-style: normal;
    padding: 0px 0px 1px 0px;
    display: inline-block;background-color: #ff5e5c;"><?php echo $i;?></em>
      <?php }else{ ?>
      <em><img src="http://www.5axl.com/content/templates/5axl/images/4.gif" width="13" height="13" alt="1" style="margin-right:4px;"></em>
      <?php }?>
		<c style="color:red"><a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>"><?php echo $value['title']; ?></a></c></li>
	<?php $i++; } ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
	<li style="display:none">
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="logsearch">
	<form name="keyform" method="get" action="<index.php?php echo BLOG_URL; ?>index.php">
	<input name="keyword" class="search" type="text" />
	</form>
	</ul>
	</li>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
	<li class="box-b mb20">
    <span class="arrow-right"></span>
    <h3 class="title pt10 pl10"><span><?php echo $title; ?></span></h3>
	<ul class="ullist2">
	<?php foreach($record_cache as $value): ?>
	<li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
	<li class="box-b mb20">
    <span class="arrow-right"></span>
    <h3 class="title pt10 pl10"><span><?php echo $title; ?></span></h3>
	<div class="zz-list lh200 p10">
	<?php echo $content; ?>
	</div>
	</li>
<?php } ?>
<?php
//widget：链接
function ilinks(){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
    //if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
	?>
<?php foreach($link_cache as $value): $color = dechex(rand(0,1677721));  ?>

    <li style="border:1px #ddd solid;padding:2px;">
		  <p><img src="https://www.google.cn/s2/favicons?domain=<?php echo $value['url']; ?>" width="16" height="16"></p>&nbsp;<a href="<?php echo $value['url']; ?>"  style="color:#<?php echo $color;?>;" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
<?php endforeach; ?>
<?php }?> 
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	?>
	<?php
	foreach($navi_cache as $value):
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
        $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'navhome' : 'common';
		?>
		<li class="item <?php echo $current_tab;?>">
			<a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a>
			<?php if (!empty($value['children'])) :?>
            <ul class="sub-nav">
                <?php foreach ($value['children'] as $row){
                        echo '<li><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></li>';
                }?>
			</ul>
            <?php endif;?>

            <?php if (!empty($value['childnavi'])) :?>
            <ul class="sub-nav">
                <?php foreach ($value['childnavi'] as $row){
                        $newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';
                        echo '<li><a href="' . $row['url'] . "\" $newtab >" . $row['naviname'].'</a></li>';
                }?>
			</ul>
            <?php endif;?>

		</li>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：置顶
function topflg($istop){
	$topflg = $istop == 'y' ? "<span class=\"good-label\">置顶</span><i class=\"good-arrow\"></i>" : '';
	echo $topflg;
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
    <a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
	<?php endif;?>
<?php }?>
<?php
//blog：文章标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '<span class="icon icon-00"></span>关键词:';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "<a rel=\"tag\" href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
		}
		echo $tag; }
	else {$tag = '这篇文章木有标签';
		echo $tag;}
}
?>
<?php
//blog：文章作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog):?>
	    <li class="previous">
		<a title="<?php echo $prevLog['title'];?>" href="<?php echo Url::log($prevLog['gid']) ?>">上一篇：<?php echo $prevLog['title'];?></a>
		</li>
	<?php endif;?>
	<?php if($nextLog && $prevLog):?>
	<?php endif;?>
	<?php if($nextLog):?>
	<li class="next">		
	<a title="<?php echo $nextLog['title'];?>" href="<?php echo Url::log($nextLog['gid']) ?>">下一篇：<?php echo $nextLog['title'];?></a>
	</li>
	<?php endif;?>
<?php }?>


<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>
<?php
//getlist相关文章
function get_list($sort){
$db = MySql::getInstance();
$sql2 = "SELECT gid,title,date FROM ".DB_PREFIX."blog WHERE sortid=".$sort."  AND hide='n' ORDER BY `date` DESC LIMIT 6";
$list = $db->query($sql2);
while($row = $db->fetch_array($list)){
$row['date'] += $timezone * 3600000;
	 $img_url = '';
        if(pic_thumb($row['content'])){
            $img_url = pic_thumb($row['content']);
        }
        elseif(picthumb($row['gid'])){
            $img_url = picthumb($row['gid']);
        }else{
			$img_url = TEMPLATE_URL.'pic/wuiso/tb'.rand(1,40).'.jpg';
        }
?>

<li><a href="<?php echo Url::log($row['gid']); ?>"><img src="<?php echo $img_url; ?>" alt="<?php echo $row['title']; ?>" /></a><div class="text rtpica"><a href="<?php echo Url::log($row['gid']); ?>"><?php echo $row['title']; ?></a></div></li>

	<?php }?>
<?php } ?>
<?php
//首页分类列表
function cmslist($sort){
	$db = MySql::getInstance();
	?>
	<?php
	$sql1 = "SELECT sortname FROM ".DB_PREFIX."sort WHERE sid=".$sort;
	$s = $db->query($sql1);
	$sortname = $db->fetch_array($s);
	
	?>
    <div class="cmslist">
    	<div class="xyti">
            <h3><?php echo $sortname['sortname'];?></h3>
            <div class="tline"></div>
            <a href="<?php echo Url::sort($sort);?>"class="more"><img src="<?php echo TEMPLATE_URL; ?>images/more.gif" alt="" /></a>
        </div>
        <ul>
	<?php
        $result = $db->query("SELECT * FROM ".DB_PREFIX."sort WHERE sid=".$sort ." or pid='$sort'");
        $all = array();
        while ($row = $db->fetch_array($result)) {
            $all[] = $row;
        }
        $sorts = array();
        $sortids = array();
        foreach($all as $v){
            $sorts[$v['sid']] = $v;
            $sortids[] = $v['sid'];
        }
        if(!$sortids){
            $sortids[] = 0;
        }
	$sql2 = "SELECT gid,title,date,sortid FROM ".DB_PREFIX."blog WHERE sortid in(".  join(",", $sortids).") AND hide='n' ORDER BY `date` DESC LIMIT 8";
	$list = $db->query($sql2);
	$iiiii=1;
	while($row = $db->fetch_array($list)){
            $sort = isset($sorts[$row['sortid']])?$sorts[$row['sortid']]:array();
			$nowtime = date('Y-m-d');
			$endtime = gmdate('Y-m-d',$row['date']);
	?>
    		<li><img src="<?php echo TEMPLATE_URL; ?>images/<?php echo $iiiii++; ?>.gif" width="13" height="13" alt="1" style="margin-right:4px;" />
    		<span class="cms_daye_time" style="font-size:13px;float:right;<?php if($nowtime==$endtime) echo "color:red"; ?>">&nbsp;
			<?php echo gmdate('Y-m-d',$row['date']); ?></span><a href="<?php echo Url::log($row['gid']);?>" target="_blank" style="<?php if($nowtime==$endtime) echo "color:red"; ?>"title="<?php echo $row['title'];?>"><?php echo $row['title'];?></a></li>
	<?php }?>
        </ul>
    </div>
<?php } ?>
<?php
//getimage
function picthumb($blogid) {
    $db = MySql::getInstance();
    $sql = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$blogid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";
//    die($sql);
    $imgs = $db->query($sql);
    while($row = $db->fetch_array($imgs)){
        $pict.= ''.BLOG_URL.substr($row['filepath'],3,strlen($row['filepath'])).'';
    }
    return $pict;
}
?>
<?php
//getimageurl
function pic_thumb($content){
    preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $content, $img);
    $imgsrc = !empty($img[1]) ? $img[1][0] : '';
    if($imgsrc):
        return $imgsrc;
    endif;
}
?>
<?php
//首页幻灯
function indexslide($sort, $num,$lastday=0){
    $db = MySql::getInstance();    
    $where = "hide='n'";
    if($sort){
        $sort = explode(',',$sort);
        $sort = array_map("intval",$sort);
        $where .= " AND sortid IN(".join(',',$sort).") ";
    }
    if($lastday){
        $where .= " AND date>='".(time()-$lastday*86400)."'";
    }
    $sql = "SELECT gid,title,excerpt,content,sortid FROM ".DB_PREFIX."blog WHERE $where ORDER BY `date` DESC LIMIT 0,$num";
    $go = $db->query($sql);
    while($row = $db->fetch_array($go)){
        $img_url = '';
        if(pic_thumb($row['content'])){
            $img_url = pic_thumb($row['content']);
        }
        elseif(picthumb($row['gid'])){
            $img_url = picthumb($row['gid']);
        }else{
            $img_url = TEMPLATE_URL.'pic/ap'.rand(1,49).'.jpg';
        }?>
        <li><a href="<?php echo Url::log($row['gid']); ?>"><img src="<?php echo $img_url; ?>" alt="<?php echo $row['title']; ?>" width="765" height="400" /></a></li>
    <?php		}
}
?>
<?php
//右边栏图列
function sideplist($sort, $num,$lastday=0){
    $db = MySql::getInstance();    
    $where = "hide='n'";
    if($sort){
        $sort = explode(',',$sort);
        $sort = array_map("intval",$sort);
        $where .= " AND sortid IN(".join(',',$sort).") ";
    }
    if($lastday){
        $where .= " AND date>='".(time()-$lastday*86400)."'";
    }
    $sql = "SELECT gid,title,excerpt,content,sortid FROM ".DB_PREFIX."blog WHERE $where ORDER BY `date` DESC LIMIT 0,$num";
    $go = $db->query($sql);
    while($row = $db->fetch_array($go)){
        $img_url = '';
        if(pic_thumb($row['content'])){
            $img_url = pic_thumb($row['content']);
        }
        elseif(picthumb($row['gid'])){
            $img_url = picthumb($row['gid']);
        }else{
			$img_url = TEMPLATE_URL.'pic/wuiso/tb'.rand(1,40).'.jpg';
        }?>
        <li><a href="<?php echo Url::log($row['gid']); ?>"><img src="<?php echo $img_url; ?>" alt="<?php echo $row['title']; ?>" /></a><div class="text"><a href="<?php echo Url::log($row['gid']); ?>"><?php echo $row['title']; ?></a></div></li>
    <?php		}
}
?>
<?php
//自动为文章标签添加该标签的链接
function tag_link($content){
    global $CACHE;
        $tag_cache = $CACHE->readCache('tags');
        foreach($tag_cache as $value){
                $tag_url = Url::tag($value['tagurl']);
                $keyword = $value['tagname'];
                $cleankeyword = stripslashes($keyword);
                $url = "<a href=\"{$tag_url}\" title=\"浏览关于“{$cleankeyword}”的文章\" target=\"_blank\" >{$cleankeyword}</a>";
                $regEx = '\'(?!((<.*?)|(<a.*?)))('. $cleankeyword . ')(?!(([^<>]*?)>)|([^>]*?</a>))\'s';
                $content = preg_replace($regEx,$url,$content);
        }
        return $content;
}
?>

<?php
//判断内容页是否百度收录
function baidu($url){
$url='http://www.baidu.com/s?wd='.$url;
$curl=curl_init();curl_setopt($curl,CURLOPT_URL,$url);curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);$rs=curl_exec($curl);curl_close($curl);if(!strpos($rs,'没有找到')){return 1;}else{return 0;}}
 
function logurl($id){$url=Url::log($id);
if(baidu($url)==1){echo "<a style=\"color:#1EA83A;\" rel=\"external nofollow\" title=\"点击查看！\" target=\"_blank\" href=\"http://www.baidu.com/s?wd=$url\">[百度已收录]</a>";
}else{echo "<a style=\"color:red;\" rel=\"external nofollow\" title=\"点击提交收录！\" target=\"_blank\" href=\"http://zhanzhang.baidu.com/sitesubmit/index?sitename=$url\">[百度未收录]</a>";}}
?>


<?php
//文章分享
function share() {
	echo '
<li title="分享文章" class="open"><i class="fa fa-share-alt"></i></li>
<div class="Share">
	<ul>
		<p class="close"><i class="fa fa-share-alt-square"></i> 分享到各大社区<a href="javascript:;" title="关闭"></a></p>
		<li title="分享到QQ空间"><a class="share1"></a></li>
		<li title="分享到新浪微博"><a class="share2"></a></li>
		<li title="打开微信，点击底部的“发现”，使用“扫一扫”即可将网页分享至朋友圈"><a class="share3"></a></li>
		<li title="分享到QQ"><a class="share4"></a></li>
		<li title="分享到腾讯微博"><a class="share5"></a></li>
		<li title="分享到开心网"><a class="share6"></a></li>
	</ul>
</div>
';
} ?>
<?php
//文章分享
function dashang() {
	echo '
<div id="dashang">
	<ul>
		<p class="close"><i class="fa fa-yen"></i> 选择打赏方式<a href="javascript:;" title="关闭"></a></p>
		<li title="打开微信，点击右上角“加号”，使用“扫一扫”打赏"><a class="wx"></a></li>
		<li title="打开QQ，点击右上角“加号”，使用“扫一扫”打赏"><a class="qq"></a></li>
		<li title="打开支付宝，点击右上角“加号”，使用“扫一扫”打赏""><a class="zfb"></a></li>
	</ul>
</div>
';
} ?>



<?php
//代码压缩
function em_compress_html_main($buffer){
    $initial=strlen($buffer);
    $buffer=explode("<!--em-compress-html-->", $buffer);
    $count=count ($buffer);
    for ($i = 0; $i <= $count; $i++){
        if (stristr($buffer[$i], '<!--em-compress-html no compression-->')){
            $buffer[$i]=(str_replace("<!--em-compress-html no compression-->", " ", $buffer[$i]));
        }else{
            $buffer[$i]=(str_replace("\t", " ", $buffer[$i]));
            $buffer[$i]=(str_replace("\n\n", "\n", $buffer[$i]));
            $buffer[$i]=(str_replace("\n", "", $buffer[$i]));
            $buffer[$i]=(str_replace("\r", "", $buffer[$i]));
            while (stristr($buffer[$i], '  '))
            {
            $buffer[$i]=(str_replace("  ", " ", $buffer[$i]));
            }
        }
        $buffer_out.=$buffer[$i];
    }
    $final=strlen($buffer_out);
    $savings=($initial-$final)/$initial*100;
    $savings=round($savings, 2);
    $buffer_out.="\n<!--压缩前的大小: $initial bytes; 压缩后的大小: $final bytes; 节约：$savings% -->";
    return $buffer_out;
}

//pre不被压缩
function unCompress($content){
    if(preg_match_all('/(crayon-|<\/pre>)/i', $content, $matches)) {
        $content = '<!--em-compress-html--><!--em-compress-html no compression-->'.$content;
        $content.= '<!--em-compress-html no compression--><!--em-compress-html-->';
    }
    return $content;
}
//comment：输出评论人等级
function echo_levels($comment_author_email,$comment_author_url){
	$DB = MySql::getInstance();
	global $CACHE;
	$user_cache = $CACHE->readCache('user'); 
	$adminEmail = '"'.$user_cache[1]['mail'].'"';
	if($comment_author_email==$adminEmail){
	echo '<c class="admin" title="管理员认证" style="top:4px;"><img src="'.TEMPLATE_URL.'img/admin.svg" ></c>';
	}
	$sql = "SELECT cid as author_count,mail FROM ".DB_PREFIX."comment WHERE mail != '' and mail = $comment_author_email and hide ='n'";
	$res = $DB->query($sql);

}	
?>

<?php
//获取评论用户操作系统、浏览器等信息
function useragent($info){
	require_once 'useragent.class.php';
	$useragent = UserAgentFactory::analyze($info);
?>
<span class="useragent1"><img src="<?php echo TEMPLATE_URL.$useragent->platform['image']?>" class="side-xt" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="<?php echo $useragent->platform['title']; ?>">&nbsp;
&nbsp; <img src="<?php echo TEMPLATE_URL.$useragent->browser['image']?>" class="side-xt1" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="<?php echo $useragent->browser['title']; ?>"></span>
<?php
}
?>
<?php
//外链IP库 支持https
function get_ips($commentip){
	$ip = @file_get_contents("https://ipip.yy.com/get_ip_info.php?ip=".$commentip."");
	$gs=json_decode(ltrim(rtrim($ip, ";"), "var returnInfo = "),true);
	echo $gs['country'].' '.$gs['province'].' '.$gs['city'];
}

//查看该用户是否评论
function ishascomment($content,$post_id){
	if(preg_match_all('|\[hide\]([\s\S]*?)\[\/hide\]|i', $content, $hide_words)){
		if($_COOKIE['postermail'] && $_COOKIE['postermail'] != ''){
			$r = MySql::getInstance();
			$row=$r->once_fetch_array("SELECT * FROM  `".DB_NAME."`.`".DB_PREFIX."comment` WHERE `mail` =  '".$_COOKIE['postermail']."' and `gid` = '".$post_id."' ORDER BY `date` DESC");
		}else if($_COOKIE['posterurl'] && $_COOKIE['posterurl'] != ''){
			$r = MySql::getInstance();
			$row=$r->once_fetch_array("SELECT * FROM  `".DB_NAME."`.`".DB_PREFIX."comment` WHERE `url` =  '".$_COOKIE['posterurl']."' and `gid` = '".$post_id."' ORDER BY `date` DESC");
		}
		if($row && (time()-$row['date']) <= 3600*24 && $row['hide'] == 'n' || ROLE == "admin"){ //通过的评论在24小时之内
			$content = str_replace($hide_words[0],$hide_words[1], $content);
		}else{
			$hide_notice = '<div style="text-align:center;border:1px dashed #5db8f8;padding:8px;margin:10px auto;color:#5db8f8;"><i class="fa fa-lock"></i> 管理员设置<a href="#comment">回复</a>可见隐藏内容</div>';
			$content = str_replace($hide_words[0], $hide_notice, $content); 
		}
	}
	return $content;
}


//格式化内容工具
function blog_tool_purecontent($content, $strlen = null){
        $content = str_replace('继续阅读>>', '', strip_tags($content));
        if ($strlen) {
            $content = subString($content, 0, $strlen);
        }
        return $content;
}
//字符转换
function number($ssbb) {
	$patterns = array ("0","1","2","3","4","5","6","7","8","9"); 
	$replace = array ("零","一","二","三","四","五","六","七","八","九");
	$ssbb=str_replace($patterns, $replace, $ssbb);
	return $ssbb;
}

//Custom：获取模板目录名称
function get_template_name(){
    $template_name = str_replace(BLOG_URL,"",TEMPLATE_URL);
    $template_name = str_replace("content/templates/","",$template_name);
    $template_name = str_replace("/","",$template_name);
    return $template_name;
}
//blog-tool:获取Gravatar头像并缓存到本地
function SB_getGravatar($email, $s=40, $d='monsterid', $r='g') {
    $f = md5($email);
    $a = TEMPLATE_URL.'img/avatar/'.$f.'.jpg';
    $e = EMLOG_ROOT.'/content/templates/'.get_template_name().'/img/avatar/'.$f.'.jpg';
    $t = 1296000; //15天，单位：秒
    if (empty($d)) $d = BLOG_URL.'avatar/default.jpg';
    if (!is_file($e) || (time() - filemtime($e)) > $t ) {
        //当头像不存在或者超过15天才更新
        $g = sprintf("https://secure.gravatar.com",(hexdec($f{0})%2)).'/avatar/'.$f.'?s=48&d='.$d.'&r='.$r;
        copy($g,$e); $a=$g; //新头像copy时, 取gravatar显示
    }
    if (filesize($e) < 500) copy($d,$e);
    return $a;
}
//吐槽水军
function guest($num){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['name'];
	$DB = MySql :: getInstance();
	$sql = "SELECT count(*) AS comment_nums,poster,mail,url FROM ".DB_PREFIX."comment where date >0 and poster !='". $name ."' and  poster !='' and hide ='n' group by poster order by comment_nums DESC limit 0,$num";
	$log_content = $content[1];
	if(strpos($log_content, '[READERWALL-WEEK]') > -1) {
		$cur_time_span = strtotime('last Year',strtotime('Sunday'));
	}
	$result = $DB -> query( $sql );
	while($row = $DB -> fetch_array($result)){
		$img = "<li><a rel=\"external nofollow\" target=\"_blank\" href=\"" . $row[ 'url' ] . "\" title=\"" . $row[ 'poster' ] ."(赐教" . $row[ 'comment_nums' ] . "次)\"><img  alt=\"avatar\"  src=\"" . getqqpic($row['mail']) . "\" class=\"avatar\"><em>" . $row[ 'poster' ] ."</em><strong>+" . $row[ 'comment_nums' ] . "</strong></a></li>";
		if( $row[ 'url' ] ){
			$tmp = "<li><a rel=\"external nofollow\" target=\"_blank\" href=\"" . $row[ 'url' ] . "\" title=\"" . $row[ 'poster' ] ."(吐槽" . $row[ 'comment_nums' ] . "次)<br>" . $row[ 'url' ] . "\" ><img  alt=\"avatar\"  src=\"" . getqqpic($row['mail']) . "\"><em>" . $row[ 'poster' ] ."</em><strong>+" . $row[ 'comment_nums' ] . "</strong></a></li>";
		}else{
			$tmp = $img;
		}
		$output .= $tmp;
	}
	$output = ''. $output .'';
	return $output ;
}
//获取头像
function getqqpic($email){
	$qq = explode('@',$email);
            $pic = 'https://q2.qlogo.cn/headimg_dl?dst_uin='.$qq[0].'&spec=100';
            $pic = $qq[1] =='qq.com' ? $pic : $pic = SB_getGravatar($email);
	return $pic;
}
//评论内容
function comcontent($pl) {
	$patterns = array ("/@/","/\[blockquote\](.*?)\[\/blockquote\]/","/\[F(([1-4]?[0-9])|50)\]/"); 
	$replace = array ('回复了','<blockquote>$1</blockquote>','<img alt="表情" src="'.TEMPLATE_URL.'img/face/$1.gif" />'); 
	$pl=preg_replace($patterns, $replace, $pl);
	return $pl;
}

//获取blog表的一条内容,$content填写表名
function blog_content($gid,$content){
    $db = MySql::getInstance();
    $sql = 'SELECT * FROM ' . DB_PREFIX . "blog WHERE gid='".$gid."'";
    $sql = $db->query($sql);
    while ($row = $db->fetch_array($sql)) {
        $content = $row[$content];
	}
    return $content;
}
//侧边栏评论
function sidecomcontent($pl) {
	$patterns = array ("/@/","/\[blockquote\](.*?)\[\/blockquote\]/","/\[F(([1-4]?[0-9])|50)\]/"); 
	$replace = array ('回复了','<small>$1</small>','<img alt="表情" src="'.TEMPLATE_URL.'img/face/$1.gif" />'); 
	$pl=preg_replace($patterns, $replace, $pl);
	return $pl;
}
//正则去除HTML
function ClearHtml($content) {  
   $preg = "/<\/?[^>]+>/i";
   return preg_replace($preg,'',$content);
}
//检测是否为手机
function em_is_mobile() {
    static $is_mobile;

    if ( isset($is_mobile) )
        return $is_mobile;

    if ( empty($_SERVER['HTTP_USER_AGENT']) ) {
        $is_mobile = false;
    } elseif ( strpos($_SERVER['HTTP_USER_AGENT'], 'Mobile') !== false
        || strpos($_SERVER['HTTP_USER_AGENT'], 'Android') !== false
        || strpos($_SERVER['HTTP_USER_AGENT'], 'Silk/') !== false
        || strpos($_SERVER['HTTP_USER_AGENT'], 'Kindle') !== false
        || strpos($_SERVER['HTTP_USER_AGENT'], 'BlackBerry') !== false
        || strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mini') !== false
        || strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mobi') !== false ) {
            $is_mobile = true;
    } else {
        $is_mobile = false;
    }

    return $is_mobile;
}
//数据库报错用
function getimgforgid($gid){
    $db = MySql::getInstance();
    $sql = 'SELECT content FROM ' . DB_PREFIX . "blog WHERE gid='".$gid."'";
	$d = $db->once_fetch_array($sql);

	return isset($d['content']) && preg_match("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $d['content'], $img) ? $img[1] : false;
}
function getimgforgids($gid){
    $db = MySql::getInstance();
    $sql = 'SELECT * FROM ' . DB_PREFIX . "blog WHERE gid='".$gid."'";
    $img = $db->query($sql);
	$imgsrc = false;
	if($img){
		while ($row = $db->fetch_array($img)) {
			$content = $row['content'];
			$imgsrc = preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $content, $img);
			$imgsrc = !empty($img[1]) ? $img[1][0] : '';
		}
	}
    return $imgsrc;
}
function gettime($id){
	$db = MySql::getInstance();
	$sql = 'SELECT * FROM ' . DB_PREFIX . "blog WHERE gid='".$id."'";
	$date = $db->query($sql);
	while ($row = $db->fetch_array($date)) {
		$time = date('Y-m-d',$row['date']);
	}
	return $time;
}
//本地IP库
function get_ip($ip) { $dat_path = EMLOG_ROOT.'/content/templates/5axl/lib/ip.dat'; //*数据库路径*//
if(!$fd = @fopen($dat_path, 'rb')){ return 'IP数据库文件不存在或者禁止访问或者已经被删除！';   
    } $ip = explode('.', $ip); $ipNum = $ip[0] * 16777216 + $ip[1] * 65536 + $ip[2] * 256 + $ip[3]; $DataBegin = fread($fd, 4); $DataEnd = fread($fd, 4); $ipbegin = implode('', unpack('L', $DataBegin)); if($ipbegin < 0) $ipbegin += pow(2, 32); $ipend = implode('', unpack('L', $DataEnd)); if($ipend < 0) $ipend += pow(2, 32); $ipAllNum = ($ipend - $ipbegin) / 7 + 1; $BeginNum = 0; $EndNum = $ipAllNum; while($ip1num>$ipNum || $ip2num<$ipNum) { $Middle= intval(($EndNum + $BeginNum) / 2); fseek($fd, $ipbegin + 7 * $Middle); $ipData1 = fread($fd, 4); if(strlen($ipData1) < 4) { fclose($fd); return '系统出错！';   
        } $ip1num = implode('', unpack('L', $ipData1)); if($ip1num < 0) $ip1num += pow(2, 32); if($ip1num > $ipNum) { $EndNum = $Middle; continue;   
        } $DataSeek = fread($fd, 3); if(strlen($DataSeek) < 3) { fclose($fd); return '系统出错！';   
        } $DataSeek = implode('', unpack('L', $DataSeek.chr(0))); fseek($fd, $DataSeek); $ipData2 = fread($fd, 4); if(strlen($ipData2) < 4) { fclose($fd); return '系统出错！';   
        } $ip2num = implode('', unpack('L', $ipData2)); if($ip2num < 0) $ip2num += pow(2, 32); if($ip2num < $ipNum) { if($Middle == $BeginNum) { fclose($fd); return '未知';   
            } $BeginNum = $Middle;   
        }   
    } $ipFlag = fread($fd, 1); if($ipFlag == chr(1)) { $ipSeek = fread($fd, 3); if(strlen($ipSeek) < 3) { fclose($fd); return '系统出错！';   
        } $ipSeek = implode('', unpack('L', $ipSeek.chr(0))); fseek($fd, $ipSeek); $ipFlag = fread($fd, 1);   
    } if($ipFlag == chr(2)) { $AddrSeek = fread($fd, 3); if(strlen($AddrSeek) < 3) { fclose($fd); return '系统出错！';   
        } $ipFlag = fread($fd, 1); if($ipFlag == chr(2)) { $AddrSeek2 = fread($fd, 3); if(strlen($AddrSeek2) < 3) { fclose($fd); return '系统出错！';   
            } $AddrSeek2 = implode('', unpack('L', $AddrSeek2.chr(0))); fseek($fd, $AddrSeek2);   
        } else { fseek($fd, -1, SEEK_CUR);   
        } while(($char = fread($fd, 1)) != chr(0)) $ipAddr2 .= $char; $AddrSeek = implode('', unpack('L', $AddrSeek.chr(0))); fseek($fd, $AddrSeek); while(($char = fread($fd, 1)) != chr(0)) $ipAddr1 .= $char;   
    } else { fseek($fd, -1, SEEK_CUR); while(($char = fread($fd, 1)) != chr(0)) $ipAddr1 .= $char; $ipFlag = fread($fd, 1); if($ipFlag == chr(2)) { $AddrSeek2 = fread($fd, 3); if(strlen($AddrSeek2) < 3) { fclose($fd); return '系统出错！';   
            } $AddrSeek2 = implode('', unpack('L', $AddrSeek2.chr(0))); fseek($fd, $AddrSeek2);   
        } else { fseek($fd, -1, SEEK_CUR);   
        } while(($char = fread($fd, 1)) != chr(0)){ $ipAddr2 .= $char;   
        }   
    } fclose($fd); if(preg_match('/http/i', $ipAddr2)) { $ipAddr2 = '';   
    } $ipaddr = "$ipAddr1 $ipAddr2"; $ipaddr = preg_replace('/CZ88.Net/is', '', $ipaddr); $ipaddr = preg_replace('/^s*/is', '', $ipaddr); $ipaddr = preg_replace('/s*$/is', '', $ipaddr); if(preg_match('/http/i', $ipaddr) || $ipaddr == '') { $ipaddr = '未知';   
    } $ipaddr = iconv('gbk', 'utf-8//IGNORE', $ipaddr); if( $ipaddr != '  ' ) return $ipaddr; else $ipaddr = '评论者来自火星，无法或者其所在地!'; return $ipaddr;   
}
?>


<?php
//blog：评论列表
function blog_comments($comments){
    extract($comments);$comnum = count($comments);
	if($commentStacks):?>
	<header class="panel-header">
		<h3 class="log_h3">
			<span class="fa fa-angellist" style="margin:8px 0 0 12px;">评论</span><div class="righ" style="
    position: relative;
    bottom: 1px;
    left: 66px;
    height: 1px;
background-color: #4398ed;    border: 0;
    margin-top:6px ;
    padding: 0;
    font-size: 100%;
    text-align: left;
    vertical-align: baseline;
    background-image: none;
    background-position: 0 0;
    width: auto;
    float: none;
    overflow: visible;
    text-indent: 0;
"></div></h3>
		<span class="right" style="color:#4398ed"><span class="comments-number"><b style="font-size:18px"><?php echo $comnum; ?></b></span>条评论</span>
	</header>
	<ol class="comments-list show-avatars">
	<?php endif; ?>
	<?php
    $count_comments = count($comments);
    $count_floors = $count_comments;
    foreach($comments as $value){
        if($value['pid'] != 0){ $count_floors--; }
    }
    $page = isset($params[5])?intval($params[5]):1;
    $i= $count_floors - ($page - 1)*Option::get('comment_pnum');
	$isGravatar = Option::get('isgravatar');
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	global $CACHE;$user_cache = $CACHE->readCache('user');$name = $user_cache[1]['name'];
	$patterns = array ("/\[url\](.*?)\[\/url\]/","/\[qq\]([0-9]+)\[\/qq\]/","/\[img=?\]*(.*?)(\[\/img)?\]/e","/\[strong\](.*?)\[\/strong\]/","/\[em\](.*?)\[\/em\]/","/\[del\](.*?)\[\/del\]/","/\[blockquote\](.*?)\[\/blockquote\]/","/\[u\](.*?)\[\/u\]/","/\[code\](.*?)\[\/code\]/"); 
	$replace = array ('<a rel="external nofollow" target="_blank" href="$1">$1 </a>','<a title="点击这里给我发消息" rel="external nofollow" target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=$1&site=qq&menu=yes"><img src="http://wpa.qq.com/pa?p=1:$1:52" alt="点击这里给我发消息" /></a>','"<a target=\"_blank\" href=\"$1\"><img class=\"comment-img\" src=\"$1\" alt=\"" . basename("$1") . "\" /></a>"','<b>$1</b>','<em>$1</em>','<del>$1</del>','<blockquote>$1</blockquote>','<u>$1</u>','<code>$1</code>'); 
	$comment['content']=preg_replace($patterns, $replace, $comment['content']);
	$comment['poster'] = $comment['url'] ? '<a href="/go.php?url='.$comment['url'].'" target="_blank" rel="external nofollow" class="url">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<li class="comment even thread-odd thread-alt depth-1 show-avatars" id="comment-<?php echo $comment['cid']; ?>">
	    <article id="comment-box-<?php echo $comment['cid']; ?>" class="comment-box">
			<?php if($isGravatar == 'y'): ?>
			<img srcset="<?php echo getqqpic($comment['mail']);?>" alt="avatar" class="avatar avatar-42 photo" height="42" width="42"/><?php endif; ?>
			<div class="right-box">
			    <p class="comment-meta"> <span class="author"><?php echo $comment['poster']; ?> <?php echo echo_levels("\"".strip_tags($comment['mail'])."\"","\"".$comment['url']."\"");?></span> <span class="useragent"><?php if(function_exists('display_useragent')){display_useragent($comment['cid']);} ?></span> <span class="reply"><i rel="nofollow" class="comment-reply-link" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)" aria-label="回复"><span class="fa fa-reply-all"></span> 回复</i></span></p>
			    <p><?php echo comcontent($comment['content']); ?></p>
			    <p class="time"><span class="sign"><span class='fa fa-desktop'></span> <?php echo get_ip($comment['ip']);?></span> <time pubdate="pubdate"><span class="fa fa-clock-o"></span> <?php echo $comment['date']; ?></time></p>
			</div>
		</article>
		<ol class="children"><?php blog_comments_children($comments, $comment['children']); $ii=0;?></ol>
	</li>
	<?php $i--;endforeach; ?>
	</ol>
    <nav class="comments-list-nav page-navi">
		<?php echo $commentPageUrl;?>
		<?php if($commentPageUrl): ?>
		<?php endif; ?>
    </nav>
<?php }?>
<?php

//blog：子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	global $CACHE;$user_cache = $CACHE->readCache('user');$name = $user_cache[1]['name'];
	$patterns = array ("/\[url\](.*?)\[\/url\]/","/\[qq\]([0-9]+)\[\/qq\]/","/\[img=?\]*(.*?)(\[\/img)?\]/e","/\[strong\](.*?)\[\/strong\]/","/\[em\](.*?)\[\/em\]/","/\[del\](.*?)\[\/del\]/","/\[blockquote\](.*?)\[\/blockquote\]/","/\[u\](.*?)\[\/u\]/","/\[code\](.*?)\[\/code\]/"); 
	$replace = array ('<a rel="external nofollow" target="_blank" href="$1">$1 </a>','<a title="点击这里给我发消息" rel="external nofollow" target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=$1&site=qq&menu=yes"><img src="http://wpa.qq.com/pa?p=1:$1:52" alt="点击这里给我发消息" /></a>','"<a target=\"_blank\" href=\"$1\"><img class=\"comment-img\" src=\"$1\" alt=\"" . basename("$1") . "\" /></a>"','<b>$1</b>','<em>$1</em>','<del>$1</del>','<blockquote>$1</blockquote>','<u>$1</u>','<code>$1</code>'); 
	$comment['content']=preg_replace($patterns, $replace, $comment['content']);
	$comment['poster'] = $comment['url'] ? '<a href="/go.php?url='.$comment['url'].'" target="_blank" rel="external nofollow" class="url">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<li class="comment byuser comment-author-bing bypostauthor odd alt depth-2 show-avatars" id="comment-<?php echo $comment['cid']; ?>">
			<?php if($isGravatar == 'y'): ?>
			<article id="comment-box-492" class="comment-box">
			    <img srcset="<?php echo getqqpic($comment['mail']);?>" class="avatar avatar-42 photo" height="42" width="42">
			    <div class="right-box">
			        <p class="comment-meta"> <span class="author"><?php echo $comment['poster']; ?> <?php echo echo_levels("\"".strip_tags($comment['mail'])."\"","\"".$comment['url']."\"");?></span> <span class="useragent"><?php if(function_exists('display_useragent')){display_useragent($comment['cid']);} ?></span> <span class="reply"><i rel="nofollow" class="comment-reply-link" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)" aria-label="回复"><span class="fa fa-reply-all"></span> 回复</i></span></p>
			        <p><?php echo comcontent($comment['content']); ?></p></div>
			        <p class="time"><span class="sign1"><span class='fa fa-desktop'></span> <?php echo get_ip($comment['ip']);?></span> <time pubdate="pubdate"><span class="fa fa-clock-o"></span> <?php echo $comment['date']; ?></time></p>
            </article>
			<?php endif; ?>
		<?php blog_comments_children($comments, $comment['children']); $ii++;?>
	</li>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
	<div id="comment-place">
	<div class="comment-post" id="comment-post">
		<h3 id="reply-title" class="comment-reply-title"><span class="fa fa-comments-o"></span> 发表评论 <div class="cancel-reply" id="cancel-reply" style="display:none"><a href="javascript:void(0);" onclick="cancelReply()"><span class="fa fa-share"></span> 取消回复</a></div></h3>
		<form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
			<input type="hidden" name="gid" id="comment-gid" value="<?php echo $logid; ?>" />
			<input type="hidden" name="pid" id="comment-pid" value="0"/>
			<p class="comment-notes"><span id="email-notes">电子邮件地址不会被公开。</span> 必填项已用<span class="required">*</span>标注</p>
			<textarea id="comment" class="form-control comment-form-comment textarea" style="padding:12px 0 0 0px;margin-right:12px;" placeholder="走过路过，请留下你宝贵的字迹好吗？" name="comment" tabindex="4" cols="45" rows="10"></textarea>
			<?php if(ROLE == ROLE_VISITOR): ?>
        <input class="form-control comment-form-qq" placeholder="QQ(快速自动填写）" id="qqhao" name="qq" maxlength="10" type="text" value="" tabindex="0" size="10">
			<input class="form-control comment-form-author" placeholder="昵称" id="author" name="comname" maxlength="20" type="text" value="<?php echo $ckname; ?>" tabindex="1" size="22">
        <input class="form-control comment-form-email" placeholder="邮箱(填写邮箱加速升级)" id="email" name="commail" maxlength="30" type="email" value="<?php echo $ckmail; ?>" tabindex="2" size="22">
		<input class="form-control comment-form-url" placeholder="网站(选填)" id="url" name="comurl" maxlength="30" type="url" value="<?php echo $ckurl; ?>" tabindex="3" size="22">
			<?php endif; ?>
			<p class="form-submit"><?php if(ROLE == ROLE_VISITOR){if(Option::get('comment_code') == 'y'){?><span class="ajaximgcode"><?php echo $verifyCode; ?></span><?php }};?><button type="submit" id="submit" class="btn btn-default" tabindex="6">发表评论</button>
            <div id="error"></div><div id="ajaxloading"></div>
			<div id="error1"></div><div id="ajaxloading1"></div>
			</p>
			<div class="comment-form-smiley no-js-hide" onclick="embedSmiley()"><div class="opensmile" title="插入表情" class="button">
			<span class="fa fa-smile-o" style="top:2px"></span></div><div class="smiley-box" style="display:none"><?php include View::getView('inc/smile');?></div></div>
			<div title="打卡" onclick="javascript:SIMPALED.Editor.daka();this.style.display='none'" class="daka"><i class="fa fa-pencil"></i></div>
			<div title="赞" onclick="javascript:SIMPALED.Editor.zan();this.style.display='none'" class="zan"><i class="fa fa-thumbs-o-up"></i></div>
			<div title="踩" onclick="javascript:SIMPALED.Editor.cai();this.style.display='none'" class="cai"><i class="fa fa-thumbs-o-down"></i></div>
		<div title="插入图片" onclick="embedImage()"  class="cai"><i class="fa fa-image"></i></div></form>
	</div>
	</div>
	<?php endif; ?>
<?php }?>





<?php //调用指定分类的名称、别名、发布文章数、描述及部分文章
function sl_sortlog(){$db=MySql::getInstance();global $CACHE;$sort_cache = $CACHE->readCache('sort');foreach(array(1,2,3) as $key => $i){$key = $key+1;?>
<a href="<?php echo Url::sort($i);?>" title="<?php echo $sort_cache[$i]['sortname'];?>"><?php echo $sort_cache[$i]['sortname'];?></a>
<?php echo strtoupper($sort_cache[$i]['alias']);?> (<?php echo $sort_cache[$i]['lognum'];?>)<br />
<?php echo $sort_cache[$i]['description'];?><br />
<?php $logs = $db->query("SELECT * FROM ".DB_PREFIX."blog WHERE sortid='$i' AND type='blog' AND hide='n' order by date DESC limit 0,5"); while($row = $db->fetch_array($logs)){$date = gmdate('m-d', $row['date']);$row['title']= mb_substr($row['title'],0,40,'utf-8');?>
<a href="<?php echo Url::log($row['gid']);?>" title="<?php echo $row['title'];?>"><?php echo $row['title'];?></a><?php echo $date;?><br />
<?php }?><br /><?php }}?>
<?php
function sheli_cc(){
       session_start();
$timestampcc = time();
$cc_nowtime = $timestampcc;
if(isset($_SESSION['cc_lasttime'])){$cc_lasttime = $_SESSION['cc_lasttime'];$cc_times = $_SESSION['cc_times']+1;$_SESSION['cc_times'] = $cc_times;
}else{$cc_lasttime = $cc_nowtime;$cc_times = 1;$_SESSION['cc_times'] = $cc_times;$_SESSION['cc_lasttime'] = $cc_lasttime;} 
if(($cc_nowtime-$cc_lasttime)<50){if($cc_times>=9){header(sprintf('Location:%s', 'http://127.0.0.1'));exit;}//50秒内刷新9次以上可能为cc攻击
}else{$cc_times = 0;$_SESSION['cc_lasttime'] = $cc_nowtime;$_SESSION['cc_times'] = $cc_times;}
}
?>

