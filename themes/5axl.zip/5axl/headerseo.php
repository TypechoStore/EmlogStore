<?php
if(!defined('EMLOG_ROOT')) {exit('error!');}
 
global $CACHE;
 
$Have_Sort_Cache = $CACHE->readCache('sort');
$Have_User_Cache = $CACHE->readCache('user');
$Have_Options_Cache = $CACHE->readCache('options');
$Have_Log_Cache_Tags = $CACHE->readCache('logtags');
$Have_Log_Cache_Sort = $CACHE->readCache('logsort');
 
$Log_Model = new Log_Model();
 
if($type=='blog'){
    extract($Log_Model->neighborLog($timestamp));
}
 
$Body_Title = $Have_Options_Cache['site_title'] ? $Have_Options_Cache['site_title'] : $Have_Options_Cache['blogname'];
 
if( $params[1]=='page' ){
    $Body_Page = '第'.htmlspecialchars(urldecode($params[2])).'页_';
}
 
if( $params[4]=='page' ){
    $Body_Page = '第'.htmlspecialchars(urldecode($params[5])).'页_';
}
 
if($tws){
    preg_match_all('|^.*/\?(page)=(\d+)([\?&].*)?$|',Dispatcher::setPath(),$Preferred);
    $emDispatcher = Dispatcher::setPath();
    if( $Preferred[1][0]=='page' ){
        $Body_Page = '第'.htmlspecialchars(urldecode($Preferred[2][0])).'页_';
    }
}
 
if (!empty($Have_Log_Cache_Tags[$logid])) {
    foreach ($Have_Log_Cache_Tags[$logid] as $value) {
        $Have_Log_key .= $value['tagname'].',';
    }
}
 
if(!empty($Have_Log_Cache_Sort[$logid])){
    $Log_Sort_Name = $Have_Log_Cache_Sort[$logid]['name'];
}
 
if(empty($Have_Log_key)){
    $Log_KeyWords = stripslashes($Log_Sort_Name);
}else{
    $Log_KeyWords = $Have_Log_key;
}
 
if( blog_tool_ishome() ){
 
    $web_title = $Have_Options_Cache['site_title'];
    $web_keywords = $Have_Options_Cache['site_key'];
    $web_description = $Have_Options_Cache['site_description'];
    
}elseif( $params[1]=='sort' ){
    
    $web_title = $Have_Sort_Cache[$sortid]['sortname'].'_'.$Body_Page.$Body_Title;
    $web_keywords = $Have_Sort_Cache[$sortid]['sortname'];
    $web_description = $Have_Sort_Cache[$sortid]['description'];
    
}elseif( $params[1]=='tag' ){
    
    $web_title = stripslashes($tag).'_'.$Body_Page.$Body_Title;
    $web_keywords = stripslashes($tag);
    $web_description = $Have_Options_Cache['blogname']."'".stripslashes($tag)."'";
    
}elseif( $params[1]=='keyword' || $params[1]=='?keyword=' ){
    
    $web_title = '搜索结果    '.$keyword.'_'.$Body_Page.$Body_Title;
    $web_keywords = stripslashes($keyword);
    $web_description = $Have_Options_Cache['blogname'].": '".stripslashes($keyword)."' 的搜索結果";
    
}elseif( $params[1]=='author' ){
    
    $web_title = $Have_User_Cache[$author]['name'].'_'.$Body_Page.$Body_Title;
    $web_keywords = $Have_User_Cache[$author]['name'];
    $web_description = $Have_Options_Cache['blogname']."'".$Have_User_Cache[$author]['name']."'";
    
}elseif( $params[1]=='record' ){
    
    $web_title = stripslashes($params[2]).'_'.$Body_Page.$Body_Title;
    $web_keywords = stripslashes($params[2]);
    $web_description = $Have_Options_Cache['blogname'].": '".stripslashes($params[2])."' 的文章列表";
    
}elseif( $type == 'blog' ){
    
    $web_title = stripslashes($log_title).'_'.$Body_Title;
    $web_keywords = $Log_KeyWords;
    $web_description = extractHtmlData($log_content, 90);
 
    if($prevLog){
        $web_prev = "<link rel='prev' title='{$prevLog['title']}' href='".Url::log($prevLog['gid'])."' />";
    }
    
    if($nextLog && $prevLog){
        
    }
    
    if($nextLog){
        $web_next = "<link rel='next' title='{$nextLog['title']}' href='".Url::log($nextLog['gid'])."' />";
    }
    
    $web_canonical = "<link rel='canonical' href='".URL::log($logid)."' />";
    $web_shortlink = "<link rel='shortlink' href='".BLOG_URL."?post={$logid}' />";
    
}elseif( $type == 'page' ){
    
    $web_title = stripslashes($log_title).'_'.$Body_Title;
    $web_keywords = stripslashes($log_title);
    $web_description = extractHtmlData($log_content, 90);
    
}elseif( $tws ){
    
    $web_title = '微语_'.$Body_Page.$Body_Title;
    $web_keywords = stripslashes($log_title);
    $web_description = extractHtmlData($log_content, 90);
    
}
 
echo "<title>{$web_title}</title>\n<meta name=\"generator\" content=\"Emlog ".Option::EMLOG_VERSION."\" />";
 
if( $type == 'blog' ){
    if($prevLog){
        echo "\n".$web_prev;
    }
    
    if($nextLog && $prevLog){
        
    }
    
    if($nextLog){
        echo "\n".$web_next;
    }
    echo "\n".$web_canonical."\n".$web_shortlink;
}
 
echo "\n<meta name=\"keywords\" content=\"{$web_keywords}\" />\n<meta name=\"description\" content=\"{$web_description}\" />";
 
?>