<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!--wrapper begin-->
<div class="wrapper clearfix pt10">
  <div class="con-left">
    <div class="positionbar">
      <ul  class="bread clearfix">
        <li class="ico"><img src="<?php echo TEMPLATE_URL; ?>images/ico_07.png" /></li>
        <li><a href="<?php echo BLOG_URL; ?>">首页</a></li>
        <li>页面</li>
        <li class="last"><?php echo $log_title; ?></li>
      </ul>
    </div>
    <!--articleList begin-->
    <div class="articleList">
      <h1 class="main-tit2"><span class="black f20 fb"><a href="<?php echo Url::log($logid); ?>"><?php echo $log_title; ?></a></span></h1>
    </div>
    <div class="art-content pt10 f16 lh200">
		<?php echo $log_content; ?><div class="home-links"><div class="home-links-tt"><p><i class="fa fa-link"style="color:red;font-size:14px">本站友情链接:</i></p></div>
		<ul style="list-style-type:none"> <font style="font-size:14px">
			<?php ilinks(); ?></font>
      </ul>
</div><br><br><?php doAction('ef_link_echo'); ?>
    </div>
    <!--内容结束--> 
<div class="bdsharebuttonbox"><a href="#" class="bds_more" data-cmd="more"></a><a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a><a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a><a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a><a href="#" class="bds_renren" data-cmd="renren" title="分享到人人网"></a><a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a></div>
<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"16"},"share":{},"image":{"viewList":["qzone","tsina","tqq","renren","weixin"],"viewText":"分享到：","viewSize":"16"},"selectShare":{"bdContainerClass":null,"bdSelectMiniList":["qzone","tsina","tqq","renren","weixin"]}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>
    <div class="bk20"></div>
    <div class="comment">
      <h3 class=" clearfix"><span class="fr">已有 <?php echo $comnum; ?>/<?php echo $views; ?> 人参与</span></h3>
		<?php blog_comments($comments); ?>
        <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    </div>
    <div class="bk30"></div>
    <!--articleList end-->
  </div>
  <!--con-left end-->
  <div class="con-right">
<?php
include View::getView('side');
?>
   </div>
  <!--con-left end-->
</div>
<!--wrapper end-->
</div>
<?php
include View::getView('footer');
?>