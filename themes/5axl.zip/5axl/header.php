<?php
/*
Template Name:媒体范[小蓝美化版]
Description:<font color=red>＊</font>该主题为媒体范1.3美化主题<br><font color=red>＊</font>优化页面宽度，自适应屏幕<br><font color=blue>＊</font>全站整体浅蓝色<br><font color=yellow>＊</font>仿畅言评论,可插入图片自定义表情！<br>模版后续免费升级，联系作者免费授权体验<a href="http://wpa.qq.com/msgrd?v=3&uin=78983438&site=&menu=yes" target="_blank"><img border="0" SRC=http://wpa.qq.com/pa?p=1:78983438:3 alt="点击这里给我发消息"></a><br>当前模板需配合模板设置
Version:1.3
Author:小蓝
Author Url:www.5axl.com
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');('breadcrumb-template');echo sheli_cc();
if(function_exists('emLoadJQuery')) {
    emLoadJQuery();
}

?> 	
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>css/base.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>css/style.css" rel="stylesheet" type="text/css" id="cssfile" />
	<link href="<?php echo TEMPLATE_URL; ?>css/default.css" rel="stylesheet" type="text/css"  />
	
<script src="<?php echo TEMPLATE_URL; ?>js/jquery.js" type="text/javascript"></script>


<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/script.js"></script>
<link href="<?php echo TEMPLATE_URL; ?>css/css.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo TEMPLATE_URL; ?>css/wuiso.css" rel="stylesheet" type="text/css" />
	<script src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js"></script>
    <script src="<?php echo TEMPLATE_URL; ?>js/jquery.pjax.js"></script>	

<script type="text/javascript">
var pjaxtheme = '<?php echo TEMPLATE_URL; ?>';
var pjax_id = '#<?php echo get_template_name(); ?>';

</script>

</head>
	<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
	<!--优化SEO链接-->
<?php if(isset($sortName)): ?>
<link rel="canonical" href="<?php echo Url::sort($sortid);?>" />
<?php elseif(isset($logid)):
if(parse_url('http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'])['path'] != parse_url(Url::log($logid))['path']) header('Location:'.Url::log($logid));?>
<link rel="canonical" href="<?php echo Url::log($logid);?>" />
<?php endif;?>
<!--优化SEO链接-->
<body>
	<STYLE type=text/css> 
BODY{cursor:url('http://www.5axl.com/t/1.cur'), url(./t/2.cur), auto;}
A{cursor:url('http://www.5axl.com/t/3.cur'), url(./t/4.cur), auto;} 
  </STYLE>
<div class="wrapper-outer">
<div class="topBar">
  <div class="wrapper">
    <div class="t-fl"><?php echo $bloginfo; ?></div>
    <div class="t-fr"><a href="<?php echo BLOG_URL; ?>post/3" target="_blank">投稿说明</a><a href="<?php echo BLOG_URL; ?>post/4" target="_blank">广告合作</a><a href="<?php echo BLOG_URL; ?>?plugin=czw_link" target="_blank">友链申请</a></div>
  </div>
</div>
<!--topBar end-->
<div class="header clearfix"><div class="shake shake-opacity">
	<div class="logo">
        <?php if (_g('logotype') == image) :?>
			<a href="<?php echo BLOG_URL; ?>"><img src="<?php echo _g('logopic'); ?>" alt="<?php echo $blogname; ?>" /></a>
		<?php else: ?>
        	<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>
        <?php endif;?>
	</div></div>

    <div class="search-fr">
        <div class="ah_nav_zuo_lim">
        <form action="<?php echo BLOG_URL; ?>index.php" method="get" id="search">
        <input name="keyword" value="请输入关键词" onblur="if(this.value==''){this.value='请输入关键词';}" onfocus="if(this.value=='请输入关键词'){this.value=''}" class="seach_cha" type="text">
			<input value="搜索" class="seach_dian" type="submit"style="">
        </form>
        </div>
    </div>
</div>
<!--header end-->
<div class="wrapper">
<div class="navbar clearfix">
  <div class="pull-left"> 
    <div class="navbg">
      <div class="col960">
        <ul id="navul" class="cl">
        	<?php blog_navi();?>
        </ul>
      </div>
    </div>
  </div>
  <div class="pull-right">
	<ul>
    <li class="weixin"><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo _g('ctqq'); ?>&site=qq&menu=yes" title="QQ联系" target="_blank">QQ联系</a></li>
    <ul/>
    </div><script src="<?php echo TEMPLATE_URL; ?>js/jquery.cookie.js" type="text/javascript"></script>
</div>
	
	
	<style type="text/css">
	.topRec_List li div{ float:left;}
.topRec_List li div:nth-child(1){ width:17%;}
.topRec_List li div:nth-child(2){ width:18%;}
.topRec_List li div:nth-child(3){ width:25%;}
.topRec_List li div:nth-child(4){ width:40%;}

.apple a{display:block; text-decoration:none;}

.apple,.aa{ width:100%; height:18px; overflow:hidden; margin:8px auto; border:1px solid #eaeaea;}
.apple a,.aa a{ width:100%; height:18px; line-height:18px; text-indent:8px; color:#1B96EE;}
.aa {word-wrap:break-word;line-height:18px;  color:#1B96EE;}
	.i {
    border-right: 1px solid #EAEAEA;
  
    float: left;
    color: #666;
    
}
</style>	
	
	<!-- 公告 -->
<script type="text/javascript"> 
	  function autoScroll(obj){  
			$(obj).find("ul").animate({  
				marginTop : "-39px"  
			},500,function(){  
				$(this).css({marginTop : "0px"}).find("li:first").appendTo(this);  
			})  
		}  
		$(function(){  
			setInterval('autoScroll(".maquee")',3000);
			setInterval('autoScroll(".apple")',2000);
			  
		}) 
		
</script> 
<table style="width:100%;" cellpadding="2" cellspacing="5" align="center" border="1" bordercolor="#999999"font-size:15px;>
	<tbody>
		<tr>
			<td height="28" colspan="5" style="font-size:14px;text-align:center;">
				【公告】<i class="fa fa-bullhorn"style="left">:</i>
				
			
			</td><td height="28" colspan="5" style="font-size:14px;">
<article class="excerpt-minic excerpt-minic-index" data-aos="<?php echo $aosxg;?>">			
            <div class="apple"> 	
            	<ul>
            	<?php global $CACHE;$newtws_cache = $CACHE->readCache('newtw');
            		  foreach($newtws_cache as $value):
            	?>
            		<li><a href="<?php echo BLOG_URL.'t';?>"><?php echo preg_replace("/\[F(([1-4]?[0-9])|50)\]/",'<img alt="face" src="'.TEMPLATE_URL.'img/face/$1.gif"  />',$value['t']);echo date('（Y年n月j日）',$value['date']);?></a></li>
					<?php endforeach; ?></ul></div></article>
	</ul>			   </td>
		</tr>
	</tbody>
</table>
		<table cellpadding="0" cellspacing="0" border="1" style="width:100%;font-weight:700;text-align:center;" bordercolor="#333333">
	<tbody>
		<tr><td>
			</td></tr>
	</tbody>
</table><script type="text/javascript">
		//<![CDATA[
		$(function(){
			var $li =$("#skin li");
			$li.click(function(){
				switchSkin( this.id );
			});
			var cookie_skin = $.cookie( "MyCssSkin");
			if (cookie_skin) {
				switchSkin( cookie_skin );
			}
		});
		function switchSkin(skinName){
				 $("#"+skinName).addClass("selected")                 //当前<li>元素选中
							  .siblings().removeClass("selected");  //去掉其它同辈<li>元素的选中
				$("#cssfile").attr("href","<?php echo TEMPLATE_URL; ?>css/"+ skinName +".css"); //设置不同皮肤
				$.cookie( "MyCssSkin" ,  skinName , { path: '/', expires: 10 });
		}
		//]]>
	</script>

<!--navbar end-->  
	