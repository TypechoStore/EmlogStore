<!--
◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◆◇◇◆◆◆◆◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇
◇◇◆◆◆◆◆◆◆◆◆◆◆◆◇◇◇◇◆◆◇◇◆◆◆◆◆◇◇◇◇◆◆◆◆◆◆◆◆◆◆◆◇◇◇◇◆◆◆◆◆◆◆◆◆◆◆◆◆◇◇◇◇◆◆◆◆◆◆◆◆◆◆◇◇
◇◇◆◇◆◇◇◇◇◇◇◇◆◆◇◇◇◇◆◆◇◇◇◆◇◇◆◆◇◇◇◇◇◆◆◇◇◆◇◇◇◆◇◇◇◇◇◇◇◇◇◇◆◆◇◇◇◇◇◇◇◇◇◆◇◇◇◇◇◇◇◇◆◇◇
◇◇◆◇◆◇◇◇◇◇◇◇◆◆◇◇◇◇◆◆◇◇◇◆◇◇◇◆◆◇◇◇◆◆◇◇◇◆◇◇◇◆◇◇◇◇◇◇◇◇◇◆◆◆◇◇◇◇◇◇◇◇◇◆◆◆◆◆◆◆◆◆◆◇◇
◇◇◆◇◆◆◆◆◆◆◆◆◆◆◇◇◇◆◆◆◆◆◆◆◆◆◆◆◆◇◇◇◆◆◇◇◆◆◇◇◆◆◇◇◇◇◇◇◇◇◇◆◆◆◆◇◇◇◇◇◇◇◇◆◇◇◇◇◇◇◇◇◆◇◇
◇◇◇◇◆◇◇◇◇◇◇◇◇◇◇◇◇◆◆◆◆◇◇◆◆◇◇◇◇◇◇◇◆◆◆◆◆◆◇◇◆◆◇◇◇◇◇◇◇◇◆◆◆◆◆◆◇◇◇◇◇◇◇◆◆◆◆◆◆◆◆◆◆◇◇
◇◇◇◆◆◇◇◇◇◇◇◇◇◇◇◇◆◆◆◇◇◇◇◆◆◇◇◇◇◇◇◆◆◇◇◆◆◆◆◆◆◆◆◇◇◇◇◇◆◆◆◇◆◇◆◆◆◇◇◇◇◇◇◇◆◆◇◇◇◇◇◇◇◇◇
◇◇◇◇◆◆◆◆◆◆◆◆◆◆◇◇◆◆◆◇◇◇◇◆◆◇◇◇◇◇◇◆◆◇◇◆◇◇◇◇◇◇◆◆◇◇◇◆◆◆◇◇◆◇◇◇◆◆◇◇◇◇◇◆◆◆◆◆◆◆◆◆◆◆◇
◇◇◇◇◇◇◇◇◇◇◇◇◆◆◇◇◇◇◆◇◇◇◇◆◆◇◇◇◇◇◇◇◆◇◇◆◇◇◇◇◇◇◆◆◇◇◆◆◆◇◇◇◆◇◇◇◇◆◆◇◇◇◆◆◆◇◆◆◇◆◆◇◆◆◇
◇◇◆◆◆◆◆◆◆◆◆◇◆◆◇◇◇◇◆◇◇◇◇◇◆◆◇◇◆◇◇◇◆◇◇◆◆◆◆◆◆◆◆◇◇◇◇◇◇◇◇◇◆◇◇◇◇◇◆◇◇◇◆◇◆◆◆◇◆◆◆◇◆◆◇
◇◇◇◇◇◇◇◇◇◇◇◇◆◆◇◇◇◇◆◇◇◇◇◇◆◆◇◇◆◇◇◇◆◇◇◆◇◇◇◇◇◇◆◇◇◇◇◇◇◇◇◇◆◇◇◇◇◇◇◇◇◇◆◆◆◆◇◆◆◆◇◇◆◆◇
◇◇◇◇◇◇◇◇◆◆◆◆◆◇◇◇◇◇◆◇◇◇◇◇◇◆◆◆◆◇◇◇◆◆◆◆◇◇◇◇◇◇◆◇◇◇◇◇◇◇◇◇◆◇◇◇◇◇◇◇◇◆◆◆◇◆◆◆◆◇◇◇◆◆◇
◇◇◇◇◇◇◇◇◆◆◆◆◆◇◇◇◇◇◆◇◇◇◇◇◇◆◆◆◆◇◇◇◆◆◆◆◇◇◆◆◆◆◆◇◇◇◇◇◇◇◇◇◆◇◇◇◇◇◇◇◇◇◇◆◆◆◆◇◆◆◆◆◆◆◇
◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◆◆◆◆◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◆◇◇◇◇◇◆◆◇◇◇
◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇

◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◆◆◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◆◆◇◇◇◇◇◇◇◇◆◇◇◇◆◇◇◇◆◇◇◇
◇◇◇◆◆◆◆◆◆◆◆◆◇◇◇◇◇◇◆◆◆◆◆◆◆◆◆◆◇◇◇◇◇◆◆◆◆◆◆◆◆◆◇◇◇◇◆◆◆◆◆◆◇◆◆◆◇◇◇◇◇◇◇◆◇◇◇◆◇◇◇◆◇◇◇
◇◇◇◆◆◇◇◇◇◇◇◆◇◇◇◇◇◆◆◇◇◇◇◇◇◇◇◇◇◇◇◇◇◆◆◇◇◇◇◇◇◆◇◇◇◇◇◇◆◇◇◇◆◆◇◆◆◇◇◇◇◇◆◆◇◆◆◆◆◆◆◆◆◆◇
◇◇◇◆◇◇◇◇◇◇◇◆◇◇◇◇◆◆◆◆◇◇◇◇◇◇◇◇◇◇◇◇◇◆◇◇◇◇◇◇◇◆◇◇◇◇◇◇◆◇◇◆◆◇◆◆◆◆◇◇◇◆◆◆◆◇◇◆◇◇◇◆◇◇◇
◇◇◇◆◆◆◆◆◆◆◆◆◇◇◇◇◆◆◆◆◆◆◆◆◆◆◆◆◆◇◇◇◇◆◆◆◆◆◆◆◆◆◇◇◇◇◇◇◆◇◆◆◇◆◆◇◆◆◆◇◇◆◆◆◆◆◇◆◇◇◇◆◇◇◇
◇◇◇◆◇◇◇◇◇◇◇◆◇◇◇◇◇◇◆◆◇◇◇◇◇◆◇◇◇◇◇◇◇◆◇◇◇◇◇◇◇◆◇◇◇◇◇◇◆◇◆◇◆◆◆◆◆◇◆◇◇◆◆◆◆◆◆◆◆◆◆◆◆◆◇
◇◇◇◆◇◇◇◇◇◇◇◆◇◇◇◇◇◆◆◇◇◇◇◇◇◆◇◇◇◇◇◇◇◆◇◇◇◇◇◇◇◆◇◇◇◇◆◆◆◆◆◆◆◆◇◆◆◆◆◇◇◆◆◆◆◆◇◇◇◇◇◇◇◇◇
◇◇◇◆◇◇◇◇◇◇◇◆◇◇◇◇◆◆◆◇◇◇◇◇◇◆◇◇◇◇◇◇◇◆◇◇◇◇◇◇◇◆◇◇◇◇◇◇◆◇◇◆◇◇◆◆◇◆◆◇◇◆◇◆◇◇◆◆◆◆◆◆◆◇◇
◇◇◇◆◆◆◆◆◆◆◆◆◇◇◇◇◆◆◆◇◇◇◇◇◇◆◇◇◇◇◇◇◇◆◆◆◆◆◆◆◆◆◇◇◇◇◇◇◆◇◇◇◆◆◆◇◆◆◇◇◇◆◇◆◇◇◆◇◇◇◇◇◆◇◇
◇◇◇◆◇◇◇◇◇◇◇◆◇◇◇◇◇◇◆◇◇◇◇◇◇◆◇◇◇◇◇◇◇◆◇◇◇◇◇◇◇◆◇◇◇◇◇◇◆◇◆◆◆◆◇◆◆◆◇◇◇◇◇◆◇◇◆◆◆◆◆◆◆◇◇
◇◇◇◆◇◇◇◇◇◇◇◆◇◇◇◇◇◇◆◇◇◇◇◇◇◆◇◇◇◇◇◇◇◆◇◇◇◇◇◇◇◆◇◇◇◇◇◆◆◆◆◆◇◇◆◆◆◇◇◇◇◇◇◆◇◇◆◇◇◇◇◇◆◇◇
◇◇◇◆◇◇◇◇◇◇◇◆◇◇◇◇◇◇◆◇◇◇◆◆◆◆◇◇◇◇◇◇◇◆◇◇◇◇◇◇◇◆◇◇◇◇◆◆◆◆◇◇◆◆◆◆◇◇◇◇◇◇◇◆◇◇◆◆◇◇◇◇◆◇◇
◇◆◆◆◆◆◆◆◆◆◆◆◆◆◇◇◇◇◆◇◇◇◆◆◆◆◇◇◇◇◇◆◆◆◆◆◆◆◆◆◆◆◆◆◇◇◇◇◇◇◇◆◆◆◇◇◇◇◇◇◇◇◇◆◇◇◆◆◆◆◆◆◆◇◇
◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇
◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇◇
-->
<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} ?>


			



<div id="iautobox" class="wrapper clearfix pt10">
  <div class="con-left">
    <?php if(_g('slidepid')!=""&&_g('slidepid')!=0): ?>
    <div class="yx-rotaion" style="margin-bottom:25px;">
      <ul class="rotaion_list">
         <?php indexslide(_g('slidepid'),_g('slidepnum')); ?>
       </ul>
    </div>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.yx_rotaion.js"></script> 
<script type="text/javascript">
$(".yx-rotaion").yx_rotaion({auto:true});
</script> 
    <!--焦点图结束-->  
	  <?php endif;?>  <div class="bk8"></div>  

<?php if(_g('inewshow')=="yes"): ?>
<h3 class="main-tit"><span class="tit"><?php echo _g('inewti'); ?></span><?php
$Log_Model = new Log_Model();
$today = strtotime(date('Y-m-d'));//今天凌晨时间戳
$threeday = strtotime(date('Y-m-d',strtotime('-3 day')));//3天前凌晨时间戳
$tenday = strtotime(date('Y-m-d',strtotime('-10 day')));//10天前凌晨时间戳
$today_sql = "and date>$today";
$today_num = $Log_Model->getLogNum('n', $today_sql);
$threeday_sql = "and date>$threeday";
$threeday_num = $Log_Model->getLogNum('n', $threeday_sql);
$tenday_sql = "and date>$tenday";
$tenday_num = $Log_Model->getLogNum('n', $tenday_sql);
if($tenday_num=='0'){echo '<b>都10天，没有更新内容了。</b>';}
elseif($threeday_num=='0'){echo '<b>连续3天都没有更新文章了。</b>';}
elseif($today_num=='0'){echo ' <b>今日站长还没更新。</b>';}
else{echo ' <b>今日更新<b style="color:red">'.$today_num.'</b>个资源，</b> ';}
	?><b>本站共分享<b style="color:red"><?php echo $sta_cache['lognum'];?></b>个资源</b>
 </h3>
 <div class="cmslist newadd newlist">
			<ul>
<?php 
if (!empty($logs)):$ii=1;
$iii=$ii+1;
foreach($logs as $key=>$value): 
$search_pattern = '%<img[^>]*?src=[\'\"]((?:(?!\/admin\/|>).)+?)[\'\"][^>]*?>%s';
preg_match($search_pattern, $value['content'], $img);
$value['img'] = isset($img[1])?$img[1]:TEMPLATE_URL.'pic/ap'.rand(1,10).'.jpg';

?>
     <li class="Hu-list">
		 <?php if($value['top']=='y'):?><span class="good-label">置顶</span><i class="good-arrow"></i><?php endif; ?><img src="http:///www.5axl.com/t/arrow3.gif" width="14" height="14" alt="0" style="margin-right:1px;<?php if($value['top']=='y') echo"display:none";?>"><span class="cms_daye_time" style="font-size:13px; <?php if(((date('Ymd',time())-date('Ymd',$value['date']))< 1)){?>
       color:#ff1100;
          <?php }?>">&nbsp;<?php echo gmdate('n-j', $value['date']); ?></span>
					<a <?php if($value['top']=='y'):?>style="background: linear-gradient(to right, red, blue,green);
        -webkit-background-clip: text;
        color: transparent;"<?php endif; ?>  href="<?php echo $value['log_url']; ?>" target="_blank" title="<?php echo $value['title']; ?>">
					<span style="font-size:14px;<?php if(((date('Ymd',time())-date('Ymd',$value['date']))< 1)){?>
       color:#f44336;
          <?php }?><?php if($value['logid']=='2019') echo "color:#f90;";?>"><?php echo $value['title']; ?></span></a>
				</li>

<?php 
endforeach;
?>
          </ul>  
		  
	  </div>
<?php 
else:

?>
		<div class="nolog">
            <h2>暂无内容</h2>
            <p><br />抱歉，没有符合您查询条件的结果。</p>
		</div> <?php
$nowtime = date('Y-m-d');
$endtime = gmdate('Y-m-d',$row['date']);
$date = gmdate('m-d', $row['date']);
$gid = $row['gid'];
if ($is_list == "1") {
$out .='<ul id="ul1">';
if ($nowtime==$endtime) {
$out .= '
<li><span style="color:red;font-weight:bold" id="date">[' . $date . ']</span><a style="color:red;font-weight:bold" href="' . Url::log($row['gid']) . '" title="' . $row['title'] . '" ><span id="arrow">▪</span>' . $row['title'] . '</a></li> 
';
$out .='</ul>';
}else{
$out .= '
<li><span id="date">[' . $date . ']</span><a href="' . Url::log($row['gid']) . '" title="' . $row['title'] . '" ><span id="arrow">▪</span>' . $row['title'] . '</a></li> 
';
$out .='</ul>';
}
}		
?>
<?php endif;?>
    <div class="bk15"></div>
    <div class="pagination">
    	
			<ul>
				<?php echo sheli_fy($lognum,$index_lognum,$page,$pageurl);?>
			</ul>
		
    </div>  <?php endif;?><br>

  


    	 <div class="cmsbox">
		<?php
			//CMS模块
			if(_g('icmshowid')!=0&&_g('icmshowid')!=""){
				$cmsid=explode('|',_g('icmshowid'));
				$cmsnum=count($cmsid);
				for ($x=0; $x<$cmsnum; $x++) {
					cmslist($cmsid[$x]);
				}
			}
		?>
	</div>
  </div>


  <!--con-left end-->  
	
  <div class="con-right">
<?php
include View::getView('side');
?>	</div>  </div>

<div class="bk8"></div>
<div class="wrapper ibtad">
    <?php echo _g('bvad'); ?>
</div><br>
<!--wrapper end--> 
<?php if($pageurl == Url::logPage()): ?>
    <div class="home-links">
		<div class="home-links-tt"><p>小蓝资源网<i class="fa fa-link"style="color:red;font-size:14px">友情链接:</i></p><span><b>&nbsp;<a href="<?php echo _g('flinkp'); ?>"></a>&nbsp;&nbsp;<a href="?plugin=czw_link">友链申请&nbsp;|&nbsp;<a href="neiye.html">内页友链</a></b></span></div>
		<ul style="list-style-type:none"> <font style="font-size:14px">
			<?php ilinks(); ?></font>
      </ul>
</div>
<?php endif; ?>
</div>


<?php
include View::getView('footer');
?><div class="toolbar">
 
   <span class="toolbar-layer"></span>
   </a>
   <a href="javascript:scroll(0,0)" id="top" class="toolbar-item toolbar-item-top"></a>
</div>