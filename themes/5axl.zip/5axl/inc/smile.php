<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<a href="javascript:grin('[F1]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/1.gif" alt="表情"/></a>
<a href="javascript:grin('[F2]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/2.gif" alt="表情"/></a>
<a href="javascript:grin('[F3]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/3.gif" alt="表情"/></a>
<a href="javascript:grin('[F4]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/4.gif" alt="表情"/></a>
<a href="javascript:grin('[F5]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/5.gif" alt="表情" /></a>
<a href="javascript:grin('[F6]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/6.gif" alt="表情"/></a>
<a href="javascript:grin('[F7]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/7.gif" alt="表情"/></a>
<a href="javascript:grin('[F8]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/8.gif" alt="表情"/></a>
<a href="javascript:grin('[F9]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/9.gif" alt="表情"/></a>
<a href="javascript:grin('[F10]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/10.gif" alt="表情"/></a>
<a href="javascript:grin('[F11]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/11.gif" alt="表情"/></a>
<a href="javascript:grin('[F12]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/12.gif" alt="表情" /></a>
<a href="javascript:grin('[F13]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/13.gif" alt="表情"/></a>
<a href="javascript:grin('[F14]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/14.gif" alt="表情"/></a>
<a href="javascript:grin('[F15]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/15.gif" alt="表情"/></a>
<a href="javascript:grin('[F16]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/16.gif" alt="表情" /></a>
<a href="javascript:grin('[F17]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/17.gif" alt="表情"/></a>
<a href="javascript:grin('[F18]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/18.gif" alt="表情"/></a>
<a href="javascript:grin('[F19]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/19.gif" alt="表情" /></a>
<a href="javascript:grin('[F20]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/20.gif" alt="表情"/></a>
<a href="javascript:grin('[F21]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/21.gif" alt="表情"/></a>
<a href="javascript:grin('[F22]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/22.gif" alt="表情"/></a>
<a href="javascript:grin('[F23]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/23.gif" alt="表情"/></a>
<a href="javascript:grin('[F24]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/24.gif" alt="表情" /></a>
<a href="javascript:grin('[F25]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/25.gif" alt="表情"/></a>
<a href="javascript:grin('[F26]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/26.gif" alt="表情"/></a>
<a href="javascript:grin('[F27]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/27.gif" alt="表情"/></a>
<a href="javascript:grin('[F28]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/28.gif" alt="表情" /></a>
<a href="javascript:grin('[F29]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/29.gif" alt="表情"/></a>
<a href="javascript:grin('[F30]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/30.gif" alt="表情"/></a>
<a href="javascript:grin('[F31]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/31.gif" alt="表情" /></a>
<a href="javascript:grin('[F32]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/32.gif" alt="表情"/></a>
<a href="javascript:grin('[F33]')"  title="表情" ><img src="<?php echo TEMPLATE_URL; ?>img/face/33.gif" alt="表情"/></a>