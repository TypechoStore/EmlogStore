﻿<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div style="height:20px; clear:both;"></div>
<!--footer begin-->
<div class="footer">
  <div class="wrapper">
    <div class="col">
      <div class="span-c"> <img src="<?php echo _g('qrcode'); ?>"alt=安全认证 width="118" height="118"/></div>
      <div class="span-a">
      	<p class="span-b"><a href="<?php echo BLOG_URL; ?>" style="margin-left:0"><?php echo $blogname; ?></a>| <a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo _g('ctqq'); ?>&site=qq&menu=yes" target="_blank">QQ联系</a><?php echo _g('footlink'); ?></p>
		  <span id="timeDate">载入天数...</span><span id="times">载入时分秒...</span> <script language="javascript"> 
	var now = new Date();
	function createtime(){
		var grt= new Date("06/15/2018 00:00:00");/*---这里是网站的启用时间--*/
		now.setTime(now.getTime()+250);
		days = (now - grt ) / 1000 / 60 / 60 / 24;
		dnum = Math.floor(days);
		hours = (now - grt ) / 1000 / 60 / 60 - (24 * dnum);
		hnum = Math.floor(hours);
		if(String(hnum).length ==1 ){hnum = "0" + hnum;}
		minutes = (now - grt ) / 1000 /60 - (24 * 60 * dnum) - (60 * hnum);
		mnum = Math.floor(minutes);
		if(String(mnum).length ==1 ){mnum = "0" + mnum;}
		seconds = (now - grt ) / 1000 - (24 * 60 * 60 * dnum) - (60 * 60 * hnum) - (60 * mnum);
		snum = Math.round(seconds);
		if(String(snum).length ==1 ){snum = "0" + snum;}
		document.getElementById("timeDate").innerHTML = "稳定运行"+dnum+"天";
		document.getElementById("times").innerHTML = hnum + "小时" + mnum + "分" + snum + "秒";
	}
	setInterval("createtime()",250); 
</script>
		  <p>&copy;2015-2018 <?php echo $blogname; ?> All right reserved. 版权所有 <br><span style="padding-left:10px;"><?php echo $footer_info; ?></span> </p>
        <p><?php echo _g('xycopyright'); ?></p>
        <p><?php echo $icp; ?></p>
        <?php doAction('index_footer'); ?>
      </div>
    </div>  
  </div>
</div>
</div>
 <!--
<script type="text/javascript">function warning(){ 
if(navigator.userAgent.indexOf("MSIE")>0) { 
art.dialog.alert('复制成功！若要转载请务必保留原文链接，申明来源，谢谢合作！'); } 
else { alert("复制成功！若要转载请务必保留原文链接，申明来源，谢谢合作！"); }}
document.body.oncopy=function(){warning();}
</script><script type="text/Javascript">function inlobase_noF12(){while(1){}}function inlojv_console(){if((window.console&&(console.firebug||console.table&&/firebug/i.test(console.table())))||(typeof opera=="object"&&typeof opera.postError=="function"&&console.profile.length>0)){inlobase_noF12()}if(typeof console.profiles=="object"&&console.profiles.length>0){inlobase_noF12()}}inlojv_console();window.onresize=function(){if((window.outerHeight-window.innerHeight)>200){inlobase_noF12()}};</script>
结束-->


<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/main.js"></script>

<script>
$(function() {$("img.lazy").lazyload({effect: "fadeIn"});});
$( document ).ready(function() {$( '.swipebox' ).swipebox();});
if($("#wowslider-container1").length>0){$.getScript(''+ pjaxtheme +'js/slider.js');}
</script>
<script>
(function webpackUniversalModuleDefinition(root, factory) {
    if (typeof exports === 'object' && typeof module === 'object') module.exports = factory();
    else if (typeof define === 'function' && define.amd) define([], factory);
    else if (typeof exports === 'object') exports["POWERMODE"] = factory();
    else root["POWERMODE"] = factory();
})(this, function() {
    return (function(modules) {
        var installedModules = {};
 
        function __webpack_require__(moduleId) {
            if (installedModules[moduleId]) return installedModules[moduleId].exports;
            var module = installedModules[moduleId] = {
                exports: {},
                id: moduleId,
                loaded: false
            };
            modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
            module.loaded = true;
            return module.exports;
        }
        __webpack_require__.m = modules;
        __webpack_require__.c = installedModules;
        __webpack_require__.p = "";
        return __webpack_require__(0);
    })
    ([
        function(module, exports, __webpack_require__) {
            'use strict';
            var canvas = document.createElement('canvas');
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            canvas.style.cssText = 'position:fixed;top:0;left:0;pointer-events:none;z-index:999999';
            window.addEventListener('resize', function() {
                canvas.width = window.innerWidth;
                canvas.height = window.innerHeight;
            });
            document.body.appendChild(canvas);
            var context = canvas.getContext('2d');
            var particles = [];
            var particlePointer = 0;
            var frames = 120;
            var framesRemain = frames;
            var rendering = false;
            POWERMODE.shake = true;
 
            function getRandom(min, max) {
                return Math.random() * (max - min) + min;
            }
 
            function getColor(el) {
                if (POWERMODE.colorful) {
                    var u = getRandom(0, 360);
                    return 'hsla(' + getRandom(u - 10, u + 10) + ', 100%, ' + getRandom(50, 80) + '%, ' + 1 + ')';
                } else {
                    return window.getComputedStyle(el).color;
                }
            }
 
            function getCaret() {
                var el = document.activeElement;
                var bcr;
                if (el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && el.getAttribute('type') === 'text')) {
                    var offset = __webpack_require__(1)(el, el.selectionStart);
                    bcr = el.getBoundingClientRect();
                    return {
                        x: offset.left + bcr.left,
                        y: offset.top + bcr.top,
                        color: getColor(el)
                    };
                }
                var selection = window.getSelection();
                if (selection.rangeCount) {
                    var range = selection.getRangeAt(0);
                    var startNode = range.startContainer;
                    if (startNode.nodeType === document.TEXT_NODE) {
                        startNode = startNode.parentNode;
                    }
                    bcr = range.getBoundingClientRect();
                    return {
                        x: bcr.left,
                        y: bcr.top,
                        color: getColor(startNode)
                    };
                }
                return {
                    x: 0,
                    y: 0,
                    color: 'transparent'
                };
            }
 
            function createParticle(x, y, color) {
                return {
                    x: x,
                    y: y,
                    alpha: 1,
                    color: color,
                    velocity: {
                        x: -1 + Math.random() * 2,
                        y: -3.5 + Math.random() * 2
                    }
                };
            }
 
            function POWERMODE() {
                {
                    var caret = getCaret();
                    var numParticles = 5 + Math.round(Math.random() * 10);
                    while (numParticles--) {
                        particles[particlePointer] = createParticle(caret.x, caret.y, caret.color);
                        particlePointer = (particlePointer + 1) % 500;
                    }
                    framesRemain = frames;
                    if (!rendering) {
                        requestAnimationFrame(loop);
                    }
                } {
                    if (POWERMODE.shake) {
                        var intensity = 1 + 2 * Math.random();
                        var x = intensity * (Math.random() > 0.5 ? -1 : 1);
                        var y = intensity * (Math.random() > 0.5 ? -1 : 1);
                        document.body.style.marginLeft = x + 'px';
                        document.body.style.marginTop = y + 'px';
                        setTimeout(function() {
                            document.body.style.marginLeft = '';
                            document.body.style.marginTop = '';
                        }, 75);
                    }
                }
            };
            POWERMODE.colorful = false;
 
            function loop() {
                if (framesRemain > 0) {
                    requestAnimationFrame(loop);
                    framesRemain--;
                    rendering = true;
                } else {
                    rendering = false;
                }
                context.clearRect(0, 0, canvas.width, canvas.height);
                for (var i = 0; i < particles.length; ++i) {
                    var particle = particles[i];
                    if (particle.alpha <= 0.1) continue;
                    particle.velocity.y += 0.075;
                    particle.x += particle.velocity.x;
                    particle.y += particle.velocity.y;
                    particle.alpha *= 0.96;
                    context.globalAlpha = particle.alpha;
                    context.fillStyle = particle.color;
                    context.fillRect(Math.round(particle.x - 1.5), Math.round(particle.y - 1.5), 3, 3);
                }
            }
            requestAnimationFrame(loop);
            module.exports = POWERMODE;
        },
        function(module, exports) {
            (function() {
                var properties = ['direction', 'boxSizing', 'width', 'height', 'overflowX', 'overflowY', 'borderTopWidth', 'borderRightWidth', 'borderBottomWidth', 'borderLeftWidth', 'borderStyle', 'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft', 'fontStyle', 'fontVariant', 'fontWeight', 'fontStretch', 'fontSize', 'fontSizeAdjust', 'lineHeight', 'fontFamily', 'textAlign', 'textTransform', 'textIndent', 'textDecoration', 'letterSpacing', 'wordSpacing', 'tabSize', 'MozTabSize'];
                var isFirefox = window.mozInnerScreenX != null;
 
                function getCaretCoordinates(element, position, options) {
                    var debug = options && options.debug || false;
                    if (debug) {
                        var el = document.querySelector('#input-textarea-caret-position-mirror-div');
                        if (el) {
                            el.parentNode.removeChild(el);
                        }
                    }
                    var div = document.createElement('div');
                    div.id = 'input-textarea-caret-position-mirror-div';
                    document.body.appendChild(div);
                    var style = div.style;
                    var computed = window.getComputedStyle ? getComputedStyle(element) : element.currentStyle;
                    style.whiteSpace = 'pre-wrap';
                    if (element.nodeName !== 'INPUT') style.wordWrap = 'break-word';
                    style.position = 'absolute';
                    if (!debug) style.visibility = 'hidden';
                    properties.forEach(function(prop) {
                        style[prop] = computed[prop];
                    });
                    if (isFirefox) {
                        if (element.scrollHeight > parseInt(computed.height)) style.overflowY = 'scroll';
                    } else {
                        style.overflow = 'hidden';
                    }
                    div.textContent = element.value.substring(0, position);
                    if (element.nodeName === 'INPUT') div.textContent = div.textContent.replace(/\s/g, " ");
                    var span = document.createElement('span');
                    span.textContent = element.value.substring(position) || '.';
                    div.appendChild(span);
                    var coordinates = {
                        top: span.offsetTop + parseInt(computed['borderTopWidth']),
                        left: span.offsetLeft + parseInt(computed['borderLeftWidth'])
                    };
                    if (debug) {
                        span.style.backgroundColor = '#aaa';
                    } else {
                        document.body.removeChild(div);
                    }
                    return coordinates;
                }
                if (typeof module != "undefined" && typeof module.exports != "undefined") {
                    module.exports = getCaretCoordinates;
                } else {
                    window.getCaretCoordinates = getCaretCoordinates;
                }
            }());
        }
    ])
});;
POWERMODE.colorful = true;
POWERMODE.shake = false;
document.body.addEventListener('input', POWERMODE);
</script>
</body>
</html>

</STYLE>
