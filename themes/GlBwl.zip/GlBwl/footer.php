<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div style="clear:both;"></div>
</div><!--end #wrap-->
<div id="footerbar">
	 Copyright &copy; 2015  <a href="http://www.glbwl.com" title="孤狼备忘录" target="_blank">GlBwl.com</a>版权所有  <a href="http://www.emlog.net" title="采用emlog系统">emlog</a> </br>Theme by <a href="http://www.glbwl.com" target="_blank">GlBwlv5.9.10</a>
	<?php doAction('index_footer'); ?>
</div><!--end #footerbar-->
<script src="<?php echo TEMPLATE_URL; ?>js/glbwl.js" type="text/javascript"></script>
<script>prettyPrint();</script>
</body>
</html>