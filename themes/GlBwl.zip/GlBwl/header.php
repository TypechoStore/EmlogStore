<?php
/*
Template Name:孤狼主题（自适应版）
Description:孤狼自适应主题
Version:5.9.10
Author:孤狼
Author Url:http://www.glbwl.com
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="UTF-8"/>
<meta http-equiv="Cache-Control" content="no-transform"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
<meta http-equiv="Content-Language" content="zh-CN" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div class="header">
  <div class="top-box">
  <div class="logo">
			  <a href="<?php echo BLOG_URL; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/logo.png" alt="<?php echo $blogname; ?>" /></a>
	</div><!--logo-->
<!--	<div class="search"><a href="#" id="search-3"><span class="nav-menu-search"><i class="fa fa-search"></i></span></a></div>-->
   <div class="nav-menu">
<?php blog_navi();?>
			</div><!--nav-menu-->
  </div><!--top-box-->
</div>  <!--header-->
<div id="menu">
       <?php blog_navi2();?>
  </div><!--menu-->
  <div class="text-right visible-xs">
		            <a href="#" id="mobile-menu"><span class="fa fa-bars"></span></a>
		        </div><!--text-right visible-xs-->
<div id="logo2"><a href="/" title="点击返回首页"><img src="<?php echo TEMPLATE_URL; ?>images/logo.png" class="animated tada"></a></div><!--bwgj_logo-->
<div id="search2" title="在搜索框中输入关键字后，按“回车”即可搜到结果。">
<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
<input name="keyword" type="search" placeholder="框中输文字，回车索结果。"></form></div><!--search2-->
<div id="wrap">