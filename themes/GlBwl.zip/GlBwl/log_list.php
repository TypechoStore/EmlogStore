<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="contentleft">
<?php doAction('index_loglist_top'); ?>
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
<section id="content-pt">
<div class="content-02">
<h2><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
	<div class="content-01">
	<div class="content-img">
	<?php
		preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
		$imgsrc = !empty($img[1]) ? $img[1][0] : TEMPLATE_URL.'images/random/glbwl'.rand(1,20).'.jpg';
		?>
		<div class="content-img-o"><a href="<?php echo $value['log_url']; ?>"><p class="content-img-aa"><?php echo $value['log_title']; ?></p></div><img src="<?php echo $imgsrc; ?>" class="content-img-b-i" alt="<?php echo $value['log_title']; ?>"/></a>
</div><!--content-img-->
        <div class="content-xx">
		<span class="pauthor"><i class="fa fa-user"></i><?php blog_author($value['author']); ?></span>
		<span class="ptime"><i class="fa fa-clock-o"></i> <?php echo gmdate('Y-n-j', $value['date']); ?></span>
		<span class="pcata"><i class="fa fa-th-list"></i><?php blog_sort($value['logid']); ?></span>
		<span class="pcomm"><i class="fa fa-comment"></i><?php if($value['comnum']=="0"){ echo '<a href="'.$value['log_url'].'#respond">抢沙发</a>'; }else{ echo  '<a href="'.$value['log_url'].'#comments">'.$value['comnum'].'条评论</a>'; } ?></span>
		<span class="pview"><i class="fa fa-eye"></i> <?php echo $value['views'].""; ?></span>
	</div><!--content-xx-->
<div class="content-img-01">
	<?php
		preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
		$imgsrc = !empty($img[1]) ? $img[1][0] : TEMPLATE_URL.'images/random/glbwl'.rand(1,20).'.jpg';
		?>
		<span class="content-img-o-01"><a href="<?php echo $value['log_url']; ?>"><p class="content-img-aa"><?php echo $value['log_title']; ?></p></span><img src="<?php echo $imgsrc; ?>"  alt="<?php echo $value['log_title']; ?>"/></a>
	  </div><!--content-img-01-->
		<div class="context">
			<?php echo subString(strip_tags($value['log_description']),0,150); ?>
		</div><!--context-->
						<div class="readmore">
						<a href="<?php echo $value['log_url']; ?>" class="btn pagenavi-btn pagenavi-info-btn" >阅读全文</a></div>
	</div><!--content-01-->
    </div><!--content-02-->
  </section>
<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>

<div id="pagenavi">
	<?php echo $page_url;?>
</div>

</div><!-- end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>