$(function(){		
	$(window).scroll(function(){
		var $top = $(window).scrollTop();
		if($top > 0){
			$('.header').addClass('fixed');
		}
		else{
			$('.header').removeClass('fixed');
		}	
		var $sideH = $('#sidebar').height() + $('#sidebar').offset().top;
		var $scrollT = $top + $('#scroll').height();
		var $footT = $('#footerbar').offset().top;
		if($top > $sideH){
			if($scrollT > $footT){
				$('#scroll').addClass('stop').removeClass('scroll');
			}else{
				$('#scroll').addClass('scroll').removeClass('stop');
			}
		}else{
			$('#scroll').removeClass('scroll').removeClass('stop');
		}	
	});

	
    //mobile menu and desktop menu
    $("#menu").css({"right":-1500});
    $("#mobile-menu").click(function(){
        $("#menu").show();
        
        if($("#menu").css("right") == "-1500px") 
        {
          $("#menu").animate({ "right":0 }, 400);
        }
        else
        {
          $("#menu").animate({ "right":-1500 }, 400);
        }
        
        return false;
    });
    

    $("#menu a").click(function(){
      $("#menu").animate({ "right":-1500 }, 400);
    });
	
	
	 $("#commentform").submit(function(){
	var q = $("#commentform").serialize();
	$.post($("#commentform").attr("action"),q,function(d){
		var reg = /<div class=\"main\">[\r\n]*<p>(.*?)<\/p>/i;
		if(reg.test(d)){
			$("#error").html(d.match(reg)[1]).show().fadeOut(5000);
		}
	});
	return false;	})
  
});


