<?php 
/**
 * 文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="maincontent">
    <div id="mainleft">
<?php doAction('index_loglist_top'); ?>
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
        <div class="left-post">
            <div class="list-item">
				<h2 class="list-title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a><span class="r"><?php echo $value['views']; ?>°</span></h2>
                <div class="list-meta">
                    作者：<?php blog_author($value['author']); ?> 发布时间：<?php echo gmdate('Y-n-j G:i', $value['date']); ?> <?php editflg($value['logid'],$value['author']); ?>
                </div>
                <div class="list-desc">
					<?php if(getThumb($value['gid'], $value['content'])):?>
                    <img src="<?php echo getThumb($value['gid'], $value['content']);?>" width="150" height="110" class="list-thumb" />
					<?php endif;?>
                    <p><?php echo subString(strip_tags($value['log_description']),0,150); ?></p>
                </div>
                <div class="clear"></div>
            </div>
        </div><!--//left-post end-->
<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>

<div id="pagenavi">
	<?php echo $page_url;?>
	<div class="clear"></div>
</div>
    </div><!--//mainleft end-->
    <div id="mainright">
		<?php include View::getView('side2');?>
    </div><!--//mainright end-->
    <div class="clear"></div>
<?php include View::getView('footer');?>