<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="maincontent">
    <div id="mainleft">
        <div class="left-post">
            <div class="post-post">
				<h1 class="log-title"><?php topflg($top); ?><?php echo $log_title; ?> <span class="r"><?php echo $views;?>°</span></h1>
                <div class="log-meta">
					<?php blog_author($author); ?> &nbsp; / &nbsp; <?php echo gmdate('Y-n-j G:i', $date); ?> &nbsp; / &nbsp; 浏览：<?php echo $views;?> 人次 &nbsp; / &nbsp;  分类：<?php blog_sort($logid); ?> &nbsp; / &nbsp; <a href="#pinglun" class="blue">发表评论</a> &nbsp; <?php editflg($logid,$author); ?>              
				</div>
				<div class="log-share">
<!-- Baidu Button BEGIN -->
					<div class="bdsharebuttonbox"><a href="#" class="bds_more" data-cmd="more"></a><a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a><a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a><a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a><a href="#" class="bds_renren" data-cmd="renren" title="分享到人人网"></a><a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a><a href="#" class="bds_sqq" data-cmd="sqq" title="分享到QQ好友"></a><a href="#" class="bds_twi" data-cmd="twi" title="分享到Twitter"></a><a href="#" class="bds_fbook" data-cmd="fbook" title="分享到Facebook"></a><a href="#" class="bds_t163" data-cmd="t163" title="分享到网易微博"></a><a href="#" class="bds_isohu" data-cmd="isohu" title="分享到我的搜狐"></a></div>
<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"32"},"share":{},"image":{"viewList":["qzone","tsina","tqq","renren","weixin","sqq","twi","fbook","t163","isohu"],"viewText":"分享到：","viewSize":"32"},"selectShare":{"bdContainerClass":null,"bdSelectMiniList":["qzone","tsina","tqq","renren","weixin","sqq","twi","fbook","t163","isohu"]}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script> 
           
          <script type="text/javascript">

document.getElementById("bdshell_js").src = "http://share.baidu.com/static/js/shell_v2.js?t=" + new Date().getHours();

</script> 
          
          <!-- Baidu Button END -->
					<div class="clear"></div>
				</div>
                <div class="log-content">
                	<?php echo $log_content; ?>
				</div>
				<!--百度广告开始-->
				<center>
				<script type="text/javascript">
/*文章末尾360*300*/
var cpro_id = "u1397024";
</script>
<script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script>
</center>
				<!--百度广告结束-->	
                <div class="log-footer">
                    <div class="qr">
						<img src="http://caihongjia.net/content/uploadfile/201312/thum-3b3e1388140979.jpg" />
                    </div>
                    <div class="copy">
                        <p><?php blog_tag($logid); ?></p>
                        <p>
                            <?php neighbor_log($neighborLog); ?>
                        </p>
						<li>部分文章来源于网络，不代表本人立场，如果侵犯了您的权益，请联系本人修改或删除。</a></li>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
			<!--百度推荐-->
	<center>
	<div id="hm_t_10058"></div>
</center>
	<!--百度推荐-->
			<div id="pinglun">
				<?php blog_comments($comments); ?>
				<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
			</div>
        </div><!--//left-post end-->
    </div><!--//mainleft end-->
    <div id="mainright">
		<?php include View::getView('side');?>
    </div><!--//mainright end-->
    <div class="clear"></div>
<?php include View::getView('footer');?>