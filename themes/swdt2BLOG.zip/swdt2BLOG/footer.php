﻿<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
    <div id="footer">
		<div class="link">
			<h3>友情链接</h3>
			<ul>
				<?php frdlink();?>
				<div class="clear"></div>
			</ul>
		</div>
		<div class="about">
			<h3>关于我们</h3>
			<ul>
				<li><a href="http://caihongjia.net/about.html">关于我们</a></li>
				<li><a href="http://caihongjia.net/gustbook.html">给我留言</a></li>
				<li><a href="http://caihongjia.net/dahang.html">博客导航</a></li>
				<li><a href="http://caihongjia.net/tv.html" target="_blank">电视直播</a></li>
				<li><a href="http://caihongjia.net/post-253.html" target="_blank">音乐电台</a></li>
				<li><a href="http://caihongjia.net/m/">手机浏览</a></li>
				<div class="clear"></div>
			</ul>
		</div>
		<div class="more">
			<h3>官方链接</h3>
			<ul>
				<li><a href="http://t.qq.com/zhongyishenghi" target="_blank" rel="nofollow">腾讯微博</a></li>
				<li><a href="http://weibo.com/liangxin8" target="_blank" rel="nofollow">新浪微博</a></li>
				<li><a href="http://love.caihongjia.net/" target="_blank">情侣博客</a></li>
				<div class="clear"></div>
			</ul>
		</div>
		<div class="clear"></div>
    </div>
	<div id="copyright">
		<p>版权所有：<?php echo $blogname;?> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
		<?php doAction('index_footer'); ?></p>
		<p>自豪的采用 <a href="http://www.emlog.net" title="采用emlog系统" target="_blank" rel="nofollow">Emlog</a>搭建本站, 感谢 <a href="http://www.myemlog.com" target="_blank" rel="nofollow">明月网络</a>提供技术支持，本站空间由<a href="http://www.west263.com/index.asp?ReferenceID=675431" 
target="_blank" rel="nofollow">西部数码</a>友情提供！</p>
	</div><a href="http://webscan.360.cn/index/checkwebsite/url/caihongjia.net" name="4f4e809b863a159260fc67be5691fdac" rel="nofollow">360网站安全检测平台</a>
</div><!--//maincontent end-->
<script>prettyPrint();</script>
</body>
</html>