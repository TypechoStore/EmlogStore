﻿<?php
/*
Template Name: 生物地铁2blog
Description: 蓝色风格
Version:1.0
Author:彩虹之家
Author Url:http://caihongjia.net
Sidebar Amount:2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
$timeandnum = timeandnum(strtotime('2012-09-07'));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<!--[if IE 6]>
<script src="<?php echo TEMPLATE_URL; ?>iefix.js" type="text/javascript"></script>
<![endif]-->
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="header">
    <div id="header-banner">
        <div id="logo">
            <a href="http://caihongjia.net"></a>
        </div>
		<div id="banner">
			
		<!-- 广告位：彩虹之家头部banger 开始-->
<script type="text/javascript" >BAIDU_CLB_SLOT_ID = "863278";</script>
<script type="text/javascript" src="http://cbjs.baidu.com/js/o.js"></script>
			<!-- 广告位：彩虹之家头部banger结束 -->
		</div>
        <div class="clear"></div>
    </div>
    <div id="menu">
        <div class="inner">
            <div id="nav">
                <?php blog_navi();?>
            </div>
            <div id="menu-contact">
				<a href="http://wpa.qq.com/msgrd?v=3&uin=2254872142&site=qq&menu=yes" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/pa.gif" /></a>
            </div>
            <div class="clear"></div>
        </div>
    </div><!--//menu end-->
    <div id="under-menu">
        <div class="position">
            <span class="l">您的位置：
				<?php 
					if(blog_tool_ishome()):
						echo '首页';
					elseif(isset($logs)):
?>
<a href="<?php echo BLOG_URL;?>">首页</a> >> 
<?php if ($params[1]=='sort'){ ?>
			<?php echo $sortName; ?>
<?php }elseif ($params[1]=='tag'){ ?>
		 	标签 <?php echo urldecode($params[2]);?>
<?php }elseif($params[1]=='author'){ ?>
			作者 <?php echo blog_author($author);?>
<?php }elseif($params[1]=='keyword'){ ?>
			关键词 <?php echo urldecode($params[2]);?>
<?php }elseif($params[1]=='record'){ ?>
			时间 <?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?>
		<?php }?>
				<?php
					elseif(isset($logid) && !isset($neighborLog)):
				?>
					<a href="<?php echo BLOG_URL;?>">首页</a> >> <?php blog_sort($logid); ?> >> <?php echo $log_title;?>
				<?php
					elseif(isset($logid) && isset($neighborLog)):
				?>
					<a href="<?php echo BLOG_URL;?>">首页</a> >> <?php blog_sort($logid); ?> >> <?php echo $log_title;?>
				<?php
					elseif(isset($tws)):
				?>
					<a href="<?php echo BLOG_URL;?>">首页</a> >> 微语
				<?php
					endif;
				?>
			</span>
            <span class="r">运行天数：<?php echo $timeandnum['time'];?>天，文章总数：<?php echo $timeandnum['num'];?>篇</span>
            <div class="clear"></div>
        </div>
        <div class="bar">
            <div class="l">
                <span class="tip">
                    <a href="http://caihongjia.net/post-883.html" target="_blank"><font color="red" size="1">爆料：很多充电宝内含窃听装置</font></a>
                </span>
				<span class="share"><?php if(!isset($logid)):?>
<div class="bdsharebuttonbox"><a href="#" class="bds_more" data-cmd="more"></a><a title="分享到QQ空间" href="#" class="bds_qzone" data-cmd="qzone"></a><a title="分享到新浪微博" href="#" class="bds_tsina" data-cmd="tsina"></a><a title="分享到腾讯微博" href="#" class="bds_tqq" data-cmd="tqq"></a><a title="分享到人人网" href="#" class="bds_renren" data-cmd="renren"></a><a title="分享到微信" href="#" class="bds_weixin" data-cmd="weixin"></a></div>
<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdPic":"","bdStyle":"0","bdSize":"16"},"share":{}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>
                </span><?php endif;?>
                <div class="clear"></div>
            </div>
            <div class="r">
                <div class="search">
					<form action="<?php echo BLOG_URL;?>">
						<div class="s">
							<input type="text" name="keyword" />
						</div>
						<div class="b">
							<input type="submit" value="搜索" />
						</div>
					</form>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="clear"></div>
        </div><!--//bar end-->
    </div>
</div><!--header end-->