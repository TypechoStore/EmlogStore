<?php 
/*
* 自定义404页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>您请求的页面未找到(404)</title>
<style>
*{
	margin:0;
	padding:0;
}
body{
	background:#f6f6f6;
}
.total{
	position:absolute;
	width:100%;
	height:100%;
}
.error-bg{
	position:fixed;
	bottom:0;
	width:100%;
	height:70px;
	background:url(<?php echo TEMPLATE_URL; ?>img/foot2.gif) no-repeat;
}
.error-box{
	width:60%;
	margin:0 auto;
	margin-top:120px;
	font-family:"微软雅黑";
	font-weight:bold;
	font-size:36px;
	color:#00b3fe;
	cursor:default;
}
.error-box b{
	font-size:56px;
	margin-left:-20px;
}
</style>
</head>
<body>
<div class="total" onclick="window.location.href='<?php echo BLOG_URL; ?>';">
<div class="error-bg">
</div>
<div class="error-box"><b>:(</b>
<br />很荣幸您能访问梦寐鱼求。<br />但是您的请求指向了错误的URL，点击页面任意位置返回首页。
</div>
</div>
</body>
</html>