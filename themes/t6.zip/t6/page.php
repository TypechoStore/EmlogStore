<?php 
/*
* 自建页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="content">
	<div class="content-left">
    	<div class="content-left-title"><?php topflg($top); ?><?php echo $log_title; ?></div>
        <div class="content-left-content"><?php echo $log_content; ?></div>
        <?php doAction('log_related', $logData); ?>
        <div class="comment-num">/ <?php echo $comnum; ?> <?php if($comnum<=1){echo 'Message';}else{echo 'Messages';} ?></div>
		<?php blog_comments($comments); ?>
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    </div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>