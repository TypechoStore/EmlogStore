<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="content">
	<div class="content-left">
    	<div class="content-left-title"><?php topflg($top); ?><?php echo $log_title; ?></div>
        <div class="content-left-info"><?php echo gmdate('Y.n.j', $date); ?> / <?php blog_sort($logid); ?> / <?php blog_tag($logid); ?></div>
        <div class="content-left-content"><?php echo $log_content; ?></div>
        <?php doAction('log_related', $logData); ?>
        <?php neighbor_log($neighborLog); ?>
        <div class="comment-num">/ <?php echo $comnum; ?> <?php if($comnum<=1){echo 'Comment';}else{echo 'Comments';} ?></div>
		<?php blog_comments($comments); ?>
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    </div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>