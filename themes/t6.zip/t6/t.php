<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="content">
<div class="content-left">
    <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
    <div class="t_top"><a href="<?php echo BLOG_URL . 'admin/twitter.php' ?>">写碎语</a></div>
    <?php endif; ?>
    <ul>
    <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?> 
    <li class="li">
    <div class="t_main">
    <div class="main_img"><img src="<?php echo $avatar; ?>" width="60px" height="60px" /></div>
    <div class="post1"><span class="t_author"><?php echo $author; ?></span><br /><?php echo $val['t'].'<br />'.$img;?><span class="t_time"><?php echo $val['date'];?></span> <span class="post">[<a href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">我来说两句</a>]</span></div>
    </div>
	<div class="clear"></div>
   	<ul id="r_<?php echo $tid;?>" class="r"></ul>
    <?php if ($istreply == 'y'):?>
    <div class="huifu" id="rp_<?php echo $tid;?>">
	<textarea id="rtext_<?php echo $tid; ?>" onFocus="if(value==defaultValue){value='';}"
onBlur="if(!value){value=defaultValue;}">我们坚信，鱼叔能够拯救世界！</textarea>
    <div class="tbutton">
        <div class="tinfo" style="display:<?php if(ROLE == 'admin' || ROLE == 'writer'){echo 'none';}?>">
        <input type="text" id="rname_<?php echo $tid; ?>" onFocus="if(value==defaultValue){value='';}"
onBlur="if(!value){value=defaultValue;}" value="昵称" />
        <span style="display:<?php if($reply_code == 'n'){echo 'none';}?>"><input type="text" id="rcode_<?php echo $tid; ?>" value="验证码" onFocus="if(value==defaultValue){value='';}"
onBlur="if(!value){value=defaultValue;}" /><?php echo $rcode; ?></span>        
        </div>
        <input class="button_p" type="button" onclick="reply('<?php echo DYNAMIC_BLOGURL; ?>index.php?action=reply',<?php echo $tid;?>);" value="回复" /> 
        <div class="msg"><span id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></span></div>
    </div>
    </div>
    <?php endif;?>
    </li>
    <?php endforeach;?>
    <?php if($twnum <= $index_twnum){ ?>
    <style>.t_page-right, .t_page-right{display:none;}</style>
    <?php }elseif($page == 1){ ?>
    <a href="<?php echo BLOG_URL.'t/?page='.(string)($page+1); ?>"><div class="t_page-right">→</div></a>
    <?php }elseif($page > 1 && $page < ceil($twnum / $index_twnum)){ ?>
    <a href="<?php echo BLOG_URL.'t/?page='.(string)($page-1); ?>"><div class="t_page-left">←</div></a>
    <a href="<?php echo BLOG_URL.'t/?page='.(string)($page+1); ?>"><div class="t_page-right">→</div></a>
    <?php }elseif($page >= ceil($twnum / $index_twnum)){ ?>
    <a href="<?php echo BLOG_URL.'t/?page='.(string)($page-1); ?>"><div class="t_page-left">←</div></a>
    <style>.t_page-right{display:none;}</style>
    <?php } ?>
    </ul>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>