<?php
/*
Template Name:T6
Description:T系列第二作，一样的蓝韵，一样的瀑布流……
Version:1.2.8
Author:sinkery
Author Url:http://www.sinkery.com
Sidebar Amount:1
ForEmlog:5.0.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<link type="text/css" rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/main.css" />
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<title><?php echo $site_title; ?></title>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div class="head-backgroud">
	<div class="head">
    	<div class="head-logo"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?><br /><span><?php echo $bloginfo; ?></span></a>
        </div>
        <div class="head-nav"><?php blog_navi();?>
        </div>
    </div>
</div>
<div class="search">
    <form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
    	<input class="search-box" name="keyword" id="search" type="text" value="搜索从这里开始" onFocus="if(value==defaultValue){value='';}"
onBlur="if(!value){value=defaultValue;}" />
    </form>
</div>