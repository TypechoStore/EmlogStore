<?php
/*
Template Name:AllTuts
Description:国外的一款火爆主题AllTuts
Version:1.2
Author:ENiuWa
Author Url:http://www.eniuwa.com
Sidebar Amount:1
ForEmlog:4.2.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="shortcut icon" href="<?php echo BLOG_URL; ?>/favicon.ico" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>/style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js"></script>
<script type="text/javascript"src="http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js"></script> 
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/js/laodao.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/js/tab.js"></script>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div id="logo"><h1><a href="<?php echo BLOG_URL; ?>"><img src="<?php echo TEMPLATE_URL; ?>/images/logo.png"></a></h1><br /></span></div>	
		<div class="ddsmoothmenu">
		<ul><LI>
 <A class=<?php echo $pageurl == BLOG_URL."page" ? '' : 'thisnav';?>  href="<?php echo BLOG_URL; ?>">首页</A>
		  </LI>
		  <?php if($istwitter == 'y'):?>
	
	<?php endif;?>
	<?php 
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach ($navi_cache as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	$val['is_blank'] = $val['newtab'] == 'y' ? 'target="_blank"' : '';
    $val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
	?>
	<li><a href="<?php echo $val['url']; ?>" target="<?php echo $val['is_blank']; ?>"><?php echo $val['naviname']; ?></a></li>
	<?php endforeach;?>
		  <?php
        global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	<?php foreach($sort_cache as $value): ?>
	<li>
	<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?></a>
	</li>
	<?php endforeach; ?>
	
		</ul>
		</div>
			<div id="socialLinks">
<a href="http://feed.eniuwa.com" title="RSS" class="rss" target="_blank">订阅我们</a>
<a href="https://me.alipay.com/shouke123" title="支持我们" class="facebook" target="_blank">支持我们</a>
<a href="http://t.qq.com/zsytx63" title="腾讯微博" class="twitter" target="_blank">腾讯微博</a>
<a href="http://weibo.com/515789964" title="新浪微博" class="linkedin" target="_blank">新浪微博</a>
							</div>
	</div>
	<div id="content" class="clearfix">