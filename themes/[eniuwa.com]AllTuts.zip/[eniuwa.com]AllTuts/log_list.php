<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="colLeft">			
		<div class="postBox">
		<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
			<div class="postBoxTop"></div>
			<div class="postBoxMid">
				<div class="postBoxMidInner first clearfix">
				<div class="date"><?php echo gmdate('M') ?><br /><span class="day"><?php echo gmdate('j') ?></span><br /><?php echo gmdate('Y') ?></div>
				<div class="category"></div>
				<h1><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></h1> 
				
				<div class="textPreview">
					<?php echo $value['log_description']; ?>
				</div>
				<div class="postMeta">
	
					<div class="metaRight">
						<img src="<?php echo TEMPLATE_URL; ?>/images/ico_author.png" alt="Author"/>&nbsp;&nbsp;阅读：<?php echo $value['views']; ?>
				<img src="<?php echo TEMPLATE_URL; ?>/images/ico_comments.png" alt="Comments"/>&nbsp;&nbsp;评论：<?php echo $value['comnum']; ?>
					</div>
				</div>
				</div>
			</div>
			<div class="postBoxBottom"></div>
			<?php endforeach; ?>
		</div>
		<div class="emm-paginate">
	<?php echo $page_url;?>
</div>
		</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>