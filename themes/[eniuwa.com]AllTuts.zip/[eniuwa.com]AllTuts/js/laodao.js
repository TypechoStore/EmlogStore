jQuery(document).ready(function(){
	//唠叨栏轮显效果
	(function(){
		$("#prev").click(function(){
			$(".laodao span:visible").animate({height:'toggle',opacity:'toggle'},400, 
			function() {
				if ($(this).prev().is("span")) {
					$(this).prev().animate({height:'toggle',opacity:'toggle'},200);
				} else {
					$(".laodao span:last").animate({height:'toggle',opacity:'toggle'},200);
				}
			});
		});
		$("#next").click(function(){
			$(".laodao span:visible").animate({height:'toggle',opacity:'toggle'},400, 
			function(){
				if ($(this).next().is("span")) {
					$(this).next().animate({height:'toggle',opacity:'toggle'},200);
				} else {
					$(".laodao span:first").animate({height:'toggle',opacity:'toggle'},200);
				}
			});
		});
		var b,
		a = function(){
			$("#next").trigger("click");
			b = setTimeout(a, 4000);
		};
		$(".laodao").hover(function(){
			clearTimeout(b);
			$("#prev,#next").fadeIn("fast");
		},
		function(){
			b = setTimeout(a, 4000);
			$("#prev,#next").fadeOut("fast");
		});
		b = setTimeout(a, 4000);
	})();
								})