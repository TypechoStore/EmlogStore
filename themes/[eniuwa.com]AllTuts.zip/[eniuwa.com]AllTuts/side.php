<?php 

/*

* 侧边栏

*/

if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="colRight">
<form id="searchform" action="<?php echo BLOG_URL; ?>" method="get">
			<div class="rightBox">
				<div class="rightBoxTop"></div>
				<div class="rightBoxMidSearch">
					<input type="text" id="s" name="keyword" value="输入内容" onfocus="this.value=''" onblur="this.value='type your search here"/>
					<input type="submit" value="" class="submit" id="searchsubmit"/>
				</div>	
				<div class="rightBoxBottom"></div>
			</div>
		</form>



		
<!-- Begin Ads -->
		<div class="rightBox clearfix">
				<div class="rightBoxTop"></div>
				<div class="rightBoxMidAds clearfix">
<div class="laodao">

		<p>轻轻心语·每日一句</p><span><strong>&raquo;</strong>易牛娃应用世界与你分享应用的精彩！http://www.eniuwa.com</span><span class="hidden"><strong>&raquo;</strong>从今天起，做一个幸福的人！</span><span class="hidden"><strong>&raquo;</strong>易牛娃应用世界与你分享应用的精彩！http://www.eniuwa.com</span><p id="prev">&laquo;</p>

		<p id="next">&raquo;</p>

	</div>
					 <!-- begin ads -->
						
						<!-- end ads -->
				
				</div>	
				<div class="rightBoxBottom"></div>
			</div>
<ul id="sidebar">
<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>
</ul><!--end #siderbar-->
</div>