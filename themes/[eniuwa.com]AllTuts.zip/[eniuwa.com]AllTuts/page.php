<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="colLeft">
    <!-- Begin .postBox -->
		<div class="postBox">
			<div class="postBoxTop"></div>
			<div class="postBoxMid">
				<div class="postBoxMidInner first clearfix">
				<h1><?php echo $log_title; ?></h1>	
<?php echo $log_content; ?>
<hr>
<h3 class="comment-header">
      <a href="#comment">↓快速评论↓</a><a name="comments"></a>
    </h3>
	<?php blog_comments($comments); ?>
    <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>

			</div>
		</div>
		<div class="postBoxBottom"></div>
		</div>
	
		</DIV>
<?php
 include View::getView('side');
 include View::getView('footer');
?>