<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="colLeft">
<div class="postBox">
<div class="postBoxTop"></div>
<div class="postBoxMid">
<div class="postBoxMidInner first clearfix">
<div class="date"><?php echo gmdate('M') ?><br /><span class="day"><?php echo gmdate('j') ?></span><br /><?php echo gmdate('Y') ?></div>
<div class="category"><?php blog_sort($logid); ?></div>
	<h1><?php topflg($top); ?><?php echo $log_title; ?></h1>
	<div class="postMetaSingle">
					<img src="<?php echo TEMPLATE_URL; ?>/images/ico_author.png" alt="Author"/> 文章by :<?php blog_author($author); ?>
					<img src="<?php echo TEMPLATE_URL; ?>/images/ico_comments.png" alt="Comments"/>&nbsp;&nbsp;评论： <?php echo $comnum; ?>
				</div>
	<?php echo $log_content; ?>
	 <div class="postTags"><?php blog_tag($logid); ?></div>
	 <h3 class="comment-header">
      <span><?php echo $views; ?> 人围观 / <?php echo $comnum; ?> 条评论</span>
      <a href="#comment">↓快速评论↓</a><a name="comments"></a>
    </h3>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div></div>
	<div class="postBoxBottom"></div>
</div>
</div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>