<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--end .slience-->
</div><!--end #content-->
<div style="clear:both;"></div>
<div id="footerbar">
<div id="footleft"><?php echo $blogname; ?>&copy;2011-2012 </div>
<div id="footright">
<ul>
<li><a href="<?php echo BLOG_URL; ?>">首页</a><span class="cut"> | </span></li>
<li><a href="http://t.qq.com/firber_slience/" target="_blank">腾讯微博</a><span class="cut"> | </span></li>
<li><a href="http://weibo.com/sliencezone/" target="_blank" >新浪微博</a><span class="cut"> | </span></li>
<li><a href="http://feed.feedsky.com/Sliencezone" target="_blank">订阅本站</a><span class="cut"> | </span></li>
<li><a href="http://slience.me/about-message-board.html">联系我</a><span class="cut"> | </span></li>
<li><a href="http://slience.me/sitemap.xml" target="_blank">网站地图</a></li>
</ul>
<script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F847a5f63a6011311dd2f0777892ea6a6' type='text/javascript'%3E%3C/script%3E"));
</script>
Theme by <a href="http://slience.me" target="_blank">slience</a>
Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> 
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>

<?php doAction('index_footer'); ?>
</div>

</div><!--end #footerbar-->
<div class="googlead">
<!--广告代码-->
</div>
</div><!--end #wrap-->
<!--<?php
if ($type == 'blog') { echo <<<LOADSCRIPT

<script type="text/javascript">
    var wumiiParams = "&num=5&mode=2&pf=emlog";
</script>
<script type="text/javascript" id="wumiiRelatedItems" src="http://widget.wumii.com/ext/relatedItemsWidget.htm"></script>
<a href="http://www.wumii.com/widget/relatedItems.htm" style="border:0;">
    <img src="http://static.wumii.com/images/pixel.png" alt="无觅相关文章插件，快速提升流量" style="border:0;padding:0;margin:0;" />
</a>
LOADSCRIPT;
}
?>--><!--无觅代码，用自己的替换-->
</body>
</html>