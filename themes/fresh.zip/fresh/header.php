<?php
/*
Template Name:小清新
Description:清新模板，简洁优雅 ……
Version:1.0
Author:Slience
Author Url:http://slience.me
Sidebar Amount:1
ForEmlog:4.1.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
<!--
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js"></script>
-->
<script type="text/javascript">
jQuery(document).ready(function($){
 $(".link a").each(function(e){
	$(this).prepend("<img src=http://www.google.com/s2/favicons?domain="+this.href.replace(/^(http:\/\/[^\/]+).*$/, '$1').replace( 'http://', '' )+" style=float:left;padding:3px;>");
});
 
});
</script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="wrap">
  <div id="header">
    <div class="slience">
		<h1><a href="<?php echo BLOG_URL; ?>"><img src="http://static.emlog.net/images/css_images/logo.png"/></a></h1><!-- logo -->
		<!--<h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1><h3><?php echo $bloginfo; ?></h3>-->
	<div id="search">
		<form method="get" id="searchform" action="<?php echo BLOG_URL; ?>index.php" class="searchform">
			<input type="text" onblur="if (this.value == '';){this value = '搜一搜……';}" onfocus="if (this.value=='搜一搜……'){this.value='';}" id="s"  value="搜一搜……" class="searchinput" name="keyword"/>
			<input type="submit" class="searchbutton" value=""/>
		</form>
	</div>
	<div id="nav">
		<ul>
			<li class="<?php echo $curpage == CURPAGE_HOME ? 'current' : 'common';?>"><a href="<?php echo BLOG_URL; ?>">首页</a><span class="cut"> | </span></li>
			
			<?php if($istwitter == 'y'):?>
			<li class="<?php echo $curpage == CURPAGE_TW ? 'current' : 'common';?>"><a href="<?php echo BLOG_URL; ?>t/">微语</a><span class="cut"> | </span></li>
			<?php endif;?>
			<?php 
			global $CACHE; 
			$navi_cache = $CACHE->readCache('navi');
			foreach ($navi_cache as $key => $val):
			if ($val['hide'] == 'y'){continue;}
			if (empty($val['url'])){$val['url'] = Url::log($key);}
			$newtab = $val['newtab'] == 'y' ? 'target="_blank"' : '';
			$val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
			?>
			<li class="<?php echo isset($logid) && $key == $logid ? 'current' : 'common';?>"><a href="<?php echo $val['url']; ?>" <?php echo $newtab; ?>><?php echo $val['naviname']; ?></a><span class="cut"> | </span></li>
			<?php endforeach;?>
			<?php doAction('navbar', '<li class="common">', '</li>'); ?>
			<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
			<li class="common"><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a><span class="cut"> | </span></li>
			<li class="common"><a href="<?php echo BLOG_URL; ?>admin/">管理中心</a><span class="cut"> | </span></li>
			<li class="common"><a href="<?php echo BLOG_URL; ?>admin/?action=logout" style="background-image: none; background-attachment: initial; background-origin: initial; background-clip: initial; background-color: initial; background-position: initial initial; background-repeat: initial initial; ">退出</a></li>
			<?php else: ?>
			<li class="common"><a href="<?php echo BLOG_URL; ?>admin/" style="background-image: none; background-attachment: initial; background-origin: initial; background-clip: initial; background-color: initial; background-position: initial initial; background-repeat: initial initial; ">登录</a></li>
			<?php endif; ?>
	 	</ul>
	</div>
	
	</div>
  </div>


