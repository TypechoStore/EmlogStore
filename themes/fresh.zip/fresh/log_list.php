<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
	<div class="slience">
		<div id="contentleft">
			<div id="post">
			<?php doAction('index_loglist_top'); ?>
			<?php $logs = getLogThumb(); ?>
			<?php foreach($logs as $value): ?>
			
			<div class="post-a">
				<div class="post-b">
					<div class="post-c">
					<?php topflg($value['top']); ?>
						<h2><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>&nbsp;&nbsp;&nbsp;<?php editflg($value['logid'],$value['author']); ?></h2>
						<div class="entry-info">	
							By <?php blog_author($value['author']); ?> Time: <?php echo gmdate('Y-n-j G:i l', $value['date']); ?>
						</div>
					</div>
					<div class="post-d">
						<div class="views"><?php echo $value['views']; ?></div>
						<p><a href="<?php echo $value['log_url']; ?>"></a></p>
					</div>
					
				</div><!-- end post-b-->
				
				<?php echo $value['log_description']; ?>
				
				<div class="entry-info2">
					<span class="sort"><?php blog_sort($value['logid']); ?></span> 
					<span class="tag"><?php blog_tag($value['logid']); ?></span>
				</div>
				<div style="clear:both;"></div>
			</div><!-- end post-a-->
			<?php endforeach; ?>
			</div>
			<div id="pagenavi">
				<p><?php echo $page_url;?></p>
			</div>
		</div><!-- end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>