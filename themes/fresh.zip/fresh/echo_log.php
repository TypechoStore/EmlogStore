<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div class="slience">
<div id="contentleft">
	<div class="post-content">
	<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
	<p class="entry-info">发布时间：<?php echo gmdate('Y-n-j G:i l', $date); ?> <?php blog_sort($logid); ?> <?php echo $views; ?>次点击 <span class="pll_comment_count_tag" style="display:none"><?php echo $value['log_url']; ?></span>
	</p>
	<!-- JiaThis Button BEGIN -->
<div id="jiathis_style_32x32">
	<a class="jiathis_button_fav"></a>
	<a class="jiathis_button_tsina"></a>
	<a class="jiathis_button_tqq"></a>
	<a class="jiathis_button_qzone"></a>
	<a class="jiathis_button_kaixin001"></a>
	<a class="jiathis_button_mop"></a>
	<a class="jiathis_button_tianya"></a>
	<a class="jiathis_button_douban"></a>
	<a class="jiathis_button_renren"></a>
	<a class="jiathis_button_hi"></a>
	<a class="jiathis_button_feixin"></a>
	<a class="jiathis_button_gmail"></a>
	<a class="jiathis_button_miliao"></a>
	<a href="http://www.jiathis.com/share" class="jiathis jiathis_txt jtico jtico_jiathis" target="_blank"></a>
	<a class="jiathis_counter_style"></a>
</div>
<script type="text/javascript" src="http://v2.jiathis.com/code/jia.js" charset="utf-8"></script>
<!-- JiaThis Button END -->
	<div class="logs"><?php doAction('xiaosong', $log_content); ?><p class="att"><?php blog_att($logid); ?></p></div>
	<div class="wumii-hook">
    <input type="hidden" name="wurl" value="<?php echo Url::log($logid); ?>" />
    <input type="hidden" name="wtitle" value="<?php echo $log_title; ?>" />
</div>
<script>
    var wumiiSitePrefix = "<?php echo BLOG_URL; ?>";
</script>
	
	
	<?php doAction('log_related', $logData); ?>
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	<div class="googlead">
	<!--广告代码-->
</div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    <div style="clear:both;"></div>
	</div>
</div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>