<?php 
/*
* 底部信息
/*
Template Name:ZMblog v1.3
Description:本模板为戒律（www.zming.org）的二次创作作品，以蓝色为主色调、追求天的辽阔、海的自由！
Version:1.3
Author:戒律
Author Url:http://www.zming.org/
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
 <!--Footer Start-->
	<div id="footerinfo">
    	<div class="ftooercon"> 
        	<div id="copyright">CopyRight &copy; 2009-2012&nbsp;<?php echo $blogname; ?>.&nbsp;&nbsp;All rights reserved.&nbsp;<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>
            </div>    
            <div id="pwte">Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">Emlog</a> & zming Theme  By <a href="http://www.zming.org" title="戒律" target="_blank">戒律</a>
<?php doAction('index_footer'); ?>
            </div>
		</div>
    </div>
    
    <div id="footer">
		<div class="ftooercon">
        	<div id="f_link" class="fleft">
    			<div class="title"> 
   					 <ul>
				  <li><a href="http://www.zming.org/post-59.html" target="_blank">LOGO设计作品</a></li>
				  <li><a href="http://www.hengfa.cc/" target="_blank">企业网站作品</a></li>
				  <li><a href="http://www.aucy.org" target="_blank" >校园网站作品</a></li>
   					 </ul>
    			</div>
            </div>
            
            <div id="f_link" class="fleft">
    			<div class="title"> 
   					 <ul><li><a href="http://mail.zming.org/" target="_blank">zming 邮箱系统</a></li><li><a href="https://me.alipay.com/zhiming" target="_blank">友情赞助我们</a></li><li><a href="http://www.zming.org/sitemap.xml" target="_blank">zming 网站地图</a></li><li><!--这里是统计代码 开始--><?php echo $footer_info; ?><!--这里是统计代码 结束--></</li></ul>
    			</div>
            </div>
			
            <div id="flogo" class="fright"> <a> <div class="ftlogo fright"></div></a> </div>
		</div>  
	</div>

<!--Footer End-->    


</body>
</html>