<?php 
/*
* 首页日志列表部分
/*
Template Name:ZMblog v1.3
Description:本模板为戒律（www.zming.org）的二次创作作品，以蓝色为主色调、追求天的辽阔、海的自由！
Version:1.3
Author:戒律
Author Url:http://www.zming.org/
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!--Container Stard-->
	<div class="container">
	<!--Left Stard-->
<div class="main">
        	<div class="posts">
            <!--Post Stard-->
            	<?php foreach($logs as $key=>$value):preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);$imgsrc = !empty($img[1]) ? $img[1][0] : '';?> 
            	<div class="post-box">
                	<div class="post-box-container">
                    	<h2 class="title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
                        
                        <div class="logtext read-content">
                          <div align="center">
                            <?php if($imgsrc):?>
                            <img src="<?php echo $imgsrc; ?>"  alt="<?php echo $value['log_title']; ?>" />
                            <?php endif;?>
                            </div>
                            <br />
                            <?php echo ''.subString(strip_tags($value['log_description'],$img),0,200).''; ?>...
                          
                        </div>
                        
                  <div class="meta">
							<div class="post-tags">
                            <?php blog_tag($value['logid']); ?>
							</div>
                            <span class="fleft">Date：&nbsp;</span>
                            <span class="fleft"><?php echo gmdate('Y/n/j', $value['date']); ?></span>
                            <span class="fleft">&nbsp;&nbsp;Sort：&nbsp;</span><?php blog_sort($value['logid']); ?>
                            <a class="fright" href="<?php echo $value['log_url']; ?>" title="阅读全文">Continue Reading</a>
                            <a class="fright" href="<?php echo $value['log_url']; ?>"><?php echo $value['views']; ?> Views&nbsp;/&nbsp;</a>
                            <!--显示评论数--a class="fright" href="<!--显示评论数--?php echo $value['log_url']; ?>#comments"><!--显示评论数--?php echo $value['comnum']; ?> Comments&nbsp;/&nbsp;</a!--显示评论数-->
						</div>
                    </div>
                </div>
                <?php endforeach; ?>
            <!--Post End-->
            </div>
            <!--pagination Stard-->
            <div class="pagination"><?php if($page_url): ?><p class="pageinfo">Page: <?php echo $page; ?> of <?php echo ceil($lognum/$index_lognum); ?></p><?php endif; ?>
                   <?php echo $page_url;?>
			</div>
            <!--pagination End-->
            
            
            
        </div>
    <!--Left End-->
    <!--Right Stard-->
    	<div class="side">
  		<?php
 include View::getView('side');
?>
    	</div>
    <!--Right End-->
    </div>
<!--Container End-->
<div class="heard m15"></div>
<!-- Scroll  Start-->
<div id="scroll">
    <a class="scroll_t" title="返回顶部"></a>
    <a class="scroll_b" title="转到底部"></a>
</div>
<!-- scroll End-->
<?php
 include View::getView('footer');
?>