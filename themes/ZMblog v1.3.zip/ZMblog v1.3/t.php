<?php 
/*
* 碎语部分
/*
Template Name:ZMblog v1.3
Description:本模板为戒律（www.zming.org）的二次创作作品，以蓝色为主色调、追求天的辽阔、海的自由！
Version:1.3
Author:戒律
Author Url:http://www.zming.org/
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!--Container Stard-->
	<div class="container">
	<!--Left Stard-->
    	<div class="main">
        	<div class="posts">
            <!--Post Stard-->
            	<div class="post-box">
                	<div class="post-box-container">
                    	<h2 class="con_title"><?php echo Option::get('twnavi');?></h2>
                        	
                            <div id="tw">
    <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
    <div class="top"><a href="<?php echo BLOG_URL . 'admin/twitter.php' ?>">发布碎语</a></div>
    <?php endif; ?>
    <ul>
    <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
//*emlog5.0兼容代码begin
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
//*emlog5.0兼容代码end
    ?> 
    <li class="li">
    <div class="main_img"><img src="<?php echo $avatar; ?>" width="32px" height="32px" /></div>
    <div class="post1"><span><?php echo $author; ?></span><br /><div class="time"><?php echo $val['date'];?> </div><br /><?php echo $val['t'].'<br/>'.$img;?></div> <!--emlog5.0兼容代码begin-->
    <div class="clear"></div>
    <div class="bttome">
        <div class="post"><a href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">回复(<span id="rn_<?php echo $tid;?>"><?php echo $val['replynum'];?></span>)</a></div>
        
    </div>
	<div class="clear"></div>
   	<ul id="r_<?php echo $tid;?>" class="r"></ul>
    <div class="huifu" id="rp_<?php echo $tid;?>">   
	<textarea id="rtext_<?php echo $tid; ?>"></textarea>
    <div class="tbutton">
        <div class="tinfo" style="display:<?php if(ROLE == 'admin' || ROLE == 'writer'){echo 'none';}?>">
        昵称：<input type="text" id="rname_<?php echo $tid; ?>" value="" />
        <span style="display:<?php if($reply_code == 'n'){echo 'none';}?>">验证码：<input type="text" id="rcode_<?php echo $tid; ?>" value="" /><?php echo $rcode; ?></span>        
        </div>
        <input class="button_p" type="button" onclick="reply('<?php echo DYNAMIC_BLOGURL; ?>index.php?action=reply',<?php echo $tid;?>);" value="回复" /> 
        <div class="msg"><span id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></span></div>
    </div>
    </div>
    </li>
    <?php endforeach;?>
    </ul>
</div>
                            
                        	<div style="margin-bottom:10px; clear:both;"></div>
                        	
                        
                        
					 </div>  
                </div>
            <!--Post End-->
            </div>
            
            <!--pagination Stard-->
            <div class="pagination"><?php echo $pageurl;?>
			</div>
            <!--pagination End-->
            <div class="m15"></div>
           
        </div>
    <!--Left End-->
    <!--Right Stard-->
    	<div class="side">
        <?php
 include View::getView('side');
?>

    	</div>
    <!--Right End-->
    </div>
<!--Container End-->
<!-- Scroll  Start-->
<div id="scroll">
    <a class="scroll_t" title="返回顶部"></a>
    <a class="scroll_b" title="转到底部"></a>
</div>
<!-- scroll End-->

<?php
 include View::getView('footer');
?>