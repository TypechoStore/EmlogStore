<?php
/*
* 头部信息
/*
Template Name:ZMblog v1.3
Description:本模板为戒律（www.zming.org）的二次创作作品，以蓝色为主色调、追求天的辽阔、海的自由！PS：若使图片增加slimbox效果需要开启模板目录的slimbox插件。
Version:1.3
Author:戒律
Author Url:http://www.zming.org/
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $site_title ; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description ; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<link href="<?php echo TEMPLATE_URL; ?>style/blue.css" rel="stylesheet" type="text/css" />
<style type="text/css">
body,td,th {
	color: #000;
}
</style>
<SCRIPT src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js" type=text/javascript></SCRIPT>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/menu-scroll.js"></script>
<?php doAction('index_head'); ?>
</head>
<body>


<!--[if lte IE 6]>

<SCRIPT>
	function toueme(){
		document.getElementById("iewarning").style.display="none";
	}
</SCRIPT>

<DIV id="iewarning">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="4%" height="30" align="center"><img src="<?php echo TEMPLATE_URL; ?>style/img/share-dd/con-text-error.png" width="40" height="40"></td>
    <td width="88%">亲！您正在使用的是世界上最垃圾的IE6浏览器！亲，您知道IE6正在阻碍着人类的进步吗？亲！你知道微软早就把IE6枪毙了吗？本博推荐您升级到<a href="http://apple.com/safari" target="_blank">Safari</a>, <a href="http://chrome.google.com">Chrome</a>, <a href="http://windows.microsoft.com/zh-CN/internet-explorer/downloads/ie-8" target="_blank">IE8</a>及以上或<a href="http://www.getfirefox.com" target="_blank">Firefox</a>, <a href="http://opera.com" target="_blank">Opera</a>, <a href="http://apple.com/safari" target="_blank">Safari</a>, <a href="http://chrome.google.com">Chrome</a>等浏览器！如果你换用搜狗/遨游3/360极速版等双核浏览器访问本博，建议切换到高速模式，可浏览到最完美的效果！</td>
    <td width="8%" align="right"> <a style="CURSOR: hand" onClick=toueme()> <img 
      src="<?php echo TEMPLATE_URL; ?>style/img/share-dd/close.gif" width=84 height=11 hspace="6" border=0> </a></td>
  </tr>
</table>
</DIV>
 <![endif]-->

<!--钓鱼岛是中国的-->
<SCRIPT>
	function toueme(){
		document.getElementById("iewarning").style.display="none";
	}
</SCRIPT>
<DIV id="iewarning">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="8%" height="30" align="center"><img src="../content/templates/ZMblog/style/img/share-dd/con-text-error.png" width="40" height="40"></td>
    <td width="4%"></td>
    <td width="76%" align="center">
      <h1 align="center"><strong>钓 鱼 岛 是 中 国 的 ！</strong></h1>
      <div align="right">———— 戒律_一个人逛超市【来自中国的心声】<br/>
  </div></td>
    <td width="4%"></td>
    <td width="8%" align="center"> <a style="CURSOR: hand" onClick=toueme()> <img 
      src="../content/templates/ZMblog/style/img/share-dd/close.gif" width=84 height=11 hspace="6" border=0> </a></td>
  </tr>
</table>
</DIV>
<!--钓鱼岛是中国的-end->

<!--Header Stard-->
	<!--Banner Stard-->
	<div id="toplogo">
		<div class="header">
			<div id="logo-bg">
				<!--[if gt IE 6]>
                <h1 id="logo"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>	
                <![endif]-->
                <!--[if lte IE 6]>
                <h1 id="logo-ie6"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
                <![endif]-->
                <!--[if !IE]><!--> <h1 id="logo"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1> <!--<![endif]-->

			</div>
			<a><h1 id="banner"></h1></a>
		</div>
	</div>
<!--Banner End-->
    <!--MenuNav Stard-->
    <div id="topnav">
		<div id="navhead">
        <ul id="menu" class="menu">
          <?php blog_navi();?>
        </ul> 
            <ul class="searchbox">
            
            	<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
                <button class="submit-go" type="submit">搜索</button>
    			<input class="input" autocomplete="off" value='按回车搜索...' onblur="if(this.value == '')this.value='按回车搜索...'" onfocus="if(this.value == '按回车搜索...')this.value = ''"  name="keyword" >
                </form>
            </ul>
        </div>
	</div>
    <!--MenuNav End-->
<!--Header End-->