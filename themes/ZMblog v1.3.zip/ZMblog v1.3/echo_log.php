<?php 
/*
* 阅读日志页面
/*
Template Name:ZMblog v1.3
Description:本模板为戒律（www.zming.org）的二次创作作品，以蓝色为主色调、追求天的辽阔、海的自由！
Version:1.3
Author:戒律
Author Url:http://www.zming.org/
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!--Container Stard-->
	<div class="container">
	<!--Left Stard-->
    	<div class="main">
        	<div class="posts">
            <!--Post Stard-->
            	<div class="post-box">
                	<div class="post-box-container">
                    	<h2 class="con_title"><?php topflg($top); ?><?php echo $log_title; ?></h2>
                        <div class="con_info">
							<span class="fleft">Date：&nbsp;</span>
                            <span class="fleft"><?php echo gmdate('Y/n/j', $date); ?></span>
                            <span class="fleft">&nbsp;&nbsp;Sort：&nbsp;</span><?php blog_sort($logid); ?>
                            <?php editflg($logid,$author); ?>
							<span class="fright"><?php echo $views;?> Views&nbsp;/&nbsp;</span>
                            <!--显示评论数--a class="fright" href="<!--显示评论数--?php echo $value['log_url']; ?>#comments"><!--显示评论数--?php echo $comnum; ?> Comments&nbsp;/&nbsp;</a!-->
						</div>
                         
                        <div class="logtext read-content">
                              <?php echo $log_content; ?>
                              <!--emlog5.0兼容代码begin-->
                              <!--?php blog_att($logid); ?>
                              <!--emlog5.0兼容代码end-->
                        </div>
                        <div class="baidudiv"><!-- Baidu Button BEGIN -->
    <div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare">
        <a class="bds_tsina"></a>
        <a class="bds_tqq"></a>
        <a class="bds_qzone"></a>
        <a class="bds_tqf"></a>
        <a class="bds_douban"></a>
        <a class="bds_renren"></a>
        <a class="bds_t163"></a>
        <a class="bds_tsohu"></a>
        <a class="bds_hi"></a>
        <a class="bds_s51"></a>
        <a class="bds_kaixin001"></a>
        <a class="bds_zx"></a>
        <a class="bds_fx"></a>
        <a class="bds_ty"></a>
        <a class="bds_taobao"></a>
        <a class="bds_ff"></a>
        <a class="bds_fbook"></a>
        <a class="bds_twi"></a>
        <a class="bds_baidu"></a>
        <a class="bds_qq"></a>
        <a class="bds_copy"></a>
        <span class="bds_more">更多</span>
		<a class="shareCount"></a>
    </div>
<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=680402" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
	document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + new Date().getHours();
</script>
<!-- Baidu Button END -->
						</div>
                        <div class="meta">
						
						<?php doAction('log_related', $logData); ?>
                        	<div style="border-top:1px solid #ECEEF0; margin-bottom:10px;"></div>
                        	<div class="post-tags">
                        	<?php blog_tag($logid); ?>
                        	</div>
                        	<?php neighbor_log($neighborLog); ?>
						</div>
                        
                        
					 </div>  
                </div>
            <!--Post End-->
            </div>
                                 
            <div id="notes" class="notes">
<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
			</div>
            <div class="m15"></div>
                     
        </div>
        

        
    <!--Left End-->
    <!--Right Stard-->
    	<div class="side">
        <?php
 include View::getView('side');
?>

    	</div>
    <!--Right End-->
    </div>
<!--Container End-->
<!-- Scroll  Start-->
<div id="scroll">
    <a class="scroll_t" title="返回顶部"></a>
    <a class="scroll_b" title="转到底部"></a>
</div>
<!-- scroll End-->






<?php
 include View::getView('footer');
?>