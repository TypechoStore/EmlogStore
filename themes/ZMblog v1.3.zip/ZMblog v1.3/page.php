<?php 
/*
* 自建页面模板
/*
Template Name:ZMblog v1.3
Description:本模板为戒律（www.zming.org）的二次创作作品，以蓝色为主色调、追求天的辽阔、海的自由！
Version:1.3
Author:戒律
Author Url:http://www.zming.org/
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!--Container Stard-->
	<div class="container">
	<!--Left Stard-->
    	<div class="main">
        	<div class="posts">
            <!--Post Stard-->
            	<div class="post-box">
                	<div class="post-box-container">
                    	<h2 class="con_title"><?php echo $log_title; ?></h2>
                        
                        <div class="logtext read-content">
                              <?php echo $log_content; ?>
                              <!--emlog5.0兼容代码begin-->
                              <!--?php blog_att($logid); ?>
                              <!--emlog5.0兼容代码end-->
                        </div>
                       <div style="width:570px; clear:both;"></div>
                        
                        
					 </div>  
                </div>
            <!--Post End-->
            </div>
            
            
            <!--com-->
            <div id="notes" class="notes">
<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
			</div>
            <!--com end--> 
        </div>
    <!--Left End-->
    <!--Right Stard-->
    	<div class="side">
        <?php
 include View::getView('side');
?>

    	</div>
    <!--Right End-->
    </div>
<!--Container End-->
<!-- Scroll  Start-->
<div id="scroll">
    <a class="scroll_t" title="返回顶部"></a>
    <a class="scroll_b" title="转到底部"></a>
</div>
<!-- scroll End-->





<?php
 include View::getView('footer');
?>