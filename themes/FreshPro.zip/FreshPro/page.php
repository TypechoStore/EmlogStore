<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content" class="log">
<ul class="box">
<li class="title location"><span>&nbsp;</span>
	<a title="回到首页" href="<?php echo BLOG_URL; ?>">首页</a><em class="cut">&raquo;</em>
	<?php blog_sort($logid); ?>
	<?php echo $log_title; ?>
</li>
<li class="cnt clearfix">
	<h2 class="content_h2"><span><?php topflg($top); ?><?php echo $log_title; ?></span></h2>
	<div class="editor"><?php editflg($logid,$author); ?></div>
	<div class="echo_tag"><?php blog_tag($logid); ?></div>
    <div class="bloger">作者： <?php blog_author($author); ?> 发布于 <?php echo gmdate('Y年 n月 j日', $date); ?></div>
	<div id="fix" class="post clearfix"><?php echo $log_content; ?></div>
	<div class="clear line"></div>
	<p class="comment"><b>评论：</b>(<?php echo $comnum; ?>条)</p>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</li>
</ul>
</div>
<!--end content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>