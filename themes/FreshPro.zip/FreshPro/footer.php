<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="clear"></div>
<div id="footer">
Copyright &copy; 2012 <?php echo $blogname; ?>,&nbsp;
Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> &nbsp;|&nbsp;
Themed By <a href="http://zj86.info/" target="_blank" rel="nofollow">Jin</a>
&nbsp;&nbsp;<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
<?php doAction('index_footer'); ?>
</div>
</div>
</body>
</html>
