<?php
/*
Template Name:FreshPro
Description:绿色清新，简洁明快，由<a href="http://www.wangleiseo.cn/" title="王磊SEO">王磊SEO</a>升级，并增加背景图片轮播、嵌套评论 ! 支持emog5.0.0 !
Version:1.2
Author:Jin
Author Url:http://www.wangleiseo.cn/demo/?theme=FreshPro
Sidebar Amount:1
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<!--[if ie 6]>
<link href="<?php echo TEMPLATE_URL; ?>ie6.css" rel="stylesheet" type="text/css" />
<script defer type="text/javascript" src="<?php echo TEMPLATE_URL; ?>images/pngfix.js"></script>
<![endif]-->
<?php doAction('index_head'); ?>
</head>
<body>
<?php $random_image=rand(1,8); ?>
<image id="bg" alt="" src="<?php echo TEMPLATE_URL; ?>images/<?php echo $random_image; ?>.jpg" />
<div class="main">
	<div class="header">
		<ul class="adm">
	        <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
	             <li class="common"><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
	             <li class="common"><a href="<?php echo BLOG_URL; ?>admin/">管理中心</a></li>
	             <li class="common"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
        	<?php else: ?>
	             <li class="common"><a href="<?php echo BLOG_URL; ?>admin/">登录</a></li>
        	<?php endif; ?>
		</ul>
	<h1 id="title"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
	<p id="tagline" align="center"><?php echo $bloginfo; ?></p>
  <?php blog_navi();?>
	<div class="clear"></div>
	<div class="rss"><a href="<?php echo BLOG_URL; ?>rss.php" target="_blank" title="订阅本博客"><img src="<?php echo TEMPLATE_URL; ?>images/rss.png" alt="rss"/></a></div>
</div>	<!--header end-->