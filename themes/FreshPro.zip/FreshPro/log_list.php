<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<?php doAction('index_loglist_top'); ?>
<ul class="box">
	<li class="title location"><span>首页</span><em class="cut">&raquo;</em>
<?php if ( isset($_GET['sort']) ) {
			echo $sort_cache[$_GET['sort']]['sortname'];
	  }elseif (isset($_GET['tag'])){
			echo '包含标签<em>“'.addslashes(strval(trim($_GET['tag']))).'”</em>的文章';
	  }elseif(isset($_GET['author'])){
			 echo '<em>'.blog_author($author).'</em>的文章';
	  }elseif(isset($_GET['keyword'])){
            echo '关键词<em>“'.addslashes(trim($_GET['keyword'])).'”</em>的搜索结果';
	  }elseif(isset($_GET['record'])){
            echo '在<em>“'.substr($_GET['record'],0,4).'年'.substr($_GET['record'],4,2).'月'.'”</em>发表的文章';
	  }else{
}?>
	</li>
<?php foreach($logs as $value): ?>
	<li class="cnt">
	<h2 class="content_h2">
	<?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
	<div>
	<span class="act">分类：<?php blog_sort($value['logid']); ?> </span>
   	<span class="bloger">作者：<?php blog_author($value['author']); ?>  发布于 <?php echo gmdate('Y年 n月 j日', $value['date']); ?></span>
	<span class="editor"><?php editflg($value['logid'],$value['author']); ?></span>
	</div>
	<div id="fix" class="post clearfix"><?php echo $value['log_description']; ?></div>
	<div class="under">
	<div class="top"></div>
	<div class="under_p">
	<?php blog_tag($value['logid']); ?>
	<div>
	<a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a>&nbsp;&nbsp;|&nbsp;
	<a href="<?php echo $value['log_url']; ?>#tb">引用(<?php echo $value['tbcount']; ?>)</a>&nbsp;&nbsp;|&nbsp;
	<a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a>
	</div>
	</div>
	</div>
	</li>
<?php endforeach; ?>
	<li id="pagenavi"><?php echo $page_url;?><br/></li>
</ul>
</div>
<!--end content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>