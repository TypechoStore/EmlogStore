<?php 
/*
* 日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
    	<div id="content">
			<div class="content-top"></div>
			<?php doAction('index_loglist_top'); ?>
        	<?php foreach($logs as $value): ?>
        	    <div class="post">
				<div class="date"><span class="day"><?php echo gmdate('j', $value['date']); ?></span>
				<span class="time"><?php echo gmdate('M', $value['date']); ?></span></div>
				<h2><?php topflg($value['top']); ?> <a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
				<div class="info">
                    <span class="tags">TAGS: <?php blog_tag($value['logid']); ?></span>
                    <span class="comments"><a href="<?php echo $value['log_url']; ?>#comment"> <?php echo $value['comnum']; ?> COMMENTS</a></span>
					<div class="clear"></div>
				</div>
				<div class="con"><div class="indexpage"><?php echo $value['log_description']; ?></div></div>
			</div>	
			<?php endforeach; ?>		 	
			<div id="pageurl"><?php echo $page_url;?></div>
        </div>
		 <div class="sidebar"> 
        <?php include View::getView('side'); ?>
		</div>
    </div>
<?php
 
 include View::getView('footer');
?>