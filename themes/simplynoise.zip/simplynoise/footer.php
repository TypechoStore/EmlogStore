<?php
/*
* 页底信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="footer"> 
    <div class="foot">
    	<a id="gotop" href="javascript:void(0);" onclick="MGJS.goTop();return false;">TOP</a>
    	<div class="copy"><p>Copyright &copy;  2010-2011 <?php echo $blogname; ?></p><p>
	<span class="copyright">Theme by <a href="http://www.pagecho.com/">cho</a></span> | 移植 by <a href="http://lwllo.com/">老王</a></span> |
	Powered by <a href="http://bbs.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>
	<?php echo $footer_info; ?></p></div>
	</div> 
</div> 
</div>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.all.js"></script>
</body>
</html>
