<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
    	<div id="content">
			<div class="content-top"></div>
            <div class="post">
				<div class="date"><span class="day"><?php echo gmdate('j', $date); ?></span>
				<span class="time"><?php echo gmdate('M', $date); ?></span></div>
				<?php if(isset($_GET['plugin'])){$log_title=$navibar[addslashes($_GET['plugin'])]['title'];} ?>
				<h2><?php echo $log_title; ?></h2>
				<div class="info">
                    <span class="comments"><?php echo $comnum; ?> COMMENTS</span>
					<div class="clear"></div>
				</div>
				<div class="con"><?php echo $log_content; ?></div>

			</div>
			<div class="postunder">
		    <div id="comments">
			<?php blog_comments($comments,$params); ?>
			<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	        </div>
			</div>
        </div>
				<div class="sidebar"> 
        <?php include View::getView('side'); ?>
				</div>
</div>							
<?php  include View::getView('footer'); ?>
