<?php 
/*
* 侧边栏组件、页面模块
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
	<div class="block">
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="bloggerinfo">
	<div id="bloggerinfoimg">
	<?php if (!empty($user_cache[1]['photo']['src'])): ?>
	<img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="<?php echo $user_cache[1]['photo']['width']; ?>" height="<?php echo $user_cache[1]['photo']['height']; ?>" alt="blogger" />
	<?php endif;?>
	</div>
	<p><b><?php echo $name; ?></b>
	<?php echo $user_cache[1]['des']; ?></p>
	</ul>
	</div>
<?php }?>
<?php
//widget：日历
function widget_calendar($title){ ?>
	 <div class="block">
	<h3><span><?php echo $title; ?></span></h3>
	<div id="calendar">
	</div>
	<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
	</div>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
   <div class="block links"><h3><?php echo $title; ?></h3>
   	<ul>  
	<?php foreach($sort_cache as $value): ?>
	<li><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>	</li>
	<?php endforeach; ?>
	</ul></div>
<?php }?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
   <div class="block"><h3><?php echo $title; ?></h3>
   	<ul> 
	<?php foreach($record_cache as $value): ?>
	<li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
	<?php endforeach; ?>
	</ul></div>
<?php } ?>
<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
	<div class="block">
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="blogtags">
	<?php foreach($tag_cache as $value): ?>
		<span style="font-size:<?php echo $value['fontsize']; ?>pt; line-height:30px;">
		<a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇日志"><?php echo $value['tagname']; ?></a></span>
	<?php endforeach; ?>
	</ul>
	</div>
<?php }?>
<?php
//widget：随机日志
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
   <div class="block"><h3><?php echo $title; ?></h3>
   	<ul> 
	<?php foreach($randLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul></div>
<?php }?>
<?php
//widget：最新日志
function widget_newlog($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
	<div class="block">
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="newlog">
	<?php foreach($newLogs_cache as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</div>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
	<div class="block"><h3><?php echo $title; ?></h3>
   	<ul> 
	<?php 
	foreach($com_cache as $value): 
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	$value['content'] = preg_replace("/\{smile:(([1-4]?[0-9])|50)\}/i","<img src='".TEMPLATE_URL."smiles/\\1.gif' alt='' height='16' />",$value['content']);
	?>
	<li><?php echo $value['name']; ?>：<a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</div>
<?php }?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
   <div class="block"><h3><?php echo $title; ?></h3>
   	<ul> 
	<li><?php echo $content; ?></li>
	</ul>
	</div>
<?php } ?>
<?php
//blog：引用通告
function blog_trackback($tb, $tb_url, $allow_tb){
    if($allow_tb == 'y' && Option::get('istrackback') == 'y'):?>
	<div id="trackback_address">
	<p>引用地址: <input type="text" style="width:350px" class="input" value="<?php echo $tb_url; ?>">
	<a name="tb"></a></p>
	</div>
	<?php endif; ?>
	<?php foreach($tb as $key=>$value):?>
		<ul id="trackback">
		<li><a href="<?php echo $value['url'];?>" target="_blank"><?php echo $value['title'];?></a></li>
		<li>BLOG: <?php echo $value['blog_name'];?></li><li><?php echo $value['date'];?></li>
		</ul>
	<?php endforeach; ?>
<?php }?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link'); ?>
   <div class="block links"><h3><?php echo $title; ?></h3>
   	<ul> 
	<?php shuffle($link_cache);foreach($link_cache as $value): ?>
	<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
	<?php endforeach; ?>
    </ul>
	</div>
<?php }?>
<?php
//blog：置顶
function topflg($istop){
	$topflg = $istop == 'y' ? "[<span style=\"color:#f00\">置顶</span>]" : '';
	echo $topflg;
}
?>
<?php 
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort'); ?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
	<a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>" rel="index"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
	<?php endif;?>
<?php }?>
<?php
//blog：文件附件
function blog_att($blogid){
	global $CACHE;
	$log_cache_atts = $CACHE->readCache('logatts');
	$att = '';
	if(!empty($log_cache_atts[$blogid])){
		$att .= '<a id="download"">附件下载：</a>';
		foreach($log_cache_atts[$blogid] as $val){
			$att .= '<a href="'.BLOG_URL.$val['url'].'" rel="nofollow" class="rar">'.$val['filename'].'</a> '.$val['size'].' ';
		}			
	}
	echo $att;
}
?>
<?php
//blog：日志标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "<a href=\"".Url::tag($value['tagurl'])."\" rel=\"tag\">".$value['tagname'].'</a>&nbsp;';
		}
		echo $tag;
	}
}
?>
<?php
//blog：日志作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($des) ? "title=\"$des\"" : '';
	echo '<a rel="me" href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻日志
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog):?>
	<div class="left">&laquo; 上一篇：<a href="<?php echo Url::log($prevLog['gid']) ?>" rel="previous"><?php echo $prevLog['title'];?></a></div>
	<?php else:?>
	<div class="left">&laquo; 上一篇：没有了</div>
	<?php endif;?>
	<?php if($nextLog):?>
	<div class="right"><a href="<?php echo Url::log($nextLog['gid']) ?>" rel="next"><?php echo $nextLog['title'];?></a>：下一篇&raquo;</div>
	<?php else:?>
	<div class="right">没有了：下一篇&raquo;</div>
	<?php endif;?>
<?php }?>
<?php
//blog：博客评论列表
function blog_comments($comments, $params){
	extract($comments);
	$commnum = count($comments);
	if($commentStacks): ?>    
    <h4>已有 <?php echo $commnum; ?> 条评论</h4>
	<ol class="comment-list">	
	<?php endif; ?>
	<?php
	$comnum = count($comments);
	foreach($comments as $value){
		if($value['pid'] != 0){
			$comnum--;
		}
	}
	$page = isset($params[4]) ? intval($params[4]) : 1;
	$i = $comnum - ($page-1) * Option::get('comment_pnum');
	$isGravatar = Option::get('isgravatar');
	foreach($commentStacks as $cid):
	$comment = $comments[$cid];
	$poster = $comment['poster'];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	$comment['content'] = preg_replace("/\{smile:(([1-4]?[0-9])|50)\}/i","<img src='".TEMPLATE_URL."smiles/\\1.gif' alt='' height='16' />",$comment['content']);
	?>
	<li id="comment-<?php echo $comment['cid']; ?>" class="comment-body comment-parent comment-evenl comment-odd">
    <div class="comment-author">
	<?php if($isGravatar == 'y'): ?><img class="avatar" src="<?php echo getGravatar($comment['mail']); ?>" alt="<?php echo $poster; ?>" title="<?php echo $poster; ?>" width="32" height="32" /><?php endif; ?>
	<cite class="fn"><?php echo $comment['poster']; ?></cite>  |  <?php echo $i; ?>楼 
	</div>
    <div class="comment-meta">
      <?php echo $comment['date']; ?>  <span class="reply"><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a></span>
    </div>
    <div class="com_content"><?php echo $comment['content']; ?></div>
	<?php blog_comments_children($comments, $comment['children']); ?>
	</li>
		<?php $i--; endforeach; ?>
	<?php if($commentStacks) echo '</ol>'; ?>
	<?php if(!empty($commentPageUrl)): ?>
	<div id="pageurl"><?php echo $commentPageUrl;?></div>
	<?php endif; ?>
<?php }?>
<?php
//blog：博客子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	$poster = $comment['poster'];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank" >'.$comment['poster'].'</a>' : $comment['poster'];
	$comment['content'] = preg_replace("/\{smile:(([1-4]?[0-9])|50)\}/i","<img src='".TEMPLATE_URL."smiles/\\1.gif' alt='' height='16' />",$comment['content']);
	?>
    <div class="comment-children">
        <ol class="comment-list">
    <li id="<?php echo $comment['cid']; ?>" class="comment-body comment-child comment-odd">            
    <div class="comment-author">
	<?php if($isGravatar == 'y'): ?><img class="avatar" src="<?php echo getGravatar($comment['mail']); ?>" alt="<?php echo $poster; ?>" title="<?php echo $poster; ?>"  width="32" height="32" /><?php endif; ?>
	<cite class="fn"><?php echo $comment['poster']; ?></cite>
	</div>
    <div class="comment-meta">
       <?php echo $comment['date']; ?>  <span class="reply"><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a></span>
    </div>
    <div class="com_content"><?php echo $comment['content']; ?></div>
	<?php blog_comments_children($comments, $comment['children']);?>
    </li></ol>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
			<div class="comment-place" id="comment-place">
            <div id="comment-post" class="respond">            
            <div class="cancel-comment-reply" id="cancel-reply" style="display:none"><small><a href="javascript:void(0);" onclick="cancelReply()">取消回复</a></small></div>
            <div class="addcomment"></div>
			<h4 id="response">添加新评论</h4>			
			<form method="post" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="comment_form">
				<div class="ie6show"></div>
				<div class="col2">
				<p><textarea name="comment" id="comment" tabindex="1" class="textarea"></textarea></p>				
				</div>	
				<?php if(ROLE == 'admin' || ROLE == 'writer'): $CACHE = Cache::getInstance();$user_cache = $CACHE->readCache('user');?>	
				<div class="col1">
				<p>Logged in as <?php echo $user_cache[UID]['name']; ?>. <a href="<?php echo BLOG_URL; ?>admin/?action=logout">[退出]</a></p>
				<p><input type="submit" tabindex="5" value="提交(Ctrl+Enter)" class="submit"/></p>	
				<p><input type="hidden" name="gid" value="<?php echo $logid; ?>" /></p>
				<p><input type="hidden" id="comment-pid" name="pid" value="0" /></p>
                </div>
				<?php elseif (ROLE == 'visitor'): ?>
				<div class="col1">
				<p>
                    <label for="author">昵称</label>
					<input type="text" tabindex="2" name="comname" id="author" class="text" value="<?php echo $ckname; ?>" />
				</p>
				<p>
                    <label for="mail">邮箱</label>
					<input type="text" tabindex="3" name="commail" id="mail" class="text" value="<?php echo $ckmail; ?>" />
				</p>
				<p>
                    <label for="url">网站</label>
					<input type="text" tabindex="4" name="comurl" id="url" class="text" value="<?php echo $ckurl; ?>" />
				</p>               
				<p><?php echo $verifyCode; ?><input type="submit" tabindex="5" value="提交(Ctrl+Enter)" class="submit"/></p>	
				<p><input type="hidden" name="gid" value="<?php echo $logid; ?>" /></p>
				<p><input type="hidden" id="comment-pid" name="pid" value="0" /></p>			
				</div>
				<?php endif; ?>
				<div class="clear"></div>
			</form>
            </div>
			<div class="clear"></div>
		</div>
	<?php endif; ?>
<?php }?>