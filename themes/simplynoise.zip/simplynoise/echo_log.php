<?php
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="container">
    	<div id="content">
			<div class="content-top"></div>
			<div class="place">
				<?php blog_sort($logid); ?>  &lt; 首页
			</div>
            <div class="post">
				<div class="date"><span class="day"><?php echo gmdate('j', $date); ?></span>
				<span class="time"><?php echo gmdate('M', $date); ?></span></div>
				<h2><?php echo $log_title; ?></h2>
				<div class="info">
                    <span class="tags">By: <?php blog_author($author); ?></span>
                    <span class="comments"><?php echo $comnum; ?> COMMENTS</span>
					<div class="clear"></div>
				</div>
				<div class="con"><?php echo $log_content; ?></div>
				<div class="under">
					<p>本文地址：<?php echo Url::log($logid); ?></p>
					<p><?php blog_att($logid); ?></p>
				</div>
				<div class="after_log"><?php doAction('log_related', $logData); ?></div>
				<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
			</div>
			<div class="postunder">
			<div id="comments">
			<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	        <?php blog_comments($comments,$params); ?>
	        <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	        </div>
			</div>
        </div>
				<div class="sidebar"> 
        <?php include View::getView('side'); ?>
				</div>
</div>							
<?php 
 include View::getView('footer');
?>