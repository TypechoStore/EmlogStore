<?php
/*
Template Name:simplynoise
Description:移植至http://www.pagecho.com
Author:老王
Author Url:http://lwllo.com
Sidebar Amount:0
ForEmlog:4.1.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE HTML>
<html lang="zh-CN">
<head>
	<meta charset="UTF-8">
	<title><?php echo $blogtitle; ?></title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="keywords" content="<?php echo $site_key; ?>">
	<meta name="description" content="<?php echo $description; ?>">
	<meta name="generator" content="emlog">
	<meta name="author" content="">
	<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
	<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
	<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
	<link href="<?php echo TEMPLATE_URL; ?>css/main.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js"></script>
	<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
	<?php doAction('index_head'); ?>
</head>
<body>
<div id="wrap">
	<div id="header"> 
		<div id="blog_title"> 
        	<h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1> 
        	<div id="blog-description"><?php echo $bloginfo; ?></div> 
        </div>
		<div id="menu">
				<ul>
				<li class="<?php echo $curpage == CURPAGE_HOME || (isset($logid) && !in_array($logid,array_keys($navibar))) ? 'current ' : '';?>"><a href="<?php echo BLOG_URL; ?>" rel="home">首页</a></li>
				<?php 
				global $CACHE; 
				$navi_cache = $CACHE->readCache('navi');
				foreach ($navi_cache as $key => $val):
				if ($val['hide'] == 'y'){continue;}
				if (empty($val['url'])){$val['url'] = Url::log($key);}
				$newtab = $val['newtab'] == 'y' ? 'target="_blank"' : '';
				$val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
				?>
				<li class="<?php echo isset($logid) && $key == $logid ? 'current ' : '';?>"><a href="<?php echo $val['url']; ?>" <?php echo $newtab; ?>><?php echo $val['naviname']; ?></a></li>
				<?php endforeach;?>
				<?php doAction('navbar', '<li >', '</li>'); ?>
				<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
				<li><a href="<?php echo BLOG_URL; ?>admin/">管理</a></li>
				<li><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
				<?php else: ?>
				<li><a href="<?php echo BLOG_URL; ?>admin/" title="乱登录切JJ">登录</a></li>
				<?php endif; ?>
				</ul>
		</div> 
		<form action="<?php echo BLOG_URL; ?>" class="head-search" method="get">
				<input type="submit" value="GO" class="submit">
				<input id="search-input" type="text" name="keyword" class="inputbox" value="" />
		</form>
    </div>