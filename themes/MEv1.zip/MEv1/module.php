<?php 

if(!defined('EMLOG_ROOT')) {exit('error!');} 

if (!function_exists('_g')) {

	emMsg('骚年，你得先安装<a href="https://github.com/Baiqiang/em_tpl_options" target="_blank">模板设置插件</a>哦！安装了主题才能正常运行哦！', BLOG_URL . 'admin/plugins.php');

}

?>
<?php

//blog：导航

function blog_navi(){

	global $CACHE; 

	$navi_cache = $CACHE->readCache('navi');

	?>

	<?php foreach($navi_cache as $value):if ($value['pid'] != 0) {continue;}if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):	?>

	<?php continue;endif;$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';$value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');$current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? '' : ''; ?>

		<li>

			<a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>>
			<?php if($value['naviname'] == "首页"):?><i class="fa fa-home"></i>
			<?php elseif($value['naviname'] =="微语"):?><i class="fa  fa-coffee"></i>
			<?php elseif($value['naviname'] =="相册"):?><i class="fa fa-camera"></i>
			<?php elseif($value['naviname'] =="归档"):?><i class="fa  fa-th-list"></i>
			<?php elseif($value['naviname'] =="留言" || $value['naviname'] =="留言板"):?><i class="fa fa-comments"></i>
			<?php elseif($value['naviname'] =="读者排行" || $value['naviname'] =="读者墙"):?><i class="fa fa-windows"></i>
			<?php elseif($value['naviname'] =="登录"):?><i class="fa fa-cogs"></i>
			<?php elseif($value['naviname'] =="投稿"):?><i class="fa fa-share-alt"></i>
			<?php elseif($value['naviname'] =="手机版"):?><i class="fa fa-mobile"></i>
			<?php endif;?>
			<?php echo $value['naviname']; ?></a>

			<?php if (!empty($value['children'])) :?>

            <ul class="second-lvl">

                <?php foreach ($value['children'] as $row){echo '<li><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></li>';} ?>

			</ul>

            <?php endif;?>

            <?php if (!empty($value['childnavi'])) :?>

            <ul class="second-lvl">

                <?php foreach ($value['childnavi'] as $row){$newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';echo '<li><a href="' . $row['url'] . "\" $newtab >" . $row['naviname'].'</a></li>';} ?>

			</ul>

            <?php endif;?>

		</li>

	<?php endforeach; ?>

<?php }?>

<?php
//blog：置顶
function topflg($top, $sortop='n', $sortid=null){
    if(blog_tool_ishome()) {
       echo $top == 'y' ? "<img src=\"".TEMPLATE_URL."/images/top.png\" title=\"首页置顶文章\" /> " : '';
    } elseif($sortid){
       echo $sortop == 'y' ? "<img src=\"".TEMPLATE_URL."/images/sortop.png\" title=\"分类置顶文章\" /> " : '';
    }
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a right="light" href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
    <a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
	<?php endif;?>
<?php }?>
<?php
//blog：文章标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '标签:';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "	<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
		}
		echo $tag;
	}
}
?>
<?php
//blog：文章作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog):?>
	<div class="contentprev">上一组：<a href="<?php echo Url::log($prevLog['gid']) ?>" rel="prev"><?php echo $prevLog['title'];?></a></div>
	<?php endif;?>
	<?php if($nextLog && $prevLog):?>

	<?php endif;?>
	<?php if($nextLog):?>
		 <div class="contentnext">下一组：<a href="<?php echo Url::log($nextLog['gid']) ?>" rel="next"><?php echo $nextLog['title'];?></a></div>
	<?php endif;?>
<?php }?>
<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>
<?php
//图片链接
function pic_thumb($content){
    preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $content, $img);
    $imgsrc = !empty($img[1]) ? $img[1][0] : '';
	if($imgsrc):
		return $imgsrc;
	endif;
}
?>
<?php
//格式化内容工具
function blog_tool_purecontent($content, $strlen = null){
        $content = str_replace('继续阅读&gt;&gt;', '', strip_tags($content));
        if ($strlen) {
            $content = subString($content, 0, $strlen);
        }
        return $content;
}
?>
<?php
//widget：随机文章
function shouqi_logs(){
	$index_randlognum = 1;
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	<?php foreach($randLogs as $value): ?>
	<a href="<?php echo Url::log($value['gid']); ?>">试试手气</a>
	<?php endforeach; ?>
<?php }?>
<?php
//30天按点击率排行文章
function getdatelogs($log_num) {
	$a="";
	$b=1;
	$c="";
	$d=1;
    $db = MySql::getInstance();
    $time = time();
    $sql = "SELECT gid,title,date,views,comnum FROM ".DB_PREFIX."blog WHERE type='blog' AND date > $time - 30*24*60*60 ORDER BY `views` DESC LIMIT 0,$log_num";
    $list = $db->query($sql);
    while($row = $db->fetch_array($list)){ ?>
<li><a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>" target="_blank"><img width="360" height="225" src="<?php get_thum($row['gid']);?>" class="attachment-thumbnail wp-post-image" alt="Pete_Nottage"/></a>
<div class="toppostinfo">
<div class="topposttitle">
<a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>" target="_blank"><?php echo $row['title']; ?></a>
</div>
						<div class="toppostdate">日期：<?php echo gmdate('Y-n-j', $row['date']); ?></div>
						<div class="toppostdate">浏览：<?php echo $row['views']; ?>　评论：<?php echo $row['comnum']; ?></div>
					</div>
<div class="toppostrank"><?php echo $c+$d++;?></div>
</li>
    <?php } ?>
<?php } ?>
<?php
//获取文章缩略图
function get_thum($logid){
 $db = MySql::getInstance();
$thum_pic = EMLOG_ROOT.'/thumpic/'.$logid.'.jpg';
if (is_file($thum_pic)) {
    $thum_url = BLOG_URL.'thumpic/'.$logid.'.jpg'; 
}else{
	$sqlimg = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$logid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";
	$img = $db->query($sqlimg);
    while($roww = $db->fetch_array($img)){
	 $thum_url=BLOG_URL.substr($roww['filepath'],3,strlen($roww['filepath']));
    }
    if (empty($thum_url)) {
	
srand((double)microtime()*1000000); 
$randval   =rand(1,10); 

            $thum_url = TEMPLATE_URL.'images/random/tb'.$randval.'.jpg';
        }
    }
echo $thum_url;
}
?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
	shuffle($link_cache);$link_cache = array_slice($link_cache,0,6);
    //if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
	?>
<div class="widget widget_links" >      
        <h3><?php echo $title;?></h3>
      <ul>
	<?php foreach($link_cache as $value): ?><li><i class="icon-link" style="padding-left: 10px;"></i>
	<a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
	<?php endforeach; ?></ul>
	
    </div>
<?php }?> 