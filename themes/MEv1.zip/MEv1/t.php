﻿<?php
/*
Template Name:Colorful
Description:Designed For Emlog
Version:1.0
Author:麦特佐罗
Author Url:http://www.zorrorun.com
Sidebar Amount:1
ForEmlog:5.3.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container2">
 <ul class="template">
		<article role="article">
		<center>
		<font color="red">
		抱歉，此模板不提供微语功能！-_-||
		</font>
		</center>
		</article>
 </ul>
</div>
<?php include View::getView('footer'); ?>