<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php if($pageurl == Url::logPage()):?>
<?php include View::getView('index');?>
<?php else:?>
<div id="container">
	<?php doAction('index_loglist_top'); ?>
</div>
<div id="container2">
 <ul class="template">
    <section>
		<div class="homelistbox">
			<ul>
		<div class="pagetitle">
			<h2>
            <?php if ($params[1]=='sort'){ ?>
		分类：<?php echo $sortName;?>
<?php }elseif ($params[1]=='tag'){ ?>
		标签:<?php echo htmlspecialchars(urldecode($params[2]));?>
<?php }elseif($params[1]=='author'){ ?>
		作者：<?php echo blog_author($author);?>
<?php }elseif($params[1]=='keyword'){ ?>
       关键词：<?php echo htmlspecialchars(urldecode($params[2]));?>
<?php }elseif($params[1]=='record'){ ?>
       时间：<?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?>
<?php }else{?>文章列表<?php }?>
            </h2>
		</div>
<?php 
if (!empty($logs)):
foreach($logs as $value):
$logdes = blog_tool_purecontent($value['content'], 96);
if(pic_thumb($value['content'])){
	$imgsrc = pic_thumb($value['content']);
	}else
	$imgsrc = TEMPLATE_URL.'images/random/tb'.rand(1,10).'.jpg';
?>
	<li class="listbox">
		<a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><img width="360" height="200" src="<?php echo $imgsrc;?>" class="attachment-thumbnail wp-post-image" alt="<?php echo $value['log_title']; ?>"/></a>
				<div class="summary"><div class="summarytxt"><p><?php echo subString(strip_tags($value['log_title']),0,50); ?></p></div></div>
				<div class="listinfo">
					<div class="listtag">标签：<?php blog_tag($value['logid']); ?></div>
					<div class="listdate">时间:<?php echo gmdate('Y-n-j', $value['date']); ?></div>
					<div class="listview">阅读:<?php echo $value['views']; ?></div>
					<h4><a href="<?php echo $value['log_url']; ?>"><b>查看</b><span>全文</span></a></h4>
				</div>
				</li>
<?php 
endforeach;
else:
?>
	<li class="nothing">你找到的东西已飞宇宙黑洞去了！</li>
<?php endif;?>
			</ul>
		</div>
    </section>
 </ul>
		<div class="page"><?php echo $page_url;?></div>
</div>
		<div class="clear"></div>
<div class="idea">
 <p><?php echo _g('botsm'); ?>
 </p>
</div>
<?php
 include View::getView('footer');
?>
<?php endif;?>