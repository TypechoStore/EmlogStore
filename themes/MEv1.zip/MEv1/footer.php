<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<footer>
 <div class="footer-mid">
    <section class="visitors">
      <h2><i class="fa fa-user"></i> 最近访客</h2>
<ul class="ds-recent-visitors" data-num-items="9" data-avatar-size="50">
</ul>
    </section>
      <section class="links">
      <h2><i class="fa fa-paper-plane-o"></i> 合作伙伴</h2>
      <ul>
		<?php echo _g('hzhb')?>
      </ul>
    </section>
     <section class="links">
      <h2><li class="fa fa-link"></li> 友情链接</h2>
      <ul>
	  <?php widget_link($title); ?>
      </ul>
    </section>
    <section class="weixin">
      <h2><i class="fa fa-comment"></i> 微信关注</h2>
      <img src="<?php echo _g('wxgz')?>">
    </section>
 </div>
<div id="footer-bottom"><ul><p>Copyright &copy; 2015 <a href="<?php echo BLOG_URL; ?>" target="_blank"><?php echo $blogname; ?></a> Powered by <a href="http://www.emlog.net" title="由Emlog强力驱动" target="_blank">Emlog</a> Theme by <a href="http://vbs.so/" title="做自己喜欢的事就对了！" target="_blank">Finally</a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a><?php doAction('index_footer'); ?></p></ul></div>
</footer>
<script type="text/javascript">
//d
jQuery(function(){
	jQuery('#newcomment').addClass('ds-recent-comments').data('excerpt-length', 32).data('show-admin', 0);
});
var duoshuoQuery = {short_name:"<?php echo _g('ds_url');?>"};
	(function() {
		var ds = document.createElement('script');
		ds.type = 'text/javascript';ds.async = true;
		ds.src = '<?php echo TEMPLATE_URL; ?>js/embed.js';
		ds.charset = 'UTF-8';
		(document.getElementsByTagName('head')[0] 
		 || document.getElementsByTagName('body')[0]).appendChild(ds);
	})();
//t
$(document).ready(function(){(function(){$("a").each(function(m){if(this.title){var c=this.title;var a=30;$(this).mouseover(function(d){this.title="";$("body").append('<div id="pre_a">'+c+"</div>");$("#pre_a").css({left:(d.pageX+a)+"px",top:d.pageY+"px",opacity:"0.7"}).fadeIn(250)}).mouseout(function(){this.title=c;$("#pre_a").remove()}).mousemove(function(d){$("#pre_a").css({left:(d.pageX+a)+"px",top:d.pageY+"px"})})}})})();});
</script>
</body>
</html>