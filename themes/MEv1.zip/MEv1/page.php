<?php 
/**
 * 新建页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="container2">
		<ul class="template">
		<div class="contentbox">
			<div class="contenttitle">
				<h1><?php echo $log_title; ?></h1>
				<span class="info"><?php editflg($logid,$author); ?> 日期：<?php echo gmdate('Y-n-j G:i l', $date); ?></span>
			</div>
			<div class="contentview">
				浏览次数<span><?php echo $views; ?></span>
			</div>
			<div class="contenttxt"><div class="clear"></div><?php echo $log_content; ?><?php doAction('log_related', $logData); ?></div>
		<div class="ds-thread" data-thread-key="<?php echo $logid;?>" data-title="<?php echo $log_title; ?>" data-url="<?php echo $log_url; ?>"></div>
		<div class="clear"></div>
		</div>
		 </ul>
</div>
<div class="clear"></div>
<?php
 include View::getView('footer');
?>
