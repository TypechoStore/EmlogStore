<?php

/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
	'logo' =>array(
		'type' => 'image',
		'name' => 'LOGO',
		'values' => array(
			TEMPLATE_URL . 'images/logo.png',
		),
	),
	
	'ds_url' =>array(
		'type' => 'text',
		'name' => '多说二级域名',
		'description' => '比如我的多说pigzt.duoshuo.com,只需要输入pigzt',
		'values' => array(
			'pigzt',
		),
	),
	
	'wygg' => array(
		'type' => 'radio',
		'name' => '微语公告',
		'values' => array(
			'y' => '开启',
			'n' => '关闭',
		),
		'default' => 'n',		
	),
	
	'tbsm' =>array(
		'type' => 'text',
		'name' => '文章版权',
		'description' => '显示在内容页',
		'values' => array(
			'该资源来源于互联网，版权当然归原作者所有！如果您从本站下载了该素材，请仅用于学习和研究！如果您要作为商业用途，请向原作者购买正版获得商业用途授权！',
		),
	), 	
	
	'botsm' =>array(
		'type' => 'text',
		'name' => '底部说明',
		'description' => '主页说明',
		'multi' => true,
		'default' => 
			'当我们懂得珍惜平凡的幸福的时候，就已经成了人生的赢家。Nothing is as sweet as you 再没什么，能甜蜜如你。我以为只要很认真的喜欢就能打动一个人，到后来，却只打动了我自己。',
	),
	
	'hzhb' => array(
		'type' => 'text',
		'name' => '合作伙伴',
		'description' => '这里写入合作伙伴,格式如下',
		'multi' => true,
		'default' => '<li><a href="http://vbs.so" target="_blank">M1dwint3r</a></li><li><a href="http://www.emlog.com" target="_blank">emlog</a></li><li><a href="#">友情链接</a></li><li><a href="#">意见反馈</a></li><li><a href="#">联系站长</a></li>',
	),

	'wxgz' =>array(
		'type' => 'image',
		'name' => '微信关注',
		'values' => array(
			TEMPLATE_URL . 'images/weixin.png',
		),
	),
	
	'banner_open' => array(
		'type' => 'radio',
		'name' => '开启BANNER',
		'values' => array(
			'y' => '开启',
			'n' => '关闭',
		),
		'default' => 'y',		
	),
	
	'ba1_url' => array(
		'type' => 'radio',
		'name' => 'banner1连接新窗口打开',
		'values' => array(
			'y' => '开启',
			'n' => '关闭',
		),
		'default' => 'n',		
	),
	'ba1img' =>array(
		'type' => 'image',
		'name' => 'banner图片1',
		'values' => array(
			TEMPLATE_URL . 'images/1.jpg',
		),
	),
	'ba1url' => array(
		'type' => 'text',
		'name' => 'banner图片1链接',
		'values' => array(
			'http://vbs.so',
		),
	),
	'ba1name' => array(
		'type' => 'text',
		'name' => 'banner图片1名称',
		'values' => array(
			'设计创意',
		),
	),
	'ba1js' => array(
		'type' => 'text',
		'name' => 'banner1介绍',
		'values' => array(
			'界面设计是网站的灵魂，是抓住用户眼球的第一要素。良好界面、强大的后台支持。',
		),
	),

	'ba2_url' => array(
		'type' => 'radio',
		'name' => 'banner2连接新窗口打开',
		'values' => array(
			'y' => '开启',
			'n' => '关闭',
		),
		'default' => 'n',		
	),	
	'ba2img' =>array(
		'type' => 'image',
		'name' => 'banner图片2',
		'values' => array(
			TEMPLATE_URL . 'images/2.jpg',
		),
	),
	'ba2url' => array(
		'type' => 'text',
		'name' => 'banner图片2链接',
		'values' => array(
			'http://vbs.so',
		),
	),
	'ba2name' => array(
		'type' => 'text',
		'name' => 'banner图片2名称',
		'values' => array(
			'客户服务',
		),
	),
	'ba2js' => array(
		'type' => 'text',
		'name' => 'banner2介绍',
		'values' => array(
			'为客户提供良好的服务，并考虑客户的实际情况，为客户提供个性化的、最适合您的服务。',
		),
	),

	'ba3_url' => array(
		'type' => 'radio',
		'name' => 'banner3连接新窗口打开',
		'values' => array(
			'y' => '开启',
			'n' => '关闭',
		),
		'default' => 'n',		
	),	
	'ba3img' =>array(
		'type' => 'image',
		'name' => 'banner图片3',
		'values' => array(
			TEMPLATE_URL . 'images/3.jpg',
		),
	),
	'ba3url' => array(
		'type' => 'text',
		'name' => 'banner图片3链接',
		'values' => array(
			'http://vbs.so',
		),
	),
	'ba3name' => array(
		'type' => 'text',
		'name' => 'banner图片3名称',
		'values' => array(
			'执行效率',
		),
	),
	'ba3js' => array(
		'type' => 'text',
		'name' => 'banner3介绍',
		'values' => array(
			'拒绝拖拉让您放心，做一个按时、高质、高效的行业典范企业。',
		),
	),
	
	'qq' => array(

		'type' => 'text',

		'name' => '博主QQ',

		'default' => '1501700017',

	),

	'weixin' => array(

		'type' => 'text',

		'name' => '博主微信',

		'default' => 'qtvb52',

	),

	'twitter' => array(

		'type' => 'text',

		'name' => '腾讯QQ空间',
		
		'default' => 'http://user.qzone.qq.com/1501700017',

	),

	'txwb' => array(

		'type' => 'text',

		'name' => '腾讯微博地址',

		'default' => 'http://t.qq.com/M1dWint3r',

	),

	'xlwb' => array(

		'type' => 'text',

		'name' => '新浪微博地址',

		'default' => 'http://weibo.com/M1dWint3r',

	),
);
