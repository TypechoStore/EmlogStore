<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
	<?php doAction('index_loglist_top'); ?>
<?php if (_g('banner_open')=='y'): ?>
  <div id=wrapper class=index_banner>
    <div id=home-slider class=home-slider>
      <div class=slider-item><a href="<?php echo _g('ba1url'); ?>" <?php if (_g('ba1_url') == 'y'): ?>target="_blank"<?php endif; ?>><img alt="<?php echo _g('ba1name'); ?>" src="<?php echo _g('ba1img'); ?>" width=1920 height=480></a></div>
      <div class=slider-item><a href="<?php echo _g('ba2url'); ?>" <?php if (_g('ba2_url') == 'y'): ?>target="_blank"<?php endif; ?>><img alt="<?php echo _g('ba2name'); ?>" src="<?php echo _g('ba2img'); ?>" <?php if (_g('ba2_url') == 'y'): ?>target="_blank"<?php endif; ?>
width=1920 height=480></a></div>
      <div class=slider-item><a href="<?php echo _g('ba3url'); ?>" <?php if (_g('ba3_url') == 'y'): ?>target="_blank"<?php endif; ?>><img alt="<?php echo _g('ba3name'); ?>" src="<?php echo _g('ba3img'); ?>" <?php if (_g('ba3_url') == 'y'): ?>target="_blank"<?php endif; ?>
width=1920 height=480></a></div>
    </div>
    <div class=design_box>
      <div id=home-slider-nav class=design>
        <dl class=sel onmouseover=banner_hover(0)>
          <dt><?php echo _g('ba1name'); ?> </dt>
          <dd class=design_dd><?php echo _g('ba1js'); ?> </dd>
        </dl>
        <dl class=design_center onmouseover=banner_hover(1)>
          <dt><?php echo _g('ba2name'); ?> </dt>
          <dd class=design_dd><?php echo _g('ba2js'); ?> </dd>
        </dl>
        <dl onmouseover=banner_hover(2)>
          <dt><?php echo _g('ba3name'); ?> </dt>
          <dd class=design_dd><?php echo _g('ba3js'); ?> </dd>
        </dl>
        <div class=clear></div>
      </div>
    </div>
  </div>
  <?php endif; ?>
</div>
<div class="content-box">
<div class="motto">
<?php if (_g('wygg')=='y'): ?>
 <div class="bulletin"> 
				<ul>
					<?php global $CACHE;$newtws_cache = $CACHE->readCache('newtw');?>
					<?php foreach($newtws_cache as $value): ?>
					<?php $img = empty($value['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" target="_blank"><span class="icon-image"></span></a>';?>
					<li><?php echo preg_replace("/\[F(([1-4]?[0-9])|50)\]/",'<img alt="face" src="'.TEMPLATE_URL.'images/face/$1.gif"  />',$value['t']);echo $img;echo date('（Y年n月j日）',$value['date']);?></li>
					<?php endforeach; ?>
				</ul>
			</div>
<?php endif; ?>
	<div class="box">
		<ul id="contact-li">
			<li class="qq"><a rel="nofollow" target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo _g('qq'); ?>&site=qq&menu=yes" title="博主QQ：<?php echo _g('qq'); ?>">QQ联系</a></li>
			<li class="weixin"><a rel="nofollow" target="_blank" href="mailto:<?php echo _g('weixin'); ?>" title="博主微信：<?php echo _g('weixin'); ?><?php echo $isset_email; ?>">微信</a></li>
			<li class="twitter"><a rel="nofollow" target="_blank" href="<?php echo _g('twitter'); ?>" title="博主QQ空间：<?php echo _g('twitter'); ?>">Twitter微博</a></li>
			<li class="qqmblog"><a rel="nofollow" target="_blank" href="<?php echo _g('txwb'); ?>" title="博主腾讯微博：<?php echo _g('txwb'); ?>">腾讯微博</a></li>
			<li class="sinamblog"><a rel="nofollow" target="_blank" href="<?php echo _g('xlwb'); ?>" title="博主新浪微博：<?php echo _g('xlwb'); ?>">新浪微博</a></li>
			<li class="rss"><a target="_blank" href="http://vbs.so" title="关注Finally">Finally</a></li>
   	<form class="searchform" name="keyform" method="get" action="<?php echo BLOG_URL;?>">
		<input class="search-input" name="keyword" type="text" placeholder="输入关键字搜索"><button class="search-btn" type="submit"><i class="fa fa-search"></i></button>
	</form>
		</ul>
	</div>
</div>
</div>
<div id="container2">
 <ul class="template">
    <section>
		<div class="homelistbox">
			<ul>
<?php 
if (!empty($logs)):
foreach($logs as $value):
$logdes = blog_tool_purecontent($value['content'], 96);
if(pic_thumb($value['content'])){
	$imgsrc = pic_thumb($value['content']);
	}else
	$imgsrc = TEMPLATE_URL.'images/random/tb'.rand(1,10).'.jpg';
?>
	<li class="listbox">
		<a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><img width="360" height="200" src="<?php echo $imgsrc;?>" class="attachment-thumbnail wp-post-image" alt="<?php echo $value['log_title']; ?>"/></a>
				<div class="summary"><div class="summarytxt"><p><?php echo subString(strip_tags($value['log_title']),0,50); ?></p></div></div>
				<div class="listinfo">
					<div class="listtag">标签：<?php blog_tag($value['logid']); ?></div>
					<div class="listdate">时间:<?php echo gmdate('Y-n-j', $value['date']); ?></div>
					<div class="listview">阅读:<?php echo $value['views']; ?></div>
					<h4><a href="<?php echo $value['log_url']; ?>"><b>查看</b><span>全文</span></a></h4>
				</div>
				</li>
<?php 
endforeach;
else:
?>
	<li class="nothing">你找到的东西已飞宇宙黑洞去了！</li>
<?php endif;?>
			</ul>
		</div>
    </section>
 </ul>
		<div class="page"><?php echo $page_url;?></div>
</div>
		<div class="clear"></div>
<div class="idea">
 <p><?php echo _g('botsm'); ?>
 </p>
</div>
<?php
 include View::getView('footer');
?>