<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="container2">
		<ul class="template">
			<section>
				<div class="pagetitle">
			<h2>
            <?php if ($params[1]=='sort'){ ?>
		分类：<?php echo $sortName;?>
<?php }elseif ($params[1]=='tag'){ ?>
		标签:<?php echo htmlspecialchars(urldecode($params[2]));?>
<?php }elseif($params[1]=='author'){ ?>
		作者：<?php echo blog_author($author);?>
<?php }elseif($params[1]=='keyword'){ ?>
       关键词：<?php echo htmlspecialchars(urldecode($params[2]));?>
<?php }elseif($params[1]=='record'){ ?>
       时间：<?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?>
<?php }else{?>文章列表<?php }?>
            </h2>
		</div>
		</section>
		<div class="contentbox">
			<div class="contenttitle">
				<h1><?php echo $log_title; ?></h1>
				<span class="info"><?php editflg($logid,$author); ?> 日期：<?php echo gmdate('Y-n-j G:i l', $date); ?></span>
			</div>
			<div class="contentview">
				浏览次数<span><?php echo $views; ?></span>
			</div>
			<div class="contenttxt"><div class="clear"></div><?php echo $log_content; ?><?php doAction('log_related', $logData); ?></div>
			
		<div class="contenttagbox">
			<div class="contenttaglist"><?php blog_tag($logid); ?></div>
		</div>
		<div class="contentprevnextbox"><?php neighbor_log($neighborLog); ?></div>
		<div class="declarationbox"><b>特别声明：</b><?php echo _g('tbsm')?></div>
		<div class="ds-thread" data-thread-key="<?php echo $logid;?>" data-title="<?php echo $log_title; ?>" data-url="<?php echo $log_url; ?>"></div>
		<div class="clear"></div>
		</div>
		 </ul>
</div>
<div class="clear"></div>
<?php
 include View::getView('footer');
?>