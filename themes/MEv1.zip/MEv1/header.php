<?php
/*
Template Name:MEv1
Description: <font color=red>＊</font>有问题的可以告诉我QQ；1501700017<br><font color=red>＊</font>这个模板为免费模板，后续可能会更新<br><a href="http://emlog.pigzt.com/?theme=MEv1" target="_blank">主题演示</a>  <a href="http://vbs.so/emlog/MEv1.html" target="_blank">使用说明</a>
Version:1.0
Author:M1dint3r
Author Url:http://vbs.so
Sidebar Amount:3
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
$theme_version='1.0';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<!--
// 　　　　　　　　┏┓　　　┏┓
// 　　　　　　　┏┛┻━━━┛┻┓  
// 　　　　　　　┃　　　　　　　┃ 　 
// 　　　　　　　┃　　　━　　　┃   
// 　　　　　　　┃　＞　　　＜　┃
// 　　　　　　　┃　　　　　　　┃
// 　　　　　　　┃...　⌒　...  ┃
// 　　　　　　　┃　　　　　　　┃ 
// 　　　　　　　┗━┓　　　┏━┛ 
// 　　　　　　　　　┃　　　┃　Code is far away from bug with the animal protecting　　　　　　　　　　 
// 　　　　　　　　　┃　　　┃    神兽保佑,代码无bug
// 　　　　　　　　　┃　　　┃　　　　　　　　　　　 
// 　　　　　　　　　┃　　　┃  　　　　　　 
// 　　　　　　　　　┃　　　┃ 
// 　　　　　　　　　┃　　　┃　　　　　　　　　　　 
// 　　　　　　　　　┃　　　┗━━━┓ 
// 　　　　　　　　　┃　　　　　　　┣┓ 
// 　　　　　　　　　┃　　　　　　　┏┛ 
// 　　　　　　　　　┗┓┓┏━┳┓┏┛ 
// 　　　　　　　　　　┃┫┫　┃┫┫ 
// 　　　　　　　　　　┗┻┛　┗┻┛
//
-->
<!-- <?php echo $site_title; ?>欢迎您！ <?php echo BLOG_URL; ?> -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>css/styles.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>css/index.css" rel="stylesheet" media="screen" type="text/css" />
<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
<!--[if lt IE 9]>
<script src="<?php echo TEMPLATE_URL; ?>js/modernizr.js"></script>
<![endif]-->
<script src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/main.js"></script>
<SCRIPT type=text/javascript src="<?php echo TEMPLATE_URL; ?>js/jquery.cycle.all.js"></SCRIPT>
<SCRIPT type=text/javascript src="<?php echo TEMPLATE_URL; ?>js/index.js"></SCRIPT>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>

<body>
<header>
<a href="<?php echo BLOG_URL; ?>" id="logo" title="<?php echo $blogname; ?>"><img src="<?php echo _g('logo'); ?>" alt=""/></a>
 <div id="wrap-menu">                    
   <ul id="header-menu">
		<?php blog_navi();?>
    </ul>
</div>            
</header>