<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="wrap">
	<div class="mainleft">
		<?php if(blog_tool_ishome()):?>
		<div class="notice">
			<div class="r">
				<script type="text/javascript">
                /*mcytop百度640*/
                var cpro_id = "u1425182";
                </script>
                <script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script>
			</div>
			<div class="clear"></div>
		</div>
		<?php else:?>
		<div class="bread">
			<h3>
<?php if ($params[1]=='sort'){ ?>
			<b>分类“<?php echo $sortName; ?>”</b>
<?php }elseif ($params[1]=='tag'){ ?>
			<b>标签“<?php echo urldecode($params[2]);?>”</b>
<?php }elseif($params[1]=='author'){ ?>
			<b>作者“<?php echo blog_author($author);?>”发布的内容</b> 
<?php }elseif($params[1]=='keyword'){ ?>
            <b>关键词“<?php echo urldecode($params[2]);?>”的搜索结果</b> 
<?php }elseif($params[1]=='record'){ ?>
            <b>发表在“<?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?>”的内容</b>
				<?php }else{}?>
			</h3>
		</div>
		<div class="clear"></div>
		<?php endif;?>
		<div class="list">
        <?php echo index_show(); ?>
<?php 
if (!empty($logs)):
foreach($logs as $key=>$value): 
$search_pattern = '%<img[^>]*?src=[\'\"]((?:(?!\/admin\/|>).)+?)[\'\"][^>]*?>%s';
preg_match($search_pattern, $value['content'], $img);
$value['img'] = isset($img[1])?$img[1]:TEMPLATE_URL.'pic/ap'.rand(1,15).'.jpg';
?>
			<div class="item list-item">
				<div class="l">
					<div class="date">
						<div class="t">
							<?php echo gmdate('j', $value['date']); ?> 
						</div>
						<div class="b"><?php echo gmdate('Y-n', $value['date']); ?></div>
					</div>
				</div>
                <div class="l2">
                    <h3><a href="<?php echo $value['log_url']; ?>" target="_blank"><?php echo subString($value['log_title'],0,20); ?></a><span class="e"><?php editflg($value['logid'],$value['author']); ?></span></h3>
                    <div class="tags">
                        <span><?php blogtags($value['logid']); ?></span>
                    </div>
                </div>
                <div class="clear"></div>
				<div class="r">
					<div class="m">
						<div class="con">
                          <a target="_blank" class="a-img" href="<?php echo $value['log_url']; ?>"><img src="<?php echo $value['img']; ?>" alt="<?php echo $value['log_title']; ?>" title="<?php echo $value['log_title'] ?>" /></a>
						  <div class="article-box-ctt"><?php echo subString(strip_tags($value['log_description']),0,150,"......"); ?></div>
						</div>
						<div class="meta">
							<div class="tag">
								<span class="author">作者：<?php blog_author($value['author']); ?></span>
								<span class="cat"><?php blog_sort($value['logid']); ?></span>
							</div>
							<div class="view">
								<span class="v">浏览：<?php echo $value['views']; ?></span>
								<span class="c">评论：<?php echo $value['comnum']; ?></span>
							</div>
							<div class="clear"></div>
						</div>
					</div>
				</div>
				<div class="clear"></div>
			</div><!--//item end-->
<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>

<div id="pagenavi">
	<?php echo $page_url;?>
	<div class="clear"></div>
</div>
		</div><!--//list end-->
	</div>
	<div class="mainright">
		<?php
			include View::getView('side');
		?>
	</div><!-- //mainright end-->
	<div class="clear"></div>
        <div id="frdlink">
			<b>友情链接：</b>
			<ul>
				<?php frdlink();?>
				<div class="clear"></div>
			</ul>
			<div class="clear"></div>
		</div>
<?php
 include View::getView('footer');
?>
