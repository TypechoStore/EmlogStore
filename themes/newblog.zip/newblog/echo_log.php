<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="l-header-ad">
	<script type="text/javascript">
    /*show页中部960百度*/
    var cpro_id = "u1417385";
    </script>
    <script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script>
</div>
<div class="wrap">
	<div class="mainleft">
		<div class="list content">
			<div class="item">
				<div class="r">
					<div class="m">
						<div class="t position">
							<span class="inner"><a href="<?php echo BLOG_URL;?>" title="返回首页">首页</a> >> <?php getBlogSort($logid);?> >> <?php echo $log_title; ?></span>
						</div>
						<h1><?php topflg($top); ?><?php echo $log_title; ?><span class="e"><?php editflg($logid,$author); ?></span></h1>
                        <div class="meta">
							<div class="tag">
								<span class="author"><?php blog_author($author); ?></span>
                                <span><?php echo gmdate('Y-n-j G:i', $date); ?></span>
								<span class="cat"><?php blog_sort($logid); ?></span>
                                <span class='tags'><?php blogtags($logid); ?></span>
							</div>
							<div class="view">
								<span class="v">浏览：<?php echo $views; ?></span>
								<span class="c">评论：<?php echo $comnum; ?></span>
							</div>
							<div class="clear"></div>
						</div>
                        <div class="log-share" style="overflow:hidden; width:420px; margin:0 auto;">
                            <script type="text/javascript">
							/*mcycontop百度*/
							var cpro_id = "u1454115";
							</script>
							<script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script>
                        </div>
                        
						<div class="con">
                        <!--<div class="l-main-inner-ad">
							   <script type="text/javascript">
								/*mcy-inner-ad*/
								var cpro_id = "u1454152";
								</script>
							   <script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script>
							</div>-->
							<?php echo $log_content; ?>
							<?php doAction('log_related', $logData); ?>
                            <div id="copylink">本文地址：<a href="<?php echo Url::log($logid);?>" id="linkbar" /><?php echo Url::log($logid);?></a></div>
							<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
							<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
						</div>
					</div>
				</div>
				<div class="clear"></div>
			</div><!--//item end-->
			<div class="item">
				<div class="l">
				</div>
				<div class="r2">
					<div class="m">
						<div class="con pinglun" id="pinglun">
							<?php blog_comments($comments); ?>
							<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
						</div>
					</div>
				</div>
				<div class="clear"></div>
			</div><!--//item end-->
		</div><!--//list end-->
	</div>
	<div class="mainright">
		<?php
			include View::getView('side');
		?>
	</div><!-- //mainright end-->
	<div class="clear"></div>
<?php
 include View::getView('footer');
?>