<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="doc">
<div id="posts">


<?php foreach($logs as $value): ?>
<div class="post">
            <h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
                <div class="text">
				
                      <?php echo $value['log_description']; ?>
                </div>
                <div class="texticon"></div>
                <div class="clear"></div>
                <div class="meta noborder">
                    <div class="time">
						<a href="<?php echo $value['log_url']; ?>">全文链接</a>	
                    	<?php echo gmdate('Y年n月j日 ', $value['date']); ?> 
                    </div>
                    <div class="hotcnt"><a href="<?php echo $value['log_url']; ?>#respond"><?php echo $value['comnum']; ?>评论</a>
                    </div>
                </div>     
            </div>
<?php endforeach; ?>

<div class="pager">
				<?php echo $page_url;?>	
				</div>
				</div>
				
<?php
 include View::getView('side');
 include View::getView('footer');
?>