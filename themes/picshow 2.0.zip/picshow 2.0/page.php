<?php 
<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="doc">

<div id="posts">
        
			            <!-- 文字 --> 
            <div class="post">
            	<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
                <div class="text">
				
                     <?php echo $log_content; ?>
                </div>
                <div class="texticon"></div>
                <div class="clear"></div>
                <div class="meta noborder">
                    <div >
                    </div>
                    <div class="hotcnt">
                    </div>
                </div>     
            </div>
						
            <div class="clear"></div>
		
<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
			
        </div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>