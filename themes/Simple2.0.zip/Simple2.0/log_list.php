<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="contentleft">
<?php doAction('index_loglist_top'); ?>

<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
	<h3><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h3>
	<?php echo $value['log_description']; ?></br>
    <div class="info info-1">
        <div class="tags"><?php echo gmdate('Y， n， j', $value['date']); ?>&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;<?php blog_sort($value['logid']); ?>&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;<a href="<?php echo $value['log_url']; ?>">点击阅读</a><span class="reply"><?php echo $log_content; ?></span></div>
	</div>
	<div style="clear:both;"></div>
<?php 
endforeach;
?>
<div id="bg">
<li id="page-navi" style="list-style-type:none"><?php echo $page_url;?></li>
</div>
<?php
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
</div><!-- end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>