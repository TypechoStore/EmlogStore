<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--end #content-->
<div style="clear:both;"></div>
<div id="footerbar">
	<a href="http://www.ma-am.cn/" title="首页">首页</a>&nbsp;&nbsp;&nbsp; /&nbsp;&nbsp;&nbsp;
		<a href="http://www.ma-am.cn/t" title="碎语">碎语</a>&nbsp;&nbsp;&nbsp; /&nbsp;&nbsp;&nbsp;
			<a href="http://www.ma-am.cn/about" title="关于">关于</a>&nbsp;&nbsp;&nbsp; /&nbsp;&nbsp;&nbsp;
			<a href="http://www.ma-am.cn/guestbook" title="留言">留言</a>&nbsp;&nbsp;&nbsp; /&nbsp;&nbsp;&nbsp;
	<a href="http://www.emlog.net" title="采用emlog系统">emlog</a>&nbsp;&nbsp;&nbsp; /&nbsp;&nbsp;&nbsp; &copy; 2014 <a href="http://www.ma-am.cn/">微语日记。</a>
	<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
	<?php doAction('index_footer'); ?>
</div><!--end #footerbar-->
</div><!--end #wrap-->
<script>prettyPrint();</script>
</body>
</html>