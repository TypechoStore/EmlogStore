<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="daweb">
	<div id="web" class="w1002">
		<div class="ziweb">
		    <div class="web-left floatl">
				<h3 id="tetitle" class="title"><span class="span1 floatl">产品系列</span><span class="span2 floatr">CATEGORIES</span></h3>
				<div class="box" id="sidebar">
					<dl class="list-none navnow">
            			<?php echo widget_sort(); ?>
            		</dl>
        		</div>
				<h3 id="tetitle" class="title line"><span class="span1 floatl">联系方式</span><span class="span2 floatr">CONTACT US</span></h3>
				<div class="box editor"><p>
	<?php echo $blogname; ?><br />
	<?php echo $itel; ?><br />
	<?php echo $imob; ?><br />
	<?php echo $iqq; ?><br />
	<?php echo $ipost; ?><br />
	<?php echo $email; ?><br />
	网址：<a href="<?php echo BLOG_URL; ?>"><?php echo BLOG_URL; ?></a></p>
				</div>
		    </div>
    		<div class="web-right floatr ">
	    		<h3 class="title"><div>您现在所在的位置: <a href="<?php echo BLOG_URL; ?>" title="首页">首页</a> &gt; <a href="<?php echo Url::log($logid); ?>"><?php echo $log_title; ?></a></div></h3>
				<div class="shownews webbox">
            		<h1 class="title"><?php topflg($top); ?><?php echo $log_title; ?></h1>
            		<div class="editor">
<?php echo $log_content; ?>
					</div>
					<div class="hits">
浏览次数:<span><?php echo $views; ?></span>&nbsp;&nbsp;更新时间:<?php echo gmdate('Y-n-j G:i', $date); ?>
					</div>
        		</div>
        		<?php blog_comments($comments); ?>
				<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    	</div>
	</div>
    <div class="clear"></div>
<?php
 include View::getView('footer');
?>