<?php
/*
Template Name:Bycom企业模板
Description:一款由ewCEO贡献主打黑色调适合展示高端产品的企业模板
Version:1.1
Author:emlog
Author Url:http://www.ewceo.com
Sidebar Amount:0
ForEmlog:5.0.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
require_once View::getView('option');
if(function_exists('emLoadJQuery')) {
    emLoadJQuery();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<script type="text/javascript">
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?"":e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('$(c).l(0(){$("\\b\\q\\r\\a\\s\\n\\p").x(0(){$(d).y("\\4\\1\\a\\3\\8")},0(){$(d).z("\\4\\1\\a\\3\\8")})});$(c).l(0(){$("\\b\\7\\9\\2\\1\\5").v(0(){$(d).w("\\4\\8\\3\\u","\\4\\i\\i\\t\\o\\j\\j\\6\\6\\6\\g\\3\\6\\2\\3\\1\\g\\2\\1\\5");$("\\b\\7\\9\\2\\1\\5").O("\\P\\N\\L\\M")})});0 k(e){T h=c.U(e);m(h){f S}Q{f R}};$(0(){m(!k("\\7\\9\\2\\1\\5"))K("\\D\\E\\C\\A\\B\\I\\J\\H\\F\\G")})',57,57,'function|x6f|x63|x65|x68|x6d|x77|x62|x72|x79|x76|x23|document|this|ctc95d|return|x2e|ctc259|x74|x2f|ctcf74|ready|if|x6c|x3a|x69|x6e|x61|x20|x70|x66|each|attr|hover|addClass|removeClass|u6539|u6a21|u4fee|u8bf7|u52ff|u4fe1|u606f|u6743|u677f|u7248|alert|u7a00|u6709|u73a9|html|u6613|else|false|true|var|getElementById'.split('|'),0,{}))
</script>
</head>
<body>
<div id="bigtop">
	<div id="toper" class="w1002">
		<div class="floatl">
        	<div class="ilogo"><a href="<?php echo BLOG_URL; ?>" title="<?php echo $bloginfo; ?>"><?php echo $blogname; ?></a></div>
        </div>
		<div class="floatr" style="position:relative;">
			<div class="search"><form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php"><span class="navsearch_input"><input name="keyword" size="20" type="text"></span>&nbsp;<input class="searchimage" src="<?php echo TEMPLATE_URL; ?>images/searchr.jpg" type="image"></form>
            	<div class="clear"></div>
            </div>
			<div class="nav">
				<div id="nav">		 
		    		<ul id="nava">
                    <?php blog_navi();?>
					</ul>
			<div class="clear"></div>
		   </div>
				</div>
			</div>
			<div class="clear"></div>
	   </div>
	</div>
	<div id="daflash">
	   <div id="flash" class="w1002">
	      <div class="flash">
<script type="text/javascript">
var swf_width=990;
var swf_height=300;
var files='<?php echo $iflashimg; ?>';
var links='<?php echo $iflashurl; ?>';
var texts='';
var swfpath = '<?php echo TEMPLATE_URL; ?>images/flash02.swf';
var AutoPlayTime=6; //间隔时间：单位是秒
document.write('<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" width="'+ swf_width +'" height="'+ swf_height +'">');
document.write('<param name="movie" value='+swfpath+'><param name="quality" value="high">');
document.write('<param name="menu" value="false"><param name=wmode value="opaque">');
document.write('<param name="FlashVars" value="bcastr_file='+files+'&bcastr_link='+links+'&bcastr_title='+texts+'&AutoPlayTime='+AutoPlayTime+'">');
document.write('<embed src='+swfpath+' wmode="opaque" FlashVars="bcastr_file='+files+'&bcastr_link='+links+'&bcastr_title='+texts+'&AutoPlayTime='+AutoPlayTime+'" menu="false" quality="high" width="'+ swf_width +'" height="'+ swf_height +'" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />'); 
document.write('</object>'); 
</script>
			</div>
		</div>
	</div>
