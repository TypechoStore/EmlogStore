<?php
/*
 * Bycom企业模板配置文件
 * 如果您确定足够了解以下内容，则可以尝试自行修改
 */

//链接部分
$abouturl = "http://www.ewceo.com/pr.html"; //关于我们
$contacturl = "http://www.ewceo.com/"; //联系我们
$guestbookurl = "http://www.ewceo.com/"; //在线留言


//内容部分
$iflashimg = "/content/templates/bycom/images/1313856991.jpg|/content/templates/bycom/images/1313857453.jpg|/content/templates/bycom/images/8164537.jpg"; //头部幻灯图片名，默认3个并用|隔开
$iflashurl = "http://www.ewceo.com/|http://www.baidu.com/|http://www.ewceo2.com/"; //头部幻灯链接，默认3个并用|隔开
$iabimg = "ip1.jpg"; //首页企业简介形象图名
$iabus = "湖南德万商贸有限公司是一家系统办公家具公司，系统是产品齐全，系统是服务全程，节约客户宝贵时间，勇担责任，引导客户做出合理决策"; //首页企业简介摘要
$email = "Email：sales@ewceo.com";
$itel = "电  话：0888-87654321";
$imob = "手  机：18988888888";
$iqq = "Q    Q：<a target='_blank' href='http://wpa.qq.com/msgrd?v=3&uin=123&site=qq&menu=yes' title='点击Q我'>87654321</a>";
$ipost = "邮  编：123000";

?>
