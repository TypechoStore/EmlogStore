<?php 
/*
* 首页[index]
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="contentfooter">
	<div id="content" class="w1002">
		<div id="zicontent">
			<div id="dafloatl" class="floatl">
				<div class="floatl">
					<h3 class="title"><span class="span1">产品系列</span><span class="span2">CATEGORIES</span></h3>
					<div id="productlists">
						<dl class="list-none navnow">
							<?php echo widget_sort(); ?>
						</dl>
					</div>
				</div>
				<div class="floatr">
					<h3 class="title floatl"><span class="span11">新品推荐</span></h3>
					<div id="productlists" class="floatr">
<script type="text/javascript">
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?"":e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('$.H.G=b(e){h z={w:F,m:I};e=$.L(z,e);K r.J(b(){h 4=$("\\i\\3",r);4.7({E:"\\f\\B\\n\\q\\i\\D\\6\\2"});4.C().7({R:"\\x",S:"\\x","\\i\\3\\n\\6\\c\\n\\6\\T\\i\\2":"\\5\\q\\5\\2",U:"\\Q\\3\\a\\a\\2\\5"});b y(){h d=4.u("\\v\\f\\g\\6\\3\\k\\2").t?4.u("\\v\\f\\g\\6\\3\\k\\2"):4.o();h p=d.s().t?d.s():4.o();d.7({"\\j\\c\\3\\5\\a\\2\\l":9});p.7({A:0.0,"\\j\\c\\3\\5\\a\\2\\l":N}).M(\'\\f\\g\\6\\3\\k\\2\').m({A:1.0},e.m,b(){d.P(\'\\f\\g\\6\\3\\k\\2\').7({"\\j\\c\\3\\5\\a\\2\\l":8})})};4.o().7({"\\j\\c\\3\\5\\a\\2\\l":9});O(b(){y()},e.w)})};',57,57,'||x65|x69|ctc635|x6e|x74|css|||x64|function|x2d|ctcee7|ctcaa6|x61|x63|var|x6c|x7a|x76|x78|animate|x73|first|ctc59c|x6f|this|next|length|filter|x2e|speed|x30|ctc187|ctce81|opacity|x62|parent|x75|position|5000|imgtransition|fn|1000|each|return|extend|addClass|10|setInterval|removeClass|x68|margin|padding|x79|overflow'.split('|'),0,{}))
</script>
						<div id="advsheadlb">
							<ul>
								<?php slide_pic() ?>
							</ul>
						</div>
<script type="text/javascript">
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?"":e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('$(6).5(8(){$(\'\\7\\1\\0\\2\\3\\4\\9\\1\\0\\f\\g\').d({a:b,c:e})});',17,17,'x64|x61|x76|x73|x68|ready|document|x23|function|x65|speed|3000|animate|imgtransition|1000|x6c|x62'.split('|'),0,{}))
</script> 
					</div>
					<div class="clear"></div>
				</div>
				<div class="clear"></div>
			</div>
			<div id="dafloatr" class="floatr">
				<h3 class="title"><a href="<?php echo $abouturl; ?>" class="more"></a><span class="span1">公司简介</span><span class="span2">ABOUT US</span>			</h3>
				<div id="indexcontent">
<img alt="" src="<?php echo TEMPLATE_URL; ?>images/<?php echo $iabimg; ?>" />&nbsp;&nbsp;&nbsp; <?php echo $iabus; ?>...
				</div>
                <div id="indexnews">
					<ul class="list">
                    	<?php get_list('2');?><!--如需变更调用栏目内容，请修改左侧括号内的数字-->
					</ul>
				</div>
			</div>
			<div class="clear"></div>
		</div>
        <ul id="ilink">
            <li>友情链接：</li>
        	<?php widget_link() ?>
            <li><a href="http://www.ewceo.com/" target="_blank">易玩稀有</a></li>
		</ul>
        <div class="clear"></div>
	</div>
<?php
 include View::getView('footer');
?>