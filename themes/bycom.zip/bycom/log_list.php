<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
if($pageurl == Url::logPage()){
	include View::getView('index');
	exit;
}
?>
<div id="daweb">
	<div id="web" class="w1002">
		<div class="ziweb">
		    <div class="web-left floatl">
				<h3 id="tetitle" class="title"><span class="span1 floatl">产品系列</span><span class="span2 floatr">CATEGORIES</span></h3>
				<div class="box" id="sidebar">
					<dl class="list-none navnow">
            			<?php echo widget_sort(); ?>
            		</dl>
        		</div>
				<h3 id="tetitle" class="title line"><span class="span1 floatl">联系方式</span><span class="span2 floatr">CONTACT US</span></h3>
				<div class="box editor"><p>
	<?php echo $blogname; ?><br />
	<?php echo $itel; ?><br />
	<?php echo $imob; ?><br />
	<?php echo $iqq; ?><br />
	<?php echo $ipost; ?><br />
	<?php echo $email; ?><br />
	网址：<a href="<?php echo BLOG_URL; ?>"><?php echo BLOG_URL; ?></a></p>
				</div>
		    </div>
			<div class="web-right floatr ">
				<h3 class="title"><div>您现在所在的位置: <a href="<?php echo BLOG_URL; ?>">首页</a> &gt; <?php if ($params[1]=='sort'){ ?>
		<?php echo '<a href="'.Url::sort($sortid).'">'.$sortName.'</a>';?>
<?php }elseif ($params[1]=='tag'){ ?>
			包含标签 <b><?php echo urldecode($params[2]);?></b> 的所有文章
<?php }elseif($params[1]=='author'){ ?>
			作者 <b><?php echo blog_author($author);?></b> 的所有文章
<?php }elseif($params[1]=='keyword'){ ?>
            搜索关键词 <b><?php echo urldecode($params[2]);?></b> 的结果
<?php }else{?><?php }?></div></h3>
				<div class="newslist webbox">
<?php doAction('index_loglist_top'); ?>
        <?php if($logs == NULL) { ?>
		<div style="color:#F00;text-align:center;padding:60px 0">
抱歉，没有找到相关内容<br /><br /><a href="javascript:history.back(-1)">返回</a>
		</div>
		<?php } ?>
					<ul class='list-none metlist'>
<?php foreach($logs as $value): ?>
            			<li class='list'><span>[<?php echo gmdate('Y/n/j', $value['date']); ?>]</span><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></li>
<?php endforeach; ?>
            		</ul>
					<div id="pages">
<?php echo $page_url;?>
					 </div>
				</div>
			</div>
    		<div class="clear"></div>
		</div>
	</div>
<?php
 include View::getView('footer');
?>

