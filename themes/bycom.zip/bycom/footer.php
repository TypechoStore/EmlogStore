<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="footer" class="w1002">
		<div class="nav">
<a href="<?php echo $guestbookurl; ?>">在线留言</a><span>|</span><a href="<?php echo $abouturl; ?>">关于我们</a><span>|</span><a href="<?php echo $contacturl; ?>">联系我们</a><span>|</span><a href="<?php echo BLOG_URL; ?>m/">网站手机版</a><span>|</span><a href="<?php echo BLOG_URL; ?>rss.php">网站RSS信息</a><span>|</span><a href="<?php echo BLOG_URL; ?>admin/">网站管理</a>
		</div>
		<div class="text">
			<p><!--请注意：修改模板版权信息可能导致出错提示，如确需去版权请联系模板作者获取授权版，详见模板说明-->
Powered&nbsp;by&nbsp;<a href="http://www.emlog.net" target="_blank" title="emlog <?php echo Option::EMLOG_VERSION;?>"><b>Emlog</b></a>&nbsp;&amp;&nbsp;Themes by <a id="bycom" href="http://www.ewceo.com/" target="_blank" title="易玩稀有">易玩稀有</a>&nbsp;&nbsp;<?php echo $footer_info; ?>&nbsp;&nbsp;<?php echo $icp; ?><br /><?php doAction('index_footer'); ?>
			</p>
		</div>
	</div>
</div>	
</body>
</html>