<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="daweb">
	<div id="web" class="w1002">
		<div class="ziweb">
		    <div class="web-left floatl">
				<h3 id="tetitle" class="title"><span class="span1 floatl">产品系列</span><span class="span2 floatr">CATEGORIES</span></h3>
				<div class="box" id="sidebar">
					<dl class="list-none navnow">
            			<?php echo widget_sort(); ?>
            		</dl>
        		</div>
				<h3 id="tetitle" class="title line"><span class="span1 floatl">联系方式</span><span class="span2 floatr">CONTACT US</span></h3>
				<div class="box editor"><p>
	<?php echo $blogname; ?><br />
	<?php echo $itel; ?><br />
	<?php echo $imob; ?><br />
	<?php echo $iqq; ?><br />
	<?php echo $ipost; ?><br />
	<?php echo $email; ?><br />
	网址：<a href="<?php echo BLOG_URL; ?>"><?php echo BLOG_URL; ?></a></p>
				</div>
		    </div>
    		<div class="web-right floatr ">
	    		<h3 class="title"><div>您现在所在的位置: <a href="<?php echo BLOG_URL; ?>" title="首页">首页</a> &gt; 公告通知<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo BLOG_URL . 'admin/twitter.php' ?>">[发布公告]</a><?php endif; ?></div></h3>
				<div class="shownews webbox">
            		<div class="editor">
						<div id="tw">
							<h1 class="title"><?php echo $blogname; ?>公告通知<span>(已发布<?php echo $twnum; ?>条)</span></h1>
    <ul>
    <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?> 
    <li class="li">
    <p class="post1">以下内容由 <span><?php echo $author; ?></span> 于 <?php echo $val['date'];?> 发布：<br /><br /><?php echo $val['t'].'<br/>'.$img;?></p>
    <div class="clear"></div>
   	<ul id="r_<?php echo $tid;?>" class="r"></ul>
    </li>
    <?php endforeach;?>
	<li id="pages"><?php echo $pageurl;?></li>
    </ul>
						</div>
					</div>
        		</div>
    	</div>
	</div>
    <div class="clear"></div>
<?php
 include View::getView('footer');
?>
