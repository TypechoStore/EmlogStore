<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="footer" class="clear">
	<div class="credits">
		Theme: <a href="http://lwllo.com" target="_blank">Optimus</a> | Power: <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a><?php echo $footer_info; ?>
	</div>
<?php doAction('index_footer'); ?>
	<form method="get" id="searchform" name="keyform" class="searchform" action="<?php echo BLOG_URL; ?>index.php">
		<div id="search" class="hentry"><input type="text" value="Search..." name="keyword" id="s" size="15" onfocus="this.value = this.value == this.defaultValue ? '' : this.value" onblur="this.value = this.value == '' ? this.defaultValue : this.value"/></div>
	</form>
</div>
</div>
</div>
</body>
</html>