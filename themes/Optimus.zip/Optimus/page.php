<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">	
<div id="posts">
				<div class="postWrapper">
		<div class="post hentry">
			<div class="postContent">
			<?php if(isset($_GET['plugin'])){$log_title=$navibar[addslashes($_GET['plugin'])]['title'];} ?>
				<h2><?php topflg($top); ?><a href="<?php echo $log_url; ?>"><?php echo $log_title; ?></a></h2>
				<?php echo $log_content; ?>
		</div>
		</div>
		      </div>
		<?php if($allow_remark == 'y'): ?>
	<div id="comments"><div class="comt">
		<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div></div><?php endif;?>
	</div></div>
<?php
 //include View::getView('side');
 include View::getView('footer');
?>