﻿<script type="text/javascript" language="javascript">
/* <![CDATA[ */
    function grin(tag) {
    	var myField;
    	tag = ' ' + tag + ' ';
        if (document.getElementById('comment') && document.getElementById('comment').type == 'textarea') {
    		myField = document.getElementById('comment');
    	} else {
    		return false;
    	}
    	if (document.selection) {
    		myField.focus();
    		sel = document.selection.createRange();
    		sel.text = tag;
    		myField.focus();
    	}
    	else if (myField.selectionStart || myField.selectionStart == '0') {
    		var startPos = myField.selectionStart;
    		var endPos = myField.selectionEnd;
    		var cursorPos = endPos;
    		myField.value = myField.value.substring(0, startPos)
    					  + tag
    					  + myField.value.substring(endPos, myField.value.length);
    		cursorPos += tag.length;
    		myField.focus();
    		myField.selectionStart = cursorPos;
    		myField.selectionEnd = cursorPos;
    	}
    	else {
    		myField.value += tag;
    		myField.focus();
    	}
    }
/* ]]> */
</script>
<a href="javascript:grin('{smile:1}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/1.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:2}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/2.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:3}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/3.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:4}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/4.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:5}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/5.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:6}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/6.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:7}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/7.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:8}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/8.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:9}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/9.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:10}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/10.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:11}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/11.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:12}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/12.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:13}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/13.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:14}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/14.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:15}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/15.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:16}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/16.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:17}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/17.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:18}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/18.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:19}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/19.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:20}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/20.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:21}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/21.gif" alt="" title="" /></a>
<a href="javascript:grin('{smile:22}')"><img src="<?php echo TEMPLATE_URL; ?>smiles/22.gif" alt="" title="" /></a>
<br />