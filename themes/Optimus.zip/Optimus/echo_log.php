<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">	
<div id="posts">
				<div class="postWrapper">
		<div class="post hentry">
			<div class="postContent">
				<h2><?php topflg($top); ?><a href="<?php echo $log_url; ?>"><?php echo $log_title; ?></a></h2>
				<?php echo $log_content; ?><?php blog_att($logid); ?>
				<?php doAction('log_related', $logData); ?>				
		</div>		
			<div class="postInfo">
				<div class="postTags"><?php echo gmdate('Y-n-j G:i', $date); ?><br /> <a href="<?php echo $log_url; ?>">浏览(<?php echo $views; ?>)</a>  | <?php blog_tag($logid); ?></div>
				<div class="postNotes"><a href="<?php echo $log_url; ?>#comments">评论(<?php echo $comnum; ?>)</a></div>
				
				<div class="clear"></div>
			</div>
		</div>
		</div>
	<div id="comments"><div class="comt">
		<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div></div>
	</div></div>
<?php
 //include View::getView('side');
 include View::getView('footer');
?>