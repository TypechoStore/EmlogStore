<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="content">	<div id="posts">
	<?php doAction('index_loglist_top'); ?>
    <?php foreach($logs as $value): ?>
			<div class="postWrapper">
			<div class="post hentry">
			<div class="postContent"><h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
		    <?php echo $value['log_description']; ?></div>
					<div class="postInfo">
						<div class="postTags"><?php echo gmdate('Y-n-j', $value['date']); ?> <br /><a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a> | <?php blog_tag($value['logid']); ?> | <?php blog_sort($value['logid']); ?></div>
						<div class="postNotes"><a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a></div>
						<div class="clear"></div>
					</div>	
					</div>
		</div>
    <?php endforeach; ?> 
			</div>
		<div class="postWrapper">
		<div class="pagenavi hentry"><?php echo $page_url;?></div>
		</div>
	<!--scounter--></div>

<?php
 //include View::getView('side');
 include View::getView('footer');
?>