<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
	<div id="content-wrap">
		<div id="main">
			<?php doAction('index_loglist_top'); ?>
			<?php foreach($logs as $value): ?>
			<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
			<p class="post-by">Posted by <?php blog_author($value['author']); ?></p>
			<p><?php echo $value['log_description']; ?></p>
			<?php blog_att($value['logid']); ?>
			<?php blog_tag($value['logid']); ?>
			<p class="post-footer align-left">					
			<?php blog_sort($value['logid']); ?>
					<span class="comments">
					<a href="<?php echo $value['log_url']; ?>#comment">评论(<?php echo $value['comnum']; ?>)</a>
					<a href="<?php echo $value['log_url']; ?>#tb">引用(<?php echo $value['tbcount']; ?>)</a> 
					<a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a>
					</span>
					<span class="date"><?php echo gmdate('F Y', $value['date']); ?> <?php editflg($value['logid'],$value['author']); ?></span>	
			</p>
			<br />
			<?php endforeach; ?>
			<p align="center"><?php echo $page_url;?></p>
		</div>
<?php
include View::getView('side');
include View::getView('footer'); 
?>