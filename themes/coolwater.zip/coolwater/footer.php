<div id="footer">
	<p>
		Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> | 
		<?php if($icp): ?><a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?> | <?php endif; ?>
		Design by: <a href="http://www.styleshout.com/">styleshout</a> | Adapted by: <a href="http://www.seobilgi.com">Seobilgi</a>	<a href="http://www.medicalazer.com">Lazer Epilasyon</a> 		
   	</p>
	<?php doAction('index_footer'); ?>
	</div>	
</div>
</body>
</html>