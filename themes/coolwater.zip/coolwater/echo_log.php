<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
	<div id="content-wrap">
		<div id="main">				
			<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
			<p class="post-by">Posted by <?php blog_author($author); ?></p>
			<div class="post">
			<p><?php echo $log_content; ?></p>
			<?php blog_att($logid); ?>
			<?php blog_tag($logid); ?>
			</div>
			<p class="post-footer align-left">					
			<?php blog_sort($logid); ?>
			<span class="date"><?php echo gmdate('Y-n-j G:i l', $date); ?> <?php editflg($logid,$author); ?></span>	
			</p>
			<br />
			<?php doAction('log_related', $logData); ?>
			<p align="center"><?php neighbor_log($neighborLog); ?></p>
			<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
			<?php blog_comments($comments); ?>
			<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);?>
		</div>
<?php
include View::getView('side');
include View::getView('footer'); 
?>