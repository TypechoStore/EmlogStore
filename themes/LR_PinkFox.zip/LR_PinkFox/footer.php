<?php 
/**
* 页面底部信息
Template Name:LR_PinkFox
Description:粉色清新，简洁优雅，
Version:1.3
Author:叶雨梧桐
Author Url:http://blog.gt520.com
Sidebar Amount:0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--end #content-->

<div style="clear:both;"></div>
<div id="footer">
Copyright &copy;  2013-2014 <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>. Powered by <a href="http://www.emlog.net/" rel="external">emlog</a>.
 Theme by <a href="http://blog.gt520.com/" rel="external">叶雨梧桐</a>.
 <a href="http://www.miibeian.gov.cn" target="_blank"  rel="nofollow"><?php echo $icp; ?></a>  <?php doAction('index_footer'); ?>  <?php echo $footer_info; ?>
</div><!--end #footer-->
</div><!--end #wrap-->
<script>prettyPrint();</script>
</body>
</html>