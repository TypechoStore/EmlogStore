<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js"></script>
<script src="<?php echo BLOG_URL; ?>content/templates/t2-pink/js/masonry.min.js"></script>
<?php doAction('index_footer'); ?>
<script>
$(function(){
	var $main=$('.main');
	$main.imagesLoaded(function(){
		$main.masonry({
			itemSelector:'.main-block',
		});
	});
});
</script>
<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="foot">
<div class="foot-link"><?php echo bottom_link(); ?></div>
<div class="foot-right">Powered by <a href="http://www.emlog.net">emlog</a>.Written by <a href="http://www.sinkery.com">sinkery</a>.<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a><br /><?php echo $footer_info; ?>
</div>
</div>
<script type="text/javascript">
$(document).ready(function(){
$(window).scroll(function(){
if($(this).scrollTop()!=0){
$('.top').fadeIn();}
else{
$('.top').fadeOut();} });
$('.top').click(function(){
$('body,html').animate({scrollTop:0},800);});
});

</script>
<div class="top" title="返回顶部">↑
</div>
</body>
</html>
