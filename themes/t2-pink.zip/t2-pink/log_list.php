<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="main">
    <?php doAction('index_loglist_top'); ?>
    <div class="main-block" id="nav-div">
    <div class="logo"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></div>
    <div class="bloginfo"><a href="<?php echo BLOG_URL; ?>"><?php echo $bloginfo; ?></a></div>
	<?php echo blog_navi(); ?>
    </div>
    <div class="main-block" id="search-div">
    <form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
    	<input class="search-box" name="keyword" id="search" type="text" value="搜索从这里开始" onFocus="if(value==defaultValue){value='';}"
onBlur="if(!value){value=defaultValue;}" />
    </form>
	</div>
    <?php foreach($logs as $value): ?>
	<div class="main-block">
    	<div class="main-block-img"><a href="<?php echo $value['log_url']; ?>">
        <!--随机图片部分-->
        <?php
//拉取附件第一张图片，如果没有，则随机拉取img文件夹图片，图片名称任意
	$thum_src = getThumbnail($value['logid']);
	$imgFileArray = glob("content/templates/t2-pink/img/*.*");
	if(!empty($thum_src)){ ?>
    	<img src="<?php echo $thum_src; ?>" border="0" title="<?php echo $value['log_title'] ?>" />
        <?php
	}else{
		?>
        <img src="<?php echo BLOG_URL; ?><?php echo $imgFileArray[array_rand($imgFileArray)]; ?>" />
        <?php
    }
?>
        <!--随机图片部分-->
        </a>
        </div>
        <div class="main-block-content">
        	<div class="main-block-content-sort">/<?php blog_sort($value['logid']); ?>/</div>
            <div class="main-block-content-title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></div>
            <div class="main-block-content-info"><?php echo gmdate('Y.n.j', $value['date']); ?> / <a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?> <?php if($value['comnum']<=1){echo 'Comment';}else{echo 'Comments';} ?></a> / <?php echo $value['views']; ?> <?php if($value['views']<=1){echo 'view';}else{echo 'views';} ?></div>
        </div>
	</div>
    <?php endforeach; ?>
</div>
    <?php if($lognum <= $index_lognum){ ?>
    <style>.t_page-right, .t_page-right{display:none;}</style>
    <?php }elseif($page == 1){ ?>
    <a href="<?php echo BLOG_URL.'?page='.(string)($page+1); ?>" title="下一页"><div class="t_page-right">→</div></a>
    <?php }elseif($page > 1 && $page < ceil($lognum / $index_lognum)){ ?>
    <a href="<?php echo BLOG_URL.'?page='.(string)($page-1); ?>" title="上一页"><div class="t_page-left">←</div></a>
    <a href="<?php echo BLOG_URL.'?page='.(string)($page+1); ?>" title="下一页"><div class="t_page-right">→</div></a>
    <?php }elseif($page >= ceil($lognum / $index_lognum)){ ?>
    <a href="<?php echo BLOG_URL.'?page='.(string)($page-1); ?>" title="上一页"><div class="t_page-left">←</div></a>
    <style>.t_page-right{display:none;}</style>
    <?php } ?>
<?php
 include View::getView('footer');
?>