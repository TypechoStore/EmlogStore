<?php 
/*
* 自建页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="content">
<div class="echo-nav" id="nav-div">
    <div class="logo"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></div>
    <div class="bloginfo"><a href="<?php echo BLOG_URL; ?>"><?php echo $bloginfo; ?></a></div>
	<?php echo blog_navi(); ?>
    <div id="search-div-in">
    <form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
    	<input class="search-box" name="keyword" id="search-in" type="text" value="搜索从这里开始" onFocus="if(value==defaultValue){value='';}"
onBlur="if(!value){value=defaultValue;}" />
    </form>
	</div>
   </div>
	<div class="content-left">
    	<div class="content-left-title"><?php topflg($top); ?><?php echo $log_title; ?></div>
        <div class="content-left-content"><?php echo $log_content; ?></div>
        <?php doAction('log_related', $logData); ?>
        <div class="comment-num"><i><?php echo $comnum; ?> <?php if($comnum<=1){echo 'Message';}else{echo 'Messages';} ?></i></div>
		<?php blog_comments($comments); ?>
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    </div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>