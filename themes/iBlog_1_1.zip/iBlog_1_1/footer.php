<?php
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
    <div class="footer">
    	<div class="aboutLinks">
        	<a href="<?php echo BLOG_URL; ?>about.html">关于ASim</a>|<a rel="nofollow external" href="http://creativecommons.org/licenses/by-nc-sa/3.0/">授权协议</a>|<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=122167787&site=qq&menu=yes">QQ联系</a>|<a href="<?php echo BLOG_URL; ?>contact.html">联系留言</a>|<a href="<?php echo BLOG_URL; ?>sitemap.xml" target="_blank">网站地图</a>
        </div>
        <div class="copyRighr">
        	Copyright&nbsp;@2012-2014&nbsp;<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>&nbsp;All rights reserved.&nbsp;Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>&nbsp;Design by <a href="http://asim.cn" target="_blank">ASim</a>&nbsp;&nbsp;<a href="http://www.miitbeian.gov.cn" target="_blank"><?php echo $icp; ?></a><br /><?php echo $footer_info; ?> <?php doAction('index_footer'); ?>
        </div>
    </div>
</div>
</body>
</html>