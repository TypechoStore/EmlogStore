<?php
/*
Template Name:xuemvp
Description:xuemvp
Version:1.0
Author:xuemvp
Author Url:http://www.liujie520.com/
Sidebar Amount:0
ForEmlog:5.0.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="baidu-site-verification" content="IO7HCkOVSF" />
<meta name="themename" content="90002">
<meta http-equiv="content-type" content="text/html;charset=utf-8">
<meta http-equiv="x-ua-compatible" content="ie=emulateie7">
<title><?php echo $site_title; ?></title>
<link rel="shortcut icon" href="<?php echo TEMPLATE_URL; ?>/favicon.ico">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<meta name="Keywords" content="<?php echo $site_key; ?>">
<meta name="description" content="<?php echo $site_description; ?>" />
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>jquery-1.6.2.min.js" ></script>
<script type="text/javascript" src='<?php echo TEMPLATE_URL; ?>pubu.js' ></script>
<script src="<?php echo TEMPLATE_URL; ?>ntes.js" type="text/javascript"></script>
<link href='<?php echo TEMPLATE_URL; ?>css.css' type="text/css" rel="stylesheet" />
</head>
<body>
	
		<div class="g-hd">
	       	<div class="m-hd">
	        	<div class="m-user">
		        	<div class="hdimg"><a href="<?php echo BLOG_URL; ?>" title="<?php echo $site_title; ?>"><img src="<?php echo TEMPLATE_URL; ?>image/wo.jpg" width="90px" height="90px" ></a></div>
		            <div class="m-title">
						<div class="name"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?><span id="infoicon" style="display:none;"></span></a></div>
						<div class="info"><p></p></div>
					</div>
				</div>
				
				<ul class="m-nav">
					 <?php blog_navi();?>
					<li>
                   <form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
                   <input name="keyword" value="搜索"  type="text"  class="sch" onFocus="if(this.value=='搜索'){this.value='';}" onBlur="if(this.value==''){this.value='搜索';}"/></form>
                    
                    </li>
				</ul>
			</div>
			<div class="m-link">
				<ul class="links">
					<?php doAction('index_head'); ?> <!--header挂载点-->
				</ul>
			</div>
		</div>