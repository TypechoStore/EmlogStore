<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<!--list-->
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>jquery-1.6.2.min.js" ></script>
<script type="text/javascript" src='<?php echo TEMPLATE_URL; ?>pubu.js' ></script>

<div class="g-bd">
  <div class="masyfg m-bd">
    <?php if (!empty($logs)):foreach($logs as $value): ?>
    <div class="m-post">
      <div class="cnt">
        <div class="text">
          <h2>
            <?php topflg($value['top']); ?>
            <a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
          <p><?php echo $value['log_description']; ?></p>
        </div>
      </div>
      <div class="m-oprt">
        <div class="oprta"><a class="time" href="<?php echo $value['log_url']; ?>"><?php echo date('Y-n-j', $value['date']); ?></a></div>
        <div class="oprtb"> <a href="<?php echo $value['log_url']; ?>" class="fav"><span class="icon"></span><span class="bg"></span><?php echo $value['views']; ?></a> </div>
      </div>
    </div>
    <?php 
endforeach;
else:?>
    <h2>未找到</h2>
    <p>抱歉，没有符合您查询条件的结果。</p>
    <?php endif;?>
    <!----> 
  </div>
</div>
<!--listedn-->
<?php include View::getView('lfooter');?>
