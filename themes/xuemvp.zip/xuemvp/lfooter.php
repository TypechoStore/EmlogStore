<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="g-bm">
  <div class="m-bm">
 <div class="from"><span title="Copyright">&copy;</span><a href="http://www.liujie520.com/">心语网</a> | Powered by <a href="http://www.emlog.net/">emlog</a> </div>
    <a id="m-top" class="back dis" title="回到顶部"><span class="icon"></span><span class="bg"></span></a>
    <div class="m-page" id="page"> <?php echo $page_url;?></div>
  </div>
</div>
<?php doAction('index_footer'); ?>
</body>
</html>