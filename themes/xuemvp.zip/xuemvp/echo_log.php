<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div class="g-bd">
  <div class="m-bd ">
    <div class="m-innerpost">
      <div class="innercnt">
        <div class="text">
          <h2>
            <?php topflg($top); ?>
            <?php echo $log_title; ?></h2>
          <p> <?php echo $log_content; ?></p>
		  <p><?php doAction('log_related', $logData); ?></p>
        </div>
      </div>
      <div class="btmbor" style="display:none;">
        <div class="topbor"></div>
      </div>
      <div class="m-postinfo">
        <div class="up" style="display:none;"> </div>
        <div class="down"> <span class="time"><?php echo gmdate('Y-n-j', $date); ?></span> 
        
        <div class="tag"><?php blog_tag($logid); ?></div>
        
        
        </div>
      </div>
      <div style="float:left;width:100%;margin-top:20px;"> 
        
        <!--相关文章开始-->
        
       <!--相关文章结束--> 
        
      </div>
    </div>
    <div class="m-show">
      <div class="cmt">
        <h4>评论</h4>
        <?php echo duoshuo_comments($logData);?><!--评论多说--> 
      </div>
    </div>
  </div>
</div>
 <?php include View::getView('nfooter');?>

