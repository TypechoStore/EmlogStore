<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>
<div id="footer"><?php echo $blogname; ?> &copy; 2012 - Theme by <a href="http://www.yomoxi.com/" target="_blank">YoMoXi</a><br /> <small>Powered by <a href="http://www.emlog.net" target="_blank">emlog</a> </small><?php echo $footer_info; ?>
</div>
<a href="#top" id="top-link" title="返回顶部"></a>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>images/common.js"></script>
<?php doAction('index_footer'); ?>
</body>
</html>