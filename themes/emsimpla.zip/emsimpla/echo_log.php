<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
	<div class="entry">
		<div class="entrytitle">
			<h2><?php topflg($top); ?><?php echo $log_title; ?></h2> 
			<h3><?php echo gmdate('Y-n-j G:i l', $date); ?></h3>
		</div>       
		<div class="entrybody">
			<?php echo $log_content; ?>
            <p class="att"><?php blog_att($logid); ?></p>
        </div>		
		<div class="entrymeta metakuang">
        	<div class="postinfo">
        		<span class="class" title="分类"><?php blog_sort($logid); ?></span>
				<span class="view" title="浏览"><?php echo $views; ?></span>
        		<span class="comment" title="评论"><?php echo $comnum; ?></span>
        		<span class="link" title="引用"><?php echo $tbcount; ?></span>
        		<span class="tag" title="标签"><?php blog_tag($logid); ?></span>
			</div>       
        	<div class="post-link">
        		<span><strong>作者:</strong><?php blog_author($author); ?> <?php editflg($logid,$author); ?></span>
        		<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
        	</div>              		                 
	    </div>
        <?php doAction('log_related', $logData); ?>
  		<div class="post-nav">
        	<?php neighbor_log($neighborLog); ?>
        </div>  
	</div>
    <div class="commentsblock">
    <?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    </div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>