<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content"> 
<?php doAction('index_loglist_top'); ?>
<?php if(isset($sortName)){
		?>
        <div class="position">分类：<?php echo $sortName; ?></div>
		<?php
		}elseif(isset($tag)){
		?>
        <div class="position">标签：<?php echo $tag; ?></div>
		<?php
		}elseif(isset($author)){
		?>
        <div class="position">作者：<?php echo $author_name; ?></div>
		<?php
		}elseif(isset($record)){
		?>
        <div class="position">归档：<?php 
		if(strlen($record) == 6)
		{
			$rec_date = $record."16";
			$rec_sjc = (int)strtotime($rec_date);
			echo date("Y年m月",$rec_sjc);
		}
		else
		{
			$rec_date = $record;
			$rec_sjc = (int)strtotime($rec_date);
			echo date("Y年m月d日",$rec_sjc);
		}
		?></div>
		<?php
		}elseif(isset($keyword)){
		?>
        <div class="position">搜索：<?php echo $keyword; ?></div>
		<?php
		} 
		?>
<?php foreach($logs as $value): ?>
	<div class="entry"> 
		<div class="entrytitle"> 
			<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2> 
			<h3><?php echo gmdate('Y-n-j G:i l', $value['date']); ?></h3> 
		</div> 
		<div class="entrybody"> 
        	<?php echo $value['log_description']; ?>
            <p class="att"><?php blog_att($value['logid']); ?></p>
		</div> 
		<div class="entrymeta">
        	<div class="postinfo">
        		<span class="class" title="分类"><?php blog_sort($value['logid']); ?></span>
				<span class="view" title="浏览"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['views']; ?></a></span>
        		<span class="comment" title="评论"><a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?></a></span>
        		<span class="link" title="引用"><a href="<?php echo $value['log_url']; ?>#tb"><?php echo $value['tbcount']; ?></a></span>
        		<span class="tag" title="标签"><?php blog_tag($value['logid']); ?></span>
			</div>
        	<?php editflg($value['logid'],$value['author']); ?>
        </div>
    </div> 
<?php endforeach; ?>
<?php if($logs == NULL) { ?>
<div class="s_nofound"><p>╮(╯▽╰)╭</p><p>啥都木有找到…</p></div>
<?php } ?>
	<div class="page-navi">
		<?php echo $page_url;?>
    </div>
</div>   
<?php
 include View::getView('side');
 include View::getView('footer');
?>