<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<a href="javascript:grin('[F1]')"><img src="<?php echo TEMPLATE_URL; ?>images/gin/1.png" alt="中国赞表情" title="中国赞"></a>
<a href="javascript:grin('[F2]')"><img src="<?php echo TEMPLATE_URL; ?>images/gin/2.png" alt="摊手表情" title="摊手"></a>
<a href="javascript:grin('[F3]')"><img src="<?php echo TEMPLATE_URL; ?>images/gin/3.png" alt="吃瓜表情" title="吃瓜"></a>
<a href="javascript:grin('[F4]')"><img src="<?php echo TEMPLATE_URL; ?>images/gin/4.png" alt="笑哭表情" title="笑哭"></a>
<a href="javascript:grin('[F5]')"><img src="<?php echo TEMPLATE_URL; ?>images/gin/5.png" alt="偷笑表情" title="偷笑"></a>
<a href="javascript:grin('[F6]')"><img src="<?php echo TEMPLATE_URL; ?>images/gin/6.png" alt="衰表情" title="衰"></a>
<a href="javascript:grin('[F7]')"><img src="<?php echo TEMPLATE_URL; ?>images/gin/7.png" alt="汗表情" title="汗"></a>
<a href="javascript:grin('[F8]')"><img src="<?php echo TEMPLATE_URL; ?>images/gin/8.png" alt="思考表情" title="思考"></a>
<a href="javascript:grin('[F9]')"><img src="<?php echo TEMPLATE_URL; ?>images/gin/9.png" alt="费解表情" title="费解"></a>
<a href="javascript:grin('[F10]')"><img src="<?php echo TEMPLATE_URL; ?>images/gin/10.png" alt="抓狂表情" title="抓狂"></a>
<a href="javascript:grin('[F11]')"><img src="<?php echo TEMPLATE_URL; ?>images/gin/11.png" alt="晕表情" title="晕"></a>
<a href="javascript:grin('[F12]')"><img src="<?php echo TEMPLATE_URL; ?>images/gin/12.png" alt="流泪表情" title="泪"></a>
<a href="javascript:grin('[F13]')"><img src="<?php echo TEMPLATE_URL; ?>images/gin/13.png" alt="疑问表情" title="疑问"></a>
<a href="javascript:grin('[F14]')"><img src="<?php echo TEMPLATE_URL; ?>images/gin/14.png" alt="嘻嘻表情" title="嘻嘻"></a>
<a href="javascript:grin('[F15]')"><img src="<?php echo TEMPLATE_URL; ?>images/gin/15.png" alt="吃惊表情" title="吃惊"></a>
<a href="javascript:grin('[F16]')"><img src="<?php echo TEMPLATE_URL; ?>images/gin/16.png" alt="鼓掌表情" title="鼓掌"></a>