<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
  <div class="article">
   <div class="postop">
   <div class="pheadfill">&nbsp;</div>
   </div>
   <div class="storycontent">
	<h1 class="storytitle" id="post-9"><?php topflg ($top); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $log_title; ?></a></h1>
	  <div class="thecontent">
	 <p><?php echo $log_content;?><?php blog_att($logid); ?></p>
	<?php blog_att($logid); ?></p>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
 </div>	
         <div class="reset">&nbsp;</div>
    </div>
        <!-- end STORYCONTENT -->
  </div>
      <!-- end POST -->


<?php
 include View::getView('side');
 include View::getView('footer');
?>
		
