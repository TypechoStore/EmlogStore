<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="content">
<?php
 include View::getView('side2');
 //include View::getView('footer');
?>
<div id="border_left2">
<div id="contentleft">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): 
	preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
	$imgsrc = !empty($img[1]) ? $img[1][0] : ''; ?>
	<div style="width:100%;">
		<div style="width:100%; margin:0px; padding:0px; border-bottom:1px dashed #999;">
		<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
		</div>
		<div style="width:100%; margin:0px; padding:0px;">
		<p class="date">作者：<?php blog_author($value['author']); ?> 发布于：<?php echo gmdate('Y-n-j G:i l', $value['date']); ?> 
		<?php blog_sort($value['logid']); ?> 
		<?php editflg($value['logid'],$value['author']); ?>
		</p>
		</div>
	</div>
	<div style="width:100%;">
		<div class="log_thum">
		<div style="width:200px; height:150px; margin:0px 12px 0px 0px; border:4px ridge #ccc; overflow:hidden;">
		<a href="<?php echo $value['log_url']; ?>">
		<?php if($imgsrc): ?>
			<img src="<?php echo $imgsrc; ?>" />
		<?php else: ?>
			<img src="<?php echo TEMPLATE_URL; ?>images/no-img.jpg" />
		<?php endif; ?>
		</a>
		</div>
		</div>
		<div class="log_text">
		<?php echo $value['log_description']; ?>
		</div>
		<div style="float:left; height:20px; width:210px; margin-top:-20px; text-align:center;">
		<a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a>&nbsp&nbsp&nbsp&nbsp
		<a href="<?php echo $value['log_url']; ?>#tb">引用(<?php echo $value['tbcount']; ?>)</a>&nbsp&nbsp&nbsp&nbsp
		<a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a>
		</div>
	</div>
	<div style="clear:both; width:100%; height:5px; font-size:1px; border-bottom:0px #999 dashed;"></div>
<?php endforeach; ?>
<div style="clear:both; width:100%; height:5px; font-size:1px;"></div>
<div id="pagenavi">
	<?php echo $page_url;?>
</div>
</div><!--#contentleft.End-->
</div><!--#border_left.End-->

<?php
 //include View::getView('side');
 include View::getView('footer');
?>