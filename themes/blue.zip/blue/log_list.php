<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

  <?php doAction('index_loglist_top'); ?>
  <?php foreach($logs as $value): ?>
  <div class="post">
   <div class="postop">
   <div class="pheadfill">&nbsp;</div>
   </div>
   <div class="storycontent">
	<h1 class="storytitle" id="post-9"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h1>
	  <div class="thecontent">
	  <p><?php echo $value['log_description']; ?></p>
     </div>
         <div class="themeta" id="d1">
		 <span class="who">作者：&nbsp;</span><?php blog_author($value['author']); ?> <br />
		 <span class="when-date">&nbsp;</span><?php echo gmdate('n-j G:i l', $value['date']); ?><br />
         <span class="com"></span><a href="<?php echo $value['log_url']; ?>#comment" title="评论"><span class="areflavor"><?php echo $value['comnum']; ?></span></a>
						<a href="<?php echo $value['log_url']; ?>" title="浏览"><img src="<?php echo TEMPLATE_URL; ?>pic/icon_love.png"><?php echo $value['views']; ?></a>
						<a href="<?php echo $value['log_url']; ?>" title="引用"><img src="<?php echo TEMPLATE_URL; ?>pic/icon_notes02.png"><?php echo $value['tbcount']; ?>
						   </a><br />
		 <span class="sort">&nbsp;</span> <?php blog_sort($value['logid']); ?> <br />
           
            <span class="tag"></span><?php blog_tag($value['logid']); ?> <br />
			     </p>
            
		<?php editflg($value['logid'],$value['author']); ?> 
      </div>
         <div class="reset">&nbsp;</div>
    </div>
        <!-- end STORYCONTENT -->
  </div>
      <!-- end POST -->
<?php endforeach; ?>

<div class="pager">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $page_url;?>	
				</div>
				</div>
  
<?php
 include View::getView('side');
 include View::getView('footer');
?>
		
