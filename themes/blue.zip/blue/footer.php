<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="sideitem">
        <div class="boxhead">
          <div class="headfill">&nbsp;</div>
        </div>
        <div class="boxbody">
<p>Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a></p>
Themeby <a href="http://ekstone.com" title="一颗很普通的石头，但我会努力进化为一颗不一般的石头">EK石头</a> </p>
<?php echo $footer_info; ?><?php doAction('index_footer'); ?>
 </div>
      </div>
</body>

<link href="<?php echo TEMPLATE_URL; ?>frame.css" type="text/css" rel="stylesheet" charset="utf-8">
 <link id="skin_transformers" href="<?php echo TEMPLATE_URL; ?>skin_narrow.css" type="text/css" rel="stylesheet" charset="utf-8">

<a href="#" id="base_scrollToTop" class="W_gotop" style="visibility: visible; ">
<span><em class="sj">♦</em><em class="fk">▐</em>返回顶部</a></span>
</a> </div>