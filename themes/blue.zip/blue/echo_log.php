<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

  <?php doAction('index_loglist_top'); ?>
  <div class="article">
   <div class="postop">
   <div class="pheadfill">&nbsp;</div>
   </div>
   <div class="storycontent">
   <h1 class="storytitle" id="post-9"><?php topflg ($top); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $log_title; ?></a></h1>
	<h1 class="storytitle" id="post-9"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h1>
	  <div class="thecontent">
	  <p><?php echo $log_content;?><?php blog_att($logid); ?></p>
     </div>
         <div class="themeta" id="d1">
		 <span class="who">&nbsp;</span>：<?php blog_author($author); ?> <br />
		 <span class="when-date">&nbsp;</span>：<?php echo gmdate('n-j G:i l', $date); ?> <br />
         <span class="com"></span><a href="<?php echo $value['log_url']; ?>#comment" title="评论"><span class="areflavor"><?php echo $comnum; ?></span></a>
						<a href="<?php echo $value['log_url']; ?>" title="浏览"><img src="<?php echo TEMPLATE_URL; ?>pic/icon_love.png"><?php echo $views; ?></a>
						<a href="<?php echo $value['log_url']; ?>" title="引用"><img src="<?php echo TEMPLATE_URL; ?>pic/icon_notes02.png"><?php echo $tbcount; ?>
						   </a><br />
		 <span class="sort"></span> <?php blog_sort($logid); ?> <br />
           
            <span class="tag"></span><?php blog_tag($logid); ?></p> <br />
			     </p>
            <?php editflg($logid,$author); ?>
      </div>	
	    <div class="thecontent">
	   <?php doAction('log_related', $logData); ?>
	  <?php neighbor_log($neighborLog); ?></div><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
	<p><?php blog_trackback($tb, $tb_url, $allow_tb); ?></p>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	 </div>	
         <div class="reset">&nbsp;</div>
    </div>
        <!-- end STORYCONTENT -->
  </div>

<?php
 include View::getView('side');
 include View::getView('footer');
?>
		
