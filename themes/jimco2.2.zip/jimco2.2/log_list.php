<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
  if($pageurl == Url::logPage()){
    include View::getView('index');
  }else{
?>
<div id="contentwrap">
  <div class="crumbs">
    <div class="breadcrumbs clearfix">
      <a href="<?php echo BLOG_URL; ?>">首页</a><span></span>
      <a href="javascript:void(0);">
      <?php 
        if ($params[1]=='sort'){ 
          if(isset($_GET['sort'])){
            $sortname= $sort_cache[$_GET['sort']]['sortname'];
          }else{
            foreach($sort_cache as $val){
              if($val['alias']!='' && $params[2]==$val['alias']) $sortname= $val['sortname'];}}?>
              <?php echo $sortname;?>
        <?php }elseif ($params[1]=='tag'){ ?>
          <?php echo urldecode($params[2]);?>
        <?php }elseif($params[1]=='author'){ ?>
          <?php echo blog_author($author);?>
        <?php }elseif($params[1]=='keyword'){ ?>
          <?php echo urldecode($params[2]);?>
        <?php }elseif($params[1]=='record'){ ?>
           <?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?>
        <?php }else{?><?php }?>
      </a><span></span>
    </div>
  </div>
  <div id="content">
    <div class="list-top">
      <div class="list-feed">订阅地址：<input type="text" value="http://www.xiejiancong.com/rss.php" disabled />开源共享，邀请您订阅本站</div>
      <div class="qq-feed">
        <form method="post" target="_blank" action="http://list.qq.com/cgi-bin/qf_compose_send" class="subscribe-mail">
          <input type="hidden" value="qf_booked_feedback" name="t">
          <input type="hidden" value="6c1790d6ff6f78c0d9cb4b9f968d33e8b070cdd70bb678c3" name="id">
          QQ 订阅：<input type="text" class="ipt" name="to" value="输入邮箱 订阅本站" onblur="if (this.value == '') {this.value = '输入邮箱 订阅本站';}" onfocus="if (this.value == '输入邮箱 订阅本站') {this.value = '';}" id="to">
          <input type="submit" value="我要订阅" class="feed-btn">
        </form>
      </div>
    </div>
    <ol class="listwrap">
      <?php foreach($logs as $value): ?>
      <li class="excerpt">
        <div class="excerptimg"><a href="<?php echo $value['log_url']; ?>"><img src="<?php get_imgsrc($value['content']); ?>" alt="<?php echo $value['log_title']; ?>" /></a></div>
        <div class="excerptinfo clearfix">
          <h1><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></h1>
          <div class="excerptdes">
            <p><?php echo subString(strip_tags($value['log_description']),0,70) ?> ...</p>
          </div>
          <ul class="excerpttag"><?php blog_tag($value['logid']); ?></ul>
        </div>
        <div class="excerptvisit">
          <a class="comm" href="<?php echo $value['log_url']; ?>" title="《<?php echo $value['log_title']; ?>》上的评论"><i></i><?php echo $value['comnum']; ?> 回应</a>
          <span class="view"><i></i><?php echo $value['views']; ?> 热度</span>
        </div>
      </li>
      <?php endforeach; ?>
    </ol>
    <div class="pagenavi"><?php echo $page_url;?></div>
  </div>
<!-- end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
}?>