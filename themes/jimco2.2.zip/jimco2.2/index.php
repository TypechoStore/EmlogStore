<?php 
/*
* 站点首页页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="contentwrap">
  <div id="content">
    <div class="top-tab">
      <ul class="tab-header">
        <li class="cur"><a href="javascript:void(0);">标签</a><i>|</i></li>
        <li><a href="javascript:void(0);">最热</a><i>|</i></li>
        <li><a href="javascript:void(0);">推荐</a></li>
      </ul>
      <div class="tab-content">
        <div class="tab-tag cur">
          <ul>
            <?php $tag_cache = $CACHE->readCache('tags'); ?>
            <?php 
              shuffle($tag_cache);
              $tag_cache = array_shift(array_chunk($tag_cache,10));
              shuffle($tag_cache);
              foreach($tag_cache as $value): ?>
            <li><a href="<?php echo Url::tag($value['tagurl']); ?>"><?php echo $value['tagname']; ?></a></li>
            <?php endforeach;?>
          </ul>
          <div class="tab-search">
            <form id="searchform" name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
              <input type="text" name="keyword" id="search_input" value="回车搜索 直接有效" onblur="if (this.value == '') {this.value = '回车搜索 直接有效';}" onfocus="if (this.value == '回车搜索 直接有效') {this.value = '';}" x-webkit-speech />
            </form>
          </div>
        </div>
        <div class="tab-list">
          <ul>
            <?php home_getloglist("hot","5"); ?>
          </ul>
        </div>
        <div class="tab-list">
          <ul>
            <?php home_getloglist("rand","5"); ?>
          </ul>
        </div>
      </div>
    </div>
    <div class="slider">
      <div id="scroll">
        <?php slider("rand");?>
      </div>
      <a href="#" id="btn_prev" class="sliderbtn">prev</a>
      <a href="#" id="btn_next" class="sliderbtn">next</a>
      <div id="slider_bar"></div>
    </div>
    <ol class="homewrap">
      <?php foreach($logs as $value): ?>
      <li class="excerpt">
        <div class="excerptimg"><a href="<?php echo $value['log_url']; ?>"><img src="<?php get_imgsrc($value['content']); ?>" alt="<?php echo $value['log_title']; ?>" /></a></div>
        <div class="excerptinfo clearfix">
          <h1><a href="<?php echo $value['log_url']; ?>" title="《<?php echo $value['log_title']; ?>》"><?php echo $value['log_title']; ?></a></h1>
          <div class="excerptdes">
            <p><?php echo subString(strip_tags($value['log_description']),0,70) ?> ...</p>
          </div>
          <ul class="excerpttag"><?php blog_tag($value['logid']); ?></ul>
        </div>
        <div class="excerptvisit">
          <a class="comm" href="<?php echo $value['log_url']; ?>" title="《<?php echo $value['log_title']; ?>》上的评论"><i></i><?php echo $value['comnum']; ?> 回应</a>
          <span class="view"><i></i><?php echo $value['views']; ?> 热度</span>
        </div>
      </li>
      <?php endforeach; ?>
    </ol>
    <div class="pagenavi"><?php echo $page_url;?></div>
  </div>
<!-- end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>