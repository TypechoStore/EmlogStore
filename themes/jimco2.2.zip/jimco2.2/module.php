<?php 
/*
* 侧边栏组件、页面模块
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//widget：blogger
function widget_blogger($title){
  global $CACHE;
  $user_cache = $CACHE->readCache('user');
  $name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
  <li class="sidebox">
    <h3 class="tit"><strong><?php echo $title; ?></strong></h3>
    <div class="blogger">
      <?php if (!empty($user_cache[1]['photo']['src'])): ?>
      <img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="45px" height="45px" alt="blogger" />
      <?php endif;?>
      <p><b title="Blogger"><?php echo $name; ?></b> - <?php echo $user_cache[1]['des']; ?></p>
    </div>
  </li>
<?php }?>
<?php
//widget：日历
function widget_calendar($title){ ?>
  <li class="sidebox">
    <h3 class="tit"><strong><?php echo $title; ?></strong></h3>
    <div id="calendar">
    </div>
    <script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
  </li>
<?php }?>
<?php
//widget：标签
function widget_tag($title){
  global $CACHE;
  $tag_cache = $CACHE->readCache('tags');?>
  <li class="sidebox">
    <h3 class="tit"><strong><?php echo $title; ?></strong></h3>
    <ul class="blogtags">
      <?php shuffle ($tag_cache);
        $tag_cache = array_slice($tag_cache,0,50);
        foreach($tag_cache as $value): ?>
      <span style="font-size:<?php echo $value['fontsize']; ?>pt; line-height:30px;">
      <a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇日志"><?php echo $value['tagname']; ?></a></span>
    <?php endforeach; ?>
    </ul>
  </li>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
  global $CACHE;
  $sort_cache = $CACHE->readCache('sort'); ?>
  <li class="sidebox">
    <h3 class="tit"><strong><?php echo $title; ?></strong></h3>
    <ul class="sidelist clearfix">
      <?php foreach($sort_cache as $value): ?>
      <li>
        <a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
      </li>
      <?php endforeach; ?>
    </ul>
  </li>
<?php }?>
<?php
//widget：最新碎语
function widget_twitter($title){
  global $CACHE; 
  $newtws_cache = $CACHE->readCache('newtw');
  $istwitter = Option::get('istwitter');
  ?>
  <li class="sidebox">
    <h3 class="tit"><strong><?php echo $title; ?></strong></h3>
    <ul class="sidetext">
      <?php foreach($newtws_cache as $value): ?>
      <?php $img = empty($value['img']) ? "" : '<a title="查看图片" class="t_img" href="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" target="_blank">&nbsp;</a>';?>
      <li><p class="t_item"><?php echo $value['t']; ?><?php echo $img;?></p></li>
      <?php endforeach; ?>
      <?php if ($istwitter == 'y') :?>
      <p><a href="<?php echo BLOG_URL . 't/'; ?>">更多&raquo;</a></p>
      <?php endif;?>
    </ul>
  </li>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
  global $CACHE; 
  $com_cache = $CACHE->readCache('comment');
  ?>
  <li class="sidebox">
    <h3 class="tit"><strong><?php echo $title; ?></strong></h3>
    <ul class="sidecomm clearfix">
      <?php
      foreach($com_cache as $value):
      $url = Url::comment($value['gid'], $value['page'], $value['cid']);
      ?>
      <li class="clearfix">
        <img src="http://www.gravatar.com/avatar/<?php echo md5($value['mail']); ?>" width="40" height="40" alt="<?php echo $value['name']; ?>" />
        <span><?php echo $value['name']; ?></span>：<a href="<?php echo $url; ?>" title="<?php echo $value['content']; ?>"><?php echo $value['content']; ?></a>
      </li>
      <?php endforeach; ?>
    </ul>
  </li>
<?php }?>
<?php
//widget：最新日志
function widget_newlog($title){
  global $CACHE; 
  $newLogs_cache = $CACHE->readCache('newlog');
  ?>
  <li class="sidebox">
    <h3 class="tit"><strong><?php echo $title; ?></strong></h3>
    <ul class="sidetext">
      <?php foreach($newLogs_cache as $value): ?>
      <li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
      <?php endforeach; ?>
    </ul>
  </li>
<?php }?>
<?php
//widget：热门日志
function widget_hotlog($title){
	$index_hotlognum = Option::get('index_hotlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getHotLog($index_hotlognum);?>
	<li class="sidebox" >
	<h3 class="tit"><span><?php echo $title; ?></span></h3>
	<ul class="sidetext clearfix">
	<?php foreach($randLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：随机日志
function widget_random_log($title){
  $index_randlognum = Option::get('index_randlognum');
  $Log_Model = new Log_Model();
  $randLogs = $Log_Model->getRandLog($index_randlognum);?>
  <li class="sidebox">
    <h3 class="tit"><strong><?php echo $title; ?></strong></h3>
    <ul class="sidetext clearfix">
      <?php foreach($randLogs as $value): ?>
      <li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
      <?php endforeach; ?>
    </ul>
  </li>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
  <li class="sidebox">
    <h3 class="tit"><strong><?php echo $title; ?></strong></h3>
    <ul class="newwidgets">
      <form class="searchform" name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
        <input type="text" name="keyword" id="search_input" placeholder="回车搜索 直接有效" autofocus x-webkit-speech />
        <input type="submit"  value="搜索" id="logserch_logserch" class="btn" />
      </form>
    </ul>
  </li>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
  global $CACHE; 
  $record_cache = $CACHE->readCache('record');
  ?>
  <li class="sidebox">
    <h3 class="tit"><strong><?php echo $title; ?></strong></h3>
    <ul class="sidelist clearfix">
      <?php foreach($record_cache as $value): ?>
      <li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
      <?php endforeach; ?>
    </ul>
  </li>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
  <li class="sidebox">
    <h3 class="tit"><strong><?php echo $title; ?></strong></h3>
    <div class="newwidgets">
      <?php echo $content; ?>
    </div>
  </li>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
  global $CACHE; 
  $link_cache = $CACHE->readCache('link');
  ?>
  <li class="sidebox">
    <h3 class="tit"><strong><?php echo $title; ?></strong></h3>
    <ul class="sidelist clearfix">
      <?php foreach($link_cache as $value): ?>
      <li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
      <?php endforeach; ?>
    </ul>
  </li>
<?php }?>
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	?>
	<ul>
	<?php 
	foreach($navi_cache as $value):
		if($value['url'] == 'admin' && (ROLE == 'admin' || ROLE == 'writer')):
			?>
			<li class="common"><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
			<li class="common"><a href="<?php echo BLOG_URL; ?>admin/">管理</a></li>
			<li class="common"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
		$value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
		$current_tab = (BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url']) ? 'current' : 'common';
		?>
		<li class="<?php echo $current_tab;?>"><a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a></li>
	<?php endforeach; ?>
	</ul>
<?php }?>
<?php
//blog：置顶
function topflg($istop){
  $topflg = $istop == 'y' ? "<img src=\"".TEMPLATE_URL."/images/import.gif\" title=\"置顶日志\" /> " : '';
  echo $topflg;
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
  $editflg = ROLE == 'admin' || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'">编辑</a>' : '';
  echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
  global $CACHE; 
  $log_cache_sort = $CACHE->readCache('logsort');
  ?>
    <?php if(!empty($log_cache_sort[$blogid])): ?>
    <a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
    <?php endif;?>
<?php }?>
<?php
//blog：日志标签
function blog_tag($blogid){
  global $CACHE;
  $log_cache_tags = $CACHE->readCache('logtags');
  if (!empty($log_cache_tags[$blogid])){
    foreach ($log_cache_tags[$blogid] as $value){
      $tag .= "    <li><a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a></li>';
    }
    echo $tag;
  }
}
?>
<?php
//blog：日志作者
function blog_author($uid){
  global $CACHE;
  $user_cache = $CACHE->readCache('user');
  $author = $user_cache[$uid]['name'];
  $mail = $user_cache[$uid]['mail'];
  $des = $user_cache[$uid]['des'];
  $title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
  echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻日志
function neighbor_log($neighborLog){
  extract($neighborLog);?>
    <?php if($prevLog):?>
    <span class="pre">上一篇：<a href="<?php echo Url::log($prevLog['gid']) ?>"><?php echo $prevLog['title'];?></a></span>
    <?php endif;?>
    <?php if($nextLog && $prevLog):?>
    <?php endif;?>
    <?php if($nextLog):?>
    <span class="next">下一篇：<a class="next" href="<?php echo Url::log($nextLog['gid']) ?>"><?php echo $nextLog['title'];?></a></span>
<?php endif;?>
<?php }?>
<?php
//blog：引用通告
function blog_trackback($tb, $tb_url, $allow_tb){
  if($allow_tb == 'y' && Option::get('istrackback') == 'y'):?>
  <div id="trackback_address">
    <p>引用地址: <input type="text" style="width:350px" class="input" value="<?php echo $tb_url; ?>">
    <a name="tb"></a></p>
  </div>
  <?php endif; ?>
  <?php foreach($tb as $key=>$value):?>
    <ul id="trackback">
      <li><a href="<?php echo $value['url'];?>" target="_blank"><?php echo $value['title'];?></a></li>
      <li>BLOG: <?php echo $value['blog_name'];?></li>
      <li><?php echo $value['date'];?></li>
    </ul>
  <?php endforeach; ?>
<?php }?>
<?php
//blog：博客评论列表
function blog_comments($comments){
  extract($comments);
  if($commentStacks): ?>
  <?php endif; ?>
    <?php
    $isGravatar = Option::get('isgravatar');
    foreach($commentStacks as $cid):
    $comment = $comments[$cid];
    $comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
    ?>
    <div class="comment" id="comment-<?php echo $comment['cid']; ?>">
      <ul class="comment-text clearfix">
        <a name="<?php echo $comment['cid']; ?>"></a>
        <?php if($isGravatar == 'y'): ?><img src="<?php echo getGravatar($comment['mail']); ?>" /><?php endif; ?>
        <li class="clearfix">
          <p class="comment-content">
            <?php echo preg_replace("#\|ali(\d+)\|#i",'<img src="'.TEMPLATE_URL.'images/ali/$1.gif" id="ali$1" width="30" height="30" alt="阿狸$1" title="阿狸$1" />',$comment['content']); ?>
          </p>
          <p class="comment-reply">
            <?php echo $comment['poster']; ?>
            <span class="comment-time"><?php echo $comment['date']; ?></span>
            <span><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a></span>
          </p>
        </li>
        <?php blog_comments_children($comments, $comment['children']); ?>
      </ul>
    </div>
    <?php endforeach; ?>
    <div class="pagenavi"><?php echo $commentPageUrl;?></div>
<?php }?>
<?php
//blog：博客子评论列表
function blog_comments_children($comments, $children){
  $isGravatar = Option::get('isgravatar');
  foreach($children as $child):
  $comment = $comments[$child];
  $comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
  ?>
    <div class="comment-children" id="comment-<?php echo $comment['cid']; ?>">
      <ul class="comment-text clearfix">
        <a name="<?php echo $comment['cid']; ?>"></a>
        <?php if($isGravatar == 'y'): ?><img src="<?php echo getGravatar($comment['mail']); ?>" /><?php endif; ?>
        <li class="clearfix">
          <p class="comment-content">
            <?php echo preg_replace("#\|ali(\d+)\|#i",'<img src="'.TEMPLATE_URL.'images/ali/$1.gif" id="ali$1" width="25" height="25" alt="阿狸$1" title="阿狸$1" />',$comment['content']); ?>
          </p>
          <p class="comment-reply">
            <?php echo $comment['poster']; ?>
            <span class="comment-time"><?php echo $comment['date']; ?></span>
            <span><?php if($comment['level'] < 2): ?><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a></span><?php endif; ?>
          </p>
        </li>
      </ul>
      <?php blog_comments_children($comments, $comment['children']);?>
    </div>
  <?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
  if($allow_remark == 'y'): ?>
  <div name="respond" style="clear:both;"></div>
  <div id="comment-place">
    <div id="comment-post">
      <form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">            
        <input type="hidden" name="gid" value="<?php echo $logid; ?>" />
        <?php if(ROLE == 'visitor'): ?>
        <?php if($ckname != ''): ?>
        <p class="comment-top">欢迎回来，<b><?php echo $ckname; ?></b> <a href="javascript:void(0);" style="font-size:12px" onclick="toggleInput()">换个昵称</a></p>
        <?php endif; ?>
        <div class="comment-info" id="userinfo"<?php if($ckname != '') echo ' style="display:none"'; ?>>
          <p>
            <label for="author">签个名呗</label><input type="text" name="comname" maxlength="49" value="<?php echo $ckname; ?>" size="22" tabindex="1"><small>（必须）</small>                
          </p>
          <p>
            <label for="email">留个邮箱</label><input type="text" name="commail"  maxlength="128"  value="<?php echo $ckmail; ?>" size="22" tabindex="2"><small>（必须，保密）</small>
          </p>
          <p>
            <label for="url">个人主页</label><input type="text" name="comurl" maxlength="128"  value="<?php echo $ckurl; ?>" size="22" tabindex="3">
          </p>
        </div>
        <?php
          else:
          $CACHE = Cache::getInstance();
          $user_cache = $CACHE->readCache('user');
        ?>
        <p class="comment-top">您当前已登录为 <b><?php echo $user_cache[UID]['name']; ?></b></p>
        <?php endif; ?>
        <div class="comment-area">
          <div class="smiles" id="smiles">
            <?php for($i = 1; $i <= 18; $i++): ?>
            <img src="<?php echo TEMPLATE_URL; ?>images/ali/<?php echo $i; ?>.gif" id="ali<?php echo $i; ?>" width="20" height="20" alt="阿狸<?php echo $i; ?>" title="ali<?php echo $i; ?>" />
            <?php endfor; ?>
          </div>
          <textarea name="comment" id="comment" cols="100%" rows="6" tabindex="4"></textarea>
        </div>
        <div class="subcon">
          <?php echo $verifyCode; ?><input type="submit" id="comment_submit" value="发表评论" tabindex="6" />
          <a class="cancel-reply" id="cancel-reply" style="display:none" href="javascript:void(0);" onclick="cancelReply()">取消</a>
        </div>
        <input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/>
      </form>
    </div>
  </div>
  <?php endif; ?>
<?php }?>
<?php
//获取文章中第一张图片，如果没有就显示默认
function get_imgsrc($str){
  preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $str, $match);
  if(!empty($match[1])){
    echo $match[1][0];
  }else{
    echo TEMPLATE_URL . 'images/thumbnail.png';
  }
}
?>
<?php
//tab:最新发表、热评文章、推荐文章
function home_getloglist($way="random",$get_total="8") {
  $timezone = Option::get('timezone');
  $log_target=$GLOBALS['tcms']['log_target'];
  $hot=$GLOBALS['tcms']['hot'];
  $target = $log_target ? 'target="'.$log_target.'"':'';
  if($way=="newpost"){//最新发表
    $order = 'ORDER BY date DESC';
  }elseif($way=="hot"){//热评文章
    $order = 'ORDER BY comnum DESC';
  }else{//推荐文章
    $order = 'ORDER BY rand()';
  }
  $db=MySql::getInstance();
  $logs = $db->query("SELECT gid,title,date,comnum FROM " . DB_PREFIX . "blog WHERE hide='n' and type='blog' $order LIMIT 0, $get_total");
  while ($row = $db->fetch_array($logs)){
      $row['title'] = htmlspecialchars($row['title']);
      $row['date'] += $timezone * 3600;
   ?>
  <li><i>></i><a href="<?php echo Url::log($row['gid']); ?>" title="《<?php echo $row['title']; ?>》" <?php echo $target;?>><?php echo $row['title']; ?></a>
  <span class="date"><?php echo gmdate('m-d', $row['date']); ?></span></li>
  <?php } ?>
<?php }?>
<?php 
//相关文章
function related_logs($sortid,$logid){
  $date = time() - 3600 * 24 * 90;
  $db=MySql::getInstance();
  $sql = "SELECT gid,title,content FROM ".DB_PREFIX."blog WHERE hide='n' and type='blog' and gid!=$logid and sortid=$sortid ORDER BY views ASC LIMIT 0,6";
  $logs = $db->query($sql);
  while ($row = $db->fetch_array($logs)){
    $row['title'] = htmlspecialchars(trim($row['title']));
    preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $row['content'], $img);
    $imgsrc = !empty($img[1]) ? $img[1][0] : TEMPLATE_URL .'images/relatedimg.png';
    echo'<li><a href="'.Url::log($row['gid']).'" title="'.$row['title'].'" target="_blank">';
    echo'<img src="'.$imgsrc.'" alt="'.$row['title'].'"/></a>';
    echo'<a class="mask" href="'.Url::log($row['gid']).'" title="《'.$row['title'].'》全文阅读"><span>'.$row['title'].'</span></a></li>';
  }
};
/* 调用<ul class="related"><?php related_log($sortid,$logid);?></ul> */
?>
<?php
//评论头像缓存
function get_avatar($mail,$alt,$size = '32',$default='monsterid'){
  $alt = strip_tags($alt);
  $email_md5=md5(strtolower($mail));//通过MD5加密邮箱
  $cache_path=EMLOG_ROOT."/content/templates/jimco2.0/cache"; //缓存文件夹路径,需要换上你的主题目录名称
  if(!file_exists($cache_path)){
    mkdir($cache_path,0700);
  }
  $avatar_url=TEMPLATE_URL."cache/".$email_md5.'.jpg'; //头像相对路径
  $avatar_abs_url=$cache_path."/".$email_md5.'.jpg'; //头像绝对路径
  $cache_time=24*3600*7; //缓存时间为7天
  if (empty($default)) $default = $cache_path. '/default.jpg';
  if(!file_exists($avatar_abs_url) || (time()-filemtime($avatar_abs_url)) > $cache_time)//过期或图片不存在
  {
    $new_avatar = getGravatar($mail,$size,$default);
    copy($new_avatar,$avatar_abs_url);
  }
  return " <img title='{$alt}' alt='{$alt}' src='{$avatar_url}' height='{$size}' width='{$size}' />";
}
?>