<?php
/*
Template Name:Jimco
Description:前端那些事儿设计制作
Version:2.2
Author:Jimco
Author Url:http://www.xiejiancong.com
Sidebar Amount:1
ForEmlog:4.2+
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="www.xiejiancong.com" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>main.css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="header-frame">
  <div id="header">
    <div><a id="logo" href="<?php echo BLOG_URL; ?>" title="<?php echo $bloginfo; ?>"><?php echo $bloginfo; ?></a></div>
    <ul id="menu">
      <li><a href="<?php echo BLOG_URL; ?>">首页</a></li>
      <?php 
        global $CACHE; 
		$navi_cache = $CACHE->readCache('navi');
		foreach ($navi_cache as $key => $val):
		if ($val['hide'] == 'y'){continue;}
		if (empty($val['url'])){$val['url'] = Url::log($key);}
		$val['is_blank'] = $val['newtab'] == 'y' ? 'target="_blank"' : '';
		$val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
			
      ?>
      <li><a href="<?php echo $val['url']; ?>" target="<?php echo $val['is_blank']; ?>"><?php echo $val['naviname']; ?></a></li>
      <?php endforeach;?>
      <?php doAction('navbar', '<li>', '</li>'); ?>
    </ul>
    <ul id="nav">
      <?php if($istwitter == 'y'):?>
      
      <?php endif;?>
      <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
      <li><a href="<?php echo BLOG_URL; ?>admin/">管理</a></li>
      <li><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
      <li><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
      <?php else: ?>
      <li><a href="<?php echo BLOG_URL; ?>admin/">登录</a></li>
      <?php endif; ?>
    </ul>
  </div>
</div>