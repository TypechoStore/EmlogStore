<?php
/*
Template Name:Jimco
Description:前端那些事儿 & 黄蜂部落
Version:2.2
Author:小黄蜂
Author Url:http://www.aifengbang.com
Sidebar Amount:1
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="www.aifengbang.com" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>main.css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="header-frame">
  <div id="header">
    <div><a id="logo" href="<?php echo BLOG_URL; ?>" title="<?php echo $bloginfo; ?>"><?php echo $bloginfo; ?></a></div>
    <div id="menu"><?php blog_navi();?></div>
    <ul id="nav">
	 <li><a href="<?php echo BLOG_URL; ?>t/">碎语</a></li>
    <li><a href="<?php echo BLOG_URL; ?>admin/">后台</a></li>
    </ul>
  </div>
</div>