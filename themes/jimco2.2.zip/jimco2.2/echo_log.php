<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="contentwrap">
  <div class="crumbs">
    <div class="breadcrumbs clearfix">
      <a href="<?php echo BLOG_URL; ?>">首页</a><span></span>
      <a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php blog_sort($logid); ?></a><span></span>
      <a href="javascript:void(0);"><?php echo $log_title; ?></a>
    </div>
  </div>
  <div id="content">
    <div class="meta">
      <h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
      <div class="logmeta clearfix">
        <span><?php echo gmdate('Y - n - j', $date); ?></span>
        <span>作者 : <?php blog_author($author); ?></span>
        <span>分类 :<?php blog_sort($logid); ?></span>
        <ul><?php blog_tag($logid); ?></ul>
        <span><?php editflg($logid,$author); ?></span>
      </div>
    </div>
    <div class="logtext"><?php echo $log_content; ?></div>
	<!--
    <div class="share">
      <div id="ckepop">
        <span class="jiathis_txt">分享到：</span>
        <a class="jiathis_button_tsina">新浪微博</a>
        <a class="jiathis_button_qzone">QQ空间</a>
        <a class="jiathis_button_douban">豆瓣</a>
        <a class="jiathis_button_renren">人人网</a>
        <a class="jiathis_button_tqq">腾讯微博</a>
        <a class="jiathis_button_hi">百度空间</a>
        <a class="jiathis_button_t163">网易微博</a>
        <a class="jiathis_button_gmail">Gmail邮箱</a>
      </div>
      <script type="text/javascript" src="http://v2.jiathis.com/code/jia.js?uid=1528361" charset="utf-8"></script>
    </div>
	-->
    <div class="nextlog clearfix"><?php neighbor_log($neighborLog); ?></div>
    <?php blog_trackback($tb, $tb_url, $allow_tb); ?>
    <div class="related-log">
      <h3>相关文章：</h3>
      <ul><?php related_logs($sortid,$logid);?></ul>
    </div>
    <?php doAction('log_related', $logData); ?>
    <h3 class="comment-header">
      <span><?php echo $views; ?> 人围观 / <?php echo $comnum; ?> 条评论</span>
      <a href="#comment">↓快速评论↓</a><a name="comments"></a>
    </h3>
    <?php blog_comments($comments); ?>
    <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
  </div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>