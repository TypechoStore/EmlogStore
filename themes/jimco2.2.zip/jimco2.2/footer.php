<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>
<div class="footerbar">
  <p class="powerby">
    Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>
  </p>
  <p class="footinfo">
    版权所有，保留一切权利！
    <span>©2011 前端那些事儿</span>
    <span>Designed by <a href="http://www.xiejiancong.com" target="_blank">Jimco</a></span>
    <span>
      <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a><?php echo $footer_info; ?>
    </span>
  </p>
  <?php doAction('index_footer'); ?>
</div><!--end #footerbar-->
<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/function.js"></script>
<script>
  jQuery(function($){
    $("#scroll").slider();
    $(".tool-head li").Tab(1,".tool-content div","on");
    $(".tab-header li").Tab(1,".tab-content>div","cur");
  })
</script>
</body>
</html>