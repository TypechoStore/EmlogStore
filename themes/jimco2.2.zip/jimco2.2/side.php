<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="sidebar">
  <div class="side-about clearfix">
    <ul class="myinfo">
      <li><a href="http://t.qq.com/caoyoung" title="关注我的腾讯微博" target="_blank"><span><i class="qqt"></i></span>腾讯微博></a></li>
      <li><a href="http://weibo.com/caoyoung" title="关注我的新浪微博" target="_blank"><span><i class="sinat"></i></span>新浪微博></a></li>
      <li><a href="http://www.xiejiancong.com/rss.php" target="_blank"><span><i class="sub"></i></span>前端订阅></a></li>
      <li class="qside">
        <a href=""><span><i class="qcon"></i></span>Q群交流></a>
        <div class="side-out">
          <a href="http://qun.qq.com/#jointhegroup/gid/92907430/" style="color:red;" target="_blank">前端交流群Ⅰ</a>
          <a href="javascript:void(0);">前端交流群Ⅱ</a>
          <a href="javascript:void(0);">前端交流群Ⅲ</a>
        </div>
      </li>
    </ul>
  </div>
  <div class="toolbox">
    <div class="tool-head" id="tool-head">
      <ul>
        <li class="on">工具箱</li>
        <li>实验室</li>
        <li>名片夹</li>
      </ul>
    </div>
    <div class="tool-content" id="tool-content">
      <div class="tools clearfix">
        <ul class="clearfix">
          <li><a href="http://www.xiejiancong.com/tools/css2/" target="_blank">CSS2.0 参考手册</a></li>
          <li><a href="http://www.xiejiancong.com/tools/css3/" target="_blank">CSS3.0 参考手册</a></li>
          <li><a href="http://www.xiejiancong.com/tools/jQuery1.4.1/" target="_blank">jQuery 参考手册</a></li>
          <li><a href="http://www.xiejiancong.com/tools/html/" target="_blank">HTML 参考手册</a></li>
        </ul>
        <ul class="clearfix">
          <li><a href="<?php echo BLOG_URL; ?>css-hack.html">CSS Hack 速查表</a></li>
          <li><a href="<?php echo BLOG_URL; ?>xhtml-tags.html">xHTML 标签语义</a></li>
          <li><a href="http://www.xiejiancong.com/tools/css-min/" target="_blank">CSS压缩工具</a></li>
          <li><a href="http://www.xiejiancong.com/html-special-characters.html">Html字符参照表</a></li>
          <li><a href="http://www.xiejiancong.com/tools/livecode/" target="_blank">Html在线调试</a></li>
          <li><a href="http://www.xiejiancong.com/tools/format/" target="_blank">Html/CSS/JS格式化</a></li>
        </ul>
      </div>
      <div class="lab">
        <ul class="clearfix">
          <li><a href="http://lab.xiejiancong.com/note/">WebStorage便签</a></li>
          <li><a href="#">jQuery萌宠</a></li>
        </ul>
      </div>
      <div class="ecard" style="display:none;">
        <p>Jimco - 90后小童鞋，对前端有那么一点点热情，对梦想有那么一点点执着！</p>
        <a href="http://resume.xiejiancong.com/" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/ecard.png" /></a>
      </div>
    </div>
  </div>
  <ul>
  <?php 
  $widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
  doAction('diff_side');
  foreach ($widgets as $val){
    $widget_title = @unserialize($options_cache['widget_title']);
    $custom_widget = @unserialize($options_cache['custom_widget']);
    if(strpos($val, 'custom_wg_') === 0){
      $callback = 'widget_custom_text';
      if(function_exists($callback)){
        call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
      }
    }else{
      $callback = 'widget_'.$val;
      if(function_exists($callback)){
        preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
        $wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
        call_user_func($callback, htmlspecialchars($wgTitle));
      }
    }
  }
  ?>
  </ul>
</div>