<?php //文章详情页
if(!defined('EMLOG_ROOT')) {exit('error!');}include View::getView('go/head');if($author==15){include View::getView('go/code');exit;}?>
<div class="def-content"><div class="def-left">
<div class="def-log">
<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
<div class="def-log-date"><p><?php $weekarray=array("日","一","二","三","四","五","六");echo gmdate('Y年m月d日', $date);echo " 星期".$weekarray[gmdate('w',$date)];?> / <?php blog_author($author); ?> / <?php blog_sort($logid); ?> / <?php editflg($logid,$author); ?></p>
<script type="text/javascript">bdfx()</script>
</div>
<div class="def-ad"><?php echo _g('ad');?></div>
<div class="def-log-nr"><?php echo $log_content; ?></div>
<p class="def-log-bq">本文由<b><?php blog_author($author); ?></b>整理编辑，转载请注明：<?php echo Url::log($logid); ?> | <?php echo $blogname; ?></p>
<p class="def-log-tag"><?php blog_tag($logid); ?></p>
<?php if(in_array('dhglog', _g('on-off'))):?><div id="cyEmoji" role="cylabs" data-use="emoji" sid="<?php echo $logData['logid'];?>"></div><script type="text/javascript" charset="utf-8" src="http://changyan.itc.cn/js/??lib/jquery.js,changyan.labs.js?appid=cyrviouCG"></script><?php else:endif;?>
<div class="def-log-nextlog"><?php neighbor_log($neighborLog); ?></div>
<div class="def-log-xglog"><?php xg_logs($logData);?></div>
<?php doAction('log_related', $logData); ?>
<?php if(in_array('comlist', _g('on-off'))){?><?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);blog_comments($comments,$params);?><?php }else{?><p style="text-align:center;line-height:30px;font-size:14px;font-weight:bold;">该文章已关闭评论</p><?php }?>
</div></div>
<div class="def-right"><?php include View::getView('side');?></div></div>
<?php include View::getView('footer');?>
<?php if(in_array('next', _g('on-off'))):?><?php nextLog($logid, $sortid, 'prev'); nextLog($logid, $sortid, 'next');?><?php else:endif; ?>