<?php //自建页面模板
if(!defined('EMLOG_ROOT')) {exit('error!');}if($logid==_g('dulicom')){include View::getView('go/links');exit;} if($logid==_g('zhidao')){include View::getView('go/zhidao');exit;}include View::getView('go/head');?>
<div class="def-content"><div class="def-left">
<div class="mbx"><p>现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; <?php echo $log_title; ?></p></div>
<div class="def-page">
<h2><?php echo $log_title; ?></h2>
<div class="def-page-nr"><?php echo $log_content; ?></div>
</div>
<?php if(in_array('comlist', _g('on-off'))){?><?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);blog_comments($comments,$params);?><?php }else{?><p style="text-align:center;line-height:30px;font-size:14px;font-weight:bold;">该文章已关闭评论</p><?php }?>
</div>
<div class="def-right"><?php include View::getView('side');?></div></div>
<?php include View::getView('footer');?>