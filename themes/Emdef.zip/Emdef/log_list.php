<?php if($pageurl == Url::logPage()){include View::getView('home');}else{?>
<?php if($keyword){include View::getView('go/search');}else{ ?>
<div class="def-content"><div class="def-left">
<div class="mbx"><p>现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; <?php if ($params[1]=='sort'){ ?><?php echo '<a href="'.Url::sort($sortid).'" title="'.$sortName.'" ><b>'.$sortName.'</b></a>';?><?php }elseif ($params[1]=='tag'){ ?><b><?php echo urldecode($params[2]);?></b><?php }elseif($params[1]=='author'){ ?><b><?php echo blog_author($author);?></b><?php }elseif($params[1]=='keyword'){ ?><b><?php echo htmlspecialchars(urldecode($params[2]));?></b><?php }elseif($params[1]=='record'){ ?><b><?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?> </b>发布的文章<?php }else{?><?php }?></p></div>
<?php doAction('index_loglist_top'); ?>
<?php if(!empty($logs)):foreach($logs as $key=>$value):?>
<div class="def-list">
<h2><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
<div class="def-date"><?php $weekarray=array("日","一","二","三","四","五","六");echo gmdate('Y年m月d日', $value['date']);echo" 星期".$weekarray[gmdate('w', $value['date'])];?> / <?php blog_author($value['author']); ?> / <?php blog_sort($value['logid']); ?> / <?php editflg($value['logid'],$value['author']); ?></div>
<div class="def-list-nr"><?php if(preg_match_all("/<img.*src=[\"'](.*)[\"']/Ui", $value['content'], $imgs) && !empty($imgs[1])){$imgNum = count($imgs[1]);if($imgNum < 5) $n = 1;elseif($imgNum < 10) $n = 5;else $n = 10;for($i=0; $i < $n; $i++){if($n == 1){$img = $imgs[1][$i];echo "<p><img src='$img'></p>";}elseif($n > 1){$img = $imgs[1][$i];echo "<ul><li><img src='$img'><li></ul>";}}}else{?><?php if(in_array('listimg', _g('on-off'))):?><p><img src="<?php echo TEMPLATE_URL;?>images/news.jpg"></p><?php else:endif;?><?php }?><?php echo subString(strip_tags($value['content']),0,200);?></div>
<div class="def-list-tag"><?php blog_tag($value['logid']); ?></div>
<div class="def-list-count"><a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a> / <a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a></div>
<?php if($key == 0): ?><div class="def-ad"><?php echo _g('ad');?></div><?php endif; ?>  
</div>
<?php endforeach;else:?><div class="def-page"><h2>未找到您搜索的结果</h2><div class="def-page-nr">抱歉，没有符合您查询条件的结果；请返回首页继续浏览<br /><script  charset="utf-8" src="http://daohang.shuyong.net/daohang.js" type="text/javascript"></script></div></div><?php endif;?>
<div class="def-pagenav"><?php echo fy($lognum,$index_lognum,$page,$pageurl);?></div>
</div><div class="def-right"><?php include View::getView('side');?></div></div>
<?php include View::getView('footer');?>
<?php if(in_array('next', _g('on-off'))):?><?php $page_loglist = my_page($lognum, $index_lognum, $page, $pageurl); echo $page_loglist;?><?php else:endif; ?>
<?php }}?>