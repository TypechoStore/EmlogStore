<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width; initial-scale=1.0">
<title><?php echo $site_title;if($page>=2){echo ' - 第'.$page.'页';}?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<link href="<?php echo TEMPLATE_URL; ?>go/default.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>go/Emdef.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<!--[if lt IE 9]><script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>go/css3-mediaqueries.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>go/html5.js"></script>
<![endif]-->
<!--[if IE 6]><script src="<?php echo TEMPLATE_URL; ?>go/iefix.js" type="text/javascript"></script><![endif]-->
<?php doAction('index_head'); ?>
</head><body>
<div class="def-main"><div class="bg-l"><div class="bg-r">
<div class="def-head">
<?php if(_g('logoys')=="logo"):?><p><img src="<?php echo _g('logo'); ?>" /></p>
<?php elseif(_g('logoys')=="wenzi"):?><h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1><?php endif;?>
<div class="search"><form name="keyform" method="get" action="<?php echo BLOG_URL; ?>"><input name="keyword" class="sousuo1" type="text" placeholder="善用搜索,事半功倍" /><input type="submit" class="sousuo" title="搜索" value="搜索"/></form></div>
<h3><?php echo $bloginfo; ?></h3></div>
<div class="m-nav"><ul><li><a href="<?php echo BLOG_URL; ?>">首页</a></li><li><a href="<?php echo _g('comurl'); ?>">留言本</a></li><li><a onClick="Mnav();return false;" href="javascript:void(null)" title="导航">更多...</a></li></ul><div id="m-nav" style="display:none;"><?php echo nav_sort($title); ?></div></div>
<?php if(in_array('bankg', _g('on-off'))):?><div class="def-ban"><a href="<?php echo BLOG_URL; ?>"><img src="<?php echo _g('ban'); ?>" /></a></div><?php else:endif;?>
<div class="def-nav"><?php blog_navi();?></div>
<div class="def-content"><div class="def-left"><?php if("http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] == BLOG_URL) {?><div class="def-sortop"><?php sortoplog();?></div><?php }?>
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $key=>$value){?> 
<div class="def-list">
<h2><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
<div class="def-date"><?php $weekarray=array("日","一","二","三","四","五","六");echo gmdate('Y年m月d日', $value['date']);echo" 星期".$weekarray[gmdate('w', $value['date'])];?> / <?php blog_author($value['author']); ?> / <?php blog_sort($value['logid']); ?> / <?php editflg($value['logid'],$value['author']); ?></div>
<div class="def-list-nr"><?php if(preg_match_all("/<img.*src=[\"'](.*)[\"']/Ui", $value['content'], $imgs) && !empty($imgs[1])){$imgNum = count($imgs[1]);if($imgNum < 5) $n = 1;elseif($imgNum < 10) $n = 5;else $n = 10;for($i=0; $i < $n; $i++){if($n == 1){$img = $imgs[1][$i];echo "<p><img src='$img'></p>";}elseif($n > 1){$img = $imgs[1][$i];echo "<ul><li><img src='$img'><li></ul>";}}}else{?><?php if(in_array('listimg', _g('on-off'))):?><p><img src="<?php echo TEMPLATE_URL;?>images/news.jpg"></p><?php else:endif;?><?php }?><?php echo subString(strip_tags($value['content']),0,200);?></div>
<div class="def-list-tag"><?php blog_tag($value['logid']); ?></div>
<div class="def-list-count"><a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a> / <a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a></div><?php if($key == 0): ?><div class="def-ad"><?php echo _g('ad');?></div><?php endif; ?></div>
<?php }?>
<div class="def-pagenav"><?php echo fy($lognum,$index_lognum,$page,$pageurl);?></div>
</div><div class="def-right"><?php include View::getView('side');?>
</div></div>
<?php if(in_array('next', _g('on-off'))):?><?php $page_loglist = my_page($lognum, $index_lognum, $page, $pageurl); echo $page_loglist;?><?php else:endif; ?>
<?php include View::getView('footer');?>