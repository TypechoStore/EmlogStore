<div class="def-foot">
Copyright © 2014 <?php echo $blogname; ?> 版权所有 &nbsp; <?php echo $icp; ?><br />
<?php echo $footer_info; ?><br />
<small>Powered by emlog / &Author <a href="http://www.shuyong.net" title="舍力博客" target="_blank">舍力博客</a>.</small>
<?php if(in_array('top', _g('on-off'))){?><div id="shangxia"><div id="shang" title="↑ 返回顶部"></div><?php if(!empty($tws)){?><a id="comt1"></a><?php }elseif(isset($logid)){?><a href="#comment-place" id="comt"></a><?php }else{?><a href="<?php echo _g('comurl');?>" id="comt"></a><?php }?><div id="xia" title="↓ 移至底部"></div></div><?php }?>
<?php doAction('index_footer'); ?>
</div></div>
</body>
</html>