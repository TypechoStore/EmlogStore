<?php include View::getView('go/head');?>
<div class="def-content"><div class="def-left">
<div class="mbx"><p>现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; <?php echo $log_title; ?></p></div>
<div class="def-page"><h2><?php echo $log_title; ?></h2></div>
<div class="guidang">
<?php
global $CACHE; 
$loglists_cache = $CACHE->readCache('loglists');
$year_month = 0;
foreach($loglists_cache as $value):
if($year_month != 0&&$year_month != date("Y-m",$value['date'])){
echo '</ul>';}
if($year_month != date("Y-m",$value['date'])){
$year_month = date("Y-m",$value['date']);
echo '<h2 class="guidang-tt">'.$year_month.''.$value['lognum'].'</h2><ul class="guidang-list">';}?>
<li><span><?php echo date("Y-m-d",$value['date']);?></span><div class="atitle"><a href="<?php echo Url::log($value['gid']);?>" target="_blank" title="<?php echo $value['title']; ?>"><?php echo $value['title'];?></a></div></li>
<?php endforeach;?>
</div></div>
<script type="text/javascript">
jQuery(function($){
if ($('div.guidang').length) {
$('div.guidang').find('.guidang-list:gt(0)').hide();
$('div.guidang').find('h2').on('click', function(){
$(this).next('.guidang-list').slideToggle();
})}})
</script>
<div class="def-right"><?php include View::getView('side');?></div></div>
<?php include View::getView('footer');?>