<div class="def-content"><div class="def-left">
<div class="def-log">
<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
<p class="def-log-date"><?php echo gmdate('Y-n-j', $date);?> / <?php blog_author($author); ?> / <?php blog_sort($logid); ?> / <?php editflg($logid,$author); ?></p>
<div class="def-log-nr"><?php echo $log_content; ?><?php doAction('log_code', $logData); ?></div>
<p class="def-log-bq">本文由<b><?php blog_author($author); ?></b>整理编辑，转载请注明：<?php echo Url::log($logid); ?> | <?php echo $blogname; ?></p>
<p class="def-log-tag"><?php blog_tag($logid); ?></p>
<div class="def-log-nextlog"><?php neighbor_log($neighborLog); ?></div>
<?php doAction('log_related', $logData); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); blog_comments($comments);?>
</div></div>
<div class="def-right"><?php include View::getView('side');?></div></div>
<?php include View::getView('footer');?>
<style type="text/css">#sycode{width:90%;height:350px;padding:10px;font-size:12px;}</style>
<script type="text/javascript">code()</script>