<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width; initial-scale=1.0">
<title><?php echo $site_title;if($page>=2){echo ' - 第'.$page.'页';}?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<?php echo gf_url($logid);?>
<link href="<?php echo TEMPLATE_URL; ?>go/default.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>go/Emdef.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<!--[if lt IE 9]><script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>go/css3-mediaqueries.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>go/html5.js"></script>
<![endif]-->
<!--[if IE 6]><script src="<?php echo TEMPLATE_URL; ?>go/iefix.js" type="text/javascript"></script><![endif]-->
<?php doAction('index_head'); ?>
</head><body>
<div class="def-main"><div class="bg-l"><div class="bg-r">
<div class="def-head">
<?php if(_g('logoys')=="logo"):?><p><img src="<?php echo _g('logo'); ?>" /></p>
<?php elseif(_g('logoys')=="wenzi"):?><h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1><?php endif;?>
<div class="search"><form name="keyform" method="get" action="<?php echo BLOG_URL; ?>"><input name="keyword" class="sousuo1" type="text" placeholder="善用搜索,事半功倍" /><input type="submit" class="sousuo" title="搜索" value="搜索"/></form></div>
<h3><?php echo $bloginfo; ?></h3></div>
<div class="m-nav"><ul><li><a href="<?php echo BLOG_URL; ?>">首页</a></li><li><a href="<?php echo _g('comurl'); ?>">留言本</a></li><li><a onClick="Mnav();return false;" href="javascript:void(null)" title="导航">更多...</a></li></ul><div id="m-nav" style="display:none;"><?php echo nav_sort($title); ?></div></div>
<?php if(in_array('bankg', _g('on-off'))):?><div class="def-ban"><img src="<?php echo _g('ban'); ?>" alt="<?php echo $blogname;?>顶部图片"/></div><?php else:endif;?>
<div class="def-nav"><?php blog_navi();?></div>