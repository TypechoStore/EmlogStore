<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width; initial-scale=1.0">
<title><?php echo $log_title;?> - 解决Emlog博客程序的各种疑难杂症</title>
<meta name="keywords" content="emlog教程,emlog,emlog程序,个人博客系统,emlog官网,emlog论坛,那多记忆,,"/>
<meta name="description" content="本页面可以为大家免费解决Emlog博客使用过程中的疑难杂症，在提交问题时请尽量将问题描述清楚，请使用正确的邮箱地址，以便解决你的问题时发送邮件提醒你；<?php echo $blogname; ?>欢迎有问题在此提交！" /><?php echo gf_url($logid);?>
<link href="<?php echo TEMPLATE_URL; ?>go/default.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>go/Emdef.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<!--[if lt IE 9]><script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>go/css3-mediaqueries.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>go/html5.js"></script>
<![endif]-->
<!--[if IE 6]><script src="<?php echo TEMPLATE_URL; ?>go/iefix.js" type="text/javascript"></script><![endif]-->
</head><body>
<div class="def-main"><div class="bg-l"><div class="bg-r">
<div class="def-head"><h1><?php echo $log_title;?></h1>
<div class="search"><form name="keyform" method="get" action="<?php echo BLOG_URL; ?>"><input name="keyword" class="sousuo1" type="text" placeholder="善用搜索,事半功倍" /><input type="submit" class="sousuo" title="搜索" value="搜索"/></form></div>
<h3></h3></div><div class="def-nav"><?php blog_navi();?></div>
<div class="def-page-nr"><?php echo $log_content; ?></div>
<?php //shuyong.net：问题列表 
extract($comments);if($commentStacks):endif;
$i = count($comments);foreach($comments as $value){if($value['pid'] != 0){$i--;}}?>
<?php foreach($commentStacks as $cid):$comment = $comments[$cid];$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' :$comment['poster'];?>
<div class="zhidao"><a name="<?php echo $comment['cid']; ?>"></a>
<div class="zhidao-name"><b><?php echo com_url($comment['poster']);?> </b> 在 <?php echo $comment['date'];?> 提交了问题 [<a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)" >回复该问题</a>]</div>
<div class="zhidao-content"><b>问题内容：</b><?php echo $comment['content']; ?></div>
<?php zhidao($comments, $comment['children']); ?></div><?php endforeach; ?>
<div class="def-pagenav">(共<?php echo $i--;?>问题)<?php echo $commentPageUrl;?></div>
<hr id="fgx" /><?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);?>
<div class="def-foot">Copyright © 2015 <?php echo $blogname; ?> 版权所有 </div>
<?php //shuyong.net：回复列表
function zhidao($comments, $children){foreach($children as $child):$comment = $comments[$child];$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank" >'.$comment['poster'].'</a>' : $comment['poster'];?>
<div class="zhidao-huifu"><a name="<?php echo $comment['cid']; ?>"></a>
<div class="zhidao-name"><b><?php echo com_url($comment['poster']);?></b> 在 <?php echo $comment['date']; ?> 给出了回复</div>
<div class="zhidao-content"><?php echo $comment['content'];?></div></div><?php endforeach; ?><?php }?>

