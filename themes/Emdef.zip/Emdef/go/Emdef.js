$(document).ready(function(){ 
    var prevpage=$(".prev").attr("href"); 
    var nextpage=$(".next").attr("href"); 
    $("body").keydown(function(event){ 
      if(event.keyCode==37 && prevpage!=undefined) location=prevpage; 
      if(event.keyCode==39 && nextpage!=undefined) location=nextpage; 
    }); 
 });
 
$(function () {
if ($(".fixed_side").length > 0) {
var offset = $(".fixed_side").offset();
$(window).scroll(function () {
var scrollTop = $(window).scrollTop();
//如果距离顶部的距离小于浏览器滚动的距离，则添加fixed属性。
if (offset.top < scrollTop) $(".fixed_side").addClass("fixed");
//否则清除fixed的css属性
else $(".fixed_side").removeClass("fixed");
});}});

function Mnav(){
nav = document.getElementById("m-nav");
if(nav.style.display == "none"){
nav.style.display = "block";}
else{
nav.style.display = "none";
}}

jQuery(document).ready(function($) {
$body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $("html") : $("body")) : $("html,body");
$("#shang").mouseover(function() {
up()
    }).mouseout(function() {
        clearTimeout(fq)
    }).click(function() {
        $body.animate({
            scrollTop: 0
        },
        400)
    });
    $("#xia").mouseover(function() {
        dn()
    }).mouseout(function() {
        clearTimeout(fq)
    }).click(function() {
        $body.animate({
            scrollTop: $(document).height()
        },
        400)
    });
    $("#comt").click(function() {
        $body.animate({
            scrollTop: $("#respond").offset().top
        },
        400)
    });
});
function up() {
    $wd = $(window);
    $wd.scrollTop($wd.scrollTop() - 3);
    fq = setTimeout(up, 0);
}
function dn() {
    $wd = $(window);
    $wd.scrollTop($wd.scrollTop() + 2);
    fq = setTimeout(dn, 50);
}


function code() {
document.writeln("<style type=\"text/css\">#sycode{width:95%;height:200px;padding:10px;font-size:12px;}</style>");
document.writeln("<script type=\"text/javascript\">function runEx(cod1)  {cod=document.getElementById(cod1);var code=cod.value;if (code!=\"\"){var newwin=window.open(\'\',\'\',\'\');newwin.opener = null;newwin.document.write(code);newwin.document.close();}}</script>");
}

function bdfx(){
document.writeln("<div class=\"bdsharebuttonbox\"><a href=\"#\" class=\"bds_weixin\" data-cmd=\"weixin\" title=\"分享到微信\"></a><a href=\"#\" class=\"bds_qzone\" data-cmd=\"qzone\" title=\"分享到QQ空间\"></a><a href=\"#\" class=\"bds_tqq\" data-cmd=\"tqq\" title=\"分享到腾讯微博\"></a><a href=\"#\" class=\"bds_tsina\" data-cmd=\"tsina\" title=\"分享到新浪微博\"></a><a href=\"#\" class=\"bds_t163\" data-cmd=\"t163\" title=\"分享到网易微博\"></a></div>");
document.writeln("<script>window._bd_share_config={\"common\":{\"bdSnsKey\":{},\"bdText\":\"\",\"bdMini\":\"2\",\"bdMiniList\":[\"qzone\",\"tsina\",\"weixin\",\"tqq\",\"t163\",\"meilishuo\",\"mogujie\",\"diandian\",\"huaban\",\"share189\",\"duitang\",\"hx\",\"fx\",\"youdao\",\"sdo\",\"qingbiji\",\"people\",\"xinhua\",\"mail\",\"kanshou\",\"isohu\",\"yaolan\",\"wealink\",\"xg\",\"ty\",\"iguba\",\"fbook\",\"twi\",\"linkedin\",\"copy\",\"print\"],\"bdPic\":\"\",\"bdStyle\":\"0\",\"bdSize\":\"16\"},\"share\":{}};with(document)0[(getElementsByTagName(\'head\')[0]||body).appendChild(createElement(\'script\')).src=\'http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion=\'+~(-new Date()/36e5)];</script>");
}