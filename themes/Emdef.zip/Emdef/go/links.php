<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width; initial-scale=1.0">
<title><?php echo $log_title; ?> - 收录优质的博客站点</title>
<meta name="keywords" content="博客大全,网址导航"/>
<meta name="description" content="博客大全是只收录以博客程序建立的最活跃,业界最权威的博客导航类网站,目前正在收录中,<?php echo $blogname; ?>期待您的加入,加入博客大全能为您的网站带来流量。" /><?php echo gf_url($logid);?>
<link href="<?php echo TEMPLATE_URL; ?>go/default.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>go/Emdef.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<!--[if lt IE 9]><script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>go/css3-mediaqueries.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>go/html5.js"></script>
<![endif]-->
<!--[if IE 6]><script src="<?php echo TEMPLATE_URL; ?>go/iefix.js" type="text/javascript"></script><![endif]-->
</head><body>
<div class="def-main"><div class="bg-l"><div class="bg-r">
<div class="def-head">
<h1><a href="<?php echo BLOG_URL; ?>">博客大全</a></h1>
<div class="search"><form name="keyform" method="get" action="<?php echo BLOG_URL; ?>"><input name="keyword" class="sousuo1" type="text" placeholder="善用搜索,事半功倍" /><input type="submit" class="sousuo" title="搜索" value="搜索"/></form></div>
<h3>博客大全是只收录以博客程序建立的最活跃,业界最权威的博客导航类网站,目前正在收录中,<?php echo $blogname; ?>期待您的加入,加入博客大全能为您的网站带来流量。</h3></div>
<div class="m-nav"><ul><li><a href="<?php echo BLOG_URL; ?>">首页</a></li><li><a href="<?php echo _g('comurl'); ?>">留言本</a></li><li><a onClick="Mnav();return false;" href="javascript:void(null)" title="导航">更多...</a></li></ul><div id="m-nav" style="display:none;"><?php echo nav_sort($title); ?></div></div>
<div class="def-nav"><?php blog_navi();?></div>
<div class="mbx"><p>现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; <?php echo $log_title; ?></p></div>
<div class="def-page"><h2><?php echo $log_title; ?></h2></div>
<?php //独立评论，做内页友链之用
$DB=MySql::getInstance();
$dulicom = _g('dulicom');
$sql=$DB->query("SELECT * FROM ".DB_PREFIX."comment WHERE gid='$dulicom' AND hide='n' AND mail!='345952779@qq.com' LIMIT 1000");
while($row=$DB->fetch_array($sql)){$get[]=$row;}?>
<div class="dulipl"><?php foreach($get as $row){?><ul><li><img src="<?php echo myGravatar($row['mail']); ?>" align="left" /><div class="dulipl-tt"><a href="<?php echo $row['url']; ?>" target="_blank" target="<?php echo $row['poster']; ?>"><?php echo $row['poster']; ?></a></div><div class="dulipl-nr"><?php echo $row['comment']; ?></div></li></ul><?php }?></div>
<div class="pl_num">共收录<?php echo $comnum;?>个网址</div>
<hr id="fgx" /><div class="def-page-nr"><?php echo $log_content; ?></div>
<hr id="fgx" /><?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);?>
<div class="def-foot">Copyright © 2015 <?php echo $blogname; ?> 版权所有 </div>