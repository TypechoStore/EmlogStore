<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width; initial-scale=1.0">
<title><?php echo htmlspecialchars(urldecode($params[2]));echo ' - ';echo $blogname;if($page>=2){echo ' - 第'.$page.'页';}?></title>
<?php echo gf_url($logid);?>
<!--[if lt IE 9]><script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>go/css3-mediaqueries.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>go/html5.js"></script><![endif]-->
<!--[if IE 6]><script src="<?php echo TEMPLATE_URL; ?>go/iefix.js" type="text/javascript"></script><![endif]-->
<style>
input,textarea{outline:none;}
ul,li,p,h1,h2,h3,h4,h5,h6,dl,dd{padding:0px;margin:0px;list-style:none;}img{border:none;}
a{color:#00c;text-decoration:none;}
a:visited{color:#606;}
.search{max-width:500px;height:39px;margin:auto;}
.search form{border:2px solid #ccc;zoom:1;position:relative;height:35px;}
.sousuo1{border:none;height:24px;line-height:24px;width:67%;float:left;font-size:14px;margin-top:5px;margin-left:10px;color:#999;font-size:14px;}
.sousuo{float:right;width:20%;height:35px;border:none;text-align:center;font-size:14px;font-weight:bold;color:#886353;padding:0;line-height:28px;cursor:pointer;}
.sea{margin:10px auto;max-width:1080px;font-family:\5FAE\8F6F\96C5\9ED1,\5b8b\4f53,sans-serif;}

.sea-l{float:left;max-width:200px;}
.sea-sort{margin-top:10px;clear:both;overflow:hidden;}
.sea-sort li{float:left;width:50%;line-height:30px;font-size:12px;height:30px;overflow:hidden;}
.sea-sort li a{padding:5px 10px 5px 10px;border:1px solid #ccc;}
.sea-sort li a:hover{border:1px solid #F00;}
.sea-sort ul{text-align:center;clear:both;color:#FF0000;}
.sea-sort h1{border-bottom:2px solid #EFEFEF;padding-top:2px;font-weight:normal;}
.sea-sort h1 b{border-bottom:2px solid #ccc;display:inline-block;position:relative;bottom:-2px;padding:0 10px 0 10px;font-size:16px;font-weight:normal;}
.sea-c{float:left;max-width:600px;}
.sea-gg{float:right;width:270px;}

@media screen and (max-width:879px){.sea-l,.sea-sort{height:0px;display:none;width:0px;!important}.sea-c{width:100%;}.sea-gg{width:100%;}}
@media screen and (min-width:880px) and (max-width:1079px){.sea-l{height:0px;display:none;width:0px;}.sea-c{float:left;max-width:600px;}.sea-gg{float:right;width:270px;}}
.sea-list{overflow:hidden;border-bottom:1px solid #ccc;padding:10px 0 10px 0;clear:both;}
.sea-list h2{font-size:16px; font-weight:normal;}
.sea-list-nr{ margin:5px 0 2px 0;clear:both;overflow:hidden;font-size:13px;line-height:20px;}
.sea-list-date{clear:both;overflow:hidden;font-size:13px;color:#008000;}
.sea-fy{margin:10px;padding:5px;text-align:center; font-size:14px;}
.sea-fy span{margin:0 4px;padding:2px 7px;background:#ccc;color:#886353;border:1px solid #ccc;border-radius:3px;-moz-border-radius:3px;-webkit-border-radius:3px;font-weight:bold;}
.sea-fy a{margin:0 4px;padding:2px 7px;border:1px solid #ccc;border-radius:3px;-moz-border-radius:3px;-webkit-border-radius:3px;}
.sea-gg h1{border-bottom:2px solid #EFEFEF;padding-top:2px;font-weight:normal;}
.sea-gg h1 b{border-bottom:2px solid #ccc;display:inline-block;position:relative;bottom:-2px;padding:0 10px 0 10px;font-size:16px;font-weight:normal;}
.gg-nr{margin-top:5px; font-size:14px; line-height:25px;text-align:center;}
.gg-nr img{max-width:100%; margin-bottom:10px;}
.def-ad{clear:both;text-align:center;}
.def-ad img{max-width:100%;}
</style>
</head>
<body>
<div class="search"><form name="keyform" method="get" action="<?php echo BLOG_URL; ?>"><input name="keyword" class="sousuo1" type="text" placeholder="善用搜索,事半功倍"  value="<?php echo $keyword;?>"/><input type="submit" class="sousuo" title="搜索" value="搜索一下"/></form></div>
<div class="sea">
<div class="sea-l">
<?php //分类
global $CACHE;$sort_cache = $CACHE->readCache('sort'); ?>
<div class="sea-sort"><h1><b>所有分类</b></h1>
<?php foreach($sort_cache as $value):if($value['pid'] != 0) continue;?><li><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?></a></li><?php if (!empty($value['children'])): ?><?php $children = $value['children'];foreach ($children as $key):$value = $sort_cache[$key];?>
<li><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?></a></li><?php endforeach;endif;endforeach; ?></div>
<?php //归档
global $CACHE; $record_cache = $CACHE->readCache('record');?>
<div class="sea-sort"><h1><b>文章归档</b></h1>
<?php foreach($record_cache as $value): ?><li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?></a></li><?php endforeach;?></div>
<?php //标签
global $CACHE;$tag_cache = $CACHE->readCache('tags');foreach ($tag_cache as $key => $row){$usenum[$key]  = $row['usenum'];}array_multisort($usenum, SORT_DESC, $tag_cache);?>
<div class="sea-sort"><h1><b>文章标签</b></h1>
<?php foreach($tag_cache as $value):if($value['usenum'] > '1'): ?>
<li><a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇文章"><?php echo $value['tagname'];?></a></li><?php endif; endforeach;?></div>
</div>
<div class="sea-c">
你搜索的关键词为 <span style="color:#F00; font-weight:bold;"><?php echo $keyword;?></span> ，以下是搜索结果

<?php if(!empty($logs)){foreach($logs as $key=>$value){?>
<div class="sea-list">
<h2><a href="<?php echo $value['log_url']; ?>" target="_blank"><?php echo $value['log_title'] = str_replace($keyword,'<span style="color:#f00;font-weight:bold;">'.$keyword.'</span>',$value['log_title']);?></a></h2>
<div class="sea-list-nr"><?php echo subString(strip_tags($value['content']),0,200);?></div>
<div class="sea-list-date"><?php echo $value['log_url']; ?> <?php $weekarray=array("日","一","二","三","四","五","六");echo gmdate('Y年m月d日', $value['date']);echo" 星期".$weekarray[gmdate('w', $value['date'])];?></div>
<?php if($key == 2): ?><div class="def-ad"><?php echo _g('ad');?></div><?php endif; ?> 
</div>
<?php }}else{?>没有找到你搜索的结果，请正确输入你要查找的内容；尽量精简你的搜索词<?php }?>
<div class="sea-fy"><?php echo fy($lognum,$index_lognum,$page,$pageurl);?></div>
</div>
<div class="sea-gg">
<h1><b>赞助商广告</b></h1>
<div class="gg-nr"><?php echo _g('search');?></div>
</div>
</div>
</body>
</html>