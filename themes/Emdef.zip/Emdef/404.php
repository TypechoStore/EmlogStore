<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width; initial-scale=1.0">
<title>404错误页</title>
<style type="text/css">
body{margin:auto;padding:0px;font-size:12px;color:#666;background:#ccc;font-family:\5FAE\8F6F\96C5\9ED1,\5b8b\4f53,sans-serif;}
.map-main{max-width:1000px;margin:auto;clear:both;overflow:hidden;box-shadow:0px 0px 200px #B0E0E6;background:#fff; padding:0 5px 0 5px;}
ul,li,p,h1,h2,h3,h4,h5,h6,dl,dd{padding:0px;margin:0px;list-style:none;}img{border:none;}
a{color:#886353;text-decoration:none;}
a:hover {color:#FF0000;}
@media screen and (min-width:1001px){/**分辨率大于1001px时css**/
.bg-l{max-width:1020px;margin:auto;clear:both;overflow:hidden;}.bg-r{max-width:1020px;margin:auto;clear:both;overflow:hidden;}
.m-nav{display:none;_display:none;}
.map-head h1{color:#1F1F1F;font-size:30px;margin:20px 0 0 10px;float:left;}
.map-head p{margin-top:10px;float:left;}
.map-head p img{height:60px;max-width:300px;}
.search{float:right;width:300px;height:39px;margin:20px 0px 0px 0px;}
}
@media screen and (max-width:500px){/**分辨率小于500px时css**/
.map-head h3,.map-nav,.map-right,.map-sortop{height:0px;display:none;width:0px;}
.m-nav{background:#f0f0f0;max-width:1000px;height:35px;margin:auto; margin-top:10px;clear:both;display:block;clear:both;}
.m-nav ul{overflow:hidden;clear:both;}
.m-nav ul li{width:33.3333333333333333333333333333333%;float:left;line-height:35px;font-size:14px;text-align:center;font-weight:bold;}
#m-nav{line-height:35px;font-size:14px;text-align:center;}
#m-nav li{width:33.33333333333333333333333333333%;float:left;}
.map-head h1{color:#1F1F1F;font-size:30px;margin:auto;text-align:center;}
.map-head p{text-align:center;}
.map-head p img{height:60px;max-width:300px;}
.search{width:100%;height:39px;margin:auto;}
}
@media screen and (min-width:501px) and (max-width:1000px) {/**分辨率小于1000px时css**/
.map-head h3,.map-nav,.map-right{height:0px;display:none;width:0px;}
.m-nav{background:#f0f0f0;max-width:1000px;height:35px;margin:auto; margin-top:10px;clear:both;display:block;clear:both;}
.m-nav ul{overflow:hidden;clear:both;}
.m-nav ul li{width:33.3333333333333333333333333333%;float:left;line-height:35px;font-size:14px;text-align:center;font-weight:bold;}
#m-nav{line-height:35px;font-size:14px;text-align:center;}
#m-nav li{width:33.33333333333333333333333333333%;float:left;}
.map-head h1{color:#1F1F1F;font-size:30px;margin:auto;text-align:center;}
.map-head p{text-align:center;}
.map-head p img{height:60px;max-width:300px;}
.search{width:90%;height:39px;margin:auto;}
.map-ban{max-width:1000px;margin-top:10px;border-bottom:1px solid #ccc;padding-bottom:10px;}.map-ban img{width:100%;}
}
.map-head{margin:auto;}
.map-head h3{color:#525252;font-style:italic;font-size:14px;font-weight:normal;margin:0px 20px 0px 20px;padding:10px 0px 10px 0px;clear:both;}
.search form{border:2px solid #ccc;zoom:1;position:relative;height:35px;}
.sousuo1{border:none;height:24px;line-height:24px;width:67%;float:left;font-size:14px;margin-top:5px;margin-left:10px;color:#999;font-size:14px;}
.sousuo{float:right;width:20%;height:35px;border:none;text-align:center;font-size:14px;font-weight:bold;color:#886353;padding:0;line-height:28px;cursor:pointer;}
.map-nav{margin:10px 0px 0px 0px;border:1px solid #ccc;clear:both;}
.map-nav .bar{margin:0px;padding:0px;height:31px;}
.map-nav .bar .item{display:block;float:left;position:relative;border-right:1px solid #ccc;}
.map-nav .bar .item a{color:#1F1F1F;text-decoration:none;padding:0 18px;height:31px;line-height:31px;}
.map-nav .bar .item a:hover{background:#EFEFEF;color:#1F1F1F;text-decoration:none;padding:7px 18px;}
.map-nav .current{background:#EFEFEF;}
.map-nav .item:hover .sub-nav,.map-nav .li-hover .sub-nav{display:block;}
.sub-nav{display:none;position:absolute;background:#fff;border:1px solid #ccc;top:31px;left:-1px;width:100%;text-align:center;z-index:100;}
.map-sort{margin-top:10px;clear:both;overflow:hidden;}
.map-sort li{float:left;margin:5px; line-height:30px;}
.map-sort li a{padding:5px 10px 5px 10px;border:1px solid #ccc;}
.map-sort li a:hover{border:1px solid #F00;}
.map-sort ul{text-align:center;clear:both;color:#FF0000;}
.map-sort h1{border-bottom:2px solid #EFEFEF;padding-top:2px; margin:10px 0 0px 0px;}
.map-sort h1 b{border-bottom:2px solid #ccc;display:inline-block;position:relative;bottom:-2px;padding:0 10px 0 10px;font-size:20px;}
.map-foot{margin:auto;margin-bottom:10px;text-align:center;clear:both;overflow:hidden;border:1px solid #ccc;padding:10px 0 10px 0;line-height:20px;font-size:14px;}
</style>
</head>
<body>
<div class="map-main">
<div class="map-head"><h1>404错误页</h1><div class="search"><form name="keyform" method="get" action="<?php echo BLOG_URL; ?>"><input name="keyword" class="sousuo1" type="text" placeholder="善用搜索,事半功倍" /><input type="submit" class="sousuo" title="搜索" value="搜索"/></form></div><h3>您现在所在的位置为访问出错的页面，为了节省您宝贵的时间，<?php echo $blogname; ?>为你准备了网站地图，让你能更精准的找你想要的信息内容；同时你也可以搜索本站</h3></div>
<div class="m-nav"><ul><li><a href="<?php echo BLOG_URL; ?>">首页</a></li><li><a href="<?php echo _g('comurl'); ?>">留言本</a></li><li><a onClick="Mnav();return false;" href="javascript:void(null)" title="导航">更多...</a></li></ul></div>




<?php //404：分类
global $CACHE;$sort_cache = $CACHE->readCache('sort'); ?>
<div class="map-sort"><h1><b>所有分类</b></h1>
<?php foreach($sort_cache as $value):if($value['pid'] != 0) continue;?><li><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a></li><?php if (!empty($value['children'])): ?><?php $children = $value['children'];foreach ($children as $key):$value = $sort_cache[$key];?>
<li><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a></li><?php endforeach;endif;endforeach; ?></div>

<?php //404：归档
global $CACHE; $record_cache = $CACHE->readCache('record');?>
<div class="map-sort"><h1><b>文章归档</b></h1>
<?php foreach($record_cache as $value): ?><li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li><?php endforeach;?></div>

<?php //404：标签
global $CACHE;$tag_cache = $CACHE->readCache('tags');foreach ($tag_cache as $key => $row){$usenum[$key]  = $row['usenum'];}array_multisort($usenum, SORT_DESC, $tag_cache);?>
<div class="map-sort"><h1><b>文章标签</b></h1>
<?php foreach($tag_cache as $value):if($value['usenum'] > '1'): ?>
<li><a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇文章"><?php echo $value['tagname'];?>(<?php echo($value['usenum']);?>)</a></li><?php endif; endforeach;?></div>


<div class="map-foot">Copyright © 2015 舍力博客 版权所有 </div>
</div>
</body>
</html>