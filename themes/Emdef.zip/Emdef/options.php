<?php
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(

'on-off' => array(
'type' => 'checkbox',
'name' => '站点功能开关',
'description' =>'打勾表示显示，默认显示部分(不选则不显示)',
'values' => array(
'top' => '返回顶部图标',
'bankg' => '顶部图片',
'listimg' => '文章列表无图显示默认图片',
'dhglog' => '文章读后感',
'next' => '站点左右翻页',
'comlist' => '站点评论列表',
),
'default' => array(
'top',
'bankg',
),
),

'logo' => array(
'type' =>'image',
'name' =>'头部LOGO',
'values' => array(TEMPLATE_URL .'images/logo.png',
),
'description' =>'设置站点头部LOGO,250X60最佳。',
),

'logoys' => array(
'type' =>'radio',
'name' =>'logo样式',
'values' => array(
'wenzi' =>'文字',
'logo' =>'图片(高度60px，最大宽度300px)',
),
'default' =>'wenzi',
),

'ban' => array(
'type' =>'image',
'name' =>'顶部图片',
'values' => array(TEMPLATE_URL .'images/ban.jpg',
),
'description' =>'设置站点头部图片,宽度980px。',
),

'comurl' => array(
'type' =>'text',
'name' =>'返回顶部图标中留言板链接',
'default' =>'http://www.shuyong.net/guestbook.html',
),

'dulicom' => array(
'type' =>'text',
'name' =>'独立评论id',
'description' =>'必须确保此id下有评论，否则会出错',
'default' =>'532',
),

'zhidao' => array(
'type' =>'text',
'name' =>'博客知道id',
'description' =>'必须确保此id下有评论，否则会出错',
'default' =>'2',
),

'ad' => array(
'type' =>'text',
'multi' => true,
'name' =>'列表页广告',
'default' =>'<script type="text/javascript">var cpro_id = "u1800627";</script><script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script>
',
),

'search' => array(
'type' =>'text',
'multi' => true,
'name' =>'搜索页面右侧广告',
'default' =>'<a href="http://dwz.cn/AGUFt" target="_blank"><img src="http://i2.tietuku.com/c4f5e2d1e5acd85b.jpg"></a>
<script language="javascript" src="http://ads.west263.com/vcp/getJScode/getJScode.asp?ReferenceID=812373&No=300x250"></script>
',
),

);