﻿<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div class="clear"></div>
</div>
<footer> <div class="footer-bottom">
       <div class="foot_box">
	        <div class="foot_box1">                  
<p>☞本站部分文章、资源来自互联网, 版权归原作者及网站所有, 如果侵犯了您的权利, 请及时致信告知我站.</br>
                     ☞本站仅支持IE6以上的浏览器，推荐使用火狐浏览器，推荐在1024x768以上分辨率浏览本站</br>
                     ©Powered by <a href="http://blog.zp520.cn" title="zp520">流年酷</a> 
	                            座右铭：自己选择的路，跪着也要把它爬完！<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_5836978'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s5.cnzz.com/stat.php%3Fid%3D5836978%26show%3Dpic1' type='text/javascript'%3E%3C/script%3E"));</script><a href="http://www.miitbeian.gov.cn/" title="备案">津ICP备14000654号-1</a> </br>
                     © <?php echo date('Y',time())?> Mr.Wenzhen Miao — 始于2014 书写最新文章，翻阅真实回忆丨由<a href="http://www.emlog.net/">Emlog</a>驱动丨<a href="<?php echo BLOG_URL; ?>sitemap.xml" >站点地图</a>"</p>
</div>
<div class="foot_box2">
<p>
日志数量：<?php echo $sta_cache['lognum'];?> 篇</br>
评论数量：<?php echo $sta_cache['comnum_all'];?> 条</br>
碎语数量：<?php echo $sta_cache['twnum'];?> 条</br>
建站日期：2014-03-01</br>
运行时间：<?php echo floor((time()-strtotime("2014-03-01"))/86400); ?> 天</p></div>
<div class="login">	     
<form method="post" action="<?php echo BLOG_URL; ?>admin/index.php?action=login" name="f">
               <ul class="login">
                    <li><label for="log">登陆账号：</label><input type="text" value="" id="user" name="user"></input></li>

                    <li><label for="pwd">登陆密码：</label><input type="password" id="pw" name="pw"></input></li>
                    <li><input type="submit" class="submit1" value="确 定" name="submit">&nbsp; &nbsp;<input type="reset" class="submit2" name="Submit2" value="取 消"><input type="hidden" value="/" name="redirect_to"></li>
               </ul>
         </form>
	</div>
  </div>
</div>
<?php doAction('index_footer'); ?>

</footer>
<a name="gobottom" id="gobottom"></a>
<div class="go">
<a title="返回顶部" class="top" href="#gotop">至顶</a>
<a title="留言评论" class="tocomment" href="?post=2">发表评论</a>
<a title="返回底部" class="bottom" href="#gobottom">至底</a>
</div>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/high.js"></script>
</body>
</html>
<?php include('includes/bulletin.php'); ?>