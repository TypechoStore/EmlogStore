﻿<div class="time">
<script type="text/javascript">
function showLocale(objD)
{
var str,colorhead,colorfoot;
var yy = objD.getYear();
if(yy<1900) yy = yy+1900;
var MM = objD.getMonth()+1;
if(MM<10) MM = '0' + MM;
var dd = objD.getDate();
if(dd<10) dd = '0' + dd;
var hh = objD.getHours();
if(hh<10) hh = '0' + hh;
var mm = objD.getMinutes();
if(mm<10) mm = '0' + mm;
var ss = objD.getSeconds();
if(ss<10) ss = '0' + ss;
var ww = objD.getDay();
if  ( ww==0 )  colorhead="<font color=\"#FF0000\">";
if  ( ww > 0 && ww < 6 )  colorhead="<font color=\"#373737\">";
if  ( ww==6 )  colorhead="<font color=\"#008000\">";
if  (ww==0)  ww="星期日";
if  (ww==1)  ww="星期一";
if  (ww==2)  ww="星期二";
if  (ww==3)  ww="星期三";
if  (ww==4)  ww="星期四";
if  (ww==5)  ww="星期五";
if  (ww==6)  ww="星期六";
colorfoot="</font>"
str = colorhead + yy + "-" + MM + "-" + dd + " " + hh + ":" + mm + ":" + ss + "  " + ww + colorfoot;
return(str);
}
function tick()
{
var today;
today = new Date();
document.getElementById("www_zzjs_net").innerHTML = showLocale(today);
window.setTimeout("tick()", 1000);
}
tick();
</script></p>
<script language="JavaScript">
document.write("<table bgcolor=00FF00>"+"<font size=2 color=0000FF><br>")
var now=new Date()
var hr
hr=now.getHours()
if (hr==0)
{document.write("午夜 12 点多了，晚安!明天早些起床哦!!")}
if (hr==1)
{document.write("嗯!午夜 1 点多了，还在干什么啊?")}
if (hr==2)
{document.write("午夜 2 点多了，是不是该睡觉了?")}
if (hr==3)
{document.write("已经午夜 3 点多了，还不睡！小心变熊猫!")}
if (hr==4)
{document.write("呵!凌晨 4 点了!您是一夜未睡还是刚起床呀?")}
if (hr==5)
{document.write("早安啊!清晨 5 点了!您这么早起床有事吗?")}
if (hr==6)
{document.write("早安!清晨 6 点了!您已经准备要刷牙洗脸了?")}
if (hr==7)
{document.write("早啊! 早上 7 点了!您准备要去上班或上课了吗?")}
if (hr==8)
{document.write("OH!早上 8 点了!早餐吃了沒呀?已经开始上班了吗?")}
if (hr==9)
{document.write("早上 9 点了!嘿嘿嘿!這时上网好像快一点喔!")}
if (hr==10)
{document.write("现在是上午 10 点了!悃吗?")}
if (hr==11)
{document.write("上午 11 点了!肚子饿了吧 , 再忍耐一下，就快午休了")}
if (hr==12)
{document.write("午安!中午 12 点了!吃饭去吧!")}
if (hr==13)
{document.write("现在在是下午 1 点了!想不想要睡个午觉呀?")}
if (hr==14)
{document.write("下午 2 点了!不要边打瞌睡边流口水哦!")}
if (hr==15)
{document.write("哈!下午 3 点了!刚上班吗?")}
if (hr==16)
{document.write("下午 4 点了!再忍一下...就快下班了!")}
if (hr==17)
{document.write("下午 5 点!准备好下班了吗?")}
if (hr==18)
{document.write("已经傍晚 6 点了!先去吃个饭吧!")}
if (hr==19)
{document.write("晚上 7 点了!吃饭了吗?不要虐待自己喔!")}
if (hr==20)
{document.write("晚安!现在是 8 点了!看完新闻，看看书吧?")}
if (hr==21)
{document.write("嗨!晚上 9 点了!上网的好时光!")}
if (hr==22)
{document.write("嗯!现在是晚上 10 点了!在做什么啦?")}
if (hr==23)
{document.write("哇!已经晚上 11 点多了!又是一天过去了，准备上床睡觉了!")}
document.write("</font></font></table></center>")
</script>
</span> 
</div>