﻿<?php
/*
Template Name:流年、酷™
Description:炫酷淡色系模板
Author:zzhen
Author Url:http://www.zp520.cn
Sidebar Amount:1
ForEmlog:5.2.x-5.3.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once (View::getView('module'));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Page-Enter" content="RevealTrans (Duration=3, Transition=23)">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<SCRIPT language=JavaScript src="<?php echo BLOG_URL; ?>js/photo.js"></SCRIPT>
<title><?php echo $site_title; ?> </title>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="<?php echo TEMPLATE_URL; ?>images/favicon.ico" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<!--[if lt IE 7]>
<div style='border: 1px solid #F7941D; background: #FEEFDA; text-align: center; clear: both; height: 20px; position: relative;'>
<div style='width:auto; hight:auto; color:red; text-align: center; font-size: 14px; font-weight: bold; line-height: 2em;'>温馨提示：您的IE版本过低，建议您升级浏览器。 <strong style='color:#0099FF;'>建议浏览器：</strong>  <strong style='padding-right: 10px;padding-left: 10px;'>[<a style='color: #0099FF;text-decoration: underline; 'http://www.firefox.com.cn/download/' target='_blank'>火狐</a>]</strong>  <strong style='padding-right: 10px;padding-left: 10px;'>[<a style='color: #0099FF;text-decoration: underline; href='http://ie.sogou.com/' target='_blank'>搜狗</a>]</strong><a style='color:#000' href='#' onclick='javascript:this.parentNode.parentNode.style.display="none"; return false;'>关闭提示</a></div>
</div>
</div>
<![endif]-->
<script type="text/javascript" language="javascript">
	function showSubLevel(Obj){
		Obj.className="hover";
	}
	function hideSubLevel(Obj){
		Obj.className="";
	}
</script>
<script src="<?php echo TEMPLATE_URL; ?>js/jquery-latest.js"></script>
</head>
<body>
<div id="circle1-box">
    <div id="circle1"></div>
    <div id="circle11"></div>
</div>
<script type="text/javascript">
    $(window).load(function() {    
        $("#circle1").fadeOut(500);
        $("#circle11").fadeOut(700);
        $("#circle1-box").fadeOut(700);
    });
</script>
<a name="gotop" id="gotop"></a>
<div id="na">
    <div id="naBar">
     <div class="topna"><ul>
<li><a href="javascript:void(0)" onclick="SetHome(this,window.location)">设为首页</a></li>
<li><a href="javascript:void(0)" onclick="shoucang(document.title,window.location)">加入收藏</a></li> 
</ul>
</div>
			<!-- end: left_top --> 
			<div id="naLink">
        <ul>
          <li><a href="<?php echo BLOG_URL; ?>rss.php" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/navLink/icon-rss.gif" alt="欢迎订阅本博客!" title="欢迎订阅本博客!" width="21" height="21" /></a></li>
          <li><a href="http://weibo.com/271055334" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/navLink/ioc-weibo.png" alt="新浪微博 求围观!" title="新浪微博 求围观!" width="21" height="21" /></a></li>
           <li><a href="http://1.t.qq.com/mwz747512353" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/navLink/icon-tqq.gif" alt="腾讯微博 求围观!" title="腾讯微博 求围观!" width="21" height="21" /></a></li>
        <li><a href="http://sighttp.qq.com/authd?IDKEY=9f485e38024eaac7f87ac41d6aa70dc9c152a2a58d590a4b" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/navLink/ioc-qq.png" alt="点此和我QQ交谈!" title="点此和我QQ交谈!" width="21" height="21" /></a></li>
          <li><a target="_blank" href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=LE1IQUVCbFZcGR4cAk9C" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/navLink/icon-email.gif" alt="发邮件给我吧!" title="发邮件给我吧!" width="21" height="21" /></a></li>
        </ul>
      </div>
      </div>
		</div>	
		<div class="header_c">
			<h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?>&trade;</a><br/><span  class="blog-title"><?php echo $bloginfo; ?></span ></h1>
			<div class="login_t"></div>
			<?php include('includes/time.php'); ?>
		</div>
		<div class="clear"></div>
		<!-- end: header_c -->
</div>	
<div class="menu-one"><div id="menu">
   <?php blog_navi();?>
	<div class="s_bar">
				<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>">
					<input type="text" size="30"  name="keyword" class="search"/>
				</form>
		</div>
        </div></div>
<div class="clear"></div>
<div class="main">



