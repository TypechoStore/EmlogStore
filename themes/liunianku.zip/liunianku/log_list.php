﻿
<style>
.jc{
position:relative;

</style>

<script language="JavaScript">
var ns6=document.getElementById && !document.all
var ie=document.all
var customcollect=new Array()
var i=0
function jiggleit(num){
if ((!document.all && !document.getElementById)) return;
customcollect[num].style.left=(parseInt(customcollect[num].style.left)==-1)? customcollect[num].style.left=1 : customcollect[num].style.left=-1
}

function init(){
if (ie){
while (eval("document.all.jiggle"+i)!=null){
customcollect[i]= eval("document.all.jiggle"+i)
i++
} 
}
else if (ns6){
while (document.getElementById("jiggle"+i)!=null){
customcollect[i]= document.getElementById("jiggle"+i)
i++
}
}

if (customcollect.length==1)
setInterval("jiggleit(0)",80)
else if (customcollect.length>1)
for (y=0;y<customcollect.length;y++){
var tempvariable='setInterval("jiggleit('+y+')",'+'100)'
eval(tempvariable)
}
}

window.onload=init;
$(function(){
$("#content ul li").hover(function(){$(this).css({'border-left':'3px solid red'})},function(){$(this).css({'border-left':'1px solid #d8d8d8'})});
</script>
<?php
/*
Template Name:流年、酷™
Description:炫酷淡色系模板
Author:zzhen
Author Url:http://www.zp520.cn
Sidebar Amount:1
ForEmlog:5.2.x-5.3.0
*/
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="content">

   <div id="position">
    	<div id="position_l">
<?php if ($params[1]=='sort'){ ?>
			当前位置： 分类 <b><?php echo $sortName; ?></b> 下的文章
<?php }elseif ($params[1]=='tag'){ ?>
			当前位置： 包含标签 <b><?php echo urldecode($params[2]);?></b> 的文章
<?php }elseif($params[1]=='author'){ ?>
			当前位置： 作者 <b><?php echo blog_author($author);?></b> 的文章
<?php }elseif($params[1]=='keyword'){ ?>
            当前位置： 关键词 <b><?php echo urldecode($params[2]);?></b> 的搜索结果
<?php }elseif($params[1]=='record'){ ?>
           当前位置： 发表在 <b><?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?> </b>的文章
				<?php }else{?><img src="<?php echo BLOG_URL; ?>content/templates/simpleone/images/bulletin.gif"><span id="jiggle0" class="jc"><b>欢迎光临本站，有任何建议欢迎大家留言。</b><b color="red">留言版正在更新中……很期待</b></span><?php }?>
			</div>
            </div> 
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?> 
    	<div class="clear"></div>
<ul>

	<li>
	<h2 class="content_h2">
	<?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
	</h2>
	<div class="editor"><?php editflg($value['logid'],$value['author']); ?></div>
    <div class="clear"></div>
   	<div class="thumbnail_box">
							<div class="thumbnail">
								<?php if(pic_thumb($value['content'])){
						$imgsrc = pic_thumb($value['content']);
					}else
						$imgsrc = TEMPLATE_URL.'images/random/tb'.rand(1,20).'.jpg';
					?>
						<a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><img src="<?php echo $imgsrc; ?>" width="140" height="100"/></a>
							</div>
						</div> 	
  <div class="post">
    <?php echo subString(strip_tags($value['log_description']),0,190,"..."); ?></div>
    <div class="clear"></div>
	<div class="ge"></div>
  <div class="postact">
     &nbsp;作者：<?php blog_author($value['author']); ?>&nbsp;|&nbsp; 时间：<?php echo date('Y-n-j ', $value['date']); ?>&nbsp;|&nbsp;
	评论：<a  href="<?php echo $value['log_url']; ?>#comment"><?php echo $value['comnum']; ?>条</a>&nbsp;|&nbsp;
	引用:<a  href="<?php echo $value['log_url']; ?>#tb"><?php echo $value['tbcount']; ?>次</a> &nbsp;|&nbsp;
	浏览：<a href="<?php echo $value['log_url']; ?>"><?php echo $value['views']; ?>次</a>&nbsp;|&nbsp;
    <?php blog_tag($value['logid']); ?>
	</div>
	
	</li>
<?php endforeach; ?>
</ul>
<div id="pagenavi">
<span>共<?php echo ceil($sta_cache['lognum']/$index_lognum);?>页</span>
	<?php echo $page_url;?>
</div>
</div>
<!--end content-->
<?php
 include View::getView('side');
 include View::getView('footer'); 
?>