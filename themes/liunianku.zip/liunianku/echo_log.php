﻿<?php 
/*
* 日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="content">
<ul>
<li>
	<h2 class="content_h3"><?php topflg($top); ?><?php echo $log_title; ?></h2>
	<div class="editor"><?php editflg($logid,$author); ?></div>
    <div class="ge1"></div>
    <div class="postact1">&nbsp;作者：<?php blog_author($author); ?>&nbsp;|&nbsp;
    日期：<?php echo gmdate('Y-n-j H:i', $date); ?>&nbsp;|&nbsp;
    阅读：<?php echo $views; ?>次&nbsp;|&nbsp;
    评论：<a href="#respond"><?php echo $comnum; ?>人</a>&nbsp;|&nbsp;
    分类：<?php blog_sort($logid); ?>
    </div>
	<div class="post2">
	<?php echo $log_content; ?></div>
	<div class="fujian"><?php blog_att($logid); ?></div>
	<?php doAction('log_related', $logData); ?>
 <div class="content-footer">
 <!-- Baidu Button BEGIN -->
<div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
<a class="bds_tsina"></a>
<a class="bds_qzone"></a>
<a class="bds_tqq"></a>
<a class="bds_renren"></a>
<a class="bds_t163"></a>
<a class="bds_fx"></a>
<a class="bds_kaixin001"></a>
<a class="bds_tsohu"></a>
<a class="bds_ty"></a>
<a class="bds_tfh"></a>
<a class="bds_xg"></a>
<a class="bds_mail"></a>
<a class="bds_print"></a>
<a class="bds_copy"></a>
<span class="bds_more"></span>
<a class="shareCount"></a>
</div>
<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=0" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
</script>
<!-- Baidu Button END -->
</br></br>
       <?php blog_tag($logid); ?>
      </br>
       相邻文章：<?php neighbor_log($neighborLog); ?>
该日志于&nbsp;<?php echo gmdate('Y-n-j H:i', $date); ?>&nbsp;由&nbsp;<?php blog_author($author); ?>&nbsp;发表在&nbsp;<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>&nbsp;网站上，你除了可以发表评论外，还可以转载"<?php echo $log_title;?>"日志到你的网站或博客，但是请保留源地址及作者信息，谢谢!!（尊重他人劳动，你我共同努力）</br> 
      </div>
    <?php blog_comments($comments,$params); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);?>
    
</li>
</ul>
</div>
<!--end content-->
<?php 
include View::getView('side');
include View::getView('footer'); 
?>