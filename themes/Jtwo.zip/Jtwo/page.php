<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="v9-article">
<h1 class="v9-group-post-title"><?php topflg($top); ?><?php echo $log_title; ?></h1>
	<div class="v9-post-content clearfix">
	    <div class="topic-content">
	        <?php echo $log_content; ?>
	    </div>
	</div>
	<?php blog_comments($comments,$comnum); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>