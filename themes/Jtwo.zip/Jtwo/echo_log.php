<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="v9-article">
<h1 class="v9-group-post-title"><?php topflg($top); ?><?php echo $log_title; ?></h1>
	<div class="v9-post-content clearfix">
	<div class="topic-doc">
	<h3><p class="date"><?php echo gmdate('Y-n-j', $date); ?>  <?php blog_author($author); ?> <?php blog_sort($logid); ?> <?php editflg($logid,$author); ?></p></h3>
	<div id="link-report" class="">
	<div class="topic-content">
	<?php echo $log_content; ?>
    <?php doAction('log_related', $logData); ?>
	</div></div>
	<div class="v9-post-op"><?php blog_tag($logid); ?></div>
	<?php doAction('log_related', $logData); ?>
	</div></div>
    <div class="tabs" id="reviews">
	<a href="#recomment" class="on" style="color:#999;">回应</a>
	</div>
	<?php blog_comments($comments,$comnum); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
<!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>