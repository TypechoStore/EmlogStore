<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="v9-article">
<?php doAction('index_loglist_top'); ?>
<div class="v9-article-listshow clearfix">
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
<div class="v9-quan-item">
	<div class="likes">
   		<a href="<?php echo $value['log_url']; ?>#comments" style="color:#CA6445;"><?php echo $value['comnum']; ?><br>回应</a>
    </div>
	<div class="bd">
		<h3>
        <a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
        </h3>
		<div class="v9-quan-source">
		<span class="from">作者 <?php blog_author($value['author']); ?><a><img class="v9-pro-expert" src="<?php echo TEMPLATE_URL; ?>images/rz.png"></a>，发布于 <?php echo gmdate('Y-n-j', $value['date']); ?> <?php blog_tag($value['logid']); ?>  <?php editflg($value['logid'],$value['author']); ?></span>
							  </div>
							  <div class="v9-quan-infos clearfix">						<?php 
		preg_match_all("|<img[^>
						]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
		$rand_img = TEMPLATE_URL.'images/random/tb'.rand(1,20).'.jpg';
		$imgsrc = !empty($img[1]) ? $img[1][0] : $rand_img;
	?>
								<p>
								</p><p style="FLOAT: left"><a href="<?php echo $value['log_url']; ?>"><img width="140px" height="100px" src="<?php echo $imgsrc; ?>" alt="<?php echo $value['log_title']; ?>
						" title="<?php echo $value['log_title']; ?>
						" /></a></p><p style="MARGIN-LEFT: 150px"><?php echo subString(strip_tags($value['content']),0,170,"..."); ?></p>								<p></p>
							  </div>
							  <p class="more"><a href="<?php echo $value['log_url']; ?>">查看全文 »</a></p>
  </div>
						 </div>
<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
<div class="v9-page">
 <div id="pages" class="pages">
<?php echo $page_url;?>
 </div>
</div>
</div><!-- end #contentleft-->
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>