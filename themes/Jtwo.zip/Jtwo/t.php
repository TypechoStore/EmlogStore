<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="v9-article">
<div id="tw">
<div id="v9newpost" class="hotmod" style="display: block;">
    <ul>
    <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?> 
    <li>
    <h3 class="v9-aside-h3 clearfix" style="color:#337FE5;"><?php echo $author; ?><span class="side-title-txt"><?php echo $val['date'];?></span></h3><?php echo $val['t'].'<br/>'.$img;?>
    </li>
    <?php endforeach;?>
<div class="v9-page">
<div id="pages" class="pages">
<?php echo $pageurl;?></div></div>
    </ul>
    </div>
</div><!--end #tw-->
</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>