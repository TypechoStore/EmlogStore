<?php
/*
Template Name:Jtwo-仿360站长社区群
Description:简洁优雅，仿360站长社区群 原地址http://webscan.360.cn/group
Version:1.0
Author:刘培杰
Author Url:http://azt-lmt.com
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<!--[if IE 6]>
<script src="<?php echo TEMPLATE_URL; ?>iefix.js" type="text/javascript"></script>
<![endif]-->
<style>
.Bar{ position: relative; width: 150px;    /* 宽度 */ /*border: 1px solid #B1D632; padding: 1px;*/ background-color:#999 ; display:inline-block}
.Bar div{ display: block; position: relative; background:#68a64c;/* 进度条背景颜色 */ color: #333333; height: 15px; /* 高度 */ line-height: 15px;  /* 必须和高度一致，文本才能垂直居中 */ }
.Bars div{ background:#090}
.Bar div span{ position: absolute; width: 150px; /* 宽度 */ text-align: center; font-weight: bold; }

.add_points_tips{position:absolute;background: none repeat scroll 0 0 #FFFFD7;border: 1px solid #EEC197;border-radius: 5px 5px 5px 5px; height:50px; width:180px; z-index:1000; line-height:40px; height:40px; left:50px; display:none; font-size:16px; font-weight:bold; text-align:center; color:#333;z-index:2000}
</style>
<script async="" src="<?php echo TEMPLATE_URL; ?>js/analytics.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/foucsbox.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.idTabs.min.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.pinwheel-0.1.0.js"></script>
<script type="text/javascript">
$(function(){
	$(".v9-aside-hotmod li").hover(function(){
		$(".v9-aside-hotmod li").removeClass("curr");
		$(this).addClass("curr");
		var showid = $(this).attr("id")+"s";
		$(".v9-aside-homenewmod .hotmod").hide();
		$("#"+showid).show();	
	})
	$("#v9topnewtopic ul").idTabs(); 
	$('.loading_userpro').pinwheel();
	$('#refreshexpt').click(function(){ 
		var i = $(this).attr("myAttr");
		$.ajax({  	
			url : "/group/moreexpt",
			type: "GET",
			data:"i="+i,
			success: function(data){
				$("#v9-aside-hotmod-55").html(data);
				i = parseInt(i)+1;
				$('#refreshexpt').attr('myAttr',i);
			}
		});
	});
	$('#refreshgroup').click(function(){ 
		var i = $(this).attr("mygro");
		$.ajax({  	
			url : "/group/moregro",
			type: "GET",
			data:"i="+i,
			success: function(data){
				i = parseInt(i)+1;
				$('#v9-aside-hotmod-3').html(data);
				$('#refreshgroup').attr('mygro',i);
			}
		});
	});

});
</script>
<?php doAction('index_head'); ?>
</head>
<body>

<div id="v9-warp">
	<div id="v9-header">
		<div class="v9-header-wrap clearfix">
			<div class="v9-logo">
				<a href="<?php echo BLOG_URL; ?>" title="<?php echo $bloginfo; ?>"></a>
				<span class="sologon"><?php echo $bloginfo; ?></span>
			</div>
		</div>
	</div>
	<div class="v9-qun-menu clearfix">
		<?php blog_navi();?>
	</div>
<div class="v9-container clearfix">
<div class="v9-quan-wrap">