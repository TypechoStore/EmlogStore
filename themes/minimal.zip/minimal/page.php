<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content-container" class="clearfix">
<ul class="double-cloumn clearfix">
<li id="left-column">
	<ul class="blog-main-post-container">
		<li class="post type-post status-publish format-standard hentry category-design category-knowledge post clearfix">
			<div class="content clearfix">
				<div class="post-title-block">
					<h2 class="post-title typography-title">
						<?php echo $log_title; ?>
					</h2>
					<h4 class="author-meta">Posted by <?php blog_author($author); ?></h4>
				</div>
					<?php echo $log_content; ?>
			</div>
			<div class="post-meta">
			</div>
			
		</li>
	</ul>
	
	<div id="comments" class="comments-area">
		<?php blog_comments($comments); ?>
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
</li><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>