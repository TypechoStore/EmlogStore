<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content-container" class="clearfix">
<ul class="double-cloumn clearfix">
<li id="left-column">
	<ul class="blog-main-post-container">
		<?php doAction('index_loglist_top'); ?>
		<?php foreach($logs as $value): ?>
			<li class="post type-post status-publish format-standard hentry category-design category-knowledge post clearfix">
				<div class="content clearfix">
					<div class="post-title-block">
						<h5 class="dater">
							<span><?php echo gmdate('j M', $value['date']); ?> </span>
							<span><?php echo gmdate('Y', $value['date']); ?> </span>
						</h5>
						<h2 class="post-title typography-title">
							<?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a><br/><div> <?php blog_sort($value['logid']); ?></div>
						</h2>
					</div>
					<?php echo $value['log_description']; ?>
				</div>
				
				<div class="post-meta">
					<div class="social">
						<a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a>
						<a href="<?php echo $value['log_url']; ?>#tb">引用(<?php echo $value['tbcount']; ?>)</a>
						<a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a>
					</div>
					<div class="about">
						<p class="tags">
							<?php blog_tag($value['logid']); ?>
						</p>
					</div>
				</div>
				<div style="clear:both;"></div>
			</li>
		<?php endforeach; ?>
	</ul>
<div id="pagenavi">
	<?php echo $page_url;?>
</div>

</li><!-- end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>