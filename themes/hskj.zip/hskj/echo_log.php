<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div class="post-content">

<!--正文输出开始-->
 <div class="post-content">
				<div id="post-523" class="article">
				<div class="single_info">
				<h2>
				<?php topflg($top); ?><?php echo $log_title; ?>				</h2>
				<div class="article_info1">
				<span class="author">作者：<?php blog_author($author); ?></span> | 
				<span>时间：<?php echo gmdate('Y-n-j G:i l', $date); ?></span> |
				<span class="category">分类：<?php blog_sort($logid); ?> |
				<span class="post_view"> <?php echo $views; ?> 次阅读</span>

				</div></div><div class="clr"></div>
			
			<div class="entry">

						<p><?php echo $log_content; ?></p>
			</div>
			<div class="context_box">
				<li>   该日志由  <?php blog_author($author); ?>  于<?php echo gmdate('Y-n-j G:i l', $date); ?>发表在 <?php blog_sort($logid); ?> 分类下，
								你可以<a href="#respond">发表评论</a>，并在保留原文地址
				及作者的情况下引用到你的网站或博客。
				</li>
				<li>本文链接: <a title="本文固定链接" rel="bookmark" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
 ?>"><?php echo $log_title; ?></a></li>
				<li>文章标签: <?php blog_tag($logid); ?>
				<li>版权所有: <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>-转载请标明出处</li>
</div><div class="clr"></div>			
					<div class="article_page">
	  <?php neighbor_log($neighborLog); ?></div>
	  		<div class="relatedposts">
<?php doAction('log_related', $logData); ?> <!--相关日志挂载点-->		
		</div>


<div class="comment-box">
<?php blog_comments($comments,$params); ?> 
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?> 

</div>
		<div class="clr"></div>
	  
		</div>
		</div>
<!--正文输出结束-->

</div>
<!--侧边栏开始-->
<?php
 include View::getView('side');
?>
<!--侧边栏结束-->
<?php
 include View::getView('footer');
?>
