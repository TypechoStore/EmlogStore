<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php if($pageurl == Url::logPage()){ ?>
<?php include View::getView('index'); ?>
<?php }else{ ?>
<div id="content">
<div class="post-content">
<!--日志循环输出开始-->	     		 	 
 <?php if (!empty($logs)):foreach($logs as $value): ?>
<div id="post-523" class="article">
			<div style="position:relative;width:100%">
				<div class="pre-cat">
					<div class="pre-catinner"><?php blog_sort($value['logid']); ?></div>
					<div class="pre-catarrow"></div>
				</div>				
				<h2>				<a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
				</h2><div class="entry-commentnumber"> <span class="number">
          <?php echo $value['comnum']; ?>          </span> <span class="corner"></span> </div>
			</div>
			<div class="article_info">
				<span class="date"><?php echo gmdate('Y-n-j G:i l', $value['date']); ?></span> |
				<span class="author"><?php blog_author($value['author']); ?></span> |
				<span class="post_view"> <?php echo $value['views']; ?> 次阅读</span> |
				<span class="tags"><?php blog_tag($value['logid']); ?></span>
			</div><div class="clr"></div>
			
<div class="entry">
						<div class="thumbnail">
<?php
 //拉取附件第一张图片，如果没有，则随机拉取random文件夹图片，图片名称任意
$thum_src = getThumbnail($value['logid']);
 $imgFileArray = glob("content/templates/hskj/images/random/*.*");
 if(!empty($thum_src)){ ?>
 <img width="140" height="100" src="<?php echo $thum_src; ?>" alt="<?php echo $value['log_title']; ?>" title="<?php echo $value['log_title'] ?>" />
<?php
 }else{
 ?>
 <img width="140" height="100" src="<?php echo $imgFileArray[array_rand($imgFileArray)]; ?>" alt="<?php echo $value['log_title']; ?>" title="<?php echo $value['log_title'] ?>" />
 <?php
 }
 ?>
</div>
	<p><?php echo subString(strip_tags($value['log_description']),0,170,"..."); ?></p>
			</div>		
			
		</div>     
     	     		 	 
	      <?php endforeach;else:?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
   <?php endif;?>
	     	<div class="clr"></div> 
<!--日志循环输出结束-->	     		 	 
		<div id="postnavigation">   
   			<div class="page_navi"><?php echo $page_url;?> </div>  
        </div>
		</div>
<?php
 include View::getView('side');
?>
<?php } ?>
<?php
 include View::getView('footer');
?>
