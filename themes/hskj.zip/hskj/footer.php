<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="clr"></div>
		<div id="footer">
		<div class="footbg">
		<div class="footbg">
		<span>Copyright &copy; 2013  Sanzi保留所有权利.
       </span><br>
	   Theme By 陈子文移植自Sanzi. Powered By <a rel="nofollow" target="_blank" href="http://www.emlog.net/">emlog</a>.
		<?php echo $footer_info; ?>	<?php doAction('index_footer'); ?>
		</div>
		</div>
	
	</div>
</div>
<!-- 返回顶部 -->
<div style="display: none;" id="gotop"></div>
<!-- 返回顶部END -->


<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/js/jquery-1.9.0.min.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/js/sanzi.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/js/prettify.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/js/prettify.min.js"></script>
<script type="text/javascript">
window.onload = function(){prettyPrint();};
</script>

 
<script type="text/javascript">
	$(document).ready(function() {
		$(".fancybox").fancybox();
	});
</script>
 <!--[if ie 6]>
	<script src="http://letskillie6.googlecode.com/svn/trunk/letskillie6.zh_TW.pack.js"></script>
<![endif]-->
</body>
</html>