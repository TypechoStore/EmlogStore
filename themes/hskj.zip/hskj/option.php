<?php 
/**
模板配置文件
* */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
	// 设置
// 首页右上角链接设置//
	$sortid_01 = '主题';  $sortid_02 = 'http://vps.lantk.com/?post=75'; // 右上角链接1名称 // //右上角链接1链接地址 //
	$sortid_03 = '归档';  $sortid_04 = '?plugin=archiver'; // 右上角链接2名称 // //右上角链接2链接地址 //
	$sortid_05 = '留言';  $sortid_06 = 'http://vps.lantk.com/?post=1'; // 右上角链接3名称 ////右上角链接3链接地址 //
	$sortid_07 = '管理';  $sortid_08 = 'admin'; // 右上角链接4名称 // //右上角链接4链接地址 //
	
// 首页订阅按钮，可自行更改//	
	$get_slideshow_num = '订阅RSS';  $get_newlog_num = 'rss.php'; // 按钮1名称与链接
	$sort_log_num = '订阅到邮箱'; $imgnum = 'http://list.qq.com/cgi-bin/qf_invite?id=c6da20ef5a2d00dbaf22850d22d7ffdc63fb85f59266ef77'; // 按钮2名称与链接
	
 // 首页全局设置
    $emailid = '1';	//首页置顶图文调用数量
	$islogo = '又一个EMLOG主题，移植自Sanzi博客，经过小编改版了一下，更改了首页显示模式，整体来说是个不错的主题，类似CMS却又并非CMS，主题命名为“newgavin”.这将是它的第一个版本'; // 博客首页公告
	$admin_link = 'http://vps.lantk.com'; // 首页公告链接

//侧边栏设置
	$admin_twitter ='欢迎光临 Welcome To My Blog!'; // 侧边栏欢迎语
	$admin_gg = 'http://vps.lantk.com/content/templates/hskj/images/screenshot.png'; // 侧边栏广告图片地址
	$admin_sina_weibo = 'http://vps.lantk.com/?post=71'; // 侧边栏广告图片链接地址

//评论等级输出设置说明
//请打开module.php找到第11~32行自行修改！！

?>

