<?php 
/*
* 首页
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<?php doAction('index_loglist_top'); ?>	
<div class="post-content">
<!--置顶图文开始-->         		 	 
<?php index_show($emailid);?>  
     	     	<!--置顶图文结束-->         		 		  
							  <!--首页公告开始-->
							  <div id="post-525" class="article">
<a title="首页公告" rel="external" href="<?php echo $admin_link; ?>" class="status-link clearfix">
 <span class="status-cat">公告</span> <span class="status-img">
 <?php global $CACHE;$user_cache = $CACHE->readCache('user');$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?><?php if (!empty($user_cache[1]['photo']['src'])): ?> 
  <img width="80" height="80" src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>"alt="blogger" />
  <?php endif;?></span>
<div class="status-entry"><p class="status-post">
<?php echo $islogo; ?></p></div>
</a>
</div>  
<!--首页公告结束->
<!--日志循环输出开始-->	     		 	 
 <?php if (!empty($logs)):foreach($logs as $value): ?>
<div id="post-523" class="article">
			<div style="position:relative;width:100%">
				<div class="pre-cat">
					<div class="pre-catinner"><?php blog_sort($value['logid']); ?></div>
					<div class="pre-catarrow"></div>
				</div>				
				<h2>				
	                       <a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
				</h2>
	<div class="entry-commentnumber"> 
	   <span class="number">
             <?php echo $value['comnum']; ?>          
         </span>
      </div>
			</div>
			<div class="article_info">
				<span class="date"><?php echo gmdate('Y-n-j G:i l', $value['date']); ?></span> |
				<span class="author"><?php blog_author($value['author']); ?></span> |
				<span class="post_view"> <?php echo $value['views']; ?> 次阅读</span> |
				<span class="tags"><?php blog_tag($value['logid']); ?></span>
			</div><div class="clr"></div>
</div>     
	      <?php endforeach;else:?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
   <?php endif;?>
	     	<div class="clr"></div> 
<!--日志循环输出结束-->	     		 	 
		<!--载入翻页按钮-->
		<div id="postnavigation">   
   			<div class="page_navi"><?php echo $page_url;?> </div>  
        </div>
		</div>
			<!--载入翻页按钮结束-->
<!--载入侧边栏-->
<?php
 include View::getView('side');
?>