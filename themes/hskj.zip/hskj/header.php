<?php
/*
Template Name:黑色空间
Description:移植自三子博客 ……
Version:1.2
Author:陈子文
Author Url:http://vps.lantk.com
Sidebar Amount:1
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
require_once View::getView('option');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!--忽略因找不到JS对象所产生的网页错误-->
<script language="JavaScript">
<!-- Hide
function killErrors() {
return true;
}
window.onerror = killErrors;
// -->
</script> 
<!--忽略因找不到JS对象所产生的网页错误结束-->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<!--高亮代码-->
<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>

<body>
<div id="page">
	<div id="header">
		<div class="header-left">
		
		<a rel="home" title="<?php echo $blogname; ?>" href="<?php echo BLOG_URL; ?>">
		<img alt="<?php echo $blogname; ?>" src="<?php echo TEMPLATE_URL; ?>images/logo.png">
		
		</div>

			<div class="topnav">	
			<ul class="menu" id="nav">
			<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-114" id="menu-item-114"><a href="<?php echo $sortid_08; ?>"><?php echo $sortid_07; ?></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-113" id="menu-item-113"><a href="<?php echo $sortid_06; ?>"><?php echo $sortid_05; ?></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-116" id="menu-item-116"><a href="<?php echo $sortid_04; ?>"><?php echo $sortid_03; ?></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-515" id="menu-item-515"><a href="<?php echo $sortid_02; ?>"><?php echo $sortid_01; ?></a></li>
</ul>			</div>
			
			
			
			
			<div class="topcom">	
			<li class="topcomred"><a title="<?php echo $get_slideshow_num; ?>" rel="nofollow" target="_blank" href="<?php echo $get_newlog_num; ?>"><?php echo $get_slideshow_num; ?></a></li>
			<li class="topcomblue"> <a title="<? echo $sort_log_num; ?>" rel="nofollow" target="_blank" href="<?php echo $imgnum; ?>"><? echo $sort_log_num; ?></a></li>
			</div>
				
			<div class="nav">		
		<?php blog_navi();?>
			<div id="search">		
				<form action="<?php echo BLOG_URL; ?>index.php" method="get" id="searchform">
				<input type="text" value="没事别点我,节约资源.." name="keyword" class="s" onfocus="if (this.value == '没事别点我,节约资源..') {this.value = '';}" onblur="if (this.value == '') {this.value = '没事别点我,节约资源..';}" x-webkit-speech="">
				<button type="submit">搜索</button>
				</form>
			</div>
		</div> <div class="clr"></div> 
	</div>