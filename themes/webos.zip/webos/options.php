<?php
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
 'ull' => array(
		'type' => 'tag',
		'name' => '这里填写的所有都是设置桌面图标的',
		'description' => '
					默认有十个图标可以设置，如果标题为“一个emlog新模板”则无图标',
        ),
'ico1_url' => array(
		'type' => 'text',
		'name' => '链接地址',
		'description' => '填写链接',
		'default' => 'http://douban.fm/partner/qq_plus',
        ),
'ico1_title' => array(
		'type' => 'text',
		'name' => '标题',
		'description' => '填写标题',
		'default' => '豆瓣FIM',
        ),
'ico1_image' => array(
		'type' => 'image',
		'name' => '图片',
		'values' => array(
            TEMPLATE_URL . 'icon/icon7.png',
        ),
	),  

'ico2_url' => array(
		'type' => 'text',
		'name' => '链接地址',
		'description' => '填写链接',
		'default' => 'http://www.letv.com/cooperation/qq.html',
        ),
'ico2_title' => array(
		'type' => 'text',
		'name' => '标题',
		'description' => '填写标题',
		'default' => '乐视网',
        ),
'ico2_image' => array(
		'type' => 'image',
		'name' => '图片',
		'values' => array(
            TEMPLATE_URL . 'icon/icon4.png',
        ),
	), 


'ico3_url' => array(
		'type' => 'text',
		'name' => '链接地址',
		'description' => '填写链接',
		'default' => 'http://www.qianqian.com/paihang.html',
        ),
'ico3_title' => array(
		'type' => 'text',
		'name' => '标题',
		'description' => '填写标题',
		'default' => '千千音乐',
        ),
'ico3_image' => array(
		'type' => 'image',
		'name' => '图片',
		'values' => array(
            TEMPLATE_URL . 'icon/icon5.png',
        ),
	), 


'ico4_url' => array(
		'type' => 'text',
		'name' => '链接地址',
		'description' => '填写链接',
		'default' => 'http://www.manmankan.com/',
        ),
'ico4_title' => array(
		'type' => 'text',
		'name' => '标题',
		'description' => '填写标题',
		'default' => '火影忍者漫画动画',
        ),
'ico4_image' => array(
		'type' => 'image',
		'name' => '图片',
		'values' => array(
            TEMPLATE_URL . 'icon/icon20.png',
        ),
	), 


'ico5_url' => array(
		'type' => 'text',
		'name' => '链接地址',
		'description' => '填写链接',
		'default' => 'http://www.mathrs.net/',
        ),
'ico5_title' => array(
		'type' => 'text',
		'name' => '标题',
		'description' => '填写标题',
		'default' => '中国数学资源网',
        ),
'ico5_image' => array(
		'type' => 'image',
		'name' => '图片',
		'values' => array(
            TEMPLATE_URL . 'icon/icon21.png',
        ),
	), 


'ico6_url' => array(
		'type' => 'text',
		'name' => '链接地址',
		'description' => '填写链接',
		'default' => 'http://blog.yesfree.pw',
        ),
'ico6_title' => array(
		'type' => 'text',
		'name' => '标题',
		'description' => '填写标题',
		'default' => '一个emlog新模板',
        ),
'ico6_image' => array(
		'type' => 'image',
		'name' => '图片',
		'values' => array(
            TEMPLATE_URL . 'icon/icon7.png',
        ),
	), 


'ico7_url' => array(
		'type' => 'text',
		'name' => '链接地址',
		'description' => '填写链接',
		'default' => 'http://blog.yesfree.pw',
        ),
'ico7_title' => array(
		'type' => 'text',
		'name' => '标题',
		'description' => '填写标题',
		'default' => '一个emlog新模板',
        ),
'ico7_image' => array(
		'type' => 'image',
		'name' => '图片',
		'values' => array(
            TEMPLATE_URL . 'icon/icon7.png',
        ),
	), 


'ico8_url' => array(
		'type' => 'text',
		'name' => '链接地址',
		'description' => '填写链接',
		'default' => 'http://blog.yesfree.pw',
        ),
'ico8_title' => array(
		'type' => 'text',
		'name' => '标题',
		'description' => '填写标题',
		'default' => '一个emlog新模板',
        ),
'ico8_image' => array(
		'type' => 'image',
		'name' => '图片',
		'values' => array(
            TEMPLATE_URL . 'icon/icon7.png',
        ),
	), 


'ico9_url' => array(
		'type' => 'text',
		'name' => '链接地址',
		'description' => '填写链接',
		'default' => 'http://blog.yesfree.pw',
        ),
'ico9_title' => array(
		'type' => 'text',
		'name' => '标题',
		'description' => '填写标题',
		'default' => '一个emlog新模板',
        ),
'ico9_image' => array(
		'type' => 'image',
		'name' => '图片',
		'values' => array(
            TEMPLATE_URL . 'icon/icon7.png',
        ),
	), 


'ico10_url' => array(
		'type' => 'text',
		'name' => '链接地址',
		'description' => '填写链接',
		'default' => 'http://blog.yesfree.pw',
        ),
'ico10_title' => array(
		'type' => 'text',
		'name' => '标题',
		'description' => '填写标题',
		'default' => '一个emlog新模板',
        ),
'ico10_image' => array(
		'type' => 'image',
		'name' => '图片',
		'values' => array(
            TEMPLATE_URL . 'icon/icon7.png',
        ),
	), 


);