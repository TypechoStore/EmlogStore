<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="contentleft">
<div class="tnextlog"><?php neighbor_log($neighborLog); ?></div>
	<h2><span><?php topflg($top); ?><?php echo $log_title; ?></span></h2>
	<p class="edate"><?php echo gmdate('Y-n-j G:i', $date); ?>  作者：<?php blog_author($author); ?> | <?php blog_sort($logid); ?> | <?php blog_tag($logid); ?>  <?php editflg($logid,$author); ?></p>
	
	<div class="ec"><?php echo $log_content; ?></div>
	<?php doAction('log_related', $logData); ?>
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	
	
	<p class="blogcopyright">
	<span class="pcopy">
	<img src="<?php global $CACHE; $user_cache = $CACHE->readCache('user'); echo empty($user_cache[$author]['avatar']) ? './admin/views/images/avatar.jpg' : BLOG_URL.$user_cache[$author]['avatar']; ?>" width="80px" height="80px"/> </span><span class="icopy">
	
	
	
	文章作者：<?php blog_author($author); ?><br>文章地址：<a href="<?php echo curPageURL();?>"><?php echo curPageURL();?></a><br>版权所有 © 转载时必须以链接形式注明作者和原始出处！</span>
	


	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>

	<div style="clear:both;"></div>

</div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>