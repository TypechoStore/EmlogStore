<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--end #content-->
<div style="clear:both;"></div>
<div id="footerbar">
<div align="left">
    <div class="t"></div>
    <?php
    global $CACHE;
    $link_cache = $CACHE->readCache('link');
    ?>
    <div class="link"><b>友情链接：</b>
        <?php foreach ($link_cache as $value): ?>
            <a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a>丨
        <?php endforeach; ?>
    </div>
<div style="clear:both;"></div>
</div><br>
<p align="center"><a href="/about.html" target="_blank" rel="nofollow">关于我们</a> | <a href="/mz.html" target="_blank" rel="nofollow">免责声明</a> | <a href="http://so.Milw0rm.top/" target="_blank">站内搜索</a> |<a href="/job.html" target="_blank" rel="nofollow">加入我们</a> | <a href="/about.html" target="_blank">联系我们</a>
<br>
	Copyright ©
        2010-2016      <a href="http://www.miibeian.gov.cn" target="_blank">Milw0rm'Team</a> All Rights Reserved.
	<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
	


	 <script type="text/javascript" src="<?php echo TEMPLATE_URL ?>js/jquery-1.4.1.min.js"></script>
	 <script type="text/javascript" src="<?php echo TEMPLATE_URL ?>js/phzoom.js"></script>
	 <link href="<?php echo TEMPLATE_URL ?>js/phzoom.css" rel="stylesheet" type="text/css" />
	 
<script type="text/javascript">
    hs.graphicsDir = "<?php echo TEMPLATE_URL ?>js/graphics/";
    hs.outlineType = "rounded-white";
    jQuery(function($){$("a[href$=jpg],a[href$=gif],a[href$=png],a[href$=jpeg],a[href$=bmp]").addClass("highslide").each(function(){this.onclick=function(){return hs.expand(this)}});})
</script>

	<?php doAction('index_footer'); ?>
</div><!--end #footerbar-->
</div><!--end #wrap-->
<script>prettyPrint();</script>
</body>
</html>