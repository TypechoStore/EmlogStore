<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="contentleft">
<?php doAction('index_loglist_top'); ?>

<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
 <div class="post_img">
                                        <?php if(pic_thumb($value['content'])){
                                                $imgsrc = pic_thumb($value['content']);
                                        }else
                                                $imgsrc = TEMPLATE_URL.'images/random/'.rand(1,20).'.jpg';
                                        ?>
                                                <a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><img src="<?php echo $imgsrc; ?>"/></a>
                                        </div>
										
										<div class="cont">
	<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
	
	        
										
	<p class="date"><?php echo gmdate('Y-n-j G:i', $value['date']); ?>  作者:<?php blog_author($value['author']); ?> 
	|<a href="<?php echo $value['log_url']; ?>#tb">引用(<?php echo $value['tbcount']; ?>)</a>
	|<a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a>
	|<a href="<?php echo $value['log_url']; ?>">阅读(<?php echo $value['views']; ?>)</a>
	<?php blog_sort($value['logid']); ?> 
	<?php editflg($value['logid'],$value['author']); ?>
	</p>
	<p class="c">
	<?php $c=mb_substr(strip_tags($value['log_description']),0,170,'utf-8'); $m=(strlen($c) + mb_strlen($c,'utf-8')/2);if($m>170) echo $c."..."; else echo $c; ?>
	</p>
	<p class="count">
	
	<span><?php blog_tag($value['logid']); ?></span> <a href="<?php echo $value['log_url']; ?>">【阅读全文】</a>
	
	</p>
	</div>
		<div style="clear:both;"></div>
		<div class="more"></div>
<?php endforeach;else:?>
	<p class="none">未找到</p>
	<p class="nonec">抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>

<div id="pagenavi">
	<?php echo $page_url;?>
</div>

<?php
//首页幻灯片
function home_slide(){
	$db = MySql::getInstance();
	$sql = "SELECT `A`.`blogid` as `g`, `A`.`filepath`, `B`.`title` as `t`, `B`.`date` as `d`, `B`.`content` as `c` FROM ".DB_PREFIX."attachment `A` LEFT JOIN ".DB_PREFIX."blog `B` ON `A`.`blogid`=`B`.`gid` WHERE `B`.`hide`='n' AND (`A`.`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') GROUP BY `A`.`blogid` ORDER BY `A`.`addtime` DESC LIMIT 0,5";
	$imgs = $db->query($sql);
	while($row = $db->fetch_array($imgs)){
	$slide .= '<li><a href="'.Url::log($row['g']).'" target="_blank"><img src="'.BLOG_URL.substr($row['filepath'],3,strlen($row['filepath'])).'" alt="'.$row['t'].'" width="650" height="350" /></a></li>'; }
	echo $slide;		
	}
?>
</div><!-- end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>