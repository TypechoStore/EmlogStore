<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--end #content-->
<div style="clear:both;"></div>
<div id="footerbar">
<div align="left">
    <div class="t"></div>
    <?php
    global $CACHE;
    $link_cache = $CACHE->readCache('link');
    ?>
    <div class="link"><b>Links：</b>
        <?php foreach ($link_cache as $value): ?>
            <a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a>丨
        <?php endforeach; ?>
    </div>
<div style="clear:both;"></div>
</div><br>
<p align="center">
 Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION; ?>" target="_blank">Emlog</a> & <a href="http://www.milw0rm.top" title="emlog <?php echo Option::EMLOG_VERSION; ?>" target="_blank">Milw0rm'Team</a></p>
 CopyRight &copy; 2009-2016&nbsp;<?php echo $blogname; ?>.&nbsp;&nbsp;All rights reserved.&nbsp;<?php echo $icp; ?>
    <?php doAction('index_footer'); ?>
	


	 <script type="text/javascript" src="<?php echo TEMPLATE_URL ?>js/jquery-1.4.1.min.js"></script>
	 <script type="text/javascript" src="<?php echo TEMPLATE_URL ?>js/phzoom.js"></script>
	 <link href="<?php echo TEMPLATE_URL ?>js/phzoom.css" rel="stylesheet" type="text/css" />
	 
<script type="text/javascript">
    hs.graphicsDir = "<?php echo TEMPLATE_URL ?>js/graphics/";
    hs.outlineType = "rounded-white";
    jQuery(function($){$("a[href$=jpg],a[href$=gif],a[href$=png],a[href$=jpeg],a[href$=bmp]").addClass("highslide").each(function(){this.onclick=function(){return hs.expand(this)}});})
</script>

	<?php doAction('index_footer'); ?>
</div><!--end #footerbar-->
</div><!--end #wrap-->
<script>prettyPrint();</script>
</body>
</html>