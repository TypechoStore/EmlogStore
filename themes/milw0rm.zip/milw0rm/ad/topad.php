﻿<?php 
/*
* 广告页
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!--调用说说公告开始-->
	
	<p>最新公告：<?php global $CACHE;  $newtws = $CACHE->readCache('newtw');if(empty($newtws)){ echo "求知若饥，虚心若愚。";}else{echo subString(strip_tags($newtws[0]['content']),0,36);echo "
	<script type='text/javascript'>
	if ( (/MSIE 6.0/ig.test(navigator.appVersion))||(/MSIE 7.0/ig.test(navigator.appVersion))||(/MSIE 8.0/ig.test(navigator.appVersion)) ) {document.write('<font color=red>低版本者浏览器滚粗。</font>');}
	</script>" ;
	} ?></p>

	<!--调用说说公告结束-->