<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="main">
  <div id="articleBox">
    <div class="articleTitle">
      <h1>
        <?php topflg($top); ?>
        <?php echo $log_title;?></h1>
    </div>
    <span class="articleInfo"> <small>日期：<?php echo gmdate('Y-n-j H:i', $date); ?></small>&nbsp;｜&nbsp; <small>作者：
    <?php blog_author($author); ?>
    </small>&nbsp;｜&nbsp; <small>
    <?php blog_sort($logid); ?>
    </small>&nbsp;｜&nbsp; <small><?php echo $views; ?>人围观</small>&nbsp;｜&nbsp; <small><?php echo $comnum; ?>人<a href="#respond">参与讨论</a></small> </span>
    <div class="content"> <?php echo $log_content; ?>
      <div class="content-footer">
        <?php blog_att($logid); ?>
        <p></p>
        相邻文章：
        <?php neighbor_log($neighborLog); ?>
        <p></p>
        <?php blog_tag($logid); ?>
        <p></p>
        引用地址：
        <?php blog_trackback($tb, $tb_url, $allow_tb); ?>
      </div>
    </div>
  </div>
  <div id="otherBox">
    <h3>[日志分享]</h3>
    <div class="otherMsg">
      <div id="ckepop"> <a class="jiathis_button_douban"> </a> <a class="jiathis_button_zhuaxia"> </a> <a class="jiathis_button_xianguo"> </a> <a class="jiathis_button_digu"> </a> <a class="jiathis_button_tsina"> </a> <a class="jiathis_button_tqq"> </a> <a class="jiathis_button_sohu"> </a> <a class="jiathis_button_renren"> </a> <a class="jiathis_button_baidu"> </a> <a class="jiathis_button_google"> </a> <a class="jiathis_button_qq"> </a> <a class="jiathis_button_51"> </a> <a class="jiathis_button_yahoo"> </a> <a class="jiathis_button_live"> </a> <a class="jiathis_button_taobao"> </a> <span class="separator">|</span> <a href="http://v2.jiathis.com/code/jia.js" class="jiathis button jtico jtico_more">更多</a> </div>
      <!-- JiaThis Button BEGIN --> 
      <script type="text/javascript" src="http://www.jiathis.com/code/jia.js" charset=utf-8></script> 
      <!-- JiaThis Button END --> 
    </div>
  </div>
  <div id="otherBox">
    <h3>[日志信息]</h3>
    <div class="otherMsg"> 该日志于&nbsp;<b><?php echo gmdate('Y-n-j H:i', $date); ?></b>&nbsp;由<b>&nbsp;
      <?php blog_author($author); ?>
      &nbsp;</b>发表在<b>&nbsp;<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>&nbsp;</b>网站上，你除了可以发表评论外，还可以转载<b>&nbsp;"<?php echo $log_title;?>"&nbsp;</b>日志到你的网站或博客，但是请保留源地址及作者信息，谢谢!!&nbsp;&nbsp;&nbsp;&nbsp;<b>（尊重他人劳动，你我共同努力）</b> </div>
  </div>
  <?php doAction('log_related', $logData); ?>
  <div id="decmt-box">
    <?php blog_comments($comments); ?>
  </div>
  <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>
