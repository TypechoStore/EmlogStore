<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
$weekarr= array('星期日','星期一','星期二','星期三','星期四','星期五','星期六');
?>

<div id="main">
  <?php doAction('index_loglist_top'); ?>
  <?php
if(isset($sortName)){
  echo '<div class="pagetitle">▨&nbsp;类别《<span>'.$sortName.'</span>》下的文章:</div>';
}
if(isset($record)) {
  if(strlen($record)>6){
    echo '<div class="pagetitle">▨&nbsp;写于<span>'.substr($record,0,4).'年'.substr($record,4,2).'月'.substr($record,6,2).'日</span>的文章:</div>';
  }else{
    echo '<div class="pagetitle">▨&nbsp;写于<span>'.substr($record,0,4).'年'.substr($record,4,2).'月</span>的文章:</div>';
  }
}
if(isset($tag)) echo '<div class="pagetitle">▨&nbsp;标签《<span>'.$tag.'</span>》下的文章:</div>';
if(isset($keyword)) echo '<div class="pagetitle">▨&nbsp;搜索关键词为『<span>'.$keyword.'</span>』的文章:</div>';
if(isset($author)) echo '<div class="pagetitle">▨&nbsp;作者"<span>'.$user_cache[$author]['name'].'</span>"的文章:</div>';
?>
  <?php foreach($logs as $value):?>
  <div id="listArticle">
    <div class="listtitle">
      <h3>
        <?php topflg($value['top']); ?>
        <a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></h3>
    </div>
    <span class="info"><small>日期：<?php echo date('Y-n-j ', $value['date']); ?></small>&nbsp;｜&nbsp; <small> 作者：
    <?php blog_author($value['author']); ?>
    </small>&nbsp;｜&nbsp; <small>
    <?php blog_sort($value['logid']); ?>
    </small>&nbsp;｜&nbsp; <small> 围观群众<?php echo $value['views']; ?></small> &nbsp;｜&nbsp;<small> 参与讨论<a href="<?php echo $value['log_url']; ?>#comments" title="<?php echo $value['log_title']; ?>上的评论"><?php echo $value['comnum']; ?></a> </small>
    <?php editflg($value['logid'],$value['author']); ?>
    </span>
    <div class="intro"> <?php echo $value['log_description']; ?> </div>
  </div>
  <?php endforeach; ?>
  <div class="pagenav">
    <?php if($page_url) echo '<div class="pagenum">Pages:'.$page_url.'</div>' ?>
  </div>
  <!-- /pages --> 
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>
