<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>

<div class="clearfix"></div>
<div id="footSub"> </div>
<div id="footNav">
  <h1>Copyright © 2011 <a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>"><strong><?php echo $blogname; ?></strong></a> <?php echo $footer_info; ?> | power by <a href="http://www.emlog.net" target="_blank" title="Emlog<?php echo Option::EMLOG_VERSION; ?>"><strong>Emlog</strong></a> | Theme By <a href="http://www.zld.me" target="_blank" title="自留地"><strong>ZLD.ME</strong></a> Designed By <a href="http://www.1h1y.cn" target="_blank" title="一花一叶"><strong>1H1Y</strong></a>
    <?php if($icp) echo " | <a href=\"http://www.miibeian.gov.cn\" target=\"_blank\"><strong>" .$icp. "</strong></a>"; ?>
  </h1>
</div>
<div id="go_top"><em></em><a href="javascript:movetop()">返回顶部</a></div>
<?php doAction('index_footer'); ?>
<!-- /footer -->
</body></html>