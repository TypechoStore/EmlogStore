<?php
/*
Template Name:1H1Y
Description:一花一世界，一叶一菩提。
Version:3.0
Author:Sogei
Author Url:http://www.zld.me
Sidebar Amount:1
ForEmlog:4.1.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $bloginfo; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" media="screen" type="text/css" />
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.min.1.4.0.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<!--[if lte IE 6]>
	<script>var LETSKILLIE6_DELAY=3;</script>
	<script src="<?php echo TEMPLATE_URL; ?>js/letskillie6.zh_CN.pack.js"></script>
<![endif]-->
</head>
<body>
<div id="header">
  <div id="nav">
    <div id="navBar">
      <div id="navMenu">
        <ul>
          <?php if(isset($curpage)){ ?>
          <li<?php echo $curpage == CURPAGE_HOME ? ' class="current"' : ''; ?>><a href="<?php echo BLOG_URL; ?>"><span>首页</span></a></li>
          <li<?php echo $curpage == CURPAGE_TW ? ' class="current"' : ''; ?>><a href="<?php echo BLOG_URL; ?>t/"><span>微语</span></a></li>
          <?php }else{ ?>
          <li<?php echo empty($_GET) ?  ' class="current"' : ''; ?>><a href="<?php echo BLOG_URL; ?>"><span>首页</span></a></li>
          <?php } ?>
          <?php
global $CACHE; 
$navi_cache = $CACHE->readCache('navi');
foreach ($navi_cache as $key => $val):
if ($val['hide'] == 'y'){continue;}
if (empty($val['url'])){$val['url'] = Url::log($key);}
$newtab = $val['newtab'] == 'y' ? 'target="_blank"' : '';
?>
          <li<?php echo isset($logid) && $logid == $key ? ' class="current"' : ''; ?>><a href="<?php echo $val['url']; ?>" <?php echo $newtab; ?>><span><?php echo $val['naviname']; ?></span></a></li>
          <?php endforeach;?>
          <?php doAction('navbar', '<li><span>', '</span></li>'); ?>
          <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
          <li><a href="<?php echo BLOG_URL; ?>admin/write_log.php"><span>写日志</span></a></li>
          <li><a href="<?php echo BLOG_URL; ?>admin/"><span>管理中心</span></a></li>
          <li><a href="<?php echo BLOG_URL; ?>admin/?action=logout"><span>退出</span></a></li>
          <?php else: ?>
          <li><a href="<?php echo BLOG_URL; ?>admin/"><span>登录</span></a></li>
          <?php endif; ?>
        </ul>
      </div>
      <div id="navLink">
        <ul>
          <li><a href="<?php echo BLOG_URL; ?>rss.php" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/navLink/icon-rss.gif" alt="订阅我 得永生!" title="订阅我 得永生!" width="21" height="21" /></a></li>
          <li><a href="http://t.qq.com/freesogei" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/navLink/icon-tqq.gif" alt="企鹅微博 求围观!" title="企鹅微博 求围观!" width="21" height="21" /></a></li>
          <li><a href="mailto:admin@zld.me" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/navLink/icon-email.gif" alt="发邮件给sogei吧!" title="发邮件给我吧!" width="21" height="21" /></a></li>
        </ul>
      </div>
    </div>
  </div>
  <div id="sub">
    <div id="subLogo"> </div>
    <div id="subTitle">
      <h1><?php echo $blogname; ?></h1>
      <h4> <?php echo $bloginfo; ?> </h4>
    </div>
  </div>
</div>
<!-- //End header -->
<div id="container">
