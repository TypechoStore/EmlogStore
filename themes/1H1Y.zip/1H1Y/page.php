<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="main">
  <div id="articleBox">
    <div class="articleTitle">
      <h1><?php echo $log_title; ?></h1>
    </div>
    <div class="content"> <?php echo $log_content; ?>
      <?php blog_att($logid); ?>
    </div>
  </div>
  <div id="decmt-box">
    <?php blog_comments($comments); ?>
  </div>
  <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
<!--end content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>
