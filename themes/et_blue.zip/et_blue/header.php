<?php
/*
Template Name:ET_BLUE
Description:蓝色简约模板
Version:1.0
Author:emlog
Author Url:http://www.openkee.com
Sidebar Amount:1
ForEmlog:5.0.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>main.css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="header">
	<div id="header-bg">
	</div>
	<div id="header-sub">
		<div id="logo">
			<a href="<?php echo BLOG_URL; ?>" title="<?php echo $bloginfo; ?>"><?php echo $blogname; ?></a>
		</div>
		<?php blog_navi();?>
	</div>
</div>