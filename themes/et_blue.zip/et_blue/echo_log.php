<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
    <div id="content">
		<div id="left_con">
					<div id="h_info">
						<h1 id="tit"><?php topflg($top); ?><?php echo $log_title; ?></h1>
						<div id="tdetail">作者：<?php blog_author($author); ?> 发布于：<?php echo gmdate('Y-m-d', $date); ?> 
	<?php blog_sort($logid); ?> <?php editflg($logid,$author); ?></div>
					</div>
					
					<div id="article">
						<?php echo $log_content; ?>
					</div>
                    <div class="tags echo_log">
						<?php blog_tag($logid); ?>
					</div>
										<div id="more-post">
						 
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
    
    <?php doAction('log_related', $logData); ?>
                         
    <?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
                         
					</div>
				</div>
		<div id="right_con">
			<?php include View::getView('side');?>
		</div>
		<div style="clear:both">
		</div>
	</div>
	<!-- #content -->
</div>
<!-- #container -->
<?php include View::getView('footer');?>