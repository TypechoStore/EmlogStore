<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
	<?php doAction('index_loglist_top'); ?>
    <div id="content">
		<div id="left_con">
			<div class="excerpt">
				<?php foreach($logs as $value): ?>
                <ul>
					<li>
					<h2 class="tit">
					<?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></h2>
					<p class="time">
						发布于：<?php echo gmdate('Y-m-d', $value['date']); ?>　作者：<?php blog_author($value['author']); ?>　<a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a>　<a href="<?php echo $value['log_url']; ?>#tb">引用(<?php echo $value['tbcount']; ?>)</a>　<a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a> &nbsp;<?php blog_sort($value['logid']); ?>　<?php editflg($value['logid'],$value['author']); ?>
					</p>
					<p class="abstract">
						<?php echo $value['log_description']; ?>
					</p>
					<div class="tags">
						<?php blog_tag($value['logid']); ?>
					</div>
					</li>
				</ul>
                <?php endforeach; ?>
			</div>
            <div class="pagenav"><?php echo $page_url;?></div>
		</div>
		<div id="right_con">
			<?php include View::getView('side');?>
		</div>
		<div style="clear:both">
		</div>
	</div>
	<!-- #content -->
</div>
<!-- #container -->
<?php include View::getView('footer');?>