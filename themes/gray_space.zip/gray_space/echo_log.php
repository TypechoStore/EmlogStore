<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="wrapper">	
  
	<div id="main" class="clearfix">
     <div id="containers" class="clearfix">

 <div id="contents" class="section">

 
        <!-- Featured Articles -->
        <div class="post post hentry category clearfix single-post">
   <h2 class="entry-title"><?php topflg($top); ?><?php echo $log_title; ?></h2>
             <div class="entry-info"><span class="entry-author">
            <address class="author vcard">
            作者:<?php blog_author($author); ?>    </address>
            </span><strong>发布时间: </strong> <abbr class="published">
          <?php echo gmdate('Y-n-j', $date); ?><strong>   已有</strong><?php echo $comnum; ?> 条评论</abbr><span class="entry-cat"><?php blog_sort($logid); ?>  <?php editflg($logid,$author); ?></span>
            
                        </div>
          <div class="entry-content">
            <p>
                  </p><p>	<?php echo $log_content; ?></p>            <p></p>
          </div>
          					<p class="att"><?php blog_att($logid); ?></p>
        
 	<p class="tag"><?php blog_tag($logid); ?></p>
          </div>
        </div>
    	<?php doAction('log_related', $logData); ?>
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>

 
        </div>
    <div id="bottom-content-1"> </div>
    <div id="bottom-content-2"> </div>
 </div>
<div id="primary" class="aside main-aside sidebar">

 
</div><!-- #primary -->
 
<?php
 include View::getView('footer');
?>
 		
 