<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="wrapper">	
  
	<div id="main" class="clearfix">
    <div id="container" class="clearfix">


<div id="content" class="section">


<!-- Featured Articles -->
	<div id="index-featured">
    
          <div class="home-title">我的博文</div>
          
          <div class="traditional hfeed">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
                      <div class="post-52 post hentry category-1 clearfix single-post">
              <h2 class="entry-title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
              <div class="entry-info"><span class="entry-author">
            <address class="author vcard">
            作者:<?php blog_author($value['author']); ?></address>
            </span><strong>发布时间: </strong> <abbr class="published">
           <?php echo gmdate('Y-n-j', $value['date']); ?>  <strong>被围观: </strong><?php echo $value['views']; ?>次 <strong>评论: </strong><?php echo $value['comnum']; ?>条</abbr><span class="entry-cat"><?php blog_sort($value['logid']); ?> </span>
            
                        </div>
              <div class="entry-content">
                <p></p><p>	<?php echo $value['log_description']; ?></p><p></p>
              </div>
              				<?php blog_tag($value['logid']); ?>
            </div>
                      
            <?php endforeach; ?>
          </div>
          <!-- .traditional -->
    </div>
 



<!-- News Articles -->
<div id="index-news">

          <div class="wp-pagenavi">
          <ol class="pages clearfix">
            <li class="current">	<?php echo $page_url;?></li>          </ol>
          </div>
</div><!-- #index-news -->




    <div id="bottom-content-1"> </div>
    <div id="bottom-content-2"> </div>
</div><!-- #content -->
    
</div><!-- #container -->


<div id="primary" class="aside main-aside sidebar">

<?php  include('side.php');?>
</div><!-- #primary -->
 
	
            				

<?php 
 include View::getView('footer');
?>