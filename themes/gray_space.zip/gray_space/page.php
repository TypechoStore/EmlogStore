<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="wrapper">	
 
	<div id="main" class="clearfix">
    <div id="containers" class="clearfix">
      <div id="contents" class="section">
        <!-- Featured Articles -->
        <div class="post-52 post hentry category-1 clearfix single-post">
   <h2 class="entry-title"><?php echo $log_title; ?></h2>
          <div class="entry-info"><span class="entry-author">
            <address class="author vcard">
   </span> 
            
                      
          <div class="entry-content">
       <p>	<?php echo $log_content; ?></p>  
        
</div></div></div> 
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	
<div style="clear:both;"> </div>
</div>
 </div></div>
<?php
 
 include View::getView('footer');
?>
 		
 