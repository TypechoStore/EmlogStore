<?php
/*
Template Name:BBCMS 3.1
Description:老妖工作室倾情奉献，应原作者要求，此主题为商业主题。
Author:老妖工作室
Author Url:http://vruan.net
Sidebar Amount:1
ForEmlog:5.2.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
emLoadJquery();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js" language="javascript" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<!--[if IE 6]>
<script src="<?php echo TEMPLATE_URL; ?>iefix.js" type="text/javascript"></script>
<![endif]-->

<SCRIPT language="javascript" src="<?php echo TEMPLATE_URL; ?>js/Kurly_kv.js" type="text/javascript"></SCRIPT>
</head>
<body>
<div id="page">
<div id="header">
<div id="top">
<div id="top_logo">
            <a href="<?php echo BLOG_URL; ?>" title="<?php echo $site_title; ?> "><div class="logo"></div></a>
				
</div>
	   <div id="mp_gonggao">
	<a href="#" target="_blank" title="480*80banner横幅 "><div class="banner "></div></a>
			   </div>
		<div class="search">		
			<form name="keyform" id="searchform" method="get" action="<?php echo BLOG_URL; ?>index.php">
				<input type="text" x-webkit-speech name="keyword" class="search-keyword" onfocus="if (this.value == '请输入关键字进行搜索') {this.value = '';}" onblur="if (this.value == '') {this.value = '请输入关键字进行搜索';}" value="请输入关键字进行搜索" /> 
				<button type="submit">搜索</button>
			</form>
				<div id="rss">
			<ul>
			  <li class="mp_maillist" id="mp_email"><a target="_blank" class="icon6" title="订阅我的邮箱"></a>
									  </li>																	  <li class="mp_qq"><a  rel="nofollow" href="http://wpa.qq.com/msgrd?V=1&Menu=yes&Uin=176632" target="_blank" class="icon5" title="我的腾讯QQ"></a>
									  </li>																	  <li class="mp_wangwang"><a rel="nofollow"  href="#" target="_blank" class="icon4" title="我的阿里旺旺"></a></li>																	  <li class="mp_tqq"><a rel="nofollow"  href="http://t.qq.com/tiexincn" target="_blank" class="icon3" title="我的腾讯微博"></a>
									  </li>																	  <li class="mp_weibo"><a rel="nofollow"  href="http://weibo.com/tiexincn" target="_blank" class="icon2" title="我的新浪微博"></a>
									  </li>																	  <li class="mp_rss"><a  rel="nofollow" href="<?php echo BLOG_URL; ?>rss.php" target="_blank" class="icon1" title="欢迎通过RSS订阅我的博客"></a>
									  </li>						
									  </ul>
									  </div>
		</div>
		<div class="clear"></div>
</div><div class="topnav">
<?php blog_navi();?>
</div>

		 		 

	 	 	<div class="clear"></div>
	 </div>
</div>
</div><div class="rolltofall"><a class="rollico ico-tofall" title="到底部"></a></div>