<?php 
/**
 * 侧边栏组件、页面模块
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
<div class="widget">
<div class="sponsor">
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="bloggerinfo">
	<div id="bloggerinfoimg">
	<?php if (!empty($user_cache[1]['photo']['src'])): ?>
	<img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="<?php echo $user_cache[1]['photo']['width']; ?>" height="<?php echo $user_cache[1]['photo']['height']; ?>" alt="blogger" />
	<?php endif;?>
	</div>
	<p><b><?php echo $name; ?></b>
	<?php echo $user_cache[1]['des']; ?></p>
	</ul>
</div></div>
<?php }?>
<?php
//widget：日历
function widget_calendar($title){ ?>
<div class="widget">
<div class="sponsor">
	<h3><span><?php echo $title; ?></span></h3>
	<div id="calendar">
	</div>
	<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
</div></div>
<?php }?>
<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
<div class="widget">
<div class="sponsor">
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="blogtags">
<?php
shuffle($tag_cache);
$tag_cache = array_slice($tag_cache,0,30); //显示数量
foreach($tag_cache as $value): $color=dechex(rand(0,13421772));?>
<span >
<a style="color:#<?php echo $color ?>" href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['tagname']; ?>标签有<?php echo $value['usenum']; ?> 篇日志"><?php echo $value['tagname']; ?></a></span>
<?php endforeach; ?>
	</ul>
</div></div>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
<div class="widget">
<div class="sponsor">
	<h3><span><?php echo $title; ?></span></h3>
		<div class="mp_links" style="_padding-bottom: 30px;">
	<ul id="blogsort"  class="index_resourse_list ">
	<?php
	foreach($sort_cache as $value):
		if ($value['pid'] != 0) continue;
	?>
	<li>
	<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
	<a href="<?php echo BLOG_URL; ?>rss.php?sort=<?php echo $value['sid']; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/rss.png" alt="订阅该分类"/></a>
	<?php if (!empty($value['children'])): ?>
		<ul>
		<?php
		$children = $value['children'];
		foreach ($children as $key):
			$value = $sort_cache[$key];
		?>
		<li>
			<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
			<a href="<?php echo BLOG_URL; ?>rss.php?sort=<?php echo $value['sid']; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/rss.png" alt="订阅该分类"/></a>
		</li>
		<?php endforeach; ?>
		</ul>
	<?php endif; ?>
	<?php endforeach; ?>
	</ul>
</div></div></div>
<?php }?>
<?php
//widget：最新微语
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	?>
<div class="widget">
<div class="sponsor">
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="twitter">
	<?php foreach($newtws_cache as $value): ?>
	<?php $img = empty($value['img']) ? "" : '<a title="查看图片" class="t_img" href="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" target="_blank">&nbsp;</a>';?>
	<li><?php echo $value['t']; ?><?php echo $img;?><p><?php echo smartDate($value['date']); ?></p></li>
	<?php endforeach; ?>
    <?php if ($istwitter == 'y') :?>
	<p><a href="<?php echo BLOG_URL . 't/'; ?>">更多&raquo;</a></p>
	<?php endif;?>
	</ul>
</div></div>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
<div class="widget">
<div class="sponsor">
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="newcomment" class="index_resourse_list ">
	<?php
	foreach($com_cache as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	?>
<li id="comment_index"><img alt="<?php echo $value['name']; ?>" src="<?php echo getGravatar($value['mail']); ?>" height='20' width='20' /><?php echo $value['name']; ?>:
	<a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a></li>
	<?php endforeach; ?>
	</ul>
</div></div>
<?php }?>
<?php
//widget：最新文章
function widget_newlog($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
<div class="widget">
<div class="sponsor">
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="newlog" class="index_resourse_list ">
	<?php foreach($newLogs_cache as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
</div></div>
<?php }?>
<?php
//widget：热门文章
function widget_hotlog($title){
	$index_hotlognum = Option::get('index_hotlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getHotLog($index_hotlognum);?>
<div class="widget">
<div class="sponsor">
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="hotlog" class="index_resourse_list ">
	<?php foreach($randLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
</div></div>
<?php }?>
<?php
//widget：随机文章
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
<div class="widget">
<div class="sponsor">
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="randlog" class="index_resourse_list ">
	<?php foreach($randLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
</div></div>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
<div class="widget">
<div class="sponsor">
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="logsearch">
	<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
	<input name="keyword" class="search" type="text" />
	</form>
	</ul>
</div></div>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
<div class="widget">
<div class="sponsor">
	<h3><span><?php echo $title; ?></span></h3>
		<div class="mp_links" style="_padding-bottom: 30px;">
	<ul id="record" class="index_resourse_list ">
	<?php foreach($record_cache as $value): ?>
	<li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
	<?php endforeach; ?>
	</ul>
</div></div></div>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
<div class="widget">
<div class="sponsor">
	<h3><span><?php echo $title; ?></span></h3>
	<ul>
	<?php echo $content; ?>
	</ul>
</div></div>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
    //if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
	?>
<div class="widget">
<div class="sponsor">
	<h3><span><?php echo $title; ?></span></h3>
	<div class="mp_links" style="_padding-bottom: 30px;">
	<ul id="link" class="index_resourse_list ">
	<?php foreach($link_cache as $value): ?>
	<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
	<?php endforeach; ?>
	</ul>
</div></div></div>
<?php }?>
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	?>
	<ul class="bar">
	<?php
	foreach($navi_cache as $value):
		if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):
			?>
			<li class="item common"><a href="<?php echo BLOG_URL; ?>admin/">管理站点</a></li>
			<li class="item common"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
        $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'current' : 'common';
		?>
		<li class="item <?php echo $current_tab;?>">
			<a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a>
			<?php if (!empty($value['children'])) :?>
            <ul class="sub-nav">
                <?php foreach ($value['children'] as $row){
                        echo '<li><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></li>';
                }?>
			</ul>
            <?php endif;?>
		</li>
	<?php endforeach; ?>
	</ul>
<?php }?>
<?php
//blog：置顶
function topflg($istop){
	$topflg = $istop == 'y' ? "<img src=\"".TEMPLATE_URL."/images/import.gif\" title=\"置顶文章\" /> " : '';
	echo $topflg;
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
	分类：<a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
	<?php endif;?>
<?php }?>
<?php
//blog：文章标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '标签:';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "	<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
		}
		echo $tag;
	}
}
?>
<?php
//blog：文章作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog):?>
	&laquo; <a href="<?php echo Url::log($prevLog['gid']) ?>"><?php echo $prevLog['title'];?></a>
	<?php endif;?>
	<?php if($nextLog && $prevLog):?>
		|
	<?php endif;?>
	<?php if($nextLog):?>
		 <a href="<?php echo Url::log($nextLog['gid']) ?>"><?php echo $nextLog['title'];?></a>&raquo;
	<?php endif;?>
<?php }?>
<?php
//blog：评论列表
function blog_comments($comments){
    extract($comments);
    if($commentStacks): ?>
	<div  class="mp_review">
	
	<h3 id="comments">评论：</h3>
	<ol class="review_list" >
	<?php endif; ?>
	<?php
	$isGravatar = Option::get('isgravatar');
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	
		<?php if($isGravatar == 'y'): ?>
			<li class="comment even thread-even depth-<?php echo $comment['cid']; ?>" id="comment-<?php echo $comment['cid']; ?>"><div id="div-comment-<?php echo $comment['cid']; ?>" class="review_body"><div class="review_img"><div class="thumbnail">
		<img src="<?php echo getGravatar($comment['mail']); ?>" /></div></div><div class="review_info"><div class="review_floor"><a href="#comment-<?php echo $comment['cid']; ?>"><?php echo $comment['cid']; ?></a></div><?php endif; ?>
		<span class="review_author"><?php echo $comment['poster']; ?></span>于<?php echo $comment['date']; ?>说:
		 	<a class='comment-reply-link' href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a>
			<p><?php echo $comment['content']; ?> </p>
		
		 </div></div>
	
		<?php blog_comments_children($comments, $comment['children']); ?>
</li>
	<?php endforeach; ?>
   </ol>

<div class="navigation">
   <div class="pagination">
	    <?php echo $commentPageUrl;?></div>
</div>

<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?><ul class='children'>
	<li class="comment byuser comment-author-raynailao bypostauthor odd alt depth-<?php echo $comment['cid']; ?>" id="comment-<?php echo $comment['cid']; ?>"><div id="div-comment-<?php echo $comment['cid']; ?>" class="review_body"><div class="review_img"><div class="thumbnail">
		<a name="<?php echo $comment['cid']; ?>"></a>
		<?php if($isGravatar == 'y'): ?><img src="<?php echo getGravatar($comment['mail']); ?>" /></div></div><div class="review_info"><div class="review_floor"><a href="#comment-<?php echo $comment['cid']; ?>"><?php echo $comment['cid']; ?></a></div><?php endif; ?>
	<span class="review_author"><?php echo $comment['poster']; ?></span>于<?php echo $comment['date']; ?>说： <?php if($comment['level'] < 5): ?><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a><?php endif; ?>
			<p><?php echo $comment['content']; ?></p>
			</div></div>
		
		<?php blog_comments_children($comments, $comment['children']);?>
		
</ul> </li>
	<?php endforeach; ?>
<?php }?>

<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
if($allow_remark == 'y'): ?>
<div class="clear"></div>
<div id="comment-place" class="respond">
<div id="comment-post" class="comment-post">
		<h3><b>发表评论：</b><a name="respond"></h3>
				<form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
				<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
				<?php if(ROLE == 'visitor'): ?>
      <div id="review_data" >
        <p><label for="author">昵称</label><input type="text" name="comname" maxlength="49" value="<?php echo $ckname; ?>" size="22"  tabindex="1" /><em>*</em></p>
        <p><label for="email">邮箱</label><input type="text" name="commail"  maxlength="128"  value="<?php echo $ckmail; ?>" size="22" tabindex="2" /></p>
        <p><label for="url">网址</label><input type="text" name="comurl" maxlength="128"  value="<?php echo $ckurl; ?>" size="22" tabindex="3" /></p>
      </div>
			 <?php endif; ?>
		  <div class="review_area">
				  <textarea name="comment" id="comment" cols="100%" rows="10" tabindex="4" ></textarea>			
   	</div>
				<?php echo $verifyCode; ?>
    <input class="btn" type="submit" id="comment_submit" value="发表评论" tabindex="6" />
			 <input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/>
				<div id="cancel-reply" class="mp_qx" style="display:none">
				  <a href="javascript:void(0);" onclick="cancelReply()">取消回复</a>
			 </div>
		</form>
</div>
</div>
<?php endif; ?>
<?php }?>
<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>
<?php
//按分类获取列表
function index_tablist($sortid, $by, $num="5", $long="180") {
$date = time() - 3600 * 24 * $long;
$sort_sql = 'and sortid='.$sortid;
if($sortid == '')$sort_sql = '';
if($by=="new"){
$order = 'ORDER BY date DESC, date DESC';
}elseif($by=="hot"){
$order = 'AND date > '.$date.' ORDER BY comnum DESC, date DESC';
}elseif($by=='view'){
$order = 'AND date > '.$date.' ORDER BY views DESC, date DESC';
}elseif($by=='rand'){
$order = 'ORDER BY rand()';
}elseif($by=='sofa'){
$order = 'AND comnum = 0 ORDER BY rand()';
}else{
$order = 'AND top=\'y\' ORDER BY  date DESC';
}
$db=MySql::getInstance();
$logs = $db->query("SELECT gid ,title FROM " . DB_PREFIX . "blog WHERE hide='n' and type='blog' $sort_sql $order LIMIT 0, $num");
while ($row = $db->fetch_array($logs)){
$row['title'] = htmlspecialchars($row['title']);
?>
<li ><a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>" ><?php echo $row['title']; ?></a></li>
<?php } ?>
<?php }?>

<?php
//首页栏目文章列表
function get_list($sort){
$db = MySql::getInstance();
?>
<?php
$sql1 = "SELECT sortname FROM ".DB_PREFIX."sort WHERE sid=".$sort;
$timezone = Option::get('timezone');
$s = $db->query($sql1);
$sortname = $db->fetch_array($s);
?>
<div class="con_box fl qd_aritle">
<h2><span><a  rel="nofollow" href="<?php echo Url::sort($sort);?>"><?php echo $sortname['sortname'];?></a></span></h2>
  <div class="widgetr">
		<ul class="index_resourse_list qd_list">
<?php
$sql2 = "SELECT gid,title,date FROM ".DB_PREFIX."blog WHERE sortid=".$sort."  AND hide='n' ORDER BY `date` DESC LIMIT 9";
$list = $db->query($sql2);
while($row = $db->fetch_array($list)){
$row['date'] += $timezone * 3600;
?>
<span class="fr"><?php echo gmdate('Y-m-d', $row['date']);?></span>
<li>
<a href="<?php echo Url::log($row['gid']);?>" title="<?php echo $row['title'];?>" style="padding-left: 4px;"><?php echo $row['title'];?></a></li>	
<?php }?>
</ul>
</div>
</div>

<?php } ?>

<?php 
// 首页最新文章
function get_newlog(){
$db = MySql::getInstance();
$sql = $db->query ("SELECT * FROM ".DB_PREFIX."blog inner join ".DB_PREFIX."sort WHERE hide='n' AND type='blog' AND top='n' AND sortid=sid order by date DESC limit 0,6");
while($row = $db->fetch_array($sql)){
$logpost = !empty($row['excerpt']) ? $row['excerpt'] : ''.$row['content'].'';			
if (!empty($row['excerpt'])){
preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['excerpt'], $match);
if(empty($match[0][0]))
{
preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'], $match);
}
}else{
preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'], $match);
}
$num = rand(1,10);	
$img = isset($match[0][0]) ? $match[0][0] : '<img src="'.TEMPLATE_URL.'images/random/'.$num.'.jpg" width="140px" height="100px" />';
$date = gmdate('Y年m月d日', $row['date']);
$content = strip_tags($logpost,'');
$content = mb_substr($content,0,300,'utf-8');
$comment = ($row['comnum'] != 0) ? '评论：<small>'.$row['comnum'].'</small>' : '暂无评论';
$gid = $row['gid'];
$tag = $db -> query("SELECT * FROM ".DB_PREFIX."tag WHERE gid LIKE '%,$gid,%'");
$out .='
<ul class="post-821 post type-post status-publish format-standard hentry category-wlzy tag-191" id="post-821">
<li><div class="article">
<div class="mp_article">
<h2><a href="'.Url::log($row['gid']).'" title="'.$row['title'].'"  >'.$row['title'].'</a><span class="new"></span></h2> 
<div class="thumbnail_box">
<div class="thumbnail1">
</div>
<div class="thumbnail1">
<a href="'.Url::log($row['gid']).'" title="'.$row['title'].'"  >'.$img.'</a>
</div></div>
<div class="preview">'.$content.'...</div>
<div class="info">发布日期：'.$date.'|                        
点击：<small> '.$row['views'].' 次</small>|
<a href="'.Url::log($row['gid']).'#comments" title="《'.$row['title'].'》上的评论">'.$comment.'</a> | 
栏目：<a href="'.Url::sort($row['sortid']).'" title="查看 '.$row['sortname'].' 中的全部文章" rel="category tag">'.$row['sortname'].'</a> </div>
<div class="info_tag">标签：';
while ($tagrow = $db->fetch_array($tag)){
$out .='<a href="'.Url::tag($tagrow['tagname']).'" rel="tag">'.$tagrow['tagname'].'</a>';}
$out .='
</div></div></li></ul><div class="clear"></div>	';
}
echo $out;
}?>
<?php
//获取文章缩略图，先是自定义指定，然后是查找附件图片，最后是随机图片
//思路来自独头茧
function get_thum($logid){
 $db = MySql::getInstance();
$thum_pic = EMLOG_ROOT.'/thumpic/'.$logid.'.jpg';
if (is_file($thum_pic)) {
    $thum_url = BLOG_URL.'thumpic/'.$logid.'.jpg'; 
}else{
	$sqlimg = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$logid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";
//    die($sql);
	$img = $db->query($sqlimg);
    while($roww = $db->fetch_array($img)){
	 $thum_url=BLOG_URL.substr($roww['filepath'],3,strlen($roww['filepath']));
    }
    if (empty($thum_url)) {
	
srand((double)microtime()*1000000); 
$randval   =   rand(1,10); 

            $thum_url = TEMPLATE_URL.'images/random/'.$randval.'.jpg';
        }
    }
echo $thum_url;
}
?>
<?php
//文章底部随机图片文章
function get_rand_log(){
	$index_randlognum = 5;
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
		<div class="thumbnail">
	<ul>
	<?php foreach($randLogs as $value): ?>
	<li>
	<a  href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>" ><img src="<?php get_thum($value['gid']); ?>" >	<div class="related_posts_tittle"><?php echo $value['title']; ?></div></a>

	</li>
	<?php endforeach; ?>
			</ul>
</div>
<?php }?>

<?php
//get thumbs（图片链接）
function pic_thumb($content){
    //preg_match_all全局匹配content中的图片地址，并存入$img变量
    preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $content, $img);
    //当图片存在时，获取第一张图片，地址保存在$imgsrc中
    $imgsrc = !empty($img[1]) ? $img[1][0] : '';
	if($imgsrc):
		return $imgsrc;
	endif;
}
?>