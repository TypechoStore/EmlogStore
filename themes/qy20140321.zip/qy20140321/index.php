<?php 
/*
* 首页
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="roll">
<div title="回到顶部" id="roll_top">
</div>
<div title="转到底部" id="fall">
</div>
</div>
<div id="wrapper">
</div>
<!-- 图片幻灯 结束 -->


<div id="content">
<div class="main">
<div class="crumbs">
<div class="crumbs_name"><i></i><p>当前位置：</p></div>
<ul> 
<li><a  title="返回首页" href="<?php echo BLOG_URL; ?>">首页 &raquo;</a></li>
</ul>
</div>

<div class="clear"></div>

<DIV  class="post-857 post type-post status-publish format-standard hentry category-ment tag-window-9 tag-200" id="post-857">
<div id="slider_wz">
<UL id="TOP_ART" CLASS="TOP_ARTICLES">
<?php
//置顶文章
$db = MySql::getInstance();
$sql = 	"SELECT gid,title,content FROM ".DB_PREFIX."blog WHERE type='blog' and top='y' ORDER BY `top` DESC LIMIT 0,8";
$list = $db->query($sql);
$row = $db->fetch_array($list);
?>
<DIV class='T'>

<a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>"><?php echo $row['title']; ?></a>
</DIV>

<DIV class='TS'><?php echo subString(strip_tags($row['content']),0,350); ?>
</DIV>
<?php
//置顶文章的数量
$db = MySql::getInstance();
$sql = 	"SELECT gid,title,content FROM ".DB_PREFIX."blog WHERE type='blog' and top='y' ORDER BY `top` DESC LIMIT 1,8";
$list = $db->query($sql);
while($row = $db->fetch_array($list)){
?>
<li><a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>" rel="bookmark"><?php echo $row['title']; ?></a></li>
<?php } ?>
</UL>
</DIV>
<div class="leftad">
<img src="<?php echo TEMPLATE_URL; ?>images/pfu5lsuv.gif" />
</div>
<div class="clear"></div>
<div id="art_main" class="fl"> 
<?php get_list('1');?>
<?php get_list('2');?>


</div>
<div class="leftad">
<img src="<?php echo TEMPLATE_URL; ?>images/ypkyskil.gif" />
</div>

<?php get_newlog();?>



</div>
</div>
<?php include View::getView('side'); ?>

