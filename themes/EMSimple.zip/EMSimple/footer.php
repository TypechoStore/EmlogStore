<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="clear"></div>
</div><!--end #content-->

<div id="footerbar">
    <div class="copy">
		&copy; <?php echo date("Y"); ?> <a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>"><?php echo $blogname; ?></a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> 由<a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">Emlog</a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>强力驱动 <?php echo $footer_info; ?>
    </div>
<?php doAction('index_footer'); ?>
</div><!--end #footerbar-->
</div><!--end #wrap-->
</body>
</html>