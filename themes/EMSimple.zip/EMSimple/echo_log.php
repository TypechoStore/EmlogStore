<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="contentleft">
    <div class="post">
    	<div class="pdate">
    	<?php echo gmdate('M', $date); ?>
        <span><?php echo gmdate('j', $date); ?></span>
        <?php echo gmdate('Y', $date); ?>
    </div>
    <div class="pcontent">
    	<h2 class="ch2"><?php topflg($top); ?><?php echo $log_title; ?></h2>
        <div class="log_description"><?php echo $log_content; ?></div>
    </div>
    <div class="pcomm">
    	<a href="<?php echo $value['log_url']; ?>#comments"><?php echo $comnum; ?></a>	
    </div>
    <div class="clear"></div>
    </div>
    <div id="breadcrumb">
	<?php neighbor_log($neighborLog); ?>
    <div class="clear"></div>
    </div>
    <div id="comments">
        <div class="roubcornrcontent">
			<?php blog_comments($comments); ?>
            <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    	</div><!--end .roubcornrcontent-->
	</div><!--end #comments--> 
</div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>