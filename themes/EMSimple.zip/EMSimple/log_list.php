<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="contentleft">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<div class="post">
	<div class="pdate">
    	<?php echo gmdate('M', $value['date']); ?>
        <span><?php echo gmdate('j', $value['date']); ?></span>
        <?php echo gmdate('y', $value['date']); ?>
    </div>
    <div class="pcontent">
    	<h2 class="ch2"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
        <div class="log_description"><?php echo $value['log_description']; ?></div>
    </div>
    <div class="pcomm">
    	<a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?></a>	
    </div>
    <div class="clear"></div>
</div><!-- end .post-->
<?php endforeach; ?>

<div class="pagenav">
	<div class="page-navigator"><?php echo $page_url;?></div>	
</div><!-- end .pagenav-->
<div class="end"></div>
</div><!-- end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>