<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="contentleft">
	<div class="post">
    	<div class="pdate">
    	<?php echo gmdate('M', $date); ?>
        <span><?php echo gmdate('j', $date); ?></span>
        <?php echo gmdate('Y', $date); ?>
    </div>
    <div class="pcontent">
    	<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
        <div class="log_description"><?php echo $log_content; ?></div>
    </div>
    <div class="pcomm">
    	<a href="<?php echo $value['log_url']; ?>#comments"><?php echo $comnum; ?></a>	
    </div>
    <div class="clear"></div>
    </div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>