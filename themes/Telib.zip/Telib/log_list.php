<?php
/**
 * 列表页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
if($pageurl == Url::logPage()){include View::getView('index');exit;}
?>
	<div class="loglist-wapper Mauto">
		<div class="loglist-1 Left">
			<div class="loglist-title BG MB10 <?php echo $Tcon['Te-wow'];?>">
				当前位置：<a href="<?php echo BLOG_URL;?>">首页</a>&nbsp;>&nbsp;<?php if($params[1]=='sort'){?><?php echo '<a href="'.Url::sort($sortid).'">'.$sortName.'</a>';?><?php }elseif ($params[1]=='tag'){?>包含标签 <b><?php echo htmlspecialchars(urldecode($params[2]));?></b> 的所有文章<?php }elseif($params[1]=='author'){?>作者 <b><?php echo blog_author($author);?></b> 的所有文章<?php }elseif($params[1]=='keyword'){?>搜索 <b><?php echo htmlspecialchars(urldecode($params[2]));?></b> 的结果<?php }elseif($params[1]=='record'){?>正在查看 “<b><?php echo $params[2];?>” 年月的文章</b><?php }?>
			</div>
<?php
if (!empty($logs)){
foreach($logs as $key=>$value): 
$search_pattern = '%<img[^>]*?src=[\'\"]((?:(?!\/admin\/|>).)+?)[\'\"][^>]*?>%s';
preg_match($search_pattern, $value['content'], $img);
$value['img'] = isset($img[1])?$img[1]:TEMPLATE_URL.'CLASS/IMG/default.png';
	if($Tcon['Te-color'] == '1'){
		$value['img'] = isset($img[1])?$img[1]:TEMPLATE_URL.'CLASS/IMG/default11.png';
		$loading = TEMPLATE_URL.'CLASS/IMG/loading11.png';
	}else{
		$value['img'] = isset($img[1])?$img[1]:TEMPLATE_URL.'CLASS/IMG/default12.png';
		$loading = TEMPLATE_URL.'CLASS/IMG/loading12.png';
	}
?>
			<div class="loglist-box BG <?php echo $Tcon['Te-wow'];?>">
				<a href="<?php echo $value['log_url'];?>" class="llbox-img Left"><img src="<?php echo $loading;?>" data-original="<?php echo $value['img'];?>" alt="<?php echo $value['log_title'];?>"></a>
				<div class="llbox-con Right">
					<div class="llbox-title">
						<?php if($value['sortop'] == 'y'){?><span class="lltitle1">分类置顶</span><?php }?>
						<?php blog_sort($value['logid']);?>
						<a href="<?php echo $value['log_url'];?>" class="lltitle3"><?php echo $value['log_title'];?></a>
					</div>
					<div class="llbox-text"><?php if(!empty($value['log_description'])){echo subString(strip_tags($value['log_description']),0,100,"...");}else{echo "此作者很懒，没有为文章撰写内容呦！";}?></div>
					<div class="llbox-other">
						<span class="llo1"><i class="fa fa-user-circle"></i> 作者：<?php blog_author($value['author']);?></span>
						<span class="llo2"><i class="fa fa-eye"></i> 围观：<?php echo $value['views'];?></span>
						<span class="llo3"><i class="fa fa-clock-o"></i> 时间：<?php echo date('Y-n-j',$value['date']);?></span>
						<span class="llo4"><i class="fa fa-comments-o"></i> 评论：<?php echo $value['comnum'];?></span>
					</div>
				</div>
			</div>
<?php endforeach;?>
			<div class="Telib-page <?php echo $Tcon['Te-wow'];?>">
				<?php echo Telib_page($lognum,$index_lognum,$page,$pageurl);?>
			</div>
<?php }?>
		</div>
		<div class="loglist-2 Right">
<?php include view::getView('side');?>
		</div>
	</div>
<?php include view::getView('footer');?> 