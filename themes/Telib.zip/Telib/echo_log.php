<?php
/**
 * 文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
$page = isset($params[5])?intval($params[5]):1;
if(BLOG_URL.trim(Dispatcher::setPath(),'/') != Url::log($logid) && $page == 1 && $p == ''){
	header('HTTP/1.1 301 Moved Permanently');
	header('Location:'.Url::log($logid));
}
?>
	<div class="echolog Mauto">
		<div class="echolog-con">
			<div class="echolog-1 Left">
				<div class="loglist-title MB10 BG <?php echo $Tcon['Te-wow'];?>">当前位置：<a href="<?php echo BLOG_URL;?>">首页</a>&nbsp;>&nbsp;<?php blog_sort1($logid);?>&nbsp;>&nbsp;详情</div>
				<div class="echolog-wapper MB10 BG <?php echo $Tcon['Te-wow'];?>">
					<div class="echolog-title">
						<div class="echolog-title1"><?php echo $log_title;?></div>
						<div class="echolog-title2">
							<span class="elt1">分类：<?php blog_sort1($logid);?></span>
							<span class="elt2">时间：<?php echo date('Y-n-j',$date);?></span>
							<span class="elt3">围观：<?php echo $views;?></span>
							<span class="elt4"></span>
						</div>
					</div>
					<div class="echolog-content"><?php echo $log_content;?></div>
					<?php doAction('down_log',$logid);?>
					<div class="echolog-end"><div class="echolog-end1"><div class="echolog-end2">THE END</div></div></div>
					<div class="echolog-other">免责声明：本文由本站撰写发布，但不代表本站的观点和立场。</div>
				</div>
<?php
$Log_Model = new Log_Model();
$log = $Log_Model -> getLogsForHome("AND sortid = $sortid and gid != $logid ORDER BY views ASC",0,4);
/*判断是否有相邻文章开始*/
if($log){
?>
				<div class="echolog-link MB10 BG <?php echo $Tcon['Te-wow'];?>">
					<div class="echolog-link1">
						<div class="newtitle"><h3 class="newtitle-l Left">相关推荐：</h3></div>
						<ul>
<?php 
$i=0;
foreach($log as $value){
$i++;
$time = date('Y-m-d',$value['date']);
	$img_url = '';
	if(pic_thumb($value['content'])){
		$img_url = pic_thumb($value['content']);
	}elseif(picthumb($value['gid'])){
		$img_url = picthumb($value['gid']);
	}else{
		if($Tcon['Te-color'] == '1'){
			$img_url = TEMPLATE_URL.'CLASS/IMG/default11.png';
			$loading = TEMPLATE_URL.'CLASS/IMG/loading11.png';
		}else{
			$img_url = TEMPLATE_URL.'CLASS/IMG/default12.png';
			$loading = TEMPLATE_URL.'CLASS/IMG/loading12.png';
		}
	}
?>
							<li><a href="<?php echo $value['log_url'];?>"><img src="<?php echo $loading;?>" data-original="<?php echo $img_url;?>" alt=""><h4><?php echo $value['log_title'];?></h4><time><?php echo $time;?></time></a></li>
<?php }?>
						</ul>
					</div>
					<div class="echolog-link2 ClearFix">
						<?php neighbor_log($neighborLog);?>
					</div>
				</div>
<?php }/*判断是否有相邻文章结束*/?>
<?php if($allow_remark == 'y'): ?>
				<div class="echolog-common ClearFix BG <?php echo $Tcon['Te-wow'];?>">
					<div class="newtitle"><h3 class="newtitle-l Left">评论：</h3></div>
					<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);?>
				</div>
<?php endif;?>
				<?php blog_comments($comments);?>
			</div>
			<div class="echolog-2 Right">
<?php include view::getView('side');?>
			</div>
		</div>
	</div>
<?php include View::getView('footer');?>