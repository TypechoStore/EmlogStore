<?php
/**
 * 模板设置
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
date_default_timezone_set('Asia/Shanghai');
?>
<?php
//widget：blogger
function widget_blogger($title){
	global $Tcon;
$db = Database::getInstance();
$sta_cache = array();
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "user WHERE role = 'admin'");
$blog_admin = $data['total'];
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "blog WHERE  top = 'y' or sortop = 'y' AND type = 'blog'");
$log_top = $data['total'];
$data = $db->once_fetch_array('SELECT COUNT(*) AS total FROM ' . DB_PREFIX . 'blog WHERE type = \'blog\'');
$log_total = $data['total'];
$data = $db->once_fetch_array('SELECT COUNT(*) AS total FROM ' . DB_PREFIX . 'comment');
$log_com = $data['total'];
$data = $db->once_fetch_array('SELECT COUNT(*) AS total FROM ' . DB_PREFIX . 'link');
$log_link = $data['total'];
$data = $db->once_fetch_array('SELECT COUNT(*) AS total FROM ' . DB_PREFIX . 'sort');
$log_sort = $data['total'];
$data = $db->once_fetch_array('SELECT COUNT(*) AS total FROM ' . DB_PREFIX . 'tag');
$log_tag = $data['total'];
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "twitter");
$wei_yu = $data['total'];
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "blog WHERE type = 'page'");
$log_page = $data['total'];
$data = $db->once_fetch_array('SELECT COUNT(*) AS total FROM ' . DB_PREFIX . 'user');
$count_user = $data['total'];
$sql = 'SELECT * FROM ' . DB_PREFIX . 'blog WHERE type=\'blog\' ORDER BY date DESC LIMIT 0,1';
$res = $db->query($sql);
$row = $db->fetch_array($res);
$date = date('n月j日', $row['date']);
?>
			<div class="widget widget_blogger MB10 BG ClearFix <?php echo $Tcon['Te-wow'];?>">
				<h3><?php echo $title;?>：</h3>
				<div class="wbgger1"><?php echo $Tcon['Te-grzl1'];?></div>
				<div class="wbgger2"><?php echo $Tcon['Te-grzl2'];?></div>
				<ul>
					<li><span>文章</span><b><?php echo $log_total;?></b></li>
					<li><span>评论</span><b><?php echo $log_com;?></b></li>
					<li><span>微语</span><b><?php echo $wei_yu;?></b></li>
				</ul>
			</div>
<?php }?>
<?php
//widget：日历
function widget_calendar($title){
	global $Tcon;
?>
			<div class="widget widget_calendar MB10 BG ClearFix <?php echo $Tcon['Te-wow'];?>">
				<h3><?php echo $title;?>：</h3>
				<div id="calendar"></div>
				<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
			</div>
<?php }?>
<?php
//widget：标签
function widget_tag($title){
    global $CACHE;
	global $Tcon;
$tag_cache = array_slice($CACHE->readCache('tags'),0,50);?>
			<div class="widget widget_tag MB10 BG ClearFix <?php echo $Tcon['Te-wow'];?>">
				<h3><?php echo $title;?>：</h3>
				<ul>
<?php foreach($tag_cache as $value):?>
					<li><a title="<?php echo $value['usenum']; ?> 篇文章" href="<?php echo Url::tag($value['tagurl']); ?>"><?php echo $value['tagname']; ?> (<?php echo $value['usenum']; ?>)</a></li>
<?php endforeach; ?>
				</ul>
			</div>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	global $Tcon;
$sort_cache = $CACHE->readCache('sort'); ?>
			<div class="widget widget_sort MB10 BG ClearFix <?php echo $Tcon['Te-wow'];?>">
				<h3><?php echo $title;?>：</h3>
				<ul>
<?php
foreach($sort_cache as $value):
if ($value['pid'] != 0) continue;
?>
					<li>
						<a href="<?php echo Url::sort($value['sid']); ?>" title="<?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
<?php if (!empty($value['children'])): ?>
						<ul style="display:none">
<?php
$children = $value['children'];
foreach ($children as $key):
$value = $sort_cache[$key];
?>
							<li>
								<a href="<?php echo Url::sort($value['sid']); ?>" title="<?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
							</li>
<?php endforeach; ?>
						</ul>
				</li>
<?php endif; ?>
<?php endforeach; ?>
				</ul>
			</div>
<?php }?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE;
	global $Tcon;
	$record_cache = $CACHE->readCache('record');
?>
			<div class="widget widget_archive MB10 BG ClearFix <?php echo $Tcon['Te-wow'];?>">
				<h3><?php echo $title;?>：</h3>
				<ul>
<?php foreach($record_cache as $value): ?>
					<li><a href="<?php echo Url::record($value['date']); ?>" title="<?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
<?php endforeach;?>
				</ul>
			</div>
<?php }?>
<?php
//widget：最新微语
function widget_twitter($title){
	global $CACHE; 
	global $Tcon;
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
?>
			<div class="widget widget_twitter MB10 BG ClearFix <?php echo $Tcon['Te-wow'];?>">
				<h3><?php echo $title;?>：</h3>
				<ul>
<?php foreach($newtws_cache as $value):?>
<?php $img = empty($value['img']) ? "" : '<a title="查看图片" class="t_img" href="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" target="_blank">&nbsp;</a>';?>
					<li class="ClearFix">
						<div class="widget_twitter_1"><?php echo subString(strip_tags($value['t']),0,31,"..."); ?><?php echo $img;?></div>
						<div class="widget_twitter_2">
							<span class="Left"><?php echo smartDate($value['date']);?></span>
<?php if ($istwitter == 'y') :?>
							<span class="Right"><a href="<?php echo BLOG_URL . 't/'; ?>">更多 <i class="fa fa-plus-circle"></i></a></span>
<?php endif;?>
						</div>
					</li>
<?php endforeach;?>

				</ul>
			</div>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE;
	global $Tcon;
	$com_cache = $CACHE->readCache('comment');
?>
			<div class="widget widget_newcomm MB10 BG ClearFix <?php echo $Tcon['Te-wow'];?>">
				<h3><?php echo $title;?>：</h3>
				<ul>
<?php
foreach($com_cache as $value):
$url = Url::comment($value['gid'], $value['page'], 'comment-' . $value['cid']);
?>
					<li><a href="<?php echo $url; ?>" title="来自《<?php echo $value['name'];?>》的评论"><time><?php echo sydate($value['date'],true);?></time><h4><?php echo $value['name'];?></h4><?php echo showPrivateComment($value['content'],$value['mail'],$_COOKIE["postermail"]);?></a></li>
<?php endforeach; ?>
				</ul>
			</div>
<?php }?>
<?php
//widget：最新文章
function widget_newlog($title){
	global $CACHE;
	global $Tcon;
	$newLogs_cache = $CACHE->readCache('newlog');
?>
			<div class="widget widget_newlog MB10 BG ClearFix <?php echo $Tcon['Te-wow'];?>">
				<h3><?php echo $title;?>：</h3>
				<ul>
<?php foreach($newLogs_cache as $value): 
	$thum_src = getThumbnail($value['gid']);
	$imgsrc = getimgforgid($value['gid']);
 	if($thum_src){
 		$img = $thum_src;
	}elseif($imgsrc){
		$img = $imgsrc;
	}else{
		if($Tcon['Te-color'] == '1'){
			$img = TEMPLATE_URL.'CLASS/IMG/default11.png';
			$loading = TEMPLATE_URL.'CLASS/IMG/loading11.png';
		}else{
			$img = TEMPLATE_URL.'CLASS/IMG/default12.png';
			$loading = TEMPLATE_URL.'CLASS/IMG/loading12.png';
		}
	}
?>
					<li class="ClearFix">
						<div class="widget_log_1"><a href="<?php echo Url::log($value['gid']);?>"><img src="<?php echo $loading;?>" data-original="<?php echo $img;?>" alt="<?php echo $value['title']; ?>"></a></div>
						<div class="widget_log_2">
							<a href="<?php echo Url::log($value['gid']);?>"><?php echo subString(strip_tags($value['title']),0,23,"...");?></a>
							<span><?php echo gettime($value['gid']);?></span>
						</div>
					</li>
<?php endforeach; ?>
				</ul>
			</div>
<?php }?>
<?php
//widget：热门文章
function widget_hotlog($title){
	global $Tcon;
	$index_hotlognum = Option::get('index_hotlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getHotLog($index_hotlognum);
?>
			<div class="widget widget_hotlog MB10 BG ClearFix <?php echo $Tcon['Te-wow'];?>">
				<h3><?php echo $title;?>：</h3>
				<ul>
<?php foreach($randLogs as $value): 
	$thum_src = getThumbnail($value['gid']);
	$imgsrc = getimgforgid($value['gid']);
 	if($thum_src){
 		$img = $thum_src;
	}elseif($imgsrc){
		$img = $imgsrc;
	}else{
		if($Tcon['Te-color'] == '1'){
			$img = TEMPLATE_URL.'CLASS/IMG/default11.png';
			$loading = TEMPLATE_URL.'CLASS/IMG/loading11.png';
		}else{
			$img = TEMPLATE_URL.'CLASS/IMG/default12.png';
			$loading = TEMPLATE_URL.'CLASS/IMG/loading12.png';
		}
	}
?>
					<li class="ClearFix">
						<div class="widget_log_1"><a href="<?php echo Url::log($value['gid']);?>"><img src="<?php echo $loading;?>" data-original="<?php echo $img;?>" alt="<?php echo $value['title']; ?>"></a></div>
						<div class="widget_log_2">
							<a href="<?php echo Url::log($value['gid']);?>"><?php echo subString(strip_tags($value['title']),0,23,"...");?></a>
							<span><?php echo gettime($value['gid']);?></span>
						</div>
					</li>
<?php endforeach; ?>
				</ul>
			</div>
<?php }?>
<?php
//widget：随机文章
function widget_random_log($title){
	global $Tcon;
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);
?>
			<div class="widget widget_random_log MB10 BG ClearFix <?php echo $Tcon['Te-wow'];?>">
				<h3><?php echo $title;?>：</h3>
				<ul>
<?php foreach($randLogs as $value): 
	$thum_src = getThumbnail($value['gid']);
	$imgsrc = getimgforgid($value['gid']);
 	if($thum_src){
 		$img = $thum_src;
	}elseif($imgsrc){
		$img = $imgsrc;
	}else{
		if($Tcon['Te-color'] == '1'){
			$img = TEMPLATE_URL.'CLASS/IMG/default11.png';
			$loading = TEMPLATE_URL.'CLASS/IMG/loading11.png';
		}else{
			$img = TEMPLATE_URL.'CLASS/IMG/default12.png';
			$loading = TEMPLATE_URL.'CLASS/IMG/loading12.png';
		}
	}
?>
					<li class="ClearFix">
						<div class="widget_log_1"><a href="<?php echo Url::log($value['gid']);?>"><img src="<?php echo $loading;?>" data-original="<?php echo $img;?>" alt="<?php echo $value['title']; ?>"></a></div>
						<div class="widget_log_2">
							<a href="<?php echo Url::log($value['gid']);?>"><?php echo subString(strip_tags($value['title']),0,23,"...");?></a>
							<span><?php echo gettime($value['gid']);?></span>
						</div>
					</li>
<?php endforeach; ?>
				</ul>
			</div>
<?php }?>
<?php
//widget：搜索
function widget_search($title){
	global $Tcon;
?>
			<div class="widget widget_search MB10 BG ClearFix <?php echo $Tcon['Te-wow'];?>">
				<h3><?php echo $title;?>：</h3>
				<form action="<?php echo BLOG_URL; ?>index.php" method="get">
					<input name="keyword" value="关键词为2个字搜索最精准" onblur="if(this.value==''){this.value='关键词为2个字搜索最精准';}" onfocus="if(this.value=='关键词为2个字搜索最精准'){this.value=''}" class="widget_search_cha" type="text">
					<input value="搜索" class="widget_search_dian" type="submit">
				</form>
			</div>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE;
	global $Tcon;
	$link_cache = $CACHE->readCache('link');
    //if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
	?>
			<div class="widget widget_link MB10 BG ClearFix <?php echo $Tcon['Te-wow'];?>">
				<h3><?php echo $title;?>：</h3>
				<ul>
<?php foreach($link_cache as $value):?>
					<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
<?php endforeach; ?>
				</ul>
			</div>
<?php }?>
<?php
//获取头像
function getqqpic($email){
	$qq = explode('@',$email);
            $pic = 'https://q2.qlogo.cn/headimg_dl?dst_uin='.$qq[0].'&spec=100';
            $pic = $qq[1] =='qq.com' ? $pic : $pic = getGravatar($email);
	return $pic;
}
//获取附件第一张图片
function getThumbnail($blogid){
    $db = Database::getInstance();
    $sql = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$blogid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";
    //die($sql);
    $imgs = $db->query($sql);
    $img_path = "";
	if($db->num_rows($imgs)){
		while($row = $db->fetch_array($imgs)){
			 $img_path .= BLOG_URL.substr($row['filepath'],3,strlen($row['filepath']));
		}
	}else{
		$img_path = false;
	}
    return $img_path;
}
//数据库报错用
function getimgforgid($gid){
    $db = Database::getInstance();
    $sql = 'SELECT content FROM ' . DB_PREFIX . "blog WHERE gid='".$gid."'";
	$d = $db->once_fetch_array($sql);

	return isset($d['content']) && preg_match("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $d['content'], $img) ? $img[1] : false;
}
function getimgforgids($gid){
    $db = Database::getInstance();
    $sql = 'SELECT * FROM ' . DB_PREFIX . "blog WHERE gid='".$gid."'";
    $img = $db->query($sql);
	$imgsrc = false;
	if($img){
		while ($row = $db->fetch_array($img)) {
			$content = $row['content'];
			$imgsrc = preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $content, $img);
			$imgsrc = !empty($img[1]) ? $img[1][0] : '';
		}
	}
    return $imgsrc;
}
//获取文章时间
function gettime($id){
	$db = Database::getInstance();
	$sql = 'SELECT * FROM ' . DB_PREFIX . "blog WHERE gid='".$id."'";
	$date = $db->query($sql);
	while ($row = $db->fetch_array($date)) {
		$time = date('Y-m-d',$row['date']);
	}
	return $time;
}
function sydate($ptime,$isunix=false){
	if(!$isunix){
		$ptime = strtotime($ptime);
	}
	$etime = time() - $ptime;
	if($etime < 1){return '刚刚';}
	$interval = array(
		12 * 30 * 24 * 60 * 60 => '年前 ('.date('Y-m-d', $ptime).')',
		30 * 24 * 60 * 60      => '个月前 ('.date('Y-m-d', $ptime).')',
		7 * 24 * 60 * 60       => '周前 ('.date('Y-m-d', $ptime).')',
		24 * 60 * 60           => '天前',
		60 * 60                => '小时前',
		60                     => '分钟前',
		1                      => '秒前',
	);
foreach ($interval as $secs => $str) {
		$d = $etime / $secs;
		if ($d >= 1){
			$r = round($d);
			return $r . $str ;
		}
	}
}
?>
<?php
//随机文章
function getRandLog($log_num) {
$db = Database::getInstance();
$sql = "SELECT gid,title,comnum FROM ".DB_PREFIX."blog WHERE type='blog' and hide='n' ORDER BY rand() LIMIT 0,$log_num";
$list = $db->query($sql);
while($row = $db->fetch_array($list)){ ?>
<li class="layout_li"><strong>[<?php echo gettime($row['gid']);?>]</strong><a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>"><span>荐</span><?php echo $row['title']; ?></a></li>
<?php }?>
<?php }?>
<?php
//blog：PC端导航
function blog_navpc(){
global $CACHE;
global $Tcon;
$navi_cache = $CACHE->readCache('navi');
?>
			<ul>
<?php
foreach($navi_cache as $value):
$id=$value["id"];
if ($value['pid'] != 0) {continue;}
$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
$value['url'] = $value['isdefault'] == 'y' ? Option::get('blogurl') . $value['url'] : trim($value['url'], '/');
//if (!strstr(strtolower($value['url']),'http://')){$value['url'] = Option::get('blogurl') . $value['url'];}
$current_tab = Option::get('blogurl') . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'item' : 'common';
?>
				<li class="Left <?php echo $current_tab;?>"><a href="<?php echo $value['url'];?>" <?php echo $newtab;?>><?php if(empty($Tcon['Te-navico'][$id])) {echo $value['naviname'];}else {echo "<i class='fa ".$Tcon['Te-navico'][$id]."'></i> ".$value['naviname']."";} ?></a><?php if (!empty($value['children'])) :?><ul class="s-nav BG"><?php foreach ($value['children'] as $row):?><li><a href="<?php echo Url::sort($row['sid']);?>"><?php if(empty($Tcon['Te-sortico'][$row['sid']])) {echo $row['sortname'];}else {echo "<i class='fa ".$Tcon['Te-sortico'][$row['sid']]."'></i> ".$row['sortname']."";} ?></a></li><?php endforeach;?></ul><?php endif;?><?php if (!empty($value['childnavi'])) :?><ul class="s-nav BG"><?php foreach ($value['childnavi'] as $row): $newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';?><li><a href="<?php echo $row['url'];?>" <?php echo $newtab;?>><?php if(empty($Tcon['Te-sortico'][$row['sid']])) {echo $row['sortname'];}else {echo "<i class='fa ".$Tcon['Te-sortico'][$row['sid']]."'></i> ".$row['sortname']."";} ?></a></li><?php endforeach;?>
					</ul><?php endif;?></li>
<?php endforeach; ?>
			</ul>
<?php }?>
<?php
//blog：手机端导航
function blog_navm(){
global $CACHE;
global $Tcon;
$navi_cache = $CACHE->readCache('navi');
?>
	<ul>
<?php
foreach($navi_cache as $value):
$id=$value["id"];
if ($value['pid'] != 0) {continue;}
$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
$value['url'] = $value['isdefault'] == 'y' ? Option::get('blogurl') . $value['url'] : trim($value['url'], '/');
//if (!strstr(strtolower($value['url']),'http://')){$value['url'] = Option::get('blogurl') . $value['url'];}
$current_tab = Option::get('blogurl') . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'item' : 'common';

?>
		<li class="Left <?php echo $current_tab;?><?php if (!empty($value['children']) || !empty($value['childnavi'])){echo ' nav-mdown';}?>"><a href="<?php echo $value['url'];?>" <?php echo $newtab;?>><?php if(empty($Tcon['Te-navico'][$id])) {echo $value['naviname'];}else {echo "<i class='fa ".$Tcon['Te-navico'][$id]."'></i> ".$value['naviname']."";} ?></a><?php if (!empty($value['children'])):?><ul class="nav-m1"><?php foreach ($value['children'] as $row):?><li><a href="<?php echo Url::sort($row['sid']);?>"><?php if(empty($Tcon['Te-sortico'][$row['sid']])) {echo $row['sortname'];}else {echo "<i class='fa ".$Tcon['Te-sortico'][$row['sid']]."'></i> ".$row['sortname']."";} ?></a></li><?php endforeach;?></ul><?php endif;?><?php if (!empty($value['childnavi'])):?><ul class="nav-m1"><?php foreach ($value['childnavi'] as $row): $newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';?><li><a href="<?php echo $row['url'];?>" <?php echo $newtab;?>><?php if(empty($Tcon['Te-sortico'][$row['sid']])) {echo $row['sortname'];}else {echo "<i class='fa ".$Tcon['Te-sortico'][$row['sid']]."'></i> ".$row['sortname']."";} ?></a></li><?php endforeach;?></ul><?php endif;?></li>
<?php endforeach; ?>
	</ul>
<?php }?>
<?php
//getimage
function picthumb($blogid) {
$db = Database::getInstance();
$sql = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$blogid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";
//    die($sql);
$imgs = $db->query($sql);
while($row = $db->fetch_array($imgs)){
$pict.= ''.BLOG_URL.substr($row['filepath'],3,strlen($row['filepath'])).'';
}
return $pict;
}
?>
<?php
//getimageurl
function pic_thumb($content){
preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $content, $img);
$imgsrc = !empty($img[1]) ? $img[1][0] : '';
if($imgsrc):
return $imgsrc;
endif;
}
?>
<?php
//blog：首页幻灯
function blog_wp($sort, $num,$lastday=0){
	global $Tcon;
    $db = Database::getInstance();    
    $where = "hide='n' AND checked='y'";
    if($sort){
        $sort = explode(',',$sort);
        $sort = array_map("intval",$sort);
        $where .= " AND sortid IN(".join(',',$sort).") ";
    }
    if($lastday){
        $where .= " AND date>='".(time()-$lastday*86400)."'";
    }
    $sql = "SELECT * FROM ".DB_PREFIX."blog WHERE $where ORDER BY `date` DESC LIMIT 0,$num";
    $go = $db->query($sql);
    while($row = $db->fetch_array($go)){
        $img_url = '';
        if(pic_thumb($row['content'])){
            $img_url = pic_thumb($row['content']);
        }
        elseif(picthumb($row['gid'])){
            $img_url = picthumb($row['gid']);
        }else{
        	if($Tcon['Te-color'] == '1'){
				$img_url = TEMPLATE_URL.'CLASS/IMG/default21.png';	
			}else{
				$img_url = TEMPLATE_URL.'CLASS/IMG/default22.png';
			}
        }
        if($Tcon['Te-color'] == '1'){
        	$loading = TEMPLATE_URL.'CLASS/IMG/loading21.png';
        }else{
        	$loading = TEMPLATE_URL.'CLASS/IMG/loading22.png';
        }
        ?>
						<li><div><h3><?php echo $row['title']; ?></h3></div><a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>"><img src="<?php echo $loading;?>" data-original="<?php if(!empty($row['thumbs'])){echo $row['thumbs'];}else{echo $img_url;}?>" alt="<?php echo $row['title']; ?>"/></a></li>
<?php }?>
<?php }?>
<?php
//blog：首页CMS最新文章
function blog_cms_newlog(){
	$Log_Model = new Log_Model();
	$today = strtotime(date('Y-m-d'));
	$today_sql = "and date>$today";
	$today_num = $Log_Model->getLogNum('n', $today_sql);
	$db = Database::getInstance();
	$number = 22;
	$sql = "SELECT gid,title,content,top,date FROM ".DB_PREFIX."blog WHERE type='blog' AND checked='y' AND hide='n' ORDER BY `top` DESC,`date` DESC LIMIT 0,$number";
	$list = $db->query($sql);
	$id = 0;
	while($row = $db->fetch_array($list) or $row1 = $db->fetch_array($list1)){
    	$id++;
		$time = date('m-d',$row['date']);
?>
					<li><strong><?php echo $time;?></strong><a href="<?php echo Url::log($row['gid']);?>" title="<?php echo $row['title'];?>"><span><?php echo $id;?></span><?php echo $row['title'];?></a></li>
<?php } ?>
<?php } ?>
<?php
//blog：首页CMS列表
function blog_cmslist($sort){
	global $Tcon;
	$db = Database::getInstance();
	$sql1 = "SELECT sortname FROM ".DB_PREFIX."sort WHERE sid=".$sort;
	$s = $db->query($sql1);
	$sortname = $db->fetch_array($s);
?>
				<div class="index-cms1-list Left BG <?php echo $Tcon['Te-wow'];?>">
					<div class="newtitle">
						<h3 class="newtitle-l Left"><?php if($sortname['sortname'] == ''){echo '暂未分配';}else{echo $sortname['sortname'];}?></h3>
						<a href="<?php echo Url::sort($sort);?>" class="Right">更多 <i class="fa fa-plus-circle"></i></a>
						<div class="newtitle-bb"></div>
					</div>
					<ul>
<?php
	$result = $db->query("SELECT * FROM ".DB_PREFIX."sort WHERE sid=".$sort ." or pid='$sort'");
	$all = array();
	while ($row = $db->fetch_array($result)){
		$all[] = $row;
	}
	$sorts = array();
	$sortids = array();
	foreach($all as $v){
		$sorts[$v['sid']] = $v;
		$sortids[] = $v['sid'];
	}
	if(!$sortids){
		$sortids[] = 0;
	}
	$sql2 = "SELECT gid,title,top,date,sortid FROM ".DB_PREFIX."blog WHERE sortid in(".  join(",", $sortids).") AND checked='y' AND hide='n' ORDER BY `date` DESC LIMIT 6";
	$list = $db->query($sql2);
    $id = 0;
	while($row = $db->fetch_array($list)){
		$sort = isset($sorts[$row['sortid']])?$sorts[$row['sortid']]:array();
		$id++;
		$time = date('m-d',$row['date']);
?>
						<li><strong><?php echo $time;?></strong><a href="<?php echo Url::log($row['gid']);?>"><span><?php echo $id;?></span><?php echo $row['title'];?></a></li>
<?php }?>
					</ul>
				</div>
<?php } ?>
<?php 
//blog：分页函数
function Telib_page($count,$perlogs,$page,$url,$anchor=''){
	$pnums = @ceil($count / $perlogs);
	$page = @min($pnums,$page);
	$prepg=$page-1;
	$nextpg=($page==$pnums ? 0 : $page+1);
	$urlHome = preg_replace("|[\?&/][^\./\?&=]*page[=/\-]|","",$url);
	$re = "";
	if($pnums<=1) return false;
	if($page!=1) $re .=" <a href=\"$urlHome$anchor\" title=\"首页\" class=\"Tpage1\">首页</a> ";
	if($prepg) $re .=" <a href=\"$url$prepg$anchor\" title=\"上一页\" class=\"Tpage2\">上一页</a> ";
	for ($i = $page-2;$i <= $page+2 && $i <= $pnums; $i++){
		if ($i > 0){if ($i == $page){
			$re .= " <span class=\"Tspan1\">$i</span> ";
		}elseif($i == 1){
			$re .= " <a href=\"$urlHome$anchor\" title=\"$i\" class=\"Tpage3\">$i</a> ";
		}else{
			$re .= " <a href=\"$url$i$anchor\" title=\"$i\" class=\"Tpage3\">$i</a> ";}
		}
	}
	if($nextpg) $re .=" <a href=\"$url$nextpg$anchor\" title=\"下一页\" class=\"Tpage4\">下一页</a> "; 
	if($page!=$pnums) $re.=" <a href=\"$url$pnums$anchor\" title=\"尾页\"  class=\"Tpage5\">尾页</a>";
	return '<div class="Telib-page1">' . $re . '</div>';
}
?>
<?php
//blog：列表分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
?>
<?php if(!empty($log_cache_sort[$blogid])){?><a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']);?>" class="lltitle2"><?php echo $log_cache_sort[$blogid]['name'];?></a><?php }else{echo '<a class="lltitle2">无分类</a>';};?>
<?php }?>
<?php
//blog：列表分类1
function blog_sort1($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
?>
<?php if(!empty($log_cache_sort[$blogid])){?><a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']);?>"><?php echo $log_cache_sort[$blogid]['name'];?></a><?php }else{echo '<a>无分类</a>';};?>
<?php }?>
<?php
//blog：文章作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
extract($neighborLog);?>
<?php if($prevLog){?>
<a href="<?php echo Url::log($prevLog['gid']) ?>" title="<?php echo $prevLog['title'];?>" class="ellink Left">上一篇：<span><?php echo $prevLog['title'];?></span></a>
<?php }else{ ?>
<a href="javascript:alert('没有上一篇啦！');" title="没有上一篇啦！" class="ellink Left">没有上一篇啦！</a>
<?php }?>
<?php if($nextLog && $prevLog):?>
<?php endif;?>
<?php if($nextLog){?>
<a href="<?php echo Url::log($nextLog['gid']) ?>" title="<?php echo $nextLog['title'];?>" class="ellink Right">下一篇：<span><?php echo $nextLog['title'];?></span></a>
<?php }else{?>
<a href="javascript:alert('没有下一篇啦！');" title="没有下一篇啦！" class="ellink Right">没有下一篇啦！</a>
<?php }?>
<?php }?>
<?php
//blog：评论列表
function blog_comments($comments){
	global $Tcon;
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	extract($comments);
	$isGravatar = Option::get('isgravatar');
	foreach($commentStacks as $cid):
    	$comment = $comments[$cid];
		$user_role='';
		foreach($user_cache as $k => $a){
			$role = $a["role"];
			$name = $a["name"];
			$mail = $a["mail"];
			if($comment['poster'] == $name && $comment['mail'] == $mail){
				if($role == "admin"){$user_role = '<span class="comment-userpic">站长</span>';}
				if($role == "writer"){$user_role = '<span class="comment-userpic1">作者</span>';}
				break;
			}
		}
		if(empty($user_role)){$user_role = '<span class="comment-userpic2">游客</span>';}
		$isNofollow = $comment['url'] && $comment['url'] != BLOG_URL ? 'rel="nofollow"':'';
		$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank"  '.$isNofollow.'>'.$comment['poster'].'</a>' : $comment['poster'];
?>
	<div class="comment BG ClearFix <?php echo $Tcon['Te-wow'];?>" id="comment-<?php echo $comment['cid']; ?>">
		<div class="comment-con">
			<div class="comment-info">
<?php if($isGravatar == 'y'): ?>
				<div class="avatar Left"><img src="<?php echo GetQPic($comment['mail']);?>" /></div>
<?php endif; ?>
				<div class="cinfo Right">
					<b><?php echo $comment['poster']; ?></b>
					<?php echo $user_role;?>
					<span class="comment-time"><?php echo $comment['date']; ?></span>
					<span class="comment-reply"><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a></span>
					<div class="comment-content"><?php echo showPrivateComment($comment['content'],$comment['mail'],$_COOKIE["postermail"]);?></div>
				</div>
			</div>
		</div>
		<?php blog_comments_children($comments, $comment['children']); ?>
	</div>
	<?php endforeach; ?>
    <div class="Telib-page <?php echo $Tcon['Te-wow'];?>">
<?php if($commentPageUrl):?>
		<style>.echolog-1 .comment:nth-last-child(2){margin-bottom: 10px;}</style>
    	<div class="Telib-page1">
    		<?php echo $commentPageUrl;?>
    	</div>
<?php endif;?>
    </div>
<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
		$comment = $comments[$child];
		$user_role='';
		foreach($user_cache as $k => $a){
			$role = $a["role"];
			$name = $a["name"];
			$mail = $a["mail"];
			if($comment['poster'] == $name && $comment['mail'] == $mail){
				if($role == "admin"){$user_role = '<span class="comment-userpic">站长</span>';}
				if($role == "writer"){$user_role = '<span class="comment-userpic1">作者</span>';}
				break;
			}
		}
		if(empty($user_role)){$user_role = '<span class="comment-userpic2">游客</span>';}
		$isNofollow = $comment['url'] && $comment['url'] != BLOG_URL ? 'rel="nofollow"':'';
		$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank"  '.$isNofollow.'>'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<div class="comment-children" id="comment-<?php echo $comment['cid']; ?>">
		<div class="comment-con1">
			<div class="comment-zpl comment-info">
<?php if($isGravatar == 'y'): ?>
				<div class="avatar Left"><img src="<?php echo GetQPic($comment['mail']);?>" /></div>
<?php endif; ?>
				<div class="cinfo Right">
					<b><?php echo $comment['poster']; ?> </b>
					<?php echo $user_role;?>
					<span class="comment-time"><?php echo $comment['date']; ?></span>
					<span class="comment-reply"><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a></span>
					<div class="comment-content"><?php echo showPrivateComment($comment['content'],$comment['mail'],$_COOKIE["postermail"]);?></div>
				</div>
			</div>
		</div>
		<?php blog_comments_children($comments, $comment['children']);?>
	</div>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
	<div id="comment-place">
	<div class="comment-post" id="comment-post">
		<div class="cancel-reply" id="cancel-reply" style="display:none"><a href="javascript:void(0);" onclick="cancelReply()">取消回复</a></div>
		<form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
			<div class="comt">
				<textarea name="comment" id="comment" rows="10" tabindex="1"></textarea>
				<div class="comt-tips">
					<input type="hidden" name="gid" value="<?php echo $logid; ?>">
					<input type='hidden' name='pid' id='comment-pid' value='0'>
				</div>
				<div class="comt-sub">
					<a href="javascript:addNumber('[私密评论]')" class="comt-sub-a"><i class="fa fa-lock"></i></a>
					<span class="comterror"></span>
					<input type="submit" id="comment_submit" value="发表评论" tabindex="5">
<?php if(Option::get('comment_code') == 'y'){ ?>
					<span class="comyz"><?php echo $verifyCode;?></span>
<?php }?>
<?php if(SEND_MAIL == 'Y' || REPLY_MAIL == 'Y'){ ?>
					<input value="y" checked="checked" type="checkbox" name="send" style="display:none">
<?php }?>
				</div>
			</div>
<?php if(ROLE == ROLE_VISITOR):?>
			<div class="comment-list">
				<div class="comment-list1">
					<span><i class="fa fa-qq"></i></span>
					<input type="text" name="comqq" value="" placeholder="QQ号(快速获取信息)" tabindex="1">
				</div>
				<div class="comment-list1">
					<span><i class="fa fa-user"></i></span>
					<input type="text" name="comname" maxlength="49" value="<?php echo $ckname; ?>" placeholder="昵称(必填*)" tabindex="2">
				</div>
				<div class="comment-list1">
					<span><i class="fa fa-envelope"></i></span>
					<input type="text" name="commail"  maxlength="128"  value="<?php echo $ckmail; ?>" placeholder="邮箱(必填*)" tabindex="3">
				</div>
				<div class="comment-list1">
					<span><i class="fa fa-link"></i></span>
					<input type="text" name="comurl" maxlength="128"  value="<?php echo $ckurl; ?>" placeholder="网址" tabindex="4">
				</div>
			</div>	
<?php endif; ?>
		</form>
	</div>
	</div>
	<?php endif; ?>
<?php }?>
<?php 
// 判断是否为私密评论
function isPrivateComment($comments){
	return(strstr($comments,"[私密评论]"));
}
// 显示私密评论
function showPrivateComment($comments,$post_email,$current_email){
	// 如果是私密评论 是管理员身份或者发布私密者本身才会显示
	if(isPrivateComment($comments)){
		if($post_email===$current_email or ROLE == ROLE_ADMIN){
			return $comments;
		}else{
			return "<font color='#5298FF'>[ 私密评论仅博主可见 ]</font>";
		}
	}else{
		return $comments;
	}
}
?>
<?php
//blog：链接
function ilinks(){
global $CACHE; 
$link_cache = $CACHE->readCache('link');
//if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
?>
<?php foreach($link_cache as $value): ?>
				<li><a href="<?php echo $value['url'];?>" title="<?php if($value['des'] == ""){echo $value['link'];}else{echo $value['des'];}?>" target="_blank"><?php echo $value['link'];?></a></li>
<?php endforeach; ?>
<?php }?>
<?php
//blog：最新微语
function twitter($title){
global $CACHE; 
$newtws_cache = $CACHE->readCache('newtw');
$istwitter = Option::get('istwitter');
?>
<?php foreach($newtws_cache as $value): ?>
<?php $img = empty($value['img']) ? "" : '<a title="查看图片" class="t_img" href="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" target="_blank">&nbsp;</a>';?>
							<li><a href="<?php echo BLOG_URL . 't'; ?>" target="_blank"><?php echo $value['t']; ?><?php echo $img;?></a></li>
<?php endforeach; ?>
<?php }?>
<?php
//获取头像
function GetQPic($email){
	$QQ = explode('@',$email);
            $pic = 'https://q2.qlogo.cn/headimg_dl?dst_uin='.$QQ[0].'&spec=100';
            $pic = $QQ[1] == 'qq.com' ? $pic : $pic = BLOG_URL . 'avatar/default.jpg';
	return $pic;
}
?>