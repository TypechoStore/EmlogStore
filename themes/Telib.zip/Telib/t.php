<?php
/**
 * 微语页面
 */
if(!defined('EMLOG_ROOT')){exit('error!');}
?>
	<div class="Tother Mauto">
		<div class="Tother1 Left">
			<div class="loglist-title MB10 BG <?php echo $Tcon['Te-wow'];?>">当前位置：<a href="<?php echo BLOG_URL;?>">首页</a>&nbsp;>&nbsp;微语</div>
			<div class="Tother1-wapper ClearFix MB10 BG <?php echo $Tcon['Te-wow'];?>">
				<ul>
<?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    //$avatar = empty($user_cache[$val['author']]['avatar']) ? BLOG_URL . 'admin/views/images/avatar.jpg' : BLOG_URL . $user_cache[$val['author']]['avatar'];
    $avatar = GetQPic($user_cache[$val['author']]['mail']);
    $tid = (int)$val['id'];
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img src="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" class="tp" /></a>';
?>
					<li>
						<div class="twiter1 Left"><img src="<?php echo $avatar;?>" title="<?php echo "作者：" . $author;?>"></div>
						<div class="twiter2 Right">
							<span class="tsp1"><?php echo $val['t'].$img; ?></span>
							<span class="tsp2"><?php echo '条数：'.$tid.'&emsp;时间：'.$val['date'];?></span>
						</div>
					</li>
<?php endforeach;?>
				</ul>
			</div>
			<div class="Telib-page <?php echo $Tcon['Te-wow'];?>">
					<?php echo Telib_page($twnum,Option::get('index_twnum'),$page,BLOG_URL.'t/?page=');?>
			</div>
		</div>
		<div class="Tother2 Right">
			<?php include view::getView('side');?>
		</div>
	</div>
<?php include View::getView('footer');?>