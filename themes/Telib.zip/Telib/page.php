<?php
/*
Custom:page
Description:默认页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
$page = isset($params[5])?intval($params[5]):1;
if(BLOG_URL.trim(Dispatcher::setPath(),'/') != Url::log($logid) && $page == 1 && $p == ''){
	header('HTTP/1.1 301 Moved Permanently');
	header('Location:'.Url::log($logid));
}
?>
	<div class="echolog Mauto">
		<div class="echolog-con">
			<div class="echolog-1 Left">
				<div class="loglist-title MB10 BG <?php echo $Tcon['Te-wow'];?>">当前位置：<a href="<?php echo BLOG_URL;?>">首页</a>&nbsp;>&nbsp;<?php echo $log_title;?></div>
				<div class="echolog-wapper MB10 BG <?php echo $Tcon['Te-wow'];?>">
					<div class="echolog-title">
						<div class="echolog-title1"><?php echo $log_title;?></div>
					</div>
					<div class="echolog-content"><?php echo $log_content;?></div>
					<div class="echolog-end"><div class="echolog-end1"><div class="echolog-end2">THE END</div></div></div>
					<div class="echolog-other">免责声明：本文由本站撰写发布，但不代表本站的观点和立场。</div>
				</div>
<?php if($allow_remark == 'y'): ?>
				<div class="echolog-common ClearFix BG <?php echo $Tcon['Te-wow'];?>">
					<div class="newtitle"><h3 class="newtitle-l Left">评论：</h3></div>
					<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);?>
				</div>
<?php endif;?>
				<?php blog_comments($comments);?>
			</div>
			<div class="echolog-2 Right">
<?php include view::getView('side');?>
			</div>
		</div>
	</div>
<?php include View::getView('footer');?>