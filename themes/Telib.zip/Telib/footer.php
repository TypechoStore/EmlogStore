<?php
/**
 * 页脚页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
</div>
<div class="footer BG Clear">
	<div class="footer-text Mauto">
		<span>©&nbsp;2019&nbsp;<a href="<?php echo BLOG_URL;?>"><?php echo $blogname;?></a></span>
		<span id="copy">Theme&nbsp;by&nbsp;<a href="http://www.wuaif.com">Telib.</a></span>
		<div>
<?php if($footer_info):?>
			<span><?php echo $footer_info; ?></span>
<?php endif;?>
<?php if($icp):?>
			<span><a href="http://www.miitbeian.gov.cn/" target="_blank"><?php echo $icp;?></a></span>
<?php endif;?>
			<span><?php doAction('index_footer');?></span>
		</div>
	</div>
</div>
<script type="text/javascript">
/* ↓↓↓此代码为重要代码，改动出现问题概不负责↓↓↓ */
window.Telib = {
	blog_url: '<?php echo BLOG_URL; ?>',
	blog_turl: '<?php echo TEMPLATE_URL; ?>',
	blog_wow: '<?php echo $Tcon['Te-mktx'];?>',
	blog_ver: '1.2'
};
/* ↑↑↑此代码为重要代码，改动出现问题概不负责↑↑↑ */
</script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL;?>CLASS/JS/LAZY.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL;?>CLASS/JS/WOW.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL;?>CLASS/JS/SLID.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL;?>CLASS/JS/TEPIC.js"></script>
</body>
</html>