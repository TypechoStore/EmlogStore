<?php  
header('Content-type: text/css');   
include('style.css');
require_once '../../lib/set-con.php';//载入模板设置配置文件
$Tcon = unserialize($Tcon);
$GLOBALS['Tcon'] = $Tcon;
if($Tcon['Te-color'] == '2'):
?>
h6{background: #e4e4e4;}
body{background: #e9e9e9!important;}
.BG{background-color: #FFF;color: #333;}
.Hover, a{color: #333;}
.header1 .search input{border: 1px solid #666;}
.notice-ico .fa{background: #f00;color: #FFF;}
.newtitle-bb{border-bottom: 1px solid #e9e9e9;}
.newtitle .newtitle-l:after{border: 2px solid #f00;}
.Telib-link1 ul{background: #e9e9e9;}
.backtop a{background: #d9d9d9;color: #fff;}
.widget_blogger ul li{border-top: 1px solid #e9e9e9;border-left: 1px solid #e9e9e9;}
.widget_tag ul li a, .widget_sort ul li a, .widget_archive ul li a, .widget_link ul li a{background: #e9e9e9;}
.widget_search_cha{background: #e9e9e9;color: #333;}
.echolog-end2{background-color: #fff;}
#comment{background: #e9e9e9;color: #555;}
.comt-sub,.comt,.cancel-reply a,.twiter2{background: #e9e9e9;}
@media (max-width: 720px){.header1 .search{background: #fff;}}
.error{background: #e9e9e9;color: #333;}
.set-title1 input[type="text"], .set-title2 input[type="text"],.set-title1 select{background: #FFF;color: #333;}
.set-title1 textarea{background: #e9e9e9;color: #333;}
#index-wp2 ul#index-wp3 li > div{background: #e9e9e9;}
#index-wp2 ul#index-wp3 li > div h3{color: #333;}
#index-wp-num1 ul li{background: #333;}
.echolog-link1 ul li a time,.echolog-link1 ul li a h4,.widget_calendar .calendar .day{background: #e9e9e9;color: #333;}
.set-title1 textarea{background: #FFF;}
.index-cms ul li a span,.index-cms1-list ul li a span{background: #e4e4e4;color: #333;}
.echolog-content img{border: 2px solid #e4e4e4;}
.Tedown{background: #e4e4e4!important;}
.Tedown1-other p{color: #777!important;}
.Telib-page1 span{background: #fff;color: #5298FF;}
.Telib-page1 a, .Telib-page1 em{background: #d9d9d9;color: #333;}
.header1 .nav .s-nav li a{color: #333;}
.header1 .nav .s-nav li a:hover{background: #e4e4e4;}
@media (max-width: 1300px){.nav-m1 li a {background-color: #e4e4e4;color: #333;}}
.comment-list1 span,.comment-list1 input,.Tedown-title{background: #e4e4e4!important;}
<?php endif;?>