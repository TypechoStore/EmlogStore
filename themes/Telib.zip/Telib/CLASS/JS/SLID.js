/* 幻灯片 */
var pos = 0;
var totalSlides = $('#index-wp2 ul li').length;
var sliderWidth = $('#index-wp2').width();
$(document).ready(function(){
	$('#index-wp2 ul#index-wp3').width(sliderWidth*totalSlides);	
	$('#index-wp-next').click(function(){slideRight();});
	$('#index-wp-prev').click(function(){slideLeft();});
	var autoSlider = setInterval(slideRight, 3000);
	$.each($('#index-wp2 ul li'), function() { 
		var c = $(this).attr("data-color");
		$(this).css("background",c);
		var li = document.createElement('li');
		$('#index-wp-num1 ul').append(li);	   
	});
	countSlides();
	pagination();
	$('#index-wp2').hover(
		function(){ $(this).addClass('active'); clearInterval(autoSlider); }, 
		function(){ $(this).removeClass('active'); autoSlider = setInterval(slideRight, 3000); }
	);
});
function slideLeft(){
	pos--;
	if(pos==-1){ pos = totalSlides-1; }
	$('#index-wp2 ul#index-wp3').css('left', -(sliderWidth*pos)); 	
	countSlides();
	pagination();
}
function slideRight(){
	pos++;
	if(pos==totalSlides){ pos = 0; }
	$('#index-wp2 ul#index-wp3').css('left', -(sliderWidth*pos)); 
	countSlides();
	pagination();
}
function countSlides(){
	$('#index-wp-num').html(pos+1 + ' / ' + totalSlides);
}
function pagination(){
	$('#index-wp-num1 ul li').removeClass('active');
	$('#index-wp-num1 ul li:eq('+pos+')').addClass('active');
}
/* WOW特效代码 */
$i = Telib.blog_wow;
if($i > 0){
	wow = new WOW({
		boxClass:'wow',
		animateClass:'animated',
		offset:0,
		mobile:true,
		live:true
	});
	wow.init();
}