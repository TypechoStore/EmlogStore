<?php
/**
 * CMS模块页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
			<div class="index-cms BG MB10 <?php echo $Tcon['Te-wow'];?>">
				<div class="newtitle">
					<h3 class="newtitle-l Left">最近更新</h3>
					<div class="newtitle-r Right" data-total="<?php echo $sta_cache['lognum']; ?>">
						<i class="fa fa-angle-left Hover cms-prev"></i>
						<i class="fa fa-angle-right Hover cms-next"></i>
					</div>
					<div class="newtitle-bb"></div>
				</div>
				<ul>
<?php echo blog_cms_newlog('0');?>
				</ul>
			</div>
			<div class="index-cms1">
<?php
//CMS模块
$cmsid = explode(',',$Tcon['Te-cmsfl']);
$cmsnum = count($cmsid);
for($x = 0;$x < $cmsnum;$x++){blog_cmslist($cmsid[$x]);}
?>
			</div>
