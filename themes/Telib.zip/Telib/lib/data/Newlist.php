<?php
//域名授权开始
define('REFERER_URL', $_SERVER['HTTP_HOST']);//如：define('REFERER_URL', www.test.com|m.test.com|api.test.com'); 即可
$uriarr = parse_url($_SERVER['HTTP_REFERER']);
$host = $uriarr['host'];
$ymarr = explode("|",REFERER_URL);
if(in_array($host,$ymarr)){
?>
<?php 
/**
 * 首页无限获取最新文章 [模板:woaif]
 */
require_once '../../../../../init.php';
if(isset($_GET['startnum'])){
	$startnum = $_GET['startnum'];
	$Log_Model = new Log_Model();
	$today = strtotime(date('Y-m-d'));
	$today_sql = "and date>$today";
	$today_num = $Log_Model->getLogNum('n', $today_sql);
	$db = Database::getInstance();
	$sql = "SELECT gid,title,content,top,date FROM ".DB_PREFIX."blog WHERE type='blog' AND checked='y' AND hide='n' ORDER BY `top` DESC,`date` DESC LIMIT $startnum,22";
	//$sql = "SELECT gid,title,date,sortid,top FROM ".DB_PREFIX."blog WHERE type='blog' AND top = 'y' OR top = 'n' AND hide='n' AND checked = 'y' ORDER BY `top` DESC ,`date` DESC LIMIT $startnum,24";
	$go = $db->query($sql);
	$id = 0;
	while($row = $db->fetch_array($go)){
		$id++;
		$time = date('m-d',$row['date']);
?>
					<li><strong><?php echo $time;?></strong><a href="<?php echo Url::log($row['gid']);?>" title="<?php echo $row['title'];?>"><span><?php echo $id;?></span><?php echo $row['title'];?></a></li>
<?php }}}else{header('HTTP/1.1 403 Forbidden');}?>