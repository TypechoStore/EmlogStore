<?php
//域名授权开始
define('REFERER_URL', $_SERVER['HTTP_HOST']);//如：define('REFERER_URL', www.test.com|m.test.com|api.test.com'); 即可
$uriarr = parse_url($_SERVER['HTTP_REFERER']);
$host = $uriarr['host'];
$ymarr = explode("|",REFERER_URL);
if(in_array($host,$ymarr)){
?>
<?php
header("Content-type: application/json; charset=utf-8"); 
$qq = $_GET['qq'];
$opts=array("http"=>array("method"=>"GET","timeout"=>1),);
$context = stream_context_create($opts);
$html = file_get_contents('http://r.qzone.qq.com/fcg-bin/cgi_get_portrait.fcg?uins='.$qq, false, $context);
$nic = explode(',',$html);
$name = trim(mb_convert_encoding($nic[6], "UTF-8", "GBK"),'"');
$json['name'] = $name;
//$img = file_get_contents('http://q2.qlogo.cn/headimg_dl?dst_uin='.$qq.'&spec=100', false, $context);
//$json['pic'] = $img;
echo $_GET['callback'].'('.json_encode($json).')';
?>
<?php }else{header('HTTP/1.1 403 Forbidden');}?>