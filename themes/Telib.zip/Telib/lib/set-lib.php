<?php
/*
 * 模板设置运行库
 * Telib.theme by Telib
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
function d($str){
	$str = str_replace("'","\'",$str );
	return $str;
}
function telib_setting(){
	$telib = isset($_GET['telib']) ? $_GET['telib'] : '';
	if($telib == 'save'&& ROLE == ROLE_ADMIN) {
		if(empty($_GET)){
			$json = array(
				'code' => '201',
				'info' => '修改失败'
			);
			print json_encode($json);
			exit();
		}
		$config_data = $_POST["config"];				
       //处理上传的图片
		if ($_POST["Teliblogo"]) {
			$data = explode(",",$_POST["Teliblogo"]);
			$dataurl = EMLOG_ROOT.'/content/templates/Telib/CLASS/IMG/Teliblogo.png';
			$info = file_put_contents($dataurl, base64_decode($data[1]));
		}
		if ($_POST["default11"]) {
			$data = explode(",",$_POST["default11"]);
			$dataurl = EMLOG_ROOT.'/content/templates/Telib/CLASS/IMG/default11.png';
			$info = file_put_contents($dataurl, base64_decode($data[1]));
		}
		if ($_POST["default12"]) {
			$data = explode(",",$_POST["default12"]);
			$dataurl = EMLOG_ROOT.'/content/templates/Telib/CLASS/IMG/default12.png';
			$info = file_put_contents($dataurl, base64_decode($data[1]));
		}
		if ($_POST["loading11"]) {
			$data = explode(",",$_POST["loading11"]);
			$dataurl = EMLOG_ROOT.'/content/templates/Telib/CLASS/IMG/loading11.png';
			$info = file_put_contents($dataurl, base64_decode($data[1]));
		}
		if ($_POST["loading12"]) {
			$data = explode(",",$_POST["loading12"]);
			$dataurl = EMLOG_ROOT.'/content/templates/Telib/CLASS/IMG/loading12.png';
			$info = file_put_contents($dataurl, base64_decode($data[1]));
		}
		if ($_POST["default21"]) {
			$data = explode(",",$_POST["default21"]);
			$dataurl = EMLOG_ROOT.'/content/templates/Telib/CLASS/IMG/default21.png';
			$info = file_put_contents($dataurl, base64_decode($data[1]));
		}
		if ($_POST["default22"]) {
			$data = explode(",",$_POST["default22"]);
			$dataurl = EMLOG_ROOT.'/content/templates/Telib/CLASS/IMG/default22.png';
			$info = file_put_contents($dataurl, base64_decode($data[1]));
		}
		if ($_POST["loading21"]) {
			$data = explode(",",$_POST["loading21"]);
			$dataurl = EMLOG_ROOT.'/content/templates/Telib/CLASS/IMG/loading21.png';
			$info = file_put_contents($dataurl, base64_decode($data[1]));
		}
		if ($_POST["loading22"]) {
			$data = explode(",",$_POST["loading22"]);
			$dataurl = EMLOG_ROOT.'/content/templates/Telib/CLASS/IMG/loading22.png';
			$info = file_put_contents($dataurl, base64_decode($data[1]));
		}
        $config_data = serialize($config_data);
		$cachedata = '<?php
			$Tcon = \''.$config_data.'\';
		?>';
		$cachefile = EMLOG_ROOT.'/content/templates/Telib/lib/set-con.php';
		@ $fp = fopen($cachefile, 'wb') OR emMsg('读取缓存失败。如果您使用的是Unix/Linux主机，请修改缓存目录 (content/templates/Telib) 下所有文件的权限为777。如果您使用的是Windows主机，请联系管理员，将该目录下所有文件设为可写');
		@ $fw =	fwrite($fp,$cachedata) OR emMsg('写入缓存失败，缓存目录 (content/templates/Telib) 不可写');
		fclose($fp);
		$json = array(
			'code' => '200',
			'info' => '修改成功'
		);
		print json_encode($json);
		exit();
	}
}