<?php
/**
 * list模块页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
			<div class="index-list">
<?php
foreach($logs as $key=>$value): 
$search_pattern = '%<img[^>]*?src=[\'\"]((?:(?!\/admin\/|>).)+?)[\'\"][^>]*?>%s';
preg_match($search_pattern, $value['content'], $img);
$value['img'] = isset($img[1])?$img[1]:TEMPLATE_URL.'CLASS/IMG/default.png';
	if($Tcon['Te-color'] == '1'){
		$value['img'] = isset($img[1])?$img[1]:TEMPLATE_URL.'CLASS/IMG/default11.png';
		$loading = TEMPLATE_URL.'CLASS/IMG/loading11.png';
	}else{
		$value['img'] = isset($img[1])?$img[1]:TEMPLATE_URL.'CLASS/IMG/default12.png';
		$loading = TEMPLATE_URL.'CLASS/IMG/loading12.png';
	}
?>
				<div class="loglist-box BG <?php echo $Tcon['Te-wow'];?>">
					<a href="<?php echo $value['log_url'];?>" class="llbox-img Left"><img src="<?php echo $loading;?>" data-original="<?php echo $value['img'];?>" alt="<?php echo $value['log_title'];?>"></a>
					<div class="llbox-con Right">
						<div class="llbox-title">
							<?php if($value['top'] == 'y'):?><span class="lltitle1">首页置顶</span><?php endif;?>
							<?php blog_sort($value['logid']);?>
							<a href="<?php echo $value['log_url'];?>" class="lltitle3"><?php echo $value['log_title'];?></a>
						</div>
						<div class="llbox-text"><?php if(!empty($value['log_description'])){echo subString(strip_tags($value['log_description']),0,100,"...");}else{echo "此作者很懒，没有为文章撰写内容呦！";}?></div>
						<div class="llbox-other">
							<span class="llo1"><i class="fa fa-user-circle"></i> 作者：<?php blog_author($value['author']);?></span>
							<span class="llo2"><i class="fa fa-eye"></i> 围观：<?php echo $value['views'];?></span>
							<span class="llo3"><i class="fa fa-clock-o"></i> 时间：<?php echo date('Y-n-j',$value['date']);?></span>
							<span class="llo4"><i class="fa fa-comments-o"></i> 评论：<?php echo $value['comnum'];?></span>
						</div>
					</div>
				</div>
<?php endforeach;?>
				<div class="Telib-page <?php echo $Tcon['Te-wow'];?>" style="margin-bottom: 10px;">
					<?php echo Telib_page($lognum,$index_lognum,$page,$pageurl);?>
				</div>
			</div>
			<div class="index-cms1">
<?php
//CMS模块
$cmsid = explode(',',$Tcon['Te-cmsfl']);
$cmsnum = count($cmsid);
for($x = 0;$x < $cmsnum;$x++){blog_cmslist($cmsid[$x]);}
?>
			</div>
