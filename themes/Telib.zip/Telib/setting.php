<?php
/**
 * 模板设置页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
if (ROLE == ROLE_ADMIN){
	$sort_cache = $CACHE->readCache("sort");
?>
	<div class="Telib-setting Mauto">
		<form action="" method="post" id="setting">
			<div class="setting-1 BG Left <?php echo $Tcon['Te-wow'];?>">
				<ul>
					<li class="active"><a href="#set1">基本设置</a></li>
					<li><a href="#set2">高级设置</a></li>
					<li><a href="#set3">广告设置</a></li>
					<li><a href="#set4">导航图标</a></li>
					<li class="telib_save"><input type="submit" value="保存设置" class="set_save"></li> 
				</ul>
			</div>
			<div class="setting-2 BG Right <?php echo $Tcon['Te-wow'];?>">
				<div class="set-box" id="set1">
					<div class="set-list ClearFix">
						<div class="set-title Left">站点首页图标：</div>
						<div class="set-title1 Left">
							<div class="set-title3">
								<input type="file" id="Teliblogo" class="ufile">
								<input name="Teliblogo" type="hidden" value="">
								<img id="Teliblogoimg" src="<?php echo TEMPLATE_URL.'CLASS/IMG/Teliblogo.png';?>">
							</div>
						</div>
					</div>
					<div class="set-list ClearFix">
						<div class="set-title Left">默认黑色提示：</div>
						<div class="set-title1 Left">
							<div class="set-title3">
								<input type="file" id="default11" class="ufile">
								<input name="default11" type="hidden" value="">
								<img id="default11img" src="<?php echo TEMPLATE_URL.'CLASS/IMG/default11.png';?>">
							</div>
						</div>
						<div class="set-title Left">轮播黑色默认：</div>
						<div class="set-title1 Left">
							<div class="set-title3">
								<input type="file" id="default21" class="ufile">
								<input name="default21" type="hidden" value="">
								<img id="default21img" src="<?php echo TEMPLATE_URL.'CLASS/IMG/default21.png';?>">
							</div>
						</div>
					</div>
					<div class="set-list ClearFix">
						<div class="set-title Left">默认白色提示：</div>
						<div class="set-title1 Left">
							<div class="set-title3">
								<input type="file" id="default12" class="ufile">
								<input name="default12" type="hidden" value="">
								<img id="default12img" src="<?php echo TEMPLATE_URL.'CLASS/IMG/default12.png';?>">
							</div>
						</div>
						<div class="set-title Left">轮播白色默认：</div>
						<div class="set-title1 Left">
							<div class="set-title3">
								<input type="file" id="default22" class="ufile">
								<input name="default22" type="hidden" value="">
								<img id="default22img" src="<?php echo TEMPLATE_URL.'CLASS/IMG/default22.png';?>">
							</div>
						</div>
					</div>
					<div class="set-list ClearFix">
						<div class="set-title Left">默认黑色加载：</div>
						<div class="set-title1 Left">
							<div class="set-title3">
								<input type="file" id="loading11" class="ufile">
								<input name="loading11" type="hidden" value="">
								<img id="loading11img" src="<?php echo TEMPLATE_URL.'CLASS/IMG/loading11.png';?>">
							</div>
						</div>
						<div class="set-title Left">轮播黑色加载：</div>
						<div class="set-title1 Left">
							<div class="set-title3">
								<input type="file" id="loading21" class="ufile">
								<input name="loading21" type="hidden" value="">
								<img id="loading21img" src="<?php echo TEMPLATE_URL.'CLASS/IMG/loading21.png';?>">
							</div>
						</div>
					</div>
					<div class="set-list ClearFix">
						<div class="set-title Left">默认白色加载：</div>
						<div class="set-title1 Left">
							<div class="set-title3">
								<input type="file" id="loading12" class="ufile">
								<input name="loading12" type="hidden" value="">
								<img id="loading12img" src="<?php echo TEMPLATE_URL.'CLASS/IMG/loading12.png';?>">
							</div>
						</div>
						<div class="set-title Left">轮播白色加载：</div>
						<div class="set-title1 Left">
							<div class="set-title3">
								<input type="file" id="loading22" class="ufile">
								<input name="loading22" type="hidden" value="">
								<img id="loading22img" src="<?php echo TEMPLATE_URL.'CLASS/IMG/loading22.png';?>">
							</div>
						</div>
					</div>
					<div class="set-list ClearFix">
						<div class="set-title Left">站点配色：</div>
						<div class="set-title1 Left">
							<input name="config[Te-color]" type="radio" value="1" class="set-in" <?php if ($Tcon["Te-color"] == "1") echo 'checked'?>> 黑色
							<input name="config[Te-color]" type="radio" value="2" class="set-in" <?php if ($Tcon["Te-color"] == "2") echo 'checked'?>> 白色 
						</div>
					</div>
					<div class="set-list ClearFix">
						<div class="set-title Left">模块特效：</div>
						<div class="set-title1 Left">
							<input name="config[Te-mktx]" type="radio" value="1" class="set-in" <?php if ($Tcon["Te-mktx"] == "1") echo 'checked'?>> 开启
							<input name="config[Te-mktx]" type="radio" value="2" class="set-in" <?php if ($Tcon["Te-mktx"] == "2") echo 'checked'?>> 关闭
							<select name="config[Te-wow]">
								<option value="">选择效果</option>
								<option value="wow fadeInUp" <?php if ($Tcon['Te-wow'] == 'wow fadeInUp'){echo 'selected="selected"';}?>>默认</option>
								<option value="wow zoomIn" <?php if ($Tcon['Te-wow'] == 'wow zoomIn'){echo 'selected="selected"';}?>>弹出</option>
								<option value="wow pulse" <?php if ($Tcon['Te-wow'] == 'wow pulse'){echo 'selected="selected"';}?>>跳动</option>
								<option value="wow swing" <?php if ($Tcon['Te-wow'] == 'wow swing') {echo 'selected="selected"';}?>>晃动</option>
								<option value="wow bounceIn" <?php if ($Tcon['Te-wow'] == 'wow bounceIn'){echo 'selected="selected"';}?>>跳出</option>
								<option value="wow bounceInUp" <?php if ($Tcon['Te-wow'] == 'wow bounceInUpp'){echo 'selected="selected"';}?>>下拉</option>
								<option value="wow flipInX"<?php if ($Tcon['Te-wow'] == 'wow flipInX'){echo 'selected="selected"';}?>>上下翻转</option>
								<option value="wow flipInY"<?php if ($Tcon['Te-wow'] == 'wow flipInY'){echo 'selected="selected"';}?>>左右翻转</option>
							</select>
						</div>
					</div>
					<div class="set-list ClearFix">
						<div class="set-title Left">源码压缩：</div>
						<div class="set-title1 Left">
							<input name="config[Te-ymys]" type="radio" value="1" class="set-in" <?php if ($Tcon["Te-ymys"] == "1") echo 'checked'?>> 开启
							<input name="config[Te-ymys]" type="radio" value="2" class="set-in" <?php if ($Tcon["Te-ymys"] == "2") echo 'checked'?>> 关闭
						</div>
					</div>
				</div>
				<div class="set-box" id="set2">
					<div class="set-list ClearFix">
						<div class="set-title Left">首页模块：</div>
						<div class="set-title1 Left">
							<input name="config[Te-list]" type="radio" value="1" class="set-in" <?php if ($Tcon["Te-list"] == "1") echo 'checked'?>> CMS模式
							<input name="config[Te-list]" type="radio" value="2" class="set-in" <?php if ($Tcon["Te-list"] == "2") echo 'checked'?>> 列表模式
						</div>
					</div>
					<div class="set-list ClearFix">
						<div class="set-title Left">轮播数量：</div>
						<div class="set-title1 Left">
							<input name="config[Te-lbsl]" type="text" class="text" value="<?php echo $Tcon['Te-lbsl'];?>">
							<span>请填写轮播图需要显示的数量</span>
						</div>
					</div>
					<div class="set-list ClearFix">
						<div class="set-title Left">轮播分类：</div>
						<div class="set-title1 Left">
							<input name="config[Te-lbfl]" type="text" class="text" value="<?php echo $Tcon['Te-lbfl'];?>">
							<span>请填写轮播分类的ID，多个分类ID之间用（逗号）隔开！</span>
						</div>
					</div>
					<div class="set-list ClearFix">
						<div class="set-title Left">CMS分类：</div>
						<div class="set-title1 Left">
							<input name="config[Te-cmsfl]" type="text" class="text" value="<?php echo $Tcon['Te-cmsfl'];?>">
							<span>请填写CMS分类的ID，多个分类ID之间用（逗号）隔开！</span>
						</div>
					</div>
					<div class="set-list ClearFix">
						<div class="set-title Left">侧边标题：</div>
						<div class="set-title1 Left">
							<input name="config[Te-grzl1]" type="text" class="text" value="<?php echo $Tcon['Te-grzl1'];?>">
						</div>
					</div>
					<div class="set-list ClearFix">
						<div class="set-title Left">侧边内容：</div>
						<div class="set-title1 Left">
							<input name="config[Te-grzl2]" type="text" class="text" value="<?php echo $Tcon['Te-grzl2'];?>">
						</div>
					</div>
				</div>
				<div class="set-box" id="set3">
					<div class="set-list ClearFix">
						<div class="set-title Left">首页顶部广告：</div>
						<div class="set-title1 Left">
							<input name="config[Te-indexGG1]" type="radio" value="1" class="set-in" <?php if ($Tcon["Te-indexGG1"] == "1") echo 'checked'?>> 开启
							<input name="config[Te-indexGG1]" type="radio" value="2" class="set-in" <?php if ($Tcon["Te-indexGG1"] == "2") echo 'checked'?>> 关闭
						</div>
					</div>
					<div class="set-list ClearFix">
						<div class="set-title Left">广告代码：</div>
						<div class="set-title1 Left">
							<textarea name="config[Te-indexGG1-1]" rows="5"><?php echo $Tconfig["Te-indexGG1-1"];?></textarea>
						</div>
					</div>
					<div class="set-list ClearFix">
						<div class="set-title Left">首页最新列表上广告：</div>
						<div class="set-title1 Left">
							<input name="config[Te-indexGG2]" type="radio" value="1" class="set-in" <?php if ($Tcon["Te-indexGG2"] == "1") echo 'checked'?>> 开启
							<input name="config[Te-indexGG2]" type="radio" value="2" class="set-in" <?php if ($Tcon["Te-indexGG2"] == "2") echo 'checked'?>> 关闭
						</div>
					</div>
					<div class="set-list ClearFix">
						<div class="set-title Left">广告代码：</div>
						<div class="set-title1 Left">
							<textarea name="config[Te-indexGG1-2]" rows="5"><?php echo $Tconfig["Te-indexGG1-2"];?></textarea>
						</div>
					</div>
				</div>
				<div class="set-box" id="set4">
					<div class="set-list ClearFix">
						<div class="set-title Left">Awesome图标：(&nbsp;<a href="http://www.fontawesome.com.cn/faicons/" target="_black"><span style="color:#5298FF; font-weight:bold">点此浏览图标库</span></a>&nbsp;)</div>
					</div>
					<div class="set-list ClearFix">
						<div class="set-title">导航图标设置：(&nbsp;<span style="color:#5298FF; font-weight:bold">注意更改导航后需重新设置</span>&nbsp;)</div>
						<div class="set-title1 Left">
<?php
global $CACHE;
$navi_cache = $CACHE->readCache('navi');
foreach ($navi_cache as $num => $value){
if ($value['pid'] == 0) {$id = $value['id'];?>
							<div class="set-title2">
								<?php echo $value['naviname'];?>：
								<input type="text" value="<?php echo $Tcon['Te-navico'][$id];?>" name="config[Te-navico][<?php echo $id;?>]">
							</div>
<?php }}?>
						</div>
					</div>
					<div class="set-list ClearFix">
						<div class="set-title">分类图标设置：(&nbsp;<span style="color:#5298FF; font-weight:bold">注意更改导航后需重新设置</span>&nbsp;)</div>
						<div class="set-title1 Left">
<?php
global $CACHE;
$sort_cache = $CACHE->readCache('sort');
global $arr_navico1;
foreach ($sort_cache as $num => $value) {$sid = $value['sid'];?>
							<div class="set-title2">
								<?php echo $value['sortname'];?>：
								<input type="text" value="<?php echo $Tcon['Te-sortico'][$sid];?>" name="config[Te-sortico][<?php echo $sid;?>]">
							</div>
<?php }?>
						</div>
					</div>
				</div>
			</div>
		</form>
	</div>
<?php include View::getView('footer');?>
<?php }else{header("Location:".BLOG_URL."");exit;}?>