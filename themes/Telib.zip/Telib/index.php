<?php
/**
 * 首页页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
if(isset($_GET["setting"])){include View::getView('setting');exit;}
?>
	<div class="index-top Mauto ClearFix">
		<div class="index-wapper Left">
<?php if($Tcon['Te-lbfl'] != "" && $Tcon['Te-lbfl'] !=0):?>
			<div id="index-wp1" class="MB10">
				<div id="index-wp2">
					<ul id="index-wp3">
<?php blog_wp($Tcon['Te-lbfl'],$Tcon['Te-lbsl']);?>
					</ul>
					<div class="index-wp-btns" id="index-wp-next"><i class="fa fa-arrow-right"></i></div>
					<div class="index-wp-btns" id="index-wp-prev"><i class="fa fa-arrow-left"></i></div>
					<div id="index-wp-num1"><ul></ul></div>
				</div>
			</div>
<?php endif;?>
			<div class="index-notice BG MB10 <?php echo $Tcon['Te-wow'];?>">
				<div class="notice-ico Left"><i class="fa fa-volume-up"></i></div>
				<div id="content" class="notice1 Right"> 
					<div id="top" class="notice2"> 
						<ul> 
<?php echo twitter();?>
						</ul> 
					</div> 
					<div id="bottom" class="notice2"></div> 
				</div> 
			</div>
<?php if($Tcon['Te-indexGG2'] == '1'):?>
			<div class="PA10 MB10 BG <?php echo $Tcon['Te-wow'];?>">
				<?php echo $Tcon['Te-indexGG1-2'];?>
			</div>
<?php endif;?>
<?php if($Tcon['Te-list'] == 1){include View::getView('lib/index-cms');}elseif($Tcon['Te-list'] == 2){include View::getView('lib/index-list');}?>
		</div>
		<div class="index-side Right">
<?php include View::getView('side');?>
		</div>
	</div>
	<div class="Telib-link BG ClearFix">
		<div class="Telib-link1 Mauto">
			<h3>友情链接：</h3>
			<ul class="Clear">
<?php echo ilinks();?>
			</ul>
		</div>
	</div>
<?php include View::getView('footer');?>

