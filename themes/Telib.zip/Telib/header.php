<?php
/**
Template Name:Telib模板
Description:<a href="../?setting" target="_blank">进入模板设置</a><br>此模板为EMLOG模板售卖站模板,灵感来源于会飞的鱼的fee模板，此模板更个性，符合大多数站长的需求，主要表现在如果屏幕较亮也不会刺眼，很护眼的一个主题，期待大家的支持，在此持续更新...模板问题反馈群：608960444模板作者网站：www.wuaif.com模板演示地址：blog.woaif.cn
Version:1.0
ForEmlog:6.1.1
Author:晗枫
Author Url:http://www.woaif.cn
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
header('X-Frame-Options:sameorigin');
require_once View::getView('module');
date_default_timezone_set('Asia/Shanghai');//设置时区
require_once View::getView('lib/set-lib');//载入模板设置运行库
require_once View::getView('lib/set-con');//载入模板设置配置文件
$Tcon = unserialize($Tcon);
$GLOBALS['Tcon'] = $Tcon;
if($_GET['telib'] == 'save'&& ROLE == ROLE_ADMIN){telib_setting();}
if($_GET{'keyword'} != ""){
	$Blog_title = '搜索 [ '.$_GET{'keyword'}.' ] 的结果&nbsp-&nbsp'.$site_title;
}elseif($tws){
	$Blog_title = '微语' . $site_title;
}else{
	$Blog_title = $site_title;
}
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="applicable-device" content="pc,mobile">
<meta content="always" name="referrer">
<title><?php echo $Blog_title;?></title>
<meta name="keywords" content="<?php echo $site_key;?>">
<meta name="description" content="<?php echo $site_description;?>">
<link rel="shortcut icon" href="<?php echo TEMPLATE_URL;?>favicon.ico" type="image/x-icon">
<link type="text/css" rel="stylesheet" href="<?php echo TEMPLATE_URL;?>CLASS/CSS/wow.css">
<link type="text/css" rel="stylesheet" href="<?php echo TEMPLATE_URL;?>CLASS/CSS/font.css">
<link type="text/css" rel="stylesheet" href="<?php echo TEMPLATE_URL;?>CLASS/CSS/style.php">
<script type="text/javascript" src="<?php echo TEMPLATE_URL;?>CLASS/JS/JQ.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL;?>CLASS/JS/JS.js"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
</head>
<body>
<div class="header BG">
	<div class="header1 Mauto">
		<h1 class="logo Left"><a href="<?php echo BLOG_URL;?>" title="<?php echo $blogname;?>">
		<!-- <i class="fa fa-logo"></i> -->
		<img class="fa" src="<?php echo TEMPLATE_URL;?>CLASS/IMG/Teliblogo.png" alt="<?php echo $blogname;?>">
		</a>
		</h1>
		<div class="nav Left">
<?php echo blog_navpc();?>
		</div>
		<div class="nav-i Left"><i class="fa fa-bars Hover"></i></div>
		<div class="other Right"><i class="fa fa-search Hover"></i></div>
		<div class="search Right"><form method="get" action="<?php echo BLOG_URL;?>index.php"><input type="text" name="keyword" value="" placeholder="输入关键字 Enter键搜索..."></form></div>
	</div>
</div>
<div class="nav-mback"></div>
<div class="nav-m BG">
<?php echo blog_navm();?>
</div>
<div class="wapper ClearFix">
<?php if($Tcon['Te-indexGG1'] == '1'):?>
	<div class="Mauto MB10 PA10 BG <?php echo $Tcon['Te-wow'];?>">
		<?php echo $Tcon['Te-indexGG1-1'];?>
	</div>
<?php endif;?>
