<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div class="main">
  <div class="main-block" id="nav-div">
    <div class="logo"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></div>
    <div class="bloginfo"><a href="<?php echo BLOG_URL; ?>"><?php echo $bloginfo; ?></a></div>
    <?php echo blog_navi(); ?>
    <div id="search-div-in">
      <form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
        <input class="search-box" name="keyword" id="search-in" type="text" value="搜索从这里开始" onFocus="if(value==defaultValue){value='';}"
onBlur="if(!value){value=defaultValue;}" />
      </form>
    </div>
  </div>
  <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
  <?php endif; ?>
  <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?>
  <div class="main-block">
    <div class="t_main">
      <div class="post1"><?php echo $val['t'].'<br />'.$img;?></div>
      <div class="t_time"><?php echo $val['date'];?></div>
    </div>
  </div>
  <?php endforeach;?>
  </div>
  <?php if($twnum <= $index_twnum){ ?>
  <style>
.t_page-right, .t_page-right{display:none;}
</style>
  <?php }elseif($page == 1){ ?>
  <a href="<?php echo BLOG_URL.'t/?page='.(string)($page+1); ?>">
  <div class="t_page-right">→</div>
  </a>
  <?php }elseif($page > 1 && $page < ceil($twnum / $index_twnum)){ ?>
  <a href="<?php echo BLOG_URL.'t/?page='.(string)($page-1); ?>">
  <div class="t_page-left">←</div>
  </a> <a href="<?php echo BLOG_URL.'t/?page='.(string)($page+1); ?>">
  <div class="t_page-right">→</div>
  </a>
  <?php }elseif($page >= ceil($twnum / $index_twnum)){ ?>
  <a href="<?php echo BLOG_URL.'t/?page='.(string)($page-1); ?>">
  <div class="t_page-left">←</div>
  </a>
  <style>
.t_page-right{display:none;}
</style>
  <?php } ?>
<?php
 include View::getView('footer');
?>
