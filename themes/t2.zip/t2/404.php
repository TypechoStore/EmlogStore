<?php 
/*
* 自定义404页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>梦寐鱼求 - 错误404</title>
<style>
*{
	margin:0;
	padding:0;
	font-family:"微软雅黑";
}
body{
	background:#ddd;
}
.error-wrap{
	background:#f6f6f6;
	position:absolute;
	width:500px;
	height:116px;
	top:50%;
	left:50%;
	margin-left:-250px;
	margin-top:-58px;
	box-shadow:1px 1px 5px #888;
	-webkit-box-shadow:1px 1px 5px #888;
	-moz-box-shadow:1px 1px 5px #888;
	transition-property:box-shadow;
	transition-duration:0.5s;
	-webkit-transition-property:box-shadow;
	-webkit-transition-duration:0.5s;
	-moz-transition-property:box-shadow;
	-moz-transition-duration:0.5s;
}
.error-wrap:hover{
	box-shadow:1px 1px 20px #000;
	-webkit-box-shadow:1px 1px 20px #000;
	-moz-box-shadow:1px 1px 20px #000;
	transition-property:box-shadow;
	transition-duration:0.5s;
	-webkit-transition-property:box-shadow;
	-webkit-transition-duration:0.5s;
	-moz-transition-property:box-shadow;
	-moz-transition-duration:0.5s;
}
.error-title{
	width:460px;
	height:25px;
	margin-top:20px;
	margin-left:20px;
	border-bottom:1px solid #ddd;
	color:#888
}
.error-content{
	margin:10px 20px 0 20px;
	width:460px;
	height:45px;
	color:#888;
	font-size:14px;
}
</style>
</head>
<body>
<div class="error-wrap" onclick="window.location.href='http://sinkery.com'">
	<div class="error-title">梦寐鱼求 - 错误404
    </div>
    <div class="error-content">很荣幸您能光临梦寐鱼求，但是您的请求指向了错误的URL地址。<br />请您尝试刷新本页面，或者点击此提示信息返回本站首页。
    </div>
</div>
</body>
</html>