<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="clear"></div>
</div><!--end wrapper-->
<script src="<?php echo TEMPLATE_URL; ?>js/scrolltop.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/slimbox2.js" type="text/javascript"></script>
<!--鼠标经过显示回复-->
<script type="text/javascript">
$(function(){
	$(".reply-hover").hover(function(){
		$(this).children(":first").children(".comment-reply").show();
		$(this).parent().parent().children(":first").children(".comment-reply").hide();
	},function(){
		$(this).children(":first").children(".comment-reply").hide();
		$(this).parent().parent().children(":first").children(".comment-reply").show();
	});
});
</script>
<!--鼠标经过显示回复结束-->
<div id="footerbar">
    <div class="copyright">
        <p class="about_info">
            <a href="http://aisheji.org">Home</a> | <a href="http://aisheji.org/about.html">About</a> | <a href="http://aisheji.org/guestbook.html">Guestbook</a> | <a href="http://aisheji.org/sitemap.xml">Sitemap</a> | <a href="http://aisheji.org/rss.php">RSS</a> | <a href="http://aisheji.org/m">Wap</a>  | 
			<?php echo $footer_info; ?><?php echo $icp; ?>
        </p>
        <p class="emlog1">
            Copyright &copy; 2012 - 2013 Aisheji. All Rights Reserved. Powered By <a href="http://www.emlog.net" target="_blank" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>. Theme by <a href="http://cdc.tencent.com/" target="_blank" rel="nofollow">CDC</a>＆<a href="http://www.m4html.com/" target="_blank" rel="nofollow">M4</a>.
            <span class="emlog2">Copyright &copy; 2012 - 2013 Aisheji. All Rights Reserved. Powered By <a href="http://www.emlog.net" target="_blank" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>. Theme by <a href="http://cdc.tencent.com/" target="_blank">CDC</a>＆<a href="http://www.m4html.com/" target="_blank">M4</a>.</span>
        </p>
    </div><!--end copyright-->
</div><!-- end #footerbar -->
<?php doAction('index_footer'); ?>
<!-- Baidu Button BEGIN -->
<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=202915" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
</script>
<!-- Baidu Button END -->
</body>
</html>