<?php
/*
 * 面包屑
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
当前位置：
<?php if ($url_path == BLOG_URL): ?>
首页
<?php elseif (!isset($logid) && empty($tws)) : ?>
<a href="<?php echo BLOG_URL; ?>index.php" target="_self">日志列表</a>
<?php endif; ?>
<?php
$controller = isset($this) ? get_class($this) : '';
if(!empty($tws)): ?>
    <a href="<?php echo BLOG_URL; ?>t/">碎语</a>
<?php elseif($controller === 'Sort_Controller'): ?>
    &raquo; <a href="<?php echo Url::sort($sortid); ?>"><?php echo $sortName; ?></a> (分类)
<?php elseif($controller === 'Tag_Controller'): ?>
    &raquo; <a href="<?php echo Url::tag(urlencode($tag)); ?>"><?php echo $tag; ?></a> (标签)
<?php elseif($controller === 'Author_Controller'): ?>
    &raquo; <a href="<?php echo Url::author($author); ?>"><?php echo $author_name; ?></a> (作者)
<?php elseif($controller === 'Record_Controller'): ?>
    &raquo; <a href="<?php echo Url::record($record); ?>"><?php echo $record; ?></a> (归档)
<?php elseif($controller === 'Search_Controller'): ?>
    &raquo; <a href="<?php echo BLOG_URL.'?keyword='.urlencode($keyword); ?>"><?php echo $keyword; ?></a> (搜索)
<?php elseif($controller === 'Plugin_Controller'): ?>
    &raquo; <a href="<?php echo BLOG_URL.'?plugin='.$plugin; ?>"><?php echo $plugin; ?></a> (插件)
<?php
elseif($controller === 'Log_Controller' && isset($logid)):
//elseif(isset($logid)): 
    if (!(isset($type) && $type == 'page')):
        global $CACHE; 
        $log_cache_sort = $CACHE->readCache('logsort');
        ?>
        <a href="<?php echo Url::sort($log_cache_sort[$logid]['id']); ?>">
		<?php if(empty($log_cache_sort[$logid])): 
				echo '未分类';
			  else:
				echo $log_cache_sort[$logid]['name']; 
			  endif; 
	    ?>
		</a> &raquo;
    <?php endif; ?>
    <?php echo $log_title; ?>
<?php endif; ?>
<?php if(isset($page) && $page > 1): ?>
    &raquo; 第<?php echo $page; ?>页
<?php endif; ?>
<?php if(isset($comment_page) && $comment_page > 1): ?>
    &raquo; 评论第<?php echo $comment_page; ?>页
<?php endif; ?>