<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="sidebar" class="sidebar-<?php echo _g('sidebar'); ?>">
    <div class="widget" id="search">
	<form id="searchform" name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
    <input type="text" name="keyword" onblur="if(this.value==''){this.value='搜索';}" onfocus="this.value='';" value="搜索">
    <input type="submit" onmouseover="this.className='soHover'" onmouseout="this.className='so'" class="so" value="">
	<div style="clear:both;"></div>
	</form>
    </div>
	<div class="widget" id="tqq">
		<a href="http://t.qq.com/todlog" target="_blank" rel="nofollow">收听Tod的腾讯微博</a>
    </div>
<?php
$isLog = isset($logid);
$isPage = isset($logid) && !isset($neighborLog);
$sortid = isset($sortid) ? $sortid : null;
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle), $isLog, $isPage, $sortid);
		}
	}
}
?>
<!--
<div class="rss">
<a href="<?php echo BLOG_URL; ?>rss.php" title="RSS订阅"><img src="<?php echo TEMPLATE_URL; ?>images/rss.gif" alt="订阅Rss"/></a>
</div>
-->
<?php echo widget_Information($title, $isLog = false, $isPage = false); ?>
</div><!-- end #sidebar -->
