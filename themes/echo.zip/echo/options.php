<?php

/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
	'sidebar' => array(
		'type' => 'radio',
		'name' => '侧边栏位置',
		'values' => array(
			'left' => '左边',
			'right' => '右边'
		),
		'default' => 'right',
	),
	'sidebarPage' => array(
		'type' => 'radio',
		'name' => '自建页面显示侧边栏',
		'values' => array(
			'1' => '是',
			'0' => '否'
		),
		'default' => '1',
	),
	'links' => array(
		'type' => 'checkbox',
		'name' => '友链显示位置',
		'values' => array(
			'index' => '首页',
			'list' => '各个列表页',
			'page' => '自建页面',
		),
		'default' => array(
			'index',
		),
	),
	'links_pr' => array(
		'type' => 'radio',
		'name' => '友情链接是否显示PR值',
		'values' => array(
			'1' => '是',
			'0' => '否'
		),
		'default' => '1',
	),
		'Information' => array(
		'type' => 'checkbox',
		'name' => '是否显示站点信息',
		'values' => array(
			'index' => '首页',
			'list' => '各个列表页',
			'page' => '自建页面',
		),
		'default' => array(
			'index',
		),
	),
		'nav' => array(
		'type' => 'radio',
		'name' => '是否显示面包屑导航',
		'values' => array(
			'1' => '是',
			'0' => '否'
		),
		'default' => '1',
	),
	'sortIcon' => array(
		'type' => 'image',
		'name' => '分类图标设置',
		'values' => array(
			TEMPLATE_URL . 'images/star.png',
		),
		'depend' => 'sort',
		'description' => '给不同的分类设置不一样的小icon，以20×20为宜',
	),
	'sortKeywords' => array(
		'type' => 'text',
		'name' => '分类关键词设置（多个关键词之间用半角逗号隔开）',
		'depend' => 'sort',
		'description' => '设置每个分类页面显示的关键词',
		'default' => '设置关键词，请不要留空',
	),
);