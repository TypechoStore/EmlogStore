<?php
/*
Template Name:echo
Description:仿腾讯CDC ……
Version:1.2
Author:Tod
Author Url:http://aisheji.org
Sidebar Amount:1
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module'); //模板核心函数
require_once View::getView('user-defined'); //自定义函数
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<!--
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>
<link rel="icon" href="favicon.gif" type="image/gif"/>
-->
<?php if (isset($logid)) : ?>
<meta name="keywords" content="<?php log_key_words($logid); ?>" />
<?php elseif (isset($sortName)) : ?>
<meta name="keywords" content="<?php echo _g('sortKeywords.'.$sortid); ?>" />
<?php else : ?>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<?php endif; ?>
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js" charset="utf-8" type="text/javascript"></script>
<script type="text/javascript">var isGravatar = '<?php echo Option::get('isgravatar');?>';</script>
<!--IE6 PNG处理-->
<!--[if lte IE 6]>
    <script src="<?php echo TEMPLATE_URL; ?>js/DD_belatedPNG.js" type="text/javascript"></script>
    <script type="text/javascript">
        DD_belatedPNG.fix('#header,#header #logo h1 a,#header #logo ul li a:hover,#header #logo ul li.current a,#header #logo ul li.rss,#header #logo ul li.rss a,#header #logo ul li.feed a,#header #logo ul li.rss a:hover,#header #logo ul li.feed a:hover,#slidernav a#slideshownext,#slidernav a#slideshowprev,#content .post .title .comm a,#content .post .meta span.tag,#content .post .meta span.view,#search, #search .so, #search .soHover, #search:hover,#sidebar .widget h3');
    </script>
<![endif]-->
<!--IE6 PNG处理 结束-->
<?php if (!isset($logid) && empty($tws)) : ?>
    <script src="<?php echo TEMPLATE_URL; ?>js/jquery.cycle.all.latest.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.slideshow').cycle({
		        fx: 'fade',
		        speed: '1000', 
		        timeout: '4000',
		        next: '#slideshownext',
		        prev: '#slideshowprev'
	        });
        });
    </script>
<?php endif; ?>
<!--屏蔽IE JS报错-->
<!--[if lte IE 8]>
<script type="text/javascript">
try
{
	window.onerror = function(){return true;}
}
catch (err)
{
}
</script>
<![endif]-->
<?php doAction('index_head'); ?>
</head>
<body>
<!--焦点图片-->
<?php if (!isset($logid) && empty($tws)) : ?>
    <div id="index">
        <div id="banner" class="slideshow">
            <div class="index_1"></div>
	        <div class="index_2"></div>
	        <div class="index_3"></div>
        </div>
<?php endif; ?>
<div id="header">
  <div id="logo"><h1><a href="<?php echo BLOG_URL; ?>" alt="<?php echo $site_description; ?>" title="<?php echo $site_description; ?>"><?php echo $blogname; ?></a></h1>
    <div id="pagenavi">
        <?php blog_navi();?>
    </div>
  </div>
</div><!--end header-->
<?php if (!isset($logid) && empty($tws)) : ?>
        <div id="slidernav">
            <a id="slideshowprev" href="#slideshowprev">prev</a>
            <a id="slideshownext" href="#slideshownext">next</a>
        </div>
    </div id="index"><!--end index-->
<?php endif; ?>
<?php if (!isset($logid) && empty($tws) && empty($keyword)) : ?>
<div id="navi_bread"><div id="navi_bread_head"></div></div>
<?php else: ?>
<div id="navi_bread"><div class="navi_bread_log_height-<?php echo _g('nav'); ?>"><div id="navi_bread_log" class="navi_bread_log-<?php echo _g('nav'); ?>"><?php include View::getView('user-bread'); ?></div></div></div>
<?php endif; ?>
<div id="wrapper">