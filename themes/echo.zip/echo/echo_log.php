<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="content" class="content-<?php echo _g('sidebar'); ?>">
    <div class="post">
        <div class="title">
            <div class="title">
                <div class="user">
                    <img src="<?php echo _g('sortIcon.' . $sortid); ?>" alt="<?php echo sort_name($logid); ?>" title="<?php echo sort_name($logid); ?>" />
                </div>
                <div class="line"><i class="line_h"></i></div>
                <div class="h3">
                    <h3><?php echo $log_title; ?></h3>
                        <p>
                            <?php blog_author($author); ?> ┊ 
                            <?php blog_sort($logid); ?> ┊ 
                            <?php echo gmdate('Y-n-j G:i l', $date); ?> ┊ 浏览 
                            <?php echo $views; ?>&nbsp&nbsp&nbsp字号：
                            <b>
                                <a style="font-size:12px;" href="javascript:doZoom(12)">T</a>&nbsp&nbsp
                                <a style="font-size:14px;" href="javascript:doZoom(14)">T</a>&nbsp&nbsp
                                <a style="font-size:18px;" href="javascript:doZoom(18)">T</a>&nbsp&nbsp
                            </b>
                            <?php editflg($logid,$author); ?>
                        </p>
                </div>
                <div class="comm">
                    <a class="up" href="<?php echo $value['log_url']; ?>#comments" title="<?php echo $log_title; ?>上的评论"><?php echo $comnum; ?></a>
                </div>
            </div><!--end title-->
        </div><!--end title-->
        <!--改变字号-->
            <script type="text/javascript">
				function doZoom(size){
				document.getElementById('zoom').style.fontSize=size+'px'}
			</script>
        <!--改变字号 end-->
        <div class="blog" id="zoom">
            <div class="blog_dsc"><?php echo $log_content; ?></div>
            <div class="clear"></div>
        </div>
        <div class="meta">
            <span class="next"><?php neighbor_log($neighborLog); ?></span>
        </div>
        <div class="notice">
            <!-- Baidu Button BEGIN -->
            <div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare" style="margin-bottom:5px;">
                <a class="bds_qzone"></a>
                <a class="bds_tsina"></a>
                <a class="bds_tqq"></a>
                <a class="bds_renren"></a>
                <a class="bds_t163"></a>
                <span class="bds_more"></span>
            </div>
            <br style="clear:both;" />
            <!-- Baidu Button END -->
            <div class="shenming">
                <span>文章除注明外均为原创，转载请注明出处：<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></span><br />
                <span>本文地址：:<a href="<?php echo Url::log($logid); ?>"><?php echo Url::log($logid); ?></a></span>
            </div>
        </div>
    <?php doAction('log_related', $logData); ?>
    </div><!--end post-->
	<?php blog_comments($comments,$params); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div><!-- end #content-->
<?php
    include View::getView('side');
    include View::getView('footer');
?>