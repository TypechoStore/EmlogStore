<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content" class="content-<?php echo _g('sidebar'); ?> content-<?php echo _g('sidebarPage'); ?>">
	<div class="post">
		<div class="title_page">
			<h3><?php echo $log_title; ?></h3>			     
		</div>
		<div class="blog">
			<?php if($log_title == "归档"): ?>
				<script src="<?php echo TEMPLATE_URL; ?>js/sdmenu.js" charset="utf-8" type="text/javascript"></script>
				<script type="text/javascript">
					// <![CDATA[
					var myMenu;
					window.onload = function() {
					myMenu = new SDMenu("my_menu");
					myMenu.init();
					};
					// ]]>
				</script>
				<form action="#" style="font-family: sans-serif; font-size: .8em" onsubmit="return false">
					<fieldset><legend>Menu actions</legend>
						<label for="speed">Speed (1-5):</label>
						<input type="text" id="speed" value="3" size="1" onchange="myMenu.speed = parseInt(this.value)" />
						<label for="oneSmOnly">One submenu at a time:</label>
						<select id="oneSmOnly" onchange="myMenu.oneSmOnly = this.selectedIndex"><option>false</option><option>true</option></select>
						<select name="smNr"><option>1</option><option>2</option><option>3</option><option>4</option></select>
						<input type="button" value="Expand" onclick="myMenu.expandMenu(myMenu.submenus[smNr.selectedIndex])" />
						<input type="button" value="Collapse" onclick="myMenu.collapseMenu(myMenu.submenus[smNr.selectedIndex])" />
						<input type="button" value="Toggle" onclick="myMenu.toggleMenu(myMenu.submenus[smNr.selectedIndex])" />
						<input type="button" value="Expand all" onclick="myMenu.expandAll()" />
						<input type="button" value="Collapse all" onclick="myMenu.collapseAll()" />
					</fieldset>
				</form>
				<?php get_archive($log_content); ?>
		    <?php else: ?>
				<?php echo $log_content; ?>
			<?php endif; ?>
            <div style="clear:both;"></div>
		</div><!--end blog-->
	</div><!--end post-->
	<?php blog_comments($comments,$params); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div><!-- end #content-->
<?php
if (_g('sidebarPage')) {
	include View::getView('side');
}
include View::getView('footer');
?>