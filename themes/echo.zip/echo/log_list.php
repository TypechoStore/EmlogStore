<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content" class="content-<?php echo _g('sidebar'); ?>">
<?php doAction('index_loglist_top'); ?>
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
	<div class="post">
		<div class="title">
			<div class="title">
				<div class="user">
					<a href="<?php echo Url::sort($value['sortid']); ?>"><img src="<?php echo _g('sortIcon.' . $value['sortid']); ?>" alt="<?php echo sort_name($value['logid']); ?>" title="<?php echo sort_name($value['logid']); ?>" /></a>
				</div>
				<div class="line"><i class="line_h"></i></div>
				<div class="h3">
					<h3><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>" onfocus="this.blur()"><?php echo $value['log_title']; ?></a></h3><p><?php blog_author($value['author']); ?> ┊ <?php blog_sort($value['logid']); ?> ┊ <?php echo gmdate('Y-n-j G:i l', $value['date']); ?>&nbsp&nbsp<?php editflg($value['logid'],$value['author']); ?></p>
				</div>			     
				<div class="comm">
					<a href="<?php echo $value['log_url']; ?>#comments" title="《<?php echo $value['log_title']; ?>》上的评论"><?php echo $value['comnum']; ?></a>
				</div>
			</div><!--end title-->
		</div><!--ent title-->
		<div class="blog">
			<div class="blog_dsc"><?php echo $value['log_description']; ?></div>
		</div>
			<div class="meta">
				<span class="view"><a href="<?php echo $value['log_url']; ?>">浏览：<?php echo $value['views']; ?></a></span>
				<span class="tag">标签：<?php blog_tag($value['logid']); ?></span>
				<span class="more"><a href="<?php echo $value['log_url']; ?>">阅读全文</a></span>
			</div>
	</div><!--end post-->
<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
	<div id="pagesnav">
		<?php echo $page_url;?>
	</div>
</div><!-- end #content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>