<?php 
/*
* 自定义函数
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//Custom: 归档
function get_archive($log_content){
$sql="select *,date_format(from_unixtime(date),'%Y年%m月') as ym,date_format(from_unixtime(date),'%m/%d') as md from ".DB_PREFIX."blog WHERE hide='n' and type='blog' ORDER BY date DESC";
$DB = MySql::getInstance();
$re=$DB->query($sql);
$log_content='<ul id="my_menu" class="sdmenu">';
$ym='';
$k=0;
while( $row = $DB->fetch_array($re) ){
	if($ym==$row['ym']){
		$log_content.='<a href="'.Url::log($row['gid']).'">'.$row['title'].'&nbsp'.'('.$row['comnum'].'/'.$row['views'].')'.'</a>';
	}else{
		$ym=$row['ym'];
		if($log_content!=='<ul id="my_menu" class="sdmenu">'){$log_content.='</li>';}
		$k++;
		if($k<=5):
			$log_content.='<li class="current"><span>'.$row['ym'].'</span>';
		else:
			$log_content.='<li class="collapsed"><span>'.$row['ym'].'</span>';
		endif;
		$log_content.='<a href="'.Url::log($row['gid']).'">'.$row['title'].'&nbsp'.'('.$row['comnum'].'/'.$row['views'].')'.'</a>';
	}
}
$log_content.='</ul>';
echo $log_content;
}
?>
<?php
//blog：获取分类名称
function sort_name($blogid) {
    global $CACHE; 
    $log_cache_sort = $CACHE->readCache('logsort');
    if(!empty($log_cache_sort[$blogid])):
        return $log_cache_sort[$blogid]['name'];
    else:
        return '未分类';
    endif;
}?>
<?php
//文章关键词
function log_key_words($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .="".$value['tagname'].',';
		}
		echo substr($tag,0,-1);
	}
}
?>
<?php
//随机文章
function rand_log() {
    $db = MySql::getInstance();
    $sql = 	"SELECT gid,title,content FROM ".DB_PREFIX."blog WHERE type='blog' ORDER BY rand() LIMIT 0,1";
    $list = $db->query($sql);
    while($row = $db->fetch_array($list)){
        echo Url::log($row['gid']);
    }
}
?>
<?php
//获取Gravatar头像
function MyGravatar($email, $s=64, $d='identicon', $r='g') {
    $f = md5($email);
    $a = BLOG_URL.'avatar/'.$f.'.jpg';
    $e = EMLOG_ROOT.'/avatar/'.$f.'.jpg';
    $t = 1296000; //15天，单位：秒
    if (empty($d)) $d = BLOG_URL.'avatar/default.jpg';
    if (!is_file($e) || (time() - filemtime($e)) > $t ) {
        //当头像不存在或者超过15天才更新
        $g = sprintf("http://%d.gravatar.com",(hexdec($f{0})%2)).'/avatar/'.$f.'?s=64&d='.$d.'&r='.$r;
        copy($g,$e); $a=$g; //新头像copy时, 取gravatar显示
    }
    if (filesize($e) < 500) copy($d,$e);
    return $a;
}
?>