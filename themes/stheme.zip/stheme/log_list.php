<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content_top">
<?php include View::getView('lsidebar');?>

<div id="blog">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<div class="box">
<div class="entry" id="post-1">
<div class="posttime"><div class="d"><?php echo gmdate('j', $value['date']); ?></div><div class="m"><?php echo gmdate('m', $value['date']); ?>月</div></div>
<div class="posttitle">
<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
<p class="postmeta">
<span class="comment"><a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?>条评论</a></span>
<span class="category"><?php blog_sort($value['logid']); ?></span>
<span class="date"><?php echo gmdate('Y年n月j日', $value['date']); ?></span>
<span class="views">热度:<?php echo $value['views']; ?>℃</span><?php editflg($value['logid'],$value['author']); ?>
</p>
</div>
<div class="post"><?php echo $value['log_description']; ?></div>
<p class="tags"><?php blog_tag($value['logid']); ?></p>
</div>
</div>
<?php endforeach; ?>
    <div id="pagenavi">
<?php echo $page_url;?>
    </div>
</div>

<?php include View::getView('side');?>

		</div>
<div id="content_foot"></div>
	</div>	
<div class="clear"></div>
</div>

<?php include View::getView('footer');?>