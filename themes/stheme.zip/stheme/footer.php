<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="footer">
	<div id="foot_right">
	<div class="w3c">
	Valid <a href="http://validator.w3.org/check?uri=referer" target="_blank">XHTML 1.0</a> and <a href="http://jigsaw.w3.org/css-validator/" target="_blank">CSS 3</a>!
    </div>
    <!--你可以根据需要修改名人名言，或直接删除-->  
	<ul class="foot_fun">领袖和跟风者的区别就在于创新。——乔布斯</ul>
	<p>Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">emlog</a>. <a href="http://sivan.in/blog/stheme/" target="_blank">STheme主题</a><a href="http://www.loek.us" target="_blank">由loekman移植</a>. <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?></p>
	</div>
</div>
<?php doAction('index_footer'); ?>
</body>
</html>