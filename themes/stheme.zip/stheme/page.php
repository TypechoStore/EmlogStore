<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content_top">
<?php include View::getView('lsidebar');?>
<div id="blog">
<div class="box">
<div class="entry" id="post-1">
		<div class="post"><?php echo $log_content; ?></div>
		</div>
		</div> 
	<div class="clear"></div>
<div class="box">
	<div id="comments">
	<h3>共有<?php echo $comnum; ?>条留言 | <a href="#respond"><font color="#006600">点击这里快速发表留言</font></a></h3>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
</div>
</div>
<?php include View::getView('side');?>
</div>

<div id="content_foot"></div>
	</div>
<div class="clear"></div>	
</div>
<?php include View::getView('footer');
?>