<?php
/*
Template Name:STheme for emlog
Description:WP的一款个性的三栏模板，可关闭右边栏；CSS代码简洁干练通过W3C验证。
Version:1.1(20130110)
Author:loekman
Author Url:http://www.loek.us
Sidebar Amount:2
ForEmlog:5.0.x
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<link rel="shortcut icon" href="favicon.ico">
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>style.css" type="text/css" media="screen" />
<!--[if IE 6]>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>IE6.css" type="text/css" media="screen" />
<![endif]-->
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script language="javascript">
function killErrors() {
    return true;
}
window.onerror = killErrors;
</script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="main"></div>
<div class="top_bg"></div>
<div id="header">
<div id="logo">
	<h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
	<div class="description"><?php echo $bloginfo; ?></div>
	</div>
<div id="rssblock">
<a id="rssfeed" href="<?php echo BLOG_URL; ?>rss.php">RSS Feed</a>
<ul id="rssList">
<li>你可以通过Google Reader或其它阅读工具订阅我的博客。</li>
</ul>
</div>	
</div>
<ul id="subnav">
<?php blog_navi();?>
<?php if(!$_COOKIE['show_sidebar']=='no'):?>
<li class="close-sidebar" title=""><a href="#"><em>关闭右边栏</em></a></li>
<li class="show-sidebar" style="display:none;" title=""><a href="#"><em>开启右边栏</em></a></li>
<?php else: ?>
<li class="close-sidebar" style="display:none;" title=""><a href="#"><em>关闭右边栏</em></a></li>
<li class="show-sidebar" title=""><a href="#"><em>开启右边栏</em></a></li>
<?php endif;?>
<?php if($_COOKIE['show_sidebar']=='no'):?>
<style type="text/css">
#blog {width:770px;}
.box {width:760px;}
#rsidebar {display:none;}
</style>
<?php endif;?>
</ul>
<script type="text/javascript" language="javascript">
/* <![CDATA[ */
$(document).ready(function(){
(function(){
function SetCookie(c_name,value,expiredays){
var exdate=new Date();
exdate.setDate(exdate.getDate()+expiredays);
document.cookie=c_name+"="+escape(value)+((expiredays==null)?"":";expires="+exdate.toGMTString())+";path=/"; 
}
window['RootCookies'] = {};
window['RootCookies']['SetCookie'] = SetCookie;
})();
$('.close-sidebar').click(function() { 
RootCookies.SetCookie('show_sidebar', 'no', 1);
$('.close-sidebar').hide();
$('.show-sidebar').show();
$('#rsidebar').fadeOut(1000);
$('#blog').animate({width: "770px"}, 1000);
$('.box').animate({width: "760px"}, 1000);
});
$('.show-sidebar').click(function() {  
RootCookies.SetCookie('show_sidebar', 'no', -1);       
$('.show-sidebar').hide();
$('.close-sidebar').show();
$('#blog').animate({width: "550px"}, 1000);
$('.box').animate({width: "530px"}, 1000);
$('#rsidebar').animate({opacity: 1.0}, 500).fadeIn('slow');}); 
});
/* ]]> */
</script>
<script type="text/javascript" language="javascript">
/* <![CDATA[ */
$(document).ready(function(){
$('#rssfeed, #rssList').mouseover(function() {
if(window.willhide) clearTimeout(window.willhide);
$('#rssList').fadeIn(500);
});
$('#rssfeed,#rssList').mouseout(function() {
window.willhide = setTimeout(function() {
$('#rssList').fadeOut(500);
}, 750);
});
});
/* ]]> */
</script>
<div id="wrapper">
<div id="stheme_left">
<div class="sblk1"><div class="sblk2">
<a href="<?php echo BLOG_URL; ?>" title="首页"><img src="<?php echo TEMPLATE_URL; ?>images/home.gif" alt=""></img></a></div></div>
<div class="sblk1"><div class="sblk2">
<!--根据实际情况更改留言地址-->
<a href="<?php echo BLOG_URL; ?>guestbook.html" title="留言本"><img src="<?php echo TEMPLATE_URL; ?>images/smg.gif" alt=""></img></a></div></div>
<div class="sblk1"><div class="sblk2">
<a href="<?php echo BLOG_URL; ?>admin" title="博客登录"><img src="<?php echo TEMPLATE_URL; ?>images/slogout.gif" alt=""></img></a></div></div>
</div>

<div id="content">