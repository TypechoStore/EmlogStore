<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content_top">
<?php include View::getView('lsidebar');?>
<div id="blog">
<div class="box">
<div class="entry" id="post-1">
<div class="posttime"><div class="d"><?php echo gmdate('j', $date); ?></div><div class="m"><?php echo gmdate('m', $date); ?>月</div></div>
<div class="posttitle">
<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
<p class="postmeta">
<span class="comment"><a href="#respond" title="我要评论"><?php echo $comnum; ?>条评论</a></span>
<span class="category"><?php blog_sort($logid); ?></span>
<span class="date"><?php echo gmdate('Y年n月j日', $date); ?></span>
<span class="views">热度:<?php echo $views; ?>℃</span><?php editflg($logid,$author); ?></p></div>

		<div class="post"><?php echo $log_content; ?></div>
		<P class="tags"><?php blog_tag($logid); ?></P></div></div> 
	<div class="clear"></div>
<div class="box">
	<div id="comments">
	<h3>当前文章共有<?php echo $comnum; ?>条评论 | <a href="#respond"><font color="#006600">点击这里快速发表评论</font></a></h3>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
</div>
</div>
	<?php include View::getView('side');?>
</div>

<div id="content_foot"></div>
	</div>
<div class="clear"></div>	
</div>
<?php include View::getView('footer');
?>