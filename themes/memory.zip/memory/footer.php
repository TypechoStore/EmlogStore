<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?><footer><div class="main" id="footer">
    <span><?php doAction('index_footer'); ?> <a href="http://www.miibeian.gov.cn" target="_blank" rel="nofollow"><?php echo $icp; ?></a> <?php echo $footer_info; ?> <a href="http://www.aliyun.com/cps/rebate?from_uid=t/Svud2BQAg=" target="_blank" rel="nofollow">阿里云</a> <a href="http://www.emlog.net/templates/author-139" target="_blank" rel="nofollow">EMLOG</a>驱动</span>Copyright &copy;&nbsp;2007-2013 <a href="http://www.lvtao.net">吕滔个人主页</a> All rights reserved.
</div></footer>
</div>
</body>
</html>