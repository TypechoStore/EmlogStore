<?php 
/*
* 自定义404页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd" >
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>错误提示-页面未找到...</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="refresh" content="2; url=http://www.lvtao.net/">
<style>
body {margin-top:100px;background:#fff;font-family: Verdana, Tahoma;}
a {color:#CE4614;}
#msg-box {color: #CE4614; font-size:0.9em;text-align:center;}
#msg-box .logo {border-bottom:5px solid #ECE5D9;margin-bottom:20px;padding-bottom:10px;}
#msg-box .title {font-size:1.4em;font-weight:bold;margin:0 0 10px 0;}
#msg-box .nav {margin-top:20px;}
</style>
</head>
<body>
  <div id='msg-box'>

    <div class='logo'><a href="/"><img src="/content/templates/default/images/logo.png" border="0" alt=""></a></div>
    <div class='title'>抱歉，您访问的页面出现了一点点小故障...</div>
    <div class='msg'>我们已经将此错误信息记录下来，并将尽快处理，为此造成您的不便请多见谅</div>

    <div class='nav'><a href="javascript:history.go(-1)">返回上页</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="http://www.lvtao.net">返回首页</a></div>
  </div>
</body>
</html>
