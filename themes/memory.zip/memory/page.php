<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?><section>
<div class="container">
        <dl>
            <article>
            <dd class="content"><?php echo $log_content; ?></dd>
            </article>
            <div class="clear"></div>
            <?php blog_comments($comments,'titter'); ?>
        </dl>
        <div class="clear"></div>
        <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div></section>
<?php include View::getView('footer');?>