<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?><section>
<div class="container">
    <div class="leftCon">
        <div class="location">您的位置：<?php if($pageurl == Url::logPage()){ ?>
        <a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a>
        <?php }elseif ($params[1]=='sort'){ ?>
        <a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> <em>></em> <?php echo '<a href="'.Url::sort($sortid).'">'.$sortName.'</a>';?>
        <?php }elseif ($params[1]=='tag'){ ?>
        <a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> <em>></em> 标签 <?php echo urldecode($params[2]);?> 的所有文章
        <?php }elseif($params[1]=='author'){ ?>
        <a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> <em>></em> 作者 <?php echo blog_author($author);?> 的所有文章
        <?php }elseif($params[1]=='keyword'){ ?>
        <a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> <em>></em> 关键词 <?php echo urldecode($params[2]);?> 的搜索结果
        <?php }elseif($params[1]=='record'){ ?>
        <a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> <em>></em> 发表在 <?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?> 的所有文章
        <?php }?></div>
        <div class="divideLine"></div>
        <div class="con_tabBox">
            <ul class="clear">
                <article>
                <?php doAction('index_loglist_top'); ?>
                <?php foreach($logs as $value): ?>
                <li>
                    <dl>
                        <dt>
                            <div><?php echo gmdate('Y', $value['date']); ?></div><div><?php echo gmdate('n-j', $value['date']); ?></div> 
                        </dt>
                        <dd class="title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></dd>
                        <dd class="date">作者：<?php blog_author($value['author']); ?> 
    <?php blog_sort($value['logid']); ?> 
    <?php editflg($value['logid'],$value['author']); ?> <a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a>
    <a href="<?php echo $value['log_url']; ?>#tb"></a>
    <a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a> <?php blog_tag($value['logid']); ?></dd>
                        <dd class="detail"><span><?php echo $value['log_description']; ?></span></dd>
                        
                    </dl>
                </li>
                <?php endforeach; ?>
                </article>
            </ul>
            <div class="page"><?php echo $page_url;?></div>
        </div>
    </div>
    <div class="rightCon">
        <aside>
        <?php include View::getView('side');?>
        </aside>
    </div>
</div>
</section>
<?php if($pageurl == Url::logPage()){ ?>
<div id="link">
<?php
//widget：链接
    global $CACHE; 
    $link_cache = $CACHE->readCache('link');
    ?>
    <strong>+友情链接 <span style="font-weight:100;">(个人技术博客,接受PR>=3且有收录同类正规站点. 链接申请请发邮件:admin@lvtao.net.不符合要求的链接将予删除.敬请谅解)</span></strong>
    <p><?php foreach($link_cache as $value): ?><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a><?php endforeach; ?></p>
</div>
<?php }?>
<?php include View::getView('footer');?>