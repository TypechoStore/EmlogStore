<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?><section>
<div class="container">
    <div class="leftCon">
        <dl>
            <article>
            <dt id="title_article" class="title_article"><?php topflg($top); ?><?php echo $log_title; ?></dt>
            <dd class="share_article">作者：<?php blog_author($author); ?> 发布于：<?php echo gmdate('Y-n-j G:i l', $date); ?> 
    <?php blog_sort($logid); ?> <?php editflg($logid,$author); ?>
    </dd>
            <dd class="content"><?php echo $log_content; ?>
                <div class="wumii-hook">
                    <input type="hidden" name="wurl" value="<?php echo Url::log($logid); ?>" />
                    <input type="hidden" name="wtitle" value="<?php echo $log_title; ?>" />
                </div>
                <script>
                    var wumiiSitePrefix = "<?php echo BLOG_URL; ?>";
                </script>
            </dd>
            <dd class="tag"><?php blog_tag($logid); ?></dd>
            </article>
            <?php doAction('log_related', $logData); ?>
            <dd class="nextlog"><?php neighbor_log($neighborLog); ?></dd>
            <?php blog_trackback($tb, $tb_url, $allow_tb); ?>
            <?php blog_comments($comments); ?>
            <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
        </dl>
    </div>
    <div class="rightCon">
        <aside>
        <?php include View::getView('side');?>
        </aside>
    </div>
</div></section>
<?php include View::getView('footer');?>
