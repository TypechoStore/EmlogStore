<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<script>
function setTab(m,n){
    var menu = document.getElementById("tao"+ m).getElementsByTagName("span");   //获取标签组合
    var showDiv = document.getElementById("taolist"+ m).getElementsByTagName("div");    //获取内容组合
    for( var i=0;i<menu.length;i++){
        menu[i].className = i==n ?"hover":"";
        showDiv[i].style.display = i==n?"block":"none";
    }
}
</script>
<li class="tablist">
    <dl>
        <dt id="tao_nav">
            <span class="hover"  onmouseover='setTab("_nav",0)'>微信</span>
            <span  onmouseover='setTab("_nav",1)'>微博</span>
            <span  onmouseover='setTab("_nav",2)'>QQ</span>
            <span  onmouseover='setTab("_nav",3)'>网址</span>
        </dt>
        <dd id="taolist_nav">
            <div style="display:block;"><img src="http://www.lvtao.net/content/uploadfile/weixin.jpg"/></div>
            <div><img src="http://www.lvtao.net/content/uploadfile/sina.jpg"/></div>
            <div><img src="http://www.lvtao.net/content/uploadfile/qq.jpg"/></div>
            <div><img src="http://www.lvtao.net/content/uploadfile/web.jpg"/></div>
        </dd>
    </dl>
</li>
<ul id="sidebar">
<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
    $widget_title = @unserialize($options_cache['widget_title']);
    $custom_widget = @unserialize($options_cache['custom_widget']);
    if(strpos($val, 'custom_wg_') === 0)
    {
        $callback = 'widget_custom_text';
        if(function_exists($callback))
        {
            call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
        }
    }else{
        $callback = 'widget_'.$val;
        if(function_exists($callback))
        {
            preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
            $wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
            call_user_func($callback, htmlspecialchars($wgTitle));
        }
    }
}
?>
</ul><!--end #siderbar-->
