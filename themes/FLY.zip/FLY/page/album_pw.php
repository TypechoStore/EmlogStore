<section class="container container-no-sidebar">
<div class="content">
	<header class="article-header">
	<h1 class="article-title"><a href=""><?php echo $log_title;?>
	</a></h1>
	</header>
	<article class="article-content">
	<div class="mod-wrap-bd">
		<div class="photo-blank">
			<div class="blank-mask">
			</div>
			<div class="blank-tip">
				<form action="" method="post">
					<h1>请输入该相册的访问密码</h1>
					<label class="u-label input user">
					<input type="password" name="albumpwd" class="form-control input-lg" spellcheck="false" id="message-user" placeholder="" maxlength="36"></label>
					<label class="u-label f-nb ml05"><button id="message-submit" type="submit" class="btn btn-block btn-primary btn-lg">进入</button></label>
					<br/><br/><a href="<?php echo BLOG_URL;?>album/">&laquo;返回相册列表页面</a>
				</form>
			</div>
			<div class="left-side-mask">
			</div>
			<div class="right-side-mask">
			</div>
		</div>
	</div>
	</article>
</div>
</section>
<style>.article-header{display:none}
.container-no-sidebar{top:-30px;max-width:100%}
.container-no-sidebar .content{margin:0;padding:0}
.container-no-sidebar .article-content{margin-bottom:0}
.photo-blank{position:relative;height:764px;background-image:url(http://pjax.cn/content/templates/DUX/img/photo-blank.jpg);background-position:center;background-repeat:repeat}
.photo-blank .blank-mask{position:absolute;left:0;z-index:0;width:100%;height:764px;background:rgba(0,0,0,.6);filter:progid:DXImageTransform.Microsoft.gradient(enabled='true', startColorstr='#99000000', endColorstr='#99000000')}
:root .photo-blank .blank-mask{filter:none}
.photo-blank .blank-tip{position:relative;top:210px;z-index:3;margin:0 auto;width:564px;height:234px;color:#fff;text-align:center}
.photo-blank .blank-tip h1{margin-bottom:48px;text-align:center;font-weight:400;font-size:32px}
.photo-blank .blank-tip p{margin-bottom:8px;text-align:center;font-size:16px}
.photo-blank .left-side-mask{position:absolute;top:0;left:0;z-index:4;width:70px;height:764px;background-image:-webkit-linear-gradient(right,rgba(0,0,0,0),rgba(0,0,0,.8))}
.photo-blank .right-side-mask{position:absolute;top:0;right:0;z-index:4;width:70px;height:764px;background-image:-webkit-linear-gradient(left,rgba(0,0,0,0),rgba(0,0,0,.8))}
</style>
<?php include View::getView('footer');?>