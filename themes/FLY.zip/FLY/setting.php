<?php 
/*
 * LLY控制台
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
require_once('inc/config.php');
if (ROLE == ROLE_ADMIN):
require_once('inc/functions.php');
plugin_setting();
?>
<div id="<?php echo get_template_name();?>">
<section class="container">
<div class="content-wrap">
<div class="content">	
<div class="left-column">
<div id="setting" class="panel-sort">
<main id="main" class="site-main" role="main">
<form enctype="multipart/form-data" action="?setting&do=save" method="post" id="input" class="da-form">
  <div class="set_nav">
	<ul>
		<li class="active"><a href="#blog">基本设置</a></li>
        <li><a href="#plus">图标设置</a></li>
        <li><a href="#Slide">顶部广告</a></li>
        <li><a href="#Sortx">文字广告</a></li>
        <li><a href="#ADs">其他广告</a></li>
        <li><a href="#read">关于模板</a></li>
		<li class="last"><input type="submit" value="保 存" class="save" /></li>
	</ul>
</div>
<div class="set_cnt">
<div class="set_box" id="blog" style="display:block">
<div class="da-form-row">
<td class="right_td">站点LOGO：</td>
<td class="left_td"><input type="file" name="logo" style="display: inline-flex;" class="text-width"/></td>
<td class="right_td"><img src="<?php echo $logo ?  $logo : ''.TEMPLATE_URL."img/logo.png";?>" width="135px" height="32px" style="margin-left:5px;margin-top:-3px;border-radius: 3px;border:1px solid #eee;padding:2px"></td>
</div>
<div class="da-form-row">
<td class="right_td">是否开启自定义背景：</td>
<td class="left_td"><input name="bg_open" type="radio" value="1" <?php if ($bg_open == "1") echo 'checked'?> ></input></td>
<td class="right_td">开启</td>
<td class="left_td"><input name="bg_open" type="radio" value="2" <?php if ($bg_open == "2") echo 'checked'?> ></input></td>
<td class="right_td">关闭</td>
</div>
<div class="da-form-row">
<td class="right_td">自定义背景图片：</td>
<td class="left_td"><input type="file" name="bgimg" style="display: inline-flex;" class="text-width"/></td>
<td class="right_td"><img src="<?php echo $bgimg ?  $bgimg : ''.TEMPLATE_URL."img/bg.jpg";?>" width="135px" height="32px" style="margin-left:5px;margin-top:-3px;border-radius: 3px;border:1px solid #eee;padding:2px"></td>
</div>
<div class="da-form-row">
<td class="right_td">主体宽度：</td>
<td class="left_td"><input size="4" name="index_width" type="text" value="<?php echo $index_width; ?>"/></td>
<td class="right_td">单位为<span style="color:red">px</span>,不需要自己写</td>
</div>
<div class="da-form-row">
<td class="right_td">电影分类ID：</td>
<td class="left_td"><input size="2" name="dy_id" type="text" value="<?php echo $dy_id; ?>"/></td>
<td class="right_td">需要配合视频插件,否则设置一个没有的分类ID！</td>
</div>
<div class="da-form-row">
<td class="right_td">首页列表文章篇数：</td>
<td class="left_td"><input size="2" name="index_num" type="text" value="<?php echo $index_num; ?>"/></td>
</div>
<div class="da-form-row">
<td class="right_td">首页CMS风格分类ID：</td>
<td class="left_td"><input size="20" name="cms_id" type="text" value="<?php echo $cms_id; ?>" class="text-width"/></td>
<td class="right_td">多个模块之间用英文<span style="color:red">逗号</span>隔开即可！</td>
</div>
<div class="da-form-row">
<td class="right_td">源码压缩：</td>
<td class="left_td"><input name="compress_html" type="radio" value="1" <?php if ($compress_html == "1") echo 'checked'?> ></input></td>
<td class="right_td">开启</td>
<td class="left_td"><input name="compress_html" type="radio" value="2" <?php if ($compress_html == "2") echo 'checked'?> ></input></td>
<td class="right_td">关闭</td>
</div>
<div class="da-form-row">
<td class="right_td">侧边栏联系QQ：</td>
<td class="left_td"><input size="12" name="side_qq" type="text" value="<?php echo $side_qq; ?>"/></td>
<td class="right_td">需要打开侧边栏<span style="color:red">个人资料</span></td>
</div>
<div class="da-form-row">
<td class="right_td">开启菜单栏更多：</td>
<td class="left_td"><input name="more" type="radio" value="1" <?php if ($more == "1") echo 'checked'?> ></input></td>
<td class="right_td">开启</td>
<td class="left_td"><input name="more" type="radio" value="2" <?php if ($more == "2") echo 'checked'?> ></input></td>
<td class="right_td">关闭</td>
</div>
<div class="da-form-row">
<td class="right_td">菜单栏更多功能 (<span style="color:red; font-weight:bold">支持html代码</span>)</td><br/>
<p><textarea name="more_html" cols="125" rows="8" id="home_text" ><?php echo $more_html; ?></textarea></p>
</div>
<div class="da-form-row">
<td class="right_td">畅言评论 (<span style="color:red; font-weight:bold">支持html代码</span>)</td><br/>
<p><textarea name="changyan" cols="125" rows="8" id="home_text" ><?php echo $changyan; ?></textarea></p>
</div>
</div>
<div class="set_box" id="plus">
<div class="da-form-row">
<td class="right_td"><span style="color:red; font-weight:bold">导航设置: <a href="http://www.fontawesome.com.cn/faicons/" target="_black">Awesome 字体图标</a></span></td>
</div>
<div class="da-form-row">
<td class="right_td"> 导航图标设置(<span style="color:red; font-weight:bold">注意更改导航后需重新设置</span>)</td></br>
<?php
global $CACHE; 
global $arr_navico1; 
$navi_cache = $CACHE->readCache('navi');
foreach($navi_cache as $num=>$value):

        if ($value['pid'] != 0) {
            continue;
        }
		$id=$value["id"];
		
		echo '<td class="right_td">'.$value['naviname'].' &nbsp; =></td>
<td class="left_td"><input class="input"  value="'.$arr_navico1[$id].'" name="arr_navico['.$id.']"></td></br>';
endforeach;
?>
</div>
<div class="da-form-row">
<td class="right_td">分类和二级导航图标(<span style="color:red; font-weight:bold">注意更改分类后需重新设置</span>)</td></br>
<?php
global $CACHE;
$sort_cache = $CACHE->readCache('sort'); 
global $arr_navico1; 
foreach($sort_cache as $num=>$value):
		$sid=$value["sid"];
		
		echo '<td class="right_td">'.$value['sortname'].' &nbsp; =></td>
<td class="left_td"><input class="input"  value="'.$arr_sortico1[$sid].'" name="arr_sortico['.$sid.']"></td></br>';
endforeach;
?>
</div>
</div>
<div class="set_box" id="Slide">
<div class="da-form-row">
<td class="right_td">顶部图片广告（共5个）：</td>
<td class="left_td"><input name="qbkggn" type="radio" value="1" <?php if ($qbkggn == "1") echo 'checked'?> ></input></td>
<td class="right_td">开启</td>
<td class="left_td"><input name="qbkggn" type="radio" value="2" <?php if ($qbkggn == "2") echo 'checked'?> ></input></td>
<td class="right_td">关闭</td>
</div>
<div class="da-form-row">
<td class="right_td">广告图片1：</td>
<td class="left_td"><input size="30" name="dbtp1" type="text" value="<?php echo $dbtp1; ?>" class="text-width"/></td>
</div>
<div class="da-form-row">
<td class="right_td">广告链接1：</td>
<td class="left_td"><input size="30" name="dblj1" type="text" value="<?php echo $dblj1; ?>" class="text-width"/></td>
</div>
<div class="da-form-row">
<td class="right_td">广告图片2：</td>
<td class="left_td"><input size="30" name="dbtp2" type="text" value="<?php echo $dbtp2; ?>" class="text-width"/></td>
</div>
<div class="da-form-row">
<td class="right_td">广告链接2：</td>
<td class="left_td"><input size="30" name="dblj2" type="text" value="<?php echo $dblj2; ?>" class="text-width"/></td>
</div>
<div class="da-form-row">
<td class="right_td">广告图片3：</td>
<td class="left_td"><input size="30" name="dbtp3" type="text" value="<?php echo $dbtp3; ?>" class="text-width"/></td>
</div>
<div class="da-form-row">
<td class="right_td">广告链接3：</td>
<td class="left_td"><input size="30" name="dblj3" type="text" value="<?php echo $dblj3; ?>" class="text-width"/></td>
</div>
<div class="da-form-row">
<td class="right_td">广告图片4：</td>
<td class="left_td"><input size="30" name="dbtp4" type="text" value="<?php echo $dbtp4; ?>" class="text-width"/></td>
</div>
<div class="da-form-row">
<td class="right_td">广告链接4：</td>
<td class="left_td"><input size="30" name="dblj4" type="text" value="<?php echo $dblj4; ?>" class="text-width"/></td>
</div>
<div class="da-form-row">
<td class="right_td">广告图片5：</td>
<td class="left_td"><input size="30" name="dbtp5" type="text" value="<?php echo $dbtp5; ?>" class="text-width"/></td>
</div>
<div class="da-form-row">
<td class="right_td">广告链接5：</td>
<td class="left_td"><input size="30" name="dblj5" type="text" value="<?php echo $dblj5; ?>" class="text-width"/></td>
</div>

</div> 
<div class="set_box" id="Sortx">
<div class="da-form-row">
<td class="right_td">文字广告：</td>
<td class="left_td"><input name="wzggqiyong" type="radio" value="1" <?php if ($wzggqiyong == "1") echo 'checked'?> ></input></td>
<td class="right_td">开启</td>
<td class="left_td"><input name="wzggqiyong" type="radio" value="2" <?php if ($wzggqiyong == "2") echo 'checked'?> ></input></td>
<td class="right_td">关闭</td>
</div>
<div class="da-form-row">
<td class="right_td">文字广告1：(<span style="color:red; font-weight:bold">支持html代码</span>)</td><br/>
<p><textarea name="wzgg" cols="125" rows="8" id="home_text" ><?php echo $wzgg; ?></textarea></p>
</div>
</div>
<div class="set_box" id="ADs">
<div class="da-form-row">

<td class="right_td">开启广告：</td>
<td class="left_td"><input name="tupianqiyong" type="radio" value="1" <?php if ($tupianqiyong == "1") echo 'checked'?> ></input></td>
<td class="right_td">开启</td>
<td class="left_td"><input name="tupianqiyong" type="radio" value="2" <?php if ($tupianqiyong == "2") echo 'checked'?> ></input></td>
<td class="right_td">关闭</td>
</div>
<div class="da-form-row">
<td class="right_td">广告图片1：</td>
<td class="left_td"><input size="30" name="adimg1" type="text" value="<?php echo $adimg1; ?>" class="text-width"/></td>
</div>
<div class="da-form-row">
<td class="right_td">广告链接1：</td>
<td class="left_td"><input size="30" name="adurl1" type="text" value="<?php echo $adurl1; ?>" class="text-width"/></td>
</div>

<div class="da-form-row">
<td class="right_td">广告图片2：</td>
<td class="left_td"><input size="30" name="adimg2" type="text" value="<?php echo $adimg2; ?>" class="text-width"/></td>
</div>
<div class="da-form-row">
<td class="right_td">广告链接2：</td>
<td class="left_td"><input size="30" name="adurl2" type="text" value="<?php echo $adurl2; ?>" class="text-width"/></td>
</div>
<div class="da-form-row">
<td class="right_td">广告图片3：</td>
<td class="left_td"><input size="30" name="adimg3" type="text" value="<?php echo $adimg3; ?>" class="text-width"/></td>
</div>
<div class="da-form-row">
<td class="right_td">广告链接3：</td>
<td class="left_td"><input size="30" name="adurl3" type="text" value="<?php echo $adurl3; ?>" class="text-width"/></td>
</div>
<div class="da-form-row">
<td class="right_td">滚动广告文字：</td>
<td class="left_td"><input size="30" name="gdgg" type="text" value="<?php echo $gdgg; ?>" class="text-width"/></td>
</div>
<div class="da-form-row">
<td class="right_td">顶部网站描述：</td>
<td class="left_td"><input size="30" name="wzmiaoshu" type="text" value="<?php echo $wzmiaoshu; ?>" class="text-width"/></td>
</div>
</div>
<div class="set_box" id="read">
<div class="da-form-row">
<?php
$nonce_templet = Option::get('nonce_templet');
$nonceTplData = @implode('', @file(TPLS_PATH.$nonce_templet.'/header.php'));
preg_match("/Version:(.*)/i", $nonceTplData, $tplVersion);
define('Theme_Version' , !empty($tplVersion[1]) ? $tplVersion[1] : '' );
?>
<p>本主题请为七彩网络原创,在FLY1.4基础上二次开发</p>
<p>[KeCi]全站Pjax,响应式布局！</p>
<p>版本：<a herf="javascript:;" id="version">本主题已为最新版</a><span id="password" style="margin-left:5px;color:#666"></span></p>
<p>作者：<a href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank">七彩网络</a></p>
</div>
</div>  
</div>
</form>
</main>
</div>
</div>
<script>
$(function(){
	$(".set_nav li").not(".set_nav .last").click(function(e) {
		e.preventDefault();
		$(this).addClass("active").siblings().removeClass("active");
		$($(this).children("a").attr("href")).show().siblings().hide();
	});
	
  })
</script>
<div id="secondary" class="right-column">
<?php else:?>
<?php 
header("Location:".BLOG_URL.""); 
exit;
?> 
<?php endif; ?>
</div>
</div>
</div>
</section>
<?php include View::getView('inc/ajax_login');?>
</div>
<?php include View::getView('footer');?>