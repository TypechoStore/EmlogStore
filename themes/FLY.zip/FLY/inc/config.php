<?php
	$logo = '';
	$bg_open = '1';
	$bgimg = '';
	$arr_navico = 'a:4:{i:8;s:14:"fa fa-th-large";i:1;s:10:"fa fa-home";i:2;s:12:"fa fa-twitch";i:3;s:0:"";}';
	$arr_sortico = 'a:3:{i:1;s:14:"fa fa-th-large";i:3;s:14:"fa fa-th-large";i:4;s:0:"";}';
	$index_width = '1170';
	$index_num = '2';
	$fous_open = '';
	$fous_id = '';
	$dy_id = '9';
	$cms_id = '1,2,3,4,5,6,7';
	$side_qq = '972622982';
	$compress_html = '2';
	$more = '1';
	$more_html = '<li><a href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes"><i class="fa fa-picture-o"></i> 相册</a></li><li><a href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes"><i class="fa fa-music"></i> 音乐</a></li><li><a href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes"><i class="fa fa-list"></i> 归档</a></li><li><a href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes"><i class="fa fa-link"></i> 链接</a></li>';
	$Slide = '';
	$Slide1 = '';
	$Surl1 = '';
	$Slide2 = '';
	$Surl2 = '';
	$Slide3 = '';
	$Surl3 = '';
	$Sorts = '';
	$Sorth1 = '';
	$Sortp1 = '';
	$Sorta1 = '';
	$Sorth2 = '';
	$Sortp2 = '';
	$Sorta2 = '';
	$Sorth3 = '';
	$Sortp3 = '';
	$Sorta3 = '';
	$Sorth4 = '';
	$Sortp4 = '';
	$Sorta4 = '';
	$Sorth5 = '';
	$Sortp5 = '';
	$Sorta5 = '';
	$Sorth6 = '';
	$Sortp6 = '';
	$Sorta6 = '';
	$ads = '';
	$adimg1 = 'https://s1.ax1x.com/2018/09/19/ie4n4H.png';
	$adurl1 = 'http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes';
	$adimg2 = 'https://www.zy2hz.com/upFiles/infoImg/201810261016599531.png';
	$adurl2 = 'http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes';
	$adimg3 = 'https://www.zy2hz.com/style/uu_zy2hz/yxcz.png';
	$adurl3 = 'http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes';
	$dbtp1 = 'https://www.zy2hz.com/upFiles/infoImg/201807051757068144.jpg';
	$dblj1 = '';
	$dbtp2 = 'https://www.zy2hz.com/upFiles/infoImg/201807051757068144.jpg';
	$dblj2 = '';
	$dbtp3 = 'https://www.zy2hz.com/upFiles/infoImg/201807051757068144.jpg';
	$dblj3 = '';
	$dbtp4 = 'https://www.zy2hz.com/upFiles/infoImg/201807051757068144.jpg';
	$dblj4 = '';
	$dbtp5 = 'https://www.zy2hz.com/upFiles/infoImg/201807051757068144.jpg';
	$dblj5 = '';
	$wzmiaoshu = '七彩网络专注Emlog二次开发';
	$gdgg = '欢迎使用KeCi-cms主题！';
	$wzgg = '<table border="2" cellspacing="0" bordercolor="white" cellpadding="2" align="center" style="text-align:center;width:100%;">  <tbody>
    <tr>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
    </tr>
    <tr>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
    </tr>
    <tr>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
    </tr>
    <tr>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
    </tr>
    <tr>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
      <td><a rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes" target="_blank" title=""><font color="#999999" size="2"">广告位火爆招租8r</font></a></td>
  </tbody>
</table>';
	$wzggqiyong = '1';
	$tupianqiyong = '1';
	$qbkggn = '';
	$changyan = '';
?>