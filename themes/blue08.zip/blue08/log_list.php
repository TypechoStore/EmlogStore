<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="mainWrapper">

<div id="content" class="content">
<div id="innerContent">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<div class="textbox">
  <div class="textbox-title">
    <h4><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h4>
    <div class="textbox-label"><?php echo gmdate('Y-n-j G:i', $value['date']); ?> | <?php blog_sort($value['logid']); ?> 阅读：<?php echo $value['views']; ?> | 评论：<?php echo $value['comnum']; ?></div>
  </div>
  <div class="textbox-content">
<?php echo $value['log_description']; ?>
  </div>
</div>
<?php endforeach; ?>

<div id="pagenavi">
<?php echo $page_url;?></div>

</div>
</div>

<?php include View::getView('side');?>
<?php include View::getView('footer');?>