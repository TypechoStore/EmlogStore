<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="mainWrapper">

<div id="content" class="content">
<div id="innerContent">
<div class="textbox">
  <div class="textbox-title">
    <h4><?php echo $log_title; ?></h4>
  </div>
  <div id="textboxContent" class="textbox-content">
<?php echo $log_content; ?>
  </div>
</div>
<div class="textbox-urls">本页共有<?php echo $comnum; ?>条留言，点击<a href="#comment-post">这里</a>快速发表留言。</div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>