<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="mainWrapper">

<div id="content" class="content">
<div id="innerContent">
<div class="article-top">
<?php neighbor_log($neighborLog); ?>
  </div>

<div class="textbox">
  <div class="textbox-title">
    <h4><?php topflg($top); ?><?php echo $log_title; ?></h4>
    <div class="textbox-label"><?php echo gmdate('Y-n-j G:i', $date); ?> | <?php blog_sort($logid); ?> 阅读：<?php echo $views; ?> | 评论：<?php echo $comnum; ?></div>
  </div>
  <div id="textboxContent" class="textbox-content">
<?php echo $log_content; ?>
<div class="textbox-urls"><?php blog_tag($logid); ?><br />
<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
</div>
  </div>
	<?php doAction('log_related', $logData); ?>
</div>
<div class="textbox-urls">本文共有<?php echo $comnum; ?>条评论，点击<a href="#comment-post">这里</a>快速发表评论。</div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>