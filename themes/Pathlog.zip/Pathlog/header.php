<?php
/*
Template Name:Phthlog
Description:你好，这是一个私人的主题。（<a href="http://www.wangleiseo.cn/" title="王磊SEO">王磊SEO</a>移植，请尊重作者版权，保留底部链接！）碎语及分页借鉴<a href="http://blog.11ri.net">LaoLuo</a>发布的版本，并二次优化而成！
Version:1.1
Author:cho
Author Url:http://pagecho.com
Sidebar Amount:1
ForEmlog:5.0.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" media="all" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/base.js"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.backstretch.min.js"></script>
<script type="text/javascript"> 
$.backstretch("<?php echo TEMPLATE_URL; ?>images/japan.jpg", {speed: 150});
//背景图『大阪-夜色』: http://53hao.lofter.com/post/2711_37210c
</script>
<?php doAction('index_head'); ?>
<!--[if lt IE 9]>
<script src="<?php echo TEMPLATE_URL; ?>js/93D6C.js"></script>
<![endif]-->
</head>
<body>
<div class="clear_bg"></div>
<div class="body-inner">
		<div id="header">
		<header id="blog_title">
			<img src="<?php echo TEMPLATE_URL; ?>images/logo.png">
			<h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
						<span class="des"><?php echo $bloginfo; ?></span>
        </header>
			<nav id="menu"><?php blog_navi();?></nav>
			<form action="<?php echo BLOG_URL; ?>index.php" class="head-search" method="get">
				<input id="search-input" type="text" name="keyword" class="inputbox" value="搜索..." onfocus="if (value =='搜索...'){value =''}" onblur="if (value ==''){value='搜索...'}" x-webkit-speech lang="zh-CN" />
			</form>
		<div class="clear"></div>
    </div>
<div id="wrap">