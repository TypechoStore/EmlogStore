<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="timeline" class="vertical"></div>
<section id="content">
	<?php doAction('index_loglist_top'); ?>
	<?php foreach($logs as $value): ?>
		<div class="post_item">
		<article class="post">
			<header>
				<h2><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php topflg($value['top']); ?><?php echo $value['log_title']; ?></a></h2>
			</header>
			<div class="con">
			<?php echo $value['log_description']; ?></div>
		</article>
			<div class="post_bottom">
				<time><?php echo gmdate('F d, Y', $value['date']); ?></time> | <a rel="nofollow" href="<?php echo $value['log_url']; ?>#comments" title="添加新评论"><?php echo $value['comnum']; ?>个评论</a> | 作者：<?php blog_author($value['author']); ?>  <?php editflg($value['logid'],$value['author']); ?>
				<span class="premalink">
					<a rel="nofollow" href="<?php echo $value['log_url']; ?>" title="阅读全文「<?php echo $value['log_title']; ?>」"><?php echo $value['log_url']; ?></a>
				</span>
		</div>
		<div class="post_arrow"></div>
		</div>
		<div class="clear"></div>
		<?php endforeach; ?>
		<ol class="page-navigator">
			<?php echo $page_url;?>
		</ol>
<?php
 include View::getView('footer');
?>