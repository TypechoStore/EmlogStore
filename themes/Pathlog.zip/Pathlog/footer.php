<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</section><!--end #content-->
<div style="clear:both;"></div>
<footer id="footer"> 
		<div class="copy">Copyright ©  2010-2013 <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>  本主题由<a href="http://pagecho.com/">Cho's</a>制作			<span class="back2top">
				<a rel="nofollow" href="<?php echo BLOG_URL; ?>rss.php" target="_blank">Rss</a> / 
				Powered by <a rel="nofollow" href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> 
<a rel="nofollow" href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?> / 
				<a rel="nofollow" href="javascript:void(0);" onclick="MGJS.goTop();return false;">Top</a>
			</span><?php doAction('index_footer'); ?>
		</div></footer>
</div><!--end #wrap-->
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/F61B5.js"></script>
<script type="text/javascript"> 
jQuery('.con a:has(img)').lightBox();
</script> 
<script type="text/javascript">  
    if (top.location !== self.location) {  
      top.location = self.location;  
    }  
</script>
</body>
</html>