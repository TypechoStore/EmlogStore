<?php





/*





* 阅读日志页面





*/





if(!defined('EMLOG_ROOT')) {exit('error!');}





?>





<div id="container">





<div id="content">





<div class="clear"></div>





<div class="content_text">





	<div class="content_header">





    	<div class="title"><?php topflg($top); ?><?php echo $log_title; ?></div>





    	<div class="log_date"><?php echo gmdate('Y-n-j', $date); ?>|浏览(<?php echo $views; ?>)/评论(<?php echo $comnum; ?>) </div>





    </div><!--end of content_header-->





    <div class="new_content_header">





    </div><!--end of new_content_header-->





    <div class="clear"></div>





    <div class="text">





	<?php echo $log_content; ?>




	</div>





</div><!--content_text End-->




	<div class="att"><?php blog_att($logid); ?></div>





	<?php doAction('log_related', $logData); ?>





	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>





<?php blog_tag($logid); ?> <br>本文地址：<?php echo Url::log($logid); ?>,转载请注明地址





    <div class="nextlog"><?php neighbor_log($neighborLog); ?></div>





    <div style="clear:both;"></div>





    <p></p>





	<!-- UY BEGIN -->


<div id="uyan_frame"></div>


<script type="text/javascript" id="UYScript" src="http://v1.uyan.cc/js/iframe.js?UYUserId=891577" async=""></script>


<!-- UY END -->





	<div style="clear:both;"></div>





</div><!--end content-->





 </div><!--end of container-->





<?php





 include View::getView('footer');





?>