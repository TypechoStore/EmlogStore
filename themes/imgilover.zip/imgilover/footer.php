<?php





if(!defined('EMLOG_ROOT')) {exit('error!');}





?>





</div>





<div id="footer">Powered by<a href="http://www.emlog.net" target="_blank">Emlog</a> Theme By<a href="http://zhouchuan.net" target="_blank">周川工作室</a></div>





</body>





</html>











