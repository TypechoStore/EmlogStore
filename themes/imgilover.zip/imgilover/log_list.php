<?php 





if(!defined('EMLOG_ROOT')) {exit('error!');} 





?>





<?php doAction('index_loglist_top'); ?>





<div class="clear"></div>





<div id="log_list">



<center><DIV style="BORDER-RIGHT: #9D9D9D 3px dashed; BORDER-TOP: #9D9D9D 3px dashed; SCROLLBAR-FACE-COLOR: white; SCROLLBAR-HIGHLIGHT-COLOR: #9D9D9D; BORDER-LEFT: #9D9D9D 3px dashed; WIDTH: 863px; COLOR: #9D9D9D; BORDER-BOTTOM: #9D9D9D 3px dashed; SCROLLBAR-DARKSHADOW-COLOR: #9D9D9D; HEIGHT: 100px; BACKGROUND-COLOR: #ffffff" align=center>

<center><!-- ���λ��boyandgirl   860*100-->
</center>
<div id="content">
<?php foreach($logs as $value): ?>

    <div class="content_pre"><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>">


      <div class="lim"><?php get_content_img(preg_replace('/(<img.*?)border=(["\'])?.*?(?(2)\2|\s)([^>]+>)/is','$1$3',$value['content']));?></div>


	  <div class="date">


        <h2><?php echo $value['log_title']; ?></h2>
        time:<time class="time" datetime="<?php echo gmdate('Y-n-j', $value['date']); ?>" pubdate><?php echo gmdate('Y/n/j', $value['date']); ?></time>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; pv:<?php echo $value['views']; ?>


      </div>


      </a> </div><!--content_text End-->





<?php endforeach; ?>





<div id="pagenavi">





	<?php echo $page_url;?>


</div>





</div><!--end content-->





 </div><!--end of container-->





<?php





 include View::getView('footer');





?>