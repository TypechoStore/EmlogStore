<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
<div id="content">
<div class="clear"></div>
<div class="content_text">
	<div class="content_header">
    	<div class="title"><?php echo $log_title; ?></div> 
    </div><!--end of content_header-->
    <div class="clear"></div>
    <div class="text" style="text-indent: 0em;;">
	<?php echo $log_content; ?>
	</div>
</div><!--content_text End-->
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
</div><!--end content-->
 </div><!--end of container-->
<?php
 include View::getView('footer');
?>