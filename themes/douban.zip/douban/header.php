<?php
/*
Template Name:豆瓣模板
Description:简洁豆瓣，精仿豆瓣官方网站……
Version:1.1
Author:emlog
Author Url:http://www.qzee.net
Sidebar Amount:1
ForEmlog:4.2.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<!-- 使用url函数转换相关路径 -->
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" /> 
<!-- 通过自有函数输出HTML头部信息 -->
<?php doAction('index_head'); ?>
</head>
<body>
<div id="nav_box" class="clearfix">
<div class="container_16 bd"> 
<div class="top-nav-info">    
	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
	<a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a>
	<a href="<?php echo BLOG_URL; ?>admin/">管理中心</a>
	<a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a>
	<?php else: ?>
	<a href="<?php echo BLOG_URL; ?>admin/">登录</a>
	<?php endif; ?>
</div> 
<div class="top-nav-items"> 
<ul class="clearfix" id="nav_menu">
	<?php 
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach ($navi_cache as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	$val['is_blank'] = $val['newtab'] == 'y' ? 'target="_blank"' : '';
    $val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
	?>
	<li class="<?php echo isset($logid) && $key == $logid ? 'current' : 'common';?>"><a href="<?php echo $val['url']; ?>" target="<?php echo $val['is_blank']; ?>"><?php echo $val['naviname']; ?></a></li>
	<?php endforeach;?>
	<?php doAction('navbar', '<li class="common">', '</li>'); ?>
</ul>
</div>
</div>
</div>
<div id="header" class="container_16 clearfix">
	<div id="db-nav-main" class="site-nav"> 
    <div class="site-nav-logo"> 
       <a href="<?php echo BLOG_URL; ?>" title="<?php echo $bloginfo; ?>"> 
       <img src="<?php echo TEMPLATE_URL; ?>images/logo.png" alt="<?php echo $blogname; ?>" /> 
       <em><?php echo $blogname; ?></em> 
      </a> 
    </div>  
    <div class="bd"> 
    <div class="nav-srh"> 	
        <form method="post" action="/"> 
            <div class="inp"> 
                <span><input name="s" type="text" title="search" size="22" maxlength="60" value="" /></span> 
                <span><input class="bn-srh" type="submit" value="搜索" /></span> 
            </div> 
        </form> 
    </div>  
    <div class="site-nav-items"> 
        <ul> 
		    <li class="<?php echo $curpage == CURPAGE_HOME ? 'current' : 'common';?>"><a href="<?php echo BLOG_URL; ?>">首页</a></li>
	<?php if($istwitter == 'y'):?>
	<li class="<?php echo $curpage == CURPAGE_TW ? 'current' : 'common';?>"><a href="<?php echo BLOG_URL; ?>t/"><?php echo Option::get('twnavi');?></a></li>
	<?php endif;?>
        </ul> 
    </div> 
    </div> 
    </div>  
</div><!-- end #header -->
<div class="container_16 clearfix">