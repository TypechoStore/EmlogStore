<?php 
/*
* 底部信息
*
**************** Qzz 在此恳请各位博主不要删除我的链接 ****************
**************** 如有需求,欢迎大家到我博客相互交换友链 ****************
**************** 一直努力免费为大家制作模板,希望大家喜欢! ****************
*
*
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div class="grid_14" id="footer">	
	<span class="fleft gray-link"> &copy;  2012 <? echo $blogname ?></span>
    <span class="fright"><a href="http://qzee.net">Theme by Qzz</a>  
	· <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
	· Powered by <a href="http://www.emlog.net">emlog</a> 
	</span> 
	</div><!-- end #footer -->
</div>
<?php doAction('index_footer'); ?>
<!--[if IE 6]>
	<script src="http://letskillie6.googlecode.com/svn/trunk/letskillie6.zh_CN.pack.js"></script>
<![endif]-->
</body>
</html>