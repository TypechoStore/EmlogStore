<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
    <div class="grid_10" id="content">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
        <div class="post">
			<h2 class="entry_title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
			<p class="entry_data">
				<span>作者：<?php blog_author($value['author']); ?></span>
				<span>发布时间：<?php echo gmdate('F j, Y', $value['date']); ?></span>
				<span>分类：<?php blog_sort($value['logid']); ?> <?php editflg($value['logid'],$value['author']); ?></span>
				<a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?>回应</a>
			</p>
			<?php echo $value['log_description']; ?>
        </div>
<?php endforeach; ?>
    <div id="pagenavi"><?php echo $page_url;?></div>
    </div><!-- end #content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>