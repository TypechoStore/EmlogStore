<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
    <div class="grid_10" id="content">
        <div class="post">
			<h2 class="entry_title"><?php topflg($top); ?><?php echo $log_title; ?></h2>
			<p class="entry_data">
				<span>作者：<?php blog_author($author); ?></span>
				<span>发布于：<?php echo gmdate('Y-n-j G:i l', $date); ?> </span>
				<?php blog_sort($logid); ?> <?php editflg($logid,$author); ?>
			</p>
			<?php echo $log_content; ?>
			<p class="tags"><?php blog_att($logid); ?> <?php blog_tag($logid); ?></p>
		</div>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    </div><!-- end #content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>