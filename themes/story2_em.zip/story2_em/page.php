<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="column_2" class="SG_colW73">
<div class="SG_conn">
	<div class="SG_connHead">
		<span class="title">博客页面</span>
	</div>
	<div class="SG_connBody" >
		<div class="bloglist">
		<div class="blog_title_h">
		<span class="img1"></span>
		<div class="blog_title">
		<?php echo $log_title; ?>
		</div>
		</div>
					<div class="content"><?php echo $log_content; ?></div>	

						<div class="SG_j_linedot">
						</div>
					</div>
	<div class="writeComm">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
	</div>  
</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>