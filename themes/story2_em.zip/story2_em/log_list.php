<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="column_2" class="SG_colW73">
<div class="SG_conn">
	<div class="SG_connHead">
		<span class="title">我的博文</span>
	</div>
	<div class="SG_connBody" >
		<div class="bloglist">
		<?php doAction('index_loglist_top'); ?>
		<?php foreach($logs as $value): ?>
		<div class="blog_title_h">
		<span class="img1"></span>
		<div class="blog_title">
		<?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
		</div>
		<span class="time SG_txtc"><?php echo gmdate('Y-n-j G:i l', $value['date']); ?></span>
		</div>
					<div class="content"><?php echo $value['log_description']; ?></div>	
						<div class="tagMore">
							<div class="tag SG_txtc">
								   <?php blog_sort($value['logid']); ?>
								┆ <a href="<?php echo $value['log_url']; ?>">阅读</a>(<?php echo $value['views']; ?>)
								┆ <a href="<?php echo $value['log_url']; ?>#comments">评论</a>(<?php echo $value['comnum']; ?>)
								┆ <a href="<?php echo $value['log_url']; ?>">查看全文&raquo;</a>
								<?php editflg($value['logid'],$value['author']); ?></div>
							</div>
						<div class="SG_j_linedot"></div>
						<?php endforeach; ?>
					</div>
	</div>  

	<div id="pagenavi">
	<?php echo $page_url;?>
</div>
</div>
</div>

<?php
 include View::getView('side');
 include View::getView('footer');
?>