<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--/主体部分结束-->
<div class="sinablogfooter" style="position:relative;">
<p class="SG_linka">
<a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>博客驱动.主题由<a href="http://loek.us" target="_blank">loekman</a>仿制新浪博客.
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
</p>
<?php doAction('index_footer'); ?>
</div><!--/尾部 结束-->
</div>
</div><!--/全局结束-->
</body>
</html>