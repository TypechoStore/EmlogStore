<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="column_2" class="SG_colW73">
<div class="SG_conn">
	<div class="SG_connHead">
		<span class="title">我的博文</span>
	</div>
	<div class="SG_connBody" >
		<div class="bloglist">
		<div class="blog_title_h">
		<span class="img1"></span>
		<div class="blog_title">
		<?php topflg($top); ?><?php echo $log_title; ?>
		</div>
		<span class="time SG_txtc"><?php echo gmdate('Y-n-j G:i l', $date); ?> </span>
		</div>
					<div class="content"><?php echo $log_content; ?></div>	

<div class="bshare-custom"><a title="分享到" href="http://www.bShare.cn/" id="bshare-shareto" class="bshare-more">分享到：</a><a title="分享到QQ空间" class="bshare-qzone">QQ空间</a><a title="分享到新浪微博" class="bshare-sinaminiblog">新浪微博</a><a title="分享到人人网" class="bshare-renren">人人网</a><a title="分享到腾讯微博" class="bshare-qqmb">腾讯微博</a><a title="分享到豆瓣" class="bshare-douban">豆瓣</a><a title="更多平台" class="bshare-more bshare-more-icon more-style-addthis"></a></div><script type="text/javascript" charset="utf-8" src="http://static.bshare.cn/b/buttonLite.js#style=-1&amp;uuid=&amp;pophcol=3&amp;lang=zh"></script><script type="text/javascript" charset="utf-8" src="http://static.bshare.cn/b/bshareC0.js"></script>
						<div class="tagMore">
							<div class="tag SG_txtc">
								   <?php blog_sort($logid); ?>
								┆ 阅读(<?php echo $views; ?>)
								┆ <a href="<?php echo $value['log_url']; ?>#comments">评论</a>(<?php echo $comnum; ?>)
								<?php editflg($logid,$author); ?></div>
							</div>
						<div class="SG_j_linedot">
						</div>
				<div class="neighbor">
				<?php neighbor_log($neighborLog); ?>
				</div>
					</div>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<div class="writeComm">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
	</div>  
</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>