<?php
/*
Template Name:仿新浪博客《故事2》皮肤
Description:仿制新浪博客，不错的模板，顶部动态小猫...
Version:1.0
Author:loekman
Author Url:http://loek.us
Sidebar Amount:1
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>index.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<!--–[if lte IE 6]-->
<script type="text/javascript">
try{
document.execCommand("BackgroundImageCache", false, true);
}catch(e){}
</script>
<!--[endif]–-->
<?php doAction('index_head'); ?>
</head>
<body>
<div class="sinabloga" id="sinabloga">
<div id="sinablogb" class="sinablogb">

<!--头部开始 -->
<div id="sinablogHead" class="sinabloghead">
<!--背景flash -->
<div style="" id="headflash" class="headflash"><embed pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" src="<?php echo TEMPLATE_URL; ?>images/top.swf" width="950" height="306" style="undefined" id="headflash_f" name="headflash_f" bgcolor="#000" quality="high" allowscriptaccess="false" wmode="transparent" allowfullscreen="false"></div>
<!--文字显示区域 -->
<div id="headarea" class="headarea">
      <div id="blogTitle" class="blogtoparea">
      <h1 id="blogname" class="blogtitle"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
      <div id="bloglink" class="bloglink"><a href="<?php echo BLOG_URL; ?>"><?php echo BLOG_URL; ?></a> <?php echo $bloginfo; ?></div>
      </div>
      <div class="blognav" id="blognav">
      <div id="blognavBg" class="blognavBg"></div>
	  <div class="blognavInfo"> 
	  <?php blog_navi();?>
	  </div>
      </div>    		      		 	
    </div>

</div><!--/头部结束-->

<!--主体部分开始-->
<div class="sinablogbody" id="sinablogbody">