<div id="content-wrap" class="clear" > 
  <div id="content"> 
    <div id="main">
      <div class="post">
        <div class="right">
          <h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
          <p class="post-info"><?php blog_sort($logid); ?></p>
          <p><?php echo $log_content; ?></p>
          <div class="share-box clear" >
            <h4>分享到..</h4>
            <!-- Baidu Button BEGIN -->
<!-- Baidu Button BEGIN请把uid=6574935修改为自己的！ -->
<div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
<a class="bds_tsina"></a>
<a class="bds_qzone"></a>
<a class="bds_tqq"></a>
<a class="bds_renren"></a>
<a class="bds_t163"></a>
<a class="bds_hi"></a>
<a class="bds_diandian"></a>
<a class="bds_fbook"></a>
<a class="bds_twi"></a>
<span class="bds_more"></span>
<a class="shareCount"></a>
</div>
<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=6574935" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
</script>
<!-- Baidu Button END -->
          </div>
         <p> <?php doAction('log_related', $logData); ?></p>
        </div>
        <div class="left">
          <p class="dateinfo"><?php echo gmdate('M', $date); ?><span><?php echo gmdate('d', $date); ?></span></p>
          <div class="post-meta">
            <ul>
              <li class="user"><?php blog_author($author); ?></li>
              <li class="time"><?php echo gmdate('G:i l', $date); ?></li>
              <li class="comment"><a href="<?php echo $log_url; ?>#comments">评论(<?php echo $comnum; ?>)</a></li>
            </ul>
          </div>
          <div class="post-meta">
            <h4>标签</h4>
            <ul class="tags">
            <?php blog_tag($logid); ?>
            </ul>
          </div>
        </div>
      </div>
      <div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	  <?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    </div>
    <?php include View::getView('side');?>
  </div>
</div>
<?php include View::getView('footer');?>