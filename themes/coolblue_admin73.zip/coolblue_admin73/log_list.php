<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content-wrap" class="clear" > 
  <div id="content"> 
    <div id="main">
    <?php doAction('index_loglist_top'); ?>
      <?php foreach($logs as $value): ?>
      <div class="post">
        <div class="right">
          <h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
          <p class="post-info"><?php blog_sort($value['logid']); ?></p>
          <p><?php echo $value['log_description']; ?></p>
          </div>
        <div class="left">
          <p class="dateinfo"><?php echo gmdate('M', $value['date']); ?><span><?php echo gmdate('d', $value['date']); ?></span></p>
          <div class="post-meta">
            <ul>
              <li class="user"><?php blog_author($value['author']); ?></li>
              <li class="time"><?php echo gmdate('G:i l', $value['date']); ?></li>
              <li class="comment"><a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a></li>
            </ul>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
      <div id="pagenavi">
	<?php echo $page_url;?>
</div>
    </div>
  <?php include View::getView('side');?>
  </div>
</div>
<?php include View::getView('footer');?>