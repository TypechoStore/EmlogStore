<?php
/*
Template Name:CoolBlue
Description:CoolBlue
Version:5.17.13
Author:Admin73
Author Url:http://www.admin73.com/
Sidebar Amount:2
ForEmlog:5.0.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title><?php echo $site_title; ?></title>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<link href="<?php echo TEMPLATE_URL; ?>css/screen.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="header-wrap">
  <div id="header"> <a name="top"></a>
    <h1 id="logo-text"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
    <p id="slogan"><?php echo $bloginfo; ?></p>
    <div id="nav"><?php blog_navi();?></div>
    <p id="rss"> <a href="<?php echo BLOG_URL; ?>rss.php">如果喜欢就订阅我吧！</a> </p>
    <form id="quick-search" method="get" action="<?php echo BLOG_URL; ?>index.php">
      <fieldset class="search">
        <label for="qsearch">Search:</label>
        <input class="tbox" id="qsearch" type="text" name="qsearch" value="Search" title="使用ENTER搜索"  onFocus="if (value =='Search'){value =''}" onBlur="if (value ==''){value='Search'}" />
        <button class="btn" title="Submit Search">Search</button>
      </fieldset>
    </form>
  </div>
</div>