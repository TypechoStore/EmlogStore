<?php 
/**
 * 侧边栏组件、页面模块
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
    <div class="sidemenu">
        <h3><?php echo $title; ?></h3>
        <ul>
		<?php if (!empty($user_cache[1]['photo']['src'])): ?>
        <p> <a href="mailto:<?php echo $user_cache[1]['mail']; ?>"><img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="40" height="40" alt="firefox" class="float-left" /></a><?php endif;?> <?php echo $user_cache[1]['des']; ?> </p>
      </div>
<?php }?>
<?php
//widget：footblogger//页脚关注部分
function widget_ftblogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
    <div class="col-a">
      <h3>关注</h3>
      <?php if (!empty($user_cache[1]['photo']['src'])): ?>
      <p> <a href="mailto:<?php echo $user_cache[1]['mail']; ?>"><img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="40" height="40" alt="firefox" class="float-left" /></a><?php endif;?> <?php echo $user_cache[1]['des']; ?> </p>
      <ul class="subscribe-stuff">
        <li><a title="RSS" href="index.html" rel="nofollow"> <img alt="RSS" title="RSS" src="<?php echo TEMPLATE_URL; ?>images/social_rss.png" /></a> </li>
        <li><a title="Facebook" href="index.html" rel="nofollow"> <img alt="Facebook" title="Facebook" src="<?php echo TEMPLATE_URL; ?>images/social_facebook.png" /></a> </li>
        <li><a title="Twitter" href="index.html" rel="nofollow"> <img alt="Twitter" title="Twitter" src="<?php echo TEMPLATE_URL; ?>images/social_twitter.png" /></a> </li>
        <li><a title="E-mail this story to a friend!" href="index.html" rel="nofollow"> <img alt="E-mail this story to a friend!" title="E-mail this story to a friend!" src="<?php echo TEMPLATE_URL; ?>images/social_email.png" /></a> </li>
      </ul>
    </div>
<?php }?>
<?php
//widget：日历
function widget_calendar($title){ ?>
	<div class="sidemenu">
        <h3><?php echo $title; ?></h3>
        <ul>
	<div id="calendar">
	</div>
	<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
    </ul>
	</div>
<?php }?>
<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
	<div class="col-a">
      <h3><?php echo $title; ?></h3>
      <div class="footer-list">
        <ul>
	<?php foreach($tag_cache as $value): ?>
		<a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇文章"><span style="font-size:<?php echo $value['fontsize']; ?>pt; line-height:30px;"><?php echo $value['tagname']; ?></span></a>
	<?php endforeach; ?>
	</ul>	
    </div>
	</div>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
    <div class="sidemenu">
        <h3><?php echo $title; ?></h3>
        <ul>
        <?php
	foreach($sort_cache as $value):
		if ($value['pid'] != 0) continue;
	?>
          <li><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
	<a href="<?php echo BLOG_URL; ?>rss.php?sort=<?php echo $value['sid']; ?>">RSS</a>
    <?php if (!empty($value['children'])): ?>
    <?php
		$children = $value['children'];
		foreach ($children as $key):
			$value = $sort_cache[$key];
		?>
		<br/>
           ╘<a href="<?php echo Url::sort($value['sid']); ?>"> <?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
			<a href="<?php echo BLOG_URL; ?>rss.php?sort=<?php echo $value['sid']; ?>">RSS</a>
		<?php endforeach; ?>
        <?php endif; ?>
    </li>
	<?php endforeach; ?>
        </ul>
      </div>
  
<?php }?>
<?php
//widget：最新微语
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	?>
	<div class="sidemenu">
        <h3><?php echo $title; ?></h3>
        <ul>
	<?php foreach($newtws_cache as $value): ?>
	<?php $img = empty($value['img']) ? "" : '<img src="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" width=""/>';?>
    <li><a href="<?php echo BLOG_URL . 't/'; ?>" title="<?php echo $value['t']; ?>"><?php echo $value['t']; ?><?php echo $img;?> <br />
            <span><?php echo smartDate($value['date']); ?></span></a> </li>
		<?php endforeach; ?>
    <?php if ($istwitter == 'y') :?>
	<p><a href="<?php echo BLOG_URL . 't/'; ?>">更多&raquo;</a></p>
	<?php endif;?>
	</ul>
	</div>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
	<div class="col-a">
      <h3><?php echo $title; ?></h3>
      <div class="recent-comments">
        <ul>
	<?php
	foreach($com_cache as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	?>
	<li><a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a><br />
            &#45; <cite><?php echo $value['name']; ?></cite></li>
	<?php endforeach; ?>
	   </ul>
      </div>
    </div>
<?php }?>
<?php
//widget：页脚最新评论头像
function widget_newcommer($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
    <div id="gallery" class="clear">
      <h3>最新访客</h3>
      <p class="thumbs"><?php
	foreach($com_cache as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	$isGravatar = Option::get('isgravatar');
	?> 
    <a href="<?php echo $url; ?>" title="<?php echo $value['name']; ?>"><img src="<?php echo getGravatar($value['mail']); ?>" width="40" height="40"/></a>
    <?php endforeach; ?>
    </p>
    </div>    
<?php }?>
<?php
//widget：最新文章
function widget_newlog($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
	<div class="popular">
        <h3><?php echo $title; ?></h3>
        <ul>
	<?php foreach($newLogs_cache as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</div>
<?php }?>
<?php
//widget：热门文章
function widget_hotlog($title){
	$index_hotlognum = Option::get('index_hotlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getHotLog($index_hotlognum);?>
	<div class="popular">
        <h3><?php echo $title; ?></h3>
        <ul>
	<?php foreach($randLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</div>
<?php }?>
<?php
//widget：随机文章
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	 <div class="col-a">
      <h3><?php echo $title; ?></h3>
      <div class="footer-list">
      <ul>
	<?php foreach($randLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
    </div>
	</div>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
	<div class="sidemenu">
        <h3><?php echo $title; ?></h3>
	<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
	<input name="keyword"  type="text" />
	</form>
	</div>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
	<div class="sidemenu">
        <h3><?php echo $title; ?></h3>
	<ul>
	<?php foreach($record_cache as $value): ?>
	<li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
	<?php endforeach; ?>
	</ul>
	</div>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul>
	<?php echo $content; ?>
	</ul>
	</li>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
	?>
	<div class="sidemenu">
        <h3><?php echo $title; ?></h3>
        <ul>
	<?php foreach($link_cache as $value): ?>
	<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?><br />
            <span><?php echo $value['des']; ?></span></a></li>
	<?php endforeach; ?>
	</ul>
	</div>
<?php }?>
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	?>
	<ul>
	<?php
	$currentUrl = BLOG_URL . trim(Dispatcher::setPath(), '/');
	foreach($navi_cache as $value):
		if($value['type'] == 3 && (ROLE == 'admin' || ROLE == 'writer')):
			?>
			<li class="common"><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写文章</a></li>
			<li class="common"><a href="<?php echo BLOG_URL; ?>admin/">管理站点</a></li>
			<li class="common"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
		$current_tab = (BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url']) ? 'current' : 'common';
		?>
		<li id="<?php echo $current_tab;?>"><a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a></li>
	<?php endforeach; ?> 
	</ul>
<?php }?>
<?php
//blog：置顶
function topflg($istop){
	$topflg = $istop == 'y' ? "<img src=\"".TEMPLATE_URL."/images/import.gif\" title=\"置顶文章\" /> " : '';
	echo $topflg;
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == 'admin' || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
	分类：<a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
	<?php endif;?>
<?php }?>
<?php
//blog：文章标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "	<li><a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a></li>';
		}
		echo $tag;
	}
}
?>
<?php
//blog：文章作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog):?>
    <span class="float-left" style="margin-left:10px;">
	&laquo; <a href="<?php echo Url::log($prevLog['gid']) ?>"><?php echo $prevLog['title'];?></a></span>
	<?php endif;?>
	
	<?php if($nextLog):?><span class="float-right" style="margin-right:10px;">
		 <a href="<?php echo Url::log($nextLog['gid']) ?>"><?php echo $nextLog['title'];?></a>&raquo;</span>
	<?php endif;?>
<?php }?>
<?php
//blog：引用通告
function blog_trackback($tb, $tb_url, $allow_tb){
    if($allow_tb == 'y' && Option::get('istrackback') == 'y'):?>
	<div id="trackback_address">
	<p>引用地址: <input type="text" style="width:350px" class="input" value="<?php echo $tb_url; ?>">
	<a name="tb"></a></p>
	</div>
	<?php endif; ?>
	<?php foreach($tb as $key=>$value):?>
		<ul id="trackback">
		<li><a href="<?php echo $value['url'];?>" target="_blank"><?php echo $value['title'];?></a></li>
		<li>BLOG: <?php echo $value['blog_name'];?></li><li><?php echo $value['date'];?></li>
		</ul>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：评论列表
function blog_comments($comments){
    extract($comments);
     ?>
<div class="post-bottom-section">
         <?php if($commentStacks): ?><h4>评论</h4><a name="comments"></a><?php endif; ?>
        <div class="right">
          <ol class="commentlist">
          <?php
	$isGravatar = Option::get('isgravatar');
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
            <li class="depth-1" id="comment-<?php echo $comment['cid']; ?>">
            <a name="<?php echo $comment['cid']; ?>"></a>
              <div class="comment-info"><?php if($isGravatar == 'y'): ?> <img src="<?php echo getGravatar($comment['mail']); ?>" class="avatar" height="40" width="40" /><?php endif; ?> <cite> <?php echo $comment['poster']; ?> ： <br />
                <span class="comment-data"><?php echo $comment['date']; ?></span> </cite> </div>
              <div class="comment-text">
                <p><?php echo $comment['content']; ?></p>
                <div class="reply"> <a href="#blog_comments_post" onclick="commentReply(<?php echo $comment['cid']; ?>,this)" class="comment-reply-link">回复</a> </div>
              </div>
              <?php blog_comments_children($comments, $comment['children']); ?>
            </li>
            <?php endforeach; ?>
          </ol>
          <div id="pagenavi">
	    <?php echo $commentPageUrl;?>
    </div>
        </div>
      </div>
      <?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
<ul class="children">
                <li class="depth-2">
                  <div class="comment-info"> <?php if($isGravatar == 'y'): ?> <img src="<?php echo getGravatar($comment['mail']); ?>" class="avatar" height="40" width="40" /><?php endif; ?> <cite> <?php echo $comment['poster']; ?> ：  <br />
                    <span class="comment-data"><?php echo $comment['date']; ?></span> </cite> </div>
                  <div class="comment-text">
                    <p><?php echo $comment['content']; ?></p>
                    <div class="reply"> <a href="#blog_comments_post" onclick="commentReply(<?php echo $comment['cid']; ?>,this)" class="comment-reply-link">回复</a> </div>
                  </div>
                </li>
              </ul>
              <?php endforeach; ?>
              <?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?> 
    <a name="blog_comments_post"></a>
    <div class="post-bottom-section">
        <h4>发表评论</h4>
        <div class="right">
       
          <form action="<?php echo BLOG_URL; ?>index.php?action=addcom" method="post" id="commentform" name="commentform">
          <input type="hidden" name="gid" value="<?php echo $logid; ?>" />
          <?php if(ROLE == 'visitor'): ?>
            <p>
              <label for="name">昵称</label>
              <br />
              <input id="name" name="comname" value="<?php echo $ckname; ?>" type="text" tabindex="1" />
            </p>
            <p>
              <label for="email">邮件地址 (选填)</label>
              <br />
              <input id="email" name="commail" value="<?php echo $ckmail; ?>" type="text" tabindex="2" />
            </p>
            <p>
              <label for="website">个人主页 (选填)</label>
              <br />
              <input id="website" name="comurl" value="<?php echo $ckurl; ?>" type="text" tabindex="3" />
            </p>
            <?php endif; ?>
            <p>
              <label for="message" id="cancel-reply" style="display:none">请输入或<a href="javascript:void(0);" onclick="cancelReply()">取消回复</a></label>
              <br />
              <textarea id="message" name="comment" rows="10" cols="20" tabindex="4"></textarea>
            </p>
            <p class="no-border"><?php echo $verifyCode; ?>
              <input class="button" type="submit" value="发表评论" tabindex="5" />
              <input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/>
            </p>
          </form>
        </div>
      </div>	
      <?php endif; ?>
<?php }?>