<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="footer-outer" class="clear">
  <div id="footer-wrap">
    <?php widget_newcommer($value['title']); ?>
    <?php widget_ftblogger($value['title']); ?>
    <?php include View::getView('footer_side');?>
  </div>
</div>
<div id="footer-bottom">
  <p class="bottom-left">
  Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> 
  Theme by <a href="http://www.admin73.com" target="_blank">Admin73</a></p>
  <p class="bottom-right"> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>  <?php echo $footer_info; ?> <?php doAction('index_footer'); ?> | <strong><a href="#top">Back to Top</a></strong> </p>
</div>
</body>
</html>
