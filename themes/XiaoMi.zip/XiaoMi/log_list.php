<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="xmFocus">
	<div class="xmFocus_main">
	<div class="content">
		<?php doAction('index_loglist_top'); ?>
        <?php foreach($logs as $value): ?>
		<div class="post">
			<div class="iptt">
			<h2 class="ipt"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
			</div>
			<p><?php echo $value['log_description']; ?></p>
			<div class="ipxx">
			<?php blog_sort($value['logid']); ?><span><?php echo gmdate('Y-n-j'); ?></span>
			</div>
		</div>
<?php endforeach; ?>
	</div>
	<div class="accessories" style="margin:20px 0;">
	<div id="family_mi">
	<div class="pager"><ul id="yw0" class="yiiPager">
			<?php echo $page_url;?>
			</ul></div>
	</div></div>
	</div>
	<div class="xmFocus_side">
	<span class="side_right">
		<form name="keyform" id="searchform" method="get" action="<?php echo BLOG_URL; ?>">
        	<input name="keyword" id="s" class="text" type="text">
        	<input class="submit" type="submit" value="搜索">
      	</form>
</span>
<br /><br />
<br /><br />
<?php 
include View::getView('side');
?>
	</div>
</div>
<?php
 include View::getView('footer');
?>