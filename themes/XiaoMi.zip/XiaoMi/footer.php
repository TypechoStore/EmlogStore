﻿ <div id="footer">
            </div>
            <div class="copyright">
<?php echo $blogname; ?>版权所有</p><br /><a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>  本站使用<a href="http://www.emlog.net/">Emlog</a>技术构建
Theme by<a rel="nofollow" target="_blank" href="http://www.eniuwa.com/"title="易牛娃应用世界制作">  ENiuWa</a> <?php echo $footer_info; ?><?php doAction('index_footer'); ?></div></div>
<!---做个好孩纸，请保留作者链接-->
            </div>	
        </div>
    </body>
</html>