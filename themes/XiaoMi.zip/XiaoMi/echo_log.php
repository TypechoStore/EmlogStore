<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
            <div id="xmFocus">
	<div class="xmFocus_main">
	<div class="content" style="margin-top:0;">
		<div class="post">
			<div class="iptt" style="margin:0 0 10px;padding:0 0 10px;">
			<h2 class="ipt"><?php topflg($top); ?><?php echo $log_title; ?></h2>
			</div>
			<div class="ipxx">
			<?php blog_sort($logid); ?><span><?php echo gmdate('Y-n-j'); ?></span>
			</div>
			<?php echo $log_content; ?>
			<?php blog_tag($logid); ?>
		</div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
	</div>
	<div class="xmFocus_side">
		<?php 
 include View::getView('side');
		?>
	</div>
</div>
<?php
 include View::getView('footer');
?>