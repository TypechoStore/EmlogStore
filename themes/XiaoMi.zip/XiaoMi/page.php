<?php 
/*
* �Խ�ҳ��ģ��
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="xmFocus">
	<div class="xmFocus_main">
	<div class="content">
		<div class="post">
			<div class="iptt">
			<h2 class="ipt"><?php echo $log_title; ?></h2>
			</div>
			<?php echo $log_content; ?>
		</div>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
	</div>
	<div class="xmFocus_side">
		<?php 	
 include View::getView('side');
		?>
	</div>
</div>
<?php
 include View::getView('footer');
?>