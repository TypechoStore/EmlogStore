<?php
/*
Template Name:Sandfish
Description:Sandfish模板由幸福收藏夹制作，现在使其支持EMLOG
Version:2.0
Author:Kuma	
Author Url:http://www.cooron.net
Sidebar Amount:1
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<link rel='stylesheet' id='wp-pagenavi-css'  href='<?php echo TEMPLATE_URL; ?>pagenavi-css.css?ver=2.50' type='text/css' media='all' />
     <!--[if IE]>
    	<style type="text/css">@import url('<?php echo TEMPLATE_URL; ?>ie.css');</style>
    <![endif]-->
<style type="text/css" media="screen">
#toubiao{background:#eeeeee;border:#999999 1px solid;}
.bgrro{background-color:#f7f7f7;margin:0;padding:0;width:100%;}.bgrrro{margin:5px 0 5px 8px;}.bgrro1{padding:5px 0 1px 8px;}.editComment,.editableComment,.textComment{display:inline;}.comment-childs{border:#e2e8da 1px solid;margin:5px 5px 10px 8px;background-color:#FFF;}.comment-childs img{border:none;padding:0;}.comment-childs .userpic{float:left;margin-right:10px;}.comment-childs .userpic img{bottom:0;position:static;border:#e2e8da 1px solid;padding:1px;margin: 6px 2px 5px 5px;}.chalt{background-color:;}#newcommentsubmit{color:red;}.adminreplycomment{border:1px dashed #777;width:99%;margin:4px;padding:4px;}.mvccls{color:#999;}
</style>
</head>
<body>
	<div id="wrapper">

	<div id="header">
    	<div id="evlos_title"><h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
        <div id="description"><?php echo $bloginfo; ?></div></div>
		
    <div id="topnav">
		<?php blog_navi();?>
    </div><!--#topnav-->
    
    </div><!--#header-->
	<div id="container">
		<div id="content">