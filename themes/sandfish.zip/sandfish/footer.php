﻿<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>

<div id="footer">
        <p>CopyRight &copy; <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a> | <b><a rel="license" href="http://www.gnu.org/licenses/gpl.html">GNU General Public License</a></b> | All Right Reresve
        <br />
        <span>Theme by <a rel="nofollow" href="http://www.happinesz.cn" title="Designer" rel="designer">Sofish</a> | Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> |  For emlog by <a href="http://www.cooron.net">Kuma</a> | 本模板以 <a rel="nofollow" href="http://creativecommons.org/licenses/by-nc-nd/3.0/">CC协议</a> 许可 | <script src="http://s60.cnzz.com/stat.php?id=1772672&web_id=1772672" language="JavaScript" charset="gb2312"></script></span>

<script type="text/javascript">
var goto_top_type=-1;var goto_top_itv=0;function goto_top_timer(){var y=goto_top_type==1?document.documentElement.scrollTop:document.body.scrollTop;var moveby=15;y-=Math.ceil(y*moveby/100);if(y<0){y=0}if(goto_top_type==1){document.documentElement.scrollTop=y}else{document.body.scrollTop=y}if(y==0){clearInterval(goto_top_itv);goto_top_itv=0}}function goto_top(){if(goto_top_itv==0){if(document.documentElement&&document.documentElement.scrollTop){goto_top_type=1}else if(document.body&&document.body.scrollTop){goto_top_type=2}else{goto_top_type=0}if(goto_top_type>0){goto_top_itv=setInterval('goto_top_timer()',50)}}}
</script> 

<span id="evlos_totop"><a href="javascript:void(0)" onclick="goto_top()">返回顶部</a></span>
        </p>   
    </div><!--#footer-->

<!-- Generated in 0.421 seconds. Made 13 queries to database and 9 cached queries. Memory used - 28.65MB -->
<!-- Cached by DB Cache Reloaded -->

</div><!--#wrapper-->

</body>
</html>