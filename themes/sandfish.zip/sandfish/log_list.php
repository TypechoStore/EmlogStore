<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
        <div id="post-<?php echo $value['logid']; ?>" class="post">
            <h2 class="entry-title">
				<?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
			</h2>
            <div class="entry-info">
				<span class="icard"><?php blog_author($value['author']); ?></span>
				| <span class="idate"><?php echo date('Y-n-j G:i l', $value['date']); ?></span>
				| <span class="icomment">
					<a href="<?php echo $value['log_url']; ?>#comments" title="<?php echo $value['log_title']; ?>上的评论"><?php echo $value['comnum']; ?> Comments</a>
				  </span>
			</div>        
            <div class="entry-content"><?php echo $value['log_description']; ?></div>
        </div><!--.post-->
<?php endforeach; ?>       	
        <div class="navigation">
        	<div class="wp-pagenavi"><?php echo $page_url;?></div>
        </div>		    
    </div><!--#content-->
</div><!--#container-->	
<?php
require_once View::getView('side');
require_once View::getView('footer'); 
?>