<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div id="sidebar" class="sidebar">
         <p>
         <a href="<?php echo BLOG_URL; ?>rss.php" title="RSS Feed" class="feedme">RSS Feed</a>
         O(∩_∩)O 这里的所有文章，你都可以通过 <a class="rssli" href="<?php echo BLOG_URL; ?>rss.php" title="Rss Feed">Rss Feed</a> 来得到更新的通知。如果你使用订阅器，我想你可能会通过下面这些来订阅我：<br /><a class="xgli" href="http://www.xianguo.com/subscribe.php?url=<?php echo BLOG_URL; ?>rss.php" title="Xianguo Reader" rel="nofollow">鲜果</a>，<a class="grli" href="http://fusion.google.com/add?feedurl=<?php echo BLOG_URL; ?>rss.php" title="Google Reader" rel="nofollow">Google Reader</a>，<a class="zxli" href="http://www.zhuaxia.com/add_channel.php?url=<?php echo BLOG_URL; ?>rss.php" title="Zhuaxia Reader" rel="nofollow">抓虾</a>，<a class="ydli" href="http://reader.yodao.com/#url=<?php echo BLOG_URL; ?>rss.php" title="Yodao Reader" rel="nofollow">有道</a>。</p>
         <form id="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
                    <div>
                    <input id="s" name="keyword" class="text-input" type="text"  value="Search Here..." onblur="if(this.value=='') this.value='Search Here...';" onfocus="if(this.value=='Search Here...') this.value='';" size="10" tabindex="1" accesskey="S" value=""/>
                    <input id="logserch_logserch" class="submit-button" name="searchsubmit" type="submit" value="Find" tabindex="2" />
                    </div>
                </form>
<ul>
<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content'], $val);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>
</ul>
</div>
<!--end sidebar-->