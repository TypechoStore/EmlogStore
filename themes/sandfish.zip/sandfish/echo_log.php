<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>

<div id="post-<?php echo $logid;?>" class="post">
				<h2 class="entry-title"><?php echo $log_title; ?></h2>
                <div class="entry-info">
					<span class="ifolder"><?php blog_sort($sortid, $logid); ?></span> 
					| <?php blog_tag($logid); ?> 
					| <span class="idate"><?php echo date('Y-n-j G:i l', $date); ?></span>
				</div>
				<div class="entry-content"><?php echo $log_content; ?></div>
				<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
				<?php doAction('log_related', $logData); ?>
				<div class="clear"></div>
				<div class="entry-meta">
					<span class="itrackback"><?php blog_trackback($tb, $tb_url, $allow_tb); ?></span>
				</div>	 
			</div><!-- .post -->

			<div id="comments">
				<?php blog_comments($comments); ?>
				<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>

			</div><!-- #comments -->

		</div><!-- #content -->
	</div><!-- #container -->
<?php 
require_once View::getView('side');
require_once View::getView('footer'); 
?>