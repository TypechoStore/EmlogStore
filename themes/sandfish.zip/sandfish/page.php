<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div class="post">
				<div class="entry-content"><?php echo $log_content; ?></div>
			</div><!-- .post -->

			<div id="comments">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>

			</div><!-- #comments -->

		</div><!-- #content -->
	</div><!-- #container -->
<?php 
require_once View::getView('side');
require_once View::getView('footer'); 
?>