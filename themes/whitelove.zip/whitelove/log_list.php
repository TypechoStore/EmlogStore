<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

	<div id="content">

<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>

			<div class="post" id="post">
				<h2><a href="<?php echo $value['log_url']; ?>" rel="bookmark" title="Permanent Link to <?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></h2>
				<div class="postmetadata">Posted 
				<!-- the date and time -->
				on <?php echo gmdate('Y-n-j, G:i', $value['date']); ?>, 
				<!-- post author -->
				by <?php blog_author($value['author']); ?>, 
				<!-- post category -->
				under <?php blog_sort($value['logid']); ?>.
				</div>


				<div class="entry">
					<?php echo $value['log_description']; ?>
					<div class="clear"></div>
				</div>

				<div class="postmetadata">
				标签：<?php blog_tag($value['logid']); ?><br /> 
			    <?php editflg($value['logid'],$value['author']); ?> |  <a href="<?php echo $value['log_url']; ?>#comments" class="CommentsNumber"><?php if($value['comnum']==0){echo 'No Comments';}elseif($value['comnum']==1){echo '1 Comment';}else{echo $value['comnum'].' Comments';} ?></a></div>
			</div>

		<?php endforeach; ?>

		<div id="pagenavi">
		<?php echo $page_url;?>
		</div>

	</div>

<?php
 include View::getView('side');
 include View::getView('footer');
?>
