<?php
/*
Template Name:Whitelove
Description:wp移植主题
Version:1.0.0
Author:kami移植
Author Url:http://jingzipanda.com
Sidebar Amount:1
ForEmlog:4.1.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<!-- clouds -->
<div id="clouds">
<div id="page">


<div id="header">
	<div id="headerimage">
		<h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
		<div class="description"><?php echo $bloginfo; ?></div>
	</div>
</div>

<div id="hmenu">
<ul>
	<li class="<?php echo $curpage == CURPAGE_HOME ? 'current' : 'common';?>"><a href="<?php echo BLOG_URL; ?>">首页</a></li>
	<?php if($istwitter == 'y'):?>
	<li class="<?php echo $curpage == CURPAGE_TW ? 'current' : 'common';?>"><a href="<?php echo BLOG_URL; ?>t/"><?php echo Option::get('twnavi');?></a></li>
	<?php endif;?>
	<?php 
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach ($navi_cache as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	$newtab = $val['newtab'] == 'y' ? 'target="_blank"' : '';
    $val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
	?>
	<li class="<?php echo isset($logid) && $key == $logid ? 'current' : 'common';?>"><a href="<?php echo $val['url']; ?>" <?php echo $newtab; ?>><?php echo $val['naviname']; ?></a></li>
	<?php endforeach;?>
	<?php doAction('navbar', '<li class="common">', '</li>'); ?>
	<li id="hmenu_rss">	<a href="<?php echo BLOG_URL; ?>rss.php"  title="<?php echo $blogname; ?> RSS Feed">Feed</a></li>

</ul>
</div>
<hr />


<!-- add huadong daohang -->
<?php if($curpage == CURPAGE_HOME): ?>
<div id="shangxia"><div id="shang"></div><div id="xia"></div></div>
<?php else: ?>
<div id="shangxia"><div id="shang"></div><div id="comt"></div><div id="xia"></div></div>
<?php endif; ?>

<div id="wrapper">
