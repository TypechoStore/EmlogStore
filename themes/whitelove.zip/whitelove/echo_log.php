<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

	<div id="content">


		<div class="post" id="post">
			<h2><?php echo $log_title; ?></h2>
			
			<div class="postmetadata">Posted on <?php echo gmdate('Y-n-j, G:i', $date); ?>, by <?php blog_author($author); ?>, under <?php blog_sort($logid); ?>.</div>

			<div class="entry">
				<?php echo $log_content; ?>
				<div class="clear"></div>
			</div>

			<div class="postmetadata">
					标签：<?php blog_tag($logid); ?><br />
					<?php blog_att($logid); ?><br />				
					<a href="#respond">评论</a>
					&nbsp;|&nbsp;&nbsp;<a href="<?php echo $tb_url; ?> " rel="trackback">Trackback</a>
					&nbsp;|&nbsp;&nbsp<?php editflg($logid,$author); ?>
			 </div>
		</div>
        
        
        
        
 <div id="about">       
			<h3>Related Posts</h3>
			<ul>
             <?php doAction('log_related', $logData); ?>
		</ul>
		<div style="clear:both;"></div>
</div>
	<div id="comments">
	<ol class="commentlist">
	<a name="comments"></a>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</ol>
	</div>
		<div class="navigation">
			<?php neighbor_log($neighborLog); ?>
		</div>
	</div>
	
<?php
 include View::getView('side');
 include View::getView('footer');
?>
