//留言问题
css_string = '#comments{word-wrap: break-word; /*解决留言不换行的问题*/}';
//链接背景延迟
css_string += 'a:hover {-webkit-transition: all 1s;}';
//相关文章
css_string += 'h2,h3,#about';
css_string += '{text-shadow:2px 2px 2px #84C1FF}';
//lightbox
css_string += '#lightbox-nav-btnPrev, #lightbox-nav-btnNext {zoom: 1;}';
//标题
css_string += 'h1';
css_string += '{text-shadow:2px 2px 2px #84C1FF;font-weight: bold;}';
//头部
css_string += '#header, .description{text-shadow:2px 2px 2px #84C1FF;font-weight: bold;}';
//头像
css_string += '.avatar';
css_string += '{-moz-box-shadow: rgba(0,0,0,.8) 1px 5px 7px; -webkit-box-shadow: rgba(0,0,0,.8) 1px 5px 7px; -khtml-box-shadow: rgba(0,0,0,.8) 1px 5px 7px; box-shadow: rgba(0,0,0,.8) 1px 5px 7px;}';
//文章里的截图
css_string += 'a img';
css_string += '{opacity: 0.9; -webkit-transition: all 0.2s ease-out;}';
css_string += 'a:hover img { opacity: 1; -moz-transform: scale(1.05) rotate(2deg); -webkit-transform: scale(1.05) rotate(2deg); -o-transform: scale(1.05) rotate(2deg); }';

document.write('<style type="text\/css">' + css_string + '<\/style>');
//tabber
jQuery(document).ready(function($){ 
$('#tab-title span').click(function(){
	$(this).addClass("selected").siblings().removeClass();
	$("#tab-content > ul").slideUp('1500').eq($('#tab-title span').index(this)).slideDown('1500');
});
});
/*
jQuery(document).ready(function($){ 
$('#tab-title span').mouseover(function(){ 
$(this).addClass("selected").siblings().removeClass(); 
$("#tab-content > ul").eq($('#tab-title span').index(this)).show().siblings().hide(); 
}); 
}); 
*/

//huadong
jQuery(document).ready(function($) {
	var s = $('#shangxia').offset().top;
    $(window).scroll(function() {
        $("#shangxia").animate({
            top: $(window).scrollTop() + s + "px"
        },
        {
            queue: false,
            duration: 500
        })
    });
    $body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body');
    $('#shang').click(function() {
        $body.animate({
            scrollTop: '0px'
        },
        400)
    });
    $('#xia').click(function() {
        $body.animate({
            scrollTop: $('#footer').offset().top
        },
        400)
    });
    $('#comt').click(function() {
        $body.animate({
            scrollTop: $('#comments').offset().top
        },
        400)
    });
});

//reply
jQuery(document).ready(function($){	//Begin jQuery
	$('.reply').click(function() {
	var atid = '"#' + $(this).parent().attr("id") + '"';
	var atname = $(this).prevAll().find('cite:first').text();
	$("#comment").attr("value","<a href=" + atid + ">@" + atname + " </a>").focus();
});
	$('.cancel-comment-reply a').click(function() {	//点击取消回复评论清空评论框的内容
	$("#comment").attr("value",'');
});
});	//End jQuery

//clouds fuyun
	var scrollSpeed = 70;
	var step = 1;
	var current = 0;
	var imageWidth = 2247;
	var headerWidth = 800;		

	var restartPosition = -(imageWidth - headerWidth);

	function scrollBg(){
		current -= step;
		if (current == restartPosition){
			current = 0;
		}

		$('#clouds').css("background-position",current+"px 0");
	}

	var init = setInterval("scrollBg()", scrollSpeed);

//lazyload
jQuery(document).ready(
function($){
$("img").lazyload({
     placeholder : "http://img.blueandhack.com/lazyload/images/grey.gif",
     effect      : "fadeIn"
});
});

//new opne window
jQuery(document).ready(function($){
$("a[href*='http://']:not([href*='"+location.hostname+"']),[href*='https://']:not([href*='"+location.hostname+"'])") 
.addClass("external") 
.attr("target","_blank"); 
});

//Archives
jQuery(document).ready(function($){
 $('#expand_collapse,.archives-yearmonth').css({cursor:"s-resize"});
 $('#archives ul li ul.archives-monthlisting').hide();
 $('#archives ul li ul.archives-monthlisting:first').show();
 $('#archives ul li span.archives-yearmonth').click(function(){$(this).next().slideToggle('fast');return false;});
 //以下下是全局的操作
 $('#expand_collapse').toggle(
 function(){
 $('#archives ul li ul.archives-monthlisting').slideDown('fast');
 },
 function(){
 $('#archives ul li ul.archives-monthlisting').slideUp('fast');
 });
});