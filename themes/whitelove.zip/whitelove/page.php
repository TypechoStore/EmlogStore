<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

	<div id="content">
		<div class="post" id="post">
		<h2><?php echo $log_title; ?></h2>
			<div class="entry">
				<?php echo $log_content; ?>
				<div class="clear"></div>
			</div>
			<div class="postmetadata">
					<?php blog_att($logid); ?>
			 </div>
		</div>
	<div id="comments">
	<ol class="commentlist">
	<a name="comments"></a>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</ol>
	</div>
	</div>

<?php
 include View::getView('side');
 include View::getView('footer');
?>
