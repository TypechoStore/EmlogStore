<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<hr />


</div>

<div id="footer">

	<p>

		Powered by
		<a href="http://www.emlog.net">Emlog</a> and <a href="http://blueandhack.com">blueandhack</a> design <a href="http://jingzipanda.com" title="移植">ooxx</a> theme.<br />
		<br /><?php doAction('index_footer'); ?>
	</p>
</div>


		
</div>

<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/js/jquery.lazyload.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/js/all.js"></script>
<?php if($curpage == CURPAGE_LOG): ?>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/comments-ajax.js"></script>
<?php endif; ?>


</div>
<!-- clouds end -->



</body>
</html>