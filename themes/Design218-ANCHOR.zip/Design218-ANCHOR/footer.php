﻿<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div style="clear:both;"></div>
<div id="footerbar">
Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
&nbsp;|&nbsp;&nbsp;<a href="http://syoubunn.net/" title="syoubunn*">移植:syoubunn</a>&nbsp;&nbsp;|&nbsp;
<!--著作LINK<%template_delete>?改竄?変更厳禁！-->
<a href="http://anminn218.blog.fc2.com/" title="218*">[D]esigned&nbsp;by&nbsp;218*</a>
<!--/著作LINK<%template_delete>?改竄?変更厳禁-->
<?php doAction('index_footer'); ?>
</div><!--end #footerbar-->
</div><!--end #footerbar-->
</body>
</html>
<img src="http://syoubunn.net/mb/bottom.gif" border="0"><br clear="all">