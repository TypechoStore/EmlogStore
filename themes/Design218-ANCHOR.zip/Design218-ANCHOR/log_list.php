<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<img src="http://syoubunn.net/mb/top.gif" border="0"><br clear="all">
<div id="content">
<div id="contentleft">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
	<a href="<?php echo $value['log_url']; ?>" title="この記事を表示する"><?php echo gmdate('Y年n月j日', $value['date']); ?>&nbsp;&nbsp;/&nbsp;&nbsp;<?php echo $value['log_title']; ?></a>
    <div style="clear:both;"></div>
<?php endforeach; ?>
	</div>
	<div align="right"><a id="rss" rel="external nofollow" href="<?php echo BLOG_URL; ?>rss.php" title="RSS Feed">RSS Feed</a>&nbsp;&nbsp;/&nbsp;&nbsp;<a href="#top">▲</a></div>
<div id="pagenavi">
	<?php echo $page_url;?>
</div>
	<hr style="border:1px dashed #000; height:1px" >
	<div class="flink">
        <div class="data">  
			<div class="linktitle"> 友情链接 | BLOGROLL</div>
	<ul>
<?php {global $CACHE; $link_cache = $CACHE->readCache('link');foreach($link_cache as $value):?><li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li><?php endforeach; ?><?php }?>
    </ul>
        </div>
            </div>
	<?php
 include View::getView('footer');
?>
