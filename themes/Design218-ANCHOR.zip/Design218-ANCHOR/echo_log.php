﻿<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<img src="http://syoubunn.net/mb/top.gif" border="0"><br clear="all">
<div id="content">
<div id="contentleft">
<h3>
	<?php topflg($top); ?><?php echo $log_title; ?>&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;<?php echo gmdate('Y年n月j日', $date); ?>
</h3>
	<h2>
		<?php blog_sort($logid); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php blog_tag($logid); ?>
	</h2>
	<hr size="1" width="578" color=#E2E3EA align="center">
		<?php echo $log_content; ?>
	<div align=right><?php echo gmdate('G:i', $date); ?>&nbsp;&nbsp;/&nbsp;&nbsp;<a href="<?php echo $value['log_url']; ?>#comments">CM:<?php echo $comnum; ?></a>&nbsp;&nbsp;<a href="<?php echo $value['log_url']; ?>#tb">TB:<?php echo $tbcount; ?></a></div>
	<?php doAction('log_related', $logData); ?>
<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
<hr style="border:1px dashed #FFB1DB; height:1px" >
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<div style="clear:both;"></div>
</div><!--end #contentleft-->
	<div align="right"><a id="rss" rel="external nofollow" href="<?php echo BLOG_URL; ?>rss.php" title="RSS Feed">RSS Feed</a>&nbsp;&nbsp;/&nbsp;&nbsp;<a href="#top">▲</a></div>
<?php
 include View::getView('footer');
?>