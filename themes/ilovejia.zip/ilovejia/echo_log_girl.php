<?php 
/*
* boy日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="pagehead"> </div>
<div id="boy_body">
<!-- Begin #colLeft -->
<div class="body_left">
<div class="page_nav_Title">当前位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">网站首页</a> &raquo; 
<?php shouye_sort($logid); ?> &raquo; 正文</div>

	<ul class="Article_content">
        <li class="Title">
          <h1><?php echo $log_title; ?></h1>
        </li>
        <li class="Art_info"><?php blog_author($author); ?>&nbsp;/&nbsp;<?php echo gmdate('Y-n-j G:i', $date); ?>&nbsp;/&nbsp;浏览：<?php echo $views; ?> 人次&nbsp;/&nbsp;<span><a href="#comment-place" title="《<?php echo $log_title; ?>》上的评论">发表评论</a></span></li>
        <li class="bdshare"><!-- Baidu Button BEGIN -->
          
          <div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare"> <a class="bds_qzone"></a> <a class="bds_tsina"></a> <a class="bds_tqq"></a> <a class="bds_renren"></a> <span class="bds_more">更多</span> <a class="shareCount"></a> </div>
          <script type="text/javascript" id="bdshare_js" data="type=tools&uid=38631" ></script> 
          <script type="text/javascript" id="bdshell_js"></script> 
          <script type="text/javascript">

document.getElementById("bdshell_js").src = "http://share.baidu.com/static/js/shell_v2.js?t=" + new Date().getHours();

</script> 
          
          <!-- Baidu Button END --></li>
        <li class="Content">
          <?php echo $log_content; ?>
			
						
<center>
<script type="text/javascript">
/*文章末尾360*300*/
var cpro_id = "u1397024";
</script>
<script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script>		
</center>
         
          <p class="postTags"><?php blog_tag($logid); ?></p>
        </li>
      </ul>

		<div class="post-info">
			<h3>文档信息</h3>
			<ul>
				<li>版权声明：文章除注明外均为原创，转载请注明出处：原文来自《<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>》</li>
				<li>原文网址：<a href="<?php echo Url::log($logid); ?>"><?php echo Url::log($logid); ?></a></li>
				<li>订阅关注：<a href="<?php echo BLOG_URL; ?>/rss.php"><?php echo BLOG_URL; ?>rss.php</a></li>
				<li>赞助我们：<a href="https://me.alipay.com/amytask">https://me.alipay.com/amytask</a></li>
			</ul>
		</div>
	<!--百度推荐-->
	<center>
	<div id="hm_t_10058"></div>
</center>
	<!--百度推荐-->
	
<div style="text-align:left;margin-left:20px;"><?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    </div>
</div>
<div class="body_right">
<img src='<?php echo TEMPLATE_URL; ?>images/rand/<?php echo rand(0,11);?>.jpg' alt="<?php echo $blogname; ?>" />
<?php include View::getView('side');?>
<div class="vline" style='margin-top:12px;'>　</div>		</div>
</div>
<?php 
include View::getView('footer');
 ?>