<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div class="pagehead"> </div>
  <div id="girl_body">
    <div class="body_left"> <img src='<?php echo TEMPLATE_URL; ?>images/rand/<?php echo rand(0,11);?>.jpg' alt="<?php echo $blogname; ?>" />
    <?php include View::getView('side');?>
      <div class="vline" style='margin-top:12px;'>　</div>
    </div><!--左侧结束-->
<div class="body_right">
<div class="page_nav_Title">当前位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; 主人密语</div>
<div class="t_page">
<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
    <ul>
    <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?> 
    <li>
    <div class="main_img"><img src="<?php echo $avatar; ?>" width="32px" height="32px" /></div>
    <div class="post1"><span><?php echo $author; ?></span><br /><?php echo $val['t'].'<br/>'.$img;?></div>
    <div class="clear"></div>
    <div class="bttome" style="text-align: right;width: 690px;">
        <p class="post"><a href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">回复(<span id="rn_<?php echo $tid;?>"><?php echo $val['replynum'];?></span>)</a></p>
        <p class="time"><?php echo $val['date'];?> </p>
    </div>
	<div class="clear"></div>
   	   	<ul id="r_<?php echo $tid;?>" class="r"></ul>
    <?php if ($istreply == 'y'):?>
    <div class="huifu" id="rp_<?php echo $tid;?>">
	<textarea id="rtext_<?php echo $tid; ?>"></textarea>
    <div class="tbutton">
        <div class="tinfo" style="display:<?php if(ROLE == 'admin' || ROLE == 'writer'){echo 'none';}?>">
        昵称：<input type="text" id="rname_<?php echo $tid; ?>" value="" />
        <span style="display:<?php if($reply_code == 'n'){echo 'none';}?>">验证码：<input type="text" id="rcode_<?php echo $tid; ?>" value="" /><?php echo $rcode; ?></span>        
        </div>
        <input class="button_p" type="button" onclick="reply('<?php echo DYNAMIC_BLOGURL; ?>index.php?action=reply',<?php echo $tid;?>);" value="回复" /> 
        <div class="msg"><span id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></span></div>
    </div>
    </div>
    <?php endif;?>
    
    </li>
    <?php endforeach;?>
    </ul></div>
    <div class="Page_list" style="width:740px !important;"><?php echo $pageurl;?></div>
<?php else: ?> 
<p style="font-size:18px;padding:36px 18px;"><strong>主人密语</strong><br>只允许男/女主人登入后使用，其他任何人都不可以查看。</p>
<?php endif; ?>
</div>
  </div>
<?php 
include View::getView('footer');
 ?>
