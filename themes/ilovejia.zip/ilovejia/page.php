<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="pagehead"> </div>
  <div id="girl_body">
    <div class="body_left"> <img src='<?php echo TEMPLATE_URL; ?>images/rand/<?php echo rand(0,11);?>.jpg' alt="<?php echo $blogname; ?>" />
    <?php include View::getView('side');?>
      <div class="vline" style='margin-top:12px;'>　</div>
    </div><!--左侧结束-->
<div class="body_right">
<div class="page_nav_Title">当前位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">网站首页</a> &raquo; <?php echo $log_title; ?></div>
<div class="page_box">
<h2><?php echo $log_title; ?></h2><div class="clear"></div>
<div class="page_content">
<?php echo $log_content; ?>
</div><div class="clear"></div>
<div class="page_comments">
<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
</div>
</div>
  </div>
<?php include View::getView('footer');?>

	
	
