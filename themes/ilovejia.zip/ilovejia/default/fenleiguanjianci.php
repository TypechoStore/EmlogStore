<?php if($sortName == "绿色软件"): ?>
<?php $site_key ="绿色软件下载,软件绿化制作,绿色软件制作技巧,精品绿色软件,常用绿色软件下载";?>
<?php elseif($sortName == "随便写写"): ?>
<?php $site_key ="彩虹之家情感日记,生活记录,彩虹之家生活流水账";?>
<?php elseif($sortName == "免费资源"): ?>
<?php $site_key ="精品免费空间,免费账号信息资源,免费邀请码资源,免费注册码资源";?>
<?php elseif($sortName == "网站设计"): ?>
<?php $site_key ="免费个人网站模板,网站设计知识,网站设计素材,网页设计技巧";?>
<?php elseif($sortName == "网站推广"): ?>
<?php $site_key ="网站推广优化方案,操作网站推广的方法,分享网站推广中的技巧知识";?>
<?php elseif($sortName == "原创作品"): ?>
<?php $site_key ="彩虹之家原创作品,彩虹之家制作的模板,彩虹之家绿化的软件";?>
<?php else: ?>
<?php endif; ?>