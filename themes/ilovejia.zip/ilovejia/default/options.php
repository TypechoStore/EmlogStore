<?php
/**
 *配置文件
*/
//男生ID
$userid['boy'] = 1;
//女生ID
$userid['girl'] = 2;

?>