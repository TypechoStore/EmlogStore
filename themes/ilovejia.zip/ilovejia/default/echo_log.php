<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
if(in_array($author,$userid)) {
	$key = array_search($author,$userid);
	include View::getView('echo_log_'.$key);
};?>