<?php
/*
Template Name:情侣模板
Description:高出不胜寒专用模板
Version:1.0
Author:高出不胜寒
Author Url:http://caihongjia.net
Sidebar Amount:1
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
require_once View::getView('options');
require_once View::getView('fenleiguanjianci');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<?php if (isset($logid)) : ?>
<meta name="keywords" content="<?php wenzhang_tag($logid); ?>" />
<?php else: ?>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<?php endif; ?>
<meta name="description" content="<?php echo $site_description; ?>" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>css/style.css" rel="stylesheet" type="text/css" />
<script src="http://libs.baidu.com/jquery/1.7.2/jquery.min.js"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<style>
.post-info{width:698px;text-align:left;background:#aad2f0;color:#000;height:150px;padding:10px}
.post-info h3{padding:0 0 5px 0;background:none;border-bottom: 1px solid gray;font-size:21px;font-weight: normal;}
.post-info ul{margin: 10px 0 0 0;padding-left: 16px;}
.post-info ul li{font-size: 14px;line-height: 25px;color:#111;list-style: square;}
.post-info ul li a{color:#A90000 !important;text-decoration: none !important;}
.post-info ul li a:hover{color:#fff !important;text-decoration:underline !important;}
</style>
</head>
<body>
<div class="mainbg">
<div class="topbar">
<div class="topbar1"><p><span>男主人</span><strong>啊彩</strong><br />不在乎你的好与坏，愿意深陷的是我！</p></div>
<div class="topbar2">
<div class="topbar21"><img alt='彩虹之家男主人' src='<?php echo TEMPLATE_URL; ?>images/rand/0.jpg' class='avatar avatar-60 photo' height='60' width='60' /></div>
<div class="topbar22"><img alt='彩虹之家女主人' src='<?php echo TEMPLATE_URL; ?>images/rand/1.jpg' class='avatar avatar-60 photo' height='60' width='60' /></div>
</div>

    <div class="topbar3"><p><strong>啊红</strong><span>女主人</span><br />无垠的苍穹，因你的存在而炫丽辉煌！</p></div>

	<div class="topbar4"><script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/date.js"></script></div>

</div><!--topbar end-->