<?php 
/**
* 首页文章列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
if($author && in_array($author,$userid)) {
$key = array_search($author,$userid);
include View::getView('log_list_'.$key);
} else {
?>

<div class="head"></div>
<div class="index_body">
<?php

$sqlSegment = '';
if ($record) {
$sqlSegment = "and date>=$record_stime and date<$record_etime";
} elseif ($tag) {
$sqlSegment = "and gid IN ($blogIdStr)";
} elseif ($keyword) {
$sqlSegment = "and title like '%{$keyword}%'";
} elseif ($sortid) {
$sqlSegment = "and sortid=$sortid";
}
$emBlog=new Log_Model();
$boy_lognum = $emBlog->getLogNum('n', "and author={$userid['boy']} $sqlSegment order by top DESC ,date DESC");
$girl_lognum = $emBlog->getLogNum('n', "and author={$userid['girl']} $sqlSegment order by top DESC ,date DESC");
$lognum = $boy_lognum > $girl_lognum ? $boy_lognum : $girl_lognum;
$page_url = pagination($lognum, $index_lognum, $page, $pageurl);
$boy_logs = $emBlog->getLogsForHome("and author={$userid['boy']} $sqlSegment order by top DESC ,date DESC", $page, $index_lognum);
$girl_logs = $emBlog->getLogsForHome("and author={$userid['girl']} $sqlSegment order by top DESC ,date DESC", $page, $index_lognum);
?>

<div class="index_left">
<div class="Left_img"><img src="<?php echo TEMPLATE_URL; ?>images/spring.jpg" alt="男主人专区"/></div>
<?php if (!empty($boy_logs)): foreach($boy_logs as $value): ?>
<?php $value['log_description'] = strip_tags($value['log_description']);?>
<ul class="indexlist" id="post-<?php echo $value['logid']; ?>">
<li class="title"><h2><a href="<?php echo $value['log_url']; ?>" rel="bookmark"><?php echo $value['log_title']; ?></a></h2></li>
<li class="content">
<?php get_thum($value['logid']);?><?php echo $value['log_description']; ?></li>
<li class="link"><span style="float:left;"><?php echo gmdate('Y-m-d', $value['date']); ?></span><span style="float:right;"><?php echo $value['views']; ?>次浏览 / <a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?> Comments条评论</a></span></li>
</ul>
<?php endforeach;else:?>
<h2>未找到</h2>
<p>对不起，男主人最近好像很忙。</p>
<?php endif;?>
</div><!--男主人专区结束-->
<!--首页中间部分开始-->
<div class="index_mid">
<img src='<?php echo TEMPLATE_URL; ?>images/rand/<?php echo rand(0,11);?>.jpg' alt="<?php echo $blogname; ?>"/><!--随机图片-->
<!-- Baidu Button BEGIN -->
<div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare" style="margin-left:21px;">
<a class="bds_qzone"></a>
<a class="bds_tsina"></a>
<a class="bds_tqq"></a>
<a class="bds_renren"></a>
<span class="bds_more"></span>
<a class="shareCount"></a>
</div>
<script type="text/javascript" id="bdshare_js" data="type=tools&amp;mini=1&amp;uid=224514" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?t=" + new Date().getHours();
</script>
<!-- Baidu Button END -->
<?php blog_navi();?>

<div class="sidebar">
<h2><strong>登陆入口</strong></h2>
<?php if(ROLE == 'admin' || ROLE == 'writer'):?>
<ul class="login">
<li style="margin-top:10px;height:35px;"><a style="background:#2AB5DC;padding:10px;border-radius:5px;color:#fff;margin-right:5px;font-family:Arial;letter-spacing:1px;" href="<?php echo BLOG_URL; ?>admin/">管理中心</a> <a style="background:#ff006c;padding:10px;border-radius:5px;color:#fff;font-family:Arial;letter-spacing:1px;" href="<?php echo BLOG_URL; ?>admin/?action=logout">注销账号</a></li>
</ul>
<?php else: ?>
<form name="f" action="<?php echo BLOG_URL; ?>admin/index.php?action=login" method="post">
<ul class="login">
<li><label for="log">园主帐户：</label><input type="text" name="user" id="user" value="" /></li>
<li><label for="pwd">登陆密码：</label><input type="password" name="pw" id="pw" /></li>
<li><input type="submit" name="submit" value="确 定"  class="submit1">&nbsp; &nbsp;<input type="reset" value="取 消" name="Submit2" class="submit2"><input type="hidden" name="redirect_to" value="/"/></li>
</ul>
</form>
<?php endif; ?>
</div>

<?php widget_hotlog("热点排行");?><!--热点排行-->

<?php widget_random_log("随机文章");?><!--随机文章-->

<?php widget_newcomm("最新评论");?><!--最新评论-->

<?php widget_link("友情链接");?><!--友情链接-->

<div class="vline" style='margin-top:12px;'>　</div>	</div>
<!--首页中间部分结束-->
<div class="index_right">
<div class="Right_img"><img src="<?php echo TEMPLATE_URL; ?>images/Wedding.jpg" alt="女主人专区"/></div>
<?php if (!empty($girl_logs)): foreach($girl_logs as $value): ?>
<?php $value['log_description'] = strip_tags($value['log_description']);?>
<ul class="indexlist" id="post-<?php echo $value['logid']; ?>">
<li class="title"><h2><a href="<?php echo $value['log_url']; ?>" rel="bookmark"><?php echo $value['log_title']; ?></a></h2></li>
<li class="content">
<?php get_thum($value['logid']);?>
<?php echo $value['log_description']; ?></li>
<li class="link"><span style="float:left;"><?php echo gmdate('Y-m-d', $value['date']); ?></span><span style="float:right;"><?php echo $value['views']; ?>次浏览 / <a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?> Comments条评论</a></span></li>
</ul>
<?php endforeach;else:?>
<h2>未找到</h2>
<p>对不起，女主人最近好像很忙。</p>
<?php endif;?>
</div><!--女主人专区结束-->
</div>
<div class="bottom_line"> </div>
<div class="Page_list"><?php echo $page_url;?></div><!--分页-->


<?php
include View::getView('footer');
?>
<?php } ?>