<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="bottom_line2"> </div>

<div class="bottom">

	<div id="copyright">Copyright © 2005 - 2013 caihongjia.net.All Rights Reserved.Powered by:emlog
<?php echo $footer_info; ?> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php doAction('index_footer'); ?></div>
	
</div><!--底部信息-->



</div>
</body>
</html>