<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>
<div class="rolltotop"><a class="rollico ico-totop" title="回顶部"></a></div>
<div class="clear"></div>
<div id="footer"><div class="clear"></div>
<div class="copyright">
Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> | 
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> | <?php echo $footer_info; ?> | 
<?php doAction('index_footer'); ?></div></div>

</div>
	<script type="text/javascript">
		jQuery(document).ready(function(){
		jQuery("#mp_loading div").animate({width:"100%"},800,function(){
		setTimeout(function(){jQuery("#mp_loading div").fadeOut(500);});});});
	</script>
</body>
</html>