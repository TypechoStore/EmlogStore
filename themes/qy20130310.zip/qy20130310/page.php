<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

	<div id="roll">
<div title="回到顶部" id="roll_top">
</div>
<div title="转到底部" id="fall">
</div>
</div>
<div id="content">
<div class="main">
<div class="crumbs">
<div class="crumbs_name"><i></i><p>当前位置：</p></div>
<ul> 
<a  title="返回首页" href="<?php echo BLOG_URL; ?>">首页 &raquo;</a> 
<?php echo $log_title; ?>
</ul>
</div>

<div class="clear"></div>
<div class="left">
<div class="single">
		<div class="clear"></div>
	<div class="single_read">	
		<?php echo $log_content; ?>	
</div>	
		</div>			
	</div>	
<!-- 评论开始 -->
<div class="clear"></div>
<div class="left">
<div class="review">
<!-- 评论列表star -->
<?php blog_comments($comments); ?>
</div>
<!-- 评论列表end -->

<!-- 发表评论star -->
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);?>
<!-- 发表评论end -->


</div>
<!-- 评论结束 -->
</div>
</div>
	<!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>