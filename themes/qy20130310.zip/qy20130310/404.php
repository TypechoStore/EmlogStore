<?php 
/*
* 自定义404页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="<?php echo TEMPLATE_URL; ?>images/favicon.ico" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<title>404页面-老妖|老妖工作室专注互联网，专业提供企业网站建设服务</title>
</style>
</head>
<body>
<div id="content">
<div class="main">


<div class="clear"></div>
<div id="mp_404">
<div class="mp_404img"></div>
<div class="mp_404tit">
<h3>
<i>404先生说:</i><br>
朋友，我是一个受伤的404页面，请让我一边待去吧。<br>
或许你可以点击下面的点击返回。
</h3>
<p><a href="javascript:history.back(-1);">&laquo;点击返回</a></p>
</div>
</div>
</div>
</div>
</div>
</body>
</html>