<?php 
/*
* 日志阅读页
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="roll">
<div title="回到顶部" id="roll_top">
</div>
<div title="转到底部" id="fall">
</div>
</div>
<div id="content">
<div class="main">
<div class="crumbs">
<div class="crumbs_name"><i></i><p>当前位置：</p></div>
<ul> 
<a  title="返回首页" href="<?php echo BLOG_URL; ?>">首页 &raquo;</a> 
<a href=""><?php blog_sort($logid); ?></a> &raquo;正文
</ul>
</div>

<div class="clear"></div>


<div class="clear">
</div>

<div class="leftad">
<img src="<?php echo TEMPLATE_URL; ?>images/ypkyskil.gif" />
</div>

<div class="left">
	<div class="single">
		<div class="mp_single">
	<h2 style="text-align: center"><?php topflg($top); ?><?php echo $log_title; ?></h2>
	<div class="single_info">作者：<?php blog_author($author); ?>于<?php echo gmdate('Y-n-j', $date); ?>发布在
	<?php blog_sort($logid); ?> / 阅读<?php echo $views; ?> 次 / 共有<?php echo $comnum; ?>条评论</div>
			<div class="clear"></div>
	<div class="single_read">
<?php echo $log_content; ?>	
			<div class="single_paging">
						</div>
			</div>	
<div class="clear"></div>
	<div class="mp_boke">
	ad
	</div>
			<div class="single_card">
			<ul>
				<li><?php blog_trackback($tb, $tb_url, $allow_tb); ?></li>
			<li><?php blog_tag($logid); ?></li>
			<li>该日志于&nbsp;<?php echo gmdate('Y-n-j H:i', $date); ?>&nbsp;由&nbsp;<?php blog_author($author); ?>&nbsp;发表在&nbsp;<a href="<?php echo BLOG_URL; ?>">老妖工作室</a>&nbsp;网站上，你除了可以发表评论外，还可以转载"<?php echo $log_title;?>"日志到你的网站或博客，但是请保留源地址及作者信息，谢谢!!</li>
			
			<li>	<?php doAction('log_related', $logData); ?></li>
			
			</ul>
	</div>		</div>
	</div>
</div>
<div class="clear"></div>
<div class="left">
<div class="xiangguan">
<div class="postinfo">
	<div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare">
	<a class="bds_qzone"></a>
	<a class="bds_tqq"></a>
	<a class="bds_tsina"></a>
	<a class="bds_tsohu"></a>
	<a class="bds_t163"></a>
	<a class="bds_renren"></a>
	<a class="bds_hi"></a>
	<a class="bds_kaixin001"></a>
	<a class="bds_ty"></a>
	<span class="bds_more"></span>
	</div>
<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=0" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
</script>
</div>	
<div class="related_posts">
<?php get_rand_log();?>

</div>
</div>
<!-- 评论开始 -->
<div class="clear"></div>
<div class="left">
<div class="review">
<!-- 评论列表star -->
<?php blog_comments($comments); ?>

<!-- 评论列表end -->

<!-- 发表评论star -->
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);?>
<!-- 发表评论end -->
</div>
</div>
</div>
<!-- 评论结束 -->
</div>
</div>
<?php include View::getView('side'); ?>
<?php include View::getView('footer'); ?>