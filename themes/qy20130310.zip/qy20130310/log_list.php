<?php 
/*
* 日志列表
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
if($pageurl == Url::logPage()){
	include View::getView('index');
}else{
	include View::getView('list');
	}
?>
<?php
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php

 include View::getView('footer');
?>
