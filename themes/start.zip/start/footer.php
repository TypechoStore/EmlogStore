<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	</div>
	</div>
	<!-- 尾部 -->
	<div class="g-ft">
		<p class="m-cprt">&copy;&nbsp;<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>&nbsp;|&nbsp;Powered by EMLOG</p>	<?php doAction('index_footer'); ?> 
	</div>
</div>
<script type="text/javascript" src="http://l.bst.126.net/rsc/js/jquery-1.6.2.min.js" ></script>



<script>window.Theme = {'ImageProtected':true,'CcType':0,ContextValue:'版权保护'};</script>
<script src="http://l.bst.126.net/rsc/js/themecommon.js?0027" type="text/javascript"></script>

</body>
</html>