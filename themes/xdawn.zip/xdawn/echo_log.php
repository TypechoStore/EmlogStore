<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="container">
<div class="single">	
<div class="breadcrumbsclear">
  <ul class="breadcrumbs">
  <li><a href="<?php echo BLOG_URL; ?>">首页&nbsp;</a>
   &gt; <?php echo $log_title; ?></li>
  </ul>
</div>
<h1 class="singleposth1 zhenghei">
   <?php topflg($top); ?><?php echo $log_title; ?>
</h1>
	<div class="singleinfo">
		<span class="singletime"><?php echo gmdate('Y-n-j', $date); ?> </span>
		<span class="singlecom"><?php if($comnum){echo $comnum;?> comments <?php }else{?>NO comment <?php }?></span>
		<span class="singleview"><?php echo $views; ?> views </span>  
		<span class="singleedit"><?php blog_sort($logid); ?> </span>
	    <?php editflg($logid,$author); ?>
	</div>
	<section class="content cf">
	<?php echo $log_content; ?>	
	<?php doAction('log_related', $logData); ?>
    </section>
	<div class="relatebar">	
    <span class="relatetitle">暧昧帖:</span>
    <ul class="cf">	
	<?php $Log_Model = new Log_Model();
	  $randlogs = $Log_Model->getLogsForHome("AND sortid = {$sortid} ORDER BY rand() DESC,date DESC", 1, 4);?>		
<?php foreach($randlogs as $value): ?>	  
	<li class="left"><a href="<?php echo $value['log_url']; ?>" rel="bookmark" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a><span class="relatetime"><?php echo gmdate('Y-n-j', $value['date']); ?></span></li>
	<?php endforeach; ?>
    </ul>	
    </div>	
<div id="comments">
   <div id="commnents" class="commentsorping">
   <div class="commentsays"><?php if($comnum){echo $comnum;?> Responses <?php }else{?>NO Response <?php }?></div>
   <div class="commentpart" style="color: rgb(34, 34, 34); ">Comment (<?php echo $comnum;?>)</div>
  
   </div>	

	<?php blog_comments($comments); ?>
	
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
</div>
<div class="clear"></div>
</div>
<?php

 include View::getView('footer');
?>