<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<footer>
		<form method="get" id="searchformf" action="<?php echo BLOG_URL; ?>index.php">
		<label for="s" class="assistive-text">Search…</label>
		<input type="text" class="field" name="keyword" id="s" placeholder="Search…">
		<input type="submit" class="submit" name="submit" id="searchsubmitf" value="Search…">
	</form>	
	<div class="footer-text-right">FOX2 By Bigfa and Lonelyfox
	Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
<?php doAction('index_footer'); ?>	
	</div>
<div class="hide">
</div>
</footer>


</body>
</html>