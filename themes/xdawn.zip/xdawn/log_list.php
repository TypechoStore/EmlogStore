<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="container">

<article>
<div id="sep"></div>
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<div class="post-single cf">
	
   <div class="selfthum">
    <?php
            //获取缩略图
            $template_name = str_replace(BLOG_URL,"",TEMPLATE_URL);
            $template_name = str_replace("content/templates/","",$template_name);
            $template_name = str_replace("/","",$template_name);
            //以上三句代码获取模板目录名称
            $thum_file = EMLOG_ROOT.'/content/templates/'.$template_name.'/thumbnail/gid/'.$value['gid'].'.jpg';
            if (is_file($thum_file)) {
                $thum_src = TEMPLATE_URL.'/thumbnail/gid/'.$value['gid'].'.jpg';
                //ID编号配图
            }else{
                $thum_src = getThumbnail($value['logid']); //附件第一张图片
                if (empty($thum_src)) {
                    $rand_num = 12; //随机图片数量，按实际数量设置
                    if ($rand_num == 0) {
                        $thum_src = TEMPLATE_URL."thumbnail/0.jpg";
                        //默认图片，须命名为"0.jpg"
                    }else{
                        $thum_src = TEMPLATE_URL."thumbnail/random/".rand(1,$rand_num).".jpg";
                        //随机图片，须按"1.jpg","2.jpg","3.jpg"...的顺序命名
                    }
                }
            }
            //ID编号配图(gid目录)、默认图片(0.jpg)、随机图片(random目录)，都保存在模板目录中的"thumbnail"目录下，以便于集中管理
            ?>
		
   <a href="<?php echo $value['log_url']; ?> " rel="nofollow"><img src="<?php echo $thum_src; ?>"></a>
   </div>
   <div class="post">
	<div class="post-title">
	<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
	</div>
	<div class="post-meta">
		<span class="time">/ <?php echo gmdate('Y-n-j', $value['date']); ?> </span>
		<span class="comt">/ 
		
		<a href="<?php echo $value['log_url']; ?>#comments" title="《<?php echo $value['log_title']; ?>》上的评论"><?php echo $value['comnum']; ?> Comments</a></span>
		<span class="view">/ <?php echo $value['views']; ?> views</span>		
	</div>
	<div class="content_post defaultpost">
	
	<?php echo msubstr ($value['log_description'],0,100); ?>					
    <div class="clear"></div>
	<a class="post-more" href="<?php echo $value['log_url']; ?>" title="continue" rel="nofollow"></a>
	</div>
	</div>			
</div>
<?php endforeach; ?>
<nav class="pagenavi cf">
	<div id="pagenavi">
	 <?php echo $page_url;?>
	</div>
</nav>
<div class="friendlink cf">
<div id="link">
<?php
//widget：链接

	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
	?>
	<ul>
	<?php foreach($link_cache as $value): ?>
	<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
	<?php endforeach; ?>
	</ul>	
<?php ?>
</div>
</div>
</article>	
<div class="clear"></div>
</div>				
<?php

 include View::getView('footer');
?>