<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<section class="postlist">
<article class="post " id="post<?php echo $logid;?>">
    <section class="title">
      <h3><?php echo gmdate('Y-n-j G:i l', $date); ?>  <!-- by <?php blog_author($author); ?> --></h3>
      
      <h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
      <small><?php blog_sort($logid); ?></a>, by <?php blog_author($author); ?>	     
	  </small>
    </section>
    <section class="entry">
      <?php echo $log_content; ?>
      <?php blog_att($logid); ?>
   <section class="clear">
	</section> 
    </section>
    <?php doAction('log_related', $logData); ?>
    <p class="postmeta"></p>
	 <nav class="post-nav">
      <?php neighbor_log($neighborLog); ?>
	  <section class="clear"></section>
    </nav>
     <section id="comments">
		<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
		<?php blog_comments($comments); ?>
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	 </section>
	  </article>
</section>
<?php
 include View::getView('side');
 include View::getView('footer');
?>