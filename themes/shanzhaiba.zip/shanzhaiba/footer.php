<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<footer>
<div class="links">
<li class="linkcat" id="linkcat-2">
<h2>合作单位</h2><br>
	<ul class="moon">
		<li><a href="http://836.sz836.com/">836互联</a></li>
		<li><a href="http://www.sz836.com/">836导航</a></li>
	</ul>
</li>
		</div>
<p>Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> |Theme by <a target="_seft" href="http://blog.sz836.com/">山寨吧</a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?><p>
</footer>
</section>
	<div id="shangxia" style="top: 539.4px;">
	<div id="shang"></div>
	<div id="comt"></div>
	<div id="xia"></div>
	
	
	<div style="padding: 0pt; border: medium none; margin: 0pt; position: absolute; left: 0pt; top: 0pt; width: 100%; z-index: 1001;"><a class="highslide-loading" title="Click to cancel" href="javascript:;" style="position: absolute; top: -9999px; opacity: 0.75; z-index: 1;">Loading...</a><div style="display: none;"></div><table cellspacing="0" style="padding: 0pt; border: medium none; margin: 0pt; visibility: hidden; position: absolute; border-collapse: collapse;"><tbody style="padding: 0pt; border: medium none; margin: 0pt;"><tr style="padding: 0pt; border: medium none; margin: 0pt; height: auto;"><td style="padding: 0pt; border: medium none; margin: 0pt; line-height: 0; font-size: 0pt; background: url(&quot;<?php echo BLOG_URL; ?>content/templates/shanzhaiba/images/rounded-white.png&quot;) repeat scroll 0px 0px transparent; height: 20px; width: 20px;"></td><td style="padding: 0pt; border: medium none; margin: 0pt; line-height: 0; font-size: 0pt; background: url(&quot;<?php echo BLOG_URL; ?>content/templates/shanzhaiba/images/rounded-white.png&quot;) repeat scroll 0px -40px transparent; height: 20px; width: 20px;"></td><td style="padding: 0pt; border: medium none; margin: 0pt; line-height: 0; font-size: 0pt; background: url(&quot;<?php echo BLOG_URL; ?>content/templates/shanzhaiba/images/rounded-white.png&quot;) repeat scroll -20px 0px transparent; height: 20px; width: 20px;"></td></tr><tr style="padding: 0pt; border: medium none; margin: 0pt; height: auto;"><td style="padding: 0pt; border: medium none; margin: 0pt; line-height: 0; font-size: 0pt; background: url(&quot;<?php echo BLOG_URL; ?>content/templates/shanzhaiba/images/rounded-white.png&quot;) repeat scroll 0px -80px transparent; height: 20px; width: 20px;"></td><td style="padding: 0pt; border: medium none; margin: 0pt; position: relative;" class="rounded-white"></td><td style="padding: 0pt; border: medium none; margin: 0pt; line-height: 0; font-size: 0pt; background: url(&quot;<?php echo BLOG_URL; ?>content/templates/shanzhaiba/images/rounded-white.png&quot;) repeat scroll -20px -80px transparent; height: 20px; width: 20px;"></td></tr><tr style="padding: 0pt; border: medium none; margin: 0pt; height: auto;"><td style="padding: 0pt; border: medium none; margin: 0pt; line-height: 0; font-size: 0pt; background: url(&quot;<?php echo BLOG_URL; ?>content/templates/shanzhaiba/images/rounded-white.png&quot;) repeat scroll 0px -20px transparent; height: 20px; width: 20px;"></td><td style="padding: 0pt; border: medium none; margin: 0pt; line-height: 0; font-size: 0pt; background: url(&quot;<?php echo BLOG_URL; ?>content/templates/shanzhaiba/images/rounded-white.png&quot;) repeat scroll 0px -60px transparent; height: 20px; width: 20px;"></td><td style="padding: 0pt; border: medium none; margin: 0pt; line-height: 0; font-size: 0pt; background: url(&quot;<?php echo BLOG_URL; ?>content/templates/shanzhaiba/images/rounded-white.png&quot;) repeat scroll -20px -20px transparent; height: 20px; width: 20px;"></td></tr></tbody></table></div>
</body>
</html>

