<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<section class="postlist">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<script src="<?php echo BLOG_URL; ?>content/templates/shanzhaiba/js/zairu.js" type="text/javascript"></script>
<article class="post" id="post<?php echo $value['logid'];?>">
  	<section class="title">
     	<h3><?php echo gmdate('Y-n-j G:i l', $value['date']); ?></h3>

     	<h2><?php topflg($value['top']); ?><a title="<?php echo $value['log_title']; ?>" rel="bookmark" href="<?php echo $value['log_url']; ?>"
			 style="left: 0px;"><?php echo $value['log_title']; ?> </a>
		</h2>
			<small><a title="<?php echo $value['log_title']; ?>上的评论" href="<?php echo $value['log_url']; ?>#comments">
				<?php echo $value['comnum']; ?>条评论</a>, 
			<a rel=<?php blog_sort($value['logid']); ?></a>, by <?php blog_author($value['author']); ?>.</small>
		</section>
 	<section class="entry">
      <p><?php echo $value['log_description']; ?> <a class="more-link" href="<?php echo $value['log_url']; ?>">More</a></p>
    </section>
    
</article>
<?php endforeach; ?>
	<div class="istudio_pagenav">
		<?php echo $page_url;?>
	</div>

</section>
<?php
 include View::getView('side');
 include View::getView('footer');
?>

