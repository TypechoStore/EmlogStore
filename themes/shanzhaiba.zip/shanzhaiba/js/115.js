/*DOCUMENT JAVASCRIPT*/

jQuery(document).ready(function($){ 
$('#content').animate({ opacity: '1.00' }, 2000);
$('h2 a,aside ul li ul li a').hover(function() {
$(this).stop().animate({'left': '7px'}, 'fast');
}, function() {
$(this).stop().animate({'left': '0px'}, 'fast');
});
});

$(function() {
$("img").lazyload({
placeholder : "<?php bloginfo('template_url');?>/resources/grey.gif",
effect : "fadeIn"
});
});
