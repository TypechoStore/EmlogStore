jQuery(document).ready(function($){
$("#prev").click(function() {
$(".laodao span:visible").toggle(100,
function() {
 if ($(this).prev().is("span")) {
	 $(this).prev().toggle()} else {
	 $(".laodao span:last").toggle() }
	})
 });
 $("#next").click(function() {
  $(".laodao span:visible").toggle(100,function() {
   if ($(this).next().is("span")) {
	$(this).next().toggle()} else {
	$(".laodao span:first").toggle()
	}
 })
});
   var b,a = function() {
	$("#next").trigger("click");
	b = setTimeout(a, 4000)};
	$(".laodao").hover(function() {
	  clearTimeout(b);
	$("#prev,#next").fadeIn("fast")},function() {
	b = setTimeout(a, 4000);
	$("#prev,#next").fadeOut("fast")});
	b = setTimeout(a, 4000);
})
/*sidebar*/
   jQuery(document).ready(function($) {
    $('.close-sidebar').click(function() {
                $('.close-sidebar').hide();
        $('.close-sidebar,aside').fadeOut(1000);//��һ���������ز����
        $('.show-sidebar').show();
                window.setTimeout(function(){//�Ȳ����������� �ӳ�1���Ӻ�ʼ�����ݲ���չ��
                 $('#content .postlist').animate({
            width: "900px"//���ݲ��ִ�С �����������
        },
        1000);
                },1000);

            });
    $('.show-sidebar').click(function() {
        $('.show-sidebar').hide();
                $('.close-sidebar').show();
        $('#content .postlist').animate({
            width: "640px"//���ݲ���ԭ��С
        },
        1000);
                window.setTimeout(function(){//�ȴ����ݲ�����ȫ�������Բ����
                 $('aside').fadeIn(1000);
                },1000);
     });

});
jQuery(document).ready(function($){
var s= $('#shangxia').offset().top;$(window).scroll(function (){$("#shangxia").animate({top : $(window).scrollTop() + s + "px" },{queue:false,duration:500});});
$body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body');
$('#shang').click(function(){$body.animate({scrollTop: '1px'}, 400);});
$('#xia').click(function(){$body.animate({scrollTop:$('footer').offset().top}, 800);});
});
