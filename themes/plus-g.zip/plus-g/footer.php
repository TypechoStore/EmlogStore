 <div class="footer-img">
    </div>
    <div class="footer">
    	<div class="footer-wrap">
    		<div class="footer-content" id="margin-left">
        		<div class="footer-content-title">最新日志
        	    </div>
            	<div class="footer-content-content">
                	<?php echo footer_newlog(); ?>
            	</div>
        	</div>
            <div class="footer-content">
        		<div class="footer-content-title">热门日志
        	    </div>
            	<div class="footer-content-content">
                	<?php echo footer_hotlog(); ?>
            	</div>
        	</div>
            <div class="footer-content">
        		<div class="footer-content-title">随机日志
        	    </div>
            	<div class="footer-content-content">
                	<?php echo footer_random_log(); ?>
            	</div>
        	</div>
            <div class="footer-content">
        		<div class="footer-content-title">日志标签
        	    </div>
            	<div class="footer-content-content">
                	<?php echo footer_tag(); ?>
            	</div>
        	</div>
            <div class="footer-footer">
            Written by <a href="http://www.sinkery.com">梦寐鱼求</a> Powered by <a href="http://www.emlog.net">emlog</a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?> <script src="http://s22.cnzz.com/stat.php?id=4131236&web_id=4131236" language="JavaScript"></script> <a href="#top">回到顶部</a>
<?php doAction('index_footer'); ?>
            </div>
        </div>
    </div>
    <!--footer部分结束-->
</div>
</body>
</html>
