<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="main">
    <!--主框架左侧开始-->
    	<div class="main-left">
        	<div class="main-left-content">
            	<div class="main-left-content-title"><?php topflg($top); ?><a href="<?php echo $log_url; ?>"><?php echo $log_title; ?></a></div>
                <div class="main-left-content-info">作者：<?php blog_author($author); ?> | 发布日期：<?php echo gmdate('Y年n月j日 G:i', $date); ?> <?php blog_sort($logid); ?> <?php blog_tag($logid); ?></div>
                <div class="main-left-content-content">
                <?php echo $log_content; ?>
                </div>
                <div class="plugin"><?php doAction('log_related', $logData); ?></div>
                <div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
                <?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
            </div>
        </div>
        <!--主框架左侧结束，右侧开始-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>