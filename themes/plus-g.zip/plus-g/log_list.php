<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="main">
    <!--主框架左侧开始-->
    	<div class="main-left">
        <?php doAction('index_loglist_top'); ?>
        <?php foreach($logs as $value): ?>
        	<div class="main-left-content">
            	<div class="main-left-content-title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></div>
                <div class="main-left-content-info">作者：<?php blog_author($value['author']); ?> | 发布日期：<?php echo gmdate('Y年n月j日 G:i', $value['date']); ?> <?php blog_sort($value['logid']); ?> <?php blog_tag($value['logid']); ?></div>
                <div class="main-left-content-content">
                <?php echo $value['log_description']; ?>
                </div>
            </div>
            <?php endforeach; ?>
            <div class="pagenavi">
            	<?php echo $page_url;?>
            </div>
        </div>
        <!--主框架左侧结束，右侧开始-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>