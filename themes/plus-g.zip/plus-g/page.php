<?php 
/*
* 自建页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="main">
    <!--主框架左侧开始-->
    	<div class="main-left">
        	<div class="main-left-content">
            	<div class="main-left-content-title"><?php topflg($top); ?><a href="<?php echo $log_url; ?>"><?php echo $log_title; ?></a></div>
                <div class="main-left-content-content">
                <?php echo $log_content; ?>
                </div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
            </div>
        </div>
        <!--主框架左侧结束，右侧开始-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>