<?php if(!defined('EMLOG_ROOT')) {exit('error!');} include View::getView('sheli/index');?>
<div class="main">
<div class="left"><div class="syleft">
<?php doAction('index_loglist_top'); ?>
<?php if (!empty($logs)):foreach($logs as $value): ?>
<div class="list-log">
<p class="title"><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></p>
<p class="date">时间：<?php echo gmdate('Y-n-j', $value['date']); ?> | 作者：<?php blog_author($value['author']); ?> | 分类：<?php blog_sort($value['logid']); ?> | <a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a> | <a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a> | <?php blog_tag($value['logid']); ?></p>
<?php if (_g('index-img') == "yes"): ?><p class="image bk"><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" ><img  src="<?php get_thum($value['logid']);?>" alt="<?php echo $value['log_title']; ?>"/></a></p><?php else: ?><?php endif; ?>
<p class="list-wznr"><?php echo subString(strip_tags($value['content']),0,120);?></p>
</div>
<?php endforeach; else:?>
<?php endif;?>
<div class="pages"><?php echo $page_url;?></div>
</div><?php //!-- left end -- ?></div><?php //!-- syleft end -- ?>
<div class="right"><?php include View::getView('side');?></div>
</div><?php //!-- main end -- ?>