<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<?php if($pageurl == Url::logPage()){ ?><?php include View::getView('index'); ?><?php }else{ ?>
<?php doAction('index_loglist_top'); ?>
<?php include View::getView('sheli/list');?>
<div class="main">
<div class="left"><div class="syleft">
<div class="mbx">
<p>现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; 
<?php if ($params[1]=='sort'){ ?><?php echo '<a href="'.Url::sort($sortid).'">'.$sortName.'</a>';?>
<?php }elseif ($params[1]=='tag'){ ?>包含标签 <b><?php echo urldecode($params[2]);?></b> 的所有文章
<?php }elseif($params[1]=='author'){ ?>作者 <b><?php echo blog_author($author);?></b> 的所有文章
<?php }elseif($params[1]=='keyword'){ ?>关键词 <b><?php echo urldecode($params[2]);?></b> 的搜索结果
<?php }elseif($params[1]=='record'){ ?>发表在 <b><?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?> </b>的所有文章
<?php }else{?><?php }?></p></div>
<?php if (!empty($logs)):foreach($logs as $value): ?>
<div class="list-log">
<p class="title"><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></p>
<p class="date">时间：<?php echo gmdate('Y-n-j', $value['date']); ?> | 作者：<?php blog_author($value['author']); ?> | 分类：<?php blog_sort($value['logid']); ?> | <a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a> | <a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a> | <?php blog_tag($value['logid']); ?></p>
<?php if (_g('list-img') == "yes"): ?><p class="image bk"><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" ><img  src="<?php get_thum($value['logid']);?>" alt="<?php echo $value['log_title']; ?>"/></a></p><?php else: ?><?php endif; ?>
<p class="list-wznr"><?php echo subString(strip_tags($value['content']),0,120);?></p>
</div>
<?php endforeach; else:?>
<p class="title">未找到</p>
<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
<div class="pages"><?php echo $page_url;?></div>
<div class="log-gg"><?php echo _g('list-gg'); ?></div>
</div><?php //!-- left end -- ?></div><?php //!-- syleft end -- ?>
<div class="right"><?php include View::getView('side');?></div>
</div><?php //!-- main end -- ?>
<?php } ?>
<?php include View::getView('footer');?>