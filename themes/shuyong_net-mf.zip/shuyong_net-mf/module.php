<?php if(!defined('EMLOG_ROOT')) {exit('error!');} if (!function_exists('_g')) {emMsg('<div style="color:#ff0000;line-height:40px;text-align:center;font-size:16px;">欢迎你使用由舍力制作的【仿某知名博客响应式 免费版】主题；</div><div style="line-height:25px;font-size:14px;color:#999;">你现在无法正常使用本模板的原因：<br />1、你可能还未安装，请先安装<a href="http://www.emlog.net/plugin/144" target="_blank">模板设置插件</a><br />2、你还未启用模板设置插件，请到后面插件管理中启用模板插件；<br />主题由舍力负责维护，如有疑问请阅读【<a href="http://www.shuyong.net/325.html" target="_blank">模板使用说明</a>】</div>', BLOG_URL . 'admin/plugins.php');}?>
<?php
//widget：博主介绍
function widget_blogger($title){global $CACHE;$user_cache = $CACHE->readCache('user');$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
<li><h3><span><?php echo $title; ?></span></h3>
<div class="bloggerimg"><?php if (!empty($user_cache[1]['photo']['src'])): ?><img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="50" height="50" alt="博客相片" /><?php endif;?></div>
<p class="bloggerjs">博主：<b><?php echo $name; ?></b><br />
简介：<?php echo $user_cache[1]['des']; ?></p>
</li>
<?php }?>
<?php
//widget：日历
function widget_calendar($title){ ?>
<li><h3><span><?php echo $title; ?></span></h3>
<div id="calendar"></div>
<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
</li>
<?php }?>
<?php
//widget：标签
function widget_tag($title){global $CACHE;$tag_cache = $CACHE->readCache('tags');?>
<li><h3><span><?php echo $title; ?></span></h3><ul id="blogtags">
<?php foreach($tag_cache as $value): ?>
<li><a href="<?php echo Url::tag($value['tagurl']); ?>" title="标签为[<?php echo $value['tagname']; ?>]的文章共有<?php echo $value['usenum']; ?>篇文章"><?php echo $value['tagname']; ?></a></li><?php endforeach; ?></ul></li>
<?php }?>
<?php
//widget：分类
function widget_sort($title){global $CACHE;$sort_cache = $CACHE->readCache('sort'); ?>
<li><h3><span><?php echo $title; ?></span></h3>
<ul id="blogsort">
<?php foreach($sort_cache as $value):if ($value['pid'] != 0) continue;?>
<li><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
<?php if (!empty($value['children'])): ?>
<ul><?php $children = $value['children'];foreach ($children as $key):$value = $sort_cache[$key];?>
<li><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a></li>
<?php endforeach; ?></ul></li>
<?php endif; ?>
<?php endforeach; ?>
</ul></li>
<?php }?>
<?php
//widget：最新文章
function widget_newlog($title){global $CACHE; $newLogs_cache = $CACHE->readCache('newlog');?>
<li><h3><span><?php echo $title; ?></span></h3><ul id="newlog"><?php foreach($newLogs_cache as $value): ?><li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li><?php endforeach; ?></ul></li>
<?php }?>
<?php
//widget：热门文章
function widget_hotlog($title){$index_hotlognum = Option::get('index_hotlognum');$Log_Model = new Log_Model();$randLogs = $Log_Model->getHotLog($index_hotlognum);?>
<li><h3><span><?php echo $title; ?></span></h3><ul id="hotlog"><?php foreach($randLogs as $value): ?><li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li><?php endforeach; ?></ul></li>
<?php }?>
<?php
//widget：随机文章
function widget_random_log($title){$index_randlognum = Option::get('index_randlognum');$Log_Model = new Log_Model();$randLogs = $Log_Model->getRandLog($index_randlognum);?>
<li><h3><span><?php echo $title; ?></span></h3><ul id="randlog"><?php foreach($randLogs as $value): ?><li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li><?php endforeach; ?></ul></li>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){global $CACHE; $com_cache = $CACHE->readCache('comment');?>
<li><h3><span><?php echo $title; ?></span></h3>
<ul class="newcomment">
<?php foreach($com_cache as $value):$url = Url::comment($value['gid'], $value['page'], $value['cid']);?>
<li><?php echo $value['name']; ?>:<a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a></li>
<?php endforeach; ?>
</ul>
</li>
<?php }?>
<?php
//widget：最新微语
function widget_twitter($title){global $CACHE; $newtws_cache = $CACHE->readCache('newtw');$istwitter = Option::get('istwitter');?>
<li><h3><span><?php echo $title; ?></span></h3>
<ul class="twitter">
<?php foreach($newtws_cache as $value): ?>
<li><?php echo $value['t']; ?><?php echo $img;?><p><?php echo smartDate($value['date']); ?></p></li>
<?php endforeach; ?><?php if ($istwitter == 'y') :?>
<?php endif;?>
</ul>
</li>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
<li><h3><span><?php echo $title; ?></span></h3>
<ul class="sousuo">
<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
<input type="image" id="logserch_logserch" class="l-wsubmit" src="<?php echo TEMPLATE_URL; ?>/images/go.gif" title="搜索" />
<input name="keyword" class="l-search" type="text" />
</form>
</ul></li>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){global $CACHE; $record_cache = $CACHE->readCache('record');?>
<li><h3><span><?php echo $title; ?></span></h3><ul id="record"><?php foreach($record_cache as $value): ?><li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li><?php endforeach; ?></ul></li>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
<li><h3><span><?php echo $title; ?></span></h3>
<ul><?php echo $content; ?></ul>
</li>
<?php } ?>
<?php
//widget：链接
function widget_link($title){global $CACHE;$link_cache = $CACHE->readCache('link');if (!blog_tool_ishome()) return;?>
<li><h3><span><?php echo $title; ?></span></h3>
<ul id="link"><?php foreach($link_cache as $value): ?><li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li><?php endforeach; ?></ul></li>
<?php }?>
<?php function sl(){ ?>Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> &Designed By <a href="http://www.shuyong.net" title="舍力" target="_blank">舍力</a>.</div><?php } ?>
<?php
//blog：导航
function blog_navi(){global $CACHE; $navi_cache = $CACHE->readCache('navi');?>
<?php foreach($navi_cache as $value):if ($value['pid'] != 0) {continue;}if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):?>
<?php continue;endif;$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';$value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
$current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'current' : 'common';?>
<div id="nav_xl"><div class="nav_xl1"><h3 class="item <?php echo $current_tab;?>"><a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a><?php if (!empty($value['children'])) :?><ul class="sub-nav"><?php foreach ($value['children'] as $row){echo '<li><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></li>';}?></ul><?php endif;?><?php if (!empty($value['childnavi'])) :?><ul class="zjpp"><?php foreach ($value['childnavi'] as $row){$newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';echo '<li><a href="' . $row['url'] . "\" $newtab >" . $row['naviname'].'</a></li>';}?></ul><?php endif;?></h3></div></div><?php endforeach; ?>
<?php }?>
<?php
//blog：置顶
function topflg($top, $sortop='n', $sortid=null){if(blog_tool_ishome()) {echo $top == 'y' ? "<font color=\"#FF0000\">[推荐]</font> " : '';} elseif($sortid){echo $sortop == 'y' ? "<font color=\"#FF0000\">[推荐]</font> " : '';}}?>
<?php
//blog：编辑
function editflg($logid,$author){$editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';echo $editflg;}
?>
<?php
//blog：分类
function blog_sort($blogid){global $CACHE; $log_cache_sort = $CACHE->readCache('logsort');?>
<?php if(!empty($log_cache_sort[$blogid])): ?><a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a><?php endif;?>
<?php }?>
<?php
//blog：文章标签
function blog_tag($blogid){global $CACHE;$log_cache_tags = $CACHE->readCache('logtags');if (!empty($log_cache_tags[$blogid])){$tag = '标签:';foreach ($log_cache_tags[$blogid] as $value){$tag .= "	<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';}echo $tag;}}?>
<?php
//blog：文章标签关键词
function blog_tag1($blogid){global $CACHE;$log_cache_tags = $CACHE->readCache('logtags');if (!empty($log_cache_tags[$blogid])){$tag = '';foreach ($log_cache_tags[$blogid] as $value){$tag .= "".$value['tagname'].',';}echo $tag;}}?>
<?php
//blog：文章作者
function blog_author($uid){global $CACHE;$user_cache = $CACHE->readCache('user');$author = $user_cache[$uid]['name'];$mail = $user_cache[$uid]['mail'];$des = $user_cache[$uid]['des'];$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';echo $author;}?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){extract($neighborLog);?>
<?php if($prevLog):?>
&laquo; <a href="<?php echo Url::log($prevLog['gid']) ?>"><?php echo $prevLog['title'];?></a>
<?php endif;?>
<?php if($nextLog && $prevLog):?>
 | 
<?php endif;?>
<?php if($nextLog):?>
<a href="<?php echo Url::log($nextLog['gid']) ?>"><?php echo $nextLog['title'];?></a> &raquo;
<?php endif;?>
<?php }?>
<?php
//blog：引用通告
function blog_trackback($tb, $tb_url, $allow_tb){if($allow_tb == 'y' && Option::get('istrackback') == 'y'):?>
<div id="trackback_address"><p>引用地址: <input type="text" style="width:350px" class="input" value="<?php echo $tb_url; ?>"><a name="tb"></a></p></div>
<?php endif; ?><?php foreach($tb as $key=>$value):?>
<ul id="trackback">
<li><a href="<?php echo $value['url'];?>" target="_blank"><?php echo $value['title'];?></a></li>
<li>BLOG: <?php echo $value['blog_name'];?></li><li><?php echo $value['date'];?></li>
</ul>
<?php endforeach; ?>
<?php }?>
<?php
//blog：评论列表 链接已经加入nofollow标签
function blog_comments($comments){extract($comments);if($commentStacks): ?>
<?php endif; ?>
<?php $isGravatar = Option::get('isgravatar');foreach($commentStacks as $cid):$comment = $comments[$cid];$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank" rel="nofollow">'.$comment['poster'].'</a>' : $comment['poster'];?>
<div class="comment" id="comment-<?php echo $comment['cid']; ?>"><a name="<?php echo $comment['cid']; ?>"></a>
<?php if($isGravatar == 'y'): ?><div class="avatar bk"><img src="<?php echo getGravatar($comment['mail']); ?>" /></div><?php endif; ?>
<div class="comment-info"><b><?php echo $comment['poster']; ?> </b>[<a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)" style="color:#FF0000;">回复该留言</a>]<br /><span class="comment-time"><?php echo $comment['date']; ?></span>
<div class="comment-content"><?php echo $comment['content']; ?></div>
</div>
<?php blog_comments_children($comments, $comment['children']); ?>
</div>
<?php endforeach; ?>
<div class="pages"><?php echo $commentPageUrl;?></div>
<?php }?>
<?php
//blog：子评论列表 链接已经加入nofollow标签
function blog_comments_children($comments, $children){$isGravatar = Option::get('isgravatar');foreach($children as $child):$comment = $comments[$child];$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank" rel="nofollow">'.$comment['poster'].'</a>' : $comment['poster'];?>
<div class="comment comment-children" id="comment-<?php echo $comment['cid']; ?>"><a name="<?php echo $comment['cid']; ?>"></a>
<div class="zipl"><b><?php echo $comment['poster']; ?></b> 回复于 <?php echo $comment['date']; ?>  [<a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)" style="color:#FF0000;">回复该留言</a>]
<div class="comment-content"><?php echo $comment['content']; ?></div>
</div>
<?php blog_comments_children($comments, $comment['children']);?>
</div>
<?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
if($allow_remark == 'y'): ?>
<div id="comment-place">
<div class="comment-post" id="comment-post">
<div class="cancel-reply" id="cancel-reply" style="display:none"><a href="javascript:void(0);" onclick="cancelReply()">取消回复</a></div>
<p class="comment-header"><b>发表评论：</b><a name="respond"></a></p>
<form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
<?php if(ROLE == ROLE_VISITOR): ?>
<p><input type="text" name="comname" maxlength="49" value="<?php echo $ckname; ?>" size="22" tabindex="1"><label for="author"><small>昵称</small></label></p>
<p><input type="text" name="commail"  maxlength="128"  value="<?php echo $ckmail; ?>" size="22" tabindex="2"><label for="email"><small>邮件地址 (选填)</small></label></p>
<p><input type="text" name="comurl" maxlength="128"  value="<?php echo $ckurl; ?>" size="22" tabindex="3"><label for="url"><small>个人主页 (选填)</small></label></p>
<?php endif; ?>
<p><textarea name="comment" id="comment" rows="10" tabindex="4"></textarea></p>
<p><?php echo $verifyCode; ?> <input type="submit" id="comment_submit" value="发表评论" tabindex="6" /></p>
<input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/>
</form></div></div><?php endif; ?>
<?php }?>
<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){return true;} else { return FALSE;}}?>
<?php
//分页标题后面加 - 第几页
function page_tit($page){if ($page>=2){ echo ' - 第'.$page.'页'; }}?>
<?php
//文章详情页下相关文章
function related_logs($logData = array()){$configfile = EMLOG_ROOT.'/content/plugins/related_log/related_log_config.php';
if (is_file($configfile)) {require $configfile;}else{
$related_log_type = 'sort';//相关日志类型，sort为分类，tag为标签；
$related_log_sort = 'views_desc';//排列方式，views_desc 为点击数（降序）comnum_desc 为评论数（降序） rand 为随机 views_asc 为点击数（升序）comnum_asc 为评论数（升序）
$related_log_num = '10'; //显示文章数，排版需要，只能为10
$related_inrss = 'y'; //是否显示在rss订阅中，y为是，其它值为否
}global $value;$DB = MySql::getInstance();$CACHE = Cache::getInstance();extract($logData);if($value)
{$logid = $value['id'];$sortid = $value['sortid'];global $abstract;}
$sql = "SELECT gid,title FROM ".DB_PREFIX."blog WHERE hide='n' AND type='blog'";
if($related_log_type == 'tag'){$log_cache_tags = $CACHE->readCache('logtags');$Tag_Model = new Tag_Model();$related_log_id_str = '0';foreach($log_cache_tags[$logid] as $key => $val){$related_log_id_str .= ','.$Tag_Model->getTagByName($val['tagname']);}
$sql .= " AND gid!=$logid AND gid IN ($related_log_id_str)";}else{
$sql .= " AND gid!=$logid AND sortid=$sortid";}
switch ($related_log_sort){case 'views_desc':{
$sql .= " ORDER BY views DESC";break;}case 'views_asc':{
$sql .= " ORDER BY views ASC";break;}case 'comnum_desc':{
$sql .= " ORDER BY comnum DESC";break;}case 'comnum_asc':{
$sql .= " ORDER BY comnum ASC";break;}case 'rand':{
$sql .= " ORDER BY rand()";break;}}
$sql .= " LIMIT 0,$related_log_num";
$related_logs = array();$query = $DB->query($sql);while($row = $DB->fetch_array($query))
{$row['gid'] = intval($row['gid']);$row['title'] = htmlspecialchars($row['title']);$related_logs[] = $row;}
$out = '';if(!empty($related_logs)){foreach($related_logs as $val){
$out .= "<li><a href=\"".Url::log($val['gid'])."\">{$val['title']}</a></li>";
}}if(!empty($value['content'])){if($related_inrss == 'y'){$abstract .= $out;}}else{echo $out;}}
?>
<?php
//获取文章缩略图，先是自定义指定，然后是查找附件图片，最后是随机图片
function get_thum($logid){
 $db = MySql::getInstance();
$thum_pic = EMLOG_ROOT.'/thumpic/'.$logid.'.jpg';
if (is_file($thum_pic)) {
$thum_url = BLOG_URL.'thumpic/'.$logid.'.jpg'; 
}else{
$sqlimg = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$logid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";
//    die($sql);
$img = $db->query($sqlimg);
while($roww = $db->fetch_array($img)){
$thum_url=BLOG_URL.substr($roww['filepath'],3,strlen($roww['filepath']));
}if (empty($thum_url)) {
srand((double)microtime()*1000000); 
$randval   =   rand(0,9); 
$thum_url = BLOG_URL.'content/templates/shuyong_net-mf/images/shuyong_net/'.$randval.'.jpg';}
}echo $thum_url;}
?>
<?php
//blog-tool:格式化内容工具，去除html标签
function blog_tool_purecontent($content, $strlen = null){$content = strip_tags($content);if ($strlen) {$content = subString($content, 0, $strlen);}return $content;}
?>
<?php //幻灯片
function home_slideshow(){ $db = MySql::getInstance(); $sql = $db->query ("SELECT * FROM ".DB_PREFIX."blog inner join ".DB_PREFIX."sort WHERE hide='n' AND type='blog' AND sortop='y' AND sortid=sid order by date DESC limit 0,3"); while($row = $db->fetch_array($sql)){ if (!empty($row['excerpt'])){ preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['excerpt'], $match); if(empty($match[0][0])) { preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'], $match); } }else{ preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'], $match); } $logpost = !empty($row['excerpt']) ? $row['excerpt'] : ''.$row['content'].''; $num = rand(1,3); $img = isset($match[0][0]) ? $match[0][0] : '<img src="'.TEMPLATE_URL.'images/shuyong_net/'.$num.'.jpg">'; $date = gmdate('Y年m月d日', $row['date']); $content = strip_tags($logpost,''); $content = mb_substr($content,0,250,'utf-8');$comment = ($row['comnum'] != 0) ? '评论：<small>'.$row['comnum'].'</small>' : '暂无评论'; $gid = $row['gid']; $tag = $db -> query("SELECT * FROM ".DB_PREFIX."tag WHERE gid LIKE '%,$gid,%'"); $out .='
<div class="flash_img2">
<div class="hdp_img"><a href="'.Url::log($row['gid']).'" title="'.$row['title'].'"   >'.$img.'</a></div>
<div class="hdp"><h4><a href="'.Url::log($row['gid']).'" title="'.$row['title'].'">'.$row['title'].'</a></h4>
<h5>日期：'.$date.'   &nbsp;  分类：<a href="'.Url::sort($row['sortid']).'" title="查看 '.$row['sortname'].' 中的全部文章" rel="category tag">'.$row['sortname'].'</a>   &nbsp; 浏览：'.$row['views'].' 次  &nbsp; '.$comment.'</h5> 
<h6>'.$content.'...</h6></div></div>
'; } echo $out; }?>
<?php //最新日志
function home_newlog(){ require('css-js/sheli.php'); $db = MySql::getInstance(); $sql = $db->query ("SELECT * FROM ".DB_PREFIX."blog inner join ".DB_PREFIX."sort WHERE hide='n' AND type='blog' AND top='n' AND sortid=sid order by date DESC limit 0,$zxrz_sl"); while($row = $db->fetch_array($sql)){ $logpost = !empty($row['excerpt']) ? $row['excerpt'] : ''.$row['content'].''; if (!empty($row['excerpt'])){ preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['excerpt'], $match); if(empty($match[0][0])) { preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'], $match); } }else{ preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'], $match); } $num = rand(1,5); $img = isset($match[0][0]) ? $match[0][0] : '<img src="'.TEMPLATE_URL.'images/shuyong_net/'.$num.'.jpg">'; $date = gmdate('Y年m月d日', $row['date']); $content = strip_tags($logpost,''); $content = mb_substr($content,0,160,'utf-8'); $comment = ($row['comnum'] != 0) ? '评论：<small>'.$row['comnum'].'</small>' : '暂无评论'; $gid = $row['gid']; $tag = $db -> query("SELECT * FROM ".DB_PREFIX."tag WHERE gid LIKE '%,$gid,%'"); $out .='
<div class="index_newlog bk">
<div class="index_newlog_img"><a href="'.Url::log($row['gid']).'" title="'.$row['title'].'"  >'.$img.'</a></div>
<div class="index_newlog_tt"><a href="'.Url::log($row['gid']).'" title="'.$row['title'].'"  >'.$row['title'].'</a></div>       		
<div class="index_newlog_riqi">日期：'.$date.' &nbsp; 分类：<a href="'.Url::sort($row['sortid']).'" title="查看 '.$row['sortname'].' 中的全部文章" rel="category tag">'.$row['sortname'].'</a> &nbsp; 点击： '.$row['views'].' 次 &nbsp; '.$comment.' </div> 
<div class="index_newlog_nr">'.$content.'...</div>
</div>'; } echo $out; }?>
<?php //首页分类文章
function sortlogs(){ $db = MySql::getInstance(); global $CACHE; $sort_cache = $CACHE->readCache('sort'); foreach(_g('sort_id') as $key => $i){ $key = $key+1; $out .= '<div class="index_wz bk">'; $out .= '<div class="index_title"><span><a rel="nofollow" href="'.Url::sort($i).'" title="查看 '.$sort_cache[$i]['sortname'].' 中的全部文章">更多...</a></span><p>'.$sort_cache[$i]['sortname'].'</p></div>'; $out .='<div class="index_sheli">'; $sql = $db->query ("SELECT * FROM ".DB_PREFIX."blog WHERE sortid='$i' AND type='blog' AND hide='n' order by date DESC limit 0,1"); $row = $db->fetch_array($sql); if (!empty($row['excerpt'])){ preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['excerpt'], $match); if(empty($match[0][0])) { preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'], $match); } }else{ preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'], $match); } $logpost = !empty($row['excerpt']) ? $row['excerpt'] : ''.$row['content'].''; $num = rand(1,5); $img = isset($match[0][0]) ? $match[0][0] : '<img src="'.TEMPLATE_URL.'images/shuyong_net/'.$num.'.jpg">'; $content = strip_tags($logpost,''); $content = mb_substr($content,0,80,'utf-8'); $out .='
<div class="index_sheli_title"><a href="'.Url::log($row['gid']).'" rel="bookmark" title="'.$row['title'].'" >'.$row['title'].'</a></div>
<div class="index_sheli_img"><a href="'.Url::log($row['gid']).'" title="'.$row['title'].'"  >'.$img.'</a></div>
<div class="index_sheli_des">'.$content.'...</div>
</div>'; $out .=''; require('css-js/sheli.php'); $flrz_sl = $flrz_sl -1; $logs = $db->query ("SELECT * FROM ".DB_PREFIX."blog WHERE sortid='$i' AND type='blog' AND hide='n' order by date DESC limit 1,{$flrz_sl}"); while ($trow = $db->fetch_array($logs)){ $date = gmdate('m-d', $trow['date']); $trow['title'] = mb_substr($trow['title'],0,40,'utf-8'); $out .='<li><span>'.$date.'</span><p><a href="'.Url::log($trow['gid']).'" title="'.$trow['title'].'">'.$trow['title'].'</a></p></li>'; } $out .='</div>'; } echo $out; }?>