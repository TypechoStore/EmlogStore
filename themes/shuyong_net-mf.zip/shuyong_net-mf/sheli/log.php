<title><?php echo $site_title; ?><?php page_tit($page);?></title>
<meta name="keywords" content="<?php blog_tag1($logid); ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<?php include View::getView('sheli/nav');?>