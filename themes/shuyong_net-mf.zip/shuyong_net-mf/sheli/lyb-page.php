<?php if(!defined('EMLOG_ROOT')) {exit('error!');} include View::getView('sheli/index');?>
<div class="main">
<div class="left"><div class="syleft">
<div class="mbx"><p>现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; <?php echo $log_title; ?></p></div>
<p class="page_title"><?php echo $log_title; ?></p>
<div class="log-wznr"><?php echo $log_content; ?></div>
<div class="pl_num">目前有 <?php echo $comnum;?> 条评论</div>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div><!-- left end --></div><!-- syleft end -->
<div class="right"><?php include View::getView('side');?></div>
</div><!-- main end -->
<?php include View::getView('footer');?>