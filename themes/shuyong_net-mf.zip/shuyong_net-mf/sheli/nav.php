<link href="<?php echo TEMPLATE_URL; ?>css-js/sheli.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>css-js/flash.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>css-js/nav_xl1.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>css-js/sheli.js" type="text/javascript"></script>
<!--[if IE 6]><script src="<?php echo TEMPLATE_URL; ?>iefix.js" type="text/javascript"></script><![endif]-->
<?php doAction('index_head'); ?>
</head>
<body>
<div class="header">
<div class="head">
<div class="logo"><img src="<?php echo _g('logo'); ?>" alt="<?php echo $blogname; ?>"></div>
<div class="top-gg bk"><?php echo _g('top-gg'); ?></div>
</div><!-- head end -->

<?php if (_g('search') == "yes"): ?>
<div class="daohang bk1"><div class="nav"><?php blog_navi();?></div><div class="search">
<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php" class="wform">
<input name="keyword" type="text" class="winput" value="请输入关键词" onMouseOver="this.focus()" onBlur="if (this.value =='') this.value='请输入关键词'" onFocus="this.select()" onClick="if (this.value=='请输入关键词') this.value=''" />
<input type="image" id="logserch_logserch" class="wsubmit" src="<?php echo TEMPLATE_URL; ?>/images/go.gif" title="搜索" />
</form></div></div><?php else: ?><?php endif; ?>
<?php if (_g('search') == "no"): ?><div class="daohang bk1"><?php blog_navi();?></div><?php else: ?><?php endif; ?>
</div><!-- header end -->