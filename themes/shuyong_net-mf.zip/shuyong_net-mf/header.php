<?php
/*
Template Name:仿某知名博客响应式 免费版
Description:简洁优雅，需下载模版设置插件方可正常使用，打造个性化博客<br><br /><font color=red>＊</font>主题由舍力负责维护。<br><font color=red>＊</font>如有任何问题，请点击下面的使用说明。<br><br><a href="http://www.shuyong.net/" target="_blank">作者站点</a> &nbsp;  <a href="http://www.shuyong.net/325.html" target="_blank">使用说明</a>
Version:制作于2014-7-10
Author:舍力
Author Url:http://www.shuyong.net
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
