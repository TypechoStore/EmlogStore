<?php
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
	    'opentime' => array(
		'type' => 'text',
		'name' => '博客开始建站时间',
		'default' => '2014-07-11',
		'description' => '显示在博客底部右侧',
	),

	    'logo' => array(
        'type' => 'image',
        'name' => '头部LOGO',
        'values' => array(
            TEMPLATE_URL . 'images/logo.png',
        ),
		'description' => '设置站点头部LOGO,250X60最佳。',
    ),
	
		'search' => array(
	    'type' => 'radio',
		'name' => '导航栏右侧搜索框',
		'values' => array(
			'yes' => '显示',
			'no' => '影藏',
		),
		'default' => 'yes',
	),
		'index-img' => array(
	    'type' => 'radio',
		'name' => '首页文章图片',
		'values' => array(
			'yes' => '显示',
			'no' => '影藏',
		),
		'default' => 'no',
	),
		'list-img' => array(
	    'type' => 'radio',
		'name' => '列表页文章图片',
		'values' => array(
			'yes' => '显示',
			'no' => '影藏',
		),
		'default' => 'yes',
	),

	 'sortKeywords' => array(
		'type' => 'text',
		'name' => '分类关键词设置',
		'description' => '多个关键词之间用半角逗号隔开',
		'depend' => 'sort',
		'default' => '',
	),

        'about' => array(
		'type' => 'text',
		'name' => '网站底部关于我',
		'description' => '显示在网站最底部关于我，网址必须加http://或直接写文件名',
		'default' => 'about.html',
	),
	    'lx' => array(
		'type' => 'text',
		'name' => '网站底部联系我',
		'description' => '显示在网站最底部联系我，网址必须加http://或直接写文件名',
		'default' => 'contact.html',
	),
        'xml' => array(
		'type' => 'text',
		'name' => '网站底部地图地址',
		'description' => '显示在网站最底部网站地图，网址必须加http://或直接写文件名',
		'default' => 'sitemap.xml',
	),
	
		'top-gg' => array(
		'type' => 'text',
		'name' => 'logo右侧广告',
		'description' => '建议为横幅广告，最佳尺寸：730*90px；超过可能影响页面布局',
		'multi' => true,
		'default' => '<script language="javascript" src="http://ads.west263.com/vcp/getJScode/getJScode.asp?ReferenceID=812373&No=728x90"></script>',
	),

		'left-gg' => array(
		'type' => 'text',
		'name' => '页面右侧广告位',
		'description' => '建议是矩形广告,尺寸宽度不能超过260px',
		'multi' => true,
		'default' => '<script language="javascript" src="http://ads.west263.com/vcp/getJScode/getJScode.asp?ReferenceID=812373&No=250x250"></script>',
	),
	
		'log-gg' => array(
		'type' => 'text',
		'name' => '文章详情页底部广告',
		'description' => '建议为横幅广告告,尺寸宽度不能超过700px；超过可能影响页面布局',
		'multi' => true,
		'default' => '<script language="javascript" src="http://ads.west263.com/vcp/getJScode/getJScode.asp?ReferenceID=812373&No=640x60"></script>',
	),
	
		'list-gg' => array(
		'type' => 'text',
		'name' => '文章列表页底部广告',
		'description' => '建议为横幅广告告,尺寸宽度不能超过700px；超过可能影响页面布局',
		'multi' => true,
		'default' => '<<script language="javascript" src="http://ads.west263.com/vcp/getJScode/getJScode.asp?ReferenceID=812373&No=640x60"></script>',
	),
	
	);