<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>哎哟～ 出现404错误页面了～您访问的页面不在地球上</title>
<style type="text/css">
body{margin:0;padding:0;font:14px/1.6 Arial,Sans-serif;}
a:link,a:visited{color:#EA1921;text-decoration:none;}
h1{position:relative;z-index:2;width:1000px;padding:0px;overflow:hidden;xxxxborder:1px solid;margin-top: 140px;margin-right: auto;margin-bottom: 15px;margin-left: auto;text-align: center;}
li{list-style:none;}
h2{position:absolute;top:0;left:0;margin:0;font-size:0;text-indent:-999px;-moz-user-select:none;-webkit-user-select:none;user-select:none;cursor:default;}
h2 em{display:block;text-indent:0;letter-spacing:-5px;color:#FFDFDF;font-family: "Times New Roman", Times, Serif;font-size: 200px;font-style: italic;line-height: 120px;font-weight: bold;}
.link a{margin-right:1em;}
.link,.texts{width:600px;margin:0 auto 15px;color:#505050;}
.texts{line-height:2;}
.texts dd{margin:0;padding:0 0 0 15px;}
.texts ul{margin:0;padding:0;}
.portal{color:#505050;text-align:center;white-space:nowrap;word-spacing:0.45em;}
.portal a:link,.portal a:visited{color:#505050;word-spacing:0;}
.portal a:hover,.portal a:active{color:#DB1A22;}
.portal span{display:inline-block;height:38px;line-height:35px;}
.portal span span{padding:0 0 0 20px;}
.portal span span span{padding:0 20px 0 0;background-position:100% -80px;}
table {border-collapse: collapse;line-height:140%;margin-right: auto;margin-left: auto;margin-top: 6px;margin-bottom: 6px;}
td,th{margin:0;padding:3px;text-indent:0.25;text-align: center;}
</style>
<!--[if lte IE 8]>
<style type="text/css">
h2 em{color:#e4ebf8;}
</style>
<![endif]-->
<script src="Scripts/swfobject_modified.js" type="text/javascript"></script>
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-11293844-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>
<body>
<h1>哎哟～网页打开错啦！<a href="/">&#9666;返回首页</a><a href="javascript:history.go(-1);">&#9666;返回上一页</a><br />先玩玩这个游戏！然后重新打开页面吧！</h1>
<dl class="texts"><embed type="application/x-shockwave-flash" width="600" height="400" src="http://www.shuyong.net/gouwu/zhuamao.swf" wmode="transparent" quality="high" scale="noborder" flashvars="width=600&amp;height=400" allowscriptaccess="sameDomain" align="L"></embed></dl>
<h2><em>404 Error</em>: 抱歉, 您所查找的页面不存在, 可能已被删除或您输错了网址!</h2>
<p class="link">抱歉, 您所查找的页面不存在, 可能已被删除或您输错了网址!
<a href="/">&#9666;返回首页</a><a href="javascript:history.go(-1);">&#9666;返回上一页</a></p>
<dl class="texts">
<dt><strong>休息一下，玩玩这个游戏。</strong></dt>
<dd><ul><li>游戏玩法：将猫困在一个深色原点围成的圈子里面就算成功了。</li></ul></dd></dl>
<script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3Fc2c6bed2d140c53e5cde2fbb263011f6' type='text/javascript'%3E%3C/script%3E"));
</script>

<script type="text/javascript">
<!--
swfobject.registerObject("FlashID");
//-->
</script>
</body>
</html>
