<?php if(!defined('EMLOG_ROOT')) {exit('error!');} include View::getView('sheli/log');?>
<div class="main">
<div class="left"><div class="syleft">
<div class="mbx"><p>现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; <?php blog_sort($logid); ?> &raquo; <?php echo $log_title; ?></p></div>
<p class="title"><?php topflg($top); ?><?php echo $log_title; ?></p>
<p class="date">时间：<?php echo gmdate('Y-n-j', $date); ?> | 作者：<?php blog_author($author); ?> | 分类：<?php blog_sort($logid); ?> | 评论(<?php echo $comnum;?>) | 浏览(<?php echo $views;?>) | <?php blog_tag($logid); ?></p>
<div class="log-wznr"><?php echo $log_content; ?></div>
<div class="log-bq">
<script type="text/javascript">bdfx()</script>
本文固定链接：<?php echo Url::log($logid); ?><br />
本文由<?php blog_author($author); ?>原创或编辑，互联分享,尊重版权,转载请以链接形式标明本文地址
<?php if($allow_tb == 'y' && Option::get('istrackback') == 'y'){echo '<br />引用地址:	'.$tb_url; }?></div>
<div class="log-gg"><?php echo _g('log-gg'); ?></div>
<div class="log-xgwz">
<p class="log-xgwz-tt">你可能感兴趣的话题</p>
<?php related_logs($logData);?>
</div>
<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div><?php //!-- left end -- ?></div><?php //!-- syleft end -- ?>
<div class="right"><?php include View::getView('side');?></div>
</div><?php //!-- main end -- ?>
<?php include View::getView('footer');?>