<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!--index-->
<div id="index">
	<div class="user">
		 <!--幻灯片开始-->
         <div class="ifocus float_l">
         <div id="slide_img">
         <ul>
         <?php if(_g('index_img_xs')=='f'){$a='1';}elseif(_g('index_img_xs')=='q'){$a='2';}else{$a='3';}?>
         <?php index_top_sotop_new($a,5,1); ?>
         </ul>
         </div>
         </div>
         <!--ifocus end-->
	 <link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>statics/css/global.css"/>
         <script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>statics/js/jquery.js"></script>
         <script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>statics/js/slide.js"></script>
         <script type="text/javascript">
         $("#slide_img").allenSlide();
         </script>
         <!--幻灯片结束-->
		 <div class="user_zl">
		    <div class="zl"><span>个人资料</span></div>
	        <?php echo _g('user_zl'); ?>
		 </div>
	</div>
	<?php
     //获取一篇全局置顶文章
     function index_top($log_num){
	 $t = MySql::getInstance();
	 ?>
	 <?php
	 $sql = "SELECT gid,title,content,author,excerpt,comnum,top,type,date FROM ".DB_PREFIX."blog WHERE type='blog' and top='y' ORDER BY `top` DESC ,`date` DESC LIMIT 0,$log_num";
	 $list = $t->query($sql);
	 while($row = $t->fetch_array($list)){
	 ?>
	 <p class="title"><a href="<?php echo Url::log($row['gid']); ?>"><?php echo $row['title']; ?></a></p>
	 <p class="abstract"><?php echo extractHtmlData($row['content'],70); ?></p>
	 <p class="read"><a href="<?php echo Url::log($row['gid']); ?>">继续阅读全文..</a></p>
	 <p class="Author">Posted By <?php blog_author($row['author']); ?> on <?php echo gmdate('Y-n-j', $row['date']); ?> | 评论（<?php echo $row['comnum']; ?>） </p>
	 <?php }?>
    <?php } ?>
	<div class="user_right">
	      <div class="user_top">
	          <?php echo index_top(1); ?>
	      </div>
	      <div class="Newest">
                   <h2>最新文章</h2>
                   <ul><?php echo index_new(7); ?></ul>
	     </div>
	</div>
<div class="clear"></div>
</div>
<!--index end-->


<!--footer-->
<div class="footer">
	<div class="foot_img">
	   <ul>
	   <?php if(_g('index_foot_img_xs')=='f'){$a='1';}elseif(_g('index_foot_img_xs')=='q'){$a='2';}else{$a='3';}?>
	   <?php index_top_sotop_new($a,_g('index_img'),1); ?>
	   </ul>
	<div class="clear"></div>
	</div>
	
	<div class="Review">
		<div class="R_left">
		      <h2 class="R_title">随即文章</h2>
                   <ul>
                         <?php widget_random_log('随机文章'); ?>
                   </ul>
		</div>
		<div class="R_middle">
		      <h2 class="R_title">热门文章</h2>
                   <ul>
                         <?php widget_hotlog('热门文章'); ?>
                   </ul>
		</div>
		<div class="R_right">
		      <h2 class="R_title">最新评论</h2>
                   <ul>
                         <?php widget_newcomm('最新评论'); ?>
                   </ul>
		</div><!--R_right end-->
		<div class="clear"></div>
	</div><!--Review end-->