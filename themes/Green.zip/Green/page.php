<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="index">
	<div class="user_right" style="width:98%">
	      <div id="list_top" class="user_top">
	            <p class="title"><?php topflg($top); ?><?php echo $log_title; ?></p>
	            <?php echo $log_content; ?>
	            
	            <?php blog_comments($comments); ?>
	            <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	      </div>
	</div>
<div class="clear"></div>
</div>

<!--footer-->
<div id="foot" class="footer">
<?php include View::getView('footer'); ?>   