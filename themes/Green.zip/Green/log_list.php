<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php if($pageurl == Url::logPage()){ ?>
<?php include View::getView('index');?>
<?php }else{ ?>
<div id="index">
<div id="echo_log" class="user_right">
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
<?php
//拉取附件第一张图片，如果没有，则随机拉取ran文件夹图片，图片名称1.jpg - 9.jpg
if(!empty($thum_src)){
	$img_url = getThumbnail($value['logid']);
}else{
	$img_url = TEMPLATE_URL.'images/ran/'.rand(1,8).'.jpg';
}
?>
	      <div class="user_top">
	          <p class="echo_img"><img src="<?php echo $img_url; ?>"></p>
	          <p id="echo_title" class="title"><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></p>
	          <p class="abstract"><?php echo extractHtmlData($value['log_description'],100); ?></p>
	          <p class="read"><a href="<?php echo $value['log_url']; ?>">继续阅读全文..</a></p>
	          <p class="Author">Posted By <?php blog_author($value['author']); ?> on <?php echo gmdate('Y-n-j', $value['date']); ?> | 评论（<?php echo $value['comnum']; ?>） </p>
	     </div>
<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>

<div id="pagenavi">
	<?php echo $page_url;?>
</div>
</div>

<div class="clear"></div>
</div>
<!--index end-->











<!--footer-->
<div class="footer">

	

<?php } ?>
<?php include View::getView('footer'); ?>   