<?php

/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
//设置背景图颜色
	'body_color' => array(
		'type' => 'text',
		'name' => '设置背景颜色',
		'description' => '推荐使用网页颜色，#开头的颜色值',
		'default' => '#5F7821',
	),
//设置背景图定位
	'body_position' => array(
		'type' => 'text',
		'name' => '设置背景图定位',
		'description' => '第一个值是水平位置，第二个值是垂直位置。左上角是 0% 0%。右下角是 100% 100%。如果您仅规定了一个值，另一个值将是 50%。默认为0% 0%',
		'default' => '0% 0%',
	),	
//设置背景图尺寸
	'body_size' => array(
		'type' => 'text',
		'name' => '设置背景图像的尺寸',
		'description' => '设置背景图像的高度和宽度。第一个值设置宽度，第二个值设置高度。如果只设置一个值，则第二个值会被设置为 "auto"。默认值为空，无特殊要求可不填写，PS：该属性不支持IE6,7,8',
		'default' => '',
	),	
//如何重复背景图
	'body_repeat' => array(
		'type' => 'radio',
		'name' => '设置如何重复背景图像',
		'values' => array(
			'repeat' => '背景图像将在垂直方向和水平方向重复<br/>',
			'repeat-x' => '背景图像将在水平方向重复<br/>',
			'repeat-y' => '背景图像将在垂直方向重复<br/>',
			'no-repeat' => '背景图像将仅显示一次<br/>',
		),
		'default' => 'no-repeat',
	),
	
//背景图是否随页面滚动而滚动
	'body_attachment' => array(
		'type' => 'radio',
		'name' => '设置背景图是否随页面滚动',
        'values' => array(
			'scroll' => '背景图随页面滚动而滚动<br/>',
			'fixed' => '背景图不随页面滚动而滚动<br/>',
		),
		'default' => 'scroll',
	),
//设置背景图
	'body_img' => array(
		'type' => 'image',
		'name' => '设置背景图',
		'description' => '选择文件上传你的背景图',
		'default' => ''.TEMPLATE_URL.'images/body.png',
	),

//是否开启背景图片
	'body_img_yes' => array(
		'type' => 'radio',
		'name' => '是否启用背景图',
		'description' => '是否启用背景图',
		'values' => array(
			'yes' => '开启背景图<br/>',
			'no' => '关闭背景图<br/>',
		),
		'default' => 'yes',
	),
//LOGO显示方式
	'index_logo' => array(
		'type' => 'radio',
		'name' => 'LOGO显示方式',
		'description' => 'LOGO显示方式',
		'values' => array(
			'yes' => '显示logo图片<br/>',
			'no' => '显示文字<br/>',
		),
		'default' => 'yes',
	),
//设置LOGO图
	'index_logo_img' => array(
		'type' => 'image',
		'name' => 'LOGO设置',
		'description' => '选择文件上传你的LOGO',
		'default' => ''.TEMPLATE_URL.'images/logo.png',
	),
//首页图文调用数量
	'index_img' => array(
		'type' => 'text',
		'name' => '首页图文调用数量',	
		'description' => '首页图文调用数量',
		'default' => '5',
	),
//首页幻灯片显示方案
	'index_img_xs' => array(
		'type' => 'radio',
		'name' => '首页幻灯片显示方案',
		'description' => '首页幻灯片显示方案',
		'values' => array(
			'f' => '调用全局置顶图片<br/>',
			'q' => '调用分类置顶图片<br/>',
		       'z' => '调用最新文章图片<br/>',
		),
		'default' => 'z',
	),
//首页图文显示方案
	'index_foot_img_xs' => array(
		'type' => 'radio',
		'name' => '首页图文调用方案',
		'description' => '首页图文调用方案',
		'values' => array(
			'f' => '调用全局置顶图片<br/>',
			'q' => '调用分类置顶图片<br/>',
		       'z' => '调用最新文章图片<br/>',
		),
		'default' => 'z',
	),
//个人资料
	'user_zl' => array(
		'type' => 'text',
		'name' => '个人资料编辑器',	
		'multi' => true,
		'rich' => true,
		'description' => '个人资料编辑器',
		'default' => '<li><span>姓名：陈子文</span></li>
	             <li><span>昵称：沉默着继续</span></li>
	             <li><span>年龄：21</span></li>
	             <li><span>E-mil：chenziwen@lantk.com</span></li>
	             <li><span>W EB：http://www.lantk.com</span></li>
	             <li><span>个人说明：比戒色更难的事不仅仅只是戒烟</span></li>',
	),











);?>