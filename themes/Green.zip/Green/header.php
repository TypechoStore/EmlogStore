<?php
/*
Template Name:Green
Description:简洁优雅的个人主页模板
Version:1.0
Author:emlog学院
Author Url:http://vps.lantk.com
Sidebar Amount:0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>style.css" media="all" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>	

<!--复制以下代码到你的header.php相应位置-->
<?php
if(_g('body_attachment')=='scroll'){
    $a='scroll';
}else{
    $a='fixed';
}
if(_g('body_repeat')=='repeat'){
    $b='repeat';
}elseif(_g('body_repeat')=='repeat-x'){
    $b='repeat-x';
}elseif(_g('body_repeat')=='repeat-y'){
	$b='repeat-y';
}else{
	$b='no-repeat';

}
if(_g('body_img_yes')=="yes"){
    $c = _g('body_img');
}else{
    $c = '';
}
?>
<style>
body{
      background-color:<?php echo _g('body_color'); ?>;
	  background-position:<?php echo _g('body_position'); ?>;
	  background-size:<?php echo _g('body_size'); ?>;
	  background-repeat:<?php echo $b; ?>;
	  background-attachment:<?php echo $a; ?>;
	  background-image:url("<?php echo $c; ?>");
}
</style>
<?php doAction('index_head',$logid); ?>
</head>
<!--head-->
<div id="head">
      <div class="head_left">
         <?php if(_g('index_logo')=='no'): ?>
         <h2 id="head_title" class="title"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h2>
         <?php else: ?>
         <a href="<?php echo BLOG_URL; ?>"><img src="<?php echo _g('index_logo_img');?>"></a>
         <style>.head_left {margin-left: 5px; margin-top: 20px;}</style>
         <?php endif; ?>
      </div>
      <div class="head_right">
         <?php blog_navi(); ?>
      </div>
<div class="clear"></div>
</div>
