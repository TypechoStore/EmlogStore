<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="footer"><span style="cursor:pointer;" title="Copyright">&copy;</span>&nbsp;<a href="<?php echo BLOG_URL; ?>" target="_blank"><?php echo $blogname; ?></a>&nbsp;|&nbsp;Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">Emlog</a>&nbsp;|&nbsp;Theme by <a href="http://emlog.aisheji.org/" target="_blank">Tod.</a></div>
<script type="text/javascript">
$(function(){
	$(".active a").each(function(){	
		$(this).hover(
			function(){
				$(this).css("cursor","pointer");
				$(this).stop();
		   		$(this).animate({width:90},400,function(){$(this).children(".title").css("display","block");})},
			function(){
				$(this).stop();	
				$(this).children(".title").css("display","none");
				$(this).animate({width:20},400)})
	})
});
</script>
<?php echo $footer_info; ?>
<?php doAction('index_footer'); ?>
<script type="text/javascript">
$(function(){
	function backtop(){
		var backtop = $("<a class='backTop'><b>∧</b></a>")
		$("body").append(backtop);
		
		var fn = function(){
		$('html,body').animate({
			scrollTop: '0px'
			}, 200);
			return false;
		}
		$('.backTop').bind('click',fn);
		
		$(window).scroll(function () {
			var scrollt = $(window).scrollTop();
			if ( scrollt > 100 ){
				$(".backTop").fadeIn("slow");
			} else {
				$(".backTop").fadeOut("slow");
			}
		});
	}
	backtop();
});
</script>
<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"24"},"share":{},"image":{"viewList":["qzone","tsina","tqq","t163","tsohu","weixin"],"viewText":"分享到：","viewSize":"24"},"selectShare":{"bdContainerClass":null,"bdSelectMiniList":["qzone","tsina","tqq","t163","tsohu","weixin"]}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=86835285.js?cdnversion='+~(-new Date()/36e5)];</script>
</body>
</html>