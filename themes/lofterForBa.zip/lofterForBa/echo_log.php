<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="box wid700">
	<div class="block article">
		<div class="main">
			<div class="content">
				<div class="text">
					<span style="font-size:18px"><?php topflg($top); ?><a href="<?php echo Url::log($logid); ?>"><?php echo $log_title; ?></a></span><span class="date">浏览(<?php echo $views; ?>)</span>
					<p><?php echo $log_content; ?></p>
					<div class="tag"><?php blog_tag($logid); ?></div>
				</div>
			</div>
		</div>
	</div>
    <div class="page">
		<?php neighbor_log($neighborLog); ?>
					<div style="margin:0 auto;width:225px;" class="bdsharebuttonbox">
					<a title="分享到QQ空间" href="#" class="bds_qzone" data-cmd="qzone"></a>
					<a title="分享到新浪微博" href="#" class="bds_tsina" data-cmd="tsina"></a>
					<a title="分享到腾讯微博" href="#" class="bds_tqq" data-cmd="tqq"></a>
					<a title="分享到网易微博" href="#" class="bds_t163" data-cmd="t163"></a>
					<a title="分享到搜狐微博" href="#" class="bds_tsohu" data-cmd="tsohu"></a>
					<a title="分享到微信" href="#" class="bds_weixin" data-cmd="weixin"></a>
					<a href="#" class="bds_more" data-cmd="more"></a></div>
	</div>
	<div id="blog_commnets">	
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
</div>
<?php
 include View::getView('footer');
?>