<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="box wid700">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
    <div class="block article">
            <div class="content">
                <div class="text">
				    <span class="tag"><?php blog_sort($value['logid']); ?></span>
                    <?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><b><?php echo $value['log_title']; ?></b></a>
					<span class="date">
					<?php blog_tag($value['logid']); ?>
					<?php echo gmdate('Y-n-j G:i', $value['date']); ?> 
	                <?php editflg($value['logid'],$value['author']); ?>
					〖<?php echo $value['comnum']; ?>〗
					</span>
                </div>
            </div>
    </div>
<?php endforeach; ?>
    <div class="page">
	    <?php 
	        $page_next = next_page($lognum, $index_lognum, $page, $pageurl);
             echo $page_next;
	    ?>
    </div>
</div>
<div class="box wid700">
<div id="listlink" class="container">
<ul class="fixed">
<li>友情链接:</li>
<ul><?php widget_link($title);?></ul>
</div>
</div>
<?php
 include View::getView('footer');
?>