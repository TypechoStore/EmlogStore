﻿<?php
/*
  Template Name: PHP-Amateur Theme
  Description:php爱好者blog模板。采用了minify来压缩缓存js、css文件减少请求，缓存文件保存在PHP-Amateur/min/tmp下面。模板显示为两栏，左侧显示博文列表、博文内容、碎语等，右侧为相关widgets组件，右侧屏蔽了开启：存档、链接两个组件，因为已经在页面上其他的位置上已有显示
  Version:1.3
  Author:PHP爱好者
  Author Url:http://blog.51edm.org
  Sidebar Amount:1
  For emlog:5.0
 */
if (!defined('EMLOG_ROOT')) {
    exit('error!');
}
require_once View::getView('module');
$basePath = str_replace("http://" . $_SERVER['HTTP_HOST'], "", BLOG_URL);
define('CURRENT_TEMPLATE_PATH', $basePath . "content/templates/" . Option::get('nonce_templet') . '/');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title><?php echo $site_title; ?></title>
        <meta name="keywords" content="<?php echo $site_key; ?>" />
        <meta name="description" content="<?php echo $site_description; ?>" />
        <meta http-equiv="X-UA-Compatible" content="chrome=1" />
        <meta name="generator" content="emlog" />
        <link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
        <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
        <link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
        <link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>min/?f=<?php echo CURRENT_TEMPLATE_PATH ?>main.css" type="text/css" media="screen" />
        <script src="<?php echo TEMPLATE_URL; ?>min/?f=<?php echo CURRENT_TEMPLATE_PATH ?>js/jquery.js,<?php echo CURRENT_TEMPLATE_PATH ?>js/base.js,/include/lib/js/common_tpl.js" type="text/javascript"></script>
        <?php
        doAction('index_head');
        header('X-Powered-By:hengqin2008@qq.com');
        ?>
    </head>
    <body>
        <div id="toplogo">
            <div class="header">
                <div id="logo-holder">
                    <h1 id="logo"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
                </div>
                <div id="my_banner"><a href="<?php echo BLOG_URL; ?>"><img src="<?php echo TEMPLATE_URL; ?>img/my_banner.png" height="112" width="697" /></a></div>
            </div>
        </div>
        <?php
        global $CACHE;
        $navi_cache = $CACHE->readCache('navi');
        ?>
        <!--nav begin-->
        <form id="side-title-form"  name="keyform" method="get"  action="<?php echo BLOG_URL; ?>index.php" onsubmit="if($('#side-title-input').val()=='输入后按回车搜索...'||$('#side-title-input').val()=='') return false;">
            <div id="topnav">
                <div class="t"></div>
                <div id="tophead" class="clearfix">
                    <ul id="nav">
                        <?php
                        foreach ($navi_cache as $value):
                            if ($value['url'] == 'admin' && (ROLE == 'admin' || ROLE == 'writer')):
                                ?>
                                <li class="nav-item"><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
                                <li class="nav-item"><a href="<?php echo BLOG_URL; ?>admin/">管理站点</a></li>
                                <li class="nav-item"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
                                <?php
                                continue;
                            endif;
                            $newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
                            $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
                            $current_tab = (BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url']) ? 'current' : 'nav-item';
                            ?>
                            <li class="<?php echo $current_tab; ?>"><a href="<?php echo $value['url']; ?>" <?php echo $newtab; ?>><?php echo $value['naviname']; ?></a></li>
                        <?php endforeach; ?>
                        <li class="topSearch"><input style="" type="text" id="side-title-input" autocomplete="off" value='输入后按回车搜索...' onblur="if(this.value == '')this.value='输入后按回车搜索...'" onfocus="if(this.value == '输入后按回车搜索...')this.value = ''"  name="keyword" /></li>
                    </ul>
                </div>
                <div class="b"></div>
            </div>
        </form>
        <!--nav end-->
