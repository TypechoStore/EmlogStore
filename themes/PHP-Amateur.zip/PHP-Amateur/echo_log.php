<?php
/*
 * 阅读日志页面
 */
if (!defined('EMLOG_ROOT')) {
    exit('error!');
}
?>
<div class="container">
    <!--leftSide begin-->
    <div class="main">
        <div class="posts">        
            <div class="post-box radius">
                <div class="post-box-container">
                    <h2 class="con_title"><?php topflg($top); ?><?php echo $log_title; ?></h2>
                    <div class="con_info">
                        <span class="fl">博文日期：&nbsp;</span><span class="fl"><?php echo gmdate('Y-n-j H:i:s', $date); ?></span><span class="fl">&nbsp;&nbsp;分类：&nbsp;</span><?php blog_sort($logid); ?>
                        <?php editflg($logid, $author); ?>
                        <span class="fr">
                            <?php echo $views; ?> 次访问
                        </span>
                        <a class="fr" href="<?php echo $value['log_url']; ?>#comments">
                            <?php echo $comnum; ?> 条评论 &nbsp; | &nbsp;
                        </a>
                    </div>
                    <div class="entry rich-content">
                        <?php
                        echo $log_content;
                        blog_att($logid);
                        ?>
                    </div>
                    <div class="meta"><?php doAction('log_related', $logData); ?>
                        <div style="border-top:1px solid #ECEEF0; margin-bottom:10px;"></div>
                        <div class="post-tags">
                            <?php blog_tag($logid); ?>
                        </div>
                        <?php neighbor_log($neighborLog); ?>
                    </div>
                </div>
            </div>
        </div>
        <!--pageList begin-->
        <div id="notes" class="notes radius"> 
            <?php
            blog_comments($comments);
            blog_comments_post($logid, $ckname, $ckmail, $ckurl, $verifyCode, $allow_remark);
            ?>
        </div>
        <!--pageList end-->
    </div>
    <!--leftSide end-->
    <!--rightSide begin -->
    <div class="aside">
        <?php
        include View::getView('side');
        ?>
    </div>
    <!--rightSide end -->
</div>
<?php
include View::getView('footer');
?>