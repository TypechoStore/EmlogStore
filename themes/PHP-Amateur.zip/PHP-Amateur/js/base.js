var init=function(){
    if($("#sideTools").size()==0){
        $("body").append('<ul id="sideTools"><li class="top"><span></span>返回页头</li><li class="aboutMe"><span></span><a href="/about.html">关于我</a></li><li class="suiyu"><span></span><a href="/t">碎语</a></li><li class="bottom"><span></span>到页尾</li></ul>');
    }
    setTimeout(function(){
        var maxH=$(".main").height()>$(".aside").height()?$(".main").height():$(".aside").height();
        $(".main").height(maxH);
        $(".aside").height(maxH);
    },500);

    $("#sideTools").mouseenter(function(){
        $(this).animate({
            right: '0px'
        }, 300);
    }).mouseleave(function(){
        $(this).animate({
            right: '-70px'
        }, 300);
    });
    $("#sideTools .top").click(function(){
        $('html,body').animate({
            scrollTop: '0px'
        }, 800);
    });
    $("#sideTools .bottom").click(function(){
        $('html,body').animate({
            scrollTop:$('#footer').offset().top
        }, 800);
    });
    $(".classification p").toggle(
        function () {
            var obj=$(this);
            $(".classification dl").slideDown("fast", function(){
                $(obj).html("点击隐藏存档-");
            });
        },
        function () {
            var obj=$(this);
            $(".classification dl").slideUp("fast", function(){
                $(obj).html("点击查看存档+");
            });
        }
        );

    $(window).scroll(function() {
        var topnavPosition=document.body.scrollTop?document.body.scrollTop:document.documentElement.scrollTop;
        topnavPosition >= 100?$("#topnav").fadeTo("slow", 0.8).css({
            position:"fixed",
            top:"0px",
            left:"0px",
            zIndex:10
        }):$("#topnav").removeAttr('style');
    });
}



// 修复图片尺寸
function fixImgSize(img){
    var MAXWIDTH = '500';

    if(img.width > MAXWIDTH){
        img.width = MAXWIDTH;
        img.removeAttribute('height');
    }
}
