<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
         <div class="article">
          <h2>微语</h2><div class="clr"></div>
          <?php 
			    foreach($tws as $val):
			    $author = $user_cache[$val['author']]['name'];
			    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
			                BLOG_URL . 'admin/views/images/avatar.jpg' : 
			                BLOG_URL . $user_cache[$val['author']]['avatar'];
			    $tid = (int)$val['id'];
			    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
			    ?> 
    
	          <div class="comment">
	            	<a href="#"><img src="<?php echo $avatar; ?>" width="40" height="40" alt="user" class="userpic" /></a>
		            <p><a href="#"><?php echo $author; ?></a> 说:<br /><?php echo $val['date'];?></p>
		            <p><?php echo $val['t'];?>
		            	<span style="float:right;">
		            		<a href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">回复(<span id="rn_<?php echo $tid;?>"><?php echo $val['replynum'];?></span>)
		            		</a>
		            	</span>
		            </p> 
	            	<div id="tw"><ul id="r_<?php echo $tid;?>" class="r"></ul></div>
		            <?php if ($istreply == 'y'):?>
									<div class="comment" id="rp_<?php echo $tid;?>" style="display: none;">
									<ol style="display:<?php if(ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER){echo 'none';}?>"><li>
									    <label for="author">昵称 (必填)</label>
									    <input id="rname_<?php echo $tid; ?>" value="" class="text" maxlength="49" value="<?php echo $ckname; ?>" tabindex="1"/>
									  </li>
									  <li style="display:<?php if($reply_code == 'n'){echo 'none';}?>">
									    <label for="email">验证码(必填):&nbsp;<?php echo $rcode; ?></label>
									    <input id="rcode_<?php echo $tid; ?>" class="text" maxlength="128"  value="" tabindex="2"/>
									  </li></ol>
									  <ol><li>
									    <label for="comment">评论</label>
									    <textarea id="rtext_<?php echo $tid; ?>" rows="3" cols="50" tabindex="3"></textarea>
									  </li><li>
									    <input class="send" type="button" tabindex="4" onclick="reply('<?php echo DYNAMIC_BLOGURL; ?>index.php?action=reply',<?php echo $tid;?>);" value="回复" /> 
									    <div class="clr"></div>
									</li></ol>
									</div>
								<?php endif;?>
	          </div>
          <?php endforeach;?>
        </div><!--end article-->
       <p class="pages"><?php echo $pageurl;?></p>
      </div>
      
      <?php
			 include View::getView('side');
			 include View::getView('footer');
			?>