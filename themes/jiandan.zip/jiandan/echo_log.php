<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2><?php echo $log_title; ?></h2><div class="clr"></div>
          <p><span class="date">日期: <?php echo gmdate('Y-n-j G:i', $date); ?></span> 
          	&nbsp;|&nbsp; 作者: <?php blog_author($author); ?> 
          	&nbsp;|&nbsp; 分类: [<?php blog_sort($logid); ?>] 
          	&nbsp;|&nbsp; 评论: <?php echo $comnum; ?> 
          	&nbsp;|&nbsp; 查看: <?php echo $views; ?>
          </p>
          <p><?php echo $log_content; ?></p>
          <p class="lf"><div class="bdsharebuttonbox" style="float:right;">
          	<nobr>
          	<a href="#" class="bds_more" data-cmd="more"></a>
          	<a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a>
          	<a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a>
          	<a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a>
          	<a href="#" class="bds_renren" data-cmd="renren" title="分享到人人网"></a>
          	<a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a>
          	<a href="#" class="bds_tieba" data-cmd="tieba" title="分享到百度贴吧"></a>
          	<a href="#" class="bds_douban" data-cmd="douban" title="分享到豆瓣网"></a>
          </nobr>
          		</div>
						<script>
							window._bd_share_config={"common":{"bdSnsKey":{"tsina":"Sina","tqq":"Tencent","t163":"163","tsohu":"sohu"},"bdText":"","bdMini":"1","bdMiniList":false,"bdPic":"","bdStyle":"1","bdSize":"16"},"share":{},"image":{"viewList":["qzone","tsina","tqq","renren","weixin","tieba","douban"],"viewText":"分享到：","viewSize":"16"},"selectShare":{"bdContainerClass":null,"bdSelectMiniList":["qzone","tsina","tqq","renren","weixin","tieba","douban"]}};
							with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];
						</script>
					</p>
        </div>
        <div class="article">
          <div class="comment">
            <?php blog_comments($comments); ?> 
          </div>
        </div>
        <div class="article">
         <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
        </div>
      </div>
      
      <?php
			 include View::getView('side');
			 include View::getView('footer');
			?>