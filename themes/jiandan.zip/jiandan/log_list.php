<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
      	<?php doAction('index_loglist_top'); ?>
      	<?php 
				if (!empty($logs)):
				foreach($logs as $value): 
				?>
        <div class="article">
          <h2><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2><div class="clr"></div>
          <p><span class="date">日期: <a href="#"><?php echo gmdate('Y-n-j G:i', $value['date']); ?></a></span> 
          	&nbsp;|&nbsp; 作者: <?php blog_author($value['author']); ?> 
          	&nbsp;|&nbsp; 分类: [<?php blog_sort($value['logid']); ?>] 
          	&nbsp;|&nbsp;评论:<?php echo $value['comnum']; ?>
          	&nbsp;|&nbsp;查看:<?php echo $value['views']; ?>
          	&nbsp;&nbsp;<?php editflg($value['logid'],$value['author']); ?>
          </p>
          <a href="#" class="com"><?php echo gmdate('j', $value['date']); ?></a>
          <?php
					 	$imgFileArray = TEMPLATE_URL.'images/random/'.rand(1,9).'.jpg';
					?>
          <img src="<?php echo $imgFileArray; ?>" width="625" height="205" alt="image" />
          <p><?php echo $value['log_description']; ?></p>
          <p class="spec"></p>
        </div>
       <?php 
					endforeach;
					else:
			 ?>
			 <div class="article">
          <h2><span>未找到</span></h2><div class="clr"></div>
          <p>抱歉，没有符合您查询条件的结果。</p>
        </div>

			<?php endif;?>
        <p class="pages"><?php echo $page_url;?></p>
      </div>
       <?php
			 include View::getView('side');
			 include View::getView('footer');
			?>