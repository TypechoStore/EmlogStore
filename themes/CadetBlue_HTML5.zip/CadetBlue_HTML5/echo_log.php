<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
		<div id="main">
		<div id="primary">
			<div id="content">

				<article class="post type-post status-publish format-standard hentry category-uncategorized tag-personal" role="article">
					<header class="entry-header">
						<h1 class="entry-title"><?php topflg($top); ?><?php echo $log_title; ?></h1>
						<div class="entry-meta">
							<?php blog_sort($logid); ?><time class="entry-date" datetime="<?php echo gmdate('c', $date); ?>" pubdate><?php echo gmdate('Y-n-j G:i l', $date); ?></time></a>	<?php editflg($logid,$author); ?>	
						</div><!-- .entry-meta -->
					</header><!-- .entry-header -->
					<div class="entry-content"><?php echo $log_content; ?>

<?php blog_att($logid); ?>
						<!--  -->
					</div><!-- .entry-content -->
<div id="share">
		<a id="button" onclick="$(this).parent().toggleClass('expanded');"></a>
		<div class="dropdown">
			<p>We'll love you for it!</p>
			<hr>
<span class="st_sharethis_custom" displayText="Share this!">Share this! </span><div class="bshare-custom"><a title="分享到QQ空间" class="bshare-qzone" href="javascript:void(0);"></a><a title="分享到新浪微博" class="bshare-sinaminiblog" href="javascript:void(0);"></a><a title="分享到人人网" class="bshare-renren" href="javascript:void(0);"></a><a title="分享到腾讯微博" class="bshare-qqmb" href="javascript:void(0);"></a><a title="分享到豆瓣" class="bshare-douban" href="javascript:void(0);"></a><a title="更多平台" class="bshare-more bshare-more-icon"></a></div><script type="text/javascript" charset="utf-8" src="http://static.bshare.cn/b/button.js#style=-1&amp;uuid=eb6ed31a-0f21-49da-b113-ab0ce04e1a8b&amp;pophcol=2&amp;lang=zh"></script><script type="text/javascript" charset="utf-8" src="http://static.bshare.cn/b/bshareC0.js"></script>
		</div>
</div>
<div class="entry-meta">
<?php blog_tag($logid); ?>
</div><!-- .entry-meta -->
<!--
<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
-->
<?php doAction('log_related', $logData); ?>

				</article><!-- #article end -->
<?php neighbor_log($neighborLog); ?>

<p class="tutup_komentar"> </p>
<div id="comments">
			<div class="sliding"><h3 class="sub">&mdash; 已有<? echo $comnum ?>条评论 &mdash;</h3></div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
			</div><!-- #content -->
		</div><!-- #primary -->
	</div><!-- #main  -->
<? include View::getView('side');include View::getView('footer');?>