<?php
/*
Template Name:<font color="CadetBlue">CadetBlue_HTML5</font>
Description:<font color="red">CadetBlue_HTML5模板</font><br><font color="blue">本主题适用于IE7+, Chrome6+, FF3.5+, Safari4+</font>
Version:Ver 1.0
Author:Qzz
Author Url:http://www.qzee.net
Sidebar Amount:1
ForEmlog:4.1.0 - 4.2.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]> <html dir="ltr" lang="zh-CN" class="ie6"> <![endif]-->
<!--[if IE 7 ]>    <html dir="ltr" lang="zh-CN" class="ie7"> <![endif]-->
<!--[if IE 8 ]>    <html dir="ltr" lang="zh-CN" class="ie8"> <![endif]-->
<!--[if IE 9 ]>    <html dir="ltr" lang="zh-CN" class="ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html dir="ltr" lang="zh-CN"> <!--<![endif]-->
<head>
<meta charset="UTF-8" />
	<title><?php echo $blogtitle; ?></title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="generator" content="Qzz" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" type='image/x-icon' href="/favicon.ico">
  <link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
  <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
  <link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />

	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="apple-touch-icon" href="<?php echo TEMPLATE_URL; ?>newStyle/apple-touch-icon.png"><!--60X60-->
    <link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>newStyle/style.css" type="text/css" media="screen, projection" />
	<script src="<?php echo TEMPLATE_URL; ?>newStyle/js/rudyplugins.js"></script>
<!-- PREFIX-FREE --> 
	<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>newStyle/js/prefixfree.min.js"></script>
<!--[if lt IE 9]>
<script src="//cdn.bootcss.com/html5shiv/r29/html5.min.js"></script>
<![endif]-->

<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>

<link rel="index" title="<?php echo $blogtitle; ?>" />

<!-- All in One SEO Pack - Pro Version 1.72 by Michael Torbert of Semper Fi Web Design[584,648] -->
	<meta name="description" content="<?php echo $description; ?>" />
	<meta name="keywords" content="<?php echo $site_key; ?>" />
	<link rel="canonical" href="" />
<!-- /all in one seo pack Pro Version-->
	<!-- Art Direction Styles -->
	<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>

	<body class="home blog">
<!--
//若不是则输出
<a id="tooCool" href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>
-->
	<div id="page" class="hfeed">
<nav>
		<ul>
			<li class="home"><a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>">&#9733;</a></li>
	<?php 
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach ($navi_cache as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	$val['is_blank'] = $val['newtab'] == 'y' ? 'target="_blank"' : '';
    $val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
	?>
		  <li><a <?php echo isset($logid) && $key == $logid ? 'class="selected"' : ' ';?> href="<?php echo $val['url']; ?>" target="<?php echo $val['is_blank']; ?>"><?php echo $val['naviname']; ?></a></li>
	<?php endforeach;?>
	<?php doAction('navbar', '<li>', '</li>'); ?>

			<li class="right"><a href="http://blog.qzee.net/rss.php" title="RSS" id="feedlink"></a></li>

			<li class="right"><a class="facebook" href="http://facebook.com/aappc" title="Facebook">F</a></li>

			<li class="right"><a class="twitter" href="http://weibo.com/waterg" title="WeiBo">T</a></li>

			<li class="right"><a class="flickr" href="http://list.qq.com/cgi-bin/qf_invite?id=631bd6e0451632fd39822a42fb9dc2876a517b8fc8ce2259" title="订阅我">R</a></li>

		</ul>

	</nav>
	<!-- <div id="headersearch">
			<form method="get" id="searchform" action="">
			<input type="text" class="field" name="keyword" id="s"  placeholder="Search" />
			<input type="submit" class="submit" name="submit" id="searchsubmit" value="Search" />
	</form>
		</div> -->
		<header id="branding" role="banner">
				<hgroup>
					<h1 class="logotype"><?php echo $blogname; ?></h1>
					<h2 class="tagline blog"><?php echo $bloginfo; ?></h2>
				</hgroup>
			</header><!-- #branding -->