<?php 
/*
* 侧边栏组件、页面模块
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//menu：分类
function menu_sort($class){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	
	<?php foreach($sort_cache as $value): ?>
	 <li class="cat-<?php echo $class; ?>-<?php echo $value['sid']; ?>">
	<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?></a>
	</li>
	<?php endforeach; ?>

<?php }?>
<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
	<div class="column">
	<h3><?php echo $title; ?></h3>
		<ul>
<?php if (!empty($user_cache[1]['photo']['src'])): ?>
			<p><img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="<?php echo $user_cache[1]['photo']['width']; ?>" height="<?php echo $user_cache[1]['photo']['height']; ?>" alt="blogger" /></p>
<?php endif;?>
			<h4><?php echo $name; ?></h4>
			<h5><?php echo $user_cache[1]['des']; ?></h5>
		</ul>
	</div>

<?php }?>
<?php
//widget：日历
function widget_calendar($title){ ?>
        <div class="column">
			<p>
				<div id="calendar"></div>
				<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
			</p>
        </div>
<?php }?>
<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
        <div class="column">
			<h3><?php echo $title; ?></h3>
			<p>
	<?php foreach($tag_cache as $value): ?>
		<span style="font-size:<?php echo $value['fontsize']; ?>pt; line-height:30px;">
		<a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇日志"><?php echo $value['tagname']; ?></a></span>
	<?php endforeach; ?>
		    </p>
        </div>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
        <div class="column">
			<h3><?php echo $title; ?></h3>
            <ul>
	<?php foreach($sort_cache as $value): ?>
	<li>
	<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
	<a href="<?php echo BLOG_URL; ?>rss.php?sort=<?php echo $value['sid']; ?>"><img src="<?php echo TEMPLATE_URL; ?>newStyle/images/rss.gif" alt="订阅该分类"/></a>
	</li>
	<?php endforeach; ?>
            </ul>
        </div>
<?php }?>
<?php
//widget：最新碎语
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	?>
        <div class="column">
			<h3><?php echo $title; ?></h3>
            <ul>
	<?php foreach($newtws_cache as $value): ?>
	<li><?php echo $value['t']; ?><p><?php echo smartDate($value['date']); ?> </p></li>
	<?php endforeach; ?>
    <?php if ($istwitter == 'y') :?>
	<p><a href="<?php echo BLOG_URL . 't/'; ?>">更多&raquo;</a></p>
	<?php endif;?>
            </ul>
        </div>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
        <div class="column">
			<h3><?php echo $title; ?></h3>
            <ul>
	<?php
	foreach($com_cache as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	?>
	<li><a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a>
	<br /><span style="color:#aaa">by <?php echo $value['name']; ?> on <?php echo smartDate($value['date']); ?> </span></li>
	<?php endforeach; ?>
            </ul>
        </div>
<?php }?>
<?php
//widget：最新日志
function widget_newlog($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
        <div class="column">
			<h3><?php echo $title; ?></h3>
            <ul>
	<?php foreach($newLogs_cache as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
            </ul>
        </div>
<?php }?>
<?php
//widget：随机日志
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
        <div class="column">
			<h3><?php echo $title; ?></h3>
            <ul>
	<?php foreach($randLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
            </ul>
        </div>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
        <div class="column">
			<h3><?php echo $title; ?></h3>
            <ul>
			<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php" id="search_form">
              <p>
				<input class="search" type="text" name="keyword" value="Enter keywords....." onClick="this.value=''" />
                <input name="search" type="image" style="border: 0; margin: 0 0 -9px 5px;" src="<?php echo TEMPLATE_URL; ?>style/search.png" alt="Search" title="Search" />
              </p>
			</form>
        </div>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
        <div class="column">
			<h3><?php echo $title; ?></h3>
            <ul>
	<?php foreach($record_cache as $value): ?>
	<li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
	<?php endforeach; ?>
            </ul>
        </div>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
        <div class="column">
			<h3><?php echo $title; ?></h3>
            <p>
	<?php echo $content; ?>
            </p>
        </div>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
	?>
        <div class="column">
			<h3><?php echo $title; ?></h3>
            <ul>
	<?php foreach($link_cache as $value): ?>
	<dd><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></dd>
	<?php endforeach; ?>
            </ul>
        </div>
<?php }?>
<?php
//blog：置顶
function topflg($istop){
	$topflg = $istop == 'y' ? "<img src=\"".TEMPLATE_URL."/newStyle/images/import.gif\" title=\"置顶日志\" /> " : '';
	echo $topflg;
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == 'admin' || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
	<span class="entry-utility-prep entry-utility-prep-cat-links">分类 : </span><a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
	<?php endif;?>
<?php }?>
<?php
//blog：文件附件
function blog_att($blogid){
	global $CACHE;
	$log_cache_atts = $CACHE->readCache('logatts');
	$att = '';
	if(!empty($log_cache_atts[$blogid])){
		$att .= '<hr><p class="att">附件下载：';
		foreach($log_cache_atts[$blogid] as $val){
			$att .= '<br /><div class="wp_page_numbers"><a href="'.BLOG_URL.$val['url'].'" target="_blank">'.$val['filename'].'</a> '.$val['size'].'</div></p>';
		}
	}
	echo $att;
}
?>
<?php
//blog：日志标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '<span class="meta-sep">Tag: </span>';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "<span class=\"author vcard\"><a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a></span> ';
		}
		echo $tag;
	}
}
?>
<?php
//blog：日志作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻日志
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog):?><span class="pager1">
	<a href="<?php echo Url::log($prevLog['gid']) ?>"><span class="meta-nav">&larr;</span> <?php echo $prevLog['title'];?></a></span><?php endif;?>
	<?php if($nextLog && $prevLog):?><?php endif;?>
	<?php if($nextLog):?><span class="pager2"><a href="<?php echo Url::log($nextLog['gid']) ?>"><?php echo $nextLog['title'];?>
	<span class="meta-nav">&rarr;</span></a></span>
	<?php endif;?>
<?php }?>
<?php
//blog：引用通告
function blog_trackback($tb, $tb_url, $allow_tb){
    if($allow_tb == 'y' && Option::get('istrackback') == 'y'):?>
	<div id="trackback_address">
	<p>引用地址: <input type="text" class="input" value="<?php echo $tb_url; ?>">
	<a name="tb"></a></p>
	</div>
	<?php endif; ?>
	<?php foreach($tb as $key=>$value):?>
		<ul id="trackback">
		<li><a href="<?php echo $value['url'];?>" target="_blank"><?php echo $value['title'];?></a></li>
		<li>BLOG: <?php echo $value['blog_name'];?></li><li><?php echo $value['date'];?></li>
		</ul>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：博客评论列表
function blog_comments($comments){
    extract($comments);
    if($commentStacks): ?>
		<ol class="commentlist">
	<?php
	$isGravatar = Option::get('isgravatar');
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
				<li class="comment even thread-even depth-1" id="comment-<?php echo $comment['cid']; ?>">
		<article id="comment-6851" class="comment">
			<div class="comment-meta">
				<div class="comment-author vcard">
					<?php if($isGravatar == 'y'): ?>
					<img alt='' src='<?php echo getGravatar($comment['mail']); ?>' class='avatar avatar-68 photo' height='68' width='68' /><?php endif; ?>
					<span class="fn"><?php echo $comment['poster']; ?></span> on 
					<a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">
					<time pubdate datetime=""><?php echo $comment['date']; ?></time></a> <span class="says">:</span>
					<small>→ <?php if(function_exists('display_useragent')){display_useragent($comment['cid']);} ?></small>
				</div><!-- .comment-author .vcard -->
			</div>
			<div class="comment-content"><?php echo $comment['content']; ?></div>
			<div class="reply"><a class='comment-reply-link' href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复 <span>&darr;</span></a></div><!-- .reply -->
		</article><!-- #comment-## -->
<?php blog_comments_children($comments, $comment['children']); ?>
</li>
<?php endforeach;?>
</ol>
	<div class="pagenavi"><?php echo $commentPageUrl;?></div>

	<?php else: ?>


	<?php endif; ?>
<?php }?>
<?php
//blog：博客子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
if($children): 	?>

<ul class="children">
<?php
	foreach($children as $child):
	$comment = $comments[$child];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<li class="comment byuser comment-author-RudyAzhar bypostauthor odd alt depth-2" id="comment-<?php echo $comment['cid']; ?>">
		<article id="comment-6852" class="comment">
			<div class="comment-meta">
				<div class="comment-author vcard">
					<?php if($isGravatar == 'y'): ?><img alt='Avatar' src='<?php echo getGravatar($comment['mail']); ?>' class='avatar avatar-39 photo' height='39' width='39' /><?php endif; ?>
					<span class="fn"><?php echo $comment['poster']; ?></span> on 
					<a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)"><time pubdate datetime=""><?php echo $comment['date']; ?></time></a> <span class="says">:</span>
					<small>→ <?php if(function_exists('display_useragent')){display_useragent($comment['cid']);} ?></small>
				</div><!-- .comment-author .vcard -->
			</div>
			<div class="comment-content"><?php echo $comment['content']; ?></div>
			<div class="reply"><a class='comment-reply-link' href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复 <span>&darr;</span></a></div><!-- .reply -->
		</article><!-- #comment-## -->
<?php blog_comments_children($comments, $comment['children']); ?>
</li>
<?php endforeach; ?>
</ul>
	<?php endif; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
<form action="<?php echo BLOG_URL; ?>index.php?action=addcom" method="post" id="commentform">

<div id="respond">
<h3>发表评论</h3>
<div class="cancel-comment-reply" id="cancel-reply" style="display:none">
	<small><a href="javascript:void(0);" onclick="cancelReply()" id="cancel-comment-reply-link">取消回复</a></small>
</div>

<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
<p><label for="comment" class="comment-form-comment"> </label>
<textarea aria-required="true" rows="8" cols="100%" name="comment" id="comment" onkeydown="if(event.ctrlKey){if(event.keyCode==13){document.getElementById('submit').click();return false}};"></textarea></p>



<p class="comment-notes">干净网络从你做起，切勿黏贴小广告: <span class="required">*</span></p>

<p class="comment-form-author">
<label for="author">Name:</label>
<span class="required">*</span><p><input type="text" name="comname" id="author" value="<?php echo $ckname; ?>" size="22"/>
</p>
<p class="comment-form-email">

<label for="email">Email:</label>
<span class="required">*</span><input type="text" name="commail" id="email" value="<?php echo $ckmail; ?>" size="22"/>
</p>
<p class="comment-form-url">
<label for="url">Website:</label><input type="text" name="comurl" id="url" value="<?php echo $ckurl; ?>" size="22"/>

</p>
<p class="form-submit"><input name="submit" type="submit" id="submit" value="提交评论" />
<?php echo $verifyCode; ?>
<input type="hidden" name="pid" id="comment-pid" value="0" />
</p>


	<p style="clear:both;" class="subscribe-to-comments">
	<label for="subscribe">注意：收到回复时将自动发送通知到您邮箱</label>
	</p>

</p>
</div></form>
</div><!-- #comments -->
	<?php endif; ?>

<?php }?>