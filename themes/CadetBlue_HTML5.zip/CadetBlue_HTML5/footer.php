<?php 
/*
* 底部信息
*
**************** Qzz 在此恳请各位博主不要删除我的链接 ****************
**************** 如有需求,欢迎大家到我博客相互交换友链 ****************
**************** 一直努力免费为大家制作模板,希望大家喜欢! ****************
*
*
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div class="copyright">

	<p>&copy; <?php echo $blogname; ?> | <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?> | <a href="http://www.qzee.net">Theme by Qzz</a></p>

</div>

  	</footer>
</div><!-- #page -->

<!-- Grab Google CDN's jQuery. Fall back to local if necessary -->


<script type="text/javascript">

$(document).ready(function(){

	$(".sliding").click(function(){

		$("#slidingDiv").slideToggle("slow");

		$(this).toggleClass("active"); return false;

	});

});

</script>

<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>newStyle/form/jquery.form.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {
	loaderUrl: "<?php echo TEMPLATE_URL; ?>newStyle/images/ajax-loader.gif",
	sending: "Sending ..."
};
/* ]]> */
</script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>newStyle/form/scripts.js'></script>
<style>#buzr {position:absolute;overflow:auto;height:0;width:0;}</style><font id="buzr"><a></a></font>
<?php doAction('index_footer'); ?></body>
</html>
