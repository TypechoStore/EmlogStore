<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}?>
		<div id="main">
		<div id="primary">
			<div id="content">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<!-- 博客list内容模块开始 -->
	<article class="post-7518 post type-post status-publish format-standard hentry category-blogging tag-blogging tag-personal" role="article"><div class="home">

		<header class="entry-header">

<div class="comments-link">
<a href="<?php echo $value['log_url']; ?>#comments"><?php if(($value['comnum'])==0): ?><?php echo $value['views']; ?>次点击 <? else: ?>本文已有<?php echo $value['comnum']; ?>回复<?php endif;?></a></div>
<div id="tanggal"><p><?php echo gmdate('j', $value['date']); ?> <b><?php echo gmdate('M', $value['date']); ?></b> <?php echo gmdate('Y', $value['date']); ?></p></div>

			<h1 class="entry-title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h1>

		</header><!-- .entry-header -->



				<div class="entry-content">

			<p><?php echo $value['log_description']; ?><br />
 <a href="<?php echo $value['log_url']; ?>" class="more-link"><span class="more">继续阅读更多 &rarr;</span></a></p>
					</div><!-- .entry-content -->

		

		<div class="entry-meta">

			<span class="cat-links"><?php blog_sort($value['logid']); ?></span>

					</div><!-- #entry-meta --></div>

	</article><!-- #post end -->

<!-- 博客list内容模块结束 -->
<?php endforeach; ?>
<div class='pagenavi'><?php echo $page_url;?></div>
			</div><!-- #content -->
		</div><!-- #primary -->
	</div><!-- #main  -->
<? include View::getView('side');include View::getView('footer');?>