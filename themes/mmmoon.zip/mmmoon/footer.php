<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<hr/>
<footer>
  <div id="footerA">
    <p><span class="alignright">Copyright &copy;2012 <a target="_blank" rel="nofollow" href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>" rel="home"><?php echo $blogname; ?></a> - <a href="<?php echo BLOG_URL; ?>rss.php">RSS Feed</a></span>
    Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> - mmmoon theme.Designed by <a target="_blank" href="http://xuui.net/">Xu.hel</a> .Modified by <a target="_blank" href="http://www.imevlos.com/">Са[Evlos]</a>. 移植 by <a href="http://lixox.net" target="_blank">ooxx</a>.
    </p>
  </div>
</footer>
<!--/div-->
<?php doAction('index_footer'); ?></div></div>
</body>
</html>