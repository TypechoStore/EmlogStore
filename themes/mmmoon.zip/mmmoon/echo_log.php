<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<article>
  <section  class="post hentry">
   	<div class="title">
      <h2><?php echo $log_title; ?></h2>
      <small><?php echo gmdate('m.d.Y', $date); ?>, <?php blog_sort($logid); ?>, by <?php blog_author($author); ?>.<?php editflg($logid,$author); ?></small>
    </div>
    <div class="entry">
    	<?php echo $log_content; ?><div style="clear:both;"></div>
    </div>
    <div class="post-meta">
			Tags: <?php blog_tag($logid); ?><div class="clear"></div>
    </div>
    <nav class="post-nav">
    	<?php neighbor_log($neighborLog); ?>
    	<div class="clear"></div>
  	</nav>
  </section>
 	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</article>
<?php
 include View::getView('side');
?>
<div class="clear"></div>
</div>
<?php
 include View::getView('footer');
?>