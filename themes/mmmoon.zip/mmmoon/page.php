<?php 
/*
* �Խ�ҳ��ģ��
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<article>
  <section  class="post hentry">
   	<div class="title">
      <h2><?php echo $log_title; ?></h2>
    </div>
    <div class="entry">
    	<?php echo $log_content; ?><div style="clear:both;"></div>
    </div>
  </section>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</article>
<?php
 include View::getView('side');
?>
<div class="clear"></div>
</div>
<?php
 include View::getView('footer');
?>