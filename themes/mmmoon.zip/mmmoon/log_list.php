<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<article>
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
  <section class="post hentry">
   	<div class="title">
      <h2><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
      <small><?php echo gmdate('m.d.Y', $value['date']); ?>, <a href="<?php echo $value['log_url']; ?>#comments" class="CommentsNumber"><?php if($value['comnum']==0){echo '抢沙发';}elseif($value['comnum']==1){echo '1条评论';}else{echo $value['comnum'].' 条评论';} ?></a>, <?php blog_sort($value['logid']); ?>, by <?php blog_author($value['author']); ?>, <?php echo $value['views']; ?>人围观.<?php editflg($value['logid'],$value['author']); ?></small>
    </div>
    <div class="entry">
    	<?php echo $value['log_description']; ?><div style="clear:both;"></div>
    </div>
    <div class="post-meta">
			Tags: <?php blog_tag($value['logid']); ?><div class="clear"></div>
    </div>
  </section>
  <?php endforeach; ?>
  <nav class="navigation">
  <div class="ilost-pagenav">
  	<?php echo $page_url;?>
  </div>
  </nav>
</article>
<?php include View::getView('side');?>
<div class="clear"></div>
</div>
<?php include View::getView('footer');?>