<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
 include View::getView('side');
?>
<div id="center_box">
		<div id="container">
			<?php foreach($logs as $value): ?>
					<div class="post">
						<div class="entry">
							<div class="index">
								<div class="time">
									<span class="top"><?php echo gmdate('Y', $value['date']); ?></span>
									<span class="top">read</span>
									<span class="bottom"><?php echo gmdate('n-j', $value['date']); ?></span>
									<span class="bottom"><?php echo $value['views']; ?></span>
								</div>
								<h2><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></h2>
								<div class="postmetadata">
									<span><?php blog_sort($logid); ?>&nbsp;&nbsp;&nbsp;</span>
									<span class="post_tag"><?php blog_tag($value['logid']); ?></span>
									<?php editflg($value['logid'],$value['author']); ?>
								</div>
							</div>
							<div class="post_content">
								<div id="thumb">
									<?php $thum_src = getThumbnail($value['logid']);
									if(!empty($thum_src)){ ?>
									<img src="<?php echo $thum_src; ?>" width="150" />
									<?php } else{ ?>
									<img src="<?php echo TEMPLATE_URL; ?>images/thumb.png" />
									<?php } ?>
								</div>
								<?php 
										echo '<span>';
										echo utf8_strcut(Get_Log($value['logid'],'content'), 0, 1);
										echo '</span>';
										echo utf8_strcut(Get_Log($value['logid'],'content'), 1,150);
								?>
								<a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>">【阅读全文】</a>
								<p></p>
							</div>
						</div>
					</div>
			<?php endforeach; ?>
			<div class="navigation">
				<?php echo $page_url;?>
			</div>
			<div class="clear-both"></div>			
		</div>
	</div>
	<div class="clear-both"></div>
<?php
 include View::getView('footer');
?>