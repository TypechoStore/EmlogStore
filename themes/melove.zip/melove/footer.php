<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>
	<div id="footer">
		<div id="footer_bottom">
			<div id="footer-box">
				<div class="about-me">
					<p>ID：LoveSugar(爱冰)<br/>
						QQ：491366030<br/>
						e-mail:liuhaotian0520@163.com<br/>
						@游戏 @动漫 @科技 @编程<br/></p>
				</div>
				<div class="lianjie">
					<h3>other Links</h3>
					<ul>
						<li><a href="<?php echo BLOG_URL; ?>" target="_blank">首页</a></li>
						<li><a href="<?php echo BLOG_URL; ?>sitemap.html" target="_blank">网站地图</a></li>
						<li><p>版权所有&nbsp;&copy;&nbsp;<a href="<?php echo BLOG_URL; ?>" title="<?php echo $site_title; ?>"><?php echo $site_title; ?></a></p></li>
						<li><span>Theme by&nbsp;</span><a href="http://www.melove.net" target="_black">Melove</a>&nbsp;Transplanted By&nbsp;<a href="http://lovesugar.info" target="_black">LoveSugar(爱冰博客)</a></li>
					</ul>
				</div>
			
				<div class="clear-both"></div>
			</div>
			<div class="meilihao"> </div>
			<div class=""> </div>
		</div>
	</div>
	<script type="text/javascript" src="http://lib.sinaapp.com/js/jquery/1.9.0/jquery.min.js"></script>
	<script language="javascript" src="<?php echo TEMPLATE_URL; ?>js/functions.js"></script> 
	<a style="position:absolute;" name="gobottom"></a>
</body>
</html>