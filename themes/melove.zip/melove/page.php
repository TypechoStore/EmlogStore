<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="wrapper">
	<div id="center_box">
		<div id="header">
			<div id="address">
				<img src="<?php echo $log_content; ?>images/post_home.png" width="18" height="18"/>
				<a href="<?php echo BLOG_URL; ?>" title="首页">首页</a>&nbsp;&gt;&nbsp;<a href="#"><?php echo $site_title; ?></a>
			</div>
		</div>
		<div id="container">
				<?php foreach($logs as $value): ?>
					<div class="post"">
						<h2><?php echo $value['log_title']; ?></h2>
						<div class="entry">
							<div class="info">
								<div class="post_content"><?php echo $log_content; ?></div>
							</div>
						</div>
						<div class="comments_template">
							<?php blog_comments($comments); ?>
							<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
						</div>
					</div><!-- post结束 -->
				<?php endwhile;?>
				<div class="navigation">
					<?php echo $page_url;?>
				</div>
		</div><!-- container结束 -->
	</div>
	<div class="clear-both"></div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>