<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
 include View::getView('side');
?>
<div id="center_box">
	<div id="header">
		<div id="address">
			<img src="<?php echo TEMPLATE_URL; ?>images/post_home.png" width="18" height="18">
			<div>
				<a href="<?php echo BLOG_URL; ?>" title="首页">首页</a>&nbsp;&gt;&nbsp;
				<?php blog_sort($logid); ?>&nbsp;&gt;&nbsp;<a href="#"><?php echo $log_title; ?></a>
			</div>
		</div>
	</div>
	<div id="container">
		<div class="post">
			<h2><?php echo $log_title; ?></h2>
			<div class="bg_title"><img src="<?php echo TEMPLATE_URL;?>images/title-bg.png"></div>
			<div class="post_info">
				<img src="<?php echo TEMPLATE_URL; ?>images/post_time.png" width="18" height="18">
				<span><?php echo gmdate('Y-n-j G:i l', $date); ?></span>
				<img src="<?php echo TEMPLATE_URL; ?>images/post_comments.png" width="18" height="18">
				<span>有 <?php echo Get_Log($logid,'comnum')?> 位蛋友轻轻扯了一下</span>
				<img src="<?php echo TEMPLATE_URL; ?>images/post_jiangyou.gif" width="18" height="18">
				<span class="look_number">打酱油的有：<?php echo Get_Log($logid,'views')?></span>
			</div>
			<div class="entry">
				<div class="post-content" style="text-indent:2em">
					<?php echo $log_content; ?>
				</div>
			</div>
			<div class="postnextorprevious">
				<span class="post-previous"><?php neighbor_log($neighborLog); ?></span>
				<div class="clear-both"></div>
			</div>
			<div class="include_meinfo">
				<div class="meinfo">
					<img src="<?php echo TEMPLATE_URL; ?>images/lz-150x150.png" width="60" height="60">
					<p> 
						<span>订阅本站：</span><a href="http://lovesugar.info/rss.php" target="_blank">爱冰博客</a><br>
						<?php blog_tag($logid); ?><br>
						<span>发表日期：</span><span><?php echo gmdate('Y-n-j G:i l', $date); ?></span><br>
						<span>浏览热度：</span><span>已有 <?php echo Get_Log($logid,'views')?> 基友提着酱油瓶淡定的路过……</span><br>
						<span>本文地址：</span><span><a rel="more-link" href="<?php echo BLOG_URL.'?post='.$logid?>" title="<?php echo $log_title; ?>"><?php echo BLOG_URL.'?post='.$logid?></a></span><br>
						<span>特別注明：</span><span>部分原创-自由转载-不得商用-注名出处：<a href="http://lovesugar.info" target="_blank">爱冰博客</a><br> 
						<span>　　　　　</span><span>部分内容为抄录转载分享，如果有侵犯原作者权益行为请通知我，会及时处理删除！</span>
						</span>
					</p>
					<div class="clear-both"></div>
				</div>
			</div>
			<div class="comments_template">
				<h4 id="comment-title">
					<a name="gocomments"></a>
				有蛋友想要轻轻扯一下！</h4>
				<?php blog_comments($comments); ?>
				<div class="comments-navigation">
					<div class="alignleft"></div>
					<div class="alignright"></div>
				</div>
				<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
			</div>
			</div>
	</div>
</div>
<div class="clear-both"></div>
<?php
 include View::getView('footer');
?>