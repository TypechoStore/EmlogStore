

var result=new Array();

//验证码
function code(n){
	//定义一个字符串，
	var s="abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	var c="";
	var yzm="";	
		//循环得到字符,并转化为图片
		for(var j=0;j<n;j++){
			var y=s.charAt(parseInt(Math.random()*62));//得到产生的随机字符
			c+=""+y;
			yzm+='<img src="../img/code_img/'+y+'.gif" alt+=""+y />';
		}
		result[0]=yzm;
		result[1]=c;
}
function show(n){
	//将得到的随机字符输入到id为code_img的中去
	code(n);
	document.getElementById("code_img").innerHTML=result[0];
}
//验证码比较
function bj(){
	var code_Lower=document.login.code.value.toLowerCase();//获得输入的验证码,把输入的验证码转化为小写!
	if(code_Lower==""){
		alert("请输入验证码！");
		return false;
	}else if(code_Lower==result[1].toLowerCase()){//让输入的验证码与随机产生的验证码进行比较！
			document.getElementById("codeError").innerHTML="  验证码输入正确！";
			document.getElementById("codeError").style.color="#00ff00";
			return true;
		}else{
			document.getElementById("codeError").innerHTML="  验证码输入错误！请重新输入！";
			document.getElementById("codeError").style.color="#ff0000";
			return false;
		}
}



//邮箱验证！
function codeEmail(){
	var reg=/^\w+@\w+\.\w+/;
	var emailvalue=document.login.email.value;
	if(emailvalue.match(reg)!=null){
		document.getElementById("code_email").innerHTML="邮箱地址合法！"
		document.getElementById("code_email").style.color="#0f0";
		return true;
		}else{
			alert("邮箱地址不合法；必须包含@和.!");
			return false;
			}
	}


	
//提交留言的复合方法，只有同时成立才提交
function sb(){
	if(codeEmail()&&bj()){
		if(addData()){
			return true;
			}else{
				return false;
				}
		}else{
			return false;
			}
	}
//本地数据库，IE不支持本地数据库！
var db;
if(window.openDatabase){
	//创建数据库
	db=openDatabase("db","1.0","test db",5000);
	//创建表
	db.transaction(function(tx){
		tx.executeSql("create table leaveword(name char(10),email varchar(50),text varchar(500))");
		})
}
function addData(){
	//获得user和pass和email的值
	
	var name=document.login.name.value;
	var email=document.login.email.value;
	var text=document.login.text1.value;
	if(text==""){
		alert("留言内容不能为空，请留言！");
		return false;
		return;
		}
	db.transaction(function(tx){
		//插入name和pass和eamil的值
		tx.executeSql("insert into leaveword values(?,?,?)",[name,email,text]);
		alert("留言成功,请刷新页面进行查看！");
		window.open('lxly.html','lxly');
		})
	}

function clearData(){
	if(confirm("确定要删除么？删除后将不能找回以前的留言！！")){
	db.transaction(function(tx){
		//清除本地数据库创建的leaveword的表的数据
		tx.executeSql("delete from  leaveword");
	})}
}

	
function showSql(){
	//显示前让leave为空
	document.getElementById("leaveword").innerHTML="";
		db.transaction(function(tx){
			tx.executeSql("select * from leaveword",[],function(tx,rs){
				if(rs.rows.length==0){
					document.getElementById("latelyUser").innerHTML="<h2>现在还没有人来！</h2>";
					document.getElementById("leaveword").innerHTML="<P>太冷清了，还没有人留言哦！</p>";
					}
			for(var i=0;i<rs.rows.length;i++){
				//显示本地数据库存储的数据
				//把插入的图片的表情符转换成表情图片的路径！
				testImg=rs.rows.item(i).text.replace(/\[∩_∩\]/g,"<img src='../img/faceimg/0.gif'>");
				testImg=testImg.replace(/\[u_u\]/g,"<img src='../img/faceimg/1.gif'>");
				testImg=testImg.replace(/\[-_-!\]/g,"<img src='../img/faceimg/2.gif'>");
				testImg=testImg.replace(/\[↓_↓\]/g,"<img src='../img/faceimg/3.gif'>");
				testImg=testImg.replace(/\[¬.¬\]/g,"<img src='../img/faceimg/4.gif'>");
				testImg=testImg.replace(/\[↑_↑\]/g,"<img src='../img/faceimg/5.gif'>");
				testImg=testImg.replace(/\[↓_↓\]/g,"<img src='../img/faceimg/6.gif'>");
				testImg=testImg.replace(/\[❀❀\]/g,"<img src='../img/faceimg/7.gif'>");
				testImg=testImg.replace(/\[♨\]/g,"<img src='../img/faceimg/8.gif'>");
				testImg=testImg.replace(/\[¯¬¯\]/g,"<img src='../img/faceimg/9.gif'>");
				
				/*var arr=new Array("[∩_∩]","[+_+]","[-_-!]","[↓_↓]","[¬.¬]","[㊣↑]","[↓_↓]","[❀❀]","[♨]","[¯¬¯]");
				var testImg;
				var j=0;
				for(j=0;j<arr.length;j++){
					testImg=rs.rows.item(i).text.replace(arr[j],"<img src='../img/faceimg/j.gif'>");
				}*/
				
				if(rs.rows.item(i).name==""){
					document.getElementById("latelyUser").innerHTML+="<h2>"+"匿名用户"+"<span>当前时间</span></h2>";
					document.getElementById("leaveword").innerHTML+="<div><h2>"+"匿名用户"+":<span>当前时间</span></h2>"+"<p>"+testImg+"<a href='#' onclick='clearData()'>删除</a></p></div>";
					}else{
						document.getElementById("latelyUser").innerHTML+="<h2>"+rs.rows.item(i).name+"<span>当前时间</span></h2>";
						document.getElementById("leaveword").innerHTML+="<div><h2>"+rs.rows.item(i).name+":<span>当前时间</span></h2>"+"<p>"+testImg+"<a href='#' onclick='clearData()'>删除</a></p></div>";
					}
				
				}
			})
		})
	}