function load(){
	/*
	假如你已经设置了一个submit的ID，如：<input type=”submit” id=”sub_id” />
	/* 设置为不可用 
	$("#sub_id").attr("disabled","disabled");
	/* 设置为可用 
	$("#sub_id").removeAttr("disabled");
 */
var submit_state = false;
$(function(){
	var handle = $(".draghandle");
	var dragbar = $(".dragbar");
	var dragmsgstate = $(".dragmsgstate");
	handle.css({"width":"45px","top":"0px","left":"0px"});
	var maxlen=parseInt(dragbar.width())-parseInt(handle.outerWidth());
	$(".draghandle").mousedown(function(e){
		var mouseX = e.pageX;
		
		var handleX = parseInt(handle.offset().left) - parseInt(dragbar.offset().left);

		$(document).bind("mousemove",function(e){
			var left = e.pageX - mouseX + handleX <0 ? 0 : (e.pageX - mouseX + handleX >= maxlen ? maxlen : e.pageX - mouseX + handleX);
			handle.css({left:left,top:"0px"});
			if(left == maxlen){
				$(".dragmsgtext").text("OK!");
				dragmsgstate.css({"background-position":"-16px 0px"});
				submit_state = true;
				sub();
			}else{
				$(".dragmsgtext").text("请解锁后提交评论！");
				dragmsgstate.css({"background-position":"0px 0px"});
				submit_state = false;
				sub();
			}

		  percent=(left/maxlen*100).toFixed(0);
		  return false;
		});
		$(document).bind("mouseup",function(){
			$(this).unbind("mousemove");
		});
	});
	function sub(){
		if(submit_state){
			//设置为可用 
			document.getElementById("submit").type="submit";
			document.getElementById("submit").value="提交（Ctrl+Enter）";
		}else{
			document.getElementById("submit").type="button";
			document.getElementById("submit").value="请解锁后提交评论！";
		}
	}
	
});

/*---------------为标签添加文章数目----------------*/
jQuery(document).ready(function($){
    ////////TAG Cloud里面显示“每标签的文章数” by zwwooooo
    $('#my-tags a').each(function(){
        var num=$(this).attr('title').split(' ')[0]; //获取标签里面的title值
        var a=$(this).html()+' <span class="tag_num">'+num+'</span>'; //然后是标签的名插入此标签的文章数
        $(this).html(a); //最后是改变标签名
    });
})
}