<?php
/*
Template Name:ublog-black
Description:ublog系列black模板，黑色简明大气，适合做博客模板，移植于WP的problog……
Version:1.0
Author:viLuo
Author Url:http://viluo.com
Sidebar Amount:1
ForEmlog:4.1.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>css/uquwu.css" rel="stylesheet" type="text/css" />
<script src="<?php echo TEMPLATE_URL; ?>script/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>script/theme_script.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="header">
	<div class="mbox">
		<div id="tide">
			<h1>
				<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a><span><?php echo $bloginfo; ?></span>
			</h1>
		</div>

		<div id="h_serch">
			<form name="keyform" method="get" id="searchform" class="search"
				action="<?php echo BLOG_URL; ?>index.php">
				<input type="text" name="keyword" class="keyword"
					onblur="if(this.value =='')this.value='Search...and Enter';"
					onfocus="this.value='';"
					onclick="if(this.value=='Search...and Enter')this.value=''"
					value="Search...and Enter" />
				<input type="submit" name="submit" value="搜寻" class="submit" />
			</form>
		</div>
		<div id="navi">
			<?php blog_navi();?>
		</div>
	</div>
</div>
<div id="container">
<div id="t_box" class="cbx">
	<div id="welcome">
		<?php
			global $CACHE; 
			$newtws_cache = $CACHE->readCache('newtw');
			$istwitter = Option::get('istwitter');
		?>
		<?php foreach($newtws_cache as $value): ?>
		<li>
			<a href="<?php echo BLOG_URL . 't/'; ?>"><?php echo substr($value['t'],0,100); ?></a>
		</li>
		<?php endforeach; ?>
	</div>
	<script>
		var c, _ = Function;
		with( o = document.getElementById("welcome")) {
			innerHTML += innerHTML;
			onmouseover = _("c=1");
			onmouseout = _("c=0");
		}( F = _("if(#%27||!c)#++,#%=o.scrollHeight>>1;setTimeout(F,#%27?10:5000);".replace(/#/g, "o.scrollTop")))();
	</script>
	<div id="t_share">
		<a href="<?php echo BLOG_URL; ?>rss.php" target="_blank">订阅 RSS
			Feed</a>
	</div>
	<div class="clear"></div>
</div>