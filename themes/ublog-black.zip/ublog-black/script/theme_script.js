var $ = jQuery.noConflict();
var x = 1;
$(document).ready(function(e) {
	$('.post').hover(function() {
		$(this).find('.readmorea').fadeIn('fast')
	}, function() {
		$(this).find('.readmorea').fadeOut('fast')
	});
	$("#footer .mbox .gotop").click(function() {
		$body.animate({
			scrollTop : 0
		}, 1000)
	});
	var cur = $("#navi").find(".current");
	if(cur.length == 0){
		$($("#navi").find("a")[0]).addClass("current");
	}
	// setInterval(scrollTag, 10000);
});
function scrollTag() {

	if (x < 3) {
		x = x + 1
	} else
		x = 1;
	$("#menu" + x).click();
}

function setTab(cursel, n) {
	for (i = 1; i <= n; i++) {
		if (i == cursel) {
			$("#con_" + i).slideDown();
		} else {
			$("#con_" + i).slideUp();
		}
	}
}
(function() {
	var special = jQuery.event.special, uid1 = 'D' + (+new Date()), uid2 = 'D'
			+ (+new Date() + 1);
	special.scrollstart = {
		setup : function() {
			var timer, handler = function(evt) {
				var _self = this, _args = arguments;
				if (timer) {
					clearTimeout(timer);
				} else {
					evt.type = 'scrollstart';
					jQuery.event.handle.apply(_self, _args);
				}
				timer = setTimeout(function() {
					timer = null;
				}, special.scrollstop.latency);
			};
			jQuery(this).bind('scroll', handler).data(uid1, handler);
		},
		teardown : function() {
			jQuery(this).unbind('scroll', jQuery(this).data(uid1));
		}
	};
	special.scrollstop = {
		latency : 300,
		setup : function() {
			var timer, handler = function(evt) {
				var _self = this, _args = arguments;
				if (timer) {
					clearTimeout(timer);
				}
				timer = setTimeout(function() {
					timer = null;
					evt.type = 'scrollstop';
					jQuery.event.handle.apply(_self, _args);
				}, special.scrollstop.latency);
			};
			jQuery(this).bind('scroll', handler).data(uid2, handler);
		},
		teardown : function() {
			jQuery(this).unbind('scroll', jQuery(this).data(uid2));
		}
	};
})();
jQuery(document).ready(function($) {
	$body = (window.opera) ? (document.compatMode == "CSS1Compat"
			? $('html')
			: $('body')) : $('html,body');
	$('.searchbarswitch').toggle(function() {
		$(".searchbar").animate({
			marginTop : "15px"
		}, "slow")
		$(".searchfade").fadeIn("slow");
	}, function() {
		$(".searchbar").animate({
			marginTop : "0px"
		}, "slow")
		$(".searchfade").fadeOut("slow");
	});
	$("#sidebar li.widget ul.two_row li").hover(function() {
		$(this).find('ul:first').slideDown(200);
	}, function() {
		$(this).find('ul:first').slideUp(200)
	});
	$("#accordion a").hover(function() {
		$(this).stop().animate({
			left : "10px"
		}, 200);
		$(this).next().stop().animate({
			right : "10px",
			opacity : '1'
		}, 200);
	}, function() {
		$(this).stop().animate({
			left : "0px"
		}, 200);
		$(this).next().stop().animate({
			right : "0px",
			opacity : '0'
		}, 200);
	});
	$("#sidebar-avatar a").hover(function() {
		$(this).stop().animate({
			left : "0px"
		}, 200);
		$(this).next().stop().animate({
			right : "-9px",
			opacity : '1'
		}, 200);
	}, function() {
		$(this).stop().animate({
			left : "0px"
		}, 200);
		$(this).next().stop().animate({
			right : "-20px",
			opacity : '0'
		}, 200);
	});
	$(".post-content a:has(img)").css("border", "none");
	$(".post-content a:has(img)").hover(function() {
		$(this).css("background", "none");
	}, function() {
		$(this).css("background", "none");
	});
	$("nav .feedrss").hover(function() {
		$(this).animate({
			opacity : '1'
		}, 200)
	}, function() {
		$(this).animate({
			opacity : '0'
		}, 200)
	});
	$(".singleshare a").click(function() {
		$(".sharebar").toggle(400);
	});
	$(".singlerelate").click(function() {
		$(".sharebar").hide(400);
		$(".relatebar").toggle(400);
	});
	$(".singleshare").click(function() {
		$(".relatebar").hide(400);
	});
	function getParamsOfShareWindow(width, height) {
		return [
				'toolbar=0,status=0,resizable=1,width=' + width + ',height='
						+ height + ',left=', (screen.width - width) / 2,
				',top=', (screen.height - height) / 2].join('');
	}
	function bindShareList() {
		var link = encodeURIComponent(document.location);
		var title = encodeURIComponent(document.title.substring(0, 76));
		var source = encodeURIComponent('网站名称');
		var windowName = 'share';
		var site = 'http://www.example.com/';
		jQuery('#twitter-share').click(function() {
			var url = 'http://twitter.com/share?url=' + link + '&text=' + title;
			var params = getParamsOfShareWindow(500, 375);
			window.open(url, windowName, params);
		});
		jQuery('#kaixin001-share').click(function() {
			var url = 'http://www.kaixin001.com/repaste/share.php?rurl=' + link
					+ '&rcontent=' + link + '&rtitle=' + title;
			var params = getParamsOfShareWindow(540, 342);
			window.open(url, windowName, params);
		});
		jQuery('#renren-share').click(function() {
			var url = 'http://share.renren.com/share/buttonshare?link=' + link
					+ '&title=' + title;
			var params = getParamsOfShareWindow(626, 436);
			window.open(url, windowName, params);
		});
		jQuery('#douban-share').click(function() {
			var url = 'http://www.douban.com/recommend/?url=' + link
					+ '&title=' + title;
			var params = getParamsOfShareWindow(450, 350);
			window.open(url, windowName, params);
		});
		jQuery('#fanfou-share').click(function() {
			var url = 'http://fanfou.com/sharer?u=' + link + '?t=' + title;
			var params = getParamsOfShareWindow(600, 400);
			window.open(url, windowName, params);
		});
		jQuery('#sina-share').click(function() {
			var url = 'http://v.t.sina.com.cn/share/share.php?url=' + link
					+ '&title=' + title;
			var params = getParamsOfShareWindow(607, 523);
			window.open(url, windowName, params);
		});
		jQuery('#tencent-share').click(function() {
			var url = 'http://v.t.qq.com/share/share.php?title=' + title
					+ '&url=' + link + '&site=' + site;
			var params = getParamsOfShareWindow(634, 668);
			window.open(url, windowName, params);
		});
	}
	bindShareList();
	$(document).bind("mousewheel", function(e) {
		$body.stop()
	});
	$(".pingpart").click(function() {
		$(this).css({
			color : "#222"
		});
		$(".commentshow").hide(400);
		$(".pingtlist").show(400);
		$(".pingparttri").animate({
			opacity : '1'
		}, 200);
		$(".commentparttri").animate({
			opacity : '0'
		}, 200);
		$(".commentpart").css({
			color : "#999"
		});
			/*
			 * $body.animate({ scrollTop : $('#comments').offset().top }, 600,
			 * "easeOutExpo");
			 */
		});
	$(".commentpart").click(function() {
		$(this).css({
			color : "#222"
		});
		$(".pingtlist").hide(400);
		$(".commentshow").show(400);
		$(".commentparttri").animate({
			opacity : '1'
		}, 200);
		$(".pingparttri").animate({
			opacity : '0'
		}, 200);
		$(".pingpart").css({
			color : "#999"
		});
			/*
			 * $body.animate({ scrollTop : $('#comments').offset().top }, 600,
			 * "easeOutExpo");
			 */
		});
	$(".commenttext").hover(function() {
		$(this).find(".reply").fadeIn(0);
	}, function() {
		$(this).find(".reply").fadeOut(0);
	});
	$(".tw-text").hover(function() {
		$(this).find(".reply").fadeIn(0);
	}, function() {
		$(this).find(".reply").fadeOut(0);
	});
	$(".reply").click(function() {
		/*$body.animate({
			scrollTop : $(this).prevUntil(".commenttext").offset().top
		}, 1000).animate({
			scrollTop : $('#respond').offset().top
		}, 1500);
		var atid = '"#'
				+ $(this).parent().parent().parent().parent().attr("id") + '"';
		var atname = $(this).parent().parent().find(".commentid").text().trim();
		$("#comment").attr("value", "<a href=" + atid + ">@" + atname + "</a>:").focus();*/
		$("#comment").focus();
	});
	$('#cancel-comment-reply').click(function() {
		$("#comment").attr("value", '');
	});
	var id = /^#comment-/;
	var at = /^@/;
	$('.commentp p a').each(function() {
		if ($(this).attr('href').match(id) && $(this).text().match(at)) {
			$(this).addClass('atreply');
		}
	});
	$('.atreply').hover(function() {
		$($(this).attr('href')).find('div:first').clone().hide()
				.insertAfter($(this).parents('li')).attr('id', '')
				.addClass('tip').fadeIn(200);
	}, function() {
		$('.tip').fadeOut(400, function() {
			$(this).remove();
		});
	});
	$('.atreply').mousemove(function(e) {
		$('.tip').css({
			left : (e.clientX - 160),
			top : (e.pageY - 100)
		})
	});
	$("#respond input#submit").mouseover(function() {
		$(this).addClass('submitfocus').removeClass('submitstyle');
	}), $("#respond input#submit").mouseleave(function() {
		$(this).removeClass('submitfocus').addClass('submitstyle')
	});
	$('div.archivelist ul').hide();
	$('div.archivelist ul:first').show();
	$('div.archivelist:eq(0)> h3').click(function() {
		$(this).next().slideToggle(500);
	});
	jQuery.each(jQuery.browser, function(i) {
		if ($.browser.msie) {
			$('.arc-collapse').toggle(function() {
				$(this).text("折叠所有月份");
				$('div.archivelist ul').slideDown(500);
			}, function() {
				$(this).text("展开所有月份");
				$('div.archivelist ul').slideUp(500);
			});
		} else {
			$('.arc-collapse').toggle(function() {
				$(this).text("折叠所有月份");
				$('div.archivelist ul').show(500);
			}, function() {
				$(this).text("展开所有月份");
				$('div.archivelist ul').hide(500);
			});
		};
		if ($.browser.opera) {
			$(".footerwidgitswitch").css({
				display : 'none'
			})
		}
	});
	$(".link-content ul li a").each(function(e) {
		$(this).prepend("<img src=http://www.google.com/s2/favicons?domain="
				+ this.href.replace(/^(http:\/\/[^\/]+).*$/, '$1').replace(
						'http://', '') + " style=float:left;></img>");
	});
	$('.link-content ul li a').attr({
		target : "_blank"
	});
	$(".footerwidgit ul li:last-child").css({
		border : 'none'
	})
	$('.footerwidgitswitch').toggle(function() {
		$(this).removeClass("footerwidgitswitch")
				.addClass("footerwidgitswitchdown");
		$('.footerwidgitopen').slideDown(500);
		$body.animate({
			scrollTop : $('.footertop').offset().top
		}, 700)
	}, function() {
		$(this).removeClass("footerwidgitswitchdown")
				.addClass("footerwidgitswitch");
		$('.footerwidgitopen').slideUp(500);
	});
	var $elem = $('.layout');
	$('#updown').fadeIn('slow');
	$(window).bind('scrollstart', function() {
		$('#updown').stop().animate({
			'opacity' : '0.1'
		});
	});
	$(window).bind('scrollstop', function() {
		$('#updown').stop().animate({
			'opacity' : '1'
		});
	});
	$('.loperdownwards').click(function(e) {
		$body.animate({
			scrollTop : $elem.height()
		}, 1200, "easeOutExpo");
	});
	$('.loperupwards').click(function(e) {
		$body.animate({
			scrollTop : '0px'
		}, 1200, "easeOutExpo");
	});
});

addComment = {
	moveForm : function(commId, parentId, respondId, postId, num) {
		var t = this, div, comm = t.I(commId), respond = t.I(respondId), cancel = t
				.I('cancel-comment-reply-link'), parent = t.I('comment_parent'), post = t
				.I('comment_post_ID');
		num
				? (t.I('comment').value = comm_array[num], edit = t
						.I('new_comm_' + num).innerHTML
						.match(/(comment-)(\d+)/)[2], $new_sucs = $('#success_'
						+ num), $new_sucs.hide(), $new_comm = $('#new_comm_'
						+ num), $new_comm.hide(), $cancel.text(cancel_edit))
				: $cancel.text(cancel_text);
		t.respondId = respondId;
		postId = postId || false;
		if (!t.I('wp-temp-form-div')) {
			div = document.createElement('div');
			div.id = 'wp-temp-form-div';
			div.style.display = 'none';
			respond.parentNode.insertBefore(div, respond)
		}
		!comm
				? (temp = t.I('wp-temp-form-div'), t.I('comment_parent').value = '0', temp.parentNode
						.insertBefore(respond, temp), temp.parentNode
						.removeChild(temp))
				: comm.parentNode.insertBefore(respond, comm.nextSibling);
		$body.animate({
			scrollTop : $('#respond').offset().top - 180
		}, 400);
		if (post && postId)
			post.value = postId;
		parent.value = parentId;
		cancel.style.display = '';
		cancel.onclick = function() {
			var t = addComment, temp = t.I('wp-temp-form-div'), respond = t
					.I(t.respondId);
			t.I('comment_parent').value = '0';
			if (temp && respond) {
				temp.parentNode.insertBefore(respond, temp);
				temp.parentNode.removeChild(temp);
			}
			this.style.display = 'none';
			this.onclick = null;
			return false;
		};
		try {
			t.I('comment').focus();
		} catch (e) {
		}
		return false;
	},
	I : function(e) {
		return document.getElementById(e);
	}
}; // end addComment
