<?php 
/*
* 日志阅读部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<span id="log_space">
	<a href="tencent://message/?uin=1545019690&Site=www.dyuee.com&Menu=yes" title="联系QQ">联系QQ</a>
	<a href="mailto:fisheatfox@gmail.com" title="来信投稿">来信投稿</a>
	<a href="javascript:window.open('<?php echo BLOG_URL; ?>rss.php')" title="订阅RSS">订阅RSS</a>
</span>
<div id="templatemo_content_wrapper">
	<div id="templatemo_content">
        <div id="page-view"><?php echo $log_content; ?></div>
        <?php blog_comments($comments); ?>
        <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    </div><!-- end of content -->
    <?php
 include View::getView('side');
 include View::getView('footer');
?>