<?php 
/*
* 日志阅读部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<span id="log_space">
	<a href="javascript:turnbig()"  title="字体增大">字体增大</a>
	<a href="javascript:turnsmall()" title="字体减小">字体减小</a>
	<a href="tencent://message/?uin=1545019690&Site=www.dyuee.com&Menu=yes" title="联系QQ">联系QQ</a>
	<a href="mailto:fisheatfox@gmail.com" title="来信投稿">来信投稿</a>
	<a href="javascript:window.open('<?php echo BLOG_URL; ?>rss.php')" title="订阅RSS">订阅RSS</a>
</span>
<div id="templatemo_content_wrapper">

	<div id="templatemo_content">
        <div class="cleaner">
        </div>
		<article>
        <h2><?php echo $log_title; ?></h2>
        <div id="content"><?php echo $log_content; ?></div>
        <div><div class="cleaner"></div>
                   <div class="log_tag"><span class="tag"><?php blog_tag($logid); ?></span></div>
                   <div class="log_date"><span id="log_date">
                   浏览<?php echo $views; ?>&nbsp;
                   评论<?php echo $comnum; ?>&nbsp;
                   <?php blog_author($author); ?>于
                   <?php echo gmdate('Y-n-j G:i', $date); ?></span></div>
        </div>
        <div><div class="cleaner"></div>
             <div class="log_sort"><?php blog_sort($logid); ?></div>
             <div class="last_next"><?php neighbor_log($neighborLog); ?></div>
        </div><div class="cleaner"></div>
		</article>
        <div id="article_hr">
        	<input id="AddFavorite" onmouseover="this.title='点击一下收藏本页'" name="favorite" onclick="window.external.AddFavorite(location.href,document.title);" type="button" />
        </div>
        <?php blog_comments($comments); ?>
        <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    </div><!-- end of content -->
    <?php
 include View::getView('side');
 include View::getView('footer');
?>