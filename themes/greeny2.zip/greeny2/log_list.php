<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<span id="log_space">
	<a href="tencent://message/?uin=1545019690&Site=www.dyuee.com&Menu=yes" title="联系QQ">联系QQ</a>
	<a href="mailto:fisheatfox@gmail.com" title="来信投稿">来信投稿</a>
	<a href="javascript:window.open('<?php echo BLOG_URL; ?>rss.php')" title="订阅RSS">订阅RSS</a>
</span>
<div id="templatemo_content_wrapper">
  <div id="templatemo_content">
    <?php doAction('index_loglist_top'); ?>
    <?php foreach($logs as $value): ?>
    <div class="cleaner"> </div>
	<article><div class="list-box">
    <h2><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
    <p class="em_text"><?php echo $value['log_description']; ?></p>
    <div id="blog_date">
    <?php blog_author($value['author']); ?>于<?php echo gmdate('Y-n-j G:i l', $value['date']); ?>&nbsp; 
    已有<?php echo $value['views']; ?>次浏览 
    <?php echo $value['comnum']; ?>条评论
    </div>
    	    <div class="cleaner"> </div>
  </div></article>
    <?php endforeach; ?>
  <div class="cleaner"> </div>
  <div class="page-code">
    <?php echo $page_url;?>
  </div>
  </div>

<!-- end of content -->
<?php
 include View::getView('side');
 include View::getView('footer');
?>
