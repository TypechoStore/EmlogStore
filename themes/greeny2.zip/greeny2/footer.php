﻿<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>
</section>
<footer>
<div id="templatemo_content_wrapper_bottom"></div>
<?php doAction('index_footer'); ?>
<!-- end of content_wrapper -->
<div id="templatemo_footer">
<?php echo $icp; ?>
<p align="center">欢迎使用 &copy; <a href="http://www.emlog.net" target="_blank">emlog</a> <?php echo $footer_info; ?></p>
<?php doAction('index_footer'); ?>
</div>
</footer>
<!-- Baidu Button BEGIN -->
<script type="text/javascript" id="bdshare_js" data="type=slide&img=5&uid=6446137" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
	document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + new Date().getHours();
</script>
<!-- Baidu Button END -->
</body>
</html>