<?php
/*
Template Name:新绿2.0
Description:清爽绿色，需html5支持。
Version:2.00
Author:北宫嬛
Author Url:http://www.dyuee.com
Sidebar Amount:1
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>

<body>

<div id="templatemo_header_wrapper">

	<div id="templatemo_header">
    <header>
   		<div id="site_title">
            <h1><a href="<?php echo BLOG_URL; ?>" title="北宫嬛的祈雨其雨"><?php echo $blogname; ?></a></h1>
            <p><span><?php echo $bloginfo; ?></span></p>
        </div>
    </header><nav>
         <div id="templatemo_menu">
            <?php blog_navi();?>
        </div></nav> <!-- end of templatemo_menu -->
        
        <div id="search_box">
                <form name="keyform" action="<?php echo BLOG_URL; ?>index.php" method="get">
                    <input type="text" name="keyword" size="10" class="search" id="search" title="输入关键词按回车键搜索" onclick="clearText(this)" onFocus="if(value==defaultValue){value='';}" onBlur="if(!value){value=defaultValue;}" value="下方绿长条内有惊喜 ^__^ " />
                </form>
           </div>
    
    	<div class="cleaner"></div>
    </div> <!-- end of templatemo_header -->

</div> 
<!-- end of templatemo_header_wrapper -->

<section>