<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<span id="log_space">
	<a href="tencent://message/?uin=1545019690&Site=www.dyuee.com&Menu=yes" title="联系QQ">联系QQ</a>
	<a href="mailto:fisheatfox@gmail.com" title="来信投稿">来信投稿</a>
	<a href="javascript:window.open('<?php echo BLOG_URL; ?>rss.php')" title="订阅RSS">订阅RSS</a>
</span>
<div id="templatemo_content_wrapper">
  <div id="templatemo_content">
    <div class="cleaner"> </div>
    <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
    <div class="tw_top">※<a href="<?php echo BLOG_URL . 'admin/twitter.php' ?>">痴人说梦</a>※</div>
    <?php else: ?>
	  <div class="tw_top">※<a href="<?php echo BLOG_URL; ?>t/" target="_top">痴人说梦</a>※</div>
    <?php endif; ?>
    <ul class="tw_ul">
    <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?> 
    <div class="tw_li">
		<div class="tw_main_box">
		<div class="tw_main">
			<div id="tw_main_img"><div class="tw_main_img"><img alt="<?php echo $author; ?>" src="<?php echo $avatar; ?>" width="32px" height="32px" /></div></div>
			<div class="tw_post"><span id="tw_author"><?php echo $author; ?></span> 发表于<?php echo $val['date'];?>
			<div id="tw_content"><?php echo $val['t'].'<br/>'.$img;?></div>
		<ul id="r_<?php echo $tid;?>" class="re_post"></ul>
    <div class="huifu" id="rp_<?php echo $tid;?>">   
	    <div class="tinfo1"><textarea cols="35" rows="4" id="rtext_<?php echo $tid; ?>"></textarea></div>
        <div class="tinfo2">
        <div style="display:<?php if(ROLE == 'admin' || ROLE == 'writer'){echo 'none';}?>">
        <input type="text" id="rname_<?php echo $tid; ?>" onFocus="if(value==defaultValue){value='';}" onBlur="if(!value){value=defaultValue;}" value="昵称" /><br>
        <input type="text" id="rcode_<?php echo $tid; ?>" value="不要验证码" /> <?php echo $rcode; ?><br>
        </div>
        <input type="button" onclick="reply('<?php echo DYNAMIC_BLOGURL; ?>index.php?action=reply',<?php echo $tid;?>);" value="完成发表" />
        </div>
        <div id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></div>
	</div>
	<div class="re-huifu"><a href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">回复(<?php echo $val['replynum'];?>)</a>
		</div>
		</div>
		<div class="cleaner"></div>
		</div></div>
	</div>
    <?php endforeach;?>
    </ul>
    <div class="cleaner"></div>
<div class="page-code"><?php echo $pageurl;?></div>
</div><!--end #tw-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>