<?php 
/*首页日志列表部分*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

	<article>
		<div class="yun01"></div>
		<div class="yun02"></div>
		<div class="heaven"><div></div></div>

		<div class="main">
			<div class="m-content" id="cloumn1">
				<ul class="m-content-ul">
					<!-- 中间左边列表主体开始 -->
					<div class="mc-ty-m">
						<ul class="mcty-ul">
							<div class="log-list-m">
							<!-- log-list.php 主要内容开始 -->

							<?php doAction('index_loglist_top'); ?><!--页脚底部挂载点加入-->

							<?php foreach($logs as $value): ?>
								<?php
									$imgsrc = "";
									if(!empty($value['cover'])){
										$imgsrc = $value['cover']; //这里是新增加的图片
									}else{
										$imgsrc = TEMPLATE_URL.'images/random/tb'.rand(1,1).'.jpg'; //如果没有图片可以放几个随即图片 
									}
								?>

								<div class="mcim-list">
									<h2 id="cloumn3"><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></h2>
									<img src = "<?php echo $imgsrc; ?>" />
									<ul id="cloumn4"><?php echo $value['log_description']; ?></ul>
									<?php topflg($value['top']); ?>

									<div class="ain-01">
										<span><?php echo gmdate('Y-n-j', $value['date']); ?></span>
										<?php blog_sort($value['logid']); ?>
									</div>
									<div class="ain-02">
										<span>评论(<?php echo $value['comnum']; ?>)</span>
										<span>引用(<?php echo $value['tbcount']; ?>)</span>
										<span>浏览(<?php echo $value['views']; ?>)</span>
									</div>
								</div>

							<?php endforeach; ?>

								<div class="mc-ty-page"><?php echo $page_url;?></div>

							<!-- log-list.php 主要内容结束 -->
							</div>
						</ul>
					</div>
					<!-- 中间左边列表主体结束 -->
				</ul>
			</div>

			<aside id="cloumn2">
				<?php include View::getView('side'); ?>
			</aside>

		</div>

		<div class="html5-logo"><div></div></div>

		<div class="main-in-shadow"></div>
	</article>

<?php include View::getView('footer'); ?>