<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<footer>
		<div class="fot-m">
			<div class="fot-xhtmlcss">
				<a href="#" rel="external">Xhtml</a>
				<span><a href="#" rel="external">Css</a></span>
				<span><a href="<?php echo BLOG_URL; ?>rss.php" title="rss订阅" rel="external">Rss</a></span>
				<span><?php doAction('index_footer'); ?></span>
				<span><?php echo $footer_info; ?></span><!--统计代码-->
			</div>
			<div class="fot-copyright">
				<script type="text/javascript">
					copyright=new Date();
					update=copyright.getFullYear();
					document.write("&copy; 2010 - "+ update + "");
				</script>
				<a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>">HeavenDesign</a>
				<?php echo $icp; ?><!--备案号-->
			</div>
			<div class="fot-power">Powerd by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" rel="external">Emlog</a></div>
			<div class="fot-logo">
				<div class="fl-01"></div>
				<div class="fl-02"></div>
			</div>
		</div>
	</footer>

	<!--日志:<?php echo $sta_cache['lognum'];?> 评论:<?php echo $sta_cache['comnum_all'];?>-->

	<script src="<?php echo TEMPLATE_URL; ?>js/hd-main.js"></script><!--hd主配置-->
	<script src="<?php echo TEMPLATE_URL; ?>js/jquery.infieldlabel.min.js"></script><!--input框label调用-->
	
	<!--[if IE 9]>
		<script src="<?php echo TEMPLATE_URL; ?>js/nyyunsu.js"></script>
		<link href="<?php echo TEMPLATE_URL; ?>css/style-ie9.css" rel="stylesheet" />
	<![endif]-->

</body>
</html>