<?php 
/*自建页面模板*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

	<article>
		<div class="yun01"></div>
		<div class="yun02"></div>
		<div class="heaven"><div></div></div>

		<div class="main">
			<div class="m-content" id="cloumn1">
				<ul class="m-content-ul">
					<!-- 中间左边列表主体开始 -->
					<div class="mc-ty-m">
						<ul class="mcty-ul">
							<div class="page-m">
							<!-- page.php 主要内容开始 -->

							    <?php echo $log_content; ?>
							    <?php blog_comments($comments); ?>
							    <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>

							<!-- page.php 主要内容结束 -->
							</div>
						</ul>
					</div>
					<!-- 中间左边列表主体结束 -->
				</ul>
			</div>

			<aside id="cloumn2">
				<?php include View::getView('side'); ?>
			</aside>

		</div>

		<div class="html5-logo"><div></div></div>

		<div class="main-in-shadow"></div>
	</article>

<?php include View::getView('footer'); ?>

<!-- 相册插件 层级显示修复 -->
<style>
#jquery-overlay                { z-index: 9991; }
#jquery-lightbox               { z-index: 9992; }
</style>