<?php 
/*阅读日志页面*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

	<article>
		<div class="yun01"></div>
		<div class="yun02"></div>
		<div class="heaven"><div></div></div>

		<div class="main">
			<div class="m-content" id="cloumn1">
				<ul class="m-content-ul">
					<!-- 中间左边列表主体开始 -->
					<div class="mc-ty-m">
						<ul class="mcty-ul">
							<div class="echo-log-m" id="cloumn4">
							<!-- echo-log.php 主要内容开始 -->
							
								<div class="elm-pt-one">
									<h2 id="cloumn3"><a href="<?php echo Url::log($logid); ?>" title="<?php echo $log_title; ?>"><?php echo $log_title; ?></a></h2>
									<?php topflg($top); ?><!--置顶图标-->
									<div class="pto-01">
										<span><?php echo gmdate('Y-n-j', $date); ?></span>
										<?php blog_sort($logid); ?>
										<span>评论：<?php echo $comnum; ?></span>
										<span>阅读：<?php echo $views; ?></span>
										<span>引用：<?php echo $tbcount; ?></span>
									</div>
								</div>

								<div class="elm-pt-two"><?php echo $log_content; ?></div>

								<div class="elm-pt-three">
									<?php neighbor_log($neighborLog); ?>
								</div>

								<div class="elm-pt-four">
									<div class="elm-ptf-tag"><?php blog_tag($logid); ?></div>
									<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
									<?php doAction('log_related', $logData); ?><!--挂在点-->
								</div>

								<div class="elm-pt-five">

									<?php blog_comments($comments); ?>
									<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>

								</div>

							<!-- echo-log.php 主要内容结束 -->
							</div>
						</ul>
					</div>
					<!-- 中间左边列表主体结束 -->
				</ul>
			</div>

			<aside id="cloumn2">
				<?php include View::getView('side'); ?>
			</aside>

		</div>

		<div class="html5-logo"><div></div></div>

		<div class="main-in-shadow"></div>
	</article>

<?php include View::getView('footer'); ?>