<?php 
/*
* 侧边栏组件、页面模块
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//widget：最新碎语 本模板强制调用,后台不支持
function widget_twitter_change(){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	?>
	<div class="asd-div-suiyu">
		<div id="asd-div-suiyu">
			<ul>
			<?php foreach($newtws_cache as $value): ?>
			<?php $img = empty($value['img']) ? "" : '<a title="查看图片" class="t_img" href="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" target="_blank"></a>';?>
				<li><?php echo $value['t']; ?><?php echo $img;?><p><?php echo smartDate($value['date']); ?> 发布</p></li>
			<?php endforeach; ?>
		    <?php if ($istwitter == 'y') :?>
			<!--<a href="<?php echo BLOG_URL . 't/'; ?>">更多&raquo;</a>-->
			<?php endif;?>
			</ul>
		</div>
	</div>
<?php }?>
<?php
//widget：blogger 本模板不强制调用,后台不支持
function widget_blogger_change($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="bloggerinfo">
	<div id="bloggerinfoimg">
	<?php if (!empty($user_cache[1]['photo']['src'])): ?>
	<img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="<?php echo $user_cache[1]['photo']['width']; ?>" height="<?php echo $user_cache[1]['photo']['height']; ?>" alt="blogger" />
	<?php endif;?>
	</div>
	<p><b><?php echo $name; ?></b>
	<?php echo $user_cache[1]['des']; ?></p>
	</ul>
	</li>
<?php }?>
<?php
//widget：日历 本模板不强制调用,后台不支持
function widget_calendar_change($title){ ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<div id="calendar">
	</div>
	<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
	</li>
<?php }?>
<?php
//widget：搜索 本模板不强制调用,后台不支持
function widget_search_change($title){ ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="logserch">
	<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
	<input name="keyword" class="search" type="text" />
	</form>
	</ul>
	</li>
<?php } ?>
<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
	<div>
		<h3><span>Tags</span><?php echo $title; ?></h3>
		<ul class="asd-ul-sty-04 tag-color">
		<?php foreach($tag_cache as $value): ?>
			<a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇日志"><?php echo $value['tagname']; ?></a>
		<?php endforeach; ?>
		</ul>
	</div>
<?php }?>
<?php
//widget：顶部分类信息
function header_sort(){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	<div class="hns-div">
		<ul>
			<?php foreach($sort_cache as $value): ?>
			<a href="<?php echo Url::sort($value['sid']); ?>"><samp><?php echo $value['sortname']; ?></samp><span>(<?php echo $value['lognum'] ?>)</span></a>
			<?php endforeach; ?>
		</ul>
	</div>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	<div>
		<h3><span>Categories</span><?php echo $title; ?></h3>
		<ul class="asd-ul-sty-02">
		<?php foreach($sort_cache as $value): ?>
			<a href="<?php echo Url::sort($value['sid']); ?>"><span><?php echo $value['sortname']; ?></span><samp>(<?php echo $value['lognum'] ?>)</samp></a>
		<?php endforeach; ?>
		</ul>
	</div>
<?php }?>
<?php 
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
	<div>
		<h3><span>Comments</span><?php echo $title; ?></h3>
		<ul class="asd-ul-sty-06">
		<?php
		foreach($com_cache as $value):
		$url = Url::comment($value['gid'], $value['page'], $value['cid']);
		?>
			<li>
				<img alt="Gravatar" src="http://www.gravatar.com/avatar/<?php echo md5($value['mail']); ?>?s=48"/>
				<samp><?php echo $value['name']; ?></samp>
				<a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a>
			</li>
		<?php endforeach; ?>
		</ul>
	</div>
<?php }?>
<?php 
//widget：最新日志
function widget_newlog($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
	<div>
		<h3><span>Recent Log</span><?php echo $title; ?></h3>
		<ul class="asd-ul-sty-03">
		<?php foreach($newLogs_cache as $value): ?>
			<a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>"><?php echo $value['title']; ?></a>
		<?php endforeach; ?>
		</ul>
	</div>
<?php }?>
<?php
//widget：热门日志
function widget_hotlog($title){
	$index_hotlognum = Option::get('index_hotlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getHotLog($index_hotlognum);?>
	<div>
		<h3><span>Hot Log</span><?php echo $title; ?></h3>
		<ul class="asd-ul-sty-03">
		<?php foreach($randLogs as $value): ?>
			<a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>"><?php echo $value['title']; ?></a>
		<?php endforeach; ?>
		</ul>
	</div>
<?php }?>
<?php 
//widget：随机日志
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	<div>
		<h3><span>Random Log</span><?php echo $title; ?></h3>
		<ul class="asd-ul-sty-03">
			<?php foreach($randLogs as $value): ?>
				<a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>"><?php echo $value['title']; ?></a>
			<?php endforeach; ?>
		</ul>
	</div>
<?php }?>
<?php
//widget：头部搜索
function header_search(){ ?>
	<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
		<label for="s" style="opacity: 1;">I am searching for...</label>
		<input id="s" name="keyword" class="hd-search-input" type="text" />
		<input class="hd-search-submit" type="submit" value="">
	</form>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
	<div>
		<h3><span>Archive</span><?php echo $title; ?></h3>
		<ul class="asd-ul-sty-02">
		<?php foreach($record_cache as $value): ?>
			<a href="<?php echo Url::record($value['date']); ?>"><span><?php echo $value['record']; ?></span><samp>(<?php echo $value['lognum']; ?>)</samp></a>
		<?php endforeach; ?>
		</ul>
	</div>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul>
	<?php echo $content; ?>
	</ul>
	</li>
<?php } ?>
<?php 
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
	?>
	<div>
		<h3><span>Links</span><?php echo $title; ?></h3>
		<ul class="asd-ul-sty-05">
		<?php foreach($link_cache as $value): ?>
			<a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><span><?php echo $value['link']; ?></span></a>
		<?php endforeach; ?>
		</ul>
	</div>
<?php }?>
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	?>
	<ul>
	<?php 
	foreach($navi_cache as $value):
		if($value['url'] == 'admin' && (ROLE == 'admin' || ROLE == 'writer')):
			?>
			<li><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
			<li><a href="<?php echo BLOG_URL; ?>admin/">管理站点</a></li>
			<li><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
			<?php
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
		$value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
		$current_tab = (BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url']) ? 'class="xz"' : '';
		?>
		<li <?php echo $current_tab;?>><a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a></li>
	<?php endforeach; ?>
	</ul>
<?php }?>
<?php
//blog：置顶
function topflg($istop){
	$topflg = $istop == 'y' ? "<div class='ain-top' title='置顶文章'></div>" : '';
	echo $topflg;
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == 'admin' || $author == UID ? '<span><a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a></span>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?><span>所属分类：<a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>" title="<?php echo $log_cache_sort[$blogid]['name']; ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a></span><?php endif;?>
<?php }?>
<?php
//blog：日志标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '文章标签：';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
		}
		echo $tag;
	}
}
?>
<?php
//blog：日志作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo $author;
}
?>
<?php
//blog：相邻日志
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog):?>
	<span>上一篇：<a href="<?php echo Url::log($prevLog['gid']) ?>"><?php echo $prevLog['title'];?></a></span>
	<?php endif;?>
	<?php if($nextLog && $prevLog):?>

	<?php endif;?>
	<?php if($nextLog):?>
	<samp>下一篇：<a href="<?php echo Url::log($nextLog['gid']) ?>"><?php echo $nextLog['title'];?></a></samp>
	<?php endif;?>
<?php }?>
<?php
//blog：引用通告
function blog_trackback($tb, $tb_url, $allow_tb){
    if($allow_tb == 'y' && Option::get('istrackback') == 'y'):?>
	<div id="trackback_address">引用地址：<input type="text" style="width:350px" class="input" value="<?php echo $tb_url; ?>"><a name="tb"></a></div>
	<?php endif; ?>
	<?php foreach($tb as $key=>$value):?>
	<div id="trackback">
		<li><a href="<?php echo $value['url'];?>" target="_blank"><?php echo $value['title'];?></a></li>
		<li>BLOG: <?php echo $value['blog_name'];?></li>
		<li><?php echo $value['date'];?></li>
	</div>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：评论列表
function blog_comments($comments){
    extract($comments);
    if($commentStacks): ?>

	<?php endif; ?>
	<?php
	$isGravatar = Option::get('isgravatar');
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" rel="external">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<div class="comment comment-main" id="comment-<?php echo $comment['cid']; ?>">
		<ul class="ul-ct-m">

			<a class="ct-dw" name="<?php echo $comment['cid']; ?>"></a>
			<?php if($isGravatar == 'y'): ?>
			<div class="ct-avatar"><img src="<?php echo getGravatar($comment['mail']); ?>" /></div>
			<?php endif; ?>
			<div class="ct-name"><?php echo $comment['poster']; ?></div>
			<div class="ct-date"><?php echo $comment['date']; ?></div>
			<div class="ct-content">
				<?php echo $comment['content']; ?>
				<p><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a>
			</div>
			<?php blog_comments_children($comments, $comment['children']); ?>

		</ul>
	</div>
	<?php endforeach; ?>
    <div class="mc-ty-page comment-pagenavi">
	    <?php echo $commentPageUrl;?>
    </div>
<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" rel="external">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<div class="comment comment-children" id="comment-<?php echo $comment['cid']; ?>">
		<ul class="ul-ct-child">
			<a class="ct-dw" name="<?php echo $comment['cid']; ?>"></a>
			<?php if($isGravatar == 'y'): ?>
			<div class="ct-avatar"><img src="<?php echo getGravatar($comment['mail']); ?>" /></div>
			<?php endif; ?>
			<div class="ct-name"><?php echo $comment['poster']; ?></div>
			<div class="ct-date"><?php echo $comment['date']; ?></div>
			<div class="ct-content">
				<?php echo $comment['content']; ?>
				<?php if($comment['level'] < 2): ?><p><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a></p><?php endif; ?>
			</div>
			<?php blog_comments_children($comments, $comment['children']); ?>
		</ul>
	</div>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
	<div id="comment-place">
		<div id="comment-post">
			
			<ul class="ul-cp-ra">
				<div id="cancel-reply" style="display:none"><a href="javascript:void(0);" onclick="cancelReply()">取消回复</a></div>
				<form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
					<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
					<input type="hidden" name="pid" id="comment-pid" value="0" />
					<?php if(ROLE == 'visitor'): ?>
					<div class="cp-01"><input id="cp-author" type="text" maxlength="49" name="comname" value="<?php echo $ckname; ?>" tabindex="1"></div>
					<div class="cp-01"><label for="cp-author">昵称</label></div>
					<div class="cp-02"><input id="cp-email" type="text" maxlength="128" name="commail" value="<?php echo $ckmail; ?>" tabindex="2"></div>
					<div class="cp-02"><label for="cp-email">邮件（选填）</label></div>
					<div class="cp-03"><input id="cp-url" type="text" maxlength="128" name="comurl" value="<?php echo $ckurl; ?>" tabindex="3"></div>
					<div class="cp-03"><label for="cp-url">个人站点（选填）</label></div>
					<?php endif; ?>
					<div class="cp-04"><textarea name="comment" id="comment" rows="10" tabindex="4"></textarea></div>
				    <?php echo $verifyCode; ?><div class="cp-05"><button type="submit" id="comment_submit" tabindex="5" />发表评论</button>
				</form>
			</ul>

		</div>
	</div>
	<?php endif; ?>
<?php }?>