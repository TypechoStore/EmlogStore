<?php
	if(!defined('EMLOG_ROOT')) {exit('error!');}
	require_once View::getView('module');
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="chrome=1">

	<!--[if lt IE 7 ]>
		<script type='text/javascript'> 
			window.location.href="<?php echo TEMPLATE_URL; ?>error/index.html"
		</script>
	<![endif]-->

	<!--[if IE 7]>
		<script type='text/javascript'> 
			window.location.href="<?php echo TEMPLATE_URL; ?>error/index.html"
		</script>
	<![endif]-->

	<!--[if IE 8]>
		<script type='text/javascript'> 
			window.location.href="<?php echo TEMPLATE_URL; ?>error/index.html"
		</script>
	<![endif]-->

	<title><?php echo $site_title; ?></title>
	<meta name="keywords" content="<?php echo $site_key; ?>" />
	<meta name="description" content="<?php echo $site_description; ?>" />

	<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
	<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
	<link rel="alternate" type="application/rss+xml" title="RSS" href="<?php echo BLOG_URL; ?>rss.php" />

	<script src="<?php echo TEMPLATE_URL; ?>js/jquery-1.8.0.min.js"></script>
	<link href="<?php echo TEMPLATE_URL; ?>css/style.css" rel="stylesheet" />

	<script type='text/javascript'> 
	  var hour = new Date().getHours();
	  if(hour >=6&&hour<=18)
	  document.writeln('<link href="<?php echo TEMPLATE_URL; ?>css/daylight.css" rel="stylesheet" />');
	  else
	  document.writeln('<link href="<?php echo TEMPLATE_URL; ?>css/midnight.css" rel="stylesheet" />');
	</script>

	<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" ></script>
	<?php doAction('index_head'); ?>

</head>

<body>

	<header>
		<hgroup>
			<nav class="hd-nav-navi">
				<?php blog_navi();?>
			</nav>
			<nav class="hd-nav-sort">
				<a href="#" class="hns-a" alt="分类栏目"></a>
				<?php header_sort();?>
			</nav>
			<div class="hd-search">
				<?php header_search();?>
			</div>
		</hgroup>
	</header>