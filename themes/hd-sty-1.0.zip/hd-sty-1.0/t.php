<?php 
/*碎语部分*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

    <article>
        <div class="yun01"></div>
        <div class="yun02"></div>
        <div class="heaven"><div></div></div>
        
        <div class="main">
            <div class="m-content" id="cloumn1">
                <ul class="m-content-ul">
                    <!-- 中间左边列表主体开始 -->
                    <div class="mc-ty-m">
                        <ul class="mcty-ul">
                            <div class="suiyu-t-m">
                            <!-- 碎语 主要内容开始 -->

                                <?php 
                                foreach($tws as $val):
                                $author = $user_cache[$val['author']]['name'];
                                $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                                    BLOG_URL . 'admin/views/images/avatar.jpg' : 
                                    BLOG_URL . $user_cache[$val['author']]['avatar'];
                                $tid = (int)$val['id'];
                                $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
                                ?> 

                                <div class="suiyu-t-list">
                                    <img src="<?php echo $avatar; ?>" />
                                    <div class="sytl-01"><?php echo $author; ?></div>
                                    <div class="sytl-02"><?php echo $val['date'];?></div>
                                    <ul><?php echo $val['t'].'<br/>'.$img;?></ul>
                                </div>

                                <?php if ($istreply == 'y'):?>
                                <?php endif;?>
                                <?php endforeach;?>

                            <!-- 碎语 主要内容结束 -->
                            </div>
                        </ul>
                    </div>
                    <!-- 中间左边列表主体结束 -->
                </ul>
            </div>

            <aside id="cloumn2">
                <?php include View::getView('side'); ?>
            </aside>

        </div>

        <div class="html5-logo"><div></div></div>

        <div class="main-in-shadow"></div>
    </article>

<?php include View::getView('footer'); ?>