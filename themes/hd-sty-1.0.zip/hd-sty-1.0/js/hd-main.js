//heavendesign 页面主配置js文件

$(function(){ $("label").inFieldLabels(); }); 
//配合 jquery.infieldlabel.min.js label标签的隐藏

$(document).ready(function() {
	$(".hd-nav-sort > a").click(function() {
		var ulNode = $(this).next("div");
		ulNode.slideToggle();
	});
});
//header 分栏菜单

(function() {
    var $backToTopTxt = "Back Top !", $backToTopEle = $('<div class="backToTop"></div>').appendTo($("body"))
        .text($backToTopTxt).attr("title", $backToTopTxt).click(function() {
            $("html, body").animate({ scrollTop: 0 }, 1120);
    }), $backToTopFun = function() {
        var st = $(document).scrollTop(), winh = $(window).height();
        (st > 0)? $backToTopEle.show(): $backToTopEle.hide();    
        //IE6下的定位
        if (!window.XMLHttpRequest) {
            $backToTopEle.css("top", st + winh - 166);    
        }
    };
    $(window).bind("scroll", $backToTopFun);
    $(function() { $backToTopFun(); });
})();
//返回顶部

function externalLinks() {
	if (!document.getElementsByTagName) return;
	var anchors = document.getElementsByTagName("a");
	for (var i = 0; i < anchors.length; i++) {
		var anchor = anchors[i];
		if (anchor.getAttribute("href") && anchor.getAttribute("rel") == "external") anchor.target = "_blank";
	}
}
window.onload = externalLinks
//导出链接 rel="external"

$(function(){
	var scrtime;
	$("#asd-div-suiyu").hover(function(){
		clearInterval(scrtime);
	
	},function(){
	
	scrtime = setInterval(function(){
		var $ul = $("#asd-div-suiyu ul");
		var liHeight = $ul.find("li:last").height();
		$ul.animate({marginTop : liHeight + 0 + "px"},1400,function(){
		
		$ul.find("li:last").prependTo($ul)
		$ul.find("li:first").hide();
		$ul.css({marginTop:0});
		$ul.find("li:first").fadeIn(1000);
		});
	},5000);
	
	}).trigger("mouseleave");
});
//碎语部分的纵向移动

$(function(){ 
 if($('.tag-color').length){ 
  function color(){
   return '#'+('00000'+(Math.random()*0x1000000<<0).toString(16)).slice(-6);};
   var tags=$('.tag-color a');
   for(i=0;i<tags.length-1;i++){tags.css('color',color);}
}})
//彩色标签

var l=document.getElementById("cloumn1").scrollHeight;   
var r=document.getElementById("cloumn2").scrollHeight   
if (r>l) {   
    document.getElementById("cloumn1").style.height=document.getElementById("cloumn2").scrollHeight+"px";   
} else {   
    document.getElementById("cloumn2").style.height=document.getElementById("cloumn1").scrollHeight+"px";   
}
//div层height统一，取最大的那个height

    document.getElementById("cloumn3").style.width=document.getElementById("cloumn4").scrollWidth+"px";   
//找到标题的width