<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>

<div class="left">
	<div class="left-block mes">
		<p>简·志</p>
   	</div>
      <?php 
    foreach($tws as $val):
    $tid = (int)$val['id'];
	?>
        <div class="post1">
          <span class="wtime"><?php echo $val['date']; ?></span><?php echo $val['t']; ?>
        </div>
      <?php endforeach;?>
<div class="page">
	<?php echo $pageurl;?>
</div>
</div>

<?php
 include View::getView('side');
 include View::getView('footer');
?>