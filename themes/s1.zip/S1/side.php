<?php 
/**
 * 侧边栏
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
    <div class="right">
    	<div class="side">
        <?php echo widget_search(); ?>
    	</div>
    	<div class="side hot">
    	<?php echo widget_hotlog('热门文章'); ?>
    	</div>
    	<div class="side link">
    	<?php echo widget_link('友情链接'); ?>
    	</div>
        <div class="side cr">
        <h3><span>版权声明</span></h3>
        	Powered by <a href="http://www.emlog.net">emlog</a>. Written by <a href="http://sinkery.com">sinkery</a>.
        </div>
    </div>
    <div style="clear:both"></div>
