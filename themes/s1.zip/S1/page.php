<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
    <div class="left">
        <div class="left-block mes">
			<p><?php echo $log_title; ?></p>
   	    </div>
        <?php w_comments($comments); ?>     
        <div class="post">
			<?php w_comments_post($logid,$ckname,$verifyCode,$allow_remark); ?>
        </div>
	</div>

<?php
 include View::getView('side');
 include View::getView('footer');
?>