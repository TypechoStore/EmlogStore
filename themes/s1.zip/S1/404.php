<?php 
/**
 * 自定义404页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>404 页面未找到</title>
<style>
.error{
	position:absolute;
	width:600px;
	height:100px;
	line-height:100px;
	left:50%;
	top:50%;
	margin-left:-300px;
	margin-top:-50px;
	background:#f0f0f0;
	text-align:center;
	font-size:14px;
	color:#363636;
	font-family:"微软雅黑";
	border-top:5px solid #1395e4;
}
a{
	text-decoration:none;
	color:#1395e4;
}
</style>
</head>
<body>
<div class="error">错误：页面未找到。<a href="<?php echo BLOG_URL; ?>">点击返回</a>
</div>
</body>
</html>