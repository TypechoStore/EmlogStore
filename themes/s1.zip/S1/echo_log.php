<?php 
/**
 * 	文章输出
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>


    <div class="left">
        <div class="left-block">
			<h2><?php topflg($top); ?><?php echo $log_title; ?><span class="date"><?php echo gmdate('n月j日', $date); ?></span></h2>
			<div class="desc"><?php echo $log_content; ?></div>
   	    </div>
        <div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
        <?php blog_comments($comments); ?>     
        <div class="post">
			<?php blog_comments_post($logid,$ckname,$verifyCode,$allow_remark); ?>
        </div>
	</div>
    
<?php
 include View::getView('side');
 include View::getView('footer');
?>