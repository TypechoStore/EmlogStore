<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js"></script>
<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<script type="text/javascript">
$(document).ready(function(){
$(window).scroll(function(){
if($(this).scrollTop()!=0){
$('.top').fadeIn();}
else{
$('.top').fadeOut();} });
$('.top').click(function(){
$('body,html').animate({scrollTop:0},700);});
});
</script>
</div>
<div class="top" title="返回顶部">↑</div>
</body>
</html>