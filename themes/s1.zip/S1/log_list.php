<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

    <div class="left">
		<?php 
			if (!empty($logs)):
			foreach($logs as $value): 
		?>
        <div class="left-block">
			<h2><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a><span class="date"><?php echo gmdate('n月j日', $value['date']); ?></span></h2>
			<div class="desc"><?php echo $value['log_description']; ?></div>
   	    </div>
  		<?php endforeach;
			  else: ?>
        <div class="left-block">
        	<h2 style="padding-bottom:20px;">未找到关键词为 <span style="color:#1395e4; font-family:'微软雅黑 Light';"><?php echo $keyword; ?></span> 的日志。</h2>
        </div>
        <?php endif; ?>
		<div class="page">
		<?php echo $page_url;?>
		</div>
	</div>
    
<?php
 include View::getView('side');
 include View::getView('footer');
?>