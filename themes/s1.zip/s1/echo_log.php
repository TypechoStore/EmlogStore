<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
$wiget="article";
?>
<!-- content START -->
<div id="content-inner">
			<div class="post">
<div class="post-data" id="post-<?php echo $logid;?>">
             <h2><?php topflg($top); ?><a class="title" href="<?php echo $value['log_url']; ?>" rel="bookmark"><?php echo $log_title; ?></a></h2><?php editflg($logid,$author); ?>
		</div>
		<div class="bloger">作者：<?php blog_author($author); ?> 发表日期： <?php echo gmdate('Y-n-j G:i l', $date); ?></div>
		<div class="post-txt">
		<?php echo $log_content; ?>
		</div>
		  <div class="post-content"> 
    <?php blog_att($logid); ?>
    <p class='crinfo'> 版权所有：<a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>"><?php echo $blogname; ?></a> <a rel="bookmark" title="<?php echo $log_title; ?>" href="<?php echo $value['log_url']; ?>">《 <?php echo $log_title; ?>》</a><br />
      站长声明：除特别标注,本站所有文章均为原创. 互联分享,尊重版权,转载注明出处</p>
    <div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
        <a class="bds_qzone"></a>
        <a class="bds_tsina"></a>
        <a class="bds_tqq"></a>
        <a class="bds_renren"></a>
        <span class="bds_more">更多</span>
    </div>
<script type="text/javascript" id="bdshare_js" data="type=tools" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
	document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?t=" + new Date().getHours();
</script>
<!-- Baidu Button END -->
    <br />

      <div id="single-bottom">
     <div id="single-rss" style="float: right;">订阅: <a class="rss-feed" title="订阅博客文章" rel="nofollow external" href="<?php echo BLOG_URL; ?>rss.php">RSS</a></div>
    </div>
  </div>
        
    <div class="navigation">
	<ul>
      	 <?php neighbor_log($neighborLog); ?>     
	</ul>	
	</div>
	<br>
<div id="comments">
<div id="coms-title"><a class="curtab" rel="nofollow">评论</a> | <span class="addcomment"><a rel="nofollow"  href="#respond">发表评论</a></span></div>
	<div class="coms-title" ><h2>欢迎大家发表自己的想法！</h2></div>
	<!-- comments START -->
<ol class="coms-list">
<?php blog_comments($comments); ?>	
</ol>
	<!-- comments END -->
<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<!-- comments END -->
</div>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
	</div></div>
<!-- main END -->
<?php
 include View::getView('side');
 include View::getView('footer');
?>