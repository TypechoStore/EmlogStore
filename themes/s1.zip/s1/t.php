<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!-- content START -->
<div id="content-inner">
	<div class="post">
	<!-- main START -->
<div id="comments">
<div id="coms-title">
<a class="curtab" rel="nofollow">碎语 (<?php echo count($tws);?>)</a>
<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
<span class="addcomment"> | <a href="<?php echo BLOG_URL . 'admin/twitter.php' ?>">写碎语</a>
</span>
<?php endif; ?>
</div>
<ol class="coms-list">
<!-- t yu start -->
<?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
?>
<li class="comment even thread-even depth-1">
	<dl>
	<img alt="Avatar" src="<?php echo $avatar; ?>" class="photo" height="32" width="32">
	</dt>
	<dd>	
	<div class="nick"><cite><?php echo $author; ?></cite>：<a name="commtent_1478"></a></div>
	<div class="txt">
	<p><div  id='commcontent_1478' class="d"><?php echo $val['t'];?></div></p>
	</div>
		<div class="date">
		   <small>POST:<?php echo $val['date'];?></small>
			<span class="reply">
			<a href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">回复(<span id="rn_<?php echo $tid;?>"><?php echo $val['replynum'];?></span>)</a>
			</span>
		</div>
	</dd>
</li>
		<?php blog_comments_children($comments, $comment['children']); ?>
<!-- comments START -->
	<a name="comments"></a>
	<ol id="thecomments" class="commentlist">
		<li class="hreview clearfix evencomment">
<ul class='children r' id="r_<?php echo $tid;?>">
	</ul>
    <div style="display:none;" id="rp_<?php echo $tid;?>"> 
		<div id="post-coms-txt">
			<textarea name="comment"  id="rtext_<?php echo $tid; ?>"  rows="8" cols="50"></textarea>
		</div>
		<div class="row">
			<input type="text"  id="rname_<?php echo $tid; ?>" class="textfield" value="" size="24" tabindex="1" />
			<label for="author" class="txt">昵称</label>
		</div>
	<div id="submitbox" class="clearfix">
			<div id="post-coms-btn">
				<span style="display:<?php if($reply_code == 'n'){echo 'none';}?>">验证码：<input type="text" id="rcode_<?php echo $tid; ?>" value="" /><?php echo $rcode; ?></span>
				<input   type="button" onclick="reply('<?php echo DYNAMIC_BLOGURL; ?>index.php?action=reply',<?php echo $tid;?>);"  class="btn"  value="回复" />
			</div>
		</div>
	<span id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></span>
    </div>
	</li>
	<!-- comments end -->
		<?php endforeach;?>
	<div id="pagenavi">
	<div class="pagenavi"><?php echo $pageurl;?></div>
	</div>
	</ol>
<!-- t yu end -->
</ol>
</div>

</div></div></div>
	<!-- main END -->
<!-- sidebar START -->
<?php
 include View::getView('side');
 include View::getView('footer');
?>





