<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="footer">
	<div class="copyright">
		&copy; 2012 <em><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></em> All rights reserved. <?php echo $footer_info; ?> <a href="http://www.miibeian.gov.cn" target="_blank"><strong>  <?php echo $icp; ?></strong></a> <br />
<!--请保留主题作者链接 谢谢您的支持!!同时欢迎友链我哦~-->
		 <em>Theme: <a href="http://www.shouke.tk/" title="template by qz">曾怡可</a>. Powered by <strong><a href="http://emlog.net/">emlog</a></strong></em><br /><?php doAction('index_footer'); ?> 
	</div>
</div><!--end footer-->
<STYLE type=text/css><!--body {background-image:url(<?php echo TEMPLATE_URL; ?>images/s1.jpg) ;background-repeat:no-repeat;background-attachment:fixed;background- 50%}--> </STYLE>


</body>
</html>
