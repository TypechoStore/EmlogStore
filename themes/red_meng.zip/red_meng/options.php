﻿<?php
/*
 * [修复自适应]模板配置文件
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
  'logopic' => array(
        'type' => 'image',
        'name' => '上传LOGO图片',
        'values' => array(
            TEMPLATE_URL . 'images/logo.png',
        ),
		'description' => '推荐尺寸为218*68分辨率的图片',
    ),
	
	'icmshowid' => array(
		'type' => 'text',
		'name' => '首页导航分类ID',
		'default' => '1,2,3,4,5,6,7,8,9',
		'description' => '第一个数字即为第一块分类ID（以此类推），必须用 , 间隔！为空则不显示，<a href="https://www.vc99.cn/" target="_blank">分类ID查看方法</a>',
	),
	
	'ggtp1' => array(
		'type' => 'text',
		'name' => '首页顶部横幅广告图片1',
		'default' => '',
		'description' => '请输入广告图片地址',
	),
	'gglj1' => array(
		'type' => 'text',
		'name' => '首页顶部横幅广告链接1',
		'default' => '',
		'description' => '请输入广告链接地址',
	),
	'ggtp2' => array(
		'type' => 'text',
		'name' => '文章内页下横幅广告图片1',
		'default' => '',
		'description' => '请输入广告图片地址',
	),
	'gglj2' => array(
		'type' => 'text',
		'name' => '文章内页下横幅广告链接1',
		'default' => '',
		'description' => '请输入广告链接地址',
	),
  	'ggtp3' => array(
		'type' => 'text',
		'name' => '分类内页下横幅广告图片1',
		'default' => '',
		'description' => '请输入广告图片地址',
	),
	'gglj3' => array(
		'type' => 'text',
		'name' => '分类内页下横幅广告链接1',
		'default' => '',
		'description' => '请输入广告链接地址',
	),

);