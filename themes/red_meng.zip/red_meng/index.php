<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div class="article-recommend">
<a href="<?php echo _g('gglj1'); ?>"><img width="100%" src="<?php echo _g('ggtp1'); ?>"></a>
</div>
<daohang>
<div class="zuijing">
<div class="title">
<span style="width: 100%;">
最近收录 
</span>
</div>
<div class="wzlb">
<ul>  
<?php 
 if (!empty($logs)):
foreach($Log_Model->getLogsForHome("order by date DESC",$page,36) as $value):
 $flag = pic_num($value['content']);?>
<li><img src="https://www.vc99.cn/get.php?url=<?php wz_ico($value['logid']);?>" onerror="this.src='<?php echo TEMPLATE_URL; ?>/images/beiyong.ico'" ><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></li>
<?php 
 endforeach;
 else:
 ?>
<div style="margin-top: 20px;text-align: center;">
<h1>Not Found</h1>
<h2>抱歉，本破站没有</h2>
</div>
<?php endif;?>
</ul>
</div>
</div>

  
<div class=" wap_zuijing ">
<div class="title">
<span style="width: 100%;">
最近收录 
</span>
</div>
<div class="wzlb">
<ul>  
<?php 
 if (!empty($logs)):
foreach($Log_Model->getLogsForHome("order by date DESC",$page,15) as $value):
 $flag = pic_num($value['content']);?>
<li><img src="https://www.vc99.cn/get.php?url=<?php wz_ico($value['logid']);?>" onerror="this.src='<?php echo TEMPLATE_URL; ?>/images/beiyong.ico'" ><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></li>
<?php 
 endforeach;
 else:
 ?>
  
<div style="margin-top: 20px;text-align: center;">
<h1>Not Found</h1>
<h2>抱歉，本破站没有</h2>
</div>
<?php endif;?>
</ul>
</div>
</div>
  
<div class="zhongjian">
  
<div class="fenlei">
<?php
  //导航分类
  $cmsid=explode(',',_g('icmshowid'));
  $cmsnum=count($cmsid);
  for ($x=0; $x<$cmsnum; $x++) {
    cmslist($cmsid[$x]);
  }
?>
</div> 
  
<div class="wap_fenlei">
<?php
  //导航分类
  $cmsid=explode(',',_g('icmshowid'));
  $cmsnum=count($cmsid);
  for ($x=0; $x<$cmsnum; $x++) {
    wap_cmslist($cmsid[$x]);
  }
?>
</div>
</div>
  
</daohang>

  <?php
 include View::getView('footer');
?>