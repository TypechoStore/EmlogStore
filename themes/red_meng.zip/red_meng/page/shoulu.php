<?php 
/**
 * 自定义 留言板界面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<main class="container">
<section class="shoulu">
<section class="content" id="scroll">
<section class="liuyan" style=" width: 100%; "> 
<article class="entry">
<header class="post_header">
<h1><?php echo $log_title; ?></h1>
</header>
<div class="content_post"> 
<p style="text-align:center;"> <span style="font-size:18px;color:#E53333;">本导航网免费收录各种网站</span> </p>
<p style="text-align:center;"> <span style="font-size:18px;color:#00D5FF;">对于收录的网站没有任何要求</span> </p>
<p style="text-align:center;"> <span style="font-size:18px;color:#60D978;">只需要贵站添加本站的友情链接即可</span> </p>
<p style="text-align:center;"> <span style="font-size:18px;color:#60D978;"><br></span> </p>
<p style="text-align:center;"> <span style="font-size:18px;color:#FF9900;">如需申请收录请联系QQ:871359149</span> </p>
<p style="text-align:center;"> <span style="font-size:18px;color:#EE33EE;">也可以直接在评论区留下贵站的资料</span> </p>
<p style="text-align:center;"> <span style="font-size:18px;color:#337FE5;">本站拒绝收录：黄赌毒等违规网站</span> </p>
<p style="text-align:center;"> <span style="font-size:18px;color:#60D978;"><br></span> </p>
<p style="text-align:center;"><span style="font-size:18px;color:#EE33EE;" > 申请收录评论格式如下</span></p>
<p style="text-align:center;"><span style="font-size:18px;color:#000000;">站长QQ： </span></p>
<p style="text-align:center;"><span style="font-size:18px;color:#000000;">网站标题： </span></p>
<p style="text-align:center;"> <span style="font-size:18px;color:#000000;">网站域名： </span></p>
<p style="text-align:center;"><span style="font-size:18px;color:#000000;">网站介绍： </span></p>
<p style="text-align:center;"><span style="font-size:18px;color:#000000;">网站关键词： </span></p>
<p style="text-align:center;"><span style="font-size:18px;color:#ff0000;">我们会在两天内收录贵站 </span></p>
<p style="text-align:center;"><span style="font-size:18px;color:#ff0000;">请确保以添加本站的友情链接 </span></p>


</div>
</article> 
 <!-- 评论列表 -->     
 <div class="comment-container">
	<div id="comments1" class="clearfix">
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
		<?php blog_comments($comments); ?>
	</div>
</div> 
</section>
</section>
</section>
</main>

<?php
 include View::getView('footer');
?>