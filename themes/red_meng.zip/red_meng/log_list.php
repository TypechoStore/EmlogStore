<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
if($pageurl == Url::logPage()){include View::getView('index');exit;}
?>
<div class="article-recommend">
<a href="<?php echo _g('gglj3'); ?>"><img width="100%" src="<?php echo _g('ggtp3'); ?>"></a>
</div>
<div class="daohangfenlei">
 <!-- 分类文章列表 --> 
<div class="daohangliebiao">
  
 <ul> 
  <?php 
  if (!empty($logs)):
  foreach($logs as $value):
  $flag = pic_num($value['content']);?>

 <li>
 <a href="<?php echo $value['log_url']; ?>">
 <img src="https://mini.s-shot.ru/?<?php wz_jlt($value['logid']);?>" onerror="this.src='<?php echo TEMPLATE_URL; ?>/images/zanwu.png'" ><?php wz_jieshao($value['logid']);?> </a>
 </li>

<?php 
 endforeach;
 else:
 ?>
<!-- 预留给系统搜索 -->
<div style="margin-top: 20px;text-align: center;">
<h1>Not Found</h1>
<h2>抱歉，没有找到你想找的内容</h2>
</div>
<?php endif;?>
</ul>
</div>
</div>

