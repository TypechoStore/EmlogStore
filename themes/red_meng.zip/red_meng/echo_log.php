<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<link href="<?php echo BLOG_URL; ?>content/plugins/daohang/style.css" rel="stylesheet">
<div class="wzdh">
<div class="nrym">
<div class="dhxx">
<?php echo unCompress($log_content); ?>
<?php doAction('down_log',$logid); ?>  
</div>

<a href="<?php echo _g('gglj2'); ?>"><img width="100%" src="<?php echo _g('ggtp2'); ?>"></a>

<div class="comment-container">
<div id="comments1" class="clearfix">
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<?php blog_comments($comments); ?>
</div>
</div> 
</div> 
  <?php
 include View::getView('footer');
?>
</div>