<?php /** 自建页面模板*/if(!defined('EMLOG_ROOT')) {exit('error!');} ?><div class="nrsin">			<?php if($log_title=="标签"): ?>            <?php global $CACHE;             $tag_cache = $CACHE->readCache('tags');?><h1><?php echo $log_title; ?></h1><div id="post"><div class="nrtcksx"><div class="datetime"><?php echo gmdate('Y-n-j', $date); ?></div></div><p>				 <?php shuffle($tag_cache); ?>                 <?php foreach($tag_cache as $value): ?>                 <span style="font-size:<?php echo $value['fontsize']; ?>pt; line-height:30px;">                 <a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇日志" style="color:rgb(<?php echo(rand(0,255)); ?>,<?php echo(rand(0,255)); ?>,<?php echo(rand(0,255)); ?>)"><?php echo $value['tagname']; ?></a></span>                 <?php endforeach; ?></p></div>			<?php else: ?><h1><?php echo $log_title; ?></h1><div id="post"><div class="nrtcksx"><div class="datetime"><?php echo gmdate('Y-n-j', $date); ?></div></div><p><?php echo $log_content; ?></p></div>			<?php endif; ?>
				<div id="comments">
				<?php blog_comments($comments); ?>                <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>				
                </div>
            </div>

<?php include View::getView('side'); include View::getView('footer');?>
