<?php /** 首页日志列表部分*/if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div class="txtlist">
<ul><?php doAction('index_loglist_top'); ?><?php foreach($logs as $value): ?>
<li><h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
<p><?php echo $value['log_description']; ?></p><span class="info"><?php blog_author($value['author']); ?> / <?php blog_sort($value['logid']); ?> / <?php echo gmdate('Y-n-j', $value['date']); ?>&nbsp;/&nbsp;<a href="<?php echo $value['log_url']; ?>#comments" class="CommentsNumber"><?php if($value['comnum']==0){echo 'No Comments';}elseif($value['comnum']==1){echo '1 Comment';}else{echo $value['comnum'].' Comments';} ?></a>&nbsp;/&nbsp;<?php echo $value['views']; ?></span></li><?php endforeach; ?>
</ul>

</div>
<div id="pagenavi">	<?php echo $page_url;?></div>
<?php include View::getView('side'); include View::getView('footer');?>