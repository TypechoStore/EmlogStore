<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?><div class="nrsin">
    <ul>
    <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    ?> 
    <li class="li">	<div class="category-audiozz">
    <div class="wznrkzztx"><img src="<?php echo $avatar; ?>" width="42px" height="42px" /></div>
	<div class="category-audiodp"><?php echo $val['t'];?></div>
    </div>    <div style="clear:both;"></div>   	<ul id="r_<?php echo $tid;?>" class="r"></ul>
    </li>
    <?php endforeach;?>
	
    </ul>
</div>   	<div id="pagenavi"><?php echo $pageurl;?></div>
<!--end content-->
<?php
 include View::getView('footer');
?>