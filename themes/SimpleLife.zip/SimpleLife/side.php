<?php 

/*

* 侧边栏

*/

if(!defined('EMLOG_ROOT')) {exit('error!');} 

?>


<?php if ($curpage== CURPAGE_HOME || $curpage == CURPAGE_TW ) { ?>
<div class="tool">
<h2>Search</h2>
<?php widget_search(''); ?>
</div>
<div class="tool">
<h2>Recents</h2>
<ul>
<?php widget_newcomm(''); ?>
</ul>
</div>
<div class="tool">
<h2>一些友链</h2>
<?php widget_link(''); ?>
</div>
<?php } else { ?>
<div class="tool">
<h2>Archives</h2>
<ul>
<?php widget_archive(''); ?>
</ul>
</div>
<div class="tool">
<h2>一些友链</h2>
<?php widget_link(''); ?>
</div>

<?php } ?>

