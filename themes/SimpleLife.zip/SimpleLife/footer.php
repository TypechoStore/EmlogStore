<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="footer">© 2012 THE <?php echo $blogname; ?>™ RIGHTS RESERVED.DESIGN BY <a href="http://yanjinquan.com/blog/" target="_blank">JOYAPPLE</a> 移植 BY <a href="http://jingzipanda.com">ooxx</a> POWERED BY EMLOG.&nbsp;<a href="<?php echo BLOG_URL; ?>admin/">登录</a></div>

</div>

<?php doAction('index_footer'); ?>

</body>

</html>

