<?php
/**
 * 自建页面模板
 */
if (!defined('EMLOG_ROOT')) {
    exit('error!');
}
?>
<div id="zan-bodyer" style="padding-top: 30px;">
	<div class="container">
		<section class="row">
			<div class="col-md-8">	
												<article class="article container well">
					<!-- 面包屑 -->
					<div class="breadcrumb">
					    <i class="fa fa-home"></i> <!-- Breadcrumb NavXT 4.4.0 -->
<a title="Go to index." href="<?php echo BLOG_URL; ?>" class="home">首页</a> / <?php echo $log_title; ?>				</div>
					<!-- 面包屑 -->	
					<!-- 大型设备文章属性 -->
					<div class="hidden-xs">
						<div class="title-article">
							<h1><a href="#"><?php echo $log_title; ?>	</a></h1>
						</div>
						</div>
					<!-- 大型设备文章属性 -->
					<!-- 小型设备文章属性 -->
					<div class="visible-xs">
						<div class="title-article">
							<h4><a href="#"><?php echo $log_title; ?></a></h4>
						</div>
						
					</div>
					<!-- 小型设备文章属性 -->
					<div class="centent-article">
        <?php echo $log_content; ?>
							
				</article>
		        <div id="post-related">
			                      <a name="comments"></a>
<div class="ds-thread" data-thread-key="1719" data-author-key="1" id="ds-thread">
<div id="ds-reset">
<?php if ($com_list == "yes"): ?>

<div class="ds-comments-info">
<div class="ds-sort">
<a href="#fastpostmessage" class="ds-order-hot ds-current">快速回复</a>
</div>
<ul class="ds-comments-tabs">
<li class="ds-tab">
<a class="ds-comments-tab-duoshuo ds-current" href="#fastpostmessage"><span class="ds-highlight"><?php echo $comnum; ?></span>条评论</a></li>
</ul>
</div>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
 <?php else: ?>	
<!-- Duoshuo Comment BEGIN -->
        <script type="text/javascript">
        var duoshuoQuery = {short_name:"<?php echo _g('duoshuo_name'); ?>"};
        (function() {
                var ds = document.createElement('script');
                ds.type = 'text/javascript';ds.async = true;
                ds.src = 'http://static.duoshuo.com/embed.js';
                ds.charset = 'UTF-8';
                (document.getElementsByTagName('head')[0] 
                || document.getElementsByTagName('body')[0]).appendChild(ds);
        })();
        </script>
<!-- Duoshuo Comment END -->
<?php endif; ?>
</div>
</div>
</div>
</div>
<?php
 include View::getView('side');
?>		
</section>
	</div>
</div>
                
<?php
 include View::getView('footer');
?>