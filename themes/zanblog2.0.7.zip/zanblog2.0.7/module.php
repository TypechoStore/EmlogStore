<?php 
/**
 * 侧边栏组件、页面模块
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
if (!function_exists('_g')) {
	emMsg('请先安装<a href="https://github.com/Baiqiang/em_tpl_options" target="_blank">模板设置插件</a>', BLOG_URL . 'admin/plugins.php');
}
?><?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
<div class="visible-md visible-lg">
		<div class="panel panel-zan">
			<div class="panel-heading">
				<i class="fa fa-user"></i> <?php echo $title; ?>
				<i class="fa fa-times-circle panel-remove"></i>
				<i class="fa fa-chevron-circle-up panel-toggle"></i>
			</div>
             <ul class="excerpt">
			<?php if (!empty($user_cache[1]['photo']['src'])): ?>
			<a href="#" class="pic"><img  src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" alt="blogger"></a>
			<?php endif;?>
			<h2><?php echo $name; ?></h2>
			<div class="info"><?php echo $user_cache[1]['des']; ?></div>
		</ul>
		</div>
	</div>
	
<?php }?>
<?php
//widget：日历
function widget_calendar($title){ ?>
<div class="panel panel-zan hot">
		<div class="panel-heading">
        <i class="fa fa-calendar"></i> <?php echo $title; ?>	
				<i class="fa fa-times-circle panel-remove"></i>
				<i class="fa fa-chevron-circle-up panel-toggle"></i>
			</div>	
			<div id="calendar">
	<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
	</div>
		</div>
	
<?php }?>
<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
    <div class="panel panel-zan visible-lg">
			<div class="panel-heading">
				<i class="fa fa-tags"></i> <?php echo $title; ?>
				<i class="fa fa-times-circle panel-remove"></i>
				<i class="fa fa-chevron-circle-up panel-toggle"></i>
			</div>
			<?php foreach($tag_cache as $value): ?>
		<span style="font-size:<?php echo $value['fontsize']; ?>pt; line-height:30px;">
		<a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇文章"><?php echo $value['tagname']; ?></a></span>
	<?php endforeach; ?>
    </div>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	<div class="visible-md visible-lg">
		<div class="panel panel-zan random">
			<div class="panel-heading">
				<i class="fa fa-tasks"></i> <?php echo $title; ?>
				<i class="fa fa-times-circle panel-remove"></i>
				<i class="fa fa-chevron-circle-up panel-toggle"></i>
			</div>
	<?php
	foreach($sort_cache as $value):
		if ($value['pid'] != 0) continue;
	?>
	<li class="list-group-item">
	<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?></a>
    <span class="badge">
						<?php echo $value['lognum'] ?>
					</span>
				</li>
	
	<?php endforeach; ?>
		</div> 
	</div>
<?php }?>
<?php
//widget：最新微语
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	?>
	<div class="visible-md visible-lg">
		<div class="panel panel-zan">
			<div class="panel-heading">
				<i class="fa fa-comments"></i> <?php echo $title; ?>
				<i class="fa fa-times-circle panel-remove"></i>
				<i class="fa fa-chevron-circle-up panel-toggle"></i>
			</div>
	<ul class="list-group list-group-flush visible-lg">
     <?php foreach($newtws_cache as $value): ?>
	<?php $img = empty($value['img']) ? "" : '<a title="查看图片" class="t_img" href="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" target="_blank">&nbsp;</a>';?>
	<li class="list-group-item"><?php global $CACHE;        $user_cache = $CACHE->readCache('user');$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?><?php if (!empty($user_cache[1]['photo']['src'])): ?>        <img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" class="avatar avatar-40 photo avatar-default" height="40" width="40" /><?php endif;?><span class="comment-log"><a href="/t"><?php echo $value['t']; ?><?php echo $img;?></a></span></li>
	<?php endforeach; ?>
    </ul>
	</li>
    </div>
    </div>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
	<div class="visible-md visible-lg">
		<div class="panel panel-zan">
			<div class="panel-heading">
				<i class="fa fa-comments"></i> <?php echo $title; ?>
				<i class="fa fa-times-circle panel-remove"></i>
				<i class="fa fa-chevron-circle-up panel-toggle"></i>
			</div>
            <!-- 大屏PC端 -->
            <ul class="list-group list-group-flush visible-lg">
	<?php
	foreach($com_cache as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	?>
    <li class="list-group-item"><img title="<?php echo $value['name']; ?>" src="<?php echo getGravatar($value['mail']); ?>" class="avatar avatar-40 photo avatar-default" height="40" width="40"><span class="comment-log"> <a href="<?php echo $url; ?>"><?php echo preg_replace("/\{smile:(([1-4]?[0-9])|50)\}/",'<img src="/content/templates/zanblog2.0.7/face/$1.gif" height="16">',$value['content']);?></span></a></li>
	<?php endforeach; ?>
	</ul>
    <!-- 小屏PC端 -->
			<ul class="list-group list-group-flush visible-md">
            <?php
	foreach($com_cache as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	?>
    <li class="list-group-item"><img title="<?php echo $value['name']; ?>" src="<?php echo getGravatar($value['mail']); ?>" class="avatar avatar-40 photo avatar-default" height="40" width="40"><span class="comment-log"> <a href="<?php echo $url; ?>"><?php echo preg_replace("/\{smile:(([1-4]?[0-9])|50)\}/",'<img src="/content/templates/zanblog2.0.7/face/$1.gif" height="16">',$value['content']);?></span></a></li>
	<?php endforeach; ?>
	</ul>
    </div>
	</div>
<?php }?>
<?php
//widget：最新文章
function widget_newlog($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
<div class="panel panel-zan hot">
		<div class="panel-heading">
			<i class="fa fa-refresh"></i> <?php echo $title; ?>
			<i class="fa fa-times-circle panel-remove"></i>
			<i class="fa fa-chevron-circle-up panel-toggle"></i>
		</div>
        		<!-- 大屏PC端-->
		<ul class="list-group list-group-flush visible-lg">
	<?php foreach($newLogs_cache as $value): ?>
	<li class="list-group-item"><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
    <!-- 小屏PC端-->
		<ul class="list-group list-group-flush visible-md">
        <?php foreach($newLogs_cache as $value): ?>
	<li class="list-group-item"><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
    <!-- 平板端 -->
		<ul class="list-group list-group-flush visible-sm">
              <?php foreach($newLogs_cache as $value): ?>
	<li class="list-group-item"><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
    <!-- 手机端  -->
		<ul class="list-group list-group-flush visible-xs">
                <?php foreach($newLogs_cache as $value): ?>
	<li class="list-group-item"><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
    </div>
<?php }?>
<?php
//widget：热门文章
function widget_hotlog($title){
	$index_hotlognum = Option::get('index_hotlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getHotLog($index_hotlognum);?>
	<div class=" visible-md visible-lg">
		<div class="panel panel-zan recent">
			<div class="panel-heading">
				<i class="fa fa-fire"></i> <?php echo $title; ?>
				<i class="fa fa-times-circle panel-remove"></i>
				<i class="fa fa-chevron-circle-up panel-toggle"></i>
			</div>
            <ul class="list-group list-group-flush">
            <?php foreach($randLogs as $value): ?>
	
				<li class="list-group-item">
					<a href="<?php echo Url::log($value['gid']); ?>">
						
						<div class="visible-lg"><?php echo $value['title']; ?></div>
						
						<div class="visible-md"><?php echo $value['title']; ?></div>
					</a>
				
				</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</div>
	
<?php }?>
<?php
//widget：随机文章
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	<!-- 随机文章模块 -->
	<div class="visible-md visible-lg">
		<div class="panel panel-zan random">
			<div class="panel-heading">
				<i class="fa fa-random"></i> <?php echo $title; ?>
				<i class="fa fa-times-circle panel-remove"></i>
				<i class="fa fa-chevron-circle-up panel-toggle"></i>
			</div>
			<ul class="list-group list-group-flush">
	<?php foreach($randLogs as $value): ?>
	<li class="list-group-item"><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
				</ul>
		</div> 
	</div>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
	<div class="visible-md visible-lg">
		<div class="panel panel-zan host">		
			<form name="keyform" method="get" id="searchform" class="form-inline" action="<?php echo BLOG_URL; ?>index.php">
	<input name="keyword"  type="text" class="form-control" placeholder="搜索...">
	</form>
		</div>
	
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
	<div class=" visible-md visible-lg">
		<div class="panel panel-zan recent">
			<div class="panel-heading">
				<i class="fa  fa-calendar-o"></i> <?php echo $title; ?>
				<i class="fa fa-times-circle panel-remove"></i>
				<i class="fa fa-chevron-circle-up panel-toggle"></i>
			</div>
	<?php foreach($record_cache as $value): ?>
	<li class="list-group-item"><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?></a>
    <span class="badge"><?php echo $value['lognum']; ?></span>
    </li>
	<?php endforeach; ?>
    </div>
	</div>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
	<div class=" visible-md visible-lg">
		<div class="panel panel-zan recent">
			<div class="panel-heading">
				<i class="fa fa-tablet"></i> <?php echo $title; ?>
				<i class="fa fa-times-circle panel-remove"></i>
				<i class="fa fa-chevron-circle-up panel-toggle"></i>
			</div>
	<ul class="list-group list-group-flush">
	<?php echo $content; ?>
	</ul>
    </div>
    </div>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
    //if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
	?>
	<div class=" visible-md visible-lg">
		<div class="panel panel-zan recent">
			<div class="panel-heading">
				<i class="fa fa-unlink"></i> <?php echo $title; ?>
				<i class="fa fa-times-circle panel-remove"></i>
				<i class="fa fa-chevron-circle-up panel-toggle"></i>
			</div>
	<?php foreach($link_cache as $value): ?>
	<li class="list-group-item"><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
	<?php endforeach; ?>
	</div>
    </div>
<?php }?> 
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	?>
<ul id="menu-navbar" class="nav navbar-nav">
	<?php
	foreach($navi_cache as $value):
		if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):
			?>
            			 <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
			  <li id="menu-item" class="dropdown menu-item menu-item-type-custom menu-item-object-custom menu-item">
<a href="<?php echo BLOG_URL; ?>admin/"><i class="fa fa-cog"></i> 管理站点</a>
<ul class="dropdown-menu">
<li id="menu-item" class="menu-item menu-item-type-custom menu-item-object-custom menu-item"><a href="<?php echo BLOG_URL; ?>admin/comment.php">评论</a></li>
<li id="menu-item" class="menu-item menu-item-type-custom menu-item-object-custom menu-item">
<a href="<?php echo BLOG_URL; ?>admin/write_log.php">发表</a></li>
<li id="menu-item" class="menu-item menu-item-type-custom menu-item-object-custom menu-item">
<a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
</ul>
			 <?php else: ?>

           <li id="menu-item" class="menu-item menu-item-type-custom menu-item-object-custom menu-item">
<a href="<?php echo BLOG_URL; ?>admin/"><i class="fa fa-cog"></i> 登录</a></li>
			   <?php endif; ?>

			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
                $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
                $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'current-menu-item current_page_item menu-item-home menu-item' : '';
		?>
<li id="menu-item" class="<?php if (!empty($value['children'])) :?>dropdown<?php endif;?> menu-item menu-item-type-custom menu-item-object-custom <?php echo $current_tab;?>" >
                <a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a>
                <?php if (!empty($value['children'])) :?>
               <ul class="dropdown-menu">
                <?php foreach ($value['children'] as $row){
                        echo '<li id="menu-item" class="menu-item menu-item-type-custom menu-item-object-custom menu-item"><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></li>';
                }?>
		</ul>
                <?php endif;?>
                </li>
	<?php endforeach; ?>
	</ul>
<?php }?>
<?php
//blog：置顶
function topflg($istop){
	$topflg = $istop == 'y' ? "<img src=\"".TEMPLATE_URL."/images/import.gif\" title=\"置顶文章\" /> " : '';
	echo $topflg;
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
	<a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
	<?php endif;?>
<?php }?>
<?php
//blog：文章标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		foreach ($log_cache_tags[$blogid] as $value){
			$tag = "	<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
		}
		echo $tag;
	}
}
?>
<?php
//blog：文章作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog):?>
	<li class="previous"><a href="<?php echo Url::log($prevLog['gid']) ?>" title="<?php echo $prevLog['title'];?>">上一篇</a></li>
	<?php endif;?>
	
	<?php if($nextLog):?>
		<li class="next"> <a href="<?php echo Url::log($nextLog['gid']) ?>" title="<?php echo $nextLog['title'];?>">下一篇</a></li>
	<?php endif;?>
<?php }?>
<?php
//blog：评论列表
function blog_comments($comments){
    extract($comments);
    if($commentStacks): ?>
	<a name="comments"></a>
	<?php endif; ?>
	<?php
	$isGravatar = Option::get('isgravatar');
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank" class="ds-user-name ds-highlight">'.$comment['poster'].'</a>' : $comment['poster'];	?>
<a name="<?php echo $comment['cid']; ?>"></a>
<li class="ds-post">
<div class="ds-post-self" data-root-id="0" data-source="duoshuo">
<div class="ds-avatar">
<?php if($isGravatar == 'y'): ?>
<img src="<?php echo getGravatar($comment['mail']); ?>" data-bd-imgshare-binded="1">
<?php endif; ?>
</div>
<div class="ds-comment-body">
<div class="ds-comment-header">
<?php echo $comment['poster']; ?>
</div>
<p><?php echo preg_replace("/\{smile:(([1-4]?[0-9])|50)\}/",'<img src="/content/templates/zanblog2.0.7/face/$1.gif" height="16">',$comment['content']);?></p>
<div class="ds-comment-footer ds-comment-actions">
<span class="ds-time"><?php echo $comment['date']; ?></span>
<a class="ds-post-reply" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)"><span class="ds-icon ds-icon-reply"></span>回复</a>
</div>
</div>
</div>
</li>

		<?php blog_comments_children($comments, $comment['children']); ?>
        
	<?php endforeach; ?>
<div id="pagesnav"><?php echo $commentPageUrl;?></div>   
<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank" class="ds-user-name ds-highlight">'.$comment['poster'].'</a>' : $comment['poster'];	?>
		<a name="<?php echo $comment['cid']; ?>"></a>
<ul class="ds-children">
<li  data-post-id="<?php echo $comment['cid']; ?>" class="ds-post">
<div class="ds-post-self" data-post-id="<?php echo $comment['cid']; ?>" data-thread-id="<?php echo $comment['cid']; ?>" data-root-id="<?php echo $comment['cid']; ?>" data-source="duoshuo">
<div class="ds-avatar" data-user-id="<?php echo $comment['cid']; ?>">
		<?php if($isGravatar == 'y'): ?>
<img src="<?php echo getGravatar($comment['mail']); ?>"  data-bd-imgshare-binded="1">
<?php endif; ?>
</div>
<div class="ds-comment-body">
<div class="ds-comment-header">
<a class="ds-user-name ds-highlight" data-qqt-account=""  rel="nofollow" target="_blank" data-user-id="<?php echo $comment['cid']; ?>"><?php echo $comment['poster']; ?> </a>
</div>
<p><div class="hf_<?php echo $comment['cid']; ?>"><?php echo preg_replace("/\{smile:(([1-4]?[0-9])|50)\}/",'<img src="/content/templates/zanblog2.0.7/face/$1.gif" height="16">',$comment['content']);?></div></p>
<div class="ds-comment-footer ds-comment-actions">
<span class="ds-time" ><?php echo $comment['date']; ?></span>
<a class="ds-post-reply" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)""><span class="ds-icon ds-icon-reply"></span>回复</a>
</div>
</div>
</div>
</li></ul>
		<?php blog_comments_children($comments, $comment['children']);?>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>

       	<div id="comment-place">
	<div class="comment-post" id="comment-post">
	<div id="respond" class="no_webshot">
		<form action="<?php echo BLOG_URL; ?>index.php?action=addcom" method="post" id="commentform">
        		<div class="comt">

<div class="ds-login-buttons">
<p>发表评论:</p>
<div class="ds-social-links">
<ul class="ds-service-list">
<li><a id="cancel-reply" class="ds-more-services" style="display:none;text-decoration:none" href="javascript:void(0);" onclick="cancelReply()">取消</a></li>
</ul>
</div>
</div>	
            <div class="ds-replybox">

			<a class="ds-avatar" href="http://www.gravatar.com/"  target="_blank">
<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
      <?php
				global $CACHE;
				$user_cache = $CACHE->readCache('user');
				$name = $user_cache[UID]['name'];?>
<img   src="<?php echo BLOG_URL.$user_cache[UID]['photo']['src']; ?>" >
<?php else:?>
      <img src="<?php echo getGravatar(strtolower($ckmail), 64); ?>" />
<?php endif; ?>
</a>
			<div class="comt-box">
			<div class="ds-textarea-wrapper ds-rounded-top">
<textarea  name="comment" onkeydown="if(event.ctrlKey&&event.keyCode==13){document.getElementById('submit').click();return false};" title="Ctrl+Enter快捷提交" placeholder="说点什么吧…" id="fastpostmessage" <?php if($ckname == ''):?> onclick="show_div()"<?php endif;?>></textarea>
<pre class="ds-hidden-text"></pre>

	</div>			
<div class="ds-post-toolbar">
<div class="ds-post-options ds-gradient-bg">
<?php include View::getView('smiley');?>
</div>
<button class="ds-post-button" type="submit">发布</button><div class="ds-toolbar-buttons">
</div>		
			<input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/>
			</div>
			<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
            <div class="comt-comterinfo" id="comment-author-info" >
				<h4>Hi，您需要填写昵称和邮箱！</h4>
				<ul>
					<li><input class="ipt" type="text" name="comname" id="author" placeholder="昵称" value="<?php echo $ckname; ?>" size="28" tabindex="2"><span>必填项</span> </li>
					<li><input class="ipt" type="mail" name="commail" placeholder="邮箱" id="commail"  value="<?php echo $ckmail; ?>" size="28" tabindex="3"><span>必填项</span></li>
                    <li class="comt-comterinfo-url"><input class="ipt" type="comurl" name="comurl" id="comurl" placeholder="你的主页" value="<?php echo $ckurl; ?>" size="42" tabindex="4"></li>
					<li><?php echo $verifyCode; ?></li>
					
				</ul>
			</div>
			<?php else:
          $CACHE = Cache::getInstance();
	       $user_cache = $CACHE->readCache('user');
        ?>
		<?php endif; ?>
		</div>
        </div>
        </div>
	    </form>
	</div>
	
	</div>
	</div>


        
<?php }?>
<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>
<?php
//Custom: 获取附件第一张图片
function getThumbnail($blogid){
    $db = MySql::getInstance();
    $sql = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$blogid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";
    //die($sql);
    $imgs = $db->query($sql);
    $img_path = "";
    while($row = $db->fetch_array($imgs)){
         $img_path .= BLOG_URL.substr($row['filepath'],3,strlen($row['filepath']));
    }
    return $img_path;
}
?>
<?php
//blog：自定义分页函数
function my_page($count, $perlogs, $page, $url, $anchor = '') {
 $pnums = @ceil($count / $perlogs);
 $re = '';
 $urlHome = preg_replace("|[\?&/][^\./\?&=]*page[=/\-]|", "", $url);
 if($page < $pnums) {
  $i = $page + 1;
  $re .= " 
  
  <a id='load-more' class='btn btn-zan btn-block' load-data='努力加载中...' href='".$url.$i."'><i></i> <attr>加载更多</attr></a>
   ";
 }
 return $re;
}
?>

<?php
//slide数据源
function get_flash_data($num){
	$db = MySql::getInstance();
	$sql = "SELECT gid,title,date,content FROM ".DB_PREFIX."blog WHERE hide='n' ORDER BY `date` DESC LIMIT 0,$num";
	$go = $db->query($sql);
		while($row = $db->fetch_array($go)){
			$img_url = '';
			if(pic_thumb($row['content'])){
				$img_url = pic_thumb($row['content']);
				$data = '<li style="display: block;" class="clone" aria-hidden="true"><a href="'.Url::log($row['gid']).'" target="_self" ><img src="'.$img_url.'" stitle="'.$row['title'].'"  id="topimg" class="slider-411 slide-550" draggable="false"></li>';
				echo $data;
			}
		}
?>
			 
<?php
}?>
<?php
//get thumbs（图片链接）
function pic_thumb($content){
    //preg_match_all全局匹配content中的图片地址，并存入$img变量
    preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $content, $img);
    //当图片存在时，获取第一张图片，地址保存在$imgsrc中
    $imgsrc = !empty($img[1]) ? $img[1][0] : '';
	if($imgsrc):
		return $imgsrc;
	endif;
}
?>

<?php
//blog：N天内热门
function blog_ndayhot($count, $n){
    ?>
    <?php
    $curdate = time();
    $db = MySql::getInstance();
    $sql = "SELECT * FROM " . DB_PREFIX . "blog WHERE type='blog' and hide='n' and date>UNIX_TIMESTAMP()-86400*$n order by views desc limit $count";
	$ret = $db->query($sql);
    $items = array();
    global $CACHE;
	$user_cache = $CACHE->readCache('user');
	while ($row = $db->fetch_array($ret)) {
		$row['title'] = htmlspecialchars($row['title']);
        $row['excerpt'] = htmlspecialchars(strip_tags($row['excerpt']));
		$row['logurl'] = Url::log(intval($row['gid']));
        $row['author'] = '<a href="'.Url::author($row['author']).'">' . $user_cache[$row['author']]['name'].'</a>';
        $row['date'] = gmdate('Y.n.j', $row['date']);
		$items[] = $row;
	}
	foreach($items as $val):
	?>
                         <div class="col-md-4">
			                <div class="thumbnail">
			                    <div class="caption">
									<p class="post-related-title"><a href="<?php echo $val['logurl']; ?>" rel="bookmark" ><?php echo $val['title']; ?></a></p>
									<p class="post-related-content"><?php echo $val['excerpt'] = subString(trim(strip_tags($val['excerpt'])), 0, 80);?></p>
									<p><a class="btn btn-danger pull-right read-more" href="<?php echo $val['logurl']; ?>">阅读全文</a></p>							
								</div>
			                </div>					                
			            </div>
	<?php endforeach; ?>
    <?php }?>

<?php
//文章关键词
function log_key_words($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .="".$value['tagname'].',';
		}
		echo substr($tag,0,-1);
	}
}
?>
