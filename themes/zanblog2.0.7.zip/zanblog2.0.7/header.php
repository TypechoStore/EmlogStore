<?php
/*
Template Name:zanblog模板
Description:自适应模板，简洁优雅
Version:1.2
Author:flyer
Author Url:http://flyer.pytalhost.com/
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
extract(_g());
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<?php if (isset($logid)) : ?>
<meta name="keywords" content="<?php log_key_words($logid); ?>" />
<?php elseif (isset($sortName)) : ?>
<meta name="keywords" content="<?php echo _g('sortKeywords.'.$sortid); ?>" />
<?php else : ?>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<?php endif; ?>
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<meta content="<?php echo trim($description); ?>" name="description"/>
<meta content="<?php echo rtrim($keywords,','); ?>" name="keywords"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel='stylesheet' id='zanblog-style-css'  href='<?php echo TEMPLATE_URL; ?>style.css?ver=2.0.7' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-style-css'  href='<?php echo TEMPLATE_URL; ?>ui/css/bootstrap.css?ver=3.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='fontawesome-style-css'  href='<?php echo TEMPLATE_URL; ?>ui/font-awesome/css/font-awesome.min.css?ver=4.0.1' type='text/css' media='all' />
<link rel='stylesheet' id='icheck-style-css'  href='<?php echo TEMPLATE_URL; ?>ui/css/flat/red.css?ver=3.6' type='text/css' media='all' />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script type='text/javascript' src='<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js?ver=1.7.1'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>ui/js/jquery-migrate.min.js?ver=1.2.1'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>ui/js/bootstrap.js?ver=3.0.0'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>ui/js/jquery.icheck.js?ver=3.6'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>ui/js/zanblog.js?ver=2.0.7'></script>
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
<style type="text/css" id="syntaxhighlighteranchor"></style>
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements Responsive IE8-->
<!--[if lt IE 9]>
  <script src="<?php echo TEMPLATE_URL; ?>ui/js/modernizr.js"></script>
  <script src="<?php echo TEMPLATE_URL; ?>ui/js/html5shiv.js"></script>
<![endif]-->
<?php doAction('index_head'); ?>
</head>
<body <?php if (blog_tool_ishome()) : ?>class="home blog"<?php else:?>class="single single-post postid-531 single-format-standard" <?php endif; ?>>
<header id="zan-header" class="navbar navbar-inverse bs-docs-nav">
  <nav class="container">
  <?php if ($top_logo == "yes"): ?>
    <a href="<?php echo BLOG_URL; ?>"><div class="navbar-brand"></div></a>
    <?php else: ?>	
    <div id="iogo">
<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>
</div>
<?php endif; ?>
    <button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse">
      <span class="sr-only">Toggle navigation</span>
      <span class="fa fa-reorder fa-lg"></span>
    </button>
    <div class="navbar-collapse bs-navbar-collapse collapse">
 <?php blog_navi(); ?>
       <div class="search visible-lg">			<div class="textwidget"></div>
		</div>        <div class="search visible-lg">
           <form method="get" id="searchform" class="form-inline" action="<?php echo BLOG_URL; ?>index.php">
              <input class="form-control" type="text" name="keyword" id="s"  placeholder="搜索...">
              <button type="submit" class="btn btn-danger btn-small" name="submit"><i class="fa fa-search"></i></button>
           </form>
        </div>
          </div>
  </nav>
<div id="if-fixed" class="pull-right visible-lg visible-md">
    <i class="fa fa-thumb-tack"></i>
    <input type="checkbox">
  </div>
</header>