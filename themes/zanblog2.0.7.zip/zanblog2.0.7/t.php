<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<section id="zan-bodyer">
	<div class="container">
		<section class="row">
			<section id="mainstay" class="col-md-8">
				<!-- 面包屑 -->
					<div class="breadcrumb">
					    <i class="fa fa-home"></i> <!-- Breadcrumb NavXT 4.4.0 -->
<a title="Go to index." href="<?php echo BLOG_URL; ?>" class="home">首页</a> / 微语</div>
					<!-- 面包屑 -->	
 <div class="ds-thread"  id="ds-thread">
<div id="ds-reset">
 <ul class="ds-comments">

  <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?> 
<li class="ds-post" data-post-id="1252323952827565840">
<div class="ds-post-self" data-post-id="1252323952827565840" data-thread-id="1252323952827564275" data-root-id="0" data-source="duoshuo">
<div class="ds-avatar" data-user-id="4674353">
<img src="<?php echo $avatar; ?>" data-bd-imgshare-binded="1">
</div>
<div class="ds-comment-body">
<div class="ds-comment-header">
<?php echo $author; ?>
</div>
<p><?php echo $val['t'].'<br/>'.$img;?></p>
<div class="ds-comment-footer ds-comment-actions">
<span class="ds-time"><?php echo $val['date']; ?></span>
</div>
</div>
</div>
 </li>
    <?php endforeach;?>
     </ul>
</div>
</div>
</section>
<?php
 include View::getView('side');
?>
<div class="col-md-8">
<div id="pagesnav"><?php echo $pageurl;?></div>
</div>

		</section>
	</div>
</section><!-- end #contentleft-->


<?php

 include View::getView('footer');
?>