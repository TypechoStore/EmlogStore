<?php
/**
 * 自定义404页面
 */
if (!defined('EMLOG_ROOT')) {
    exit('error!');
}
?>
<?php
include View::getView('header');
?>

<div id="content" class="site-content" role="main">
	<div class="alert alert-danger text-center">
		<h1 class="page-title"><i class="fa fa-frown-o"></i> 无法找到该页面（404）</h1>
	</div>
	<div class="page-content well text-center">
		<h2>很遗憾，你所要寻找的页面已经丢失或者已经被删除。</h2>
		<h3>你可以回到 <a href="<?php echo BLOG_URL; ?>"><i class="fa fa-mail-forward"></i> <?php echo $blogname; ?></a></h3>
	</div>
</div>
<?php
include View::getView('footer');
?>
