<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="zan-bodyer" style="padding-top: 30px;">
	<div class="container">
		<section class="row">
			<div class="col-md-8">	
					<article class="article container well">
					<!-- 面包屑 -->
					<div class="breadcrumb">
					    <i class="fa fa-home"></i> <!-- Breadcrumb NavXT 4.4.0 -->
<a title="Go to index." href="<?php echo BLOG_URL; ?>" class="home">首页</a> / <?php echo $log_title; ?>				</div>
					<!-- 面包屑 -->	
					<!-- 大型设备文章属性 -->
					<div class="hidden-xs">
						<div class="title-article">
							<h1><a href="#"><?php echo $log_title; ?>	</a></h1>
						</div>
						<div class="tag-article container">
							<span class="label label-zan"><i class="fa fa-clock-o"></i> <?php echo gmdate('Y-n-j G:i', $date); ?></span>
							<span class="label label-zan"><i class="fa fa-tags"></i> <?php blog_sort($logid); ?></span>
							<span class="label label-zan"><i class="fa fa-user"></i> <?php blog_author($author); ?></span>
							<span class="label label-zan"><i class="fa fa-eye"></i> <?php echo $views; ?>人</span>
						</div>
					</div>
					<!-- 大型设备文章属性 -->
					<!-- 小型设备文章属性 -->
					<div class="visible-xs">
						<div class="title-article">
							<h4><a href="#"><?php echo $log_title; ?></a></h4>
						</div>
						<p>
							<i class="fa fa-calendar"></i> <?php echo gmdate('m-d', $date); ?>							<i class="fa fa-eye"></i> <?php echo $views; ?>人						</p>
					</div>
					<!-- 小型设备文章属性 -->
					<div class="centent-article">
														<?php echo $log_content; ?>
				        <!-- 分页 -->
                        <div clas="zan-page bs-example">
					        <ul class="pager">
								<?php neighbor_log($neighborLog); ?>
							</ul>
				        </div>
                        <?php doAction('log_related', $logData); ?>
                                            <?php if ($cop_list == "yes"): ?>

						<!-- 文章版权信息 -->
						<div class="copyright alert alert-success">
							<p>版权属于：<a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>"><?php echo $blogname; ?></a></p>
							<p>原文地址：<a href="<?php echo BLOG_URL; ?>?post=<?php echo $logid; ?>"><?php echo BLOG_URL; ?>?post=<?php echo $logid; ?></a></p>
							<p>转载时必须以链接形式注明原始出处及本声明。</p>
						</div>
						<!-- 文章版权信息 -->
									  <?php else: ?>	
<?php endif; ?>
				</article>
								<!-- 相关文章 -->
		        <div id="post-related">
					<div class="row">
                    <?php if ($like_list == "yes"): ?>

						<div class="alert alert-danger related-title">您可能也喜欢:</div>
			            <?php
			blog_ndayhot(3,400);
            ?>
                 <?php else: ?>	
<?php endif; ?>
                        <a name="comments"></a>
<div class="ds-thread" data-thread-key="1719" data-author-key="1" id="ds-thread">
<div id="ds-reset">
<?php if ($com_list == "yes"): ?>

<div class="ds-comments-info">
<div class="ds-sort">
<a href="#fastpostmessage" class="ds-order-hot ds-current">快速回复</a>
</div>
<ul class="ds-comments-tabs">
<li class="ds-tab">
<a class="ds-comments-tab-duoshuo ds-current" href="#fastpostmessage"><span class="ds-highlight"><?php echo $comnum; ?></span>条评论</a></li>
</ul>
</div>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
 <?php else: ?>	
<!-- Duoshuo Comment BEGIN -->
        <script type="text/javascript">
        var duoshuoQuery = {short_name:"<?php echo _g('duoshuo_name'); ?>"};
        (function() {
                var ds = document.createElement('script');
                ds.type = 'text/javascript';ds.async = true;
                ds.src = 'http://static.duoshuo.com/embed.js';
                ds.charset = 'UTF-8';
                (document.getElementsByTagName('head')[0] 
                || document.getElementsByTagName('body')[0]).appendChild(ds);
        })();
        </script>
<!-- Duoshuo Comment END -->
<?php endif; ?>
</div>
</div>
</div>
</div>
</div>	
<?php
 include View::getView('side');
?>		
</section>
	</div>
</div>
                
<?php
 include View::getView('footer');
?>