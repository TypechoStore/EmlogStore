<?php 
/**
 * 侧边栏
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<aside id="sidebar"  class="col-md-4">
<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>
<?php if ($side_list == "yes"): ?>
<div class="panel hidden-xs">
		<ul class="nav nav-pills pills-zan">
			<li class="active"><a href="#sidebar-categories" data-toggle="tab">分类目录</a></li>
			<li class=""><a href="#sidebar-tags" data-toggle="tab">热门标签</a></li>
						<li class=""><a href="#sidebar-links" data-toggle="tab">友情链接</a></li>
					</ul>
		<div class="tab-content">
			<div class="tab-pane nav bs-sidenav fade active in" id="sidebar-categories">
            		<?php global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
    <?php
	foreach($sort_cache as $value):
		if ($value['pid'] != 0) continue;
	?>
   <li class="cat-item cat-item-21" style="width:50%;float:left"><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a></li>
    		<?php endforeach; ?>
</div>
			<div class="tab-pane fade" id="sidebar-tags">
           <?php global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
	<?php 
		
		foreach($tag_cache as $value):
		$color = dechex(rand(0,16777215)); ?>
        			<a  href="<?php echo Url::tag($value['tagurl']); ?>"  class="tag-link-22" style="color:#<?php echo $color;?>;font-size: <?php echo rand(0, 10) ?>pt;;" title="<?php echo $value['usenum']; ?>"><?php echo $value['tagname']; ?></a>
        <?php endforeach; ?>
           </div>
						<div class="tab-pane nav bs-sidenav fade" id="sidebar-links">
                        <?php global $CACHE; 
	$link_cache = $CACHE->readCache('link');?>
                        <?php foreach($link_cache as $value): ?>
	<li style="width:50%;float:left"><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
	<?php endforeach; ?>
</div>
					</div>
	</div>
<!-- 文章存档模块	 -->
	<div class="panel visible-md visible-lg archive">
		<a href="?plugin=archiver">
			<div class="panel-heading">			
				<i class="fa fa-folder-open"></i> <span>文章存档</span>			
			</div>
		</a>
	</div>
     <?php else: ?>	
<?php endif; ?>
	</aside><!--end #siderbar-->
