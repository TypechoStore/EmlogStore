<?php

/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
	'top_logo' => array(
		'type' => 'radio',
		'name' => '是否显示图片logo',
		'values' => array(
			'yes' => '是',
			'no' => '否',
		),
		'default' => 'yes',
	),
	'top_img' => array(
	    'type' => 'radio',
		'name' => '是否显示首页幻灯图片',
		'values' => array(
			'yes' => '是',
			'no' => '否',
		),
		'default' => 'yes',
	),
'sortKeywords' => array(
		'type' => 'text',
		'name' => '分类关键词设置（多个关键词之间用半角逗号隔开）',
		'depend' => 'sort',
		'description' => '设置每个分类页面显示的关键词',
		'default' => '设置关键词，请不要留空',
	),
'com_list' => array(
		'type' => 'radio',
		'name' => '是否使用自带评论',
		'description' => '如果使用多说请填写下面的二级域名',
		'values' => array(
			'yes' => '是',
			'no' => '否',
		),
		'default' => 'yes',
	),
    'duoshuo_name' => array(
		'type' => 'text',
		'name' => '请填写你的多说二级域名，abc.duoshuo.com,只有abc',
		'default' => 'abc',
	),
'cop_list' => array(
		'type' => 'radio',
		'name' => '是否显示文章版权',
		'values' => array(
			'yes' => '是',
			'no' => '否',
		),
		'default' => 'yes',
	),
        'like_list' => array(
		'type' => 'radio',
		'name' => '文章内你也喜欢功能',
		'values' => array(
			'yes' => '是',
			'no' => '否',
		),
		'default' => 'yes',
	),
	'side_list' => array(
		'type' => 'radio',
		'name' => '是否显示自定义侧栏 分类、标签、友链',
		'values' => array(
			'yes' => '是',
			'no' => '否',
		),
		'default' => 'yes',
	),

	'foot_theme' => array(
		'type' => 'radio',
		'name' => '是否显示底部主题版权',
		'values' => array(
			'yes' => '是',
			'no' => '否',
		),
		'default' => 'yes',
	),
	'foot_emlog' => array(
		'type' => 'radio',
		'name' => '是否显示底部emlog版权',
		'values' => array(
			'yes' => '是',
			'no' => '否',
		),
		'default' => 'yes',
	),
	
);
