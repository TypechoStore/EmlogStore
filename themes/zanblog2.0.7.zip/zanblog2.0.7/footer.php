<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<footer id="zan-footer">	    
			© 2013 <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>
			<?php if ($foot_theme == "yes"): ?>Theme <a href="http://www.yeahzan.com/" target="_blank">佚站互联</a><?php else: ?><?php endif; ?>
			<?php if ($foot_emlog == "yes"): ?>Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> <?php else: ?><?php endif; ?>
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
<?php doAction('index_footer'); ?>
<script>prettyPrint();</script>
</footer>
<div style="display: none;" class="fa fa-angle-up" id="gotop"></div>
<script type='text/javascript'>
	backTop=function (btnId){
		var btn=document.getElementById(btnId);
		var d=document.documentElement;
		var b=document.body;
		window.onscroll=set;
		btn.onclick=function (){
			btn.style.display="none";
			window.onscroll=null;
			this.timer=setInterval(function(){
				d.scrollTop-=Math.ceil((d.scrollTop+b.scrollTop)*0.1);
				b.scrollTop-=Math.ceil((d.scrollTop+b.scrollTop)*0.1);
				if((d.scrollTop+b.scrollTop)==0) clearInterval(btn.timer,window.onscroll=set);
			},10);
		};
		function set(){btn.style.display=(d.scrollTop+b.scrollTop>100)?'block':"none"}
	};
	backTop('gotop');
</script>
<script type='text/javascript'>
 /* <![CDATA[ */
var infinite_scroll = "{\"loading\":{\"msgText\":\"\",\"finishedMsg\":\"<p class=\\\"alert alert-danger\\\"><i class=\\\"fa fa-warning\\\"><\\\/i> \内\容\加\载\完\毕<\\\/p>\"},\"nextSelector\":\"#load-more\",\"navSelector\":\"#load-more\",\"itemSelector\":\".article\",\"contentSelector\":\"#mainstay\",\"debug\":false,\"behavior\":\"twitter\",\"callback\":\"jQuery(\\\"#load-more\\\").removeClass(\\\"disabled\\\");\\r\\njQuery(\\\"#load-more i\\\").removeClass(\\\"fa fa-spinner\\\");\\r\\njQuery(\\\"#load-more attr\\\").text(\\\"\加\载\更\多\\\");\",\"theme\":\"zanblog\"}"; /* ]]> */
</script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>ui/js/infinitescroll.min.js?ver=2.6.1'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>ui/js/manual-trigger.js?ver=2.6.1'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>ui/js/jquery.flexslider-min.js?ver=2.3'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>ui/js/jQuery.easing.min.js?ver=2.3'></script>
<script type="text/javascript">
// Because the `wp_localize_script` method makes everything a string
infinite_scroll = jQuery.parseJSON(infinite_scroll);
jQuery( infinite_scroll.contentSelector ).infinitescroll( infinite_scroll, function(newElements, data, url) { eval(infinite_scroll.callback); });
</script>