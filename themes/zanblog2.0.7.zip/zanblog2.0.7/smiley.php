<script type="text/javascript" language="javascript">
/* <![CDATA[ */
    function grin(tag) {
    	var myField;
    	tag = ' ' + tag + ' ';
        if (document.getElementById('fastpostmessage') && document.getElementById('fastpostmessage').type == 'textarea') {
    		myField = document.getElementById('fastpostmessage');
    	} else {
    		return false;
    	}
    	if (document.selection) {
    		myField.focus();
    		sel = document.selection.createRange();
    		sel.text = tag;
    		myField.focus();
    	}
    	else if (myField.selectionStart || myField.selectionStart == '0') {
    		var startPos = myField.selectionStart;
    		var endPos = myField.selectionEnd;
    		var cursorPos = endPos;
    		myField.value = myField.value.substring(0, startPos)
    					  + tag
    					  + myField.value.substring(endPos, myField.value.length);
    		cursorPos += tag.length;
    		myField.focus();
    		myField.selectionStart = cursorPos;
    		myField.selectionEnd = cursorPos;
    	}
    	else {
    		myField.value += tag;
    		myField.focus();
    	}
    }
/* ]]> */
</script>
<a href="javascript:grin('{smile:1}')"><img src="<?php echo TEMPLATE_URL; ?>face/1.gif" alt="色迷迷" title="色迷迷" /></a>
<a href="javascript:grin('{smile:2}')"><img src="<?php echo TEMPLATE_URL; ?>face/2.gif" alt="哭" title="哭" /></a>
<a href="javascript:grin('{smile:3}')"><img src="<?php echo TEMPLATE_URL; ?>face/3.gif" alt="呕吐" title="呕吐" /></a>
<a href="javascript:grin('{smile:4}')"><img src="<?php echo TEMPLATE_URL; ?>face/4.gif" alt="大笑" title="大笑" /></a>
<a href="javascript:grin('{smile:5}')"><img src="<?php echo TEMPLATE_URL; ?>face/5.gif" alt="口水" title="口水" /></a>
<a href="javascript:grin('{smile:6}')"><img src="<?php echo TEMPLATE_URL; ?>face/6.gif" alt="微笑" title="微笑" /></a>
<a href="javascript:grin('{smile:7}')"><img src="<?php echo TEMPLATE_URL; ?>face/7.gif" alt="啵一个" title="啵一个" /></a>
<a href="javascript:grin('{smile:8}')"><img src="<?php echo TEMPLATE_URL; ?>face/8.gif" alt="发怒" title="发怒" /></a>
<br />