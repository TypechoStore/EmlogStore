<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<section id="zan-bodyer">
	<div class="container">
		<section class="row">
			<section id="mainstay" class="col-md-8">
				<div id="ie-warning" class="alert alert-danger fade in">
					<button type="button" class="close" data-dismiss="alert">×</button>
					<i class="fa fa-warning"></i> 请注意，Zanblog并不支持低于IE8的浏览器，为了获得最佳效果，请下载最新的浏览器，推荐下载 <a href="http://www.google.cn/intl/zh-CN/chrome/" target="_blank"><i class="fa fa-compass"></i> Chrome</a>
				</div>
				<div class="well fade in">
					<button type="button" class="close" data-dismiss="alert">×</button>
					<?php global $CACHE; $newtws_cache = $CACHE->readCache('newtw'); ?>
							<strong>公告：</strong><?php echo preg_replace("/\[(\d+)\]/i",'<img src='.BLOG_URL.'content/plugins/face/face/${1}.gif  />',$newtws_cache [ 0 ][t])?>
															 <i class="fa fa-smile-o"></i> 
				</div>  <?php if ($top_img == "yes"): ?>

				<!-- 幻灯片-->        <?php if (blog_tool_ishome()) : ?>

				<figure class="slide">
<!-- meta slider -->
<div style="max-width: 750px;" class="metaslider metaslider-flex metaslider-411 ml-slider visible-md visible-lg">
    <div id="metaslider_container_411">
        <div id="metaslider_411" class="flexslider">
        <div class="flex-viewport">
        <ul class="slides">
            <?php
    	get_flash_data(8);
    ?>
           
            </ul>
            </div>
            <ul class="flex-direction-nav"><li><a class="flex-prev" href="#">&lt;</a></li><li><a class="flex-next" href="#">&gt;</a></li></ul></div>
    </div>
    <script type="text/javascript">
        var metaslider_411 = function($) {
            $('#metaslider_411').flexslider({ 
                slideshowSpeed:3000,
                animation:"slide",
                controlNav:false,
                directionNav:true,
                pauseOnHover:true,
                direction:"vertical",
                reverse:false,
                animationSpeed:600,
                prevText:"<",
                nextText:">",
                easing:"easeOutExpo",
                slideshow:true,
                useCSS:false
            });
        };
        var timer_metaslider_411 = function() {
            var slider = !window.jQuery ? window.setTimeout(timer_metaslider_411, 100) : !jQuery.isReady ? window.setTimeout(timer_metaslider_411, 100) : metaslider_411(window.jQuery);
        };
        timer_metaslider_411();
    </script>
</div>
<!--// meta slider--></figure>	
    <?php endif; ?>
			 
				<!-- 幻灯片-->
                 <?php else: ?>	
<?php endif; ?>
<?php doAction('index_loglist_top'); ?>

<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
					<div class="article well clearfix">
					<i class="fa fa-bookmark article-stick visible-md visible-lg"></i>					<div class="data-article hidden-xs">
						<span class="month"><?php echo gmdate('n月', $value['date']); ?> </span>
						<span class="day"><?php echo gmdate('d', $value['date']); ?> </span>
					</div>
					<!-- PC端设备文章属性 -->
					<section class="visible-md visible-lg">
						<div class="title-article">
							<h1><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h1>
						</div>
						<div class="tag-article container">
							<span class="label label-zan"><i class="fa fa-tags"></i><?php blog_tag($value['logid']); ?></span>
							<span class="label label-zan"><i class="fa fa-user"></i> <?php blog_author($value['author']); ?></span>
							<span class="label label-zan"><i class="fa fa-eye"></i> <?php echo $value['views']; ?>人</span>
						</div>
						<div class="content-article">					
														<figure class="thumbnail"><a href="<?php echo $value['log_url']; ?>">
                                                        <?php
$thum_src = getThumbnail($value['logid']);
$imgFileArray = glob("content/templates/zanblog2.0.7/ui/random/*.*");
if(!empty($thum_src)){ ?>
<img src="<?php echo $thum_src; ?>" width="730" height="300" class="attachment-730x300 wp-post-image"/>
<?php
}else{
?>
<img src="<?php echo BLOG_URL; ?><?php echo $imgFileArray[array_rand($imgFileArray)]; ?>" width="700" height="300" class="attachment-730x300 wp-post-image"/>
<?php
}
?></a></figure>							
							<div class="alert alert-zan"><?php echo $value['log_description'] = subString(trim(strip_tags($value['log_description'])), 0, 80);?></div>
						</div>
						<a class="btn btn-danger pull-right read-more" href="<?php echo $value['log_url']; ?>">阅读全文 <span class="badge"><?php echo $value['comnum']; ?></span></a>
					</section>
					<!-- PC端设备文章属性 -->
					<!-- 移动端设备文章属性 -->
					<section class="visible-xs  visible-sm">
						<div class="title-article">
							<h4><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h4>
						</div>
						<p>
							<i class="fa fa-calendar"></i> <?php echo gmdate('m-d', $value['date']); ?>							<i class="fa fa-eye"></i> <?php echo $value['views']; ?>人						</p>
						<div class="content-article">					
														<figure class="thumbnail"><a href="<?php echo $value['log_url']; ?>">
                                                        <?php
$thum_src = getThumbnail($value['logid']);
$imgFileArray = glob("content/templates/news-uc/images/random/*.*");
if(!empty($thum_src)){ ?>
<img src="<?php echo $thum_src; ?>" width="730" height="292" class="attachment-730x300 wp-post-image">
<?php
}else{
?>
<img src="<?php echo BLOG_URL; ?><?php echo $imgFileArray[array_rand($imgFileArray)]; ?>" width="730" height="292" class="attachment-730x300 wp-post-image"/>
<?php
}
?></a></figure>							
							<div class="alert alert-zan">					
								<?php echo $value['log_description'] = subString(trim(strip_tags($value['log_description'])), 0, 80);?></div>
						</div>
						<a class="btn btn-danger pull-right read-more btn-block" href="<?php echo $value['log_url']; ?>">阅读全文 <span class="badge"><?php echo $value['comnum']; ?></span></a>
					</section>
					<!-- 移动端设备文章属性 -->
				</div>
                
                
<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
</section>
<?php
 include View::getView('side');
?>
<div class="col-md-8">
<?php 
$page_loglist = my_page($lognum, $index_lognum, $page, $pageurl);
echo $page_loglist;
?>
</div>
		</section>
	</div>
</section><!-- end #contentleft-->
<?php
 include View::getView('footer');
?>