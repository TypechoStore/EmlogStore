<?php
/*
Template Name:魅影
Description:Designed For Emlog
Version:1.3
Author:老罗
Author Url:http://hc123.site/zorro
Sidebar Amount:1
ForEmlog:5.3.1
*/
if (!defined('EMLOG_ROOT')) {
    exit('error!');
}
require_once View::getView('module');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="format-detection" content="telephone=no"/>
<link rel="shortcut icon" href="<?php echo TEMPLATE_URL; ?>images/favicon.ico" type="image/x-icon" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>style.css" type="text/css" media="all" />
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>font.css" type="text/css" media="all" />
<script type="text/javascript" src="http://libs.baidu.com/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/common.js"></script>
<?php doAction('index_head'); ?>
</head>
<body>		
<div id="wrapper">
	<header id="header" role="banner">
		<div class="box">
			<div class="logo">
				<a title="<?php echo $blogname; ?>" href="<?php echo BLOG_URL; ?>"><img alt="<?php echo $blogname; ?>" src="<?php echo TEMPLATE_URL; ?>images/logo.png"></a>
			</div>
			<h1><a title="<?php echo $blogname; ?>" href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
			<div class="text"><?php echo $bloginfo;?></div>
			<div class="openmenu" onclick="mmenu()"><i class="icon-plus"></i></div>
		</div>
		<ul class="m-nav">
			<li><a title="归档" rel="nofollow" href="#" target="_blank">归档</a></li><li><a title="留言" rel="nofollow" href="#" target="_blank">留言</a></li><li><a title="RSS" rel="nofollow" href="<?php echo BLOG_URL; ?>rss.php" target="_blank">RSS</a></li><li class="m-sch">
				<a id="hsch" title="搜索" href="#">搜索</a>
				<form id="hschform" class="form" name="keyform" action="<?php echo BLOG_URL; ?>index.php" method="get">
					<input class="txt" type="text" name="keyword"></input>
				</form>
			</li>
		</ul>
		<div class="clear"></div>
		<nav id="nav" role="navigation">
			<ul>
				<?php blog_navi();?>
			</ul>
			<div class="clear"></div>
		</nav>
	</header>
	<div id="container">