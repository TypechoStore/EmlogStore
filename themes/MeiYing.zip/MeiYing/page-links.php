﻿<?php
if (!defined('EMLOG_ROOT')) {
    exit('error!');
}
?>
<div id="single" role="main">
	<article role="article">
		<header><h2 class="post-name"><i class="icon-attachment"></i><?php echo $log_title; ?></h2></header>
		<address class="entry-meta">
			<i class="icon-profile-male"></i> <?php blog_author($author); ?>创建于<?php echo date('Y年m月d日',$date); ?>
		</address>
		<?php global $CACHE; 
	$link_cache = $CACHE->readCache('link');
	foreach($link_cache as $value){
	$output.= '<li><a target="_blank" href="'.$value['url'].'" title="'.$value['des'].'">'.'<img src="http://g.soz.im/'.$value['url'].'">'.$value['link'].'</a><p>'.$value['des'].'</p></li>';
	}
	echo '<ul class="link-content">'.$output.'</ul>';?>
	</article>
	<div id="comments">
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
		<?php blog_comments($comments,$params); ?>
	</div>
</div>
<?php include View::getView('side'); ?>
<?php include View::getView('footer'); ?>