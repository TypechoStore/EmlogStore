<?php
if (!defined('EMLOG_ROOT')) {
    exit('error!');
}
?>
</div>
<div class="clear"></div>
<div id="circle"></div>
<div id="circletext"></div>
<div id="circle1"></div>
<nav id="mmenu" role="navigation"><?php blog_navi2();?></nav>
</div>
<footer id="footer" role="contentinfo">
	<address>©&nbsp;<?php echo $blogname; ?>|Powered by <a rel="license" title="我在用emlog <?php echo Option::EMLOG_VERSION;?>" href="http://www.emlog.net" target="_blank">emlog</a> & Theme by <a rel="license" title="我是老罗" href="http://hc123.site/zorro" target="_blank">老罗</a>&nbsp;<?php echo $icp; ?>&nbsp;<?php echo $footer_info; ?><?php doAction('index_footer'); ?>
	</address>
</footer>
<script type="text/javascript">
$(function() {          
$("img").not("#sidebar img").lazyload({
effect:"fadeIn"
});
});
</script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/global.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/lazyload.js"></script>
</body>
</html>