﻿<?php
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content" role="main">
	<div class="page">
		<article role="article">
		抱歉，此模板不提供微语功能，呵呵 :)
		</article>
	</div>
</div>
<?php include View::getView('side'); ?>
<?php include View::getView('footer'); ?>