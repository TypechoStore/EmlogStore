<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="container main">
<ul class="ui_comment titter">
    <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?>
    <li class="bbs_post" id="comment-<?php echo $comment['cid']; ?>">
                                <p class="bbs_date_time">
                                    <span><?php echo $val['date'];?></span>
                                </p>
                                <div class="bbs_common">
                                    <s></s>
                                    <div class="bbs_avatar"><img src="<?php echo $avatar; ?>" /></div>
                                    <div class="bbs_common_text">
                                        <p><span class="ui_text_02"><?php echo $author; ?></span>：<?php echo $val['t'].'<br/>'.$img;?></p>
                                        <div class="bbs_common_up">
                                            <a href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">回复(<span id="rn_<?php echo $tid;?>"><?php echo $val['replynum'];?></span>)</a>
                                        </div>
                                        <?php if ($istreply == 'y'):?>
                                        <div id="r_<?php echo $tid;?>"></div>
                                        <?php endif;?>
                                        <div class="huifu" id="rp_<?php echo $tid;?>">
                                            <span class="tinfo" style="display:<?php if(ROLE == 'admin' || ROLE == 'writer'){echo 'none';}?>">
                                                昵称：<input type="text" id="rname_<?php echo $tid; ?>" value="" size="10" />
                                                <span style="display:<?php if($reply_code == 'n'){echo 'none';}?>">验证码：<input type="text" id="rcode_<?php echo $tid; ?>" value="" /><?php echo $rcode; ?></span>        
                                            </span>
                                            内容：<input id="rtext_<?php echo $tid; ?>" size="140" style="width: 40%;" />
                                            <input class="button_p" type="button" onclick="reply('<?php echo DYNAMIC_BLOGURL; ?>index.php?action=reply',<?php echo $tid;?>);" value="回复" /> 
                                             <div class="msg"><span id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></span></div>
                                        </div>
                                    </div>
                                </div>
                            <div class="clear"></div>
                        </li>
    <?php endforeach;?>
	<div id="page"><?php echo $pageurl;?></div>
</ul>
</div>
<?php
 include View::getView('footer');
?>