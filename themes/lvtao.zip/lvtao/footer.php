<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?><div class="main" id="footer">
    <div id="copy"><span><?php doAction('index_footer'); ?> <a href="http://www.miibeian.gov.cn" target="_blank" rel="nofollow"><?php echo $icp; ?></a> <?php echo $footer_info; ?></span>Copyright &copy;&nbsp;2007-2013 <a href="http://www.lvtao.net">吕滔个人主页</a> All rights reserved.</div>
</div>
</body>
</html>