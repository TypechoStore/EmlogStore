<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="container">
        <dl>
            <dd class="con_article"><?php echo $log_content; ?></dd>
        </dl>
        <?php blog_comments($comments); ?>
</div>
<?php include View::getView('footer');?>