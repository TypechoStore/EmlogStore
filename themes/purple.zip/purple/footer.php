<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="sidebar">
    <div class="side_box side_1">
    <?php footer_newlog(''); ?>

    </div>
	<div class="side_box side_2">
	
	<?php footer_newcomm(''); ?>
    </div>
    <div class="side_box side_3">
    <?php footer_sort(''); ?>
	
    </div>
	<div class="side_box side_4">
		<ul class="other">
         
            <li>
                <div class="rss">
                   <a href="<?php echo BLOG_URL; ?>rss.php">博客RSS</a>
                </div>
               
            </li>
            <li>
                <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
                    <a href="<?php echo BLOG_URL; ?>admin/">博客管理</a> | <a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a>
                <?php else: ?>
                    <a href="<?php echo BLOG_URL; ?>admin/">登录</a>
                <?php endif; ?>
            </li>
        </ul>
	<?php widget_link(''); ?>
	</div>
</div>
<footer id="footer">© <a href="<?php echo BLOG_URL; ?>" rel="home"><?php echo $blogname; ?></a>. Theme by <a href="http://kindevil.com/" target="_blank">Kindevil</a> Transplant by <a href="http://foxzld.com/" target="_blank">LonelyFox</a>. Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> .
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>. <?php echo $footer_info; ?>
<?php doAction('index_footer'); ?>
 </footer>


</div><!--end #wrap-->
</body>
</html>