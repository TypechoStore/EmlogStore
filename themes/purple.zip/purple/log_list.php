<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>


<div id="content">	
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
		<section class="post">
		<header class="post_head">
			<p class="date"><?php echo gmdate('Y-n-j G:i', $value['date']); ?></p>
			<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
		</header>
		<article class="post_artice">
			<?php echo $value['log_description']; ?>
		</article>
		<p class="cate"><?php blog_sort($value['logid']); ?>  •<a>浏览次数：<?php echo $value['views']; ?></a> • <a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?> comment</a>
		</p>
	</section>
		<?php endforeach; ?>
	    <div class="clear"></div>
	</div>
	<div id="pagenavi" class="pages">
		<?php echo $page_url;?>
			</div>


<?php

 include View::getView('footer');
?>