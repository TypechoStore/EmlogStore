<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<section class="post">
	<header class="post_head">
		<p class="date"><?php echo gmdate('Y-n-j G:i ', $date); ?> </p>
		<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
		
	</header>
	<article class="post_artice">
		<?php echo $log_content; ?>
		
		<div class="tags"><?php blog_tag($logid); ?></div>
		<?php doAction('log_related', $logData); ?>
	</article>
	<p class="cate"><?php blog_sort($logid); ?>  •<a>浏览次数：<?php echo $views; ?></a> • <a href="<?php echo $log_url; ?>#comments"><?php echo $comnum; ?> comment</a>
		</p>
</section>
<article id="comments">
<div class="comments_count">已有 <?php echo $comnum; ?>  条评论</div>
<?php blog_comments($comments); ?>

<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>

</article>
<?php

 include View::getView('footer');
?>