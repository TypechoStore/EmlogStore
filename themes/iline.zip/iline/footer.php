<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div class="c"></div>
</div>
<div class="footer">
<div class="footer_left">
<span class="footer_copy">&copy;<?php echo date('Y');?>&nbsp;<?php echo $blogname; ?></span>
<span class="footer_power">博客程序：<a href="http://www.emlog.net" title="点击访问EMLOG系官方网站" target="_blank">EMLOG</a></span>
<span class="footer_them"><?php blog_them();?></span>
<?php if(!empty($icp)){echo '<span class="footer_icp"><a href="http://www.miibeian.gov.cn" target="_blank" title="点击查看网站备案信息">'.$icp.'</a></span>';}?>
</div>
<div class="footer_right"><?php echo $footer_info; ?></div>
<div class="c"></div>
<?php doAction('index_footer'); ?>
</div>
<span id="ttop">&nbsp;</span>
</div>
<script>prettyPrint();</script>
</body>
</html>