<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div class="content">
<div class="content_left">
<div class="text_body">
<div class="text_title"><?php echo $log_title; ?></div>
<div class="text_text"><?php echo $log_content; ?></div>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<div class="c"></div>
</div>
</div>
<?php include View::getView('side'); include View::getView('footer');?>