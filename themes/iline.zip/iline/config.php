<?php if(!defined('EMLOG_ROOT')) {exit('error!');};

define('NEW_DAY','3');//几天内的文章标题显示New标示，默认3天

define('HOT_VIEW','100');//浏览量达到多少，浏览标签标记红色，默认100次

define('HOT_COMMENT','10');//评论数量到达多少时，标题栏显示Hot标示，默认10条

?>