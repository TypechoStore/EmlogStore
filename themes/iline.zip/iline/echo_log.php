<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div class="content">
<div class="content_left">
<div class="text_body">
<div class="text_title"><?php topflg($top); ?><?php echo $log_title; ?></div>
<div class="text_date"><span class="text_time"><?php $weekarray=array("日","一","二","三","四","五","六");echo gmdate('Y年n月j日 G:i', $date);echo " 星期".$weekarray[gmdate('w', $date)];?></span><?php blog_sort($logid); ?><?php editflg($logid,$author); ?></div>
<div class="text_text"><?php echo $log_content; ?></div>
<?php blog_tag($logid); ?>
<?php doAction('log_related', $logData); ?>
<?php if(!empty($neighborLog)){echo (neighbor_log($neighborLog));}?>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<div class="c"></div>
</div>
</div>
<?php include View::getView('side'); include View::getView('footer');?>