<?php
/*
Template Name:iLine
Description:偏爱直线
Version:1.0
Author:Vanze
Author Url:http://lxperson.com
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
require_once View::getView('config');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js" type="text/javascript"></script>
<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<script src="<?php echo TEMPLATE_URL; ?>js/common.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div class="body">
<div class="top">
<div class="top_left"><?php echo date('Y-m-d')?></div>
<?php if (Option::get('rss_output_num')):?>
<div class="top_right">
<a href="<?php echo BLOG_URL; ?>rss.php" title="RSS订阅"><img src="<?php echo TEMPLATE_URL; ?>img/rss.gif" alt="订阅Rss"/></a>
</div>
<?php endif;?>
<div class="c"></div>
</div>
<div class="blog_title">
<div class="blog_title_left">
<div class="name"><?php echo $blogname; ?></div>
<div class="des"><?php echo $bloginfo; ?></div>
</div>
<div class="blog_title_right">
<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
<input name="keyword" class="search" type="text" onMouseOver="this.focus()" onMouseOut="if(this.value=='')this.value='输入后按回车搜索';" onFocus="this.select()" onClick="if(this.value=='输入后按回车搜索')this.value=''" value="输入后按回车搜索" />
</form>
</div>
<div class="c"></div>
</div>
<div class="navi"><?php blog_navi();?></div>