<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div class="content">
<div class="content_left">
<?php doAction('index_loglist_top'); ?>
<?php if (!empty($logs)):foreach($logs as $value): ?>
<div class="content_body">
<div class="info_title"><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a><?php $t1 = $value['date'];$t2 = time(); $t3 = round(($t2-$t1)/3600/24);if ($t3 <= NEW_DAY){echo '<sup>New</sup>';}?><?php if($value['comnum'] >= HOT_COMMENT){echo '<sup>Hot</sup>';}?></div>
<?php log_pic($value['logid']);?>
<div class="info_text"><?php echo $value['log_description']; ?></div>
<div class="c"></div>
<div class="info_mun">
<span class="info_time"><?php $weekarray=array("日","一","二","三","四","五","六");echo gmdate('Y年n月j日 G:i', $value['date']);echo " 星期".$weekarray[gmdate('w', $value['date'])];?></span>
<?php blog_sort($value['logid']); ?>
<span class="info_com"><a href="<?php echo $value['log_url']; ?>#comments" title="查看《<?php echo $value['log_title']; ?>》的评论">评论：<?php echo $value['comnum']; ?></a></span>
<span class="info_view" <?php if($value['views'] > HOT_VIEW){echo 'id="hot"';} ?>>浏览：<?php echo $value['views']; ?>次</span>
<?php blog_tag($value['logid']); ?>
<?php editflg($value['logid'],$value['author']); ?>
<div class="c"></div>
</div>
</div>
<?php endforeach;else:?>
<h2>未找到</h2>
<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
<?php if(!empty($page_url)){echo '<div class="pagenavi">'.$page_url.'</div>';}?>
</div>
<?php include View::getView('side'); include View::getView('footer');?>