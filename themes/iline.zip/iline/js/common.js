(function(){
  $("#nav li").hover(function(){
  $(this).children("a").toggleClass("on"); 
  })
})
function menuFix() {
 var sfEls = document.getElementById("nav").getElementsByTagName("li");
 for (var i=0; i<sfEls.length; i++) {
  sfEls[i].onmouseover=function() {
  this.className+=(this.className.length>0? " ": "") + "sfhover";
  }
  sfEls[i].onMouseDown=function() {
  this.className+=(this.className.length>0? " ": "") + "sfhover";
  }
  sfEls[i].onMouseUp=function() {
  this.className+=(this.className.length>0? " ": "") + "sfhover";
  }
  sfEls[i].onmouseout=function() {
  this.className=this.className.replace(new RegExp("( ?|^)sfhover\\b"), 
"");
  }
 }
}
window.onload=menuFix;

jQuery(document).ready(function(){
 jQuery("#ttop").hide();
jQuery(function () {
jQuery(window).scroll(function(){
if (jQuery(window).scrollTop()>100){
jQuery("#ttop").fadeIn(1000);
}
else
{
jQuery("#ttop").fadeOut(1000);
}
});
jQuery("#ttop").click(function(){
jQuery('body,html').animate({scrollTop:0},1000);
return false;
});
});
});

function startmarquee(elementClass,h,n,speed,delay){
 var t = null;
 var box = '.' + elementClass;
 var $j = jQuery.noConflict();
 $j(box).hover(function(){
  clearInterval(t);
  }, function(){
  t = setInterval(start,delay);
 }).trigger('mouseout');
 function start(){
  $j(box).children('ul:first').animate({marginTop: '-='+h},speed,function(){
   $j(this).css({marginTop:'0'}).find('li').slice(0,n).appendTo(this);
  })
 }
};

function imgSize(url ,id) {
var imgObj = new Image();
var imgDiv=document.getElementById(id)
imgObj.src = url;
imgDiv.innerHTML= imgObj.width + " × " + imgObj.height;
}
function changeSize(obj, width) {
if (obj.width > width) {
obj.width=width;
}
};