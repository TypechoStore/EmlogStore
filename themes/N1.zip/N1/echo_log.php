<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div id="content">
<div class="post" >
<div class="post-title">
<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
<span class="post-time"><?php echo gmdate('Y-n-j G:i l', $date); ?></span><span class="post-cat"><?php blog_sort($logid); ?></span> <?php editflg($logid,$author); ?><span class="mini-add-comment"><a href="#ds-reset">Add comments</a></span><br /><span class="post-tags"><?php blog_tag($logid); ?></span>
</div>
<div class="entry">
<p><?php echo $log_content; ?></p>
<p><?php blog_att($logid); ?></p>
<p><?php blog_trackback($tb, $tb_url, $allow_tb); ?></p>
<div class="Information"><ul>
<li>如需转载请联系版权所有者。<br /></li>
</ul></div>
<!-- Baidu Button BEGIN -->
<script type="text/javascript" id="bdshare_js" data="type=slide&img=0&uid=6435207" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
	document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + new Date().getHours();
</script>
<!-- Baidu Button END -->
<!-- 无觅可能喜欢代码 -->
<div class="wumii-hook">
    <input type="hidden" name="wurl" value="<?php echo Url::log($logid); ?>" />
    <input type="hidden" name="wtitle" value="<?php echo $log_title; ?>" />
</div>
<script>
    var wumiiSitePrefix = "<?php echo BLOG_URL; ?>";
</script>
<!--悬浮窗-->
<div id="menu">
<!--添加评论-->
<span class="reply" onmouseover="tooltip.show('添加评论');" onmouseout="tooltip.hide();"><a href="#ds-reset" onFocus="this.blur()">&nbsp;</a></span><!--添加评论-->
<!--totop-->
<span class="top" onmouseover="tooltip.show('回到顶部');" onmouseout="tooltip.hide();"><a href="#" onclick="goTop();return false;" title="" onFocus="this.blur()">&nbsp;</a></span><!--totop-->
<!--tohome-->
<span class="toindex" onmouseover="tooltip.show('回到首页');" onmouseout="tooltip.hide();"><a href=<?php echo BLOG_URL; ?> title="" onFocus="this.blur()">&nbsp;</a></span><!--tohome-->
<!--rss-->
<span class="rss_l" onmouseover="tooltip.show('马上订阅');" onmouseout="tooltip.hide();"><a href="<?php echo BLOG_URL; ?>rss.php" onFocus="this.blur()">&nbsp;</a></span><!--rss-->
</div><!--悬浮窗-->
 </div>
<a name="ds-reset"></a>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div><!--/post -->
</div><!--/content -->
<div id="sidebar">
<?php include View::getView('side');?>
</div><!--/sidebar -->
<div id="sidebar2">
<?php include View::getView('side2');?>
</div><!--/sidebar2 -->
<?php include View::getView('footer');?>