<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<ul id="sidebar">
<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>
<li>
    <h2 class="sidebartitle">Wnin.cn</h2>    
    <ul class="list-meta">
    <li class="<?php echo $curpage == CURPAGE_HOME ? 'current' : 'common';?>"><a href="<?php echo BLOG_URL; ?>">首页</a></li>
	<?php if($istwitter == 'y'):?>
	
	<?php endif;?>
	<?php 
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach ($navi_cache as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	$val['is_blank'] = $val['newtab'] == 'y' ? 'target="_blank"' : '';
    $val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
	?>
	<li class="<?php echo isset($logid) && $key == $logid ? 'current' : 'common';?>"><a href="<?php echo $val['url']; ?>" target="<?php echo $val['is_blank']; ?>"><?php echo $val['naviname']; ?></a></li>
	<?php endforeach;?>
	<?php doAction('navbar', '<li class="common">', '</li>'); ?>
	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
	<li class="common"><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
	<li class="common"><a href="<?php echo BLOG_URL; ?>admin/">管理中心</a></li>
	<li class="common"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
	<?php else: ?>
	<li class="common"><a href="<?php echo BLOG_URL; ?>admin/">登录</a></li>
	<?php endif; ?>
    <li><a href="http://www.emlog.net/" title="基于 Emolog，一个简洁、优美的个人信息发布平台。"><img src="<?php echo TEMPLATE_URL; ?>themes/images/logo.gif" 
alt="" /></a></li>
    </ul>
</li>
</ul><!--end #siderbar-->
