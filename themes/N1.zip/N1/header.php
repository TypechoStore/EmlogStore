<?php
/*
Template Name:N1
Description:nimaboke.com
Version:1.2
Author:威宁＆吴尼玛
Author Url:http://www.nimaboke.com
Sidebar Amount:2
ForEmlog:4.2.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>themes/style.css" type="text/css" media="all" />
<!--flashimage-->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>themes/swf.js"></script>
<style type="text/css" media="screen">
	html, body, body.sidebars { width:100%; height:100%; margin:0; padding:0;}
	  object { outline:none; }
</style>
<!--flashimage-->
<!--[if lt IE 7]>
    <style type="text/css">
    /*<![CDATA[*/
body {height:auto}
#px0 {display: none}
#menu {margin-top:225px;position:absolute;top:expression(eval(document.documentElement.scrollTop));}
#ann {padding-bottom: -4px;	padding-top: 6px;}
p {
	word-spacing: -2px;
	text-align: left;
}
#content {
	width: 505px;
	padding-right: 10px;
}
.post-time {
	margin-top: 0px;
}
ul.list-facebook li a, ul.list-xianguo li a, ul.list-twitter li a, ul.list-9dian li a, ul.list-sina li a {
	height: 16px;
	line-height: 16px;
	padding-bottom: 2px;
	padding-top: 1px;
}
    /*]]>*/
    </style>
<!--ie6png-->
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>themes/js/belatedPNG.js" ></script>   
<script type="text/javascript">   
DD_belatedPNG.fix('.top a, .toindex a, .sina a, .chinesetw a, .rss_l a');   
</script>
<!--ie6png-->
<![endif]-->
</head>
<body>
<div id="page">
  <div id="header">
    <div id="ann"><?php echo $bloginfo; ?></div>
    <div id="headerleft">
    <div id="headerimg">
	<div class="tohome" ><a href="<?php echo BLOG_URL; ?>" title=""></a></div>
<!--幻灯片--><div id="flashimgshow"><div class="sidebarimage2">
<div id="kenburns">
<script type="text/javascript">
	var flashvars = {
		xml_path: "<?php echo TEMPLATE_URL; ?>themes/xml/flash1.xml"
	};
	var params = {
		bgcolor: "#dddddd",
		wmode: "opaque",
		allowfullscreen: "true"
	};
	var attributes = {};
	swfobject.embedSWF("<?php echo TEMPLATE_URL; ?>themes/flashXML.swf", "kenburns", "400", "170", "9.0.0",
	"expressInstall.swf", flashvars, params, attributes);
</script>
</div>
</div></div><!--幻灯片-->
	</div>
	<ul id="nav">
	  <li class="page_item5"><a href="<?php echo BLOG_URL; ?>" title="Home">首页</a></li>
	  <li class="page_item4"><a href="<?php echo _g('1a'); ?>" title="Contact"><?php echo _g('a1'); ?></a></li>
	  <li class="page_item3"><a href="<?php echo _g('2a'); ?>" title="Jobs"><?php echo _g('a2'); ?></a></li>	  
	  <li class="page_item2"><a href="<?php echo _g('3a'); ?>" title="About"><?php echo _g('a3'); ?></a></li>
	  <li class="page_item"><a href="<?php echo _g('4a'); ?>" title="Sitemap"><?php echo _g('a4'); ?></a></li>
	</ul>
 </div>
  <!--/header -->

<style type="text/css">
<!--
.top a {
	background-image: url(<?php echo TEMPLATE_URL; ?>themes/images/totop2.gif);
}
.toindex a {
	background-image: url(<?php echo TEMPLATE_URL; ?>themes/images/tohome2.gif);
}
#nav .page_item5 a:hover {
	color: #000;
	background-image: url(<?php echo TEMPLATE_URL; ?>themes/images/nav_bg4.gif);
	margin-top: 0px;
	margin-bottom: 0px;
	margin-left: 0px;
}
-->
</style>