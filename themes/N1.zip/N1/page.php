<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<style type="text/css">
<!--
p a {
	color: #000;
	font-weight: normal;
	text-decoration: none;
}
.commentlist li{
	color: #666666;
	padding-top: 5px;
	padding-right: 10px;
	padding-bottom: 5px;
	padding-left: 10px;
	list-style-type: none;
	display:block;
	width: 680px;
}
-->
</style>
<div id="content3">
<div class="post">
<div class="post-title">
<h2><?php echo $log_title; ?></h2>
</div>
<div class="entry">
<p><?php echo $log_content; ?></p>
<p><?php blog_att($logid); ?></p>
<!-- 评论 -->
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
</div>
<!--post -->
<!--悬浮窗-->
<div id="menu">
<!--添加评论-->
<span class="reply" onmouseover="tooltip.show('添加评论');" onmouseout="tooltip.hide();"><a href="#ds-reset" onFocus="this.blur()">&nbsp;</a></span><!--添加评论-->
<!--totop-->
<span class="top" onmouseover="tooltip.show('回到顶部');" onmouseout="tooltip.hide();"><a href="#" onclick="goTop();return false;" title="" onFocus="this.blur()">&nbsp;</a></span><!--totop-->
<!--tohome-->
<span class="toindex" onmouseover="tooltip.show('回到首页');" onmouseout="tooltip.hide();"><a href=<?php echo BLOG_URL; ?> title="" onFocus="this.blur()">&nbsp;</a></span><!--tohome-->
<!--rss-->
<span class="rss_l" onmouseover="tooltip.show('马上订阅');" onmouseout="tooltip.hide();"><a href="<?php echo BLOG_URL; ?>rss.php" onFocus="this.blur()">&nbsp;</a></span><!--rss-->
</div><!--悬浮窗-->
</div><!--content -->
<div id="sidebar2">
<?php include View::getView('side2');?>
</div><!--/sidebar2 -->
<?php include View::getView('footer');?>