<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div id="content">
<?php foreach($logs as $value): ?>
<!--post -->
<div class="post">
<div class="post-title">
<h2><a href="<?php echo $value['log_url']; ?>" rel="bookmark" title="<?php echo $value['log_title']; ?>"><?php topflg($value['top']); ?><?php echo $value['log_title']; ?></a></h2>
<span class="post-time"><?php echo gmdate('Y-n-j G:i l', $value['date']); ?></span><span class="post-cat"><?php blog_sort($value['logid']); ?></span>
</div>
<div class="entry">
<p><a href="<?php echo $value['log_url']; ?>"><img src="<?php get_imgsrc($value['content']); ?>" alt="" /></a></p>
<p><?php echo $value['log_description']; ?></p>
</div>
</div>
<?php endforeach; ?>
<!--悬浮窗-->
<div id="menu">
<!--email-->
<span class="email" onmouseover="tooltip.show('给我邮件');" onmouseout="tooltip.hide();"><a href="mailto:csjscn@qq.com" onFocus="this.blur()">&nbsp;</a></span><!--email-->
<!--totop-->
<span class="top" onmouseover="tooltip.show('回到顶部');" onmouseout="tooltip.hide();"><a href="#" onclick="goTop();return false;" title="" onFocus="this.blur()">&nbsp;</a></span><!--totop-->
<!--rss-->
<span class="rss_l" onmouseover="tooltip.show('马上订阅');" onmouseout="tooltip.hide();"><a href="<?php echo BLOG_URL; ?>rss.php" onFocus="this.blur()">&nbsp;</a></span><!--rss-->
</div><!--悬浮窗-->
<div class="pagebar">Pages:&nbsp;<?php echo $page_url;?>
</div></div><!--content -->
<div id="sidebar">
<?php include View::getView('side');?>
</div><!--/sidebar -->
<div id="sidebar2">
<?php include View::getView('side2');?>
</div><!--/sidebar2 -->
<?php include View::getView('footer');?>