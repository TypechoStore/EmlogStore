<?php
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
		'logo' => array(
        'type' => 'image',
        'name' => 'logo',
        'values' => array(TEMPLATE_URL . 'themes/images/header-logo.png',),
		'description' => '站点logo',
    ),
		'a1' => array(
		'type' => 'text',
		'name' => '导航一名称',
		'default' => '导航一',
	),
		'1a' => array(
		'type' => 'text',
		'name' => '导航一链接',
		'default' => '#',
	),
		'a2' => array(
		'type' => 'text',
		'name' => '导航二名称',
		'default' => '导航二',
	),
		'2a' => array(
		'type' => 'text',
		'name' => '导航二链接',
		'default' => '#',
	),
		'a3' => array(
		'type' => 'text',
		'name' => '导航三名称',
		'default' => '导航三',
	),
		'3a' => array(
		'type' => 'text',
		'name' => '导航三链接',
		'default' => '#',
	),
		'a4' => array(
		'type' => 'text',
		'name' => '导航四名称',
		'default' => '导航四',
	),
		'4a' => array(
		'type' => 'text',
		'name' => '导航四链接',
		'default' => '#',
	),
);