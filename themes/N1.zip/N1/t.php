<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<style type="text/css">
<!--
p a {
	color: #000;
	font-weight: normal;
	text-decoration: none;
}
.commentlist li{
	color: #666666;
	padding-top: 5px;
	padding-right: 10px;
	padding-bottom: 5px;
	padding-left: 10px;
	list-style-type: none;
	display:block;
	width: 680px;
}
-->
</style>
<div id="content3">
<div class="post">
<div class="post-title">
<h2><?php echo $blogtitle; ?></h2>
</div>
<span class="mini-add-comment"><?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
    <a href="<?php echo BLOG_URL . 'admin/twitter.php' ?>">发布碎语</a>
    <?php endif; ?></span>
	<div class="entry">
    <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
    BLOG_URL . 'admin/views/images/avatar.jpg' : 
    BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    ?>
	<ol class="commentlist">
	<li id="comment" class="alt">
		<img width="32" height="32" class="avatar avatar-32 photo" src="<?php echo $avatar; ?>" alt="">
		<cite><?php echo $author; ?></cite><span class="post-time"><?php echo $val['date'];?>  Says:&nbsp;&nbsp;</span><br>&nbsp;<br>
		<p><?php echo $val['t'];?></p>
		<p class="thdrpy"><a href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">回复(<span id="rn_<?php echo $tid;?>"><?php echo $val['replynum'];?></span>)</a></p>
	<div class="clear"></div>
   	<ul id="r_<?php echo $tid;?>" class="r"></ul>
    <div class="huifu" id="rp_<?php echo $tid;?>">   
	<textarea id="rtext_<?php echo $tid; ?>"></textarea>
    <div class="tbutton">
        <div class="tinfo" style="display:<?php if(ROLE == 'admin' || ROLE == 'writer'){echo 'none';}?>">
        昵称：<input type="text" id="rname_<?php echo $tid; ?>" value="" />
        <span style="display:<?php if($reply_code == 'n'){echo 'none';}?>">验证码：<input type="text" id="rcode_<?php echo $tid; ?>" value="" /><?php echo $rcode; ?></span>        
        </div>
        <input class="button_p" type="button" onclick="reply('<?php echo DYNAMIC_BLOGURL; ?>index.php?action=reply',<?php echo $tid;?>);" value="回复" /> 
        <div class="msg"><span id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></span></div>
    </div>
    </div></li>
	</ol>
    <?php endforeach;?>
	<li class="pagebar"><?php echo $pageurl;?><span></span></li>
</div>
</div>
<!--post -->
<!--悬浮窗-->
<div id="menu">
<!--email-->
<span class="email" onmouseover="tooltip.show('给我邮件');" onmouseout="tooltip.hide();"><a href="mailto:csjscn@qq.com" onFocus="this.blur()">&nbsp;</a></span><!--email-->
<!--totop-->
<span class="top" onmouseover="tooltip.show('回到顶部');" onmouseout="tooltip.hide();"><a href="#" onclick="goTop();return false;" title="" onFocus="this.blur()">&nbsp;</a></span><!--totop-->
<!--tohome-->
<span class="toindex" onmouseover="tooltip.show('回到首页');" onmouseout="tooltip.hide();"><a href=<?php echo BLOG_URL; ?> title="" onFocus="this.blur()">&nbsp;</a></span><!--tohome-->
<!--rss-->
<span class="rss_l" onmouseover="tooltip.show('马上订阅');" onmouseout="tooltip.hide();"><a href="<?php echo BLOG_URL; ?>rss.php" onFocus="this.blur()">&nbsp;</a></span><!--rss-->
</div><!--悬浮窗-->
</div><!--content -->
<div id="sidebar2">
<?php include View::getView('side2');?>
</div><!--/sidebar2 -->
<?php include View::getView('footer');?>