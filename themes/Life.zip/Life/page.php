 <?php
/*

    Template Name:Life
    Description:极简主义者
    Version:1.1
    Author:Secret
    Author Url:http://blog.myiooc.cn
    Sidebar Amount:0
    
 */
  
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<content>
		<div class="main">
			<div class="article">
				<div class="article-title"><?php echo $log_title; ?></div>
				<div class="article-content"><?php echo $log_content; ?></div>
			</div>
			<?php blog_comments($comments); ?>
			<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
		</div>
	</content>
<?php
 include View::getView('footer');
?>
