<?php 
/*

    Template Name:Life
    Description:极简主义者
    Version:1.1
    Author:Secret
    Author Url:http://blog.myiooc.cn
    Sidebar Amount:0
    
 */

if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<content>
        <div class="main">
            <div class="article">
                <div class="article-title">开发中...</div>
                <div class="article-content">
                <p style="text-align: center;">微语部分还在开发中,请在后台关闭微语功能.</p><br>
                </div>
            </div>
        </div>
    </content>

<?php
 include View::getView('footer');
?>
