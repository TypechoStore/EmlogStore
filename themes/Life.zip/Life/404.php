<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Error 404</title>
</head>
<body>
<h1>404</h1>
<p>
    page not found
</p>
</body>
</html>