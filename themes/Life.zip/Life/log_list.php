<?php
/*

    Template Name:Life
    Description:极简主义者
    Version:1.1
    Author:Secret
    Author Url:http://blog.myiooc.cn
    Sidebar Amount:0
    
 */
  
if(!defined( 'EMLOG_ROOT')) {exit( 'error!');} ?>
<?php doAction( 'index_loglist_top'); ?>
<content>
<div class="main">
	<?php if (!empty($logs)): foreach($logs as $value): ?>
	<div class="article">
		<div class="article-title">
			<a href="<?php echo $value['log_url']; ?>">
			<?php echo $value[ 'log_title']; ?>
			</a>
			<?php topflg($value[ 'top']); ?>
		</div>
		<small class="article-time">发表于 <?php echo gmdate( 'Y-n-j', $value[ 'date']); ?> | <span class="baiduapi" title="<?php echo $value['log_url']; ?>"></span> | <?php blog_sort($value['logid']); ?> <?php editflg($value[ 'logid'],$value[ 'author']); ?>
		</small>
		<div class="article-content">
			<?php echo $value[ 'log_description']; ?>
		</div>
	</div>
	<?php endforeach; else: ?>
	<div class="page-not-found">
		<h2>
            Page not found
		</h2>
		<p>
            抱歉，没有符合您查询条件的结果
		</p>
                                返回
		<a href="<?php echo BLOG_URL; ?>">
            博客首页
		</a>
	</div>
	<?php endif;?>
	<div class="page-url">
	</div>
	<div class="pagination">
		<?php echo $page_url;?>
	</div>
<?php include View::getView( 'footer'); ?>