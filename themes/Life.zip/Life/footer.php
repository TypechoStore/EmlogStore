<?php
/*

    Template Name:Life
    Description:极简主义者
    Version:1.1
    Author:Secret
    Author Url:http://blog.myiooc.cn
    Sidebar Amount:0
    
 */

if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
		<?php doAction('index_bodys'); ?>
		</div>
	</content>
	<footer>
		<?php doAction('index_footer'); ?><br>
		<span id="busuanzi_container_site_pv">总访问量<span id="busuanzi_value_site_pv"></span>次 / 本页阅读<span id="busuanzi_value_page_pv"></span>次</span><br>
		© 2016-至今 <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a> <i class="iconfont icon-icp"></i><?php echo $icp; ?><br>Powered by <a href="http://www.emlog.net">EMLOG</a> | 自豪的采用 <a href="http://blog.myiooc.cn/about_life" id="Life">Life</a> 主题
	</footer>
	<div class="toTop">TOP</div>
<script src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js"></script>
<script src="https://blog.myiooc.cn/include/lib/js/common_tpl.js"></script>
<!-- 一言调用（副标题），不需要可以删除下面一行 -->
<script src="<?php echo TEMPLATE_URL; ?>js/hitokoto.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/scrolltop.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/collapse.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/smoothscroll.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/busuanzi.pure.mini.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/instantclick.min.js" data-no-instant></script>
<!-- Instantclick -->
<script data-no-instant>InstantClick.init();</script>
<script>
	var UrlArr = $('.baiduapi');
	$(UrlArr).each(function(i) {
		var url = "https://api.isecret.vip/api?type=baidu&url="+UrlArr[i].title;
		$.post(url,null,function(e){
			if(e.status == 0){
				$(UrlArr[i]).html('百度暂未收录');
			}else if(e.status == 1){
				$(UrlArr[i]).html('百度已收录');
			}
		},'JSON');
	});
</script>
</body>
</html>