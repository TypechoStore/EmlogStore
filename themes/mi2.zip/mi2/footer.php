<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div style="clear:both;"></div>
<div class="space"></div>
<!--footer-->
<div class="footer">
	<div class="copyright">
	Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">Emlog</a>
   	Theme by <a href="http://zhangziheng.com/" title="子恒网络博客" target="_blank">jaeheng</a><br> 
  	© 2011-<?php echo date(Y);?> 
    </div>
	
    <div class="right">
		<span class="navr">
			<a href="<?php echo $guestBook; ?>" target="_blank">联系我们</a> |
			<a href="<?php echo BLOG_URL; ?>m" target="_blank">手机版</a> |
			<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a> 
			( <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> )
		</span><br />
		<span><?php echo date("Y年m月d日");?>| <?php echo $footer_info; ?></span>
	</div><!--right-->
	<div class="clear"></div>
	<?php doAction('index_footer'); ?>
</div><!--end #footer-->

	<div id="shangxia">
	<div id="shang" title="↑ 返回顶部"></div>
	<div id="xia" title="↓ 移至底部"></div>
	</div>
</div><!--end #warp-->
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery_cmhello.js"></script>
<!--[if IE 6]>
<link href="<?php echo TEMPLATE_URL; ?>ie6.css" rel="stylesheet" type="text/css" />
<script src="http://letskillie6.googlecode.com/svn/trunk/letskillie6.zh_CN.pack.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/PNG.js"></script>
<script>DD_belatedPNG.fix('.png_bg');</script>
<![endif]-->

</body>
</html>