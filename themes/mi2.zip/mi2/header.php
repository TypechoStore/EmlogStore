﻿<?php
/*
Template Name:仿小米论坛
Description:可自定义banner,template文件夹需存在默认模版。<br /><br /><a href="template.php?action=custom-top" style="color:red;">点此设置banner</a>
Version:V3.0
Author:jaeheng
Author Url:http://zhangziheng.com
Sidebar Amount:1
ForEmlog:5.0.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
include('includes/opinion.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>css/main.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>css/style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div class="cl" id="toptb">
	<div class="wp">
		<div class="z">
			<a href="<?php echo BLOG_URL; ?>" onClick="this.style.behavior='url(#default#homepage)';this.setHomePage('<?php echo BLOG_URL; ?>')">设为首页</a>
				<script language="javascript">
				function bookmarkit(){window.external.addFavorite('<?php echo BLOG_URL; ?>','<?php echo $blogname; ?>')}
				</script> 	
			<a href="#" onClick="bookmarkit()">收藏本站</a>
			<?php echo $toptb_left_url;?>
		</div>
		
		<div class="y">
			<?php echo $toptb_right_url;?>
			<a title="RSS订阅" href="<?php echo BLOG_URL; ?>rss.php">订阅本站</a>
		</div>
	</div>
</div>

<div class="space"></div>

<div id="hd">
	<div class="wp">
		<div class="hdc cl">
    		<h1 class="logo"><a href="<?php echo BLOG_URL; ?>"></a></h1>
			<div class="login"><!--start login-->
				<p>
				<?php if(ROLE == 'admin' || ROLE == 'writer'):?>
					<a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a><span class="pipe"> | </span>
					<a href="<?php echo BLOG_URL; ?>admin/">管理中心</a><span class="pipe"> | </span>
					<a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a>
				<?php else: ?>
					<a href="<?php echo BLOG_URL;?>admin">登录</a>
				<?php endif; ?>

			
				<a href="<?php echo BLOG_URL;?>admin">
					<?php 	global $CACHE;$user_cache = $CACHE->readCache('user');?>
					<?php if (!empty($user_cache[UID]['photo']['src'])): ?>
						<img src="<?php echo BLOG_URL.$user_cache[UID]['photo']['src']; ?>" id="login_img" title="<?php echo $user_cache[UID]['name']; ?>" alt="<?php echo $user_cache[UID]['name']; ?>">
					<?php else:?>
						<img src="<?php echo TEMPLATE_URL; ?>images/random/tb (<?php echo rand(1,5);?>).jpg" id="login_img" title="<?php echo $blogname;?>欢迎您，管理员请点击登陆" alt="头像">
					<?php endif;?>
				</a>
				</p>
			</div><!--end login-->
		</div>
		
		<div class="space"></div>
		
		<div class="nv"><?php blog_navi();?></div>
		<div id="banner">
			<a href="<?php echo $bannerUrl;?>" target="_blank">
				<img src="<?php echo BLOG_URL.Option::get('topimg'); ?>"width="960px" border="0"/>
			</a>
		</div><!--end banner-->
	</div><!--end wp-->
</div><!--end hd-->
<div id="wp" class="wp">