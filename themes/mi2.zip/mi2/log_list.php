<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="serpage">
	<a  href="<?php echo $guestBook?>" class="guestbookimg" title="前往留言板"></a>
	<div class="pagelist">  
			<?php echo $page_url;?> 
			<?php if($page_url): ?>
				<span class="pageinfo">第 <b><?php echo $page; ?></b> 页 / 共 <b><?php echo ceil($lognum/$index_lognum); ?></b> 页</span>
			<?php endif; ?>
	</div>
</div>
	
<span class="serch">
	<form name="keyform" id="searchform" method="get" action="<?php echo BLOG_URL; ?>index.php">
    <input name="keyword" id="s" class="text" type="text" value="输入关键词" onfocus="if(this.value=='输入关键词') this.value=''" onblur="if(this.value=='') this.value='输入关键词'">
    <input name="keyword" class="submit" type="submit" value="搜索">
    </form>
</span>

<div class="content">
<?php doAction('index_loglist_top'); ?>
<div class="listtop">
		<?php if (isset($tag)):?>
		<span class="navtopnotice">>>包含标签 【<?php echo $tag; ?>】 的文章</span>
		<?php elseif (isset($sortid)): ?>
		<?php global $CACHE; $sort_cache = $CACHE->readCache('sort'); ?>
		<span class="navtopnotice">>>以下是分类【<?php echo $sort_cache[$sortid]['sortname']; ?>】里的文章</span>
		
		<?php elseif (isset($author)): ?>
		<span class="navtopnotice">>>作者 【<?php echo $author; ?>】 的文章</span>
		
		<?php elseif (isset($keyword)):?>
		<span class="navtopnotice">>>含有搜索词 【<?php echo $keyword; ?>】 的文章</span>
		
		<?php elseif (isset($record)):?>
		<span class="navtopnotice">>>存档于 【<?php echo $record; ?>】 的文章</span>
		<?php else:?>		
<span class="listtopSpan">碎语轮播：</span>
	<div id="pt" class="bm cl">
		<div class="z">
		 <div id="notice">
				<?php
					global $CACHE; 
					$newtws_cache = $CACHE->readCache('newtw');
					$istwitter = Option::get('istwitter');
					foreach($newtws_cache as $value):
				?>
				<ul>
					<li>
						<a href="<?php echo BLOG_URL . 't/'; ?>"><?php echo substr($value['t'],0,100); ?></a>
					</li>
				</ul>
				<?php endforeach; ?>
				</div>
				<div style="clear:both;"></div>
				<script>
					var c, _ = Function;
					with( o = document.getElementById("notice")) {
						innerHTML += innerHTML;
						onmouseover = _("c=1");
						onmouseout = _("c=0");
					}( F = _("if(#%27||!c)#++,#%=o.scrollHeight>>1;setTimeout(F,#%27?10:4000);".replace(/#/g, "o.scrollTop")))();
				</script>
		</div>
	</div><!--end #pt-->
			<?php endif; ?>
</div><!--listtop-->

<!--日志列表-->
<?php foreach($logs as $value): ?>
<div class="lists">
	<div class="lists_l"><!---->
		<?php 	global $CACHE;
					$user_cache = $CACHE->readCache('user');?>
		<a href="<?php echo $value['log_url']; ?>">
		<?php if (!empty($user_cache[$value['author']]['photo']['src'])): ?>
		<img src="<?php echo BLOG_URL.$user_cache[$value['author']]['photo']['src']; ?>" alt="<?php echo $value['log_title']; ?>" title="<?php echo subString(strip_tags($value['log_description']),0,300); ?> --点击打开查看" height="49px"  width="49px"/>
		<?php else:?>
		<img src="<?php echo TEMPLATE_URL; ?>images/random/tb (<?php echo rand(1,5);?>).jpg" alt="<?php echo $value['log_title']; ?>" title="<?php echo subString(strip_tags($value['log_description']),0,300); ?> --点击打开查看" height="49px"  width="49px"/>
		<?php endif;?>
		</a>
	</div>
		
    <div class="lists_m">
        <div class="box">
          <div class="title">
			<img src="<?php echo TEMPLATE_URL; ?>images/random/file (<?php echo rand(1,11);?>).gif" alt="新文章" />
            <a href="<?php echo $value['log_url']; ?>" rel="bookmark" title="查看 <?php echo $value['log_title']; ?> 的详细内容"><?php topflg($value['top']); ?><?php echo $value['log_title']; ?></font></a>
          </div>
          <div class="read_total">
			<?php editflg($value['logid'],$value['author']); ?>
			<?php blog_sort($value['logid']); ?> 
			<a href="<?php echo $value['log_url']; ?>#tb">引用(<?php echo $value['tbcount']; ?>)</a>
			
			<?php blog_tag($value['logid']); ?>
		  </div>
         </div><!--end box-->
	 
    	 <div class="lists_r">   
        	<div class="info"><?php blog_author($value['author']); ?><br><?php echo gmdate('Y-n-j', $value['date']); ?></div>
        	<span id="comm"><a href="<?php echo $value['log_url']; ?>#comments" target="_blank">评论：<?php echo $value['comnum']; ?></a></span>
			<span id="views"><a href="<?php echo $value['log_url']; ?>">浏览：<?php echo $value['views']; ?></a></span>
    	 </div><!--end lists_r-->
     </div><!--end lists_m-->
	 <div style="clear:both"></div>
</div><!--end lists-->
<?php endforeach; ?>
       
<div class="serpage">
	<a  href="<?php echo $guestBook?>" class='guestbookimg'></a>
	<div class="pagelist">  
			<?php echo $page_url;?> 
			<?php if($page_url): ?>
				<span class="pageinfo">第 <b><?php echo $page; ?></b> 页 / 共 <b><?php echo ceil($lognum/$index_lognum); ?></b> 页</span>
			<?php endif; ?>&nbsp;&nbsp;&nbsp;
	</div>
</div>
</div><!-- end #content-->
<?php
	include View::getView('side');
	include View::getView('footer');
?>