<?php
	$authorID = '1';//侧边栏blogger中，要显示blogger的id，单用户博客一般为1，如何查看blogger id？：首页点作者名字，浏览器地址栏中的url中的author=1这个数字就是
	$bannerUrl = "http://zhangziheng.com";//banner的链接
	$guestBook = "http://zhangziheng.com";//首页图片 “留言”的链接
	$toptb_left_url = "
	<a href='http://zhangziheng.com' target='_blank'>子恒博客</a>
	<a href='http://zhangziheng.com' target='_blank'>子恒博客</a>
	
	
	";//设置顶部左侧菜单
	$toptb_right_url = "
	<a href='http://zhangziheng.com' target='_blank'>子恒博客</a>
	<a href='http://zhangziheng.com' target='_blank'>子恒博客</a>
	
	
	";//设置顶部右侧菜单
	
	
?>
