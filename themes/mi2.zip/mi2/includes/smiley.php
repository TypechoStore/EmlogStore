﻿<script type="text/javascript">
/* <![CDATA[ */
    function grin(tag) {
    	var myField;
    	tag = ' ' + tag + ' ';
        if (document.getElementById('comment') && document.getElementById('comment').type == 'textarea') {
    		myField = document.getElementById('comment');
    	} else {
    		return false;
    	}
    	if (document.selection) {
    		myField.focus();
    		sel = document.selection.createRange();
    		sel.text = tag;
    		myField.focus();
    	}
    	else if (myField.selectionStart || myField.selectionStart == '0') {
    		var startPos = myField.selectionStart;
    		var endPos = myField.selectionEnd;
    		var cursorPos = endPos;
    		myField.value = myField.value.substring(0, startPos)
    					  + tag
    					  + myField.value.substring(endPos, myField.value.length);
    		cursorPos += tag.length;
    		myField.focus();
    		myField.selectionStart = cursorPos;
    		myField.selectionEnd = cursorPos;
    	}
    	else {
    		myField.value += tag;
    		myField.focus();
    	}
    }
/* ]]> */
</script>
<a href="javascript:grin('[1]')"><img src="<?php echo TEMPLATE_URL; ?>images/face/1.gif" /></a>
<a href="javascript:grin('[2]')"><img src="<?php echo TEMPLATE_URL; ?>images/face/2.gif" /></a>
<a href="javascript:grin('[3]')"><img src="<?php echo TEMPLATE_URL; ?>images/face/3.gif" /></a>
<a href="javascript:grin('[4]')"><img src="<?php echo TEMPLATE_URL; ?>images/face/4.gif" /></a>
<a href="javascript:grin('[5]')"><img src="<?php echo TEMPLATE_URL; ?>images/face/5.gif" /></a>
<a href="javascript:grin('[6]')"><img src="<?php echo TEMPLATE_URL; ?>images/face/6.gif" /></a>
<a href="javascript:grin('[7]')"><img src="<?php echo TEMPLATE_URL; ?>images/face/7.gif" /></a>
<a href="javascript:grin('[8]')"><img src="<?php echo TEMPLATE_URL; ?>images/face/8.gif" /></a>
<a href="javascript:grin('[9]')"><img src="<?php echo TEMPLATE_URL; ?>images/face/9.gif" /></a>
<a href="javascript:grin('[10]')"><img src="<?php echo TEMPLATE_URL; ?>images/face/10.gif" /></a>
<a href="javascript:grin('[11]')"><img src="<?php echo TEMPLATE_URL; ?>images/face/11.gif" /></a>
<a href="javascript:grin('[12]')"><img src="<?php echo TEMPLATE_URL; ?>images/face/12.gif" /></a>
<a href="javascript:grin('[13]')"><img src="<?php echo TEMPLATE_URL; ?>images/face/13.gif" /></a>
<a href="javascript:grin('[14]')"><img src="<?php echo TEMPLATE_URL; ?>images/face/14.gif" /></a>
<a href="javascript:grin('[15]')"><img src="<?php echo TEMPLATE_URL; ?>images/face/15.gif" /></a>
<a href="javascript:grin('[16]')"><img src="<?php echo TEMPLATE_URL; ?>images/face/16.gif" /></a>
<a href="javascript:grin('[17]')"><img src="<?php echo TEMPLATE_URL; ?>images/face/17.gif" /></a>
<a href="javascript:grin('[18]')"><img src="<?php echo TEMPLATE_URL; ?>images/face/18.gif" /></a>
<a href="javascript:grin('[19]')"><img src="<?php echo TEMPLATE_URL; ?>images/face/19.gif" /></a>

<br />

