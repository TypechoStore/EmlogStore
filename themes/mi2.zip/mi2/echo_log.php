<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="breadcrumbs" class="pagenav">
	<div class="bcrumbs"><strong><a href="<?php echo BLOG_URL; ?>" title="返回首页">home</a></strong>
	<span>><?php blog_sort($logid); ?>></span>
	<span><?php echo $log_title; ?></span>
	</div>
</div>	
<span class="serch">
	<form name="keyform" id="searchform" method="get" action="<?php echo BLOG_URL; ?>index.php">
	<input name="keyword" id="s" class="text" type="text" value="输入关键词" onfocus="if(this.value=='输入关键词') this.value=''" onblur="if(this.value=='') this.value='输入关键词'">
	<input name="keyword" class="submit" type="submit" value="搜索">
	</form>
</span>
	
<div id="echolog">
	<div class="content">
		<div id="loginfo">
			<?php 	global $CACHE;
				$user_cache = $CACHE->readCache('user');?>
            <span class="face_img">
				<?php if (!empty($user_cache[$author]['photo']['src'])): ?>
				<img src="<?php echo BLOG_URL.$user_cache[$author]['photo']['src']; ?>" alt="blogger"  title="本文作者:<?php echo $user_cache[$author]['name']; ?>"/>
				<?php else:?>
				<img src="<?php echo TEMPLATE_URL; ?>images/random/tb (<?php echo rand(1,5);?>).jpg" alt="blogger" title="本文作者:<?php echo $user_cache[$author]['name']; ?>" />
				<?php endif;?>
			</span>	
			<h2 title="<?php echo $log_title; ?>"><?php echo $log_title; ?></a></h2>
			<span class="info">
			由 <?php blog_author($author); ?> 发布于 <?php blog_sort($logid); ?>  <?php echo gmdate('Y-m-d', $date); ?>&nbsp;[ <?php echo ($views); ?> ] 次浏览 [ <?php echo ($comnum); ?> ] 条评论</span>
			<p class="tag"><?php blog_tag($logid); ?></p>
		</div><!--end loginfo-->
		<div class="post_content">
		<!--正文-->
			<?php echo $log_content; ?>
		</div>
		
		<?php neighbor_log($neighborLog); ?>
		<?php doAction('log_related', $logData); ?>
		<?php if($allow_remark == 'y'): ?>
			<?php $comnum = ($comnum != 0) ? '目前有 '.$comnum.' 条留言' : '等您坐沙发呢！'; ?>
			<h3 id="comments" style="margin-bottom:10px"><?php echo $log_title; ?>：<?php echo $comnum; ?></h3>
			<?php blog_comments($comments,$params); ?>
			<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
		<?php endif; ?>
	</div>
</div><!--end echolog-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>