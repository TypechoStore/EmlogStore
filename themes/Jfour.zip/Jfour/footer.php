<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="clear"></div>
<div class="footer">Powered by <a href="http://www.emlog.net" title="采用emlog系统">emlog</a>丨Theme BY <a href="http://www.im050.com/">MEMORY</a>丨Modify BY <a href="http://azt-lmt.com">azt-lmt.com</a>丨<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>丨 <?php echo $footer_info; ?>
	</div><?php doAction('index_footer'); ?>
        </div>
<script src="<?php echo TEMPLATE_URL; ?>scripts/jquery.poshytip.min.js?ver=1.2"></script>
<script src="<?php echo TEMPLATE_URL; ?>scripts/custom.js?ver=1.0"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>comments-ajax.js?ver=3.9.2"></script>
<script>
	//文章页图片自适应
	function responsiveImg() {
		var img_count=(jQuery('.article .content').find('img')).length;
		if (img_count != 0) {
		var maxwidth=jQuery(".article .content").width();
		for (var i=0;i<=img_count-1;i++) {
			var max_width=jQuery('.article .content img:eq('+i+')');
				if (max_width.width() > maxwidth) {
					max_width.addClass('responsive-img');
				}
			}
		}
	}
	jQuery(function(){
		responsiveImg();
		window.onresize = function(){
			responsiveImg();
		}
	});
	</script>
    <script type="text/javascript">
/* <![CDATA[ */
var mejsL10n = {"language":"zh-CN","strings":{"Close":"\u5173\u95ed","Fullscreen":"\u5168\u5c4f","Download File":"\u4e0b\u8f7d\u6587\u4ef6","Download Video":"\u4e0b\u8f7d\u89c6\u9891","Play\/Pause":"\u64ad\u653e\/\u6682\u505c","Mute Toggle":"\u5207\u6362\u9759\u97f3","None":"\u65e0","Turn off Fullscreen":"\u5173\u95ed\u5168\u5c4f","Go Fullscreen":"\u5168\u5c4f","Unmute":"\u53d6\u6d88\u9759\u97f3","Mute":"\u9759\u97f3","Captions\/Subtitles":"\u5b57\u5e55"}};
var _wpmejsSettings = {"pluginPath":"\/wp\/wp-includes\/js\/mediaelement\/"};
/* ]]> */
</script>
</body>
</html>
    