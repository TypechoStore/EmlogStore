<?php

/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
		//主题公告
		'zz' => array(
		'type' => 'text',
		'name' => '主题公告',
		'description' => '<iframe src="http://azt-lmt.com/line/theme-Jfore.html" width="100%" height="70" frameborder="0"></iframe>',
		'default' => '去不掉的input，对主题有问题请联系企鹅993745241，另外承接博客主题扒皮服务，价格公道',
		),	
		'logo' => array(
        'type' => 'image',
        'name' => '左侧头像',
        'values' => array(
            TEMPLATE_URL . 'images/face.png',
        ),
		'description' => '站点左侧头像，建议png格式，大小正方形。不能上传请手动ftp',
    ),
	'xinlangshow' => array(
	    'type' => 'text',
		'name' => '新浪微博',
		'description' => '新浪微博show地址，这个应该不难懂吧',
		'default' => 'http://widget.weibo.com/weiboshow/index.php?language=&width=0&height=900&fansRow=1&ptype=1&speed=0&skin=10&isTitle=1&noborder=1&isWeibo=1&isFans=1&uid=3543644175&verifier=a5fc16e5&dpc=1',
	),
	'qq' => array(
	    'type' => 'text',
		'name' => '站长qq',
		'default' => '993745241',
	),
	'weixin' => array(
	    'type' => 'text',
		'name' => '微信号',
		'default' => 'VIP_LPJ',
	),
	'facename' => array(
	    'type' => 'text',
		'name' => '站长贵姓',
		'default' => '	刘木头',
	),
	'dis_num' => array(
		'type' => 'text',
		'name' => '自动摘要字符数',
		'description' => '请根据需要输入整数以控制首页摘要的字符数量',
		'default' => '490',
	),
	'slt' => array(
	    'type' => 'radio',
		'name' => 'TimThumb缩略图神器',
	    'description' => '如果使用，到模版目录中cache权限设置777，如果不使用可能导致图片变形严重，建议在从别的地方扒文章时将图片另行保存再重新上传',
		'values' => array(
			'yes' => '使用',
			'no' => '禁用',
		),
		'default' => 'no',
	),
	'css' => array(
	    'type' => 'radio',
		'name' => 'css样式',
	    'description' => '选择博客模板样式，红橙绿',
		'values' => array(
			'red' => '红',
			'orange' => '橙',
			'green' => '绿',
		),
		'default' => 'red',
	),
);