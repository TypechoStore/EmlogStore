<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="container">
	<div class="article-list">
		<article class="article">
		<h1><a href="<?php echo $value['log_url']; ?>" title="<?php echo $log_title; ?>" alt="<?php echo $log_title; ?>
		"><?php echo $log_title; ?>
		</a></h1>
		<div class="content">
			<p>
				<?php echo $log_content; ?>
			</p>
			<div class="article-copyright">
				<i class="fa fa-share-alt"></i> 码字很辛苦，转载请注明来自<b>.<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?>
				</a>.</b>的<a href="<?php echo $value['log_url']; ?>">《<?php echo $log_title; ?>
				》</a>
			</div>
		</div>
		<div class="article-info">
			<i class="fa fa-calendar"></i><?php echo gmdate('m-d', $date); ?>
			 &nbsp; <i class="fa fa-map-marker"></i>
			<?php echo $views; ?>人浏览
		</div>
		</article>
		<section class="comments">
		<?php blog_comments($comments,$comnum); ?>
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
		</section>
		<?php include View::getView('footer');?>
	</div>
	<?php include View::getView('side');?>
</div>