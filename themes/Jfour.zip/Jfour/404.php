<?php
 include View::getView('header');
?>
    <div class="container">
    	<div class="article-list">
			<article class="article">
            <div class="feature-img">
                	<a title="404出错提醒：没有找到相关页面" alt="404，没有找到"><img width="1000" height="300" src="<?php echo TEMPLATE_URL; ?>timthumb.php?src=<?php echo TEMPLATE_URL; ?>404.jpg&h=300&w=1000&zc=1" class="attachment-post-thumbnail wp-post-image" alt="simplehome"></a>
                </div>
           <h1><a title="404出错提示，没有找到">404木有找到</a></h1>
                <div class="content">
                <p>404出错提醒：没有找到相关页面</p>
                </div>
                <div class="article-info">
                </div>
                <div class="readmore"><a title="404出错提醒：没有找到相关页面" >+ 阅读全文丨0℃</a></div>            </article> 
<?php include View::getView('side');?>
    </div>
 <?php include View::getView('footer');?>