<?php
/*
Template Name:仿魅族论坛
Description:仿魅族论坛
Version:1.0
Author:goodstudy
Author Url:htt://blog.wdyun.cn
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
//自定义相关设置
//require_once View::getView('option');
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>meizu.css" rel="stylesheet" type="text/css" />
<script src="http://lib.sinaapp.com/js/jquery/1.7.2/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<!--[if IE 6]>
<script src="<?php echo TEMPLATE_URL; ?>iefix.js" type="text/javascript"></script>
<![endif]-->
<!--[if lt IE 8]>
<script type="text/javascript">
	$(function(){
		//不支持css3 :last-child时
		var lilength=$("#nav .bar .item").length;
		$($("#nav .bar .item")[lilength-1]).css({'border-right':"none"})
	})
</script>
<![endif]-->
<style>
	#logo{
		background:url(<?php echo _g('logo');?>) no-repeat;
	}
</style>
<?php doAction('index_head'); ?>
</head>
<body>

<div id="head">
	<div id="w_header">
		<div class="m_top">
			<div id="logo"><a href="<?php echo BLOG_URL; ?>"></a></div>
			<div id="nav"><?php blog_navi();?></div>
			<div style="clear:both"></div>
		</div>
	</div>
	<div class="wp">
		<div id="nv" >
		<a href="<?php echo BLOG_URL; ?>">首页</a>
<?php if ($params[1]=='sort'){ ?>
		<?php echo '&nbsp;&gt;&nbsp;<a href="'.Url::sort($sortid).'">'.$sortName.'</a>';?>
<?php }elseif ($params[1]=='tag'){ ?>
			&nbsp;&gt;&nbsp; 包含标签 <b><?php echo htmlspecialchars(urldecode($params[2]));?></b> 的所有文章
<?php }elseif($params[1]=='author'){ ?>
			&nbsp;&gt;&nbsp; 作者 <b><?php echo blog_author($author);?></b> 的所有文章
<?php }elseif($params[1]=='keyword'){ ?>
            &nbsp;&gt;&nbsp; 搜索 <b><?php echo htmlspecialchars(urldecode($params[2]));?></b> 的归档
<?php }elseif($logid==true){?>
		 <?php blog_sort($logid); ?>
<?php }elseif($params[1]=='record'){?>
		&nbsp;&gt;&nbsp; <b><?php echo substr(urldecode($params[2]),0,4).'年'.substr(urldecode($params[2]),4,2).'月';?></b> 的结果
<?php }else{}?>
		</div>
		<div id="scbar" class="cl">
			<form id="scbar_form" autocomplete="off" target="_blank" method="get" action="<?php echo BLOG_URL; ?>index.php">
				<div class="scbar_wrap">
					<input type="text" name="keyword" id="scbar_txt" autocomplete="off" class="xg1" placeholder="搜索话题和用户">
					<button type="submit" id="scbar_btn"></button>
				</div>
			</form>
		</div>
		<div style="clear:both"></div>
	</div>
	<div style="clear:both"></div>
</div>
