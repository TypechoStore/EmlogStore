<?php 
/**
 * 侧边栏
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div class="index_right">
		<div class="index_right_2">
		<?php 
		$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
		doAction('diff_side');
		foreach ($widgets as $val)
		{
			$widget_title = @unserialize($options_cache['widget_title']);
			$custom_widget = @unserialize($options_cache['custom_widget']);
			if(strpos($val, 'custom_wg_') === 0)
			{
				$callback = 'widget_custom_text';
				if(function_exists($callback))
				{
					call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
				}
			}else{
				$callback = 'widget_'.$val;
				if(function_exists($callback))
				{
					preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
					$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
					call_user_func($callback, htmlspecialchars($wgTitle));
				}
			}
		}
		?>
			<?php 
			if (blog_tool_ishome()){
			?>
			<!--微博微信-->
			<div class="column_r5">
				<div class="tagbox2" style="background-color:#FFFFFF;">
					<div class="tag_tags">
						<div id="bbs_firmware_push_get" class="tg activity" style="cursor: pointer;">官方微博</div>
						<div id="bbs_system_course_get" class="tg" style="cursor: pointer;">官方微信</div>
						<div class="cr"></div>
					</div>
					<div class="cr"></div>
					<div class="tag_main">
						<div class="ctag" id="bbs_firmware_push_get_x"style="overflow: hidden; display: block;">
							<?php echo _g('weiboIframe');?>
						</div>
						<div class="ctag" id="bbs_system_course_get_x" style="overflow: hidden; display: none;text-align:center">
							<a href="javascript:;" target="_blank"><img src="<?php echo _g('weixinImgUrl');?>" width="230" height="230" title="官方微信"></a>
							<div class="text mhometitle1"><a class="cg" title="官方微信" href="javascript:;" target="_blank">官方微信</a></div>
						</div>
					</div>
				</div>
			</div>
			<script  type="text/javascript">
			$(function(){
				$('#bbs_firmware_push_get').mouseover(function(){
					$('#bbs_firmware_push_get').addClass('activity');
					$('#bbs_system_course_get').removeClass('activity');
					$('#bbs_firmware_push_get_x').css({'display':'block'})
					$('#bbs_system_course_get_x').css({'display':'none'})
				})
				$('#bbs_system_course_get').mouseover(function(){
					$('#bbs_system_course_get').addClass('activity');
					$('#bbs_firmware_push_get').removeClass('activity');
					$('#bbs_firmware_push_get_x').css({'display':'none'})
					$('#bbs_system_course_get_x').css({'display':'block'})
				})
				
			})
			</script>
			<?php
			}
			?>
		</div>
		
	</div>
	

