<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="wp" class="wp">
		<div class="wp cl">
			
			<div id="ct" class="plate_mn postcontbox_mn">
				<div id="postlist" class="pl bm wp_postlist">
				
					<div class="blg_content" style="margin-top:20px;">
						<div class="position: relative;">
							<div class="headimg">
								<img src="<?php echo TEMPLATE_URL.'img/headerimg/'. rand(1,18).'.png'?>" width=70 height=70>
							</div>
							<div class="blg_content_title">
								<h2><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><?php echo $log_title; ?></h2>
								<div>
								<span class="authorspan"><?php blog_author($author); ?></span>
								<div class="barr_post">
									<span id="edit"><?php editflg($logid,$author); ?></span>
									<span class="xi1"><?php echo $comnum;?></span>
									<span class="replyicon_uinfo"></span>
									<span class="xi1"><?php echo $views; ?></span>
									<span class="readicon_uinfo"></span>
									
									<span class="xi1"><?php echo gmdate('n-j', $date); ?> </span>
								</div>
								</div>
							</div>
						</div>
						<div style="clear:both"></div>
						<div class="echo_content">
						<?php echo $log_content; ?>
						</div>
				
						<div style="clear:both;"></div>
					</div>
				</div>
				<!--评论-->
				<div class="pl replypost_postlist">
					<?php blog_comments($comments); ?>
					<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
					<div style="clear:both"></div>
				</div>
				
			</div>
		</div>	
	

<?php
 include View::getView('side');
 include View::getView('footer');
?>