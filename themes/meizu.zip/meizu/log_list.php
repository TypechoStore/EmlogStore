<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
	if(blog_tool_ishome()==true){
		include View::getView('index');
	}else{
?>
	<div id="wp" class="wp">
		<div class="wp cl">
			<div class="index_content">
				<div class="index_left">
					<div class="blog_list">
						<ul>
						<?php doAction('index_loglist_top'); ?>
						<?php 
						if (!empty($logs)):
						foreach($logs as $value): 
						?>
							<li>
								<div class="blog_list_img"><img src="<?php echo TEMPLATE_URL.'img/headerimg/'. rand(1,18).'.png'?>" width=50 height=50></div>
								<span class="blog_list_title"><a href="<?php echo $value['log_url']; ?>"><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><?php echo $value['log_title']; ?></a></span>
								<p class="blog_list_info">
									<?php blog_author($value['author']);?><?php echo gmdate('Y-n-j', $value['date']); ?> 
								</p>
							</li>
							
							
							
							
							<div style="clear:both;"></div>
						<?php 
						endforeach;
						else:
						?>
							<h2>未找到</h2>
							<p>抱歉，没有符合您查询条件的结果。</p>
						<?php endif;?>
						</ul>
						<div id="pagenavi">
							<?php echo $page_url;?>
						</div>
					</div>
				</div>
			</div>


<?php
	include View::getView('side');
	include View::getView('footer');
	}
?>
