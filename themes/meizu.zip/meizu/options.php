<?php
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
	
	//logo设置
	'logo' => array(
		'type' => 'image',
		'name' => 'logo设置',
		'values' => array(
            TEMPLATE_URL . 'img/logo.png',
        ),
		'description' => 'logo分辨率 115px X 25px'
	),
	
	
	//侧边栏相关设置
	//侧栏微博秀
	'weiboIframe' => array(
		'type' => 'text',
		'name' => '侧栏微博秀',
		'multi' => true,
		'default' => '<iframe width="270" height="400" class="share_self" frameborder="0" scrolling="no" src="http://widget.weibo.com/weiboshow/index.php?language=&amp;width=270&amp;height=400&amp;fansRow=2&amp;ptype=1&amp;speed=0&amp;skin=5&amp;isTitle=0&amp;noborder=1&amp;isWeibo=1&amp;isFans=0&amp;uid=2992465674&amp;verifier=96b7574e&amp;colors=FFFFFF,ffffff,666666,0082cb,FFFFFF&amp;dpc=1"></iframe>', 
		'description' => '微博秀请到<span style="color:red"><a href="http://app.weibo.com/tool/weiboshow">http://app.weibo.com/tool/weiboshow</a></span>开启，不知道的直接问我！参考甚至如下图：<br/><img src='.TEMPLATE_URL.'img/weiboxiu/1.png ><img src='.TEMPLATE_URL.'img/weiboxiu/2.png ><br/>'
	),
	//侧栏微信图
	'weixinImgUrl' => array (
		'type' => 'image',
		'name' => '侧栏微信图',
		'values' => array(
            TEMPLATE_URL . 'img/weixinImg.jpg',
        )
	),
	
	//底部相关设置
	//底部"关于我们"链接开关
	'isOpenAboutUrl' => array (
		'type' => 'radio',
		'name' => '底部"关于我们"链接开关',
		'values' => array(
			'yes' => '开启',
			'no' => '关闭',
		),
		'default' => 'yes',
		'description' => '底部"关于我们"链接开关 <span style="color:red">注意:底部"关于我们"链接开关设为关闭则链接地址无效</span>'
	),
	//底部"关于我们"链接地址
	'aboutUrl' => array (
		'type' => 'text',
		'name' => '底部"关于我们"链接地址',
		'default' => 'about.html',
		'description' => '底部"关于我们"链接地址 <span style="color:red">注意:底部"关于我们"链接开关设为关闭则链接地址无效</span>'
	),
	
	
	//底部"法律声明"链接开关
	'isOpenLawUrl' => array (
		'type' => 'radio',
		'name' => '底部"法律声明"链接开关',
		'values' => array(
			'yes' => '开启',
			'no' => '关闭',
		),
		'default' => 'yes',
		'description' => '底部"法律声明"链接开关 <span style="color:red">注意:底部"法律声明"链接开关设为关闭则链接地址无效</span>'
	),
	//底部"法律声明"链接地址
	'lawUrl' => array (
		'type' => 'text',
		'name' => '底部"法律声明"链接地址',
		'default' => 'law.html',
		'description' => '底部"法律声明"链接地址 <span style="color:red">注意:底部"法律声明"链接开关设为关闭则链接地址无效</span>'
	),
	
	
	//底部"联系我们"链接开关
	'isOpenContactUrl' => array (
		'type' => 'radio',
		'name' => '底部"联系我们"链接开关',
		'values' => array(
			'yes' => '开启',
			'no' => '关闭',
		),
		'default' => 'yes',
		'description' => '底部"联系我们"链接开关 <span style="color:red">注意:底部"联系我们"链接开关设为关闭则链接地址无效</span>'
	),
	//底部"联系我们"链接地址
	'contactUrl' => array (
		'type' => 'text',
		'name' => '底部"联系我们"链接地址',
		'default' => 'contact.html',
		'description' => '底部"联系我们"链接地址 <span style="color:red">注意:底部"联系我们"链接开关设为关闭则链接地址无效</span>'
	),
	
	
	//底部新浪微博链接开关
	'isOpenSinaWeiboUrl' => array (
		'type' => 'radio',
		'name' => '底部新浪微博链接开关',
		'values' => array(
			'yes' => '开启',
			'no' => '关闭',
		),
		'default' => 'yes',
		'description' => '底部新浪微博链接开关 <span style="color:red">注意:底部新浪微博链接开关设为关闭则链接地址无效</span>'
	),
	//底部新浪微博链接地址
	'sinaWeiboUrl' => array (
		'type' => 'text',
		'name' => '底部新浪微博链接地址',
		'default' => 'http://weibo.com/p/1006062683843043',
		'description' => '底部新浪微博链接地址 <span style="color:red">注意:底部新浪微博链接开关设为关闭则链接地址无效</span>'
	),
	
	
	//底部腾讯微博链接开关
	'isOpenTencentWeiboUrl' => array (
		'type' => 'radio',
		'name' => '底部腾讯微博链接开关',
		'values' => array(
			'yes' => '开启',
			'no' => '关闭',
		),
		'default' => 'no',
		'description' => '底部腾讯微博链接开关 <span style="color:red">注意:底部腾讯微博链接开关设为关闭则链接地址无效</span>'
	),
	//底部腾讯微博链接地址
	'tencentWeiboUrl' => array (
		'type' => 'text',
		'name' => '底部腾讯微博链接地址',
		'default' => 'http://weibo.com/p/1006062683843043',
		'description' => '底部腾讯微博链接地址 <span style="color:red">注意:底部腾讯微博链接开关设为关闭则链接地址无效</span>'
	)
	
);
?>
		