<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="wp" class="wp">
		<div class="wp">
			<div class="index_content">
				<div class="index_left">
					<!--首页图文章-->
					<!--图片展示-->
					<script type="text/javascript">
					$(function() {
						var sWidth = $("#focus").width(); //获取焦点图的宽度（显示面积）
						var sHeight = $("#focus").height();//获取焦点图的高度
						var len = $("#focus ul li").length; //获取焦点图个数
						var index = 0;
						var picTimer;
						
						//以下代码添加数字按钮和按钮后的半透明条，还有上一页、下一页两个按钮
						var btn = "<div class='btnBg'></div><div><div class='btn'>";
						for(var i=0; i < len; i++) {
							btn += "<span></span>";
						}
						btn += "</div></div><div id='focus2'><div class='preNext pre'></div><div class='preNext next'></div></div>";
						$("#focus").append(btn);
						$("#focus .btnBg").css("opacity",0.5);
						$("#focus .preNext").css('top',(sHeight-100)/2-10);
						
						//为小按钮添加鼠标滑入事件，以显示相应的内容
						$("#focus .btn span").css("opacity",0.4).mouseover(function() {
							index = $("#focus .btn span").index(this);
							showPics(index);
						}).eq(0).trigger("mouseover");

						//上一页、下一页按钮透明度处理
						$("#focus .preNext").css("opacity",0.2).hover(function() {
							$(this).stop(true,false).animate({"opacity":"0.5"},250);
						},function() {
							$(this).stop(true,false).animate({"opacity":"0.2"},250);
						});

						//上一页按钮
						$("#focus .pre").click(function() {
							index -= 1;
							if(index == -1) {index = len - 1;}
							showPics(index);
						});

						//下一页按钮
						$("#focus .next").click(function() {
							index += 1;
							if(index == len) {index = 0;}
							showPics(index);
						});

						//本例为左右滚动，即所有li元素都是在同一排向左浮动，所以这里需要计算出外围ul元素的宽度
						$("#focus ul").css("width",sWidth * (len));
						$("#focus ul li").css("width",sWidth);
						//鼠标滑上焦点图时停止自动播放，滑出时开始自动播放
						$("#focus").hover(function() {
							clearInterval(picTimer);
						},function() {
							picTimer = setInterval(function() {
								showPics(index);
								index++;
								if(index == len) {index = 0;}
							},3000); //此4000代表自动播放的间隔，单位：毫秒
						}).trigger("mouseleave");
						
						//显示图片函数，根据接收的index值显示相应的内容
						function showPics(index) { //普通切换
							var nowLeft = -index*sWidth; //根据index值计算ul元素的left值
							$("#focus ul").stop(true,false).animate({"left":nowLeft},250); //通过animate()调整ul元素滚动到计算出的position
							//$("#focus .btn span").removeClass("on").eq(index).addClass("on"); //为当前的按钮切换到选中的效果
							$("#focus .btn span").stop(true,false).animate({"opacity":"0.4"},250).eq(index).stop(true,false).animate({"opacity":"1"},250); //为当前的按钮切换到选中的效果
						}
					
					});
					
					</script>
					
					<div class="box1">
					<div id="picslider">
						<div id="focus" >
							<ul>
						
							<?php
								
								$imgs = getSYT('首页图');
								$imgArr=array();
								 for($i=0; $i<count($imgs); $i++ ){
									preg_match("/<img([^>]+)src=\"([^>\"]+)\"?([^>]*)>/i",$imgs[$i]['excerpt'],$matches);//从摘要找首页配图
									if(isset($matches[2])){
										$imgArr[$i]['imgSrc']=$matches[2];
										//$imgArr[$i]['logGid']=$imgs[$i][0]['gid'];
										//$imgArr[$i]['logTitle']=$imgs[$i][0]['title'];	
										$imgArr[$i]['logGid']=$imgs[$i]['gid'];
										$imgArr[$i]['logTitle']=$imgs[$i]['title'];												
									} 
								}
								for($k=0;$k<count($imgArr);$k++){
									
								?>	
								<li>
									<a href="<?php echo url::log($imgArr[$k]['logGid']);?>">
										<span class="picspan picspan2" style="background:url(<?php echo $imgArr[$k]['imgSrc']; ?>) no-repeat top;"></span><?php// title="<?php echo $imgArr[$k]['logTitle']; ?>
									 </a>		 
								</li>
								<?php
								}	
								//不存在首页图标签时，输出默认首页图
								if(count($imgArr)==0){
								?>
								<li><a href="javascript:void(0)"><span class="picspan picspan2" style="background:url(http://bbsimg.meizu.net/block/f6/f6afe0b38fe81e7be2317aa341f688a3.jpg) no-repeat top;"></span></a></li>
								<?php
								}
								 ?>
							</ul>
						</div>
					</div>
					
					</div>
					
					<!--全局置顶类文章-->
					<?php
					//var_dump(getTopBlog());
					$toplogs=getTopBlog();
					
					foreach($toplogs as $value){
					?>
					<div class="index_list mtop20">
						<div>          
							<div class="iimage">
								<a class="is_image" href="<?php echo url::log($value['gid']);?>" target="_blank">
								<?php
									preg_match_all("/<img([^>]+)src=\"([^>\"]+)\"?([^>]*)>/i",$value['excerpt'],$matches);//从摘要找首页配图
									//var_dump($matches[2]);
									if(isset($matches[2])){
										$imgurl = $matches[2][1]?$matches[2][1]:$matches[2][0];		
									}else{
										$imgurl = TEMPLATE_URL.'img/topimg/'.rand(1,9).'.png';//topimg为空中 311X214
									} 
								?>
									<img src="<?php echo $imgurl;?>" width="311" height="213" title="<?php echo htmlspecialchars($value['title']); ?>">
								</a>
							</div>          
							<div class="iright_k"> 
								<div class="ititle">          	
								<div class="index_forum"><?php new_blog_tag($value['gid']); ?></div>
								<div class="cr"></div>          
								</div>
								<div class="index_title" style="margin:3px 0 3px 0;">
									<a class="cg" target="_blank" href="<?php echo url::log($value['gid']);?>" title="<?php echo  htmlspecialchars($value['title']); ?>"><?php echo $value['title']; ?></a>
								</div>
								<div style="font-size:12px;margin:12px 0 10px 0;"> 	
									<span class="readicon_uinfo_5" style="margin:0 4px 0 0;float:left;"></span>
									<span class="spfont"><?php echo $value['views']; ?></span>
									<span class="replyicon_uinfo_5" style="margin:0 4px 0 20px;float:left;"></span>
									<span class="spfont"><?php echo $value['comnum']; ?></span>
									<span class="spfont" style="margin:0 0 0 20px;">/ <?php blog_author($value['author']); ?></span>
									<span class="spfont" style="margin:0 0 0 20px;">/ <span title="<?php echo gmdate('n-j', $value['date']); ?>"><?php echo gmdate('n-j', $value['date']); ?></span></span>
									
									<div class="cr"></div>
								</div>          
								<div class="icontent">
								<?php echo left(extractHTMLData($value['excerpt'],2048),70);?><span class="spfont alte" style="float:none;text-align:right;"><a class="alink" href="<?php echo url::log($value['gid']);?>">阅读全文</a></span>   
								</div>          
								<!--div class="itail">
									<div class="ishare">
										<span class="bdsharebuttonbox isharebtn">      
											  <a class="bds_tsina" href="" target="_blank">分享</a>
										</span>
									</div>                  
									<div class="cr"></div>          
								</div-->
							</div> 
							<div class="cr"></div> 						
						</div>
					</div>
					<?php
					}
					
					?>
					<div class="index_list mtop20 community_heat" style="padding:20px 20px 20px 20px;">
					<?php
						index_hotlog('热门文章');
					?>
					</div>
					
				</div>
			</div>
			






<?php
 include View::getView('side');
 include View::getView('footer');
?>