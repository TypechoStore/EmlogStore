<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div style="clear:both;"></div>
<div class="tborder_foot"></div>
<div id="Footer" class="cl">
        <div id="footer1">
			<?php 
			if(_g('isOpenAboutUrl')==='yes'){ ?>
				<a class="bottoma" target="_blank" href="<?php echo BLOG_URL._g('aboutUrl') ;?>">关于本站</a>
			<?php 
				if(_g('isOpenLawUrl')==='yes'||_g('isOpenContactUrl')==='yes'){
			?>
				 <img class="footline" src="<?php echo TEMPLATE_URL; ?>img/space.gif">
			<?php
				}
			} 
			?>	
           
			<?php 
			if(_g('isOpenLawUrl')==='yes'){ ?>
				<a class="bottoma" target="_blank" href="<?php echo BLOG_URL._g('lawUrl') ;?>">法律声明</a>
			<?php
				if(_g('isOpenContactUrl')==='yes'){
			?>
				 <img class="footline" src="<?php echo TEMPLATE_URL; ?>img/space.gif">
			<?php
				}
			} 
			?>
			
			<?php 
			if(_g('isOpenContactUrl')==='yes'){ ?>
				<a class="bottoma" target="_blank" href="<?php echo BLOG_URL._g('contactUrl') ;?>">联系我们</a>
			<?php } ?>	
            
            <div id="footWeibo">
			<?php if(_g('isOpenSinaWeiboUrl')==='yes'){ ?>
                <a class="sina" title="新浪微博" target="_blank" href="<?php echo _g('sinaWeiboUrl');?>"></a>
			<?php } ?>	
			
			<?php if(_g('isOpenTencentWeiboUrl')==='yes'){ ?>
              <a class="tencent" title="腾讯微博" href="<?php echo  _g('tencentWeiboUrl');?>" target="_blank"></a>
			<?php } ?>	
                
            </div>
        </div>
        <div id="footer2" class="copyright">
			Themed By <a href="http://blog.wdyun.cn" title="goodstudy">goodstudy</a> Powered by <a href="http://www.emlog.net" title="采用emlog系统">emlog</a> 
			<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
			<?php doAction('index_footer'); ?>
        </div>
</div>
</div><!--end class wp-->
</div><!--end id wp-->
<div id="scrolltop2" style="right:50px;"> </div><script>

	$(function() {
		//回到顶部
		backTop();
		$('#scrolltop2').click(function(){
			$(document).scrollTop(0);	
		})
	});
	
	//回到顶部
	$(window).scroll(function(e){
		backTop();		
	})
	function backTop(){
		height = 100;
		scrollTop = $(document).scrollTop();
		if(scrollTop > height){
			$('#scrolltop2').show();
		}else{
			$('#scrolltop2').hide();
		}
	}
</script>
</body>
</html>