<?php 
/*
 * @emlog_Fanly-MIP
 * @authors 墨渊 (www.aeink.com)
 * @date    2017-02-07
 * @version 1.4
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
if (ROLE == ROLE_ADMIN):
require_once(EMLOG_ROOT.'/content/templates/emlog_Fanly-MIP/config.php');
//echo TEMPLATE_URL.'config.php';
require_once('setting_fun.php');
plugin_setting();
?>
<link rel="stylesheet" id="set-css" href="<?php echo BLOG_URL ?>/content/templates/emlog_Fanly-MIP/style/set.css" type="text/css" media="all">
<div id="container">
	<main id="posts">
 <form action="?setting&amp;do=save" method="post" id="input" class="da-form">
  
<div class="set_cnt">

 
<div class="da-form-row">博客LOGO地址
<input size="10" name="logo_url" type="text" value="<?php echo $logo_url; ?>" >
</div>
<div class="da-form-row">PC站域名：
<input size="20" name="PC_site" type="text" value="<?php echo $PC_site; ?>" >
</div>
<div class="da-form-row">MIP域名：
<input size="20" name="MIP_site" type="text" value="<?php echo $MIP_site; ?>" >       
</div>
<div class="da-form-row">MIP Token
<input size="20" name="MIP_Token" type="text" value="<?php echo $MIP_Token; ?>"  >
</div>
<div class="da-form-row">MIP_cache_Authkey
<input size="10" name="MIP_cache_Authkey" type="text" value="<?php echo $MIP_cache_Authkey; ?>" >
</div>
<div class="da-form-row">百度统计token
<input size="10" name="bdtj_token" type="text" value="<?php echo $bdtj_token; ?>" >
</div>
<div class="da-form-row">百度网盟token
<input size="10" name="bdwm_token" type="text" value="<?php echo $bdwm_token; ?>" >
</div>
<div class="da-form-row">CNZZ_ID
<input size="10" name="cnzz_id" type="text" value="<?php echo $cnzz_id; ?>" >
</div>


<div class="da-form-row">
自定义css样式
<textarea name="css" rows="5" style="width: 100%;"><?php echo $css; ?></textarea>
</div>

<input type="submit" value="保 存" class="svae">
</div>
</form>
</main>
<?php else:?>
<?php 
emMsg('你还没有登录管理员用户！');
exit;
?> 
<?php endif; ?>
<?php
 include View::getView('footer');
?>