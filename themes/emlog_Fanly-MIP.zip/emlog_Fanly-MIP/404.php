<?php defined( 'ABSPATH' )  or exit; get_header(); ?>
<div id="container">
<div class="page">
<h2 class="page_title">404！ 该页面被吃掉了……</h2>
<div class="page_content">
<p><center>你试图访问的页面不存在于这个世上，可能已经被删除了，不解释……</br>当然，也有可能是你输入的网址有误，请检查一下，如果确实遇到问题欢迎联系站长。</center></p>
</div>
</div>
</div>
<div class="clear"></div>
<?php get_footer(); ?>