<?php 
/*
 * @emlog_Fanly-MIP
 * @authors 墨渊 (www.aeink.com)
 * @date    2017-02-07
 * @version 1.4
 */
if(!defined('EMLOG_ROOT')) {exit('emlog_dux Functions Requrire Emlog!');}
function d($str){
	$str = str_replace("'","\'",$str );
	return $str;
}
function plugin_setting(){
	$do = isset($_GET['do']) ? $_GET['do'] : '';
if ($do == 'update') {
	} elseif($do == 'save') {
		if(empty($_POST)){
			emMsg("修改失败，请重试！");
			return ;
		}
		 $logo_url = isset($_POST['logo_url']) ? d(trim($_POST['logo_url'])) : '';
		 $PC_site = isset($_POST['PC_site']) ? d(trim($_POST['PC_site'])) : '';
		 $MIP_site = isset($_POST['MIP_site']) ? d(trim($_POST['MIP_site'])) : '';
		 $MIP_Token = isset($_POST['MIP_Token']) ? d(trim($_POST['MIP_Token'])) : '';
		 $MIP_cache_Authkey = isset($_POST['MIP_cache_Authkey']) ? d(trim($_POST['MIP_cache_Authkey'])) : '';
		 $bdtj_token = isset($_POST['bdtj_token']) ? d(trim($_POST['bdtj_token'])) : '';
		 $bdwm_token = isset($_POST['bdwm_token']) ? d(trim($_POST['bdwm_token'])) : '';
		 $cnzz_id = isset($_POST['cnzz_id']) ? d(trim($_POST['cnzz_id'])) : '';
		 $css = isset($_POST['css']) ? d(trim($_POST['css'])) : '';
		 $data = "<?php
				 \$logo_url = '".$logo_url."';
	 			 \$PC_site = '".$PC_site."';
				 \$MIP_site = '".$MIP_site."';
				 \$MIP_Token = '".$MIP_Token."';
				 \$MIP_cache_Authkey = '".$MIP_cache_Authkey."';
		         \$bdtj_token = '".$bdtj_token."';
		         \$bdwm_token = '".$bdwm_token."';
		         \$cnzz_id = '".$cnzz_id."';			 
				 \$css = '".$css."';
	    ?>";
		$file = EMLOG_ROOT.'/content/templates/emlog_Fanly-MIP/config.php';
		@ $fp = fopen($file, 'wb') OR emMsg('读取文件失败，如果您使用的是Unix/Linux主机，请修改文件/content/templates/emlog_Fanly-MIP/config.phpnfig.php的权限为777。如果您使用的是Windows主机，请联系管理员，将该文件设为everyone可写');
		@ $fw =	fwrite($fp,$data) OR emMsg('写入文件失败，如果您使用的是Unix/Linux主机，请修改文件/content/templates/emlog_Fanly-MIP/config.php的权限为777。如果您使用的是Windows主机，请联系管理员，将该文件设为everyone可写');
		fclose($fp);
		emMsg("修改配置成功！",BLOG_URL.'?setting');
		//header("Location:?setting");
		}
}