<?php 
/**
 * 日志模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
	<div id="posts">
		<div id="posts-list">
<?php doAction('index_loglist_top'); ?>

<?php 
if (!empty($logs)):
foreach($logs as $key=>$value): 
	$picnum = pic($value['content']);
	$muti = False;
	if($picnum>=4){
		$muti = True;
	}else{
		if($module_thum=="0"){
			$imgsrc = GetThumFromContent($value['content']);
		}else{
			$imgsrc = get_thum($value['logid']);
		}
	}
	$keys = $key+1;
?>

		<div class="entry">
			<div class="entry-thumb">
				<a target="_blank" href="<?php echo $value['log_url']; ?>"><mip-img class="mip-img" alt="<?php echo $value['log_title']; ?>" src="<?php echo $imgsrc;?>"></mip-img></a>
			</div>
			<div class="entry-body">
				<h2 class="entry-title"><a target="_blank" href="<?php echo $value['log_url']; ?>" rel="bookmark"><?php echo $value['log_title']; ?></a></h2>
				<div class="entry-meta">
					<span class="entry-category-icon">评论(<?php echo $value['comnum']; ?>)</span>
					<span class="entry-views-icon">浏览(<?php echo $value['views']; ?>)</span>
				</div>
				<div class="entry-content">
					<?php echo $logdes = tool_purecontent($value['content'], 180); ?>
				</div>
			</div>
		</div>


<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>

<div class="prev-next">
	<?php echo sheli_fy($lognum,$index_lognum,$page,$pageurl);?>
	
</div>

</div><!-- end #contentleft-->
<?php
 /*include View::getView('side');*/
 include View::getView('footer');
?>