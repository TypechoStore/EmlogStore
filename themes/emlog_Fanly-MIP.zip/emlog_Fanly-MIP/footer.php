<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--end #content-->
<div id="footer">
	<div id="footer-body">
		<div id="footer-content">
			<a target="_blank" href="<?php echo $MIP_site; ?>/"><?php echo $blogname; ?></a> · 版权所有
			<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> 
			<p>Powered by <a href="http://www.emlog.net" title="骄傲的采用emlog系统">emlog</a> 	©  <a target="_blank" href="http://www.aeink.com/">Fanly-MIP</a> 
			</p>
			<!--?php echo $footer_info; ?-->
			<!--?php doAction('index_footer'); ?-->
		</div>
	</div>
</div>
<div class="clear"></div>
<?php //wp_footer(); ?>
<mip-stats-cnzz token="<?php echo $cnzz_id; ?>/"></mip-stats-cnzz><!--CNZZ-->
<mip-stats-baidu token="<?php echo $bdtj_token; ?>"></mip-stats-baidu><!--百度统计-->
<script src="https://mipcache.bdstatic.com/static/v1/mip.js"></script>
<script src="https://mipcache.bdstatic.com/static/v1/mip-nav-slidedown/mip-nav-slidedown.js"></script>
<script src="https://mipcache.bdstatic.com/static/v1/mip-stats-baidu/mip-stats-baidu.js"></script><!--百度统计-->
<script src="https://mipcache.bdstatic.com/static/v1/mip-link/mip-link.js"></script>
</body>
</html>