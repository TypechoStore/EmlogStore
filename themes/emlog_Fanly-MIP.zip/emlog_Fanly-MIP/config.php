<?php
				 $logo_url = 'http://ww2.sinaimg.cn/small/8c534571jw1fc22jbaczwj203f0163yb.jpg';
	 			 $PC_site = 'http://www.aeink.com';
				 $MIP_site = 'http://mip2.aeink.com';
				 $MIP_Token = 'DbHncVZJcV3FzstQ';
				 $MIP_cache_Authkey = 'a447213e14536069085c9423420475c9';
		         $bdtj_token = 'cbe693dafa28bf4892355d47859845b9';
		         $bdwm_token = '';
		         $cnzz_id = '1256674613';			 
				 $css = '';
	    ?>