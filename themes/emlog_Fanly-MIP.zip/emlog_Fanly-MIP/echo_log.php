<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
	<div class="post">	
	<h1 id="post-title"><?php topflg($top); ?><?php echo $log_title; ?></h2>
	<div id="post-category"><?php echo gmdate('Y-n-j', $date); ?>  <?php blog_author($author); ?> <?php blog_sort($logid); ?> <?php editflg($logid,$author); ?></div>
	<div class="post_content">
	<?php 
	$log=fanly_images($log_content);
	echo $log;

	?></div>
	<p class="tag"><?php blog_tag($logid); ?></p>
	<?php doAction('log_related', $logData); ?>
	<div class="section_title"><span>继续阅读</span></div>
	<div class="post_detail"><?php neighbor_log($neighborLog); ?></div>
	<!--?php blog_comments($comments); ?-->
	<!--?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?-->
	<div></div>
</div><!--end #contentleft-->
<?php
 /*include View::getView('side');*/
 include View::getView('footer');
?>