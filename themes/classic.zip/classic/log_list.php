<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');}
include View::getView('side');
?>
<?php doAction('index_loglist_top'); ?>
<?php
foreach($logs as $value):
?>
	<div class="logcontent">
	<div id="t">
	<?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><b><?php echo $value['log_title']; ?></b></a>
	<span class="sort"><?php blog_sort($value['logid']); ?></span>
	</div>
	<p id="date">post by <?php blog_author($value['author']); ?> / <?php echo gmdate('Y-n-j G:i l', $value['date']); ?>
	<span class="sort"><?php editflg($value['logid'],$value['author']); ?></span>
	</p>
	<div class="log_desc"><?php echo $value['log_description']; ?></div>
	<p><?php blog_tag($value['logid']); ?></p>
	
	<div align="right">
	<a href="<?php echo $value['log_url']; ?>#comment">评论(<?php echo $value['comnum']; ?>)</a>
	<a href="<?php echo $value['log_url']; ?>#tb">引用(<?php echo $value['tbcount']; ?>)</a> 
	<a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a>
	</div>
	</div>
<?php endforeach; ?>

<div id="pageurl"><?php echo $page_url;?></div>
<?php include View::getView('footer'); ?>