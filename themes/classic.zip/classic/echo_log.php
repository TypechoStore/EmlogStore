<?php
if(!defined('EMLOG_ROOT')) {exit('error!');}
include View::getView('side');
?>
<div class="logcontent">
<p id="tit"><b><?php topflg($top); ?><?php echo $log_title; ?></b><span class="sort"><?php blog_sort($logid); ?></span></p>
<p id="date">post by <?php blog_author($author); ?> /  <?php echo gmdate('Y-n-j G:i l', $date); ?></p>

<div class="log_con">
<?php echo $log_content; ?>
<p><?php blog_tag($logid); ?></p>
<?php doAction('log_related', $logData); ?>

</div>
<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);?>
</div>
<?php include View::getView('footer'); ?>