<?php
if(!defined('EMLOG_ROOT')) {exit('error!');}
include View::getView('side');
?>
<div class="logcontent2">
	<p id="tit"><b><?php echo $log_title; ?></b></p>
	<div>
		<?php echo $log_content; ?>
	</div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
<?php include View::getView('footer'); ?>