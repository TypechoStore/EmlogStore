<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content-container" class="clearfix">
<ul class="double-cloumn clearfix">
<li id="left-column">
	<ul class="blog-main-post-container">
		<li class="post type-post status-publish format-standard hentry category-design category-knowledge post clearfix">
			<div class="post-top"></div>
			<div class="content clearfix">
				<div class="post-title-block">
						<h2 class="post-title typography-title">
							<?php topflg($top); ?><?php echo $log_title; ?>
						</h2>
					</div>
					<?php echo $log_content; ?>
					<?php doAction('log_related', $logData); ?>
					<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
				</div>
				
				<div class="post-meta">
					<div class="about">
						<p class="tags">
							<?php blog_tag($logid); ?>
						</p>
						<p class="info">
							<?php blog_sort($logid); ?> 日期:<?php echo gmdate('d M Y', $date); ?> 
						</p>
						
					</div>
					<div class="social single">
								<img src="<?php blog_author_header($author); ?>"/> 
								<?php blog_author($author); ?> 
								<a class="view" title="回复" href="#comments" ><img src="<?php echo TEMPLATE_URL."/images/icon_comment.png"; ?>"/>  <?php echo $comnum; ?></a>
								<a title="浏览" href="<?php echo $value['log_url']; ?>"><img src="<?php echo TEMPLATE_URL."/images/icon_click.png"; ?>"/> <?php echo $views; ?></a>
								<a title="引用" href="<?php echo $value['log_url']; ?>#tb"><img src="<?php echo TEMPLATE_URL."/images/icon_like.png"; ?>"/> <?php echo $tbcount; ?></a>
					</div>
					
				</div>
				<div id="comments" class="comments-area">
					<?php blog_comments($comments); ?>
					<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
				</div>
			<div class="post-bottom"></div>
		</li>
	</ul>
	
	
</li><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>