<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content-container" class="clearfix">
<ul class="double-cloumn clearfix">
<li id="left-column">
	<ul class="blog-main-post-container">
		<?php doAction('index_loglist_top'); ?>
		<?php foreach($logs as $value): ?>
			<li class="post type-post status-publish format-standard hentry category-design category-knowledge post clearfix">
				<div class="post-top"></div>
				<div class="content clearfix">
					<div class="post-title-block">
						<!--<h5 class="dater">
							<span><?php echo gmdate('j M', $value['date']); ?> </span>
							<span><?php echo gmdate('Y', $value['date']); ?> </span>
						</h5>-->
						<h2 class="post-title typography-title">
							<?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
						</h2>
					</div>
					<?php echo $value['log_description']; ?>
				</div>
				
				<div class="post-meta">
					<div class="about">
						<p class="tags">
							<?php blog_tag($value['logid']); ?>
						</p>
						<p class="info">
							<?php blog_sort($value['logid']); ?> 日期:<?php echo gmdate('d M Y', $value['date']); ?> 
						</p>
						
					</div>
					<div class="social">
								<img src="<?php blog_author_header($value['author']); ?>"/> 
								<?php blog_author($value['author']); ?> 
								<a class="view" title="回复" href="<?php echo $value['log_url']; ?>#comments" ><img src="<?php echo TEMPLATE_URL."/images/icon_comment.png"; ?>"/>  <?php echo $value['comnum']; ?></a>
								<a title="浏览" href="<?php echo $value['log_url']; ?>"><img src="<?php echo TEMPLATE_URL."/images/icon_click.png"; ?>"/> <?php echo $value['views']; ?></a>
								<a title="引用" href="<?php echo $value['log_url']; ?>#tb"><img src="<?php echo TEMPLATE_URL."/images/icon_like.png"; ?>"/> <?php echo $value['tbcount']; ?></a>
					</div>
					
				</div>
				<div class="post-bottom"></div>
				<div style="clear:both;"></div>
			</li>
		<?php endforeach; ?>
	</ul>
<div id="pagenavi">
	<?php echo $page_url;?>
</div>

</li><!-- end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>