<?php
/*
Template Name:Kdream
Description:<a href="../?setting">模板设置</a>
Version:1.3.1
Author:1梦
Author Url:http://cnm1.cn
Sidebar Amount:2
*/
if (!defined('EMLOG_ROOT')) {
    exit('error!');
} require_once View::getView('module'); ?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="<?php echo $site_description; ?>">
    <meta name="keywords" content="<?php echo $site_key; ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $site_title; ?></title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="<?php echo $blogname; ?>">
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd">
    <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml">
    <link rel="alternate" type="application/rss+xml" title="RSS" href="<?php echo BLOG_URL; ?>rss.php">
<?php include View::getView('inc/head');?>

</head>
<body class="custom-background">
<div id="kratos-wrapper">
<div id="kratos-page">
<div id="kratos-header">
                                        <div class="nav-toggle"><a class="kratos-nav-toggle js-kratos-nav-toggle"><i></i></a></div>
                                        <header id="kratos-header-section">
                        <div class="container">
                            <div class="nav-header">
                                <div class="color-logo"><a href="<?php echo BLOG_URL; ?>"><?php echo $biaoti; ?></a></div>
                                <nav id="kratos-menu-wrap" class="menu-container">
								<ul id="kratos-primary-menu" class="sf-menu"><?php blog_navi(); ?></ul></nav> 
							</div>
                        </div>
                    </header>
                </div>
				<div class="kratos-start kratos-hero-2">
        <div class="kratos-overlay"></div>
        <div class="kratos-cover kratos-cover_2 text-center" >
            <div class="desc desc2 animate-box">
                <a href="<?php echo BLOG_URL; ?>"><h2><?php echo $head; ?></h2><br><span><?php echo $fuhead; ?></span></a>
            </div>
        </div>
</div>