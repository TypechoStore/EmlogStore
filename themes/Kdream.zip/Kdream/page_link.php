<?php if (!defined('EMLOG_ROOT')) {
    exit('error!');
}?>

<div id="kratos-blog-post"> 
<div class="container">
        <div class="row">
                        <section id="main" class="col-md-8">
                                <article>
                    <div class="kratos-hentry kratos-post-inner clearfix">
                        <header class="kratos-entry-header">
                            <h1 class="kratos-entry-title text-center"><?php echo $log_title; ?></h1>
<hr>
                        </header>
                        <div class="kratos-post-content">
                        <p><?php echo $log_content; ?></p>
                        <div class="linkpage"><?php page_link(); ?></div>
                        </div>
                    </div>
<div class="comment-respond single-post-comment">
<h2>评论</h2>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>				
<ul>
<?php blog_comments($comments); ?>	
</ul>		
</div>
                </article>
                            </section>
                <aside id="kratos-widget-area" class="col-md-4 hidden-xs hidden-sm scrollspy">
                    <?php include View::getView('side'); ?>
                    </div>
                </aside>
                    </div>
    </div>
</div>
<?php include View::getView('footer'); ?>