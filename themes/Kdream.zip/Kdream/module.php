<?php 
/**
 * Theme by 1梦
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
date_default_timezone_set('Asia/Shanghai');
if (PHP_VERSION < '5.0'){emMsg('您的php版本过低，请选用支持PHP5的环境配置。');}
require_once View::getView('inc/config');
?>

<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
    $config_file = TEMROOT.'/config.php';
    if (is_file($config_file)) {include $config_file;}
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>

<aside id="kratos_about-2" class="widget widget_kratos_about clearfix">
	<div class="photo-background">
            <div class="photo-background" style="background:url(../content/templates/Kdream/images/about.jpg) no-repeat center center;-webkit-background-size:cover;background-size:cover">
		</div>
        </div>
        <div class="photo-wrapper clearfix">
            <div class="photo-wrapper-tip text-center">
			<?php if (!empty($user_cache[1]['photo']['src'])): ?>
                <img class="about-photo" src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" alt="">
			<?php endif;?>	
            </div>
        </div>
        <div class="textwidget">
            <p class="text-center"><span><?php echo $name; ?></span><br><?php echo $user_cache[1]['des']; ?></p>
        </div>
	</aside>
<?php }?>

<?php function widget_tag($title)
//标签
{
    global $CACHE;
    $tag_cache = $CACHE->readCache('tags');
    $tag_cachenum = array_slice($tag_cache, 0, 30); ?>
     <div class="widget widget_categories clearfix">
     <h4 class="widget-title"><span><?php echo $title; ?></span></h4>
    <div class="sidebar-tag clearfix">
    <?php foreach ($tag_cachenum as $value): ?>
    <a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇文章">
    <?php echo $value['tagname']; ?></a>
    <?php endforeach; ?>
    </div>
    </div>
<?php }?>

<?php function widget_sort($title)
//分类
{
    global $CACHE;
    $sort_cache = $CACHE->readCache('sort'); ?>
    <div class="widget widget_categories clearfix">
     <h4 class="widget-title"><span><?php echo $title; ?></span></h4>
    <div class="sidebar-sort">
    <ul class="clearfix">
    <?php foreach ($sort_cache as $value): if ($value['pid'] != 0) {
        continue;
    }?>
    <li><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
    <?php if (!empty($value['children'])): ?>
    <ul>
    <?php $children = $value['children'];
    foreach ($children as $key):$value = $sort_cache[$key]; ?>
    <li>
    <a href="<?php echo Url::sort($value['sid']); ?>"><span></span><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a></li>
    <?php endforeach; ?>
    </ul><?php endif; ?></li><?php endforeach; ?></ul></div></div>
    <?php }?>
    
<?php function widget_archive($title)
//存档
{
    global $CACHE;
    $record_cache = $CACHE->readCache('record'); ?>
    <div class="widget widget_categories clearfix">
     <h4 class="widget-title"><span><?php echo $title; ?></span></h4>
    <div class="sidebar-archive">
    <ul class="clearfix">
    <?php foreach ($record_cache as $value): ?>
    <li><a href="<?php echo Url::record($value['date']); ?>">
    <span></span>
    <?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li><?php endforeach; ?></ul></div>
    </div>
<?php }?>
    
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
    <div class="widget widget_kratos_comments clearfix">
    <h4 class="widget-title"><?php echo $title; ?></h4>
    <div class="recentcomments">
    <?php foreach($com_cache as $value): $url = Url::comment($value['gid'], $value['page'], $value['cid']); ?>
    <li class="comment-listitem">
       <div class="comment-avatar">
          <img class="img-radius" src="<?php echo getqqtx($value['mail']);?>" class="avatar avatar-50 photo" height="50" width="50">
      </div>

        <div class="comment-user">
        <span class="comment-author"><?php echo $value['name']; ?></span>
         <div class="comment-content-link"><a href="<?php echo $url; ?>"><div class="comment-content"><?php echo $value['content']; ?></div></a></div>
         </div>

    </li>
	  <?php endforeach; ?>
	</div>
	</div>
    <?php }?>

<?php function widget_custom_text($title, $content)
{
    ?>        <div class="widget widget_suxingme_postlist">
        <h3><span><?php echo $title; ?></span></h3>
        <div class="sidebar-custom"><?php echo $content; ?></div></div><?php

}?>


<?php
//blog：PC导航
function blog_navi(){
    global $CACHE; 
    global $arr_navico1;
    global $arr_sortico1;
    $config_file = TEMROOT.'/config.php';
    if (is_file($config_file)) {include $config_file;}
	$navi_cache = $CACHE->readCache('navi');
	?>
<?php
	foreach($navi_cache as $value): $id=$value["id"]; if ($value['pid'] != 0) {continue;}
		if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):?>
			<li><a href="<?php echo BLOG_URL; ?>admin/">管理站点</a></li>
			<li><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
        $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'current-menu-ancestor ' : '';
		$menu_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? '' : 'menu-item-has-children';
		$tunu_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'menu-item-has-children' : '';
		?>		
		<li class="<?php echo $current_tab;?><?php if (!empty($value['children']) || !empty($value['childnavi'])) :?><?php echo $tunu_tab;?> <?php echo $menu_tab;?><?php endif;?>">
			<a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php if(empty($arr_navico1[$id])) {echo $value[''];}else {echo "<i class='".$arr_navico1[$id]."'></i>";} ?><?php echo $value['naviname']; ?></a>
			<?php if (!empty($value['children'])) :?>
            <ul class="sub-menu">
                <?php foreach ($value['children'] as $row){
                        echo '<li><a href="'.Url::sort($row['sid']).'" target="_blank"><i class="'.$arr_sortico1[$row['sid']].'"></i>'.$row['sortname'].'</a></li>';
                }?>
			</ul>
            <?php endif;?>

            <?php if (!empty($value['childnavi'])) :?>
            <ul class="sub-menu">
                <?php foreach ($value['childnavi'] as $row){
                        $newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';
                        echo '<li><a href="' . $row['url'] . "\" $newtab >" . $row['naviname'].'</a></li>';
                }?>
			</ul>
            <?php endif;?>
		</li>
	<?php endforeach; ?>	
<?php }?>

<?php function tool_ishome()
{
    if (BLOG_URL.trim(Dispatcher::setPath(), '/') == BLOG_URL) {
        return true;
    } else {
        return false;
    }
}?>
<?php function tool_purecontent($content, $strlen = null)
{
    $content = strip_tags($content);
    if ($strlen) {
        $content = subString($content, 0, $strlen);
    }
    return $content;
}?>
<?php function img_random()
//随机缩略图
{
    $imgsrc = TEMPLATE_URL."images/random/".rand(1, 4).".jpg";
    return $imgsrc;
} function img_zw($content)
{
    preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $content, $img);
    $imgsrc = !empty($img[1]) ? $img[1][0] : '';
    if ($imgsrc):return $imgsrc;
    endif;
} function img_fj($blogid)
{
    $db = MySql::getInstance();
    $sql = $db->query("SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$blogid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 1");
    $imgsrc = '';
    while ($row = $db->fetch_array($sql)) {
        $imgsrc .= BLOG_URL.substr($row['filepath'], 3, strlen($row['filepath']));
    }
    return $imgsrc;
}?>
<?php function blog_author($uid)
//头像
{
    global $CACHE;
    $user_cache = $CACHE->readCache('user');
    $author = $user_cache[$uid]['name'];

    echo '<a href="'.Url::author($uid).'" title="'.$author.'">'.$author.'</a>';
}?>
<?php function blog_sort($blogid)
{
    global $CACHE;
    $log_cache_sort = $CACHE->readCache('logsort'); ?>
    <?php if (!empty($log_cache_sort[$blogid])): ?>
    <a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
    <?php endif; ?>
<?php }?>
<?php function blog_tag($blogid)
//标签
{
    global $CACHE;
    $log_cache_tags = $CACHE->readCache('logtags');
    if (!empty($log_cache_tags[$blogid])) {
        foreach ($log_cache_tags[$blogid] as $value) {
            $tag .= "<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
        }
        echo $tag;
    }
}?>
<?php function editflg($logid, $author)
//文章编辑
{
    $editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
    echo $editflg;
}?>

<?php function neighbor_log($neighborLog)
{
    extract($neighborLog); ?>
    <?php if ($prevLog):?>
    <a class="t-left icon" href="<?php echo Url::log($prevLog['gid']) ?>">
    <em><i class="fa fa-angle-double-left"></i></em>
    <?php echo $prevLog['title']; ?>
    </a>
    <?php endif; ?>
    <?php if ($nextLog):?>
    <a class="t-right icon" href="<?php echo Url::log($nextLog['gid']) ?>">
    <?php echo $nextLog['title']; ?>
    <em><i class="fa fa-angle-double-right"></i></em>
    </a>
    <?php endif; ?>

<?php }?>
<?php function blog_hotlog()
{
    $db = MySql::getInstance();
    $sql = $db->query("SELECT * FROM ".DB_PREFIX."blog WHERE hide='n' AND type='blog' AND top='n' order by views DESC limit 0,5"); ?><div class="t-hotlog"><div class="t-title"><span></span><h4>热门文章</h4></div><ul><?php while ($value = $db->fetch_array($sql)) {
        $i++; ?><li><span><?php echo $i; ?></span><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li><?php

    }?></ul></div><?php
}?>

<?php
//blog：评论列表
function blog_comments($comments){
    extract($comments);
    if($commentStacks): ?>
<hr>
<?php endif; ?>	
<?php
	$isGravatar = Option::get('isgravatar');
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'"  class="user_info_name" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
?>
<li class="comment even thread-even depth" id="comment-<?php echo $comment['cid']; ?>"  aos="fade-down">
<div class="comment cf comment_details">
<div class="avatar left"><a href="javascript:void(0)" name="<?php echo $comment['cid']; ?>"><?php if($isGravatar == 'y'): ?><img src="<?php echo getqqtx($comment['mail']);?>" class="avatar" width="100" height="100"></a></div>
<?php endif; ?>	
<div id="div-comment-<?php echo $comment['cid']; ?>" class="commenttext">
<div class="comment-wrapper">
 <div class="postmeta">
<?php echo $comment['poster']; ?>
<time class="timeago" datetime="<?php echo $comment['date']; ?>"> • <?php echo $comment['date']; ?></time>
<a rel="nofollow" class="comment-reply-link" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a>		
</div>
<div class="commemt-main"> <p><?php echo $comment['content']; ?></p></div>
</div></div>
</div>
<?php blog_comments_children($comments, $comment['children']); ?>
</li>
<?php endforeach; ?>
<div id="fy-nav" class="pega-fy"  aos="fade-down"> 
<div class="fy-list"> 
<?php echo $commentPageUrl;?>
</div> </div>
<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'"  class="user_info_name target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
<ul class="children"> 
<li class="comment even thread-even depth" >
<div class="comment cf comment_details">
<?php if($isGravatar == 'y'): ?>
<div class="avatar left"><a href="javascript:void(0)" name="<?php echo $comment['cid']; ?>"><img src="<?php echo getqqtx($comment['mail']);?>" class="avatar" width="100" height="100"></a></div>	
<?php endif; ?>	
<div id="id="comment-<?php echo $comment['cid']; ?>" class="commenttext">
<div class="comment-wrapper">
 <div class="postmeta">
 <?php echo $comment['poster']; ?> 
<time class="timeago" datetime="<?php echo $comment['date']; ?>"> •<?php echo $comment['date']; ?></time>
<?php if($comment['level'] < 4): ?>
<a rel="nofollow" class="comment-reply-link" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)" >回复</a>		 
<?php endif; ?>
</div>
<div class="commemt-main"><p><?php echo $comment['content']; ?></p></div>
</div></div></div>
</li>
<?php blog_comments_children($comments, $comment['children']);?>
 </ul>	
	<?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
<div id="comment-place">
<div class="single-post-comment-reply" id="comment-post">
<form action="<?php echo BLOG_URL; ?>index.php?action=addcom" class="comment_form" method="post" id="commentform">
				<div class="single-post-comment__form cf">  
					<textarea class="textarea form-control" data-widearea="enable" id="comment" name="comment" placeholder="来都来了,不随便说两句吗?"></textarea>
					<input type="hidden" name="gid" value="<?php echo $logid; ?>" id="comment_post_ID">
                      <input type="hidden" name="comment_parent" id="comment_parent" value="0">
               <span class="mail-notify-check">
				</div>			
				<div id="comboxinfo" class="comboxinfo cl">
				<?php if(ROLE == ROLE_VISITOR): ?>
					<div class="cominfodiv cominfodiv-author ">
					<p for="author" class="nicheng">
					<input type="text" name="comname" id="author" class="texty" placeholder="昵称*" tabindex="1">
					</p>
					</div>
					<div class="cominfodiv cominfodiv-email">
					<p for="email">	<input type="text" name="commail" id="email" class="texty" placeholder="邮箱*" tabindex="2">
						</p>
					</div>
					<div class="cominfodiv cominfodiv-url">
					 	<p for="url"><input type="text" name="comurl" id="url" class="texty" placeholder="网址 " tabindex="3">
						</p>
					</div>
					<?php endif; ?>
					 <button type="submit" class="ladda-button comment-submit-btn" id="comment_submit"><?php echo $verifyCode; ?>
					 <input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/>
					 <span class="ladda-label" >提交评论</span><a name="respond"></a></button>
					<div id="cancel_comment_reply"><a rel="nofollow" id="cancel-reply" href="javascript:void(0);" onclick="cancelReply()" style="display:none;">取消回复</a></div>
				</div>							
			</form>		
			</div>	</div>		
	<?php endif; ?>
<?php }?>

<?php function index_slide()
{
    $db = MySql::getInstance();
    $sql = $db->query("SELECT * FROM ".DB_PREFIX."blog WHERE type='blog' and hide='n' and top='y' ORDER BY date DESC LIMIT 5");
    $slidebg = TEMPLATE_URL."images/small.gif"; ?>
    <div class="index-slide">
    <div class="swiper-container">
    <ul class="swiper-wrapper">
    <?php while ($value = $db->fetch_array($sql)) {
        if (img_zw($value['content'])) {
            $imgurl = img_zw($value['content']);
        } elseif (img_fj($value['gid'])) {
            $imgurl = img_fj($value['gid']);
        } else {
            $imgurl = img_random();
        }
        if (strstr($imgurl, 'thum-')) {
            $imgurl = strstr($imgurl, 'thum-', true).substr(strstr($imgurl, 'thum-'), 5);
        }?>
    <li class="swiper-slide">
    <a class="img" href="<?php echo Url::log($value['gid']); ?>" style="background-image: url(<?php echo $imgurl; ?>);" target="_blank">
    <img src="<?php echo $slidebg; ?>">
    </a>
    </li>
    <?php }?>
    </ul>
    <div class="swiper-pagination"></div>
    </div>
    </div>
<?php }?>

<?php function page_archive()
{
    global $CACHE;
    $record_cache = $CACHE->readCache('record');
    $output = '';
    foreach ($record_cache as $value) {
        $output .= '<h4>'.$value['record'].'</h4>'.page_archive_list($value['date']);
    }
    return $output;
} function page_archive_list($record)
{
    if (preg_match("/^([\d]{4})([\d]{2})$/", $record, $match)) {
        $days = getMonthDayNum($match[2], $match[1]);
        $record_stime = emStrtotime($record.'01');
        $record_etime = $record_stime + 3600 * 24 * $days;
    } else {
        $record_stime = emStrtotime($record);
        $record_etime = $record_stime + 3600 * 24;
    }
    $sql = "and date>=$record_stime and date<$record_etime order by top desc,date desc";
    $result = page_archive_db($sql);
    return $result;
} function page_archive_db($condition = '')
{
    $DB = MySql::getInstance();
    $sql = "SELECT gid, title, date, views FROM ".DB_PREFIX."blog WHERE type='blog' and hide='n' $condition";
    $result = $DB->query($sql);
    $output = '';
    while ($row = $DB->fetch_array($result)) {
        $log_url = Url::log($row['gid']);
        $output .= '<li><span></span><time>'.smartDate($row['date']).'</time><a href="'.$log_url.'" target="_blank">'.$row['title'].'</a></li>';
    }
    $output = '<ul>'.$output.'</ul>';
    return $output;
}?>

<?php function page_link()
//友情链接
{
    global $CACHE;
    $link_cache = $CACHE->readCache('link'); ?>
<ul>
    <?php foreach ($link_cache as $value): ?>
    <li>
    <a href="<?php echo $value['url']; ?>" target="_blank" rel="nofollow"><h4><?php echo $value['link']; ?></h4><p><?php echo $value['des']; ?></p></a></li>
    <?php endforeach; ?>
</ul>
<?php }?>

<?php function page_tag()
//页面标签
{
    global $CACHE;
    $tag_cache = $CACHE->readCache('tags');
    $mytag_cache = array_slice($tag_cache, 0, 24); ?><ul class="clearfix"><?php foreach ($mytag_cache as $value): ?><li><h5 class="p-name"><a href="<?php echo Url::tag($value['tagurl']); ?>"><?php echo $value['tagname']; ?></a><em>x <?php echo $value['usenum']; ?></em></h5><?php $db = MySql::getInstance();
    $mytagname = $value['tagname'];
    $sql = $db->query("SELECT * FROM ".DB_PREFIX."tag WHERE tagname='$mytagname'");
    while ($row = $db->fetch_array($sql)) {
        $mygid = substr(strrchr(rtrim(trim($row['gid']), ','), ','), 1);
    }
    $sql = $db->query("SELECT * FROM ".DB_PREFIX."blog WHERE gid='$mygid'");
    while ($row2 = $db->fetch_array($sql)) {
        ?><p class="p-title"><a href="<?php echo Url::log($row2['gid']); ?>" title="<?php echo $row2['title']; ?>"><?php echo $row2['title']; ?></a></p><?php

    }?></li><?php endforeach; ?></ul>
<?php }?>

<?php //获取QQ信息
function getqqtx($qq){
	$url="http://q.qlogo.cn/headimg_dl?bs=qq&amp;dst_uin=$qq&amp;src_uin=admin@92mo.cn&amp;fid=blog&amp;spec=100";
	return $url;}
if(isset($_POST['qq'])){
	if(empty($_POST['qq'])){
		echo "@@({comname:'QQ账号错误',commail:'QQ账号错误',comurl:'QQ账号错误',toux:'http://q.qlogo.cn/headimg_dl?bs=qq&dst_uin=admin@92mo.cn&src_uin=admin@92mo.cn&fid=blog&spec=100'})@@";
		return ;
	}
	$spurl = "http://r.pengyou.com/fcg-bin/cgi_get_portrait.fcg?uins={$_POST['qq']}";
	$data = file_get_contents($spurl);
	$nc=explode('"',$data);
	$s=$nc[5];
	$bm=mb_convert_encoding($s,'UTF-8','UTF-8,GBK,GB2312,BIG5');
	if(empty($bm)){echo "@@({comname:'QQ账号错误',commail:'QQ账号错误',comurl:'QQ账号错误',toux:'http://q.qlogo.cn/headimg_dl?bs=qq&dst_uin=admin@92mo.cn&src_uin=admin@92mo.cn&fid=blog&spec=100'})@@";}
else{echo "@@({comname:'{$bm}',commail:'{$_POST['qq']}@qq.com',comurl:'http://user.qzone.qq.com/{$_POST['qq']}',toux:'http://q.qlogo.cn/headimg_dl?bs=qq&dst_uin={$_POST['qq']}&src_uin=admin@92mo.cn&fid=blog&spec=100'})@@";}}
function getqqxx($qq,$role=''){
	if(!empty($role)){
		return $role;
	}
	$ssud=explode("@",$qq,2);
	if($ssud[1]=='qq.com'){
	return getqqtx($ssud[0]);
	}else{	
	return MyGravatar($qq,$role);	
}}
?>
<?php function picthumb($blogid) {$db = MySql::getInstance();$sql = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$blogid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";$imgs = $db->query($sql);while($row = $db->fetch_array($imgs)){$pict.= ''.BLOG_URL.substr($row['filepath'],3,strlen($row['filepath'])).'';}return $pict;}function pic_thumb($content){preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $content, $img);$imgsrc = !empty($img[1]) ? $img[1][0] : '';if($imgsrc):return $imgsrc;endif;}?>
<?php 
//侧边栏评论
function sidecomcontent($pl) {
	$patterns = array ("/@/","/\[blockquote\](.*?)\[\/blockquote\]/","/\[F(([1-4]?[0-9])|50)\]/"); 
	$replace = array ('回复了','<small>$1</small>','<img alt="表情" src="'.TEMPLATE_URL.'images/face/$1.gif" />'); 
	$pl=preg_replace($patterns, $replace, $pl);
	return $pl;
}
//格式化内容工具
function blog_tool_purecontent($content, $strlen = null){
        $content = str_replace('继续阅读&gt;&gt;', '', strip_tags($content));
        if ($strlen) {
            $content = subString(preg_replace("/\[gsvideo url=(.*) w=(.*) h=(.*)\]/", '', $content), 0, $strlen);
        }
        return $content;
}
//获取附件第一张图片
function getThumbnail($blogid){
    $db = MySql::getInstance();
    $sql = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$blogid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";
    //die($sql);
    $imgs = $db->query($sql);
    $img_path = "";
	if(mysql_num_rows($imgs)){
		while($row = $db->fetch_array($imgs)){
			 $img_path .= BLOG_URL.substr($row['filepath'],3,strlen($row['filepath']));
		}
	}else{
		$img_path = false;
	}
    return $img_path;
}
//数据库报错用
function getimgforgid($gid){
    $db = MySql::getInstance();
    $sql = 'SELECT content FROM ' . DB_PREFIX . "blog WHERE gid='".$gid."'";
	$d = $db->once_fetch_array($sql);

	return isset($d['content']) && preg_match("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $d['content'], $img) ? $img[1] : false;
}
function gettime($id){
	$db = MySql::getInstance();
	$sql = 'SELECT * FROM ' . DB_PREFIX . "blog WHERE gid='".$id."'";
	$date = $db->query($sql);
	while ($row = $db->fetch_array($date)) {
		$time = date('Y-m-d',$row['date']);
	}
	return $time;
}
//获取blog表的一条内容,$content填写表名
function blog_content($gid,$content){
    $db = MySql::getInstance();
    $sql = 'SELECT * FROM ' . DB_PREFIX . "blog WHERE gid='".$gid."'";
    $sql = $db->query($sql);
    while ($row = $db->fetch_array($sql)) {
        $content = $row[$content];
	}
    return $content;
}
//代码压缩
function em_compress_html_main($buffer){
    $initial=strlen($buffer);
    $buffer=explode("<!--em-compress-html-->", $buffer);
    $count=count ($buffer);
    for ($i = 0; $i <= $count; $i++){
        if (stristr($buffer[$i], '<!--em-compress-html no compression-->')){
            $buffer[$i]=(str_replace("<!--em-compress-html no compression-->", " ", $buffer[$i]));
        }else{
            $buffer[$i]=(str_replace("\t", " ", $buffer[$i]));
            $buffer[$i]=(str_replace("\n\n", "\n", $buffer[$i]));
            $buffer[$i]=(str_replace("\n", "", $buffer[$i]));
            $buffer[$i]=(str_replace("\r", "", $buffer[$i]));
            while (stristr($buffer[$i], '  '))
            {
            $buffer[$i]=(str_replace("  ", " ", $buffer[$i]));
            }
        }
        $buffer_out.=$buffer[$i];
    }
    $final=strlen($buffer_out);
    $savings=($initial-$final)/$initial*100;
    $savings=round($savings, 2);
    $buffer_out.="\n<!--压缩前的大小: $initial bytes; 压缩后的大小: $final bytes; 节约：$savings% -->";
    return $buffer_out;
}

//pre不被压缩
function unCompress($content){
    if(preg_match_all('/(crayon-|<\/pre>)/i', $content, $matches)) {
        $content = '<!--em-compress-html--><!--em-compress-html no compression-->'.$content;
        $content.= '<!--em-compress-html no compression--><!--em-compress-html-->';
    }
    return $content;
}

//自动标签内链
   function nltag($content ,$domain) {
            global $CACHE;  
            $tag_cache = $CACHE->readCache('tags');              
            foreach($tag_cache as $value){  
                $tag_url = Url::tag($value['tagurl']);  
                $keyword = $value['tagname'];  
                $cleankeyword = stripslashes($keyword);  
                $url = "<a href=\"{$tag_url}\" title=\"浏览关于“{$cleankeyword}”的文章\" target=\"_blank\" >{$cleankeyword}</a>";  
                $regEx = '\'(?!((<.*?)|(<a.*?)))('. $cleankeyword . ')(?!(([^<>]*?)>)|([^>]*?</a>))\'s';  
                $content = preg_replace($regEx,$url,$content);          
}  
return $content;  
}
//正则去除HTML
function ClearHtml($content) {  
   $preg = "/<\/?[^>]+>/i";
   return preg_replace($preg,'',$content);
}
?>
<?php 
//分页函数
function tp_page($count,$perlogs,$page,$url,$anchor=''){
$pnums = @ceil($count / $perlogs);
$page = @min($pnums,$page);
$prepg=$page-1;
$nextpg=($page==$pnums ? 0 : $page+1);
$urlHome = preg_replace("|[\?&/][^\./\?&=]*page[=/\-]|","",$url);
$re = "<ul class=\"pagination\">";
if($pnums<=1) return false;		
if($page!=1) $re .=""; 
if($prepg) $re .="<li><a href=\"$url$prepg$anchor\" ><i class=\"fa fa-chevron-left\"></i></a></li>";
for ($i = $page-2;$i <= $page+2 && $i <= $pnums; $i++){
if ($i > 0){if ($i == $page){$re .= "<li class=\"active\"><a>$i</a></li>";
}elseif($i == 1){$re .= "<li><a href=\"$urlHome$anchor\">$i</a></li>";
}else{$re .= "<li><a href=\"$url$i$anchor\">$i</a></li>";}
}}
if($nextpg) $re .="<li><a href=\"$url$nextpg$anchor\" title=\"下一页\"><i class=\"fa fa-chevron-right\"></i></a></li>"; 
if($page!=$pnums) $re.="";
$re .="";
$re .="</ul>";
return $re;}
?>		