<?php 
/*
 * Tadpole控制台
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
require_once('inc/config.php');
if (ROLE == ROLE_ADMIN):
require_once('inc/functions.php');
plugin_setting();
?>
<br>
<div id="page-content">
<div class="main_inner">
<link rel='stylesheet' id='set-css'  href='<?php echo TEMPLATE_URL; ?>css/set.css' type='text/css' media='all' />
<script src="<?php echo TEMPLATE_URL; ?>inc/jquery.js"></script>
<div id="setting" >
<main id="main" class="site-main" role="main">
<form action="?setting&do=save" method="post" id="input" class="da-form" enctype="multipart/form-data">
<div class="set_nav">
<ul><li class="active"><a href="#sethome">基本配置</a></li>
<li><a href="#setaside">主题说明</a></li>
<li class="last"><input type="submit" value="保 存" class="svae" /></li>
</ul></div>
<div class="set_cnt">
<div class="set_box" id="sethome" style="display:block">

<div class="da-form-row">
<td class="right_td">背景图片设置</td>
<td class="left_td"><input size="30" name="weixin" type="text" value="<?php echo $weixin; ?>" class="text-width"/></td>
</div>

<div class="da-form-row">
<td class="right_td">网站顶部标题</td>
<td class="left_td"><input size="30" name="head" type="text" value="<?php echo $head; ?>" class="text-width"/></td>
</div>

<div class="da-form-row">
<td class="right_td">网站顶部副标题</td>
<td class="left_td"><input size="30" name="fuhead" type="text" value="<?php echo $fuhead; ?>" class="text-width"/></td>
</div>

<div class="da-form-row">
<td class="right_td">网站标题（手机端导航栏）</td>
<td class="left_td"><input size="30" name="biaoti" type="text" value="<?php echo $biaoti; ?>" class="text-width"/></td>
</div>
</div>

<div class="set_box" id="setaside">
<div class="da-form-row">
<td class="right_td"><p>
	<span style="font-family:Microsoft YaHei;">这是日奈森梦移植的主题</span><span style="font-family:Microsoft YaHei;">Kdream</span>
</p>
<p>
	<span style="font-family:Microsoft YaHei;">主题♂跤流群：<a href="https://jq.qq.com/?_wv=1027&k=5O8mh1e" target="_blank">648194214</a></span>
</p>
<p>
	<span style="font-family:Microsoft YaHei;"><span style="font-size:16px;">@<a href="http://cnm1.cn" target="_blank">1梦</a></span></span> 
</p></td>
</div>
</div>
</div>
</form>
</main>
</div>
</div></div>
<script>
$(function(){
	$(".set_nav li").not(".set_nav .last").click(function(e) {
		e.preventDefault();
		$(this).addClass("active").siblings().removeClass("active");
		$($(this).children("a").attr("href")).show().siblings().hide();
	});
	
  })
</script>
<?php else:?>
<?php header("Location:".BLOG_URL.""); exit; ?> 
<?php endif; ?>
<div class="clear"></div>
<br/>
<?php include View::getView('footer');?>