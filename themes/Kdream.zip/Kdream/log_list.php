<?php if (!defined('EMLOG_ROOT')) {
    exit('error!');
} if (isset($_GET["setting"])) {
    include View::getView('setting');
    exit;
}?>

<div id="kratos-blog-post">
    <div class="container">
        <div class="row">
<section id="main" class="col-md-8">
<?php doAction('index_loglist_top'); ?>
        <?php if (!empty($logs)) {
            foreach ($logs as $value): if (preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $imgs)) {
                $imgNum = count($imgs[1]);
            }
            if ($value['top'] != 'y') {
         ?>
            <article class="kratos-hentry clearfix">
<div class="kratos-entry-thumb">
	<?php if (!empty($imgs[1]) ) {
                    $n = 1; for ($i=0;$i < $n;$i++) {
                        $img = $imgs[1][$i]; ?>
    <a href="<?php echo $value['log_url']; ?>">
	<img src="<?php echo $img; ?>"></a>
	<?php
                    }
                }?>
</div>    
<div class="kratos-post-inner">
    <header class="kratos-entry-header clearfix">
        <h2 class="kratos-entry-title"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
        <div class="kratos-post-meta">
            <span class="pull-left">
            <i class="fa fa-calendar"></i><?php echo gmdate('Y-m-d H:i', $value['date']); ?>
            </span>
        </div>
    </header>
    <div class="kratos-entry-content clearfix">
    <p><?php if (!empty($value['excerpt'])) {
                        echo $value['excerpt'];
                    } else {
                        echo tool_purecontent($value['content'], 110);
                    }?></p>
    </div>
</div>
</article>
   <?php
            }
            endforeach;
        } else {
            ?>
            <div class="index-box">抱歉，没有符合您查询条件的结果</div>
            <?php
        }?>
		<div class="text-center" id="page-footer"><?php echo tp_page($lognum,$index_lognum,$page,$pageurl);?></div>
      </section>
    <aside id="kratos-widget-area" class="col-md-4 hidden-xs hidden-sm scrollspy"><?php include View::getView('side'); ?></aside>
        </div>
    </div>
</div>
<?php include View::getView('footer'); ?>
