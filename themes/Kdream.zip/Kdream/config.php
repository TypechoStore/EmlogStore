<?php
	        $index_slide = '2';
	        $index_footer = '1';
	        $index_footer_code = '<div class="footer-link">
<a href="http://127.0.0.1/xiaogupai/emice/?post=4">文章存档</a>
<a href="http://127.0.0.1/xiaogupai/emice/?post=3">文章标签</a>
<a href="http://127.0.0.1/xiaogupai/emice/?post=2">友情链接</a>
<a href="http://127.0.0.1/xiaogupai/emice/rss.php">RSS订阅</a>
</div>';
	        $bdshare = '2';
	        $bdshare_code = '<div class="echo-bdshare">
<div class="bdsharebuttonbox">
<a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a>
<a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a>
<a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a>
<a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a>
<a href="#" class="bds_douban" data-cmd="douban" title="分享到豆瓣"></a>
<a href="#" class="bds_copy" data-cmd="copy" title="分享到复制网址"></a>
<a href="#" class="bds_more" data-cmd="more" title="分享到"></a>
</div>
</div>';
	        $read_naighbor = '1';
	        $read_more = '1';
        ?>