<?php if (!defined('EMLOG_ROOT')) {
    exit('error!');
}?>
<div id="kratos-blog-post"> 
<div class="container">
        <div class="row">
                        <section id="main" class="col-md-8">
                                <article>
                    <div class="kratos-hentry kratos-post-inner clearfix">
                        <header class="kratos-entry-header">
                            <h1 class="kratos-entry-title text-center"><?php echo $log_title; ?></h1>
<hr>
                        </header>
                        <div class="kratos-post-content">
                        <p><?php echo $log_content; ?></p>
                        </div>
                                                <div class="kratos-copyright text-center clearfix">
                            <h5>本作品采用 <a rel="license nofollow" target="_blank" href="http://creativecommons.org/licenses/by-sa/4.0/">知识共享署名-相同方式共享 4.0 国际许可协议</a> 进行许可</h5>
                        </div>
                        <footer class="kratos-entry-footer clearfix">
                            <div class="footer-tag clearfix">
                                <div class="pull-left">
                                <i class="fa fa-tags"></i><?php blog_tag($logid); ?>
                            </div>
                        </footer>
                    </div>
<div class="comment-respond single-post-comment">
<h2>评论</h2>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>				
<ul>
<?php blog_comments($comments); ?>	
</ul>		
</div>
                </article>
                            </section>
                            <aside id="kratos-widget-area" class="col-md-4 hidden-xs hidden-sm scrollspy">
                    <?php include View::getView('side'); ?>                 </div>
                </aside>
                    </div>
    </div>
</div>
<?php include View::getView('footer'); ?>
