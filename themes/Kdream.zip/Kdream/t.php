<?php if (!defined('EMLOG_ROOT')) {
    exit('error!');
}?>
<div id="kratos-blog-post"> 
<div class="container">
        <div class="row">
<section id="main" class="col-md-8">
                           <article>
<div id="comments" class="comments-area">
    <ol class="comment-list">
        <?php foreach ($tws as $val) : $author = $user_cache[$val['author']]['name'];$avatar = empty($user_cache[$val['author']]['avatar']) ? BLOG_URL . 'admin/views/images/avatar.jpg' : BLOG_URL . $user_cache[$val['author']]['avatar'];$tid = (int)$val['id'];$img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img src="'.BLOG_URL.$val['img'].'"></a>'; ?>
            <li class="comment even thread-odd thread-alt depth-1" id="comment-1076">
				<div id="div-comment-1076" class="comment-body">
		<div class="comment-author vcard">
			<img alt="" src="<?php echo $avatar; ?>" class="avatar avatar-50 photo" height="50" width="50">
			<cite class="fn"><?php echo $author; ?></cite>
			<span class="says">说道：</span>
		</div>
		<div class="comment-meta commentmetadata"><?php echo $val['date']; ?></div>
		<p><?php echo $val['t'].''.$img; ?></p>

				</div>
		</li>
		<?php endforeach; ?>
</ol>
</div>
</article>
                        </section>
                            <aside id="kratos-widget-area" class="col-md-4 hidden-xs hidden-sm scrollspy">
                    <?php include View::getView('side'); ?>                 </div>
                </aside>
                    </div>
    </div>
</div>
<?php include View::getView('footer'); ?>
