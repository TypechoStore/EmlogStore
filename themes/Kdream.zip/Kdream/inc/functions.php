<?php
/*
 * @主题控制中心
 */
if(!defined('EMLOG_ROOT')) {exit('Tadpole Functions Requrire Emlog!');}
function d($str){
	$str = str_replace("'","\'",$str );
	return $str;
}

function plugin_setting(){
	$do = isset($_GET['do']) ? $_GET['do'] : '';
    if($do == 'save') {
		if(empty($_POST)){
                emMsg("修改失败，请重试！");
			return ;
		}
		 $arr_navico = $_POST['arr_navico'];
		 $arr_sortico = $_POST['arr_sortico'];
		 $biaoti = isset($_POST['biaoti']) ? d(trim($_POST['biaoti'])) : '';
		 $head = isset($_POST['head']) ? d(trim($_POST['head'])) : '';
		 $fuhead = isset($_POST['fuhead']) ? d(trim($_POST['fuhead'])) : '';
		 $weixin = isset($_POST['weixin']) ? d(trim($_POST['weixin'])) : '';
		 $cachedata = "<?php
    \$biaoti = '".$biaoti."';
	\$weixin = '".$weixin."';
	\$head = '".$head."';
	\$fuhead = '".$fuhead."';
	\$more_html = '".$more_html."';
?>";
		$cachefile = EMLOG_ROOT.'/content/templates/Kdream/inc/config.php';
		@ $fp = fopen($cachefile, 'wb') OR emMsg('读取缓存失败。如果您使用的是Unix/Linux主机，请修改缓存目录 (content/cache) 下所有文件的权限为777。如果您使用的是Windows主机，请联系管理员，将该目录下所有文件设为可写');
		@ $fw =	fwrite($fp,$cachedata) OR emMsg('写入缓存失败，缓存目录 (content/cache) 不可写');
		fclose($fp);
		emMsg("修改配置成功！",BLOG_URL.'?setting');
		}
}