<?php
    $biaoti = '日奈森梦';
	$weixin = '../content/templates/Kdream/images/index_image.png';
	$head = '日奈森梦';
	$fuhead = '可能是二次元博客';
	$more_html = '';
?>