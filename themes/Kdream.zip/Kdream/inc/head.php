<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
    <script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>js/jquery.min.js?ver=2.1.4'></script>
    <link rel='stylesheet' id='animate-css'  href='<?php echo TEMPLATE_URL; ?>css/animate.min.css?ver=3.5.1' type='text/css' media='all' />
    <link rel='stylesheet' id='awesome-css'  href='<?php echo TEMPLATE_URL; ?>css/font-awesome.min.css?ver=4.7.1' type='text/css' media='all' />
    <link rel='stylesheet' id='bootstrap-css'  href='<?php echo TEMPLATE_URL; ?>css/bootstrap.min.css?ver=3.3.7' type='text/css' media='all' />
    <link rel='stylesheet' id='layer-css'  href='<?php echo TEMPLATE_URL; ?>css/layer.min.css?ver=3.1.0' type='text/css' media='all' />
    <link rel='stylesheet' id='kratos-css'  href='<?php echo TEMPLATE_URL; ?>css/kratos.min.css?ver=2.5.8' type='text/css' media='all' />
	<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/main.css" type="text/css" media="all">
	<style>@media(min-width:768px){.pagination>li>a{background-color:rgba(255,255,255,.8)}.kratos-hentry,.navigation div,.comments-area .comment-list li,#kratos-widget-area .widget,.comment-respond{background-color:rgba(255,255,255,.8)!important}.comment-list .children li{background-color:rgba(255,253,232,.7)!important}body.custom-background{background-image:url(<?php echo $weixin; ?>);background-size:cover;background-attachment:fixed}}@media(max-width:768px){#kratos-header-section{background:rgba(22,23,26,.8)}}@media(min-width:768px){.color-logo{display:none}.affix{top:54px}}    </style>
    <script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js"></script>
    <?php doAction('index_head'); ?>
    <script src="http://cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>