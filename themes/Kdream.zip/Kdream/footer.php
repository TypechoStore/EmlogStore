<?php if (!defined('EMLOG_ROOT')) {
    exit('error!');
}?>
                <footer>
                    <div id="footer">
                        <div class="cd-tool text-center">
                                <div class="gotop-box"><div class="gotop-btn"><span class="fa fa-chevron-up"></span></div></div>
                            <div class="search-box">
                                <span class="fa fa-search"></span>
                                <form class="search-form" role="search" method="get" id="searchform" action="<?php echo BLOG_URL; ?>index.php">
                                    <input type="text" name="keyword" id="search" placeholder="Search..." style="display:none"/>
                                </form>
                            </div>
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="col-md-6 col-md-offset-3 footer-list text-center">
                                    <p class="kratos-social-icons">                                    </p>
                                    <p>采用emlog<a href="http://www.emlog.net" title="采用emlog系统">emlog</a>系统| made by <a href="https://www.vtrois.com" target="_blank" rel="nofollow">Vtrois</a>
									<br>Theme：Kdream | 主题移植：<a href="http://cnm1.cn" target="_blank" rel="nofollow">1梦</a>
                                                                        </p>
                                                                    </div>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>js/jquery.easing.min.js?ver=1.3.0'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>js/layer.min.js?ver=3.1.0'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>js/bootstrap.min.js?ver=3.3.7'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var xb = {"thome":"<?php echo TEMPLATE_URL; ?>","site_sh":"55"};
/* ]]> */
</script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>js/kratos.js?ver=2.5.8'></script>
</body>
</html>
