<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div class="junBot">
<div class="jSide clearfix">
 <?php footer_newlog(''); ?>
<?php footer_newcomm(''); ?>

  <?php footer_archive(''); ?>
 <?php footer_link(''); ?>
<div class="jBox">
<div class="jBoxH"><h3>其它</h3></div>
<div class="jBoxC">
<ul class="junList">
<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
		<li><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
		<li><a href="<?php echo BLOG_URL; ?>admin/">管理中心</a></li>
		<li><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
		<?php else: ?>
		<li><a href="<?php echo BLOG_URL; ?>admin/">登录</a></li>
		<?php endif; ?>
<li><a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> </li>
</ul>
</div>
</div>

</div><!--/.jSide-->
</div>
<div class="junF">
<div class="jCopy">
<p><a href="<?php echo BLOG_URL; ?>" rel="home"><?php echo $blogname; ?></a>
Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> 
 and Theme From <a href="http://junne.net/">junType</a>  Transplant by <a href="http://foxzld.com/" target="_blank">LonelyFox</a>   {<a href="<?php echo BLOG_URL; ?>rss.php"> RSS</a> }
 
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
<?php doAction('index_footer'); ?>
 </p>
</div>
</div><!--/.junF-->
</div><!--/.junP-->

</body>
</html>