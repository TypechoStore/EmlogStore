<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
if($author && in_array($author,$userid)) {
	$key = array_search($author,$userid);
	include View::getView('log_list_'.$key);
} else {
?>


<div class="junC">
<div class="jLay">
<div class="jMain">
<div class="jWrap">
<?php doAction('index_loglist_top'); ?>
<?php

	$sqlSegment = '';
	if ($record) {
		$sqlSegment = "and date>=$record_stime and date<$record_etime";
	} elseif ($tag) {
		$sqlSegment = "and gid IN ($blogIdStr)";
	} elseif ($keyword) {
		$sqlSegment = "and title like '%{$keyword}%'";
	} elseif ($sortid) {
		$sqlSegment = "and sortid=$sortid";
	}
	$emBlog=new Log_Model();
	$boy_lognum = $emBlog->getLogNum('n', "and author={$userid['boy']} $sqlSegment order by top DESC ,date DESC");
	$girl_lognum = $emBlog->getLogNum('n', "and author={$userid['girl']} $sqlSegment order by top DESC ,date DESC");
	$lognum = $boy_lognum > $girl_lognum ? $boy_lognum : $girl_lognum;
	$page_url = pagination($lognum, $index_lognum, $page, $pageurl);
	$boy_logs = $emBlog->getLogsForHome("and author={$userid['boy']} $sqlSegment order by top DESC ,date DESC", $page, $index_lognum);
	$girl_logs = $emBlog->getLogsForHome("and author={$userid['girl']} $sqlSegment order by top DESC ,date DESC", $page, $index_lognum);
?>
<div class="jName">

<ul class="clearfix">
<li class="jBFName"><b>Boy</b></li>
<li class="jGFName"><b>Girl</b></li>
</ul>
</div>

<div class="jBoy">

<?php foreach($boy_logs as $value): ?>
<div class="jPost jBF">
<div class="jPTitle" id="post-<?php echo $value['logid']; ?>">
<div class="jPDate"><?php echo gmdate('m-d Y', $value['date']); ?></div>
<h2 class="jH2"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
</div>
<div class="jPostInfo clearfix">
<ul>
<li class="jPAuthor"><img src="<?php echo $boy_img_src;?>" alt="" /></li>
<li class="jPCat"><b>In</b> <?php blog_sort($value['logid']); ?> </li>
<li class="jPComm"><b>Has</b> <a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?> Comments</a></li>
</ul>
</div>
<div class="jPostCont">
<?php echo $value['log_description']; ?>
</div>
<div class="jPMore"><a href="<?php echo $value['log_url']; ?>">Read More »</a></div>
</div>
<!--/.jPost-->
<?php endforeach; ?>

</div>

<div class="jGirl">

				<?php foreach($girl_logs as $value): ?>
<div class="jPost jGF">
<div class="jPTitle" id="post-<?php echo $value['logid']; ?>">
<div class="jPDate"><?php echo gmdate('m-d Y', $value['date']); ?></div>
<h2 class="jH2"><?php topflg($top); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
</div>
<div class="jPostInfo clearfix">
<ul>
<li class="jPAuthor"><img src="<?php echo $girl_img_src;?>" alt="" /></li>
<li class="jPCat"><b>In</b> <?php blog_sort($value['logid']); ?> </li>
<li class="jPComm"><b>Has</b> <a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?> Comments</a></li>
</ul>
</div>
<div class="jPostCont">
<?php echo $value['log_description']; ?>
</div>
<div class="jPMore"><a href="<?php echo $value['log_url']; ?>">Read More »</a></div>
</div>
<!--/.jPost-->
<?php endforeach; ?>

</div>

</div>

<div class="jPages">
<ul class="clearfix">
<ol class="page-navigator"><?php echo $page_url;?></ol>

</ul>
</div><!--/.jPages-->
</div><!--/.jMain-->
</div>
</div><!--/.junC-->


<?php

 include View::getView('footer');
?>
<?php } ?>