<?php 
/*
* boy日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div class="gfArt">
<div class="junC">
<div class="jLay">
<div class="jMain">
<div class="jWrap">

<div class="jPost jGF">
<div class="jPTitle">
<div class="jPDate"><?php echo date('n-d Y',$date); ?></div>
<h2 class="jH2"><?php topflg($top); ?><?php echo $log_title; ?></h2>
</div>
<div class="jPostInfo clearfix">
<ul>

<li class="jPAuthor"><img width="48" height="48" src="<?php echo $girl_img_src;?>" /></li>
<li class="jPCat">In <?php blog_sort($logid); ?></li>
<li class="jPComm"><b>Has</b> <a href="<?php echo $log_url; ?>#commentlist"><?php echo $comnum; ?> Comments</a></li>
<li class="jPTags">Tags <?php blog_tag($logid); ?></li>
</ul>
</div>
<div class="jPostContlog">
<?php echo $log_content; ?>

</div>
	<?php doAction('log_related', $logData); ?>
</div><!--/.jPost-->
<div class="jPost jGF">
<div id="comments">
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
</div>
</div>
</div><!--/.jMain-->
</div>
</div><!--/.junC-->

</div>
<?php 
include View::getView('footer');
 ?>