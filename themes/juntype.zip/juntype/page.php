<?php 
/*
* boy日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div class="jPage">
<div class="junC">
<div class="jLay">
<div class="jMain">
<div class="jWrap">

<div class="jPost ">


<h2 class="jH2"><?php echo $log_title; ?></h2>


<div class="jPostContlog">
<?php echo $log_content; ?>
<p class="att"><?php blog_att($logid); ?></p>
</div>
<?php doAction('log_related', $logData); ?>
</div><!--/.jPost-->

<div id="comments">
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>

</div>
</div><!--/.jMain-->
</div>
</div><!--/.junC-->

</div>
<?php 
include View::getView('footer');
 ?>