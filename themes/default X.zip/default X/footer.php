<?php 

/*

* 底部信息

*/

if(!defined('EMLOG_ROOT')) {exit('error!');} 

?>

</div><!--end #content-->

<div style="clear:both;"></div>

<div id="logo"><a href="http://www.facebook.com/design.ooian" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>/images/logo/facebook.png" width="64" height="64" alt="facebook" /></a>

  <a href="https://twitter.com/Not_design" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>/images/logo/twitter.png" width="64" height="64" alt="twitter" /></a>

  <a href="https://www.youtube.com/channel/UCWlEgzUHzHynMji4dLlr0uQ?feature=mhee" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>/images/logo/youtube.png" width="64" height="64" alt="youtube" /></a>

  <a href="mailto:design.ooinn@gmail.com" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>/images/logo/gmail.png" width="64" height="64" alt="gmail" /></a>

  <a href="http://www.google.com.hk/" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>/images/logo/google.png" width="64" height="64" alt="google" /></a>

  <a href="http://www.ooian.net/music.html"><img src="<?php echo TEMPLATE_URL; ?>/images/logo/ilike.png" width="64" height="64" alt="music" /></a>

  <a href=""><img src="<?php echo TEMPLATE_URL; ?>/images/logo/sharethis.png" width="64" height="64" alt="share" /></a>

<a href="http://www.not-design.com/" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>/images/logo/designmoo.png" width="64" height="64" alt="not-design" /></a></div>

<div style="clear:both;"></div>

<div id="footerbar">

Powered by <a href="http://www.emlog.net" target="_blank" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog.</a> Theme by <a href="http://www.ooian.net/" target="_blank">paopao.</a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?> </a><?php echo $footer_info; ?> <?php doAction('index_footer'); ?> <a href="#">返回顶部</a></div>

<!--end #footerbar-->

</div><!--end #wrap-->

</body>

</html>