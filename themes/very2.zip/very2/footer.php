<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--end #content-->
<div style="clear:both;"></div>
<div class="adcss">
   <!-- 页脚广告位2 -->
   <div class="clear"></div>
</div>
<div style="clear:both;"></div>
<div id="bottom">
   <p class="center"> 
      Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> 
	<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>&nbsp; 
      Copyright &copy; 2002-2013 <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a> 版权所有	<?php doAction('index_footer'); ?>
   </p>
   <center>
      <table border="0" align="center"><tbody><tr><td>
<?php global $CACHE; 
	$link_cache = $CACHE->readCache('link'); ?>
	<?php foreach($link_cache as $value): ?>
	<a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a>&#12288;
	<?php endforeach; ?>
	    	</div><p></p>
      </td></tr></tbody></table></center>
</div>
<script>prettyPrint();</script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/function.js"></script>
<script>
  jQuery(function($){
    $("#scroll").slider();
    $(".tool-head li").Tab(1,".tool-content div","on");
    $(".tab-header li").Tab(1,".tab-content>div","cur");
  })
</script>
</body>
</html>