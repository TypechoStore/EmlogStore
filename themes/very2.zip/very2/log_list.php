<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="ks">
  <div id="ks_xp">
  <?php doAction('index_loglist_top'); ?>

    <div class="main">
      <div class="title">最近更新</div>
      <div class="list">
 <ul>
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
	<li>
	<span><?php echo gmdate('Y-n-j G:i', $value['date']); ?> (<?php echo $value['views']; ?>)人次围观</span>
	[<?php blog_sort($value['logid']); ?>][<?php blog_tag($value['logid']); ?>]
	<a title="<?php echo $value['log_title']; ?>" href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a> <?php topflg($value['top']); ?>
	</li>
<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
</ul>
	<div style="clear:both;"></div>
      </div>
    </div>
    <div class="box_page">
	<?php echo $page_url;?>
    </div>
    <div class="clear"></div>
  </div>
</div>
<?php
 include View::getView('footer');
?>