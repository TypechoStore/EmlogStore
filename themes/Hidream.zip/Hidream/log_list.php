<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="contentleft">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
	<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
	<p class="date"><?php blog_author($value['author']); ?></p>
	<?php echo $value['log_description']; ?>
	<p class="count">
	<?php echo gmdate('Y-n-j G:i l', $value['date']); ?> |<?php editflg($value['logid'],$value['author']); ?> </br>
	<?php blog_sort($value['logid']); ?>|
	<?php blog_tag($value['logid']); ?> | 
	<a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?> 评论</a>|
	<a href="<?php echo $value['log_url']; ?>#tb"><?php echo $value['tbcount']; ?> 引用</a>|
	<a href="<?php echo $value['log_url']; ?>"><?php echo $value['views']; ?> 浏览</a>
	
	</p>
	<div style="clear:both;"></div>
<?php endforeach; ?>

<div id="pagenavi">
	<?php echo $page_url;?>
</div>

</div><!-- end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>