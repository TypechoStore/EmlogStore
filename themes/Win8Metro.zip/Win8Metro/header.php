<?php
/*
页面头部
Template Name:Win8 Metro
Description:Win8 Metro主题，最炫最好看
Version:1.5
Author:射雕天龙
Author Url:http://www.wangyanxiang.com
Sidebar Amount:1
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title><?php echo $site_title; ?></title>
	<meta name="keywords" content="<?php echo $site_key; ?>" />
	<meta name="description" content="<?php echo $site_description; ?>" />
	<meta name="generator" content="emlog" />
	<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
	<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
	<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
	<link type="text/css" href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" />
	<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js" type="text/javascript"></script>
	<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
	<script src="http://tjs.sjs.sinajs.cn/open/api/js/wb.js" type="text/javascript" charset="utf-8"></script>
	<?php doAction('index_head'); ?>
</head>
<body>
	<div id="page">
		<script type="text/javascript">
			if(screen.width>1030){document.getElementsByTagName('body')[0].className = "widescreen";}
		</script>
		<div id="container">
			<div id="wrap">
				<div id="header">
					<div id="logo">
						<h1>
							<a title="返回 <?php echo $blogname; ?> 首页" href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>
						</h1>
					</div>
					<div class="search">	
						<div class="search_site addapted" style="overflow: hidden;">	
							<form id="searchform" method="get" action="<?php echo BLOG_URL; ?>index.php">
								<input type="submit" value="" id="searchsubmit" class="button">
								<input type="text" id="s" name="keyword" value="">
							</form>
						</div>
					</div>
					<div id="contact">
						<a href="<?php echo BLOG_URL; ?>rss.php" rel="bookmark" target="_blank" title="订阅到RSS"><img src="<?php echo TEMPLATE_URL ?>images/rss24.png" alt="订阅到RSS" title="订阅到RSS" /></a>
						<a href="http://weibo.com/u/1936454255" rel="bookmark" target="_blank" title="关注新浪微博"><img src="<?php echo TEMPLATE_URL ?>images/sina24.png" alt="关注新浪微博" title="关注新浪微博" /></a>
						<a href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=RnJ2cXN_cHV0dwY3N2glKSs" rel="bookmark" target="_blank" title="发邮件给我们"><img src="<?php echo TEMPLATE_URL ?>images/mail24.png" alt="发邮件给我们" title="发邮件给我们" /></a>
						<a href="http://t.qq.com/w407586321" rel="bookmark" target="_blank" title="关注腾讯微博"><img src="<?php echo TEMPLATE_URL ?>images/tengxun24.png" alt="关注腾讯微博" title="关注腾讯微博" /></a>
					</div>
				</div>
				<div id="nav">
					<div class="topnav">
						<?php blog_navi();?>
					</div>
				</div>
				
			