<?php
/*
功能：显示日志列表内容
Template Name:Win8 Metro
Description:Win8 Metro主题，最炫最好看
Version:1.0
Author:射雕天龙
Author Url:http://www.shediaotianlong.cn
Sidebar Amount:1
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<!--当前位置开始-->
<div id="map">
	<div class="position">
		您的位置：<?php if($pageurl == Url::logPage()){ ?>
        <a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a>
		<?php }elseif ($params[1]=='sort'){ ?>
		<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> <em>></em> <?php echo '<a href="'.Url::sort($sortid).'">'.$sortName.'</a>';?>
        <?php }elseif ($params[1]=='tag'){ ?>
		<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> <em>></em> 标签 <?php echo htmlspecialchars(urldecode($params[2]));?> 的所有文章
        <?php }elseif($params[1]=='author'){ ?>
		<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> <em>></em> 作者 <?php echo blog_author($author);?> 的所有文章
        <?php }elseif($params[1]=='keyword'){ ?>
		<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> <em>></em> 关键词 <?php echo htmlspecialchars(urldecode($params[2]));?> 的搜索结果
        <?php }elseif($params[1]=='record'){ ?>
		<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> <em>></em> 发表在 <?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?> 的所有文章
        <?php }?>
	</div>
</div>
<!--当前位置结束-->

<div id="content">
	<div class="main">
		<?php doAction('index_loglist_top'); ?>
        <?php foreach($logs as $value): ?>
		<ul>
			<li>
				<div class="post_date">
					<span class="date_ym"><?php echo gmdate('Y', $value['date']); ?>.<?php echo gmdate('n', $value['date']);?></span>
					<span class="date_d"><?php echo gmdate('j', $value['date']); ?></span>
				</div>
				<div class="article">
					<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>" target="_blank" title="详细阅读 <?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></h2>
					<div class="infotop">
						<span class="info-category-icon"><?php blog_sort($value['logid']); ?></span>
						<span class="info-view-icon">超过<?php echo $value['views']; ?>围观</span>
						<span class="info-comment-icon"><a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?>条评论</a></span>
					</div>
					<div class="entry_post_top">
						<span style="padding-left:20px"><?php echo subString(strip_tags($value['content']),0,170,"..."); ?></span>
						<div class="clear"></div>
						<div class="infobot">
							<span class="info-tag-icon"><?php echo blog_tag($value['logid']); ?></span>
						</div>
						<div class="readmore"><a href="<?php echo $value['log_url']; ?>" target="_blank" title="详细阅读 <?php echo $value['log_title']; ?>" rel="bookmark" style="opacity: 1; ">阅读全文</a></div>
					</div>
				</div>
			</li>
		</ul>
		<div class="clear"></div>
		<?php endforeach; ?>
		<div class="navigation"><div class='pagination'><?php echo $page_url;?></div></div>
	</div>
	<div id="sidebar">
		<?php include View::getView('side');?>
	</div>
</div>
<?php include View::getView('footer');?>