<div id="footer">
	<div id="footer-body">
		<div id="footer-subbody">
			<div class="footerLink">
				<li id="linkcat-2" class="linkcat">
					<h2>友情链接</h2>
					<ul class='xoxo blogroll'>
						<li><a href="http://www.weiboxh.cn" title="大连工业大学微博协会官方网站" target="_blank">微博协会</a></li>
						<li><a href="http://www.199508.com" title="黎健雄部落格" target="_blank">黎健雄部落格</a></li>
						<li><a href="http://www.199604.com" title="小俊の记忆地" target="_blank">小俊の记忆地</a></li>
						<li><a href="http://bk.likinming.com" title="博客之家" target="_blank">博客之家</a></li>
					</ul>
				</li>
				<div class="clear"></div>
			</div>
			<div class="footerLink" id="footerNavgate">
				<h2>站内导航</h2>
				<ul>
					<li>联系站长</li>
					<li><a href="<?php echo BLOG_URL; ?>guestbook" target="_blank">我想留言</a></li>
					<li>关于本站</li>
					<li><a href="<?php echo BLOG_URL; ?>sitemap.xml" target="_blank">站点地图</a></li>
				</ul>
				<div style="margin:4px auto;color:#3399FF">关注本站站长微博：</div>
					<ul>
						<li><wb:follow-button uid="1936454255" type="red_1" width="67" height="30" ></wb:follow-button></li>
						<li><iframe src="http://follow.v.t.qq.com/index.php?c=follow&a=quick&name=w407586321&style=5&t=1374027053139&f=0" frameborder="0" scrolling="auto" width="125" height="24" marginwidth="0" marginheight="0" allowtransparency="true"></iframe></li>
					</ul>
			</div>
			<div class="footerLink" id="footer-about">
				<h2>本站简介</h2>
					<ul>
						<li>射雕天龙的博客，分享自己的生活点滴和学到的网络开发技术和其他计算机技术信息！同时分享最新最好看的国产电影、美国电影等等。
						</li>
					</ul>
				<div id="footer-logo"><a id="footer-title">站长：射雕天龙</a></div>
			</div>
			<div class="clear"></div>
		</div>

		<div id="footer-content">
			Copyright &copy;  2013<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a> |  
			<a href="<?php echo BLOG_URL; ?>sitemap.xml" target="_blank">站点地图</a> | <a href="http://www.miibeian.gov.cn" target="_blank"  rel="nofollow"><?php echo $icp; ?></a> |主题由<a href="http://blog.wangyanxiang.com" target="_blank"> 射雕天龙</a> 制作 | 本主题基于<a href="http://www.emlog.net" rel="external">Emlog</a>技术构建 |<?php doAction('index_footer'); ?><!--这里是统计代码 开始--><?php echo $footer_info; ?><!--这里是统计代码 结束--><br/>
			<!-- 返回顶部 -->
			<div style="display: none;" id="gotop"></div>
				<script type='text/javascript'>
					backTop=function (btnId){
						var btn=document.getElementById(btnId);
						var d=document.documentElement;
						var b=document.body;
						window.onscroll=set;
						btn.onclick=function (){
							btn.style.display="none";
							window.onscroll=null;
							this.timer=setInterval(function(){
								d.scrollTop-=Math.ceil((d.scrollTop+b.scrollTop)*0.1);
								b.scrollTop-=Math.ceil((d.scrollTop+b.scrollTop)*0.1);
								if((d.scrollTop+b.scrollTop)==0) clearInterval(btn.timer,window.onscroll=set);
							},10);
						};
						function set(){btn.style.display=(d.scrollTop+b.scrollTop>100)?'block':"none"}
					};
					backTop('gotop');
				</script>
				<!-- 返回顶部END -->
				</div>
			</div>
		</div>
	</div>
	<div class="clear"></div>
	<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/common_tpl.js"></script>
	<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/x.js"></script>
</div>
	<?php if(isset($ckmail) && empty($ckmail)): ?>
	<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/realgravatar.js"></script>
	<?php endif; ?>
</body>
</html>