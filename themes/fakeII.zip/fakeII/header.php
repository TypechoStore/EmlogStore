<?php
/*
Template Name:费壳II
Description:蓝外蓝出品
Version:1.0
Author:蓝外蓝
Author Url:http://lanwailan.com
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<!--[if lt IE 9]>
　　　　<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
　　<![endif]-->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<link href="http://apps.bdimg.com/libs/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="http://libs.baidu.com/jquery/2.0.0/jquery.min.js"></script>
   <script src="http://libs.baidu.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>

<script>
$(document).ready(function(){
  $("#menu-trigger").click(function(){
    $(".navbar").slideToggle();
  });
});
// iPad
var isiPad = navigator.userAgent.match(/iPad/i) != null;
if (isiPad) $('.navbar').addClass('no-transition');
</script>

<?php doAction('index_head'); ?>
</head>
<body>	
<div id="menu-trigger"><span class="glyphicon glyphicon-align-justify"></span>Menu</div>  
<nav id="#menu-wrap">
<div class="header">
    <div class="nav_bg">
	     <div class="leftnav">
		    <div class="logo_url"><a href="<?php echo BLOG_URL; ?>" ><img src="<?php echo TEMPLATE_URL; ?>images/logo.png" /></a></div>
		    <div class="navbar"><?php blog_navi();?></div>
		 </div>
		 <div class="rightnav"> 
		           <form class="navbar-form navbar-right" role="search" name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
				      <div class="form-group">
	                     <input name="keyword" type="text" class="form-control" placeholder="Search" />
					  </div>
	               
	               </form>
		 </div>
	</div>
	<div class="huandeng">
	  <div id="myCarousel" class="carousel slide">
       <!-- 轮播（Carousel）指标 -->
        <ol class="carousel-indicators">
         <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
         <li data-target="#myCarousel" data-slide-to="1"></li>
         <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>   
       <!-- 轮播（Carousel）项目 -->
        <div class="carousel-inner">
           <div class="item active">
               <img src="<?php echo TEMPLATE_URL; ?>images/img/1m.jpg" alt="First slide">
           </div>
            <div class="item">
              <img src="<?php echo TEMPLATE_URL; ?>images/img/2m.jpg" alt="Second slide">
            </div>
           <div class="item">
              <img src="<?php echo TEMPLATE_URL; ?>images/img/3m.jpg" alt="Third slide">
           </div>
         </div>
         <!-- 轮播（Carousel）导航 -->
            <a class="carousel-control left" href="#myCarousel" 
                data-slide="prev">&lsaquo;</a>
            <a class="carousel-control right" href="#myCarousel" 
                data-slide="next">&rsaquo;</a>
       </div> 
	</div> 		
</div>
</nav>


		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		