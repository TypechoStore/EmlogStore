<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<style>
.header .huandeng {display:none;}

</style>
<div class="container" style="margin-top:30px;">
	<div class="content-wtap">
		<div class="content">
		    <div class="positionbar" style="background-color:#FFE3E3;" >
              <ul >
                 <li><a><span class="glyphicon glyphicon-map-marker"></span>当前位置：</a><a href="<?php echo BLOG_URL; ?>">首页<span class="glyphicon glyphicon-hand-right"></span></a></li>
                 <li><?php blog_sort($logid); ?><span class="glyphicon glyphicon-hand-right"></span></li>
                 <li><?php echo $log_title; ?></li>
             </ul>
            </div>
			<div class="post_art">
				<h1 class="tit"><?php echo $log_title; ?></h1>
				<p class="date"><span class="admin"><span class="glyphicon glyphicon-user"></span><?php blog_author($author); ?></span> <span class="time"><span class="glyphicon glyphicon-time"></span><?php echo gmdate('Y-n-j', $date); ?></span>  <span class="sort"><span class="admin"><span class="glyphicon glyphicon-tag"></span><?php blog_sort($logid); ?></span> <span class="sort"><a href="<?php echo $value['log_url']; ?>"><span class="glyphicon glyphicon-eye-open"></span><?php echo $views; ?></a></span> <span class="sort"><a href="<?php echo $value['log_url']; ?>#comments"><span class="admin"><span class="glyphicon glyphicon-fire"></span><?php echo $comnum; ?></a></span> 
				</p>
				<div class="w"><?php echo $log_content; ?></div>
				<p><span class="glyphicon glyphicon-tags"></span><?php blog_tag($logid); ?> </p>
				<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
				<div>
					<h3>赞助商</h3>
				</div>
			</div>
			 
			<div class="link-box">
                <h4 ><span class="glyphicon glyphicon-leaf"></span>相关文章</h3>
                <ul style="margin-left:20px;">
	  	           <?php get_list($sortid); ?>
                </ul>
            </div>
			
			
			<div class="post_art">
			  
			 <?php blog_comments($comments); ?>
	         <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	         <div style="clear:both;"></div>
			</div>
		</div>
		
		<div class="weiboxiu" style="width:30%;height:650px;">
		   <h4 style="border-bottom:1px solid #FF618C;"><span class="glyphicon glyphicon-heart-empty"></span>微博秀</h4>
		   <iframe width="100%" height="650" class="share_self"  frameborder="0" scrolling="no" src="http://widget.weibo.com/weiboshow/index.php?language=&width=0&height=650&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=1&uid=1828728351&verifier=c6fd2b80&dpc=1"></iframe>
		</div>
	</div>
</div>
<?php
 include View::getView('footer');
?>
