<?php 
/**
 * 页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="container">
	<div class="content-wtap">
		<div class="content">
			
			<div class="post_art">
				<h1 class="tit"><?php echo $log_title; ?></h1>
				<div class="w"><?php echo $log_content; ?></div>
			</div>
			<div class="post_art">
			<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
			</div>
			
		</div>
	</div>
	<div class="sidebar">
		<?php 
			include View::getView('side');
		?>
	
	</div>
</div>
<?php
 include View::getView('footer');
?>