<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="container">
	<div class="content-wtap">
		<div class="content">
			<div class="post_art">
				<h1 class="tit"><?php echo $log_title; ?></h1>
				<p class="date"><span class="admin"><?php blog_author($author); ?></span> <span class="time"><?php echo gmdate('Y-n-j', $date); ?></span>  标签：<span class="sort"><?php blog_sort($logid); ?></span> 
				
				</p>
				<div class="w"><?php echo $log_content; ?></div>
				
				<p class="tag_art">本文相关标签：<?php blog_tag($logid); ?> </p>
				<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
				<div>
					<h3>赞助商</h3>
				</div>
			</div>
			<div class="post_art">
			<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
			</div>
			
		</div>
		
	</div>
	<div class="sidebar">
		<?php 
			include View::getView('side');
		?>
	
	</div>
	<?php
 include View::getView('footer');
     ?>
</div>
