

<!-- 以下为本模板的版权信息，尊重作者劳动成果，请自觉保留内容，谢谢支持 -->


<div class="footer">			
	<div class="">Powered by  <a href="http://www.emlog.net/" target="_blank"> Emlog  </a>   Theme  by  <a href="http://www.lanwailan.com/" target="_blank"> 蓝外蓝  </a>  </div>
</div>
</body>
</html>