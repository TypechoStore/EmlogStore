<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<?php if($pageurl == Url::logPage()): ?>
<?php include View::getView('index');?>
<?php else: ?>
<div class="searchBox list"><ul><li class="a">
现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; 
<?php if ($params[1]=='sort'){ ?>
		<?php echo '<a href="'.Url::sort($sortid).'">'.$sortName.'</a>';?>
<?php }elseif ($params[1]=='tag'){ ?>
			包含标签 <b><?php echo urldecode($params[2]);?></b> 的所有文章
<?php }elseif($params[1]=='author'){ ?>
			作者 <b><?php echo blog_author($author);?></b> 的所有文章
<?php }elseif($params[1]=='keyword'){ ?>
            关键词 <b><?php echo urldecode($params[2]);?></b> 的搜索结果
<?php }elseif($params[1]=='record'){ ?>
           发表在 <b><?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?> </b>的所有文章
<?php }else{?><?php }?>
</li></ul>
</div><div class="clear"></div>
<?php doAction('index_loglist_top'); ?>
<div id="mainBody">
<div class="areaL" id="newsList">
<div class="pageBox"><dl><dt><?php if ($params[1]=='sort'){ ?>
<?php echo '<a  href="'.Url::sort($sortid).'">'.$sortName.'</a>';?>
<?php }elseif ($params[1]=='tag'){ ?>
标签搜索
<?php }elseif($params[1]=='author'){ ?>
作者搜索
<?php }elseif($params[1]=='keyword'){ ?>
搜索结果
<?php }elseif($params[1]=='record'){ ?>
日期搜索结果
<?php }else{?><?php }?></dt>
<dd class="listBox2"><ul>
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
<?php $value['log_description'] = strip_tags($value['log_description']);?>
<li><div class="a"><div class="img"><a href="<?php echo $value['log_url']; ?>" class="font1_1" target="_blank"><img src="<?php get_thum($value['logid']);?>" width="100px" height="85px" alt="<?php echo $value['log_title']; ?>"></a></div></div>

<div class="b"><div class="addi">&nbsp;<?php echo gmdate('Y-n-j G:i', $value['date']); ?>&nbsp;&nbsp;点击：<?php echo $value['views']; ?>&nbsp;&nbsp;评论：<?php echo $value['comnum']; ?></div><h4><a href="<?php echo $value['log_url']; ?>" class="font1_1" target="_blank"><?php echo $value['log_title']; ?></a></h4><div class="clear"></div>
<div class="note"><?php echo mb_substr($value['log_description'],0,200,'utf-8');?></div><div class="clear"></div>
<div class="mark"><?php blog_tag($value['logid']); ?></div></div>
<div class="clear"></div></li>
<?php endforeach;else:?>
<h2>未找到</h2>
<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
<div class="clear"></div>
</ul>
<div class="navBox"><?php echo $page_url;?></div>
</dd></dl></div><div class="clear"></div>
</div>
<?php include View::getView('side');?>
<div class="clear"></div>
</div>
<?php include View::getView('footer');?>
<?php endif; ?>