<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="searchBox list"><ul><li class="a">
现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; 微语
</li></ul>
</div><div class="clear"></div>

<div id="mainBody">
<div class="areaL">
<div class="pageBox">
<dl>
<dt id="areaName"><?php if(ROLE == 'admin' || ROLE == 'writer'): ?><a href="<?php echo BLOG_URL . 'admin/twitter.php' ?>">写微语</a><?php endif; ?></dt>
<dd class="webBox">

<div class="b">
<div id="newsContent">
<ul>
    <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?> 
    <li style="padding:10px 0;border-bottom:1px dashed #ccc">
    <div class="main_img"><img src="<?php echo $avatar; ?>" width="48px" height="48px" /></div>
    <div class="post1"><span style="font-weight:bold"><?php echo $author; ?></span><br /><?php echo $val['t'].'<br/>'.$img;?></div>
    <div class="clear"></div>
    </li>
    <?php endforeach;?></ul>
	<div class="navBox"><?php echo $pageurl;?></div>

</div>

</div>

</dd>
</dl>
</div>
<div class="clear"></div>
</div>
<?php include View::getView('side');?>
<div class="clear"></div>
</div>
<?php include View::getView('footer');?>