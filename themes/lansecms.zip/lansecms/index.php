<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div id="mainBody1" style="margin-top: 2px;">

<div class="areaL">
<div class="areaL1">
<div id="saySlide"><?php home_slide();?></div>
</div><!--幻灯代码结束-->
<div class="areaL2"><div class="newBox">
<dl>
<dt></dt>
<dd class="listArrow0">
<ul><?php getNewLogs(9);?>
</ul>
</dd></dl></div><div class='clear'></div></div><!--最新文章结束-->
<!--栏目列表开始-->
<?php $sort_cache = $CACHE->readCache('sort');
                if (!empty($sort_cache)):
                    foreach ($sort_cache as $value):
                        if ($value['pid'] != 0)
                            continue;
                        ?>
<div class="itemBox">
<dl>
<dt><div class="more"><a href="<?php echo Url::sort($value['sid']) ?>" title="查看<?php echo $value['sortname']; ?>中的全部文章"></a></div><span class="pointer"><a href="<?php echo Url::sort($value['sid']) ?>" title="查看<?php echo $value['sortname']; ?>中的全部文章"><?php echo $value['sortname']; ?></a></span></dt>
<dd class="listArrow3">
<ul>
<?php
                                $sqlSegment = '';
                                if ($value['pid'] != 0 || empty($value['children'])) {
                                    $sqlSegment = "and sortid={$value['sid']}";
                                } else {
                                    $sortids = array_merge(array($value['sid']), $value['children']);
                                    $sqlSegment = "and sortid in (" . implode(',', $sortids) . ")";
                                }
                                $sqlSegment .= " order by date desc";
                                $logs = $Log_Model->getLogsForHome($sqlSegment, 1, 10);
                                foreach ($logs as $row) :
                                    ?>
                                <li><div class="right">&nbsp;<?php echo gmdate('Y.n.j', $row['date']); ?></div><a href="<?php echo $row['log_url']; ?>" title="<?php echo $row['log_title']; ?>" class="font1_2"><?php echo subString($row['log_title'], 0, 17); ?></a></li>
                                <?php endforeach; ?>
</ul>
</dd>
</dl>
</div><?php endforeach;endif;?>
<!--栏目列表结束-->
<div class="clear"></div></div>

<?php include View::getView('side');?>
</div>
<div class="clear"></div>
<?php include View::getView('footer');?>
