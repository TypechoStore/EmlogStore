<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div id="mainBody">
<div class="logoBox"><dl><dt></dt>
<dd><?php index_flinks();?></dd></dl></div><div class="clear"></div>
<div class="footinfo">
<p><?php echo $footer_info; ?></p>
<p><a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php copyright();?></p>
<p><?php doAction('index_footer'); ?></p>
</div>
</div>
</div></div>
</body>
</html>