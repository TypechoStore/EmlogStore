<?php
/*
Template Name:蓝色调CMS模板
Description:蓝色调CMS模板，此模板适用于企业网站，文章模板，个人博客等；请尊重蓝叶劳动成果，保留一个小小的链接。
Version:1.0
Author:蓝叶
Author Url:http://lanyes.org
Sidebar Amount:1
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>images/style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<script src="http://libs.baidu.com/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>jquery.saySlide.js" type="text/javascript" ></script>
</head>
<body>
<div id="zhutibox">
<div id="wrap">
<div id="topBody">
<div class="topLogo">
<!--网站名代码开始-->
<div id="left">
<h2><?php echo $blogname; ?>
<span><?php echo $blogname; ?></span>
</h2>
<p><?php echo $bloginfo; ?>
<span><?php echo $bloginfo; ?></span></p>
</div>
<!--网站名代码结束如果不需要就删除开始到结束中间这段代码-->
</div>
<div class="clear"></div>
<div class="mainMenu">
<ul class="topnav"><?php blog_navi();?></ul>
</div><div class="clear"></div>
