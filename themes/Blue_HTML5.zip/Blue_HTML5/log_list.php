<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
include View::getView('side');
?>
      <div id="content">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
        <h1><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h1>
		<p class="date">作者：<?php blog_author($value['author']); ?> 发布于：<?php echo gmdate('Y-n-j G:i l', $value['date']); ?> 
	<?php blog_sort($value['logid']); ?> 
	<?php blog_tag($value['logid']); ?>
	<?php editflg($value['logid'],$value['author']); ?>
	</p>
	<?php echo $value['log_description']; ?>
	<p align="right"><a href="<?php echo $value['log_url']; ?>" title="阅读更多..."><img style="border:0px solid #555;padding:0;" src="<?php echo TEMPLATE_URL; ?>style/more.gif" border="0"></a>
	<br>
	<a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a>
	<a href="<?php echo $value['log_url']; ?>#tb">引用(<?php echo $value['tbcount']; ?>)</a>
	<a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a>
	</p>
	<div class="log_line"></div>
<?php endforeach; ?>
	<div id="pagenavi"><?php echo $page_url;?></div>
</div>

<? include View::getView('footer');?>