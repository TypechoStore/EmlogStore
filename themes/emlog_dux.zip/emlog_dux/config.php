<?php
				 $timedate = '2015-8-1';
				 $timehide = '1';
				 $logo_url = 'https://x.hacking8.com/logo.png';
	 			 $new_log_num = '又一个</br>emlog大前端主题';
				 $web_method = '';
				 $navhide = '1';
				 $home_text = '<ul>
	<li><time>置顶</time><a href="http://blog.yesfree.pw/?post=79" style="color: #FD8C84;" target="_blank">emlog大前端4.3调戏完毕</a></li>
</ul>';
		         $radio_zhiding = '2';
		         $heightkeycolor = '';
		         $top_title = 'Emlog大前端主题F4.0社区版';
		         $top_titleurl = 'https://x.hacking8.com';				 
		         $top_content = '感谢大家对Emlog大前端这个模板的支持，新版在很多体验上做了些优化...';
				 $heightkey = '[推荐]';
				 $home_toptext = '<li>
	 <a href="https://github.com/boy-hack" target="_blank"><i class="fa fa-github" aria-hidden="true"></i>Github</a> 
</li>

<li>
<a href="https://x.hacking8.com/?sort=9">Emlog大前端模板</a>
</li>
<li>
	<a href="https://x.hacking8.com/?post=7">关于草窝</a> 
</li>
<li>
	<a href="https://x.hacking8.com/?post=6">留言板</a> 
</li>
<li>
				<a href="">旗下网站 <i class="fa fa-angle-down"></i></a>
				<ul class="sub-menu">
					<li><a  rel="external nofollow" href="https://bugs.hacking8.com/"> 乌云漏洞库</a></li>
					<li><a  rel="external nofollow" href="https://bugs.hacking8.com/tiquan/"> 提权辅助</a></li>
<li><a  rel="external nofollow" href="https://whatcms.hacking8.com/"> CMS在线识别</a></li>
<li><a  rel="external nofollow" href="https://scan.hacking8.com/"> w8scan扫描平台</a></li>
				</ul>
			</li>
<li>
				<a href="">模式切换 <i class="fa fa-angle-down"></i></a>
				<ul class="sub-menu">
					<li><a  rel="external nofollow" href="https://x.hacking8.com/?blog"> 博客模式</a></li>
					<li><a  rel="external nofollow" href="https://x.hacking8.com/?gfs"> 高富帅模式</a></li>
					<li><a  rel="external nofollow" href="https://x.hacking8.com/?image"> 图片模式</a></li>
					<li><a  href="https://x.hacking8.com/?zazhi"> 杂志模式</a></li>
				</ul>
			</li>';				 
				 $ppt_zhiding= '2';			 
			     $ppt_picurl = 'http://www.daqianduan.com/wp-content/uploads/2014/11/hs-xiu.jpg';
			     $ppt_titleurl = 'https://x.hacking8.com';
			 	 $ppt_picur2 = 'http://www.daqianduan.com/wp-content/uploads/2014/11/hs-xiu.jpg';
			 	 $ppt_titleur2 = 'https://x.hacking8.com';
			     $ppt_titleur3 = 'https://x.hacking8.com';
			 	 $ppt_picur3 = 'http://www.daqianduan.com/wp-content/uploads/2014/11/hs-xiu.jpg';
				 $arr_navico = 'a:4:{i:1;s:10:"fa fa-home";i:2;s:0:"";i:3;s:0:"";i:4;s:0:"";}';
				 $arr_sortico = 'a:2:{i:1;s:0:"";i:2;s:13:"fa fa-windows";}';
				 $side_title = 'a:20:{i:1;s:12:"友情链接";i:2;s:9:"留言板";i:3;s:9:"关于我";i:4;s:6:"微语";i:5;s:1:"-";i:6;s:12:"文章归档";i:7;s:9:"读者墙";i:8;s:0:"";i:9;s:0:"";i:10;s:0:"";i:11;s:0:"";i:12;s:0:"";i:13;s:0:"";i:14;s:0:"";i:15;s:0:"";i:16;s:0:"";i:17;s:0:"";i:18;s:0:"";i:19;s:0:"";i:20;s:0:"";}';
				 $side_url = 'a:20:{i:1;s:30:"https://x.hacking8.com/?post=5";i:2;s:30:"https://x.hacking8.com/?post=6";i:3;s:30:"https://x.hacking8.com/?post=7";i:4;s:25:"https://x.hacking8.com/t/";i:5;s:0:"";i:6;s:31:"https://x.hacking8.com/?post=51";i:7;s:31:"https://x.hacking8.com/?post=52";i:8;s:0:"";i:9;s:0:"";i:10;s:0:"";i:11;s:0:"";i:12;s:0:"";i:13;s:0:"";i:14;s:0:"";i:15;s:0:"";i:16;s:0:"";i:17;s:0:"";i:18;s:0:"";i:19;s:0:"";i:20;s:0:"";}';				 
				 $css = '.cat-scroll li{float:left}
@media (max-width: 640px){
.single .content {
    padding: 10px 15px; 
    border: none;
}
}';
				 $theme_skin = '45B6F7';
				 $ajaxclient = '0';
				 $m_cms_pci = '2';
				 $m_cms_page = '115,98,89,105,63';
				 $imgnum_all = '';
				 $pjax = '';
				 $tip = '';
				 $type_wall = '';
				 $ad_side = '';
				 $ad_page = '';
				 $ad_page_down = '';
				 $userhide = '0';
				 $firstblood = '1';
				 $webcompress = '1';				 
				 $module_thum = '0';				 
				 $down_next = '0';
				 $m_zazhi_config = '2,9,3,4,5,6';
				 $m_zazhi_config1 = '6';
				 $m_zazhi_config2 = '3';
				 $cdn_css = '0';
                 $m_gfs_tuijian = '1';
                 $m_gfs_div = '132,115,128,126,123,122,82,134';
	    ?>