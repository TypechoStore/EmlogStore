<?php 
header('Content-type: image/x-icon');
//定义一个合理缓存时间。合理值屈居于页面本身、访问者的数量和页面的更新频率，此处为7day。 
$time = 60 * 60 * 24 * 7;
  
//发送Last-Modified头标，设置文档的最后的更新日期。 
header ("Last-Modified: " .gmdate("D, d M Y H:i:s", time() )." GMT"); 
 
//发送Expires头标，设置当前缓存的文档过期时间，GMT格式。 
header ("Expires: " .gmdate("D, d M Y H:i:s", time()+$time )." GMT"); 
 
//发送Cache_Control头标，设置xx秒以后文档过时,可以代替Expires，如果同时出现，max-age优先。 
header ("Cache-Control: max-age=$time"); 
include_once("fav_function.php");
error_reporting(0); 

$url = $_GET['url'];

if(empty($url)){
	echo 'erro';
}

$arr = parse_url($url);
$http = $arr["scheme"];
$domain = $arr['host'];

$dir = 'cache/fav';
$fav = $dir."/".$domain.".ico";

if(is_file($fav)){
	//调用缓存文件
	$file = @file_get_contents($fav);
	echo $file;exit;
}

//新建文件
$curl = get_url_content($http.'://'.$domain."/favicon.ico");
$file = $curl['exec'];
$zt = $curl['getinfo'];


if($file && $zt['http_code']=='200'){
   $f2 = $file;
   write_cache($fav,$f2);
   echo $f2;
}else{
   $curl = get_url_content($url);
   $file = $curl['exec'];
		@preg_match('|href=\"(.*?)\.ico\"|i',$file,$a);
        if($a[1]){
           $a[1] .='.ico';
		   $curl = get_url_content($a[1]);	
	       $file = $curl['exec'];
	       $zt = $curl['getinfo'];	
		   if($zt['http_code']=='200'){//类似昵图网的独立图片存储链接情况处理
			  $f2 = $file;
			  write_cache($fav,$f2);
		      echo $f2;  			   
		   }else{		   
		      $u = $http.$domain.'/'.$a[1];
			  $curl = get_url_content($u);
		     $file = $curl['exec'];
	         $zt = $curl['getinfo'];
		      if($file && $zt['http_code']=='200'){
			     $f2 = $file;
				 write_cache($fav,$f2);
		         echo $f2;
		      }else{
				 $file = "i/no.ico";			  
                 $f2 = @file_get_contents($file);
				 write_cache($fav,$f2);
                 echo $f2;			     
		     }
		   }
		}else{
		    $file = "i/no.ico";			  
            $f2 = @file_get_contents($file);
			write_cache($fav,$f2);
            echo $f2;
		}
	}
?> 