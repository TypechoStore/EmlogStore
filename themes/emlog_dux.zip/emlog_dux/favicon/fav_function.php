<?php
function get_url_content($bbb) { 
   $ch = curl_init(); 
   curl_setopt ($ch, CURLOPT_URL, $bbb); 
   curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);  
   curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, FALSE); // https请求 不验证证书和hosts
   curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
   $file_info['exec']= curl_exec($ch); 
   $file_info['getinfo'] = curl_getinfo($ch); //判断状态 有的情况下无法正确判断ico是否存在
   curl_close($ch); 
   return $file_info; 
}

function write_cache($filename,$contents){
    if(is_file($filename))return false;
    return file_put_contents($filename,$contents);
}
?>