<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}

if(isset($_GET["setting"])){
	require_once View::getView('setting');
	exit;
}

$view='module/m_blog';
//测试模板模式

include View::getView($view);
?>
