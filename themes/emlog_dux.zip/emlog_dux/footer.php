<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

</section>
<footer class="footer">
<div class="container">
	<!--
		希望各位站长保留版权 您的支持就是我们最大的动力
		小草窝 Blog:http://blog.hacking8.com/
	-->
	<p>Powered by <a href="http://www.emlog.net" title="骄傲的采用emlog系统">emlog</a> 
	©  Emlog大前端 theme By <span id="copyright"><a href="https://x.hacking8.com/" title="草窝Blog">草窝</a></span><?php if(!empty($icp)):?><a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a><?php endif;?><a href="<?php echo TEMPLATE_URL.'SiteMap.php';?>" target="_blank"> SiteMap</a><?php echo $footer_info; ?>
	</p>
</div>
</footer>
<?php doAction('index_footer'); ?>
</div>
<div class="pjax_loading"></div>
<div class="pjax_loading1"></div>
</div>
</body>


<script>
window.jsui={
	www: '<?php echo BLOG_URL; ?>',
	uri: '<?php echo TEMPLATE_URL; ?>',
	ver: '4.9',
	logocode: '<?php echo Option::get('login_code');?>',
	is_fix:'<?php echo $navhide;?>',
	is_pjax:'<?php echo $pjax;?>',
	iasnum:'<?php echo $down_next; ?>',
	lazyload:'<?php echo $webcompress; ?>',
	ajaxclient:'<?php echo $ajaxclient; ?>'
};
</script>

<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>js/loader.js?ver=4.9.0' data-no-instant></script>
</html>