﻿<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--end #wrap-->
<div style="clear:both;"></div>
<div id="footerbar">
    <div class="dibubanquan">
  <?php echo $footer_info; ?> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?> </a>  Powered by <a href="http://www.emlog.net" target="_blank" title="采用emlog系统">emlog</a> 
	<?php doAction('index_footer'); ?>
<div id="back-to-top"></div>
	</div>
	
Theme by <a href="http://www.glbwl.com" target="_blank" title="孤狼主题">GlBwl v5.9.29</a> </div><!--end #footerbar-->
<script src="<?php echo TEMPLATE_URL; ?>js/glbwl.js" type="text/javascript"></script>
<script>prettyPrint();</script>
</body>
</html>