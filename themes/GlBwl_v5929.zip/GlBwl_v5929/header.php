<?php
/*
Template Name:孤狼自适应模板（v 5.9.29）
Description:孤狼GlBwl主题模板，黑色大气。
Version:5.9.29
Author:孤狼
Author Url:http://www.glbwl.com
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!doctype html>
<html lang="zh-cn">
<head>
<meta charset="utf-8">
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js"></script>
</head>
<body>
  <div id="dinbugudin">
  <div class="dinbugudin-01">
    <div class="tupian"><a href="<?php echo BLOG_URL; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/logo.png" alt="<?php echo $blogname; ?>" /></a></div>
    <div class="daohang"><?php blog_navi();?></div>
    </div><!-- end .dinbugudin-01-->
  </div><!-- end #dinbugudin--> 
<div id="menu">
       <?php blog_navi2();?>
  </div><!--menu-->
   <div class="daohang-01">
		            <a href="#" id="mobile-menu"><span class="icon-menu"></span><span class="icon-menu"></span><span class="icon-menu"></span></a>
		        </div>

<div id="wrap">
<div class="search2">
	<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
	<input name="keyword" class="input" type="text" placeholder="在这里输入文字，按回车搜索结果。" />
	</form>
	</div>
<div class="gonggao"><i class="fa fa-volume-up"></i> <?php global $CACHE;  $newtws = $CACHE->readCache('newtw'); echo subString(strip_tags($newtws[0]['content']),0,300); ?></div>
