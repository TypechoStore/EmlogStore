<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
		<div id="main">
	<a id="rss-link" href="http://lmesee.com/?feed=rss">RSS</a>
	<div id="main-top">
		<div id="main-bot">
			<div class="cl">&nbsp;</div>
			<div id="content">
		
				<div class="post">
			<h2><?php echo $log_title; ?></h2>
			
			
			<div class="entry">
			<?php echo $log_content; ?>
		
							</div>
			
			<div class="meta">
				<div class="bg">
					<span class="comments-num"><a title="《<?php echo $log_title; ?>》上的评论" href="<?php echo $value['log_url']; ?>#spond"><?php echo $value['comnum']; ?>Comment</a></span>
					<p>Posted <!-- by guigui --> in <?php blog_sort($logid); ?> <?php blog_tag($logid); ?><?php editflg($logid,$author); ?></p>
				</div>
				<div class="bot">&nbsp;</div>
			</div>
					</div>
			
				<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
			</div>
			<?php include View::getView('side'); ?>
			<div class="cl">&nbsp;</div>
		</div>
	</div>
<?php include View::getView('footer'); ?>			
