<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="main">
	<a id="rss-link" href="http://lmesee.com/?feed=rss">RSS</a>
	<div id="main-top">
		<div id="main-bot">
			<div class="cl">&nbsp;</div>
			<div id="content">
				<?php doAction('index_loglist_top'); ?>
				<?php foreach($logs as $value): ?>
				<div class="post">
					<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
					<div class="date">
						<div class="bg">
							<span class="day1"><?php echo gmdate('j', $value['date']); ?></span>
							<span><?php echo gmdate('M', $value['date']); ?></span>
						</div>
					</div>
					<div class="entry">
						<?php echo $value['log_description']; ?>
						<div class="cl">&nbsp;</div>
					</div>
					<div class="meta">
						<div class="bg">
							<span class="comments-num"><a title="《<?php echo $value['log_title']; ?>》上的评论" href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?>Comments</a></span>
							<p><b>Posted <!-- by guigui --> in</b> <?php blog_sort($value['logid']); ?> <?php blog_tag($value['logid']); ?></p>
						</div>
						<div class="bot">&nbsp;</div>
					</div>
				</div>
				<?php endforeach; ?>	
				<div id="pagenavi">
	<?php echo $page_url;?>
</div>
			</div>
			<?php include View::getView('side'); ?>
			<div class="cl">&nbsp;</div>
		</div>
	</div>
<?php include View::getView('footer'); ?>
