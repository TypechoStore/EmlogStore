<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<article class="article">
  <section class="articles">
	<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
	<section class="article_info">
	<br/><br/><p>作者：<?php blog_author($author); ?><?php blog_tag($logid); ?><?php blog_sort($logid); ?>
	<br/>发布于：<?php echo gmdate('Y-n-j G:i l', $date); ?>
	
	<?php editflg($logid,$author); ?></p>
	</section>
	<br/><br/>
	<section class="context">
	   <?php echo $log_content ?>
	   	<p class="att"><?php blog_att($logid); ?></p>
	   <p class="staylink"> <?php blog_trackback($tb, $tb_url, $allow_tb); ?></p></section>
  </section>
    <?php neighbor_log($neighborLog)?>
  <section class="articles">
      <span class="help">如果您觉得本文的内容对您的学习有所帮助：<a href="https://me.alipay.com/ekstone" target="_blank" title="小小捐助巨大帮助">小小捐助巨大帮助</a></span>
  </section>
    <section class="articles">
     <?php doAction('log_related', $logData); ?>
    </section>
  <section class="articles">
	<?php blog_comments($comments); ?> 	
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</section>
</article>
<?php
 include View::getView('side');
 include View::getView('footer');
?>