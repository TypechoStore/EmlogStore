<?php
/*
Template Name:Look
Description:Look....
Version:1.2
Author:EK石头
Author Url:http://ekstone.com
Sidebar Amount:1
ForEmlog:4.2.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<meta name="viewport" content="width=device-width" />

<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.cookie.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/gemerz.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/html5.js"></script>
<script type="text/javascript">
jQuery(document).ready(function($){
$('.article h2 a').click(function(){
    $(this).text('页面载入中……');
    window.location = $(this).attr('href');
    });
});
</script>
<!--
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/js/lazyload.js"></script>
<script type="text/javascript">
	$(function() {          
    	$(".article img, .articles img").not("#respond_box img").lazyload({
        	placeholder:"<?php echo TEMPLATE_URL; ?>images/loading.gif",
            effect:"fadeIn"
          });
    	});
</script>
!-->

<?php doAction('index_head'); ?>
</head>
<body class="home blog">

<div class="startbg">
	<div class="startpage">
	    <h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
    <!--[if lt IE 9]>
  echo '<script>location.href="http://ekstone.com/blog/"</script>';
  echo '<meta http-equiv="Refresh" content="0,url=aURL"/>'//秒后自动跳转到aURL指定页面
  header('Location:aURL');
   <![endif]-->
	   
	    <p><span style="color:#5ff;"><span style="font-size:16px;font-family:KaiTi_GB2312;"><b>————<?php echo $bloginfo; ?></b></span></span></p>
		<br/><br/><br/>
		 <p><b><span style="color:#60d978;font-family:FangSong_GB2312;font-size:24px;">欢迎来到我的小窝</span></b><p/>
		 <br/><br/><br/><br/><b>
		 <p>----------------这是您今天第一次访问-----------------</p>
    </div>
       <a class="startbtn" href="javascript:;">开始阅读</a>
</div>

<div class="page">
<header id="header" class="header clearfix">

    <h1 class="toplogo classfix"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>

<nav id="menu"> 
 <div class="menu">
   <ul>
   <li class="page_item page-item-1"><a href="<?php echo BLOG_URL; ?>">首页</a></li>
   <?php if($istwitter == 'y'):?>
	
	<?php endif;?>
	<?php 
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach ($navi_cache as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	$val['is_blank'] = $val['newtab'] == 'y' ? 'target="_blank"' : '';
    $val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
		
	?>
	<li class="page_item page-item-2"><a href="<?php echo $val['url']; ?>" target="<?php echo $val['is_blank']; ?>"><?php echo $val['naviname']; ?></a></li>
    
	<?php endforeach;?>
	<?php doAction('navbar', '<li class="common">', '</li>'); ?>
	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
	<li class="page_item page-item-3"><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
	<li class="page_item page-item-4"><a href="<?php echo BLOG_URL; ?>admin/">管理中心</a></li>
	<li class="page_item page-item-5"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
	<?php else: ?>
	<li class="page_item page-item-6"><a href="<?php echo BLOG_URL; ?>admin/">登录</a></li>
	<?php endif; ?>
   </ul>
 </div>
</nav>
<div id="loadingdd"><div></div></div>
<script type="text/javascript">
$("#loadingdd").show();
$("#loadingdd div").animate({width:"10%"});
</script>

</header>
<div id="main" class="main clearfix">