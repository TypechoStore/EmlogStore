<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<section id="backtotop" style="display: none; "><a class="returntop" href="javascript:;"></a></section>
<footer id="footer" class="footer clearfix">
<header class="copyright"><p>Copyright © 2012 <?php echo $blogname; ?> 
  Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> 
  Theme by <a href="http://ekstone.com/" rel="">EK石头</a>
  <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>
  <p> <?php echo $footer_info; ?></p><?php doAction('index_footer'); ?>
</header>
</footer>
<script type="text/javascript">

$("#loadingdd div").animate({width:"100%"}, function() {

setTimeout(function() {

$("#loadingdd").hide();

}, 1000);

});



</script> 

</>

</body>

</html>	