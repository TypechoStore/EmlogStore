<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<article class="article">

  <?php doAction('index_loglist_top'); ?>
  <?php foreach($logs as $value): ?>

     <section class="post-<?php echo $value['logid']; ?> post type-post status-publish format-standard hentry category-uncategorized" id="post-<?php echo $value['logid']; ?>">
     <div class="post_date">
	   <span class="date_m"><?php echo gmdate('Y', $value['date']); ?> </span>
       <span class="date_d"><?php echo gmdate('n', $value['date']); ?> </span>
	   <span class="date_y"><?php echo gmdate('j', $value['date']); ?> </span>
       <div class="comments_num">
	     <a href="<?php echo $value['log_url']; ?>#comments" title="《<?php echo $value['log_title']; ?>》上的评论"><?php echo $value['comnum']; ?></a>
       </div>
	 </div>
    <section class="articlepost">
       <h2><a href="<?php echo $value['log_url']; ?>" rel="bookmark" title="详细阅读 《<?php echo $value['log_title']; ?>》"><?php echo $value['log_title']; ?></a><span class="new"></span></h2>

<div class="thumbnail_box">
  <div class="thumbnail">
	</div>
<!-- 图片 -->
	<div class="thumbnail">
	<?php get_content_img($value['content']); ?> 
	</div>
</div>
    <div class="entry_post">
	  <?php echo $value['log_description']; ?>
    </div>
<div class="clear"></div>
<div class="postinfo">
 <div class="info">
作者：<?php blog_author($value['author']); ?>  
-<?php blog_sort($value['logid']); ?> 
-<?php blog_tag($value['logid']); ?>
 - 阅读：<a href="<?php echo $value['log_url']; ?>"><?php echo $value['views']; ?></a>

 </div>
</div>
  </section>
</section>
<div class="clear"></div>
<?php endforeach; ?>
<section class="navigation">
<div class='pagination'><?php echo $page_url;?></div>

</article>

<?php
 include View::getView('side');
 include View::getView('footer');
?>
