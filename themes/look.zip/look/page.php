<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<article class="article">
 <section class="articles">
	<h2><?php echo $log_title; ?></h2>
	 <section class="context">
	 <?php echo $log_content; ?>
	    <?php doAction($log_content); ?>
		<p><?php blog_att($logid); ?></p>
		</section>
</section>
 <section class="articles">
     <?php doAction('log_related', $logData); ?>
    </section>
	<section class="articles">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</section>
</section>
</article>
<?php
 include View::getView('side');
 include View::getView('footer');
?>