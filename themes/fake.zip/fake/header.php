<?php
/*
Template Name:费壳
Description:fake：好主题从fake开始|模板q8主题，非用于商业目的。
Version:1.0
Author:蓝外蓝
Author Url:http://www.lanwailan.com
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<!--[if lt IE 9]>
　　　　<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
　　<![endif]-->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>bjqs.css" rel="stylesheet"  type="text/css" /> 
<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>images/bjqs-1.3.min.js"></script>
    <script >
        jQuery(document).ready(function($) {
          $('.fleslider').bjqs({
            height      : 320,
            width       : 620,
            responsive  : true
          });
     });
</script>
<script>
$(document).ready(function(){
  $("#menu-trigger").click(function(){
    $(".navbar").slideToggle();
  });
});
// iPad
var isiPad = navigator.userAgent.match(/iPad/i) != null;
if (isiPad) $('.navbar').addClass('no-transition');
</script>
<script type="text/javascript" charset="utf-8" src="http://static.bshare.cn/b/buttonLite.js#style=-1&amp;uuid=&amp;pophcol=2&amp;lang=zh"></script><script type="text/javascript" charset="utf-8" src="http://static.bshare.cn/b/bshareC0.js"></script>
<?php doAction('index_head'); ?>
</head>
<body>	
<div id="menu-trigger">Menu</div>
<div class="header">
    <div class="nav_bg">
	     <div class="leftnav">
		    <div class="navbar"><?php blog_navi();?></div>
		 </div>
		 <div class="rightnav"> 
		   
		</div>
	</div>			
</div>

<div class="logo_bg" >
    <div class="becenter">
	    <div class="logo" >
		  <h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
		  <span><?php echo $bloginfo; ?></span>
	    </div>
		<div class="ads_right"> </div>
	</div>
</div>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		