<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>


<div class="container">
	<div class="content-wtap">
	    <!--幻灯片-->
	    <div class="sliderbox"> 
		   <div class="fleslider">
		       <ul class="bjqs">
                    <li><img src="<?php echo TEMPLATE_URL; ?>images/img/banner01.jpg" title="Automatically generated caption"></li>
                     <li><img src="<?php echo TEMPLATE_URL; ?>images/img/banner02.jpg" title="Automatically generated caption"></li>
                     <li><img src="<?php echo TEMPLATE_URL; ?>images/img/banner03.jpg" title="Automatically generated caption"></li>
                </ul>
		   </div>
		</div><!--slidebox end-->
		
		<div class="content">
			<?php doAction('index_loglist_top'); ?>
			<?php if (!empty($logs)): foreach($logs as $value): ?>
			<div class="post_list">
				
				<div class="post_box">
				    
					<h2 class="tit"><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
					
					<p class="date"><span class="admin">作者:<?php blog_author($value['author']); ?></span> <span class="time">时间:<?php echo gmdate('Y-n-j', $value['date']); ?></span> <span class="admin">标签:<?php blog_sort($value['logid']); ?> </span> <span class="admin">分类:<?php blog_tag($value['logid']); ?></span>浏览数:<?php echo $value['views']; ?></p>
					<div class="articleimg">
					<div class="img_box">
				        <a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><img src="<?php get_imgsrc($value['content']); ?>"/></a>
				      </div>
					 <p class="info"><?php echo extractHtmlData($value['content'],140);?> <span class="readmore"><a href="<?php echo $value['log_url']; ?>">阅读全文</a></span></p>	
					 <div class="bshare-custom" style="float:right" style="width:20px"><a title="分享到QQ空间" class="bshare-qzone"></a><a title="分享到新浪微博" class="bshare-sinaminiblog"></a><a title="分享到人人网" class="bshare-renren"></a><a title="分享到腾讯微博" class="bshare-qqmb"></a><a title="分享到网易微博" class="bshare-neteasemb"></a><a title="更多平台" class="bshare-more bshare-more-icon more-style-addthis"></a><span class="BSHARE_COUNT bshare-share-count">0</span></div>
					</div>
				</div>
			</div>
			<?php 
			endforeach;
			else: ?>
			<div class="post_list">
				<div class="img_box">
				<img src="<?php echo TEMPLATE_URL; ?>images/no-f.png" />
				</div>
				<div class="post_box">
					<h2 class="tit">没找到</h2>
					<p class="info">没有符合条件的内容可以显示！</p>
				</div>
			</div>
			<?php endif;?>
			<div class="pagebar"><?php echo $page_url;?></div>
			
		</div>
	</div>
	<div class="sidebar">
		<?php 
			include View::getView('side');
		?>
	</div>
	
</div>
    <?php
       include View::getView('footer');
    ?>

