<?php
/*
Template Name:黑色简约
Description:这是我整改的第一个EMLOG黑色模板希望大家喜欢 <p>如果有什么好的建议【<a href="http://www.juehackr.net/?post=16">请点击这里</a>】给我留言<p>★右侧的QQ和统计代码请在SIDE.php文件修改<p>★希望大家在修改代码的时候手下留情，不要修改EMLOG版权和博客作者链接，谢谢！
Version:1.1
Author:juehackr
Author Url:http://www.juehackr.net
Sidebar Amount:admin@juehackr.net
ForEmlog:4.1.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml"><head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js"></script>
<script type="text/javascript">
jQuery(document).ready(function(){
jQuery('#tab-title span').click(function(){
	jQuery(this).addClass("selected").siblings().removeClass();
	jQuery("#tab-content > ul").slideUp('1500').eq(jQuery('#tab-title span').index(this)).slideDown('1500');
});
});
$(document).ready(function() {
$('h2 a').click(function(){
myloadoriginal = this.text;
$(this).text('努力加载中，请稍候...');
var myload = this;
setTimeout(function() { $(myload).text(myloadoriginal); }, 2012);
});
});
</script>
<!-- 图片延迟加载 -->
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/lazyload.js"></script>
<script type="text/javascript">
	$(function() {          
    	$(".article img").not("#respond_box img").lazyload({
        	placeholder:"<?php echo TEMPLATE_URL; ?>images/image-pending.gif",
            effect:"fadeIn"
          });
    	});
</script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<style type="text/css">
.mc {
	color: #FF0;
	font-size: 16px;
	font-weight: bold;
	font-style: italic;
	text-align: right;
	font-family: "Courier New", Courier, monospace;
}
.js {
	color: #FF0;
	font-size: 14px;
	font-style: italic;
}
</style>
<body>
<div id="nav">
  <div id="menus">
<ul>
		<li class="<?php if($class=="" && $curpage != CURPAGE_TW){echo 'current_page_item'; }else{echo 'page_item';} ?>"><a  class="home" href="<?php echo BLOG_URL; ?>">首页</a></li>
<?php if($istwitter == 'y'):?>
	<li class="<?php echo $curpage == CURPAGE_TW ? 'current_page_item' : 'page_item';?>"><a href="<?php echo BLOG_URL; ?>t/">微语</a></li>
	<?php endif;?>
	<!--如果需要导航栏的目录，请去掉下面// -->
	<?//php menu_sort($class);?>
	<?php 
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach ($navi_cache as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
    $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
	?>
	<li class="<?php echo isset($logid) && $key == $logid ? 'current_page_item' : 'page_item';?>"><a href="<?php echo $val['url']; ?>" <?php echo $newtab; ?>><?php echo $val['naviname']; ?></a></li>
	<?php endforeach;?>
	<?php doAction('navbar', '<li class="page_item">', '</li>'); ?>
	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
	<li class="page_item"><a href="<?php echo BLOG_URL; ?>admin/">后台</a></li>
	<li class="page_item"><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
	<li class="page_item"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a>
	</li>
	<?php else: ?>
	<?php endif; ?>
    <span class="mc"><?php echo $blogname; ?></span>
    <span class="js"><?php echo $bloginfo; ?></span>
</ul>
  </div>
<div id="search"></div>
</div>

<div id="wrapper">
