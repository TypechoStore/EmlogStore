<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<style type="text/css">
a:link {
	color: #0C0;
}
a:visited {
	color: #090;
}
a:active {
	color: #9F0;
}
a:hover {
	color: #060;
}
body,td,th {
	color: #090;
}
</style>
<body link="#FF0000" vlink="#FF0000" alink="#CC9933">
<div id="content">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
	<div id="post-<?php echo $value['logid']; ?>"><!-- post div -->
		<h2 class="title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>" rel="bookmark"><?php echo $value['log_title']; ?></a></h2>
		<div class="post-info-top">
			<span class="post-info-date">
				<?php echo gmdate('Y-m-d H:s', $value['date']); ?> | 分类:<?php blog_sort($value['logid']); ?> | 作者：<?php blog_author($value['author']); ?> <?php editflg($value['logid'],$value['author']); ?>
			</span>
			<span id="addcomment"><a href="<?php echo $value['../JueHacKr/log_url']; ?>#comments" rel="nofollow" ><?php echo $value['comnum']; ?> 评论</a></span>
			<span id="gotocomments"><?php echo $value['views']; ?> 阅读 </span>
		</div>
		<div class="clear"></div>
		<!-- END entry -->
  </div>
	<!-- END post -->
	<div class="clear"></div>
	<?php endforeach; ?>
<div class="clear"></div>
<div id="pagenavi">
	<div class="pagenavi"><?php echo $page_url;?></div>
	<div class="clear"></div>
</div><br>
</div><!--content-->
<?php include View::getView('side');?>
<?php  include View::getView('footer');?>