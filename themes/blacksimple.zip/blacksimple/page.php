<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<style type="text/css">
<!--
.STYLE1 {
	font-size: 20px;
	color: #000000;
}
-->
</style>

<div id="content">
	<div class="post post-single" id="post-<?php echo $logid;?>">
		<h2 class="title"><?php topflg($value['top']); ?><a href="<?php echo $value['../JueHacKr/log_url']; ?>" rel="bookmark"><?php echo $value['log_title']; ?></a></h2>
		<div class="post-info-top">
			<span class="post-info-date">
				<span class="date"><?php echo gmdate('Y-m-d H:s', $date); ?> </span>
				<span class="cata"><?php blog_sort($logid); ?> </span>
				<span class="author"><?php blog_author($author); ?></span>
				<?php editflg($logid,$author); ?>
			</span>
			<span id="addcomment"><a rel="nofollow" href="#respond">发表评论</a></span>
			<span id="gotocomments"><a rel="nofollow" href="#comments">阅读评论</a></span>	
		</div>
		<div class="clear"></div>
		
		<div class="entry">
			<?php echo $log_content; ?>
		<div class="post-info-bottom">
		<!-- 如果单独页面需要tag标签请去掉注释
			<span class="post-info-category">
			
			</span>
			<span class="post-info-tags"><?php blog_tag($logid); ?></span>
			<?php blog_att($logid); ?>
		-->
		</div>
			<ul>
			</ul>
		</div><!--entry-->
	</div><!--post-->
	<div id="content">
		<div id="comments-div">
			<span id="comments-addcomment"><a href="#respond"  rel="nofollow" title="发表评论？">发表评论？</a></span>
		</div>
  </div>
	<div class="clear"></div>
<!-- comments START -->
<?php blog_comments($comments); ?>	
<!-- comments END -->
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div><!-- END content -->
<?php include View::getView('side');?>
<?php include View::getView('footer');?>