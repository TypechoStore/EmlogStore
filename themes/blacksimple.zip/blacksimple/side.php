<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<style type="text/css">
<!--
.STYLE1 {
	color: #FF0000;
	font-size: 24px;
	font-weight: bold;
	font-family: Arial, Helvetica, sans-serif;
}
#apDiv1 {
	position:absolute;
	width:358px;
	height:51px;
	z-index:1;
	top: -48px;
	visibility: visible;
	left: -30px;
}
.STYLE3 {
	font-size: 14px;
	font-weight: bold;
}
body,td,th {
	color: #060;
}
#apDiv2 {
	position:absolute;
	width:276px;
	height:52px;
	z-index:1;
	left: 15px;
}
.so {
	color: #090;
	font-weight: bold;
}
-->
</style>

<script src="../Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
<div id="sidebar-border">
<div id="apDiv2"><form method="get" id="searchform" action="<?php echo BLOG_URL; ?>" target="_blank">
    <span class="so">站内文章:</span>
    <input name="keyword" id="s" type="text" value="请输入关键字..." onfocus="this.value='';" onblur="if(this.value==''){this.value='搜一下吧...';}" />
    <button name="" type="submit" class="search_button" >搜索</button>
</form></div>
<div id="sidebar">
  <ul>
  <p>
    <?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?><script type="text/javascript">
AC_FL_RunContent( 'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0','width','288','height','207','src','fhttp://www.JueHacKr.net/content/templates/JueHacKrhs/swf/myag','quality','high','pluginspage','http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash','movie','fhttp://www.JueHacKr.net/content/templates/JueHacKrhs/swf/myag' ); //end AC code
    </script>
  </p>
  <p class="STYLE1">我是中国人★★★★★</p>
  <p><span style="font-size:14px;">
    <embed src="<?php echo TEMPLATE_URL; ?>swf/myag.swf" width="255" height="188" autostart="False" loop="True" type="application/x-shockwave-flash" quality="high" bgcolor="#FFFFFF" wmode="transparent" />    
  </span></p>
</ul>
</div>
<div align="center">
  <script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F56b7439e175ee609658d1a1be3e1b474' type='text/javascript'%3E%3C/script%3E"));
</script>
 | QQ:787238958
</div>
