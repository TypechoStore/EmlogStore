<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!-- content START -->
<style type="text/css">
.STYLE1 {	font-size: 20px;
	color: #000000;
}
</style>

<h2 class="title">感慨</h2>
<div id="content">
	<div id="comments-div">
	<span id="comments-addcomment"><a href="" rel="nofollow"><span class="title">感慨</span> (<?php echo count($tws);?>)</a>
	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?> | <a href="<?php echo BLOG_URL . '../JueHacKr/admin/twitter.php' ?>">发布感慨</a><?php endif; ?></span>
	</div>
<!--t yu star-->
<ol class="commentlist" id="thecomments">
<?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
?>
<li class="comment byuser comment-author-toby even thread-even depth-1" id="comment-<?php echo $comment['cid']; ?>">
	<div id="comment-2">
		<div class="comment-author vcard">
			<img alt="Avatar" src="<?php echo $avatar; ?>" class='avatar avatar-40 photo' height="32" width="32"><cite class="fn"><?php echo $author; ?></cite>
			<span class="comment-meta commentmetadata">
				<a href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');" onclick="commentReply(<?php echo $comment['cid']; ?>,this)"><?php echo $val['date'];?></a>
			</span>
		</div>
		<div class="comment-text">
		<p><?php echo $val['t'];?></p>
		</div>
		<div class="reply">
		<a class='comment-reply-link' href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">评论(<span id="rn_<?php echo $tid;?>"><?php echo $val['replynum'];?></span>)</a>
		</div>
	</div>
</li>
	<!-- t yu son -->
	<p><ul class='children' id="r_<?php echo $tid;?>">
	</ul></p>
	<!-- t yu son end-->
</ol>
<!-- t yu end -->
<a name="comments"></a>
<!-- comments START -->
<ol id="thecomments" class="commentlist">
	<li class="hreview clearfix evencomment">
    <div style="display:none;" id="rp_<?php echo $tid;?>">
		<p class="comment-form-comment">
		<textarea aria-required="true" rows="8" cols="45" name="comment" id="rtext_<?php echo $tid; ?>" onkeydown="if(event.ctrlKey){if(event.keyCode==13){document.getElementById('submit').click();return false}};"></textarea></p>
		
		<p class="comment-form-author" style="display:<?php if(ROLE == 'admin' || ROLE == 'writer'){echo 'none';}?>">
        <input type="text" id="rname_<?php echo $tid; ?>" value="" /> <label for="author"><small>昵称</small></label>
		</p>
		<p class="form-submit">
			<span style="display:<?php if($reply_code == 'n'){echo 'none';}?>">验证码：<input type="text" id="rcode_<?php echo $tid; ?>" value="" /><?php echo $rcode; ?></span>
			<input type="button" onclick="reply('<?php echo DYNAMIC_BLOGURL; ?>index.php?action=reply',<?php echo $tid;?>);" id="submit" value="评论" /> <span id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></span>
		</p>
    </div>
</li>
<!-- comments end -->
<?php endforeach;?>
	<div id="pagenavi">
	<div class="pagenavi"><?php echo $pageurl;?></div>
	</div>
</ol>
</div>
<!-- content end -->
<!-- sidebar footer -->
<?php include View::getView('side');
 include View::getView('footer');
?>

