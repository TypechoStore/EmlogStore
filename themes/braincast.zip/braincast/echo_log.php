<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<style type="text/css" media="screen">
#content{
	background:#FFF url(<?php echo TEMPLATE_URL; ?>pix/contentTop.gif) 0 0 no-repeat;
	padding:23px 0 0 0;
}
</style>
<div id="content" >
<div class="first post" id="post-<?php echo $logid; ?>">
<div class="comms">
<a href="<?php echo Url::log($logid); ?>#comment" title="评论"><?php echo $comnum; ?></a>
</div>
<h2><?php echo $log_title; ?>
<small><?php echo gmdate('d F Y', $date); ?> <?php echo gmdate('G:i l', $date); ?> by <?php blog_author($author); ?> 
<?php editflg($logid,$author); ?>
</small></h2>
<div class="entry">
<?php echo $log_content; ?>
<?php blog_att($logid); ?>
<?php doAction('log_related', $logData); ?>
<div class="postmeta">
<ul>
<li class="icon_categories">
<strong>分类:</strong>
<?php blog_sort($logid); ?>
</li>
<li class="icon_tags">
<?php blog_tag($logid); ?>
</li>
</ul>
<br class="clear" />
</div>
<div class="navPost">
<?php neighbor_log($neighborLog); ?>
</div>
</div>
<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);?>
</div>
</div>
<?php
include View::getView('side');
include View::getView('footer'); 
?>