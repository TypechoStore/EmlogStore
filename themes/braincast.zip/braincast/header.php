<?php
/*
Template Name:braincast
Description:大方个性的模板
Version:1.0
Author:奇遇&VX:Diamond0422
Author Url:http://www.emlog.net/template/5
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once (View::getView('module'));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<title><?php echo $blogtitle; ?></title>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<!--[if IE]> 
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo TEMPLATE_URL; ?>ie.css" />
<![endif]-->
<!--[if IE 6]>
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo TEMPLATE_URL; ?>ie6.css" />
<![endif]-->
<?php doAction('index_head'); ?>
</head>
<body>
<div id="container">
<!-- header -->
<div id="header">
<div class="floatR">
<div class="description">
<?php echo $bloginfo; ?>
</div>
</div>
<h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
</div>
<!-- header -->
<!-- menu -->
<div id="menu">
<ul class="nav">
<li class="active"><a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>">首页</a></li>
<?php if($istwitter == 'y'):?>
<li><a href="<?php echo BLOG_URL; ?>t/">微语</a></li>
<?php endif;?>
<?php
	foreach ($navibar as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	?>
	<li><a href="<?php echo $val['url']; ?>" target="<?php echo $val['is_blank']; ?>"><?php echo $val['title']; ?></a></li>
	<?php endforeach;?>
	<?php doAction('navbar', '<li>', '</li>'); ?>
		<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
			<li><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
			<li><a href="<?php echo BLOG_URL; ?>admin/">管理中心</a></li>
			<li><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
		<?php else: ?>
			<li><a href="<?php echo BLOG_URL; ?>admin/">登录</a></li>
		<?php endif; ?>
</ul>
</div>
<!-- / menu -->
<br class="clear" />
<div id="wrapper">
