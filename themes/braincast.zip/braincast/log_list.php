<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<style type="text/css" media="screen">
<?php if(!empty($logs)): ?>
#content{
	background:#FFF url(<?php echo TEMPLATE_URL; ?>pix/contentTop.gif) 0 0 no-repeat;
	padding:23px 0 0 0;
}
<?php else: ?>
#content{
	background:#FFF url(<?php echo TEMPLATE_URL; ?>pix/singleTop.gif) top left no-repeat;
	padding:23px 0 0 0;
}
<?php endif; ?>
</style>
<div id="content" >
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
	<div class="post">
	<h2><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
	<small><?php echo gmdate('d F Y', $value['date']); ?> <?php echo gmdate('G:i l', $value['date']); ?> by <?php blog_author($value['author']); ?> 
	<a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a> 
	<?php editflg($value['logid'],$value['author']); ?>
	</small> </h2>
	<div class="entry">
	<?php echo $value['log_description']; ?>
	</div>
	</div>
<?php endforeach; ?>
<div class="navigation">
<?php echo $page_url;?>
</div>
</div>
<?php
include View::getView('side');
include View::getView('footer'); 
?>