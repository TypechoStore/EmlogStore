<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<style type="text/css" media="screen">
#content{
	background:#FFF url(<?php echo TEMPLATE_URL; ?>pix/singleTop.gif) top left no-repeat;
	padding:23px 0 0 0;
}
</style>
<div id="content" >
<div class="post page">
<h2><?php echo $log_title; ?></h2>
<div class="entry">
<?php echo $log_content; ?>
<?php blog_att($logid); ?>
</div>
<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<br class="clear" />
</div>
</div>
<?php
include View::getView('side');
include View::getView('footer'); 
?>