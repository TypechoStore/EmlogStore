<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div id="footer">
<a href="#top" class="abTip" id="logoFoot" title="Back To Top">TOP</a>
<div class="left">
<p>Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a><?php if($icp):?> | <?php endif; ?><a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?></p>
<?php doAction('index_footer'); ?>
</div>
<br class="clear" />
</div>
</div>
</body></html>