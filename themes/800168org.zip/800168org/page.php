<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div class="mbx"><p>现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; <?php echo $log_title; ?></p></div>
<div class="list_main">	
<div class="list_left">
<div class="list_wz bk" style="clear:both; overflow:hidden;">
<div class="list_page_title"><?php echo $log_title; ?></div>
<div class="list_page_nr"><?php echo $log_content; ?></div>
</div>
<div class="pl_num bk">目前有 <?php echo $comnum;?> 条评论</div>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
<?php include View::getView('side');?>
</div>
<?php include View::getView('footer');?>