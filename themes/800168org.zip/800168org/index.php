<div class="sheli_main">
<div class="sheli_index_left">

<div class="index_bk bk"><div class=flash_img><div class=scroll_box_content rel="scroll_box_content"><?php kl_data_call_for_internal(1); ?></div>
<div class="flash_sz">
<a class="sz" href="javascript:;" rel=js_btn_list>1</a>
<a class="sz" href="javascript:;" rel=js_btn_list>2</a>
<a class="sz" href="javascript:;" rel=js_btn_list>3</a>
</div></div></div>

<div class="index_hot bk"><h3>本月最热推荐</h3><?php blog_ndayhot(10, 30);?></div>
<div class="index_main">
<div class="sheli_zd"><ul><?php kl_data_call_for_internal(2); ?></ul></div>
<?php get_list('1');?>
<?php get_list('2');?>
<?php get_list('3');?>
<?php get_list('4');?>
</div></div>
<div class="sheli_index_right">
<?php home_sort($title);?>
<?php home_archive($title);?>
<?php home_tag($blogid);?>
</div></div>
<div class="index_links bk"><div class="links"><?php links();?></div></div>