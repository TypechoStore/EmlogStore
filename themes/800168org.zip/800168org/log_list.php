<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<?php if($pageurl == Url::logPage()){ ?>
<?php include View::getView('index'); ?>
<?php }else{ ?>
<?php doAction('index_loglist_top'); ?>
<div class="mbx">
<p>现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; 
<?php if ($params[1]=='sort'){ ?><?php echo '<a href="'.Url::sort($sortid).'">'.$sortName.'</a>';?>
<?php }elseif ($params[1]=='tag'){ ?>包含标签 <b><?php echo urldecode($params[2]);?></b> 的所有文章
<?php }elseif($params[1]=='author'){ ?>作者 <b><?php echo blog_author($author);?></b> 的所有文章
<?php }elseif($params[1]=='keyword'){ ?>关键词 <b><?php echo urldecode($params[2]);?></b> 的搜索结果
<?php }elseif($params[1]=='record'){ ?>发表在 <b><?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?> </b>的所有文章
<?php }else{?><?php }?></p></div>

<div class="list_main">	
<div class="list_left">
<?php foreach($logs as $value): ?>
<div class="list_wz bk">
<div class="list_title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></div>
<div class="list_riqi">发表日期：<?php echo gmdate('Y-n-j G:i', $value['date']); ?><?php blog_tag($value['logid']); ?> &nbsp;&nbsp;
<?php blog_sort($value['logid']); ?> &nbsp;&nbsp;
评论：<a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?></a>&nbsp;条&nbsp;&nbsp;
浏览：<a href="<?php echo $value['log_url']; ?>"><?php echo $value['views']; ?></a>&nbsp;人</div>
<div class="list_wznr">
<p class="bk"><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" ><img  src="<?php get_thum($value['logid']);?>" width="160px" height="120px" alt="<?php echo $value['log_title']; ?>"/></a></p><?php echo subString(strip_tags($value['content']),0,320);?>...</div>
</div>
<?php endforeach; ?>
<div class="pages bk"><?php echo $page_url;?></div>
</div>
<?php include View::getView('side');?>
</div>
<?php } ?>
<?php include View::getView('footer');?>