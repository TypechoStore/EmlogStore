<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div class="foot"><div class="footer"><ul>
<div class="foot1">
Copyright © 2014 <?php echo $blogname; ?> 版权所有 <?php echo $icp; ?><br />
Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank" rel="nofollow">emlog</a>, Designed By <a href="http://www.shuyong.net" target="_blank">舍力博客</a>.<br />
<?php echo $footer_info; ?>
<?php doAction('index_footer'); ?>
</div></div>
</body>
</html>