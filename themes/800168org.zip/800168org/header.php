<?php
/*
Template Name:舍力博客
Description:分享生活中的点点滴滴
Version:1.2
Author:舍力
Author Url:http://www.shuyong.net
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?><?php echo page_tit($page); ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<link href="<?php echo TEMPLATE_URL; ?>sheli.css" rel="stylesheet" type="text/css" />
<script src="<?php echo TEMPLATE_URL; ?>js/sheli.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/flash.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/flash1.js" type="text/javascript"></script>
<?php emLoadJQuery(); doAction('index_head'); ?>
</head>
<body>
<div class="sheli_top">
<div class="sheli_logo"></div>
<div class="sheli_topnr bk"><?php echo $bloginfo; ?></div>
<div class="sheli_sjfx"><script type="text/javascript">sjdm()</script><br /><script type="text/javascript">bdfx()</script></div>
</div>
<div class="sheli_dh">
<div class="sheli_home"><a href="<?php echo BLOG_URL; ?>" title="首页" class="sheli_home"></a></div>
<div class="sheli_nav"><?php blog_navi();?>
<div class="sheli_search"><form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php" class="wform">
<input name="keyword"  type="text" value="" class="winput" />
<input type="image" id="logserch_logserch" class="wsubmit" src="<?php echo TEMPLATE_URL; ?>/images/go.gif" title="搜索" />
</form></div>
</div></div>