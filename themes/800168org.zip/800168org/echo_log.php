<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div class="mbx"><p>现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; <?php blog_sort($logid); ?> &raquo; <?php echo $log_title; ?></p></div>
<div class="log_main">
<div class="log_left bk">
<div class="log_title"><?php topflg($top); ?><?php echo $log_title; ?></div>	
<div class="log_riqi">发表日期：<span><?php echo gmdate('Y-n-j', $date); ?></span> &nbsp;&nbsp;
<?php blog_sort($logid); ?> &nbsp;&nbsp;
作者：<span><?php blog_author($author); ?></span> &nbsp;&nbsp;
评论：<span><?php echo $comnum;?></span> &nbsp;&nbsp;
</div>
<div class="lognr"><?php echo $log_content; ?></div>
<div class="sheli_info">
本文固定链接：<?php echo Url::log($logid); ?> &nbsp;&nbsp;<?php blog_tag($logid); ?><br />
本文由<?php blog_author($author); ?>原创或编辑，互联分享,尊重版权,转载请以链接形式标明本文地址
</div>
<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
<?php include View::getView('side');?></div>
<?php include View::getView('footer');?>