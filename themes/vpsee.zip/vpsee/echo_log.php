<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
	<div id="post-<?php echo $logid; ?>" class="post">
		<h2 class="posttitle">
		<span style="float:left;">
			<?php topflg($top); ?>
		</span>
			<?php echo $log_title; ?></h2>
		<p class="postdate">
			<span><?php echo gmdate('Y 年 n 月 j 日', $date); ?> <?php blog_tag($logid); ?>/ 作者：<?php blog_author($author); ?> <?php editflg($logid,$author); ?>
		</p>
		<div class="entry">
			<?php echo $log_content; ?>
		</div>
			<?php doAction('log_related', $logData); ?>
			<p class="postmeta">
				<span style="float: right;color: #999;">
					<br><a style="font-size: 13.5px;" href="<?php echo Url::log($logid); ?>#respond">发表评论</a>
				</span> 
				<?php blog_sort($logid); ?>
			</p>
	</div>
	
	<div id="interact">
		<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
		<?php blog_comments($comments); ?>
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>	
	</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>