<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
	<?php doAction('index_loglist_top'); ?>
	<?php foreach($logs as $value): ?>
	<div class="post">
		<h2 class="posttitle">
			<span style="float:left">
				<?php topflg($value['top']); ?>
			</span>
			<a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
		</h2>
		<p class="postdate">
			<span>
				<?php echo gmdate('Y 年 n 月 j 日', $value['date']); ?>  / 
				作者: <?php blog_author($value['author']); ?>  
				<?php blog_tag($value['logid']); ?>
				<?php editflg($value['logid'],$value['author']); ?>
			</span>
		</p>
		<div class="entry">
			<?php echo $value['log_description']; ?>
		</div>
		<p class="postmeta">
			<?php blog_sort($value['logid']); ?>  | 
			<a title="<?php echo $value['log_title']; ?>" href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a>	
		</p>
	</div>
	<?php endforeach; ?>
	
	<div class="navigation">
		<?php echo $page_url;?>			
	</div>
</div>	
<?php
 include View::getView('side');
 include View::getView('footer');
?>