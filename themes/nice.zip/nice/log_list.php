<?php
/**
 * 站点首页模板
 */
if (!defined('EMLOG_ROOT')) {
    exit('error!');
}
?>
<?php
    if (!empty($logs)):
        foreach ($logs as $value):
            ?><section class="panel post">

	  <article class="panel__wrapper">

	    <div class="panel__content">

	      <h1 class="panel__headline"><i class="fa fa-commenting-o"></i>&nbsp;<?php echo $value['log_title']; ?></h1>

	      <div class="panel__block"></div>
	      <p><?php echo $value['log_description']; ?></p>

	    </div>

	    <div class="readmore">

	    	<a href="<?php echo $value['log_url']; ?>">发表评论</a>

	    </div>

	  </article>

	</section>
<?php
endforeach;
else:
?>
        <h2>未找到</h2>
        <p>抱歉，没有符合您查询条件的结果。</p>
        <?php endif; ?>
<!-- 分页导航 开始-->

				<div style="background:rgba(22, 27, 27, 0.78);">

					<span class="newer footerlink"><?php echo $_prev; ?></span>

					<span class="older footerlink"><?php echo $_next; ?></span>

				</div>

	<!-- 分页导航 结束-->
<?php
include View::getView('footer');
?>