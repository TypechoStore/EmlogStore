<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<section style="background:#F0F0F0;display:flex;justify-content:center;">
	  <article class="cdlyc">
	      <h1><?php echo $log_title; ?></h1>
	      <div class="panel__block"></div>
	      <div class="single_class">
	     <?php echo $log_content; ?>
	      </div>
	  </article>
	</section>


<div style="background:#FFFFFF;padding:30px 0px;">
<div class="comment_css">
<div class="comments-wrapp">
<div id="comments">
	<?php blog_comments($comments); ?>
  		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div class="clear"></div>
      </div> 
</div></div>
</div>
</div>
	<script src="http://libs.useso.com/js/jquery/2.1.1/jquery.min.js" type="text/javascript"></script>
<?php
 include View::getView('footer');
?>