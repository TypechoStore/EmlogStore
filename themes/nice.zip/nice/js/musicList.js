/**
 * Created by Smohan on 2015/5/15.
 */
    
var musicList = [
    {
        title : '属于',
        singer : '梁静茹',
        cover  : 'http://www.smohan.net/data/upfiles/media/2015/05/smusic/2015051701.jpg',
        src    : 'http://www.smohan.net/data/upfiles/media/2015/05/smusic/2015051701.mp3'
    },
    {
        title : '夜夜夜夜',
        singer : '梁静茹',
        cover  : 'http://www.smohan.net/data/upfiles/media/2015/05/smusic/2015051702.jpg',
        src    : 'http://www.smohan.net/data/upfiles/media/2015/05/smusic/2015051702.mp3'
    },
    {
        title : '时间去哪儿',
        singer : '王铮亮',
        cover  : 'http://www.smohan.net/data/upfiles/media/2015/05/smusic/2015051703.jpg',
        src    : 'http://www.smohan.net/data/upfiles/media/2015/05/smusic/2015051703.mp3'
    },
    {
        title : '她说',
        singer : '张碧晨',
        cover  : 'http://www.smohan.net/data/upfiles/media/2015/05/smusic/2015051704.jpg',
        src    : 'http://www.smohan.net/data/upfiles/media/2015/05/smusic/2015051704.mp3'
    },
    {
        title : 'Tonight I Wanna Cry',
        singer : 'Keith Urban',
        cover  : 'http://www.smohan.net/data/upfiles/media/2015/05/KeithUrban-TonightIWannaCry.jpg',
        src    : 'http://www.smohan.net/data/upfiles/media/2015/05/KeithUrban-TonightIWannaCry.mp3'
    },
    {
        title : '海阔天空',
        singer : 'beyond',
        cover  : 'http://www.smohan.net/data/upfiles/media/2015/05/smusic/2015051705.jpg',
        src    : 'http://www.smohan.net/data/upfiles/media/2015/05/smusic/2015051705.mp3'
    }
];