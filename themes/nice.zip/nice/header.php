<?php
/*
Template Name:Nice
Description:简洁优雅
Version:1.1
Author:吴尼玛
Author Url:https://www.zhuiming.net/
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!doctype html>
<html lang="zh">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="<?php echo $site_key; ?>"/>
    <meta name="description" content="<?php echo $site_description; ?>" />
	<title><?php echo $site_title; ?></title> 
    <link rel="shortcut icon" type="image/ico" href="<?php echo TEMPLATE_URL; ?>images/default.jpg" />
    <link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>style.css" />
	<!-- <link rel="stylesheet" type="text/css" href="http://biantan.org/wp-content/themes/nice/css/normalize.css" /> -->
	<link rel='stylesheet prefetch' href='<?php echo TEMPLATE_URL; ?>css/font-awesome.min.css'>
	<link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>css/styles.css">
    <script src="http://cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>
	<script src="http://cdn.bootcss.com/jquery.pjax/1.9.5/jquery.pjax.min.js"></script>
	<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script>
    $(document).pjax('a[target!=_blank]', '.block-body', {fragment:'.block-body', timeout:8000});
</script>

	<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/smusic.css"/>

	<!--[if IE]>
		<script src="http://libs.useso.com/js/html5shiv/3.7/html5shiv.min.js"></script>
	<![endif]-->
</head>

<body>

<nav class="nav">
	  <div class="burger">
	    <div class="burger__patty"></div>
	  </div>
<ul class="nav__list">
	    <li class="nav__item">
	      <a href="<?php echo BLOG_URL; ?>" class="nav__link c-blue"><i class="fa fa-home"></i></a>
	    </li>
	    <li class="nav__item">
	      <a href="<?php echo BLOG_URL; ?>" class="nav__link c-yellow scrolly"><i class="fa fa-link"></i></a>
	    </li>
	    <li class="nav__item">
	      <a href="<?php echo BLOG_URL; ?>" class="nav__link c-red"><i class="fa fa-commenting-o"></i></a>
	    </li>
	    <li class="nav__item">
	      <a href="<?php echo BLOG_URL; ?>" class="nav__link c-green"><i class="fa fa-child"></i></a>
	    </li>
	    <li class="nav__item">
	      <a href="<?php echo BLOG_URL; ?>" class="nav__link" style="color:#EF8E0E;"><i class="fa fa-credit-card"></i></a>
	    </li>
</ul>
	</nav>

<div id="banner" role="banner">

        <div class="clear"></div>

		<div id="authorgravatar">
                                                <img src="<?php echo get_Gravatar("wudageyx@163.com"); ?>">
                        		</div>

		<div class="clear"></div>
		
		<div class="blogtitle">
			<h1><a href="<?php echo BLOG_URL; ?>" rel="home" title="BianTan&#039;s Blog"><?php echo $blogname; ?></a></h1>
			
		</div>
		<h3><?php echo $bloginfo; ?></h3>
</div>

<div class="grid-music-container f-usn" id="music2">
	<a href="#" onClick="doAct(this);"><i class="fa fa-music suo"></i></a>
    <div class="m-music-play-wrap">
        <div class="u-cover"></div>
        <div class="m-now-info">
            <h1 class="u-music-title"><strong>标题</strong><small>歌手</small></h1>
            <div class="m-now-controls">
                <div class="u-control u-process">
                    <span class="buffer-process"></span>
                    <span class="current-process"></span>
                </div>
                <div class="u-control u-time">00:00/00:00</div>
                <div class="u-control u-volume">
                    <div class="volume-process" data-volume="0.50">
                        <span class="volume-current"></span>
                        <span class="volume-bar"></span>
                        <span class="volume-event"></span>
                    </div>
                    <a class="volume-control"></a>
                </div>
            </div>
            <div class="m-play-controls">
                <a class="u-play-btn prev" title="上一曲"></a>
                <a class="u-play-btn ctrl-play play" title="暂停"></a>
                <a class="u-play-btn next" title="下一曲"></a>
                <a class="u-play-btn mode mode-list current" title="列表循环"></a>
                <a class="u-play-btn mode mode-random" title="随机播放"></a>
                <a class="u-play-btn mode mode-single" title="单曲循环"></a>
            </div>
        </div>
    </div>
    <div class="f-cb">&nbsp;</div>
    <div class="m-music-list-wrap" style="display:none;"></div>
</div>
<script>
function doAct(s){
	var t = document.getElementById('music2'),
    c = s.className;
    //有more属性
    if(c != null && c.indexOf('more') > -1){
        s.className = c.replace('more', '');
        t.className = t.className.replace('grid-music-container-active', '');
    }else{
        s.className = c + ' more';
        t.className = t.className + ' grid-music-container-active';
    }
}
</script>
<script src="<?php echo TEMPLATE_URL; ?>js/musicList.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/smusic.min.js"></script>
<script>
    new SMusic({
        musicList : musicList
    });
</script><div class="block-body">
