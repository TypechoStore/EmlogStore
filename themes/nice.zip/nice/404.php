<?php 
/**
 * 自定义404页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<!DOCTYPE html>
<!-- saved from url=(0030)http://www.wuxiaocong.com/4444 -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta charset="UTF-8">
<title>你要找的页面不存在啊</title>
</head><body><div align="center" style="font-family:"微软雅黑"">
<img src="http://xin-moe-static.smartgslb.com/404.jpg" border="0" height="">
<br>
找不到这个页面啊！是不是天然呆打错啦!<br><br>
<audio src="http://xin.moe/404.mp3" controls="controls">
</audio><br><br> 
</div>

<!--


看什么看！


--></body></html>