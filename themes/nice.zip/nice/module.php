<?php 
/**
 * 侧边栏组件、页面模块
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//blog：评论列表
function blog_comments($comments){
    extract($comments);
    if($commentStacks): ?>
	<div class="com-1">
    <ol class="commentlist">
    <?php endif; ?>
    <?php
    $isGravatar = Option::get('isgravatar');
    foreach($commentStacks as $cid):
    $comment = $comments[$cid];
    $comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
    ?>
    <li class="comments" id="li-comment-<?php echo $comment['cid']; ?>">
		<div id="comment-<?php echo $comment['cid']; ?>" class="comment-body">
        <a name="<?php echo $comment['cid']; ?>"></a>
        <?php if($isGravatar == 'y'): ?><div style="float:left;margin-right:14px;"><img src="<?php echo getGravatar($comment['mail']); ?>" class="avatar avatar-52 photo" height="52" width="52"/></div><?php endif; ?>
       <div class="comment-head">
		   <span class="name"><?php echo $comment['poster']; ?></span><span class="date"><?php echo $comment['date']; ?></span>
            <div class="comment-content"><?php echo $comment['content']; ?></div>
            <div class="comment-reply"><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a></div>
        </div><div>    </li>
			<div class="comment-entry" style="line-height: 26px;">
        <?php blog_comments_children($comments, $comment['children']); ?>
			<div>	
    <?php endforeach; ?>
    <div id="pagenavi">
        <?php echo $commentPageUrl;?>
    </div>
    </ol>
			<div class="mark-comment"></div>
			<nav class="commentnav">  
			</nav></div>
<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){
    $isGravatar = Option::get('isgravatar');
    foreach($children as $child):
    $comment = $comments[$child];
    $comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
    ?>
<ul class="children">
	<li class="comments" id="li-comment-<?php echo $comment['cid']; ?>">
		<div id="comment-<?php echo $comment['cid']; ?>" class="comment-body">
        <a name="<?php echo $comment['cid']; ?>"></a>
        <?php if($isGravatar == 'y'): ?><div style="float:left;margin-right:14px;"><img class="avatar avatar-52 photo" height="52" width="52" src="<?php echo getGravatar($comment['mail']); ?>" /></div><?php endif; ?>
         <div class="comment-head">
		   <span class="name"><?php echo $comment['poster']; ?></span><span class="date"><?php echo $comment['date']; ?></span>
            <div class="comment-content"><?php echo $comment['content']; ?></div>
            <?php if($comment['level'] < 4): ?><div class="comment-reply"><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a></div><?php endif; ?>
        </div>
        <?php blog_comments_children($comments, $comment['children']);?>
	</div>
	</li>
    </ul>
    <?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
    if($allow_remark == 'y'): ?>
<div id="respond">
		<h2>
		发表评论<small><a rel="nofollow" id="cancel-comment-reply-link" href="/?p=1172&_pjax=.block-body#respond" style="display:none;">点击取消回复</a></small>
		</h2>	
        <form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
		<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
     <div class="col1">
<p>
<textarea name="comment" id="comment" tabindex="4" cols="50" rows="8" placeholder="既然路过就来说一句吧" onkeydown="if(event.ctrlKey&&event.keyCode==13){document.getElementById('submit').click();return false};"></textarea>
</p>
		</div>
			<div class="col2">
				 <?php if(ROLE == ROLE_VISITOR): ?>
<p><input type="text" name="author" id="author" class="commenttext" value="<?php echo $ckname; ?>" style="width:98%" size="22" tabindex="1" placeholder="姓名（必填）" required=""></p>
<p><input type="text" name="email" id="email" class="commenttext" value="<?php echo $ckmail; ?>" style="width:98%;" size="22" tabindex="2" placeholder="邮件（必填）" required=""></p>
<p><input type="text" name="url" id="url" class="commenttext" value="<?php echo $ckurl; ?>" style="width:98%;" size="22" tabindex="3" placeholder="网址（随便你）"></p>
				<?php endif; ?>
<p><?php echo $verifyCode; ?> <input id="submit" type="submit" id="comment_submit" value="发表评论" tabindex="6" /></p>
            <input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/>
</div>
		    </form>
	<div class="clear"></div>
      </div>
<?php endif; ?>
<?php }?>
<?php
function get_Gravatar($email, $s = 120, $d = 'c', $g = 'g') {
  $hash = md5($email);
  $avatar = "https://dn-qiniu-avatar.qbox.me/avatar/$hash?s=$s&d=$d";
  return $avatar;
}?>