<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

	<script src='<?php echo TEMPLATE_URL; ?>js/stopExecutionOnTimeout.js'></script>

        <script>window.jQuery || document.write('<script src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js"><\/script>')</script>

	<script>

	var menu = document.querySelector('.nav__list');

	var burger = document.querySelector('.burger');

	var doc = $(document);

	var l = $('.scrolly');

	var panel = $('.panel');

	var vh = $(window).height();

	var openMenu = function () {

	    burger.classList.toggle('burger--active');

	    menu.classList.toggle('nav__list--active');

	};

	panel.eq(0).find('.panel__content').addClass('panel__content--active');

	var scrollFx = function () {

	    var ds = doc.scrollTop();

	    var of = vh / 4;

	    for (var i = 0; i < panel.length; i++) {

	        if (window.CP.shouldStopExecution(1)) {

	            break;

	        }

	        if (panel.eq(i).offset().top < ds + of) {

	            panel.eq(i).find('.panel__content').addClass('panel__content--active');

	        } else {

	            panel.eq(i).find('.panel__content').removeClass('panel__content--active');

	        }

	    }

	    window.CP.exitedLoop(1);

	};

	var scrolly = function (e) {

	    e.preventDefault();

	    var target = this.hash;

	    var $target = $(target);

	    $('html, body').stop().animate({ 'scrollTop': $target.offset().top }, 300, 'swing', function () {

	        window.location.hash = target;

	    });

	};

	var init = function () {

	    burger.addEventListener('click', openMenu, false);

	    window.addEventListener('scroll', scrollFx, false);

	    window.addEventListener('load', scrollFx, false);

	    $('a[href^="#"]').on('click', scrolly);

	};

	doc.on('ready', init);

	</script>



	

</div>

<div id="footer" style="background:rgba(22, 27, 27, 0.78);">
	<p>Theme nice designed by BianTan＆Carry by Roll-over晓.  &copy; All right reserved.</p>
        </div> 
<script>
$(document).ready(function(){
$(window).scroll(function(){
if($(this).scrollTop()!=0){
$('.top').fadeIn(500);}
else{
$('.top').fadeOut(500);} });
$('.top').click(function(){
$('body,html').animate({scrollTop:0},700);});
});
</script>
<div class="top" style="display: none;">回到顶部</div>
</body>
</html>