<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="crumb">位置：<a rel="nofollow" href="<?php echo BLOG_URL; ?>">首页</a>&nbsp;&nbsp;&gt;&nbsp;&nbsp;<?php blog_sort($logid); ?>&nbsp;&gt;&nbsp;<?php echo $log_title; ?>
	<span style="position:absolute;right:0px;">
		<a rel="nofollow" target="_blank" href="#">文字链接</a>
		<a rel="nofollow" target="_blank" href="#">文字链接</a>
		<a rel="nofollow" target="_blank" href="#">文字链接</a>
	</span>
</div>
<div class="content">
<div id="post">
<div class="article-header">
	<h1 class="article-title"><?php echo $log_title; ?></h1>
	<div class="article-meta">
		<span class="item"><?php echo gmdate('Y-n-j', $date); ?></span>
		<span class="item">分类：<?php blog_sort($logid); ?></span>
		<span class="item post-views">阅读(<?php echo $views; ?>)</span>
		<span class="item">评论(<?php echo $comnum; ?>)</span>
		<span class="item"></span>
	</div>
</div>
<div id="post-content">
	<p><?php echo $log_content; ?></p>
	<p class="post-copyright">转载请注明出处&nbsp;<a href="<?php echo BLOG_URL; ?>">Kiny's Blog</a> » 
		<a href="<?php echo $log_url; ?>"><?php echo $log_title; ?></a>
	</p>
	<div class="article-tags">标签：&nbsp;<?php blog_tag($logid); ?></div>
	<ul><?php neighbor_log($neighborLog); ?></ul>
	<div id="comments">
	<div class="box-title"><span>精彩评论</span></div>
	<?php blog_comments($comments,$params); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
</div>
</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>