﻿<?php
/*
Template Name:KinyNEXT
Description:KinyNEXT - www.33665.net
Version:2.0
Author:kiny
Author Url:http://www.33665.net
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="zh-CN">
<head profile="http://gmpg.org/xfn/11">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta http-equiv="Cache-Control" content="no-transform" />
<meta http-equiv="Cache-Control" content="no-siteapp" />
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />	
<link rel="stylesheet" type="text/css" media="all" href="<?php echo TEMPLATE_URL; ?>style.css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/kiny.js"></script>
</head>
<body>
<div id="main">
<div id="header">
<div id="header-container">
<div id="header-left">
<h1 id="logo">
<a href="<?php echo BLOG_URL; ?>" title="<?php echo $site_title; ?> - 首页">homePage</a>
</h1></div>
<div id="header-right">
<div id="header-icons">
<ul>
<li><a class="icon-a" target="_blank" title="title" href="#">icons-a</a></li>
<li><a class="icon-b" target="_blank" title="title" href="#">icons-b</a></li>
<li><a class="icon-c" target="_blank" title="title" href="#">icons-c</a></li>
<li><a class="icon-d" target="_blank" title="title" href="/rss.php">订阅</a>
</li></ul></div></div>
<div class="clear"></div>
<div id="header-nav">
<?php blog_navi();?>
<div class="header-search">
<form target="_blank" action="<?php echo BLOG_URL; ?>index.php" id="cse-search-box">
<div><input class="search-text-box" type="text" name="keyword" onblur="if(this.value==''){this.value='搜索神马的最有爱了...';}" onfocus="this.value='';" value="搜索神马的最有爱了..." size="31" />
<input type="submit" onmouseover="this.className='header-search-hover'" onmouseout="this.className='header-search-normal'" class="header-search-normal" value="" /></div></form>
</div>
</div>
<div class="clear"></div>
</div>
</div>
<div id="container">