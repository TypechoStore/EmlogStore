<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="clear"></div>
</div></div>
<div id="footer">
<div id="footer-content">
<p><a rel="nofollow" target="_blank" href="/rss.php">订阅本站</a>  |  &copy; 2014 &nbsp;&nbsp;<?php  echo $blogname; ?>&nbsp;&nbsp; All Rights Reserved.</p>
<p><a rel="nofollow" target="_blank" href="http://www.miibeian.gov.cn/">火星ICP备33665号</a>  |  本站使用 
<a rel="nofollow" href="http://www.emlog.net/">emlog</a> 技术构建&nbsp;&nbsp;Theme by
<a target="_blank" href="http://www.33665.net">Kiny</a></p>
</div>
</div>
</body>
</html>