<?php 
/**
 * 侧边栏
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="sidebar">
<div class="widget-content">
<center><br/>
<a href="#"><img src="<?php echo TEMPLATE_URL; ?>/images/a2.jpg" width="250px" border="0" ></a>
</center>
</div>
<div class="widget"><h3 class="widget-title">热门文章</h3>
	<ul class="link-list">
	<?php
	$index_hotlognum = Option::get('index_hotlognum');
	$Log_Model = new Log_Model();
	$hotLogs = $Log_Model->getHotLog($index_hotlognum);?>
	<?php foreach($hotLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>" class="title"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
</div>
<div class="widget"><h3 class="widget-title">随机推荐</h3>
	<ul class="link-list">
	<?php
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	<?php foreach($randLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>" class="title"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
</div>
<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>
<div id="sidebar_float" class="clear">
<div class="widget"><h3 class="widget-title">这真不是广告！</h3>
<a href="#"><img src="<?php echo TEMPLATE_URL; ?>/images/a2.jpg" width="250px" border="0" ></a>
</div>
</div>

<div class="clear"></div></div>

</div>