<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<p>待开发</p>
<?php include View::getView('footer');?>
