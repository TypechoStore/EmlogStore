<?php 
/*
* �ײ���Ϣ
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<hr class="hide" />
	<div id="footer">
		<div class="inside">
			<p class="copyright">Powered by <a href="http://www.emlog.net/">Emlog</a> Theme <a href="http://warpspire.com/hemingway" rel="designer">Hemingway</a> <a href="http://iuuuu.net" title="theme��ֲ">ooxx</a>.flavored .</p>
			<p class="attributes">&copy;2012<?php echo $blogname; ?>.<a href="<?php echo BLOG_URL; ?>rss.php">RSS</a></p>
		</div>
	</div>
	<!-- [END] #footer -->	
<?php doAction('index_footer'); ?>
</body>
</html>
