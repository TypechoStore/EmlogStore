<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<hr class="hide" />
	<div id="ancillary">
		<div class="inside">
			<div class="block first">
				<h2>Recently</h2>
                <ul class="dates">
				<?php widget_newlog(''); ?>
				</ul>
				<h2>Comments</h2>
                <ul class="dates">
				<?php widget_newcomm(''); ?>
				</ul>
			</div>		
			<div class="block">
				<h2>Categories</h2>
                <ul class="counts">
				<?php widget_sort(''); ?>
				</ul>
				<h2>Tags</h2>
							    <?php
	                            global $CACHE;
	                            $tag_cache = $CACHE->readCache('tags');
                                ?>
				<ul>
	                            <?php shuffle($tag_cache);$tag_cache = array_slice($tag_cache,0,30);foreach($tag_cache as $value): ?>
		                        <span style="font-size:<?php echo $value['fontsize']; ?>pt; line-height:30px;">
		                        <a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇日志" style="text-decoration:none;"><?php echo $value['tagname']; ?></a></span>
	                            <?php endforeach; ?>
				</ul>
			</div>			
			<div class="block">
				<h2>Pages</h2>
                <?php blog_navi();?>
				<h2>Links</h2>
				<ul class="pages">
				<?php widget_link(''); ?>
				</ul>
			</div>
			
			<div class="clear"></div>
		</div>
	</div>