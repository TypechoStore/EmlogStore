<?php 
/*
* �Ķ���־ҳ��
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="primary" class="single-post">
		<div class="inside">
			<div class="primary">
				<h1 style="font-size:20px;"><?php echo $log_title; ?></h1>
				<p><?php echo $log_content; ?></p>
			</div>
			<hr class="hide" />
			<div class="secondary">
				<h2>About this entry</h2>
				<div class="featured">
					<p>You&rsquo;re currently reading &ldquo;<?php echo $log_title; ?>,&rdquo; an entry on <?php echo $blogname; ?></p>
					<dl>
						<dt>Published:</dt>
						<dd><?php echo gmdate('n.j.y / ga', $date); ?></dd>
					</dl>
					<dl>
						<dt>Category:</dt>
						<dd><?php blog_sort($logid); ?></dd>
					</dl>
					<dl>
						<dt>Tags:</dt>
						<dd><?php blog_tag($logid); ?></dd>
					</dl>
					<dl>
					    <dt>Edit:</dt>
						<dd><?php editflg($logid,$author); ?></dd>
					</dl>
				</div>
			</div>
			<div class="navigation">
				<?php neighbor_log($neighborLog); ?>
			</div>
			<div class="clear"></div>
		</div>
	</div>
	<!-- [END] #primary -->
	
	<hr class="hide" />
	<div id="secondary">
		<div class="inside">
			<ol id="comments" class="commentlist">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	        </ol>
		</div>
	</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>
