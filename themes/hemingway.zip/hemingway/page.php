<?php 
/*
* �Խ�ҳ��ģ��
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

	<div id="primary">
	<div class="inside">
		<div class="primary">
		<h1><?php echo $log_title; ?></h1>
		<p><?php echo $log_content; ?></p>
		<br class="clear" />
		</div>
	<div class="secondary">
		<h2>About the Page</h2>
		<div class="featured">
			<p>Welcome to the <?php echo $log_title; ?>, here at <?php echo $blogname; ?>. Have a look around.</p>		
		</div>
	</div>
		<br class="clear" />
	</div>
	</div>

	<hr class="hide" />
	<div id="secondary">
		<div class="inside">
			<ol id="comments" class="commentlist">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	        </ol>
	</div>
	</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>
