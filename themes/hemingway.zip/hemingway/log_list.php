<?php 
/*
* ��ҳ��־�б�����
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="primary" class="twocol-stories">
		<div class="inside">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
					<div class="story <?php echo ($final?"final":"first"); ?>" id="post">
						<h3 style="font-size:17px;"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h3>
						<p><?php echo $value['log_description']; ?></p>
						<div class="details">
							Posted at <span><?php echo gmdate('M jS', $value['date']); ?></span> | <a href="<?php echo $value['log_url']; ?>#comments" class="CommentsNumber"><?php if($value['comnum']==0){echo 'No Comments';}elseif($value['comnum']==1){echo '1 Comment';}else{echo $value['comnum'].' Comments';} ?></a> | Filed Under: <?php blog_sort($value['logid']); ?> <span class="read-on"><a href="<?php echo $value['log_url']; ?>">read on</a></span>
						</div>
					</div>
					<?php $final = ! $final; ?>
				<?php endforeach; ?>
		</div>				
			<div class="clear"></div>
	<div id="dynamic_page" class="page_nav">
	  <ul class="nav">
	     <div id="fanye">
		   <?php echo $page_url;?>
	     </div>
	  </ul>
	</div>
	</div>
	<!-- [END] #primary -->
<?php
 include View::getView('side');
 include View::getView('footer');
?>
