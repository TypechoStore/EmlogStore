<?php
				 $config_admin_dir = 'admin';
				 $config_is_pjax = 'n';
				 $config_is_play = 'n';
	 			 $config_is_ajax_page = 'n';
				 $config_is_play_auto = 'false';
				 $config_is_play_defaultMode = '1';
				 $config_playjson = '[{
			"title":"花下舞剑",
			"singer":"童可可",
			"cover":"https://img3.kuwo.cn/star/albumcover/240/49/7/2753401394.jpg",
			"src":"http://other.web.rf01.sycdn.kuwo.cn/resource/n1/84/87/3802376964.mp3",
			"lyric":"http://localhost/me/content/templates/tongleer/assets/smusic/data/tongkeke-huaxiawujian.lrc"
		},{
			"title":"萌二代",
			"singer":"童可可",
			"cover":"https://img3.kuwo.cn/star/albumcover/240/35/65/238194684.jpg",
			"src":"http://other.web.rg01.sycdn.kuwo.cn/resource/n3/21/49/2096701565.mp3",
			"lyric":"http://localhost/me/content/templates/tongleer/assets/smusic/data/tongkeke-mengerdai.lrc"
		},{
			"title":"吃货进行曲",
			"singer":"童可可",
			"cover":"https://img3.kuwo.cn/star/albumcover/240/26/34/1695727344.jpg",
			"src":"http://other.web.rh01.sycdn.kuwo.cn/resource/n3/15/72/1780780959.mp3",
			"lyric":"http://localhost/me/content/templates/tongleer/assets/smusic/data/tongkeke-chihuojinxingqu.lrc"
		},{
			"title":"小秘密",
			"singer":"童可可",
			"cover":"https://img3.kuwo.cn/star/albumcover/240/55/73/500614479.jpg",
			"src":"http://other.web.rh01.sycdn.kuwo.cn/resource/n1/74/68/3330561514.mp3",
			"lyric":"http://localhost/me/content/templates/tongleer/assets/smusic/data/tongkeke-xiaomimi.lrc"
		},{
			"title":"听你爱听的歌",
			"singer":"童可可",
			"cover":"https://img1.kuwo.cn/star/starheads/240/16/85/44330486.jpg",
			"src":"http://other.web.rh01.sycdn.kuwo.cn/resource/n2/80/39/46671518.mp3",
			"lyric":"http://localhost/me/content/templates/tongleer/assets/smusic/data/tongkeke-tingniaitingdege.lrc"
		},{
			"title":"别让我放不下",
			"singer":"童可可",
			"cover":"https://img1.kuwo.cn/star/albumcover/240/9/59/996272309.jpg",
			"src":"http://other.web.rh01.sycdn.kuwo.cn/resource/n1/15/60/2541949312.mp3",
			"lyric":"http://localhost/me/content/templates/tongleer/assets/smusic/data/tongkeke-bierangwofangbuxia.lrc"
		},{
			"title":"非主恋",
			"singer":"童可可",
			"cover":"https://img4.kuwo.cn/star/albumcover/240/21/10/339989310.jpg",
			"src":"http://other.web.rh01.sycdn.kuwo.cn/resource/n2/34/93/1218459911.mp3",
			"lyric":"http://localhost/me/content/templates/tongleer/assets/smusic/data/tongkeke-feizhulian.lrc"
		}]';
				 $config_nav = '<li><a href=http://baidu.com target=_blank>百度</a></li><li><a href=http://qq.com target=_blank>腾迅</a></li>';
				 $config_favicon = 'https://ws3.sinaimg.cn/large/005V7SQ5ly1fyq0d52r6tj300s00s744.jpg';
				 $config_bg = '';
		         $config_headBg = 'https://ws3.sinaimg.cn/large/005V7SQ5ly1fyq0dkqh45j31hc0u0wn1.jpg';
		         $config_headImgUrl = 'https://cambrian-images.cdn.bcebos.com/39ceafd81d6813a014e747db4aa6f0eb_1524963877208.jpeg';
		         $config_nickname = '快乐贰呆';
		         $config_sex = 'girl';				 
		         $config_follow_qrcode = 'https://ws3.sinaimg.cn/large/005V7SQ5ly1fyq01sd3bnj303w03wt8m.jpg';
				 $config_home_name = '主页';
				 $config_home_link = 'javascript:;';				 
				 $config_album_name= '相册';			 
			     $config_album_link = 'javascript:;';
			     $config_other_1_name = '^_^';
			 	 $config_other_1_link = 'javascript:;';
			 	 $config_weiboname = '同乐儿';
			     $config_address = '北京 朝阳区';
			 	 $config_birthday = '2018年7月1日';
				 $config_detail = '联系 ：diamond@tongleer.com 微信：Diamond0419';
				 $config_about = '';
				 $config_foot_count = '';
	    ?>