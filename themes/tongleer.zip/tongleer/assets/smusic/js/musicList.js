/**
 * Created by Smohan on 2015/5/15.
 */
    
var musicList = [
    {
        title : '花下舞剑',
        singer : '童可可',
        cover  : 'http://img3.kuwo.cn/star/albumcover/240/49/7/2753401394.jpg',
        src    : 'http://other.web.rf01.sycdn.kuwo.cn/resource/n1/84/87/3802376964.mp3',
		lyric  : "http://localhost/video/content/templates/tongleer/assets/smusic/data/tongkeke-huaxiawujian.lrc"
    },
    {
        title : '萌二代',
        singer : '童可可',
        cover  : 'http://img3.kuwo.cn/star/albumcover/240/35/65/238194684.jpg',
        src    : 'http://other.web.rg01.sycdn.kuwo.cn/resource/n3/21/49/2096701565.mp3',
		lyric  : "http://localhost/video/content/templates/tongleer/assets/smusic/data/tongkeke-mengerdai.lrc"
    },
    {
        title : '吃货进行曲',
        singer : '童可可',
        cover  : 'http://img3.kuwo.cn/star/albumcover/240/26/34/1695727344.jpg',
        src    : 'http://other.web.rh01.sycdn.kuwo.cn/resource/n3/15/72/1780780959.mp3',
		lyric  : "http://localhost/video/content/templates/tongleer/assets/smusic/data/tongkeke-chihuojinxingqu.lrc"
    },
    {
        title : '小秘密',
        singer : '童可可',
        cover  : 'http://img3.kuwo.cn/star/albumcover/240/55/73/500614479.jpg',
        src    : 'http://other.web.rh01.sycdn.kuwo.cn/resource/n1/74/68/3330561514.mp3',
		lyric  : "http://localhost/video/content/templates/tongleer/assets/smusic/data/tongkeke-xiaomimi.lrc"
    },
    {
        title : '听你爱听的歌',
        singer : '童可可',
        cover  : 'http://img1.kuwo.cn/star/starheads/240/16/85/44330486.jpg',
        src    : 'http://other.web.rh01.sycdn.kuwo.cn/resource/n2/80/39/46671518.mp3',
		lyric  : "http://localhost/video/content/templates/tongleer/assets/smusic/data/tongkeke-tingniaitingdege.lrc"
    },
    {
        title : '别让我放不下',
        singer : '童可可',
        cover  : 'http://img1.kuwo.cn/star/albumcover/240/9/59/996272309.jpg',
        src    : 'http://other.web.rh01.sycdn.kuwo.cn/resource/n1/15/60/2541949312.mp3',
		lyric  : "http://localhost/video/content/templates/tongleer/assets/smusic/data/tongkeke-bierangwofangbuxia.lrc"
    },
    {
        title : '非主恋',
        singer : '童可可',
        cover  : 'http://img4.kuwo.cn/star/albumcover/240/21/10/339989310.jpg',
        src    : 'http://other.web.rh01.sycdn.kuwo.cn/resource/n2/34/93/1218459911.mp3',
		lyric  : "http://localhost/video/content/templates/tongleer/assets/smusic/data/tongkeke-feizhulian.lrc"
    }
];
