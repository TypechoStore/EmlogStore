<div class="one-left">
<?php doAction('index_loglist_top'); ?>
<?php if(!empty($logs)):foreach($logs as $value):?>
<div class="one-list">
<div class="one-list-tp"><?php $imgsrc = preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);$imgsrc = !empty($img[1]) ? $img[1][0] : ''; ?><?php if($imgsrc): ?><img src="<?php echo $imgsrc; ?>"><?php else: ?><img src="<?php echo TEMPLATE_URL;?>images/news.jpg" alt="暂无图片" /><?php endif; ?></div>
<div class="one-list-nr">
<div class="one-list-nr-tt"><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></div>
<div class="one-list-nr-nr"><?php echo subString(strip_tags($value['content']),0,200);?></div>
<div class="one-list-bottom">
<span class="posttime"><?php echo gmdate('Y-m-d', $value['date']); ?></span>
<span class="category"><?php blog_sort($value['logid']); ?></span>
<span class="views">浏览(<?php echo $value['views']; ?>)</span>
<span class="comments"><a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a></span>
</div></div></div>
<?php endforeach;else:?>
<script type="text/javascript" src="http://sheli.sinaapp.com/js-sheli/ksan_tb.js"></script>
<?php endif;?>
<div class="one-pagenav"><?php echo $page_url;?></div>
</div>
<div class="one-right"><?php include View::getView('side');?></div>
<?php include View::getView('footer');?>