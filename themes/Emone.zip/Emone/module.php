<?php if(!defined('EMLOG_ROOT')) {exit('error!');} if (!function_exists('_g')) {emMsg('<div style="color:#ff0000;line-height:40px;text-align:center;font-size:16px;">欢迎你使用由舍力制作的主题；</div><div style="line-height:25px;font-size:14px;color:#999;">你现在无法正常使用本模板的原因：<br />1、你可能还未安装，请先安装<a href="http://www.emlog.net/plugin/144" target="_blank">模板设置插件</a><br />2、你还未启用模板设置插件，请到后面插件管理中启用模板插件；<br />主题由舍力负责维护，如有疑问请阅读【<a href="http://www.shuyong.net/" target="_blank">模板使用说明</a>】，QQ345952779</div>', BLOG_URL . 'admin/plugins.php');}?>
<?php
//widget：blogger
function widget_blogger($title){global $CACHE;$user_cache = $CACHE->readCache('user');$name = $user_cache[1]['mail'] != '' ? "".$user_cache[1]['name']."" : $user_cache[1]['name'];?>
<li><h3><span><?php echo $title; ?></span></h3>
<ul id="bloggerinfo"><div id="bloggerinfoimg"><?php if (!empty($user_cache[1]['photo']['src'])): ?><img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" alt="blogger" /><?php endif;?></div>
<p><b>博主：<?php echo $name; ?></b><br /><?php echo $user_cache[1]['des']; ?></p>
</ul></li>
<?php }?>
<?php
//widget：日历
function widget_calendar($title){ ?>
<li><h3><span><?php echo $title; ?></span></h3><div id="calendar"></div><script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script></li>
<?php }?>
<?php
//widget：标签
function widget_tag($title){
global $CACHE;
$tag_cache = $CACHE->readCache('tags');
foreach ($tag_cache as $key => $row) {
$usenum[$key]  = $row['usenum'];
}array_multisort($usenum, SORT_DESC, $tag_cache);?>
<li><h3><span><?php echo $title; ?></span></h3>
<ul id="blogtags">
<?php foreach($tag_cache as $value):
 if($value['usenum'] > '5'): //1可以更改为大于1的其他数字，控制文章相关数
$color = dechex(rand(3355443,13421772));?>
<li><a class="atag" style="background:#<?php echo $color; ?>" href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇文章"><?php echo $value['tagname'],' +',$value['usenum']; ?></a></li>
<?php endif; endforeach;?></ul></li>
<?php }?>
<?php
//widget：分类
function widget_sort($title){global $CACHE;$sort_cache = $CACHE->readCache('sort'); ?>
<li><h3><span><?php echo $title; ?></span></h3>
<ul id="blogsort">
<?php foreach($sort_cache as $value):if ($value['pid'] != 0) continue;?>
<li><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
<?php if (!empty($value['children'])): ?>
<?php $children = $value['children'];foreach ($children as $key):$value = $sort_cache[$key];?>
<li><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a></li>
<?php endforeach; ?><?php endif; ?><?php endforeach; ?></ul></li>
<?php }?>
<?php //widget：分类
function nav_sort($title){global $CACHE;$sort_cache = $CACHE->readCache('sort'); ?><?php foreach($sort_cache as $value):if ($value['pid'] != 0) continue;?><li><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a></li><?php if (!empty($value['children'])): ?>
<?php $children = $value['children'];foreach ($children as $key):$value = $sort_cache[$key];?><li><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a></li><?php endforeach; ?><?php endif; ?><?php endforeach; ?><?php }?>
<?php
//widget：最新微语
function widget_twitter($title){global $CACHE; $newtws_cache = $CACHE->readCache('newtw');$istwitter = Option::get('istwitter');?>
<li><h3><span><?php echo $title; ?></span></h3>
<ul id="twitter"><?php foreach($newtws_cache as $value): ?><li><?php echo $value['t']; ?><p><?php echo smartDate($value['date']); ?></p></li>
<?php endforeach; ?></ul></li>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){global $CACHE; $com_cache = $CACHE->readCache('comment');?>
<li><h3><span><?php echo $title; ?></span></h3>
<ul id="newcomment">
<?php foreach($com_cache as $value):$url = Url::comment($value['gid'], $value['page'], $value['cid']);?>
<li><a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a></li>
<?php endforeach; ?>
</ul>
</li>
<?php }?>
<?php
//widget：最新文章
function widget_newlog($title){global $CACHE; $newLogs_cache = $CACHE->readCache('newlog');?>
<li><h3><span><?php echo $title; ?></span></h3>
<ul id="newlog">
	<?php foreach($newLogs_cache as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：热门文章
function widget_hotlog($title){
	$index_hotlognum = Option::get('index_hotlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getHotLog($index_hotlognum);?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="hotlog">
	<?php foreach($randLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：随机文章
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
<li><h3><span><?php echo $title; ?></span></h3>
<ul id="randlog">
<?php foreach($randLogs as $value): ?><li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li><?php endforeach; ?></ul></li>
<?php }?>
<?php
//widget：归档
function widget_archive($title){
global $CACHE; 
$record_cache = $CACHE->readCache('record');
?>
<li><h3><span><?php echo $title; ?></span></h3>
<ul id="record"><?php foreach($record_cache as $value): ?><li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li><?php endforeach; ?></ul></li>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
<li><h3><span><?php echo $title; ?></span></h3>
<ul id="zdy"><?php echo $content; ?></ul></li>
<?php } ?>
<?php
//widget：链接
function widget_link($title){global $CACHE; 
$link_cache = $CACHE->readCache('link');
if (!blog_tool_ishome()) return;?>
<li><h3><span><?php echo $title; ?></span></h3>
<ul id="link"><?php foreach($link_cache as $value): ?><li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li><?php endforeach; ?></ul>
</li>
<?php }?>
<?php //内页链接
function ny_links(){$db = MySql::getInstance();$sql = "SELECT * FROM " . DB_PREFIX . "link WHERE hide='y' ORDER BY taxis ASC";$result = $db->query($sql);?>
<li><h3><span>链接</span></h3>
<ul id="link"><?php while($row = $db->fetch_array($result)){ ?><li><a href="<?php echo $row['siteurl']; ?>" title="<?php echo $row['description']; ?>" target="_blank"><?php echo $row['sitename']; ?></a></li><?php }?></ul></li><?php }?>


<?php
//blog：导航
function blog_navi(){global $CACHE; $navi_cache = $CACHE->readCache('navi');$i=0;?>
<ul class="bar">
<?php foreach($navi_cache as $value):$i++;if($i>9)break;if ($value['pid'] != 0) {continue;}
if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)){continue;}
$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
$value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
$current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'current' : 'common';?>
<li class="item"><div class="<?php echo $current_tab;?>"><a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a></div><?php if (!empty($value['children'])) :?><ul class="sub-nav"><?php foreach ($value['children'] as $row){echo '<li><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></li>';}?></ul><?php endif;?><?php if (!empty($value['childnavi'])) :?><ul class="sub-nav"><?php foreach ($value['childnavi'] as $row){$newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';echo '<li><a href="'. $row['url']. "\" $newtab >".$row['naviname'].'</a></li>';}?></ul><?php endif;?></li>
<?php endforeach; ?></ul><?php }?>






<?php
//blog：置顶
function topflg($top, $sortop='n', $sortid=null){
    if(blog_tool_ishome()) {
       echo $top == 'y' ? "<img src=\"".TEMPLATE_URL."/images/top.png\" title=\"首页置顶文章\" /> " : '';
    } elseif($sortid){
       echo $sortop == 'y' ? "<img src=\"".TEMPLATE_URL."/images/sortop.png\" title=\"分类置顶文章\" /> " : '';
    }
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
global $CACHE; 
$log_cache_sort = $CACHE->readCache('logsort');
?>
<?php if(!empty($log_cache_sort[$blogid])): ?><a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a><?php endif;?>
<?php }?>
<?php
//blog：文章标签
function blog_tag($blogid){
global $CACHE;
$log_cache_tags = $CACHE->readCache('logtags');
if (!empty($log_cache_tags[$blogid])){
$tag = '标签:';
foreach ($log_cache_tags[$blogid] as $value){
$tag .= "	<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
}echo $tag;}}
?>
<?php
//blog：文章作者
function blog_author($uid){
global $CACHE;
$user_cache = $CACHE->readCache('user');
$author = $user_cache[$uid]['name'];
$mail = $user_cache[$uid]['mail'];
$des = $user_cache[$uid]['des'];
$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
echo $author;
}
?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
extract($neighborLog);?>
<?php if($prevLog):?>&laquo; <a href="<?php echo Url::log($prevLog['gid']) ?>"><?php echo $prevLog['title'];?></a><?php endif;?>
<?php if($nextLog && $prevLog):?>&nbsp; | &nbsp;<?php endif;?>
<?php if($nextLog):?><a href="<?php echo Url::log($nextLog['gid']) ?>"><?php echo $nextLog['title'];?></a>&raquo;<?php endif;?>
<?php }?>
<?php //blog：评论列表 
function blog_comments($comments){extract($comments);if($commentStacks):endif; $i=1;?>
<?php $isGravatar = Option::get('isgravatar');foreach($commentStacks as $cid):$comment = $comments[$cid];$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' :$comment['poster'];?>
<div class="comment" id="comment-<?php echo $comment['cid']; ?>"><a name="<?php echo $comment['cid']; ?>"></a><div class="avatar"><img src="<?php echo myGravatar($comment['mail']); ?>" /></div><div class="comment-info"><b><?php echo $i;$i++;?>、<?php echo com_url($comment['poster']); ?> </b> [<a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)" >回复该留言</a>] <br /><span class="comment-time"><?php echo $comment['date']; ?></span></div><div class="comment-content"><?php echo $comment['content']; ?></div><?php blog_comments_children($comments, $comment['children']); ?></div><?php endforeach; ?><div class="one-pagenav"><?php echo $commentPageUrl;?></div><?php }?>
<?php //blog：子评论列表
function blog_comments_children($comments, $children){$isGravatar = Option::get('isgravatar');foreach($children as $child):$comment = $comments[$child];$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank" >'.$comment['poster'].'</a>' : $comment['poster'];?><div class="comment comment-children" id="comment-<?php echo $comment['cid']; ?>"><a name="<?php echo $comment['cid']; ?>"></a><div class="zipl"><?php if($isGravatar == 'y'): ?><div class="avatar"><img src="<?php echo myGravatar($comment['mail']); ?>" /></div><?php endif; ?><b><?php echo com_url($comment['poster']); ?></b> [<a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复该留言</a>]<br /><?php echo $comment['date']; ?><div class="comment-content"><?php echo $comment['content']; ?></div></div><?php blog_comments_children($comments, $comment['children']);?></div><?php endforeach; ?><?php }?>
<?php function Embq(){?>
<br /><small>Powered by emlog / &Author <a href="http://www.shuyong.net" target="_blank" id="xj">舍力博客</a>.</small>
<div id="shangxia"><div id="shang" title="top"></div><?php if(!empty($tws)):?><a href="<?php echo _g('comt'); ?>" id="comt" title="comment"></a><?php elseif(isset($logid)):?><a href="#comment-place" id="comt" title="comment"></a><?php else:?><a href="<?php echo _g('comurl');?>" id="comt" title="comment"></a><?php endif;?><div id="xia" title="bottom"></div></div><?php }?>
<?php //blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){if($allow_remark == 'y'): ?>
<div id="comment-place"><div class="comment-post" id="comment-post"><div class="cancel-reply" id="cancel-reply" style="display:none"><a href="javascript:void(0);" onclick="cancelReply()">取消回复</a></div>
<p class="comment-header"><b>留言/评论：◎欢迎参与讨论，请在这里发表您的看法、交流您的观点。</b><a name="respond"></a></p>
<form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
<div class="comxx"><div id="comname"><p>昵称</p><input type="text" name="comname" maxlength="49" value="<?php echo $ckname; ?>" size="22" tabindex="1" placeholder="必填项"></div>
<div id="commail"><p>邮箱</p><input type="text" name="commail"  maxlength="128"  value="<?php echo $ckmail; ?>" size="22" tabindex="2" placeholder="必填项,正确的邮箱地址"></div>
<div id="comurl"><p>网址</p><input type="text" name="comurl" maxlength="128"  value="<?php echo $ckurl; ?>" size="22" tabindex="3" placeholder="选填项"></div></div>
<p id="comnr"><textarea name="comment" id="comment" rows="10" tabindex="4" class="comnr"></textarea></p>
<p><?php echo $verifyCode; ?> <input type="submit" id="comment_submit" value="发表评论" tabindex="6" /></p>
<input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/></form></div></div><?php endif; }?>
<?php //替换评论外链
function com_url($text) {
if(strstr($text,$_SERVER['HTTP_HOST'])){return  $text;
}else{return str_replace('<a href="', '<a href="'.BLOG_URL.'go/?url=',  $text);}
}
?>
<?php
//blog-tool:获取Gravatar头像
function myGravatar($email, $s = 40, $d = 'mm', $g = 'g') {
$hash = md5($email);
$avatar = "http://cn.gravatar.com/avatar/$hash?s=$s&d=$d&r=$g";
return $avatar;
}?>
<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>
<?php //分类置顶文章
function sortoplog() {
$db = MySql::getInstance();
$sql = "SELECT gid,title,content,date FROM ".DB_PREFIX."blog WHERE type='blog' and sortop='y' ORDER BY `top` DESC ,`date` DESC LIMIT 0,10";
$list = $db->query($sql);
while($row = $db->fetch_array($list)){?>
<ul><li><div class="riqi"><p class="yue"><?php echo gmdate('n月', $row['date']);?></p><p class="ri"><?php echo gmdate('d日', $row['date']);?></p></div><span><a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>" target="_blank"><?php echo $row['title']; ?></a></span></li></ul>
<?php } }?>