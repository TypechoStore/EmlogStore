<?php
/*
Template Name:Emone主题
Description:<br /><font color=red>＊</font>简单主题，灰白相间<br><font color=red>＊</font>模板修改后出现的任何问题均请自行解决<br><font color=red>＊</font>发现主题Bug请到说明中留言<br><br><a href="http://www.shuyong.net/613.html" target="_blank">使用说明、更新日志及意见反馈</a>
Version:2.0
Author:舍力
Author Url:http://www.shuyong.net
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}require_once View::getView('module');ob_clean();?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width; initial-scale=1.0">
<title><?php echo $site_title;if($page>=2){echo ' - 第'.$page.'页';}?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<link href="<?php echo TEMPLATE_URL; ?>go/emone.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>go/Emone.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<!--[if lt IE 9]><script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>go/css3-mediaqueries.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>go/html5.js"></script><![endif]-->
<!--[if IE 6]><script src="<?php echo TEMPLATE_URL; ?>go/iefix.js" type="text/javascript"></script><![endif]-->
<?php doAction('index_head'); ?>
</head>
<body>
<div class="one-main">
<div class="one-head">
<div class="logo"><img src="<?php echo _g('logo'); ?>" alt="<?php echo $blogname; ?>" /></div>
<div class="wenzi"><p><?php echo $bloginfo; ?></p></div>
</div>
<div class="one-nav"><?php blog_navi();?></div>