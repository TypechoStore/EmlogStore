<div class="one-foot">
Copyright © 2014 <?php echo $blogname; ?> 版权所有 &nbsp; <?php echo $icp; ?><br />
<?php echo $footer_info;Embq();?>
<?php doAction('index_footer'); ?>
</div></div>
</body>
</html>