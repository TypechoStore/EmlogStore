<div class="one-left">
<div class="one-page">
<h2><?php echo $log_title; ?></h2>
<div class="one-page-nr"><?php echo $log_content; ?></div>
<?php doAction('log_related', $logData); ?>
</div>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);blog_comments($comments);?>
</div>
<div class="one-right"><?php include View::getView('side');?></div>
<?php include View::getView('footer');?>