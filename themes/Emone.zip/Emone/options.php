<?php
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(

'logo' => array(
'type' =>'image',
'name' =>'头部LOGO',
'values' => array(TEMPLATE_URL .'images/logo.png',
),
'description' =>'设置站点头部LOGO,300X60最佳。',
),

'comurl' => array(
'type' =>'text',
'name' =>'返回顶部图标中留言板链接',
'default' =>'http://www.shuyong.net/guestbook.html',
),


);