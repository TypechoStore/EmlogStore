<div class="one-left"><div class="one-log">
<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
<p class="one-log-date"><?php echo gmdate('Y-n-j', $date);?> / <?php blog_author($author); ?> / <?php blog_sort($logid); ?> / <?php editflg($logid,$author); ?></p>
<div class="one-log-nr"><?php echo $log_content; ?></div>
<p class="one-log-bq">本文由<b><?php blog_author($author); ?></b>整理编辑，转载请注明：<?php echo Url::log($logid); ?> | <?php echo $blogname; ?></p>
<p class="one-log-tag"><?php blog_tag($logid); ?></p>
<div class="one-log-nextlog"><?php neighbor_log($neighborLog); ?></div>
<?php doAction('log_related', $logData); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); blog_comments($comments);?>
</div></div>
<div class="one-right"><?php include View::getView('side');?></div>
<?php include View::getView('footer');?>