﻿<?php 
/*
Template Name:Loper
Description:因为简约，所以简单。
Version:1.0
Author:麦特佐罗
Author Url:http://www.zorrorun.com
Sidebar Amount:1
ForEmlog:5.21
*/
?>
<a href="javascript:grin('[F1]')" title="色迷迷"><img src="<?php echo TEMPLATE_URL; ?>images/face/1.gif" alt="色迷迷"/></a>
<a href="javascript:grin('[F2]')" title="哭"><img src="<?php echo TEMPLATE_URL; ?>images/face/2.gif" alt="哭"/></a>
<a href="javascript:grin('[F3]')" title="呕吐"><img src="<?php echo TEMPLATE_URL; ?>images/face/3.gif" alt="呕吐"/></a>
<a href="javascript:grin('[F4]')" title="大笑"><img src="<?php echo TEMPLATE_URL; ?>images/face/4.gif" alt="大笑"/></a>
<a href="javascript:grin('[F5]')" title="口水"><img src="<?php echo TEMPLATE_URL; ?>images/face/5.gif" alt="口水"/></a>
<a href="javascript:grin('[F6]')" title="微笑"><img src="<?php echo TEMPLATE_URL; ?>images/face/6.gif" alt="微笑"/></a>
<a href="javascript:grin('[F7]')" title="啵一个"><img src="<?php echo TEMPLATE_URL; ?>images/face/7.gif" alt="啵一个"/></a>
<a href="javascript:grin('[F8]')" title="发怒"><img src="<?php echo TEMPLATE_URL; ?>images/face/8.gif" alt="发怒"/></a>
<a href="javascript:grin('[F9]')" title="给力"><img src="<?php echo TEMPLATE_URL; ?>images/face/9.gif" alt="给力"/></a>
<a href="javascript:grin('[F10]')" title="囧"><img src="<?php echo TEMPLATE_URL; ?>images/face/10.gif" alt="囧"/></a>
<a href="javascript:grin('[F11]')" title="难过"><img src="<?php echo TEMPLATE_URL; ?>images/face/11.gif" alt="难过"/></a>
<a href="javascript:grin('[F12]')" title="糯米"><img src="<?php echo TEMPLATE_URL; ?>images/face/12.gif" alt="糯米"/></a>
<a href="javascript:grin('[F13]')" title="玫瑰"><img src="<?php echo TEMPLATE_URL; ?>images/face/13.gif" alt="玫瑰"/></a>
<a href="javascript:grin('[F14]')" title="伤不起"><img src="<?php echo TEMPLATE_URL; ?>images/face/14.gif" alt="伤不起"/></a>
<a href="javascript:grin('[F15]')" title="有木有"><img src="<?php echo TEMPLATE_URL; ?>images/face/15.gif" alt="有木有"/></a>
<a href="javascript:grin('[F16]')" title="惊叹号"><img src="<?php echo TEMPLATE_URL; ?>images/face/16.gif" alt="惊叹号"/></a>
<a href="javascript:grin('[F17]')" title="看海"><img src="<?php echo TEMPLATE_URL; ?>images/face/17.gif" alt="看海"/></a>
<a href="javascript:grin('[F18]')" title="向日葵"><img src="<?php echo TEMPLATE_URL; ?>images/face/18.gif" alt="向日葵"/></a>
<a href="javascript:grin('[F19]')" title="豌豆射手"><img src="<?php echo TEMPLATE_URL; ?>images/face/19.gif" alt="豌豆射手"/></a>
<a href="javascript:grin('[F20]')" title="豌豆"><img src="<?php echo TEMPLATE_URL; ?>images/face/20.gif" alt="豌豆"/></a>
<a href="javascript:grin('[F21]')" title="坚果"><img src="<?php echo TEMPLATE_URL; ?>images/face/21.gif" alt="坚果"/></a>
<a href="javascript:grin('[F22]')" title="僵尸"><img src="<?php echo TEMPLATE_URL; ?>images/face/22.gif" alt="僵尸"/></a>