<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
    <div class="title">
        <span class="tags"><?php blog_tag($logid); ?>
	    </span>
	<?php blog_sort($logid); ?>
    </div>
	<div class="post f">
        <div class="info">
            <span class="time"><?php $weekarray=array("日","一","二","三","四","五","六"); 
echo gmdate('Y-n-j', $date );echo " 星期".$weekarray[gmdate('w', $date)];?>  [<a href="<?php echo $value['log_url']; ?>#comments"><?php echo $comnum; ?>/<?php echo $views; ?></a>]</span>
            <h1 title="<?php echo $log_title; ?>"><?php echo $log_title; ?></h1>
            <span class="small"></span>
        </div>
	<div class="blank8"></div>
	<?php echo $log_content; ?>
    <div class="break"></div>
    <div class="related">
        <h3><abbr>相关日志</abbr></h3>
            <div class="relatedbox">
                <ul>
                <?php doAction('log_related', $logData); ?>
                </ul>
                <div class="break"></div>
            </div>
			</div>
		<div class="blank8"></div>
		<div class="sharejs">
            <div id="ckepop">
<!-- JiaThis Button BEGIN -->
<div class="jiathis_style">
	<span class="jiathis_txt">分享到：</span>
	<a class="jiathis_button_qzone">QQ空间</a>
	<a class="jiathis_button_tsina">新浪微博</a>
	<a class="jiathis_button_tqq">腾讯微博</a>
	<a class="jiathis_button_renren">人人网</a>
	<a class="jiathis_button_copy">复制网址</a>
	<a href="http://www.jiathis.com/share?uid=91161" class="jiathis jiathis_txt jiathis_separator jtico jtico_jiathis" target="_blank">更多</a>
</div>
<script type="text/javascript" src="http://v3.jiathis.com/code/jia.js?uid=91161" charset="utf-8"></script>
<!-- JiaThis Button END -->
            </div>
				</div>
		
        <div class="postnext">
         <?php neighbor_log($neighborLog); ?>
        </div>
	</div>
	<div id="comments">
			<a name="comments"></a>
	<h3>本文有 <?php echo $comnum; ?> 篇评论<a href="#response" title="发表你的见解"> ↓↓</a></h3>
    <?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
</div>
<?php include('side.php'); ?>
<?php include('footer.php'); ?>