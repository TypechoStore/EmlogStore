<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
    <div id="t_box" class="title">
        <div id="welcome">
		    <?php
			global $CACHE; 
			$newtws_cache = $CACHE->readCache('newtw');
			$istwitter = Option::get('istwitter');
		    ?>
		    <?php foreach($newtws_cache as $value): ?>
		        <li>
			            <a href="<?php echo BLOG_URL . 't/'; ?>"><?php echo substr($value['t'],0,100); ?></a>
		        </li>
		    <?php endforeach; ?>
	    </div>
	    <script>
		    var c, _ = Function;
		    with( o = document.getElementById("welcome")) {
			    innerHTML += innerHTML;
			    onmouseover = _("c=1");
			    onmouseout = _("c=0");
		    }( F = _("if(#%27||!c)#++,#%=o.scrollHeight>>1;setTimeout(F,#%27?10:5000);".replace(/#/g, "o.scrollTop")))();
	    </script>
	</div>
	<div id="comments"> 
	<?php 
		foreach($tws as $val):
        $author = $user_cache[$val['author']]['name'];
        $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
        $tid = (int)$val['id'];
        $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?>
    <ol class="comment-list">
	    <li class="comment-body comment-parent comment-odd twitter">
            <div class="comment-author">
	            <img class="avatar" alt="#" src="<?php echo $avatar; ?>" original="<?php echo $avatar; ?>">
		        <cite class="fn"><?php echo $author; ?></a></cite>	
            </div>	
            <div class="comment-meta"><?php echo $val['date'];?></div>
            <div class="comment-content"><?php echo $val['t'].'<br/>'.$img;?></div>
		<ul id="r_<?php echo $tid;?>" class="r"></ul>
		<div class="huifu" id="rp_<?php echo $tid;?>" style="display: none;">
	        <textarea id="rtext_<?php echo $tid; ?>" style="margin: 0px; width: 494px; height: 71px;"></textarea>
            <div class="tbutton">
            <div class="tinfo" style="display:<?php if(ROLE == 'admin' || ROLE == 'writer'){echo 'none';}?>">
            昵称：<input type="text" id="rname_<?php echo $tid; ?>" value="" />
            <span style="display:<?php if($reply_code == 'n'){echo 'none';}?>">验证码：<input type="text" id="rcode_<?php echo $tid; ?>" value="" /><?php echo $rcode; ?></span>        
            </div>
			<input id="submit" class="submit" type="submit" value="回复" name="pid" onclick="reply('<?php echo DYNAMIC_BLOGURL; ?>index.php?action=reply',<?php echo $tid;?>);"></input>
            <div class="msg"><span id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></span></div>
            </div>
        </div>
	    </li>
    </ol>
	<?php endforeach;?>
    </div>
	<ol class="page-navigator">
        <li class="current">
            <li><?php echo $pageurl;?></li>
        </li>
	</ol>
</div>
<?php include('side.php'); ?>
<?php include('footer.php'); ?>