<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
    <div id="t_box" class="title">
       <div id="welcome">
		<?php
			global $CACHE; 
			$newtws_cache = $CACHE->readCache('newtw');
			$istwitter = Option::get('istwitter');
		?>
		<?php foreach($newtws_cache as $value): ?>
		<li>
			<a href="<?php echo BLOG_URL . 't/'; ?>"><?php echo substr($value['t'],0,100); ?></a>
		</li>
		<?php endforeach; ?>
	    </div>
	    <script>
		var c, _ = Function;
		with( o = document.getElementById("welcome")) {
			innerHTML += innerHTML;
			onmouseover = _("c=1");
			onmouseout = _("c=0");
		}( F = _("if(#%27||!c)#++,#%=o.scrollHeight>>1;setTimeout(F,#%27?10:5000);".replace(/#/g, "o.scrollTop")))();
	    </script>
    </div>
	<div class="post f">
        <div class="info">
            <h1><?php echo $log_title; ?></h1>
        </div>
	<div class="blank8"></div>
	<?php echo $log_content; ?>
        <div class="break"></div>
	</div>
	<div id="comments">
    <?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
</div>
<?php include('side.php'); ?>
<?php include('footer.php'); ?>