<?php
/*
Template Name:jandan for emlog
Description:仿煎蛋风格emlog模板,移植自typecho.原作者fufuok.com
Version:1.2.1
Author:Hyear
Author Url:http://www.hyear.net
Sidebar Amount:1
ForEmlog:5.3.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>style.css" type="text/css" />
<link rel="shortcut icon" href="<?php echo BLOG_URL; ?>favicon.ico" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script type="text/javascript">if (window!=top)top.location.href =window.location.href;</script>
<!--[if IE 6]><link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>ie.css" /><![endif]-->
<?php doAction('index_head'); ?>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<div class="logo">
		    <h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
		</div>
        <div class="nav">
            <ul>
			    <li>
				<?php blog_navi();?>
				</li>
            </ul>
        </div>
	</div>
<div id="body">