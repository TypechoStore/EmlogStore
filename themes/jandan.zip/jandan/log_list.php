<?php 
/*
* 首页日志列表部分
<div class="title"><?php if($this->is('index')): ?><?php _e('新鲜发布'); ?><?php else: ?><?php $this->archiveTitle(' - ', '', ''); ?><?php endif; ?>：</div>
	<?php while($this->next()): ?>
	隐藏某分类<div class="post f" <?php if(blog_sortid($value['logid'])==4 && !isset($sortName))echo 'style="display:none;"';?>>
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="t_box" class="title">
    <div id="welcome">
		<?php
			global $CACHE; 
			$newtws_cache = $CACHE->readCache('newtw');
			$istwitter = Option::get('istwitter');
		?>
		<?php foreach($newtws_cache as $value): ?>
		<li>
			<a href="<?php echo BLOG_URL . 't/'; ?>"><?php echo substr($value['t'],0,100); ?></a>
		</li>
		<?php endforeach; ?>
	</div>
	<script>
		var c, _ = Function;
		with( o = document.getElementById("welcome")) {
			innerHTML += innerHTML;
			onmouseover = _("c=1");
			onmouseout = _("c=0");
		}( F = _("if(#%27||!c)#++,#%=o.scrollHeight>>1;setTimeout(F,#%27?10:5000);".replace(/#/g, "o.scrollTop")))();
	</script>
</div>
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
	<div class="post f">
        <div class="info">
            <span class="time"><?php $weekarray=array("日","一","二","三","四","五","六"); 
echo gmdate('Y-n-j', $value['date']);echo " 星期".$weekarray[gmdate('w', $value['date'])];?> [<a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?>/<?php echo $value['views']; ?></a>]</span>
            <h1>
			<a href="<?php echo $value['log_url']; ?>" rel="bookmark" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a>
			</h1>

        </div>
		<div class="blank8"></div>
        <?php echo $value['log_description']; ?>
    </div>
<?php endforeach; ?>
    <ol class="page-navigator">
        <li class="current">
            <li><?php echo $page_url;?></li>
        </li>
	</ol>
    <div class="break"></div>
</div>
<?php include('side.php'); ?>
<?php include('footer.php'); ?>


