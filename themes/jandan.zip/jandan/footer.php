<?php 
/*
* �ײ���Ϣ
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="break"></div>
</div>
<div id="footer">&copy; 1987 - max . <?php echo $blogname; ?> .
    Powered by 
    <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">emlog</a>  
    <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>  
    <?php doAction('index_footer'); ?>  <?php echo $footer_info; ?>
	&#x56FE;&#x7247;&#x6258;&#x7BA1;&#x5728;<a href="http://tietuku.com" target="_blank" title="&#x672C;&#x7AD9;&#x56FE;&#x7247;&#x5B58;&#x50A8;&#x7531;&#x8D34;&#x56FE;&#x5E93;&#x5F3A;&#x529B;&#x9A71;&#x52A8;">&#x8D34;&#x56FE;&#x5E93;</a>
</div>

<ul id="social-icons" style="left: 15px;">
				<li><a href="http://www.hyear.net/rss.php" class="feed tooltip" title="&#x8BA2;&#x9605;&#x6211;&#x7684;&#x535A;&#x5BA2;" target="_blank" rel="nofollow">feed</a></li>
				<li><a href="http://weibo.com/hyear" class="weibo tooltip" title="&#x5173;&#x6CE8;&#x6211;&#x7684;&#x5FAE;&#x535A;" target="_blank" rel="nofollow">weibo</a></li>
</ul>

    <a id="go_top" style="cursor: pointer; display: inline;" onclick="#">
        <span>
            &#x25B2;
        </span>
	</a>
</div>
</body>
<script src="<?php echo BLOG_URL; ?>content/templates/jandan/script/scrolltop.js" type="text/javascript"></script>
</html>