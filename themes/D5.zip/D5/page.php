<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="meta">
	<h1 class="meta-tit"><?php echo $log_title;?></h1>
	<div class="share-ico"><?php include View::getView('mod-share'); ?></div>
	<p class="meta-info">作者:<?php blog_author($author); ?> &nbsp;&nbsp;发布于：<?php $weekarray=array("日","一","二","三","四","五","六"); echo gmdate('Y年n月j日 G:i:s', $date);echo " 周".$weekarray[gmdate('w', $date)]; ?> &nbsp;&nbsp; 分类：<?php blog_sort($logid); ?> &nbsp;&nbsp; <?php echo $views; ?> 人浏览</p>
</div>
<div class="entry">
	<?php echo $log_content; ?>
</div>
	<?php blog_comments($comments,$params); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>

<?php
 include View::getView('side');
 include View::getView('footer');
?>