<?php 
/**
 * 侧边栏
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>
<div class="sidebar">
	<ul class="mypages">
		<li><a class="my-a my-tqq ds_tqqq"><span><strong>腾讯微博</strong></span>腾讯微博 &raquo;</a></li>
		<li><a class="my-a my-weibo ds_tsinaa"><span><strong>新浪微博</strong></span>新浪微博 &raquo;</a></li>
		<li><a target="_blank" class="my-a my-feed" href="<?php echo BLOG_URL; ?>"><span><strong>订阅本站</strong></span>订阅本站<em></em></a>
			<div class="mypages-dropdown">
				<a target="_blank" href="http://fusion.google.com/add?feedurl=<?php echo BLOG_URL; ?>">Google</a>
				<a target="_blank" href="http://www.xianguo.com/subscribe.php?url=<?php echo BLOG_URL; ?>">鲜果</a>
				<a target="_blank" href="http://www.zhuaxia.com/add_channel.php?url=<?php echo BLOG_URL; ?>">抓虾</a>
				<a target="_blank" href="http://mail.qq.com/cgi-bin/feed?u=<?php echo BLOG_URL; ?>">QQ邮箱</a>
				<a target="_blank" href="http://reader.youdao.com/b.do?keyfrom=<?php echo BLOG_URL; ?>">有道</a>
				<a target="_blank" href="http://add.my.yahoo.com/rss?url=<?php echo BLOG_URL; ?>">Yahoo</a>
			</div>
		</li>
		<li><a target="_blank" class="my-a my-theme" href="http://www.daqianduan.com/d5/"><span><strong>本站主题</strong></span>本站主题 &raquo;</a></li>
	</ul>
	<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>
</div>


