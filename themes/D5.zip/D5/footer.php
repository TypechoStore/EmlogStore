<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>

<div class="footer">
	<div class="inner">
		<p class="copyright">
			 <?php echo $footer_info; ?> Powered by <a href="http://bbs.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">emlog</a>  Theme D5 <a href="http://lwllo.com" target="_blank">老王</a> 移植至 <a href="http://www.daqianduan.com" target="_blank">大前端</a>
		</p>
	</div>
</div>
<script src="<?php echo TEMPLATE_URL; ?>js/post.js" type="text/javascript"></script>
<?php doAction('index_footer'); ?>
<script>prettyPrint();</script>
</body>
</html>

