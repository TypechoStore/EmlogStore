<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="post-author">
    <div class="avatar">
        <img alt="" src="<?php $user_cache = Cache::getInstance()->readCache('user'); echo getGravatar($user_cache[1]['mail'],70);?>" class="avatar" height="70" width="70" style="display: block;">
    </div>
    <div class="post-author-desc">
        <a class="post-author-name"><span>注意:</span></a><br>
        <div class="post-author-description">如果有两位博主,上面的头像默认显示第一位,如想显示别的,就将[1]改为对应的就行了.</div>
        <div class="post-author-links">预留位置</div>
        <div class="clear" style="clear both"></div>
        <div class="post-author-title">交代几句</div>
    </div>
</div>
<div class="share-txt share-home">我喜欢，<?php include View::getView('mod-share'); ?></div>
<?php doAction('index_loglist_top'); ?>
    <ul class="excerpt thumb">
		<?php foreach($logs as $value):
		preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
		$imgsrc = !empty($img[1]) ? $img[1][0] : '';
		preg_match_all("|<embed[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $embed);
		$embedsrc = !empty($embed[1]) ? $embed[1][0] : '';?>
		<li>
			<?php if(!empty($imgsrc)):?>
	        <a href="<?php echo $value['log_url']; ?>" class="pic">
    	    <img src="<?php echo $imgsrc; ?>" border="0" title="<?php echo $value['log_title'] ?>"  alt="<?php echo $value['log_title']; ?>" width="140" height="100" /></a>
    	    <?php elseif(!empty($embedsrc)):?>	        
    	    <embed src="<?php echo $embedsrc; ?>" width="140" height="100" wmode="transparent" quality="high" class="pic"/>		
            <?php else:?>    
 			<div class="excerpt-num">
				<span class="num-comm <?php if($value['comnum'] > '18'):?>num-comm-hot<?php endif;?>"><strong><?php echo $value['comnum']; ?></strong>Comment</span>
				<span class="num-view"><strong><?php echo $value['views']; ?></strong>views</span>
			</div>
 			<?php endif; ?>					
			<p class="excerpt-tit">
				<?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
			</p>
			<p class="excerpt-desc">
				<?php echo preg_replace("/<p class=\"readmore\"><a href=\"[^\"]+\">阅读全文&gt;&gt;<\/a><\/p>/i","",$value['log_description']);?>
				<div class="more"><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" rel="bookmark">阅读全文</a></div>
			</p>
			<div class="excerpt-tag">
				作者：<?php blog_author($value['author']); ?> | 分类：<?php blog_sort($value['logid']); ?>
				<span><a href="<?php echo $value['log_url']; ?>#comments" class="ds-thread-count" title="<?php echo $value['log_title']; ?>"><?php echo $value['comnum']; ?>条评论</a> &nbsp; <?php echo $value['views']; ?> 次访问</span>
				
			</div>
			<div class="excerpt-time">
				<?php echo gmdate('Y年n月j日', $value['date']); ?>
			</div>			
		</li>
 			<?php endforeach; ?>
		<?php if($logs == NULL) { //判断搜索?>
	        <h2>未找到</h2>
	        <p>抱歉，没有符合您查询条件的结果。</p>
		<?php } ?>
    </ul>
    <div class="paging"><?php echo $page_url;?></div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>
