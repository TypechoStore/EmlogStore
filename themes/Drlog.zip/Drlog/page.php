<?php 
/**
 * 新建页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="emcon">
<div class="echolog">
		<h2><?php echo $log_title; ?></h2>
	<p class="date"><i class="iconfont icon-calendar"></i><?php echo gmdate('Y-n-j', $date);?><i class="iconfont icon-attention"></i><?php echo $views; ?> 次阅读&nbsp;&nbsp;&nbsp;<?php editflg($logid,$author); ?></p>
	<?php echo $log_content; ?>
</div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div><!-- end #emcon-->
<?php include View::getView('footer');?>