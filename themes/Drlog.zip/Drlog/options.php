<?php

/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
	'topimg' => array(
		'type' => 'image',
		'name' => '顶部背景图',
		'values' => array(
            TEMPLATE_URL . 'images/bg.jpg',
        ),
            ),	
	'tximg' => array(
		'type' => 'image',
		'name' => '头像',
		'values' => array(
            TEMPLATE_URL . 'images/tx.jpg',
        ),
            ),
	'ds_url' =>array(
		'type' => 'text',
		'name' => '多说二级域名',
		'description' => '比如我的多说fking.duoshuo.com,只需要输入fking',
		'values' => array(
			'fking',
		),
	),

	'home_strong_1' => array(
		'type' => 'text',
		'name' => '首页一句话',
		'description' => '',
		'default' => '突如其来的装逼让我无法呼吸',
    ),
	
);