<?php
/*
Template Name:Drlog
Description:瑾忆博客
Version:2.3
Author:瑾忆
Author Url:http://www.drlog.pw
Sidebar Amount:0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}

require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="zh-CN">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title><?php echo $site_title; ?> - <?php echo $site_key; ?> - <?php echo $site_description; ?></title>
    <meta name="keywords" content="<?php echo $site_key; ?>" />
    <meta name="description" content="<?php echo $site_description; ?>" />
	<meta name="generator" content="emlog" />
    <meta name="HandheldFriendly" content="True" /> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="<?php echo TEMPLATE_URL; ?>images/tx.png">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link type="<?php echo TEMPLATE_URL; ?>images/tx.jpg" href="<?php echo TEMPLATE_URL; ?>images/tx.jpg" rel="shortcut icon">
<link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>main.css">
<script src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/jquery.pjax.min.js"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>

<?php doAction('index_head'); ?>
</head>
<body>
<div class="contents">
<header style="background-image: url(<?php echo _g('topimg');?>);">
<div class="main">
	<div class="intro">
		<img src="<?php echo _g("tximg");?>" class="intro-logo"/>
		<span class="intro-sitename"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></span>
		<span class="intro-siteinfo"><?php echo _g("home_strong_1");?></span>
	</div>
	<nav>
	<div class="collapse">
		<i class="iconfont icon-menu"></i>
	</div>
	<ul class="bar">
		<?php blog_navi();?>
		</ul>
	</nav>
</div>
</header>

<div class="pjax">


