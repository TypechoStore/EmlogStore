<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>
<div class="footer">
	<div class="container">

<?php widget_link($title); ?>

	<div class="right_web"><p>Copyright &copy; 2017 <a href="<?php echo BLOG_URL; ?>" target="_blank"><?php echo $blogname; ?>  </a>Theme is Drlog By <a target="_blank" rel="nofollow" href="http://www.drlog.pw/">瑾忆</a></p>
	<p><?php echo $footer_info; ?></p>
	</div>
	</div>
</div>
</div>
<div class="bg"></div>
<div class="bg-fixed"></div>
<div class="back2top"></div>
<script src="<?php echo TEMPLATE_URL; ?>js/parts.js"></script>
<?php doAction('index_footer'); ?>
<?php doAction('index_bodys'); ?>
</body>
</html>