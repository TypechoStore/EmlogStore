<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="con">	
<?php 
if (!empty($logs)):
foreach($logs as $value):
$logdes = blog_tool_purecontent($value['content'], 96);
?>
	<li>
		<h1><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h1>
		<span><i class="iconfont icon-calendar"></i><?php echo gmdate('Y-n-j', $value['date']); ?></span>
		<span><i class="iconfont icon-attention"></i><?php echo $value['views'];?></span>
<?php 
if ($value['views'] >= 800) echo '<span><i class="iconfont icon-hot"></i></span>';
?>
		<p><?php echo $logdes; ?></p>
	</li>
<?php 
endforeach;
else:
?>
	<li class="nothing">你找到的东西已飞宇宙黑洞去了！</li>
<?php endif;?>
</div><!-- end #con-->
			<div class="navigator">
<?php echo pjax_page($lognum,$index_lognum,$page,$pageurl); ?>
			</div>
<?php include View::getView('footer');?>