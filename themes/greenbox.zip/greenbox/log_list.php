<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="contentwrap"> 
<?php doAction('index_loglist_top'); ?>
<div id="content">
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
	<p class="date">作者：<?php blog_author($value['author']); ?> 发布于：<?php echo gmdate('Y-n-j G:i', $value['date']); ?> 
	<?php blog_sort($value['logid']); ?> 
	<?php editflg($value['logid'],$value['author']); ?>
	</p>
<?php echo $value['log_description']; ?>
<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
<div id="pagenavi">
	<?php echo $page_url;?>
</div>
</div>

<?php
 include View::getView('side');
 include View::getView('footer');
?>