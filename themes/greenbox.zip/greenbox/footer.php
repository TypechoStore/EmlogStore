<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div style="clear: both;"></div>
</div><!--end #contentwrap-->
<div id="contentbottom"> </div>
<div id="bottom"> </div>
<div id="footer">
<p>Powered by <a href="http://www.emlog.net" title="采用emlog系统">emlog</a> 
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?><?php doAction('index_footer'); ?></p>
</div>
</div><!--end #wrap-->
<script>prettyPrint();</script>
</body>
</html>