<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<style>
article {border-right: 1px solid #CCCCCC;border-left:1px solid #CCCCCC;border-radius: 5px;background:#FFFFFF;}
</style>
<!--浮动导航开关-->
<?php if(_g('index_dh') == "yes"): ?>
<style>
    article {margin-top: 90px;}
</style>
<?php else: ?>
<?php endif; ?> 
<link href="<?php echo TEMPLATE_URL; ?>index.css" rel="stylesheet" type="text/css" />
<article class="blogs">
	<h1 class="t_nav"><span>您当前的位置：<a href="<?php echo BLOG_URL; ?>">首页</a>&nbsp;>&nbsp;<?php echo $log_title; ?></span><a class="n1" href="<?php echo BLOG_URL; ?>">网站首页</a><a class="n2" href="#">日记</a></h1>
  <br/>
<h2 class="title_tj">
    <p>正文<span>阅读</span></p>
  </h2>
  <div class="index_about">
    <div class="post1">
    <h2 class="c_titile"><?php echo $log_title; ?></h2>
    <p class="box_c"><span class="d_time">发布时间：<?php echo gmdate('Y-n-j G:i l', $date); ?></span><span>编辑：<?php blog_author($author); ?></span></p>
    <ul class="infos">
      <p><?php echo $log_content; ?></p>
<p align="center" class="pageLink"></p>
    </ul>
    <div class="keybq">
    <p><span>关键字词</span>：<?php blog_tag($logid); ?></p>    
    </div>
    <div class="nextinfo">
         <?php neighbor_log($neighborLog); ?>    
    </div>
    <div class="otherlink">
         <?php doAction('log_related', $logData); ?>
    </div>
	</div>
 <!-- Duoshuo Comment BEGIN -->
  <div class="pinglun">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
  </div>
<!-- Duoshuo Comment END -->  
  </div>
  <?php include View::getView('side');?>
</article>
<?php
 include View::getView('footer');
?>