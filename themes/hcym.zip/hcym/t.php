<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<link href="<?php echo TEMPLATE_URL; ?>mood.css" rel="stylesheet" type="text/css" />

<div class="moodlist">
  <h1 class="t_nav"><span>删删写写，回回忆忆，虽无法行云流水，却也可碎言碎语。</span><a class="n1" href="<?php echo BLOG_URL; ?>">网站首页</a><a class="n2" href="<?php echo BLOG_URL; ?>t">碎言碎语</a></h1>
  <div class="bloglist">
   <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?>     
	  
	  
	  
	  <ul class="arrow_box">
     <div class="sy"><p><?php echo $val['t'].'<br/>'.$img;?></p></div>
      <span class="dateview"><?php echo $val['date'];?></span>
    </ul>
  
  
  
  
  
      <?php endforeach;?>

  
  </div>
  <div class="page"><?php echo $pageurl;?></div> 
</div>

<?php
 include View::getView('footer');
?>