<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php if(_g('banner_user') == "no"): ?>
<style>.avatar2 {display: none;}</style>
<?php else: ?>
<?php endif; ?> 
<!--浮动导航开关-->
<?php if(_g('index_dh') == "yes"): ?>
<link  href='<?php echo TEMPLATE_URL; ?>css/list_dh.css' rel='stylesheet' type='text/css' />
<?php else: ?>
<?php endif; ?> 
<!--浮动导航开关 end-->

<!--首页阴影开关-->
<?php if(_g('index_style') == "yes"): ?>
<link  href='<?php echo TEMPLATE_URL; ?>css/index_style_yes.css' rel='stylesheet' type='text/css' />
<?php else: ?>
<link  href='<?php echo TEMPLATE_URL; ?>css/index_style_no.css' rel='stylesheet' type='text/css' />
<?php endif; ?>
<!--首页阴影开关 end-->

<?php
function index_name(){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['name'];?>
	<?php echo $name; ?>
<?php }?>
<link href="<?php echo TEMPLATE_URL; ?>index.css" rel="stylesheet" type="text/css" />
<div class="banner">
  <section class="box">
    <ul class="texts">
      <p>我们不停的翻弄着回忆</p>
      <p>却再也找不回那时的自己</p>
      <p>红尘一梦，不再追寻</p>
    </ul>
	<div class="avatar2"><a href="<?php echo BLOG_URL; ?>"><span><?php index_name(); ?></span></a> </div>
  </section>
</div>

<!--首页随即图开关-->
<?php if(_g('index_ran') == "yes"): ?>
<div class="template">
  <div class="box">
    <h3><p><span>首页</span>随机图文 Picture</p></h3>
    <ul>
<?php thumbs_by_sort(); ?></ul>
  </div>
</div>
<?php else: ?>
<link  href='<?php echo TEMPLATE_URL; ?>css/index_ran_no.css' rel='stylesheet' type='text/css' />
<div class="template">
<div class="border" id="thenotice">
<ul>
<li>
<p class="tw">公告：<a href="<?php echo BLOG_URL; ?>t"><?php index_t(1); ?></a></p>
</li>
</ul>
</div>
</div>
<?php endif; ?>
<!--首页随即图开关 end-->

<article>
  <?php doAction('index_loglist_top'); ?>
  <h2 class="title_tj">
    <p>文章<span>推荐</span></p>
  </h2>
  <div class="bloglist left">
       <?php if (!empty($logs)):foreach($logs as $value): ?>
       <div class="post">
	        <?php if(_g('index_style') == "yes"): ?>
	        <h3 style="margin-left:5px;"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h3>
            <?php else: ?>
            <h3><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h3>
            <?php endif; ?>
            <figure>
			        <?php
                     //拉取附件第一张图片，如果没有，则随机拉取random文件夹图片，图片名称任意
                     $thum_src = getThumbnail($value['logid']);
                     $imgFileArray = TEMPLATE_URL.'images/random/'.rand(1,12).'.jpg';
                     if(!empty($thum_src)){ ?>
                        <img src="<?php echo $thum_src; ?>" alt="<?php echo $value['log_title']; ?>" title="<?php echo $value['log_title'] ?>" />
                        <?php
                    }else{
                         ?>
                        <img src="<?php echo $imgFileArray; ?>" alt="<?php echo $value['log_title']; ?>" title="<?php echo $value['log_title'] ?>" />
                      <?php
                      }
                          ?>			
             </figure>
            <ul>
                <p><?php echo subString(strip_tags($value['log_description']),0,170,"..."); ?></p>
                 <a class="readmore" href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>">阅读全文>></a>
            </ul>
            <p class="dateview">
			   <span><?php echo gmdate('Y-n-j', $value['date']); ?></span>
			   <span>编辑：<?php blog_author($value['author']); ?></span>
			   <span>分类：[<?php blog_sort($value['logid']); ?>]</span>
			</p>    
       </div>
		  <?php endforeach;else:?>
	   <h2>未找到</h2>
	   <p>抱歉，没有符合您查询条件的结果。</p>
       <?php endif;?>   
       <div class="page">
		    <?php echo $page_url;?>
	   </div>
  </div>
  <?php include View::getView('side');?>
</article>
<?php
 include View::getView('footer');
?>