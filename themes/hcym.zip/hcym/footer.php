<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="footer">
	<div class="foot">
	        <span class="left1">
			       Powered By <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank"><?php echo Option::EMLOG_VERSION;?></a>
		  </span>
	        <span class="right1">
			       <li>Emlog Theme By <a href="http://blog.chenziwen.com" target="_blank">陈子文</a>.Designed By <a href="#" target="_blank">杨青</a></li>
				   <li>CopyRight 2013 - 2014 <?php echo $blogname;?> All Right Served</li>
				   <?php echo $footer_info; ?>
	                      <?php doAction('index_footer'); ?>
		    </span>
	</div>
</div>
</body>
</html>