<?php

/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
//首页logo设置
'index_logo' => array(
     'type' => 'image',
	'name' => '首页 → LOGO设置',
	'values' => array(
	TEMPLATE_URL . 'images/logo.jpg',
	),
	'default' => ''.TEMPLATE_URL.'images/logo.jpg',
),
//首页logo设置

//首页随机图文
	'index_ran' => array(
		'type' => 'radio',
		'name' => '首页随机图文 → 是否开启',
		'values' => array(
            'yes' => '开启随机图文显示',
            'no' => '开启微语显示方案'
        ),
		'default' => 'yes',
	),
//首页随机图文

//首页盒子阴影模式
	'index_style' => array(
		'type' => 'radio',
		'name' => '首页阴影 → 是否开启',
		'values' => array(
            'yes' => '开启',
            'no' => '关闭'
        ),
		'default' => 'yes',
	),
//首页盒子阴影模式

//侧边栏天气预报
	'side_tianqi' => array(
		'type' => 'radio',
		'name' => '侧边栏天气预报 → 是否开启',
		'values' => array(
            'yes' => '开启天气预报',
            'no' => '关闭天气预报'
        ),
		'default' => 'yes',
	),
//侧边栏天气预报

//侧边栏天气预报图片是否开启
	'side_tianqi_img_kq' => array(
		'type' => 'radio',
		'name' => '侧边栏图片是否开启',
		'values' => array(
            'yes' => '开启侧边栏图片',
            'no' => '关闭侧边栏图片'
        ),
		'default' => 'no',
	),
//侧边栏天气预报图片是否开启

//侧边栏天气预报图片
'side_tianqi_img' => array(
     'type' => 'image',
	'name' => '侧边栏天气预报图片 备注：图片仅支持jpg格式',
	'values' => array(
	BLOG_URL . 'content/uploadfile/tpl_options/side_tianqi_img.jpg',
	),
	'default' => ''.BLOG_URL.'content/uploadfile/tpl_options/side_tianqi_img.jpg',
),
//侧边栏天气预报图片

//分享按钮
	'fenxiang' => array(
		'type' => 'radio',
		'name' => '分享按钮展示方案',
		'values' => array(
            'yes' => '开启浏览器左侧分享按钮',
            'no' => '开启侧边栏底部分享按钮'
        ),
		'default' => 'no',
),
//分享按钮

//qq评论
	'qqpinglun' => array(
		'type' => 'radio',
		'name' => '是否开启QQ一键评论 → 是否开启',
		'values' => array(
            'yes' => '开启',
            'no' => '关闭'
        ),
		'default' => 'yes',
	),
//qq评论

//侧边栏CD设置开始
	'side_cd' => array(
		'type' => 'radio',
		'name' => '是否开启侧边栏CD',
		'values' => array(
            'yes' => '开启',
            'no' => '关闭'
        ),
		'default' => 'yes',
	),

	'foot_li1' => array(
		'type' => 'text',
		'name' => '侧边栏CD → 歌曲名',
		'default' => '我相信',
	),
	'foot_li2' => array(
		'type' => 'text',
		'name' => '侧边栏CD → 歌手',
		'default' => '杨培安',
	),
	'foot_li3' => array(
		'type' => 'text',
		'name' => '侧边栏CD → 专辑',
		'default' => '青春励志曲',
	),
	'foot_li4' => array(
		'type' => 'text',
		'name' => '侧边栏CD → 歌曲地址',
		'default' => 'http://www.chenziwen.com/content/templates/Hsesjz/images/wxx.mp3',
	),

//侧边栏cd设置结束

//自动播放设置
	'cd_zidong' => array(
		'type' => 'radio',
		'name' => '侧边栏CD → 自动循环播放',
		'values' => array(
            'yes' => '开启',
            'no' => '关闭'
        ),
		'default' => 'no',
	),
//自动播放设置

//首页浮动导航
	'index_dh' => array(
		'type' => 'radio',
		'name' => '首页浮动导航 → 是否开启',
		'values' => array(
            'yes' => '开启',
            'no' => '关闭'
        ),
		'default' => 'no',
	),
//首页浮动导航

//banner头像
	'banner_user' => array(
		'type' => 'radio',
		'name' => 'banner左侧头像 → 是否开启',
		'values' => array(
            'yes' => '开启',
            'no' => '关闭'
        ),
		'default' => 'yes',
	),
//banner头像



);
