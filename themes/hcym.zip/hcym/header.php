<?php
/*
Template Name:红尘一梦
Description:
    我们不停的翻弄着回忆
    却再也找不回那时的自己
    红尘一梦，不再追寻
Version:6.0
Author:移植：陈子文
Author Url:http://vps.lantk.com/?post=88
Sidebar Amount:1
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=10;IE=EDGE">
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>base.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>new.css" rel="stylesheet" type="text/css" />
<link  href='<?php echo TEMPLATE_URL; ?>viewthread.css' rel='stylesheet' type='text/css' />
<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<!--[if lt IE 9]>
<script src="<?php echo TEMPLATE_URL; ?>modernizr.js"></script>
<![endif]-->
<link href="http://bdimg.share.baidu.com/static/css/bdsstyle.css?cdnversion=20131219" rel="stylesheet" type="text/css">
</head>
<body>
<iframe frameborder="0" style="display: none;"></iframe>
<header>
<div class="dh">
      <div id="logo">
            <a href="<?php echo BLOG_URL; ?>"><img alt="<?php echo $blogname; ?>" title="<?php echo $blogname; ?>" src="<?php echo _g('index_logo'); ?>"></a>
      </div>
      <nav id="topnav" class="topnav">
             <?php blog_navi();?>  
      </nav>
</div>
</header>
<!--浮动导航开关-->
<?php if(_g('index_dh') == "yes"): ?>
<link  href='<?php echo TEMPLATE_URL; ?>css/index_dh.css' rel='stylesheet' type='text/css' />
<?php else: ?>
<?php endif; ?>
<!--浮动导航开关 end-->