<?php 
/**
 * 侧边栏
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<aside class="right">
<?php if(_g('side_cd') == "yes"): ?>
<div id="side" class="viny">
        <dl>
          <dt class="art"><img alt="专辑" src="<?php echo TEMPLATE_URL; ?>images/artwork.png"></dt>
          <dd class="icon-song"><span></span><?php echo _g('foot_li1'); ?></dd>
          <dd class="icon-artist"><span></span><?php echo _g('foot_li2'); ?></dd>
          <dd class="icon-album"><span></span><?php echo _g('foot_li3'); ?></dd>
          <dd class="icon-like"><span></span><a target="_blank" href="<?php echo _g('foot_li4'); ?>">歌曲下载</a></dd>
          <dd class="music">
            <?php if(_g('cd_zidong') == "yes"): ?>
			<audio autoplay="" loop="" controls="" src="<?php echo _g('foot_li4'); ?>"></audio>
			<?php else: ?>
			<audio controls="" src="<?php echo _g('foot_li4'); ?>"></audio>
            <?php endif; ?>      
		  </dd>
        </dl>
      </div>
<?php else: ?>
<?php endif; ?>
<?php if(_g('side_tianqi') == "yes"): ?>
    <div class="weather">
		<iframe width="225" scrolling="no" height="86" frameborder="0" name="weather_inc" src="http://tianqi.xixik.com/cframe/7" marginwidth="0" marginheight="0"></iframe>
	</div>
<style>
.weather {
    background: url("content/templates/hcym/images/weather.jpg") no-repeat scroll;
    height: 88px;
    margin: 20px 0;
}
</style>
<?php else: ?>
<?php endif; ?>
<?php if(_g('side_tianqi_img_kq') == "yes"): ?>
<div class="weather"></div>
<style>
.weather {
    background: url("content/uploadfile/tpl_options/side_tianqi_img.jpg") no-repeat scroll;
    height: 88px;
    margin: 20px 0;
	width: 245px;
}
</style>
<?php else: ?>
<?php endif; ?>

<div class="news">
<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>
<?php if(_g('fenxiang') == "yes"): ?>
<a class="bshareDiv" href="http://www.bshare.cn/share">分享按钮</a><script type="text/javascript" charset="utf-8" src="http://static.bshare.cn/b/buttonLite.js#uuid=&amp;style=3&amp;fs=4&amp;textcolor=#fff&amp;bgcolor=#F60&amp;text=分享到"></script>              
<?php else: ?>
<div class="bshare-custom icon-medium"><a title="分享到QQ空间" class="bshare-qzone"></a><a title="分享到新浪微博" class="bshare-sinaminiblog"></a><a title="分享到人人网" class="bshare-renren"></a><a title="分享到腾讯微博" class="bshare-qqmb"></a><a title="分享到网易微博" class="bshare-neteasemb"></a><a title="更多平台" class="bshare-more bshare-more-icon more-style-addthis"></a><span class="BSHARE_COUNT bshare-share-count">0</span></div><script type="text/javascript" charset="utf-8" src="http://static.bshare.cn/b/buttonLite.js#style=-1&amp;uuid=&amp;pophcol=2&amp;lang=zh"></script><script type="text/javascript" charset="utf-8" src="http://static.bshare.cn/b/bshareC0.js"></script>
<?php endif; ?>
</div>
</aside>
