<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<?php $lk = bottom_link($title); if(!empty($lk)){echo $lk;}?>
<div class="footer"><!--底部框架开始-->
<div class="footer_left">
Copyright&copy;<<a href="<?php echo $blogurl;?>"><?php echo $blogname; ?></a>>. 
博客程序<<a href="http://www.emlog.net/" rel="external" target="_blank">EMLOG</a>>. 
<?php if(!empty($icp)){echo '备案信息<<a href="http://www.miibeian.gov.cn" target="_blank">'.$icp.'</a>.>';};?>
主题制作<<a href="http://lxperson.com" target="_blank">荔溪人士</a>>.
</div>
<div class="footer_right">
<?php if(!empty($footer_info)){echo '<div class="footer_info">'.$footer_info.'</div>';}?>
</div>
<div class="c"></div>
<?php doAction('index_footer'); ?>
</div><!--底部框架结束-->
<span id="ttop">&nbsp;</span>
</div><!--总体框架结束-->
</body>
</html>