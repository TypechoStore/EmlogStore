<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div class="text">
<div class="text_title"><?php topflg($top); ?><?php echo $log_title; ?></div>
<div class="text_date">
<span><?php $weekarray=array("日","一","二","三","四","五","六");echo gmdate('Y年n月j日 G:i', $date);
echo " 星期".$weekarray[gmdate('w', $date)];?></span>
<?php blog_sort($logid); ?>
<span><?php editflg($logid,$author); ?></span>
<div class="text_info"><?php echo $log_content; ?></div>
<?php blog_tag2($logid); ?>
<?php doAction('log_related', $logData); ?>
<?php neighbor_log($neighborLog); ?>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<div class="c"></div>
</div>
<?php include View::getView('footer');?>