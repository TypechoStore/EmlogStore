<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div class="page">
<div class="page_title"><?php echo $log_title; ?></div>
<div class="page_info"><?php echo $log_content; ?></div>
<div class="page_comment">
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<div class="c"></div>
</div>
<?php include View::getView('footer');?>