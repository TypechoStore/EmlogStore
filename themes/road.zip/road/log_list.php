<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div class="content">
<?php doAction('index_loglist_top'); ?>
<?php if(!empty($logs)): foreach($logs as $value): ?>
<div class="content_info">
<div class="content_title">
<div class="content_title_l"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></div>
<div class="content_title_r"><?php editflg($value['logid'],$value['author']); ?></div>
<div class="c"></div>
</div>
<div class="content_date">
<span><?php $weekarray=array("日","一","二","三","四","五","六");echo gmdate('Y年n月j日 G:i', $value['date']);
echo " 星期".$weekarray[gmdate('w', $value['date'])];?></span>
<?php blog_sort($value['logid']); ?>
<span>评论(<a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?></a>)</span>
<span>浏览(<a href="<?php echo $value['log_url']; ?>"><?php echo $value['views']; ?></a>)</span>
</div>
<div class="c"></div>
<div class="content_text"><?php echo strip_tags(subString($value['log_description'],0,400),"</a>"); ?></div>
<?php echo blog_tag($value['logid'])?>
</div>
<?php endforeach; else: ?>
<h2>未找到</h2>
<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
<?php if(!empty($page_url)){echo '<div class="page_nav">'.$page_url.'</div>';}?>
</div>
<?php include View::getView('footer');?>