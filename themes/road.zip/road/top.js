$(document).ready(function(){
 $("#ttop").hide();
$(function () {
$(window).scroll(function(){
if ($(window).scrollTop()>100){
$("#ttop").fadeIn(1500);
}
else
{
$("#ttop").fadeOut(1500);
}
});
$("#ttop").click(function(){
$('body,html').animate({scrollTop:0},1000);
return false;
});
});
});