<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content" class="content">
				<div class="announce" style="display: none">
					<div class="announce-top"></div>
					<div class="announce-content" style="display: none"> </div>
					<div class="announce-bottom"></div>
				</div>
				<div id="content-top"></div>
				<div id="innerContent">
					<div class="textbox-top"></div>
					<div class="textbox">
						<div class="article-top">
							<?php neighbor_log($neighborLog); ?>
						</div>
						<div class="textbox-title">
							<h4> <?php echo $log_title; ?></h4>
							<div class="textbox-label"> <?php blog_author($author); ?> post in <?php  blog_sort($logid); ?> <?php echo gmdate('Y-n-j G:i l', $date); ?> <?php editflg($logid,$author); ?></div>
						</div>
						<div class="textbox-content" id="zoomtext"><?php echo $log_content; ?></div>
						<div class="fujian"><?php blog_att($logid); ?></div>
						<div class="tags" style="display: block"> Tags: <?php blog_tag($logid); ?></div>
						<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
						<?php doAction('log_related', $logData); ?>
					</div>
					<div class="textbox-bottom"></div>
					<?php blog_comments($comments); ?>
					<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
</div>
<!--end content-->
<?php 
 include View::getView('side');
 include View::getView('footer');
?>