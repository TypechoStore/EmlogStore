<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php doAction('index_loglist_top'); ?>
		<div id="content" class="content">
			<div id="content-top"></div>
			<div id="innerContent">
				<?php foreach($logs as $value): ?>
				<div class="textbox-top"> </div>
				<div class="textbox">
					<div class="textbox-title">
						<h4> <?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h4>
						<div class="textbox-label"> <?php blog_author($value['author']); ?> post in <?php blog_sort($value['sortid'], $value['logid']); ?> <?php echo gmdate('Y-n-j G:i l', $value['date']); ?> <a href="<?php echo BLOG_URL; ?>?post=<?php echo $value['logid']; ?>#comment">评论(<?php echo $value['comnum']; ?>)</a>
							<a href="<?php echo BLOG_URL; ?>?post=<?php echo $value['logid']; ?>">浏览(<?php echo $value['views']; ?>)</a><?php editflg($value['logid'],$value['author']); ?>
						</div>
					</div>
					<div class="textbox-content"><?php echo $value['log_description']; ?></div>
					<div class="tags"><?php blog_tag($value['logid']); ?></div>
				</div>
				<div class="textbox-bottom"></div>
				<?php endforeach; ?>
				<div class="article-bottom" style="display: block">
					<div class="pages"> <span class="pagebar-mainbody"><?php echo $page_url;?></span></div>
				</div>
			</div>
			<div id="content-bottom"></div>
		</div>

<!--end content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>