<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content" class="content">
<div class="announce" style="display: none">
					<div class="announce-top"></div>
					<div class="announce-content" style="display: none"> </div>
					<div class="announce-bottom"></div>
				</div>
				<div id="content-top"></div>
				<div class="textbox-top"></div>
					<div class="textbox">
						<div class="textbox-title">
							<h4> <?php echo $log_title; ?></h4>
						</div>
						<div class="textbox-content" id="zoomtext"><?php echo $log_content; ?></div>
					</div>
					<div class="textbox-bottom"></div>
					<?php blog_comments($comments); ?>
					<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>



<!--end content-->
<?php 
 include View::getView('side');
 include View::getView('footer');
?>