<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
		</div>
	</div>
	<div style="clear:both;"></div>
	<div id="footer">
		<div id="innerFooter">
			<div id="Copyrightinfo"> Copyright &copy; 2009 - 2010 <?php echo $blogname; ?>  Designed By <a href="http://www.blogbus.com" target="_blank">blogbus</a>.  Theme By <a href="http://www.cooron.net" target="_blank">Kuma</a> <br/>
				Powered by <a href="http://www.emlog.net" title="emlog<?php echo Option::EMLOG_VERSION;?>">emlog</a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a><?php echo $footer_info; ?><?php doAction('index_footer'); ?>
				<div id="processtime"> </div>
			</div>
		</div>
	</div>
</div>
</body>
</html>