<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="main">
		<div id="content">
			<div class="iner">
				<div class="postlog">
					<?php doAction('index_loglist_top'); ?>
					<?php foreach($logs as $value): ?>
						<div class="logtitle"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></div>
						<div class="log">
						<?php echo $value['log_description']; ?>
						<p class="att"><?php blog_att($value['logid']); ?></p>
						<p class="tag" style=" margin-top:10px;"><?php blog_tag($value['logid']); ?></p>
						</div>
						<div class="logfoot">
						<a href="<?php echo $value['log_url']; ?>">Read More</a>
						<?php echo gmdate('Y-n-j', $value['date']); ?> |
						<?php blog_sort($value['logid']); ?> |					
						<a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?> Comments</a> |
						<a href="<?php echo $value['log_url']; ?>"><?php echo $value['views']; ?> View</a>
						<?php editflg($value['logid'],$value['author']); ?>
						</div>
						<div style="clear:both;"></div>
					<?php endforeach; ?>
					
					<div id="pagenavi">
						<?php echo $page_url;?>
					</div>
				</div>
			</div>
		</div>
<?php include("t.php"); ?>

	</div>
<?php
 include View::getView('footer');
?>