<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="foot">
<div class="footc">
Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> 
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> Theme By <a href="http://www.520dawn.com">Dawn</a><?php echo $footer_info; ?>
<?php doAction('index_footer'); ?>
<!-- 导航滑动 -->
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/js/jquery.cookie.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.scroll-follow.js"></script>
<script type="text/javascript">
$(function(){
	$("#nav").scrollFollow({
		offset: 110
	});

});
</script>
<!-- 导航滑动结束 -->


</div>
</div><!--end #foot-->
</div><!--end #pm11-->
</body>
</html>