<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="main">
		<div id="content">
			<div class="iner">
				<div class="postlog">

						<div class="logtitle"><a href="<?php echo $value['log_url']; ?>"><?php topflg($top); ?><?php echo $log_title; ?></a></div>
						<div class="log">
						<?php echo $log_content; ?>
						<p class="att"><?php blog_att($logid); ?></p>
						<p class="tag" style="margin-top:10px;"><?php blog_tag($logid); ?></p>
						<?php doAction('log_related', $logData); ?>
						</div>
						<div class="logfoot">
						<?php echo gmdate('Y-n-j', $date); ?> |
						<?php blog_sort($logid); ?>|					
						<a href="<?php echo $value['log_url']; ?>#comments"><?php echo $comnum; ?> Comments</a> |
						<a href="<?php echo $value['log_url']; ?>"><?php echo $views; ?> View</a>
						<?php editflg($logid,$author); ?>
						</div>
						<div class="nextlog"><?php neighbor_log($neighborLog); ?></div><br />
						<?php blog_comments($comments); ?>
						<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
						<div style="width:550px; height:30px; float:left;"></div>
						<div style="clear:both;"></div>

				</div>
			</div>
		</div>
<?php include("t.php"); ?>

	</div>
<?php
 include View::getView('footer');
?>