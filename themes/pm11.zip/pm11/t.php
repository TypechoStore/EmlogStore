<div id="nav">
			<div class="nav1"></div>
			<div class="nav2">
			<ul>
				<li class="<?php echo $curpage == CURPAGE_HOME ? 'current' : 'common';?>"><a href="<?php echo BLOG_URL; ?>">首页</a></li>
				<?php 
				global $CACHE; 
				$navi_cache = $CACHE->readCache('navi');
				foreach ($navi_cache as $key => $val):
				if ($val['hide'] == 'y'){continue;}
				if (empty($val['url'])){$val['url'] = Url::log($key);}
				$newtab = $val['newtab'] == 'y' ? 'target="_blank"' : '';
				$val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
				?>
				<li class="<?php echo isset($logid) && $key == $logid ? 'current' : 'common';?>"><a href="<?php echo $val['url']; ?>" <?php echo $newtab; ?>><?php echo $val['naviname']; ?></a></li>
				<?php endforeach;?>
				<?php doAction('navbar', '<li class="common">', '</li>'); ?>
				<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
				<li class="common"><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
				<li class="common"><a href="<?php echo BLOG_URL; ?>admin/">管理中心</a></li>
				<li class="common"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
				<?php else: ?>
				<li class="common"><a href="<?php echo BLOG_URL; ?>admin/">登录</a></li>
				<?php endif; ?>
			</ul>
			</div>
			<div class="nav3"></div>
</div>