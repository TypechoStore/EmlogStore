<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="main">
		<div id="content">
			<div class="iner">
				<div class="postlog">
						<div class="log" style="margin-top:20px;">
						<?php echo $log_content; ?>
						<p class="att"><?php blog_att($logid); ?></p>
						<p class="tag"><?php blog_tag($logid); ?></p>
						<?php doAction('log_related', $logData); ?>
						</div>

						<?php blog_comments($comments); ?>
						<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
						<div style="width:550px; height:30px; float:left;"></div>
						<div style="clear:both;"></div>

				</div>
			</div>
		</div>
		<?php include("t.php"); ?>

	</div>
<?php
 include View::getView('footer');
?>