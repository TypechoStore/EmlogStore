﻿<?php
require_once '../../../init.php';
if(ROLE != 'visitor'){
$cid1=$_GET['cid'];
$sql="DELETE FROM `emlog_comment` WHERE `cid` = '$cid1'";
$query=mysql_query($sql);
echo "<script>window.location.href=document.referrer;</script>";
}
else
{
echo "您不是管理员！";
}
?>
