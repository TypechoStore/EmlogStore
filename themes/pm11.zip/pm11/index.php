<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>pm11</title>
<link href="http://127.0.0.1/demo/reset.css" rel="stylesheet" type="text/css" />
<link href="http://127.0.0.1/demo/pm11.css" rel="stylesheet" type="text/css" />

<!-- 导航滑动 -->
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript" src="http://127.0.0.1/demo/js/jquery.cookie.js"></script>
<script type="text/javascript" src="http://127.0.0.1/demo/js/jquery.scroll-follow.js"></script>
<script type="text/javascript">
$(function(){
	$("#nav").scrollFollow({
		offset: 110
	});

});
</script>
<!-- 导航滑动结束 -->
</head>
<body>
<div id="pm11">
	<div id="top">
		<div class="name">
			<div class="blogname"><a href="#">点滴记忆</a></div>
		</div>
			<div class="description">这不只是一只小白熊的故事</div>
	</div>
	
	<div id="main">
		<div id="content">
			<div class="iner"></div>
		</div>
		<div id="nav"></div>

	</div>
	<div id="foot">
		<div class="footc">111<a href="#">222</a></div>
	</div>
	
</div>

</body>
</html>