<?php 
/**
 * 文章列表
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<body class="home-template nav-closed">
<div class="site-wrapper">
<a class="FixedTop ja_button" href="#menu">
<span></span>
</a>
    	<header class="main-header post-head zllz bounceInDown  animated" style="background-image: url(<?php echo TEMPLATE_URL; ?>img/header.jpg); visibility: visible; animation-name: bounceInDown;">
<div class="post-info-container">
         <h2 class="post-page-title "><?php echo $log_title; ?></h2>
            <time class="post-page-time"><?php echo gmdate('Y年n月j日 G:i l', $date); ?></time>
            <span class="post-page-tags"><?php blog_sort($logid); ?></span>
	</div>
</header>
	<main role="main" class="content">
<article class="post tag-record">
    <section class="post-content zllz bounceInRight animated" style="visibility: visible; animation-name: bounceInRight;">
    <?php echo $log_content; ?>
	</section>
 <?php doAction('log_related', $logData); ?>  
<footer class="post-footer zllz bounceInRight animated" style="visibility: visible; animation-name: bounceInRight;">
            <figure class="author-image">
			<img src="<?php echo TEMPLATE_URL; ?>img/author.jpg"  alt="" />
            </figure>
            <section class="author">
                <h2><?php blog_author($author); ?></h2>
				<div class="author-meta">
                    <span class="author-location icon-location">China </span>
                    <span class="author-link icon-link"><a href="<?php echo BLOG_URL;?>"><?php echo BLOG_URL;?></a></span>
                </div>
                    <p>﻿一个热爱网络的90后</p>
            </section>
    
            <section class="share">
    <div class="ds-share" data-thread-key="<?php echo $logid;?>" data-title="<?php echo $log_title; ?>" data-url="<?php echo Url::log($logid);?>">
    <a class="ds-share icon-wei" target="_blank" href="javascript:void(0);" data-service="weibo"></a>
<a class="ds-share icon-xin" href="javascript:void(0);" data-service="wechat"></a>
<a class="ds-share icon-qzone" href="javascript:void(0);" data-service="qzone"></a>
	<a class="ds-share icon-twitter" href="javascript:void(0);" data-service="twitter"></a>
    
    	</section>
</footer>
<div class="zllz bounceInLeft">
	<!-- 多说评论框 start -->
	<div class="ds-thread" data-thread-key="<?php echo $logid;?>" data-title="<?php echo $log_title; ?>" data-url="<?php echo Url::log($logid);?>">
</div>
<!-- 多说评论框 end -->	</div>
    </article>
</main>			
<?php
 include View::getView('footer');
?>
			<nav id="menu">
				<ul>
					    <?php blog_navi();?>
				</ul>
			</nav>