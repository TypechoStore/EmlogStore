(function($, undefined) {
    var $document = $(document);
    $document.ready(function() {
        var $postContent = $("");
        $postContent.fitVids();
        $("").on("click",
        function(e) {
            e.preventDefault();
            $("").toggleClass("")
        })
    });
    $.fn.arctic_scroll = function(options) {
        var defaults = {
            elem: $(this),
            speed: 700
        },
        allOptions = $.extend(defaults, options);
        allOptions.elem.click(function(event) {
            event.preventDefault();
            var $this = $(this),
            $htmlBody = $("html, body"),
            offset = ($this.attr("data-offset")) ? $this.attr("data-offset") : false,
            position = ($this.attr("data-position")) ? $this.attr("data-position") : false,
            toMove;
            if (offset) {
                toMove = parseInt(offset);
                $htmlBody.stop(true, false).animate({
                    scrollTop: ($(this.hash).offset().top + toMove)
                },
                allOptions.speed)
            } else {
                if (position) {
                    toMove = parseInt(position);
                    $htmlBody.stop(true, false).animate({
                        scrollTop: toMove
                    },
                    allOptions.speed)
                } else {
                    $htmlBody.stop(true, false).animate({
                        scrollTop: ($(this.hash).offset().top)
                    },
                    allOptions.speed)
                }
            }
        })
    }
})(jQuery);
if ($(window).width() > 768) {
    $(document).ready(function() {
        NProgress.start()
    });
    $(window).load(function() {
        NProgress.done()
    })
}
$(function() {
    showScroll();
    function showScroll() {
        $(window).scroll(function() {
            var scrollValue = $(window).scrollTop();
            scrollValue > 500 ? $("div[class=scroll]").fadeIn() : $("div[class=scroll]").fadeOut()
        });
        $("#scroll").click(function() {
            $("html,body").animate({
                scrollTop: 0
            },
            500)
        })
    }
});