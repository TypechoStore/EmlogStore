<?php 
/**
 * 文章列表
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
if($pageurl == Url::logPage()){
	include View::getView('index');
	exit;
}
?>
<body class="home-template nav-closed">
<div class="site-wrapper">
<a class="FixedTop ja_button" href="#menu">
<span></span>
</a>

<header class="main-header post-head zllz bounceInDown animated" style="background-image: url(<?php echo TEMPLATE_URL; ?>img/header.jpg); visibility: visible; animation-name: bounceInDown;">
<div class="vertical">
        <div class="main-header-content inner">
            <h1 class="page-title"><?php if ($params[1]=='sort'){ ?>
		<?php echo $sortName;?>
<?php }else{?><?php }?></h1>
            <h2 class="page-description"><分类下的所有文章></h2>
        </div>
    </div>
</header>
	<main id="content" class="content" role="main">
<?php doAction('index_loglist_top'); ?>
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
<article class="post tag-sheng-huo zllz bounceInUp animated">
<header class="post-header">
<a href="<?php echo $value['log_url']; ?>">
<?php
//获取缩略图
preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
if (!empty($img[1])) {
    $thum_src = $img[1][0]; //正文第一张图片
}else{
    $rand_num = 0; //随机图片数量，按实际数量设置
    if ($rand_num == 0) {
        $thum_src = TEMPLATE_URL."img/nopic.png";
        //默认图片，须命名为"0.jpg"
    }else{
        $thum_src = TEMPLATE_URL."img/g/".rand(1,$rand_num).".jpg";
        //随机图片，须按"1.jpg","2.jpg","3.jpg"...的顺序命名
    }
    //上述默认图片(0.jpg)与随机图片(random目录)须保存在模板目录中的"thumbnail"目录下
 }
?>
<a class="hidden-xs thumbLink" title="" href="<?php echo $value['log_url']; ?>" data-original-title="
	<?php echo $value['title'] = subString(strip_tags($value['title']),0,50); ?>">
<img class="post-image" alt="<?php echo $value['log_title']; ?>" src="<?php echo $thum_src; ?>">
</a>
<h2 class="post-title">
<a href="<?php echo $value['log_url']; ?>" target="_blank"><?php echo $value['title'] = subString(strip_tags($value['title']),0,11); ?></a>
</h2>
</header>
<section class="post-excerpt">
<p>
<?php echo $logdes = blog_tool_purecontent($value['content'], 30); ?><a class="read-more" href="<?php echo $value['log_url']; ?>">&raquo;</a>
</p>
</section>
<footer class="post-meta">
<?php blog_sort($value['logid']); ?> 
<time class="post-date" datetime="<?php echo gmdate('Y-n-j', $value['date']); ?> "><?php echo sldate($value['date']);?></time>
<span class="ds-thread-count icon-chat" data-count-type="comments" "><span class="ds-thread-count" data-thread-key="<?php echo $logid;?>"></span>
</footer>
</article>	
<?php 
endforeach;
else:
?>
<main id="content" class="content" role="main">
<article class="post tag-sheng-huo zllz bounceInUp animated" style="visibility: visible; animation-name: bounceInUp;">
<header class="post-header">
<h2 class="post-title">
未找到
</h2>
<p>抱歉，没有符合您查询条件的结果。</p>
	</main>
<?php endif;?>
<nav class="pagination" role="navigation">
<h2 class="post-title">	<?php echo $page_url;?></h2>
</nav>
</main>

<nav class="pagination" role="navigation">
	<div style="text-align:center;">
	<span style="line-height:1.5;font-size:16px;">Links</span>
</div>
<footer class="site-footer clearfix">
<div class ="links">
<?php widget_link(); ?>
</footer>	
</nav>
<?php
 include View::getView('footer');
?>
			<nav id="menu">
				<ul>
					    <?php blog_navi();?>
				</ul>
			</nav>
		</div>
		</div>
