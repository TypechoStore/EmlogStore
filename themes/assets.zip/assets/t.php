<?php 

/**

 * 微语部分

 */

if(!defined('EMLOG_ROOT')) {exit('error!');} 

?>
<body class="home-template nav-closed">
<div class="site-wrapper">
<a class="FixedTop ja_button" href="#menu">
<span></span>
</a>
<header class="main-header zllz bounceInDown  animated" style="background-image: url(<?php echo TEMPLATE_URL; ?>img/header.jpg); visibility: visible; animation-name: bounceInDown;">
    <nav class="main-nav overlay clearfix">
<a class="menu-button" href="#"><span class="burger"><i class="fa fa-list-ul"></i></span>
<span class="word"></span>
	</a>
    </nav>
    <div class="vertical">
        <div class="main-header-content inner">
            <h1 class="page-title">微语</h1>
            <h2 class="page-description">使用微语记录您身边的新鲜事</h2>
        </div>
    </div>
</header>
<article class="post tag zllz bounceInUp">

        <header class="post-header">

    <?php 

    foreach($tws as $val):

    $author = $user_cache[$val['author']]['name'];

    $avatar = empty($user_cache[$val['author']]['avatar']) ? 

                BLOG_URL . 'admin/views/images/avatar.jpg' : 

                BLOG_URL . $user_cache[$val['author']]['avatar'];

    $tid = (int)$val['id'];

    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';

    ?> 

<div class="dsavatar"><img src="<?php echo $avatar; ?>" /></div><h3 style="text-align:center;"><?php echo $author; ?>说</h3>

<h2 class="post-title"><?php echo $val['t'].$img;?></h2>

    </header><div class="clear"></div>

        <p class="time"><?php echo $val['date'];?> </p>

	<div class="clear"></div>

   	<ul id="r_<?php echo $tid;?>" class="r"></ul>

    <?php if ($istreply == 'y'):?>

</article>

    <?php endif;?>

    <?php endforeach;?>

<nav class="pagination" role="navigation"><h2 class="post-title"><?php echo $pageurl;?></h2></nav>

<?php

 include View::getView('footer');

?>
			<nav id="menu">
				<ul>
					    <?php blog_navi();?>
				</ul>
			</nav>
		</div>
		</div>