<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<body class="home-template nav-closed">
    <div class="site-wrapper">
   <a class="FixedTop ja_button" href="#menu">
<span></span>
</a>
    	<header class="main-header post-head zllz bounceInDown  animated" style="background-image: url(<?php echo TEMPLATE_URL; ?>img/header.jpg); visibility: visible; animation-name: bounceInDown;">
<nav class="main-nav overlay clearfix">
<a class="menu-button" href="#">
<span class="burger"><i class="fa fa-list-ul"></i></span>
<span class="word"></span>
</a>
</nav>
<div class="vertical">
<div class="main-header-content inner">
<h1 class="page-title"><?php echo $log_title; ?></h1>
</div>
</div>
</header>
<main role="main" class="content">
    <article class="post tag">
	<?php echo $log_content; ?>
	<section class="post-content zllz bounceInRight animated" style="visibility: visible; animation-name: bounceInRight;">
        </section>
    </article>
</main>			
<?php
 include View::getView('footer');
?>
			<nav id="menu">
				<ul>
					    <?php blog_navi();?>
				</ul>
			</nav>
		</div>
		</div>