<?php
/*
Template Name:灵动模板加强版
Description:响应式模板，简洁优雅
Version:1.1
Author:思源给力强化
Author Url:http://www.isiyuan.net/?post=85
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title><?php echo $site_title; ?></title>
   <meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
    <meta name="HandheldFriendly" content="True" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link href="<?php echo TEMPLATE_URL; ?>font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>css/zllz.min.css?v=c997bca825" />
	<link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>css/normalize.css?v=c997bca825" />
	<script type="text/javascript" src="http://libs.baidu.com/jquery/2.0.0/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.fitvids.js?v=c997bca825"></script>
    <script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/index.js?v=c997bca825"></script>
		  <link type="text/css" rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/menu.css" />
		<link type="text/css" rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/jquery.mmenu.all.css" />

	<script src="http://libs.baidu.com/jquery/1.7.2/jquery.min.js"></script>
		<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.mmenu.min.all.js"></script>
		<script type="text/javascript">
			$(function() {
				$('nav#menu').mmenu({
					extensions	: [ 'effect-slide-menu', 'pageshadow' ],
					searchfield	: true,
					counters	: true,
					navbar 		: {
						title		: '<?php echo $blogname; ?>'
					},
					navbars		: [
						{
							position	: 'top',
							content		: [ 'searchfield' ]
						}, {
							position	: 'top',
							content		: [
								'prev',
								'title',
							]
						}, 
					]
				});
			});
		</script>
	<!--[ifltIE9]>
 <scripttype="text/javascript"src="//libs.cncdn.cn/html5shiv/3.7.2/html5shiv.min.js"></script>
    <![endif]-->  
<link rel="canonical" href="<?php echo BLOG_URL; ?>" />
<meta name="generator" content="emlog" />
 <link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
</head>
