<?php 
/**
 * 页面底部信息
 无事不登三宝殿，版权就在下边！HTTP://WWW.ISIYUAN.NET
 short_name:"xxx" xxx替换成你的多说Id
 查询多说ID：http://www.isiyuan.net/index.php?keyword=%E5%A4%9A%E8%AF%B4
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<footer class="site-footer clearfix">
<section class="copyright">
<script type="text/javascript">
var duoshuoQuery = {short_name:"xxx"};
	(function() {
		var ds = document.createElement('script');
		ds.type = 'text/javascript';ds.async = true;
		ds.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') + '//static.duoshuo.com/embed.js';
		ds.charset = 'UTF-8';
		(document.getElementsByTagName('head')[0] 
		 || document.getElementsByTagName('body')[0]).appendChild(ds);
	})();
	</script>
<a href="<?php echo BLOG_URL;?>"><?php echo $blogname;?></a>
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>© 2015
</section>
<section class="poweredby">
本博客采用狂拽酷炫的
<a href="http://www.emlog.net" target="_blank">
 <span class="red"><i class="fa fa fa-heart"></i></span>
EMLOG
</a>
<?php 
Copyright(); 
?>
</a>
</section>
</footer>
		<div id="scroll" class="scroll" style="display: block;">
<i class="icon-chevron-up"></i>
</div>
<?php echo $footer_info; ?>
 <?php doAction('index_footer'); ?>
</body>
</html>