<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div class="main_center">
<div class="main_content">
<div class="log_title"><?php echo $log_title; ?><span><a href="javascript:void(0);" onclick="window.history.back();">返回</a></span></div>
<div class="log_text"><?php echo $log_content; ?></div>
<?php blog_att($logid); ?>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<div class="c"></div>
</div>
<div class="main_sidebar"><?php include View::getView('side');?></div>
<div class="c"></div>
</div>
<?php include View::getView('footer');?>