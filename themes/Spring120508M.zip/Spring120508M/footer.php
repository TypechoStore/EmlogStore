<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div class="foot">
<?php doAction('index_footer'); ?>
<div class="foot_info">
&copy;<?php echo gmdate(Y);?>
&nbsp;<?php echo $blogtitle;?>
&nbsp;博客系统（<a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">Emlog</a>）
&nbsp;<?php blogt();?>
&nbsp;<?php echo $footer_info;?>
&nbsp;<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>
</div>
<div class="foot_login">
<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
<a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a>
<a href="<?php echo BLOG_URL; ?>admin/">管理中心</a>
<a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a>
<?php else: ?>
<a href="<?php echo BLOG_URL; ?>admin/">登录</a>
<?php endif; ?>
</div>
<div class="c"></div>
</div>
</div>