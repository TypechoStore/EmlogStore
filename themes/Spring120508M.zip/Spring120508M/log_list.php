<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div class="main_center">
<div class="main_content">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<div class="content_body">
<div class="content_title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a><?php blog_sort($value['logid']); ?></div>
<div class="c"></div>
<div class="content_info"><?php $weekarray=array("日","一","二","三","四","五","六");echo gmdate('Y年n月j日 G:i', $value['date']); echo " 星期".$weekarray[gmdate('w', $value['date'])];?><span><?php editflg($value['logid'],$value['author']); ?></span></div>
<div class="c"></div>
<div class="content_text"><?php echo $value['log_description']; ?></div>
<?php blog_att($value['logid']); ?>
<?php blog_tag($value['logid']); ?>
<div class="content_data">
<dd><a href="<?php echo $value['log_url']; ?>#tb">引用(<?php echo $value['tbcount']; ?>)</a></dd>
<dd><a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a></dd>
<dd><a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a></dd>
</div>
<div class="c"></div>
</div>
<?php endforeach; ?>
<div class="content_page"><?php echo $page_url;?></div>
</div>
<div class="main_sidebar"><?php include View::getView('side');?></div>
<div class="c"></div>
<div class="go_top"><a href="javascript:void(0);" class="scroll_t"></a><a href="javascript:void(0);" class="scroll_b"></a></div>
</div>
<?php include View::getView('footer');?>