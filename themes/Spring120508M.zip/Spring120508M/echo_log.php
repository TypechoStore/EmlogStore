<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div class="main_center">
<div class="main_content">
<div class="log_title"><?php topflg($top); ?><?php echo $log_title; ?><span><a href="javascript:void(0);" onclick="window.history.back();">返回</a></span></div>
<div class="c"></div>
<div class="log_info">
<?php $weekarray=array("日","一","二","三","四","五","六");echo gmdate('Y年n月j日 G:i', $date);echo " 星期".$weekarray[gmdate('w', $date)];?>
<span><?php editflg($logid,$author); ?></span>
</div>
<div class="c"></div>
<div class="log_text"><?php echo $log_content; ?></div>
<?php blog_att($logid); ?>
<?php blog_tag($logid); ?>
<?php doAction('log_related', $logData); ?>
<?php neighbor_log($neighborLog); ?>
<div class="c"></div>
<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<div class="c"></div>
</div>
<div class="main_sidebar"><?php include View::getView('side');?></div>
<div class="c"></div>
</div>
<?php include View::getView('footer');?>