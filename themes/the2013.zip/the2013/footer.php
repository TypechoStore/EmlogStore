<?php 
/**
 * 底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
			</div>
			<!-- 主体 结束 -->
			<!-- 底部 开始 -->
			<footer id="ft" class="clearfix">
				本博客由 <a href="http://www.emlog.net" rel="nofollow" target="_blank" title="emlog <?php echo Option::EMLOG_VERSION;?>">EMLOG</a> 强力驱动 · 
				主题制作 <a href="http://www.maxpin.net" rel="nofollow" target="_blank" title="宠辱不惊，去留无意。">笑西楚</a> 
				<!-- = ICP备案号 -->
				<a href="http://www.miibeian.gov.cn" rel="nofollow" target="_blank"><?php echo $icp; ?></a> 
				<!-- = 其他信息 -->
				<?php echo $footer_info; ?>
				<?php doAction('index_footer'); ?>
			</footer>
			<!-- 底部 结束 -->
		</div>
		<!-- 外围容器 结束 -->
	</body>
</html>