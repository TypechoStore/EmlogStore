<?php 
/**
 * 首页日志列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
$template_name = str_replace(BLOG_URL,"",TEMPLATE_URL);
$template_name = str_replace("content/templates/","",$template_name);
$template_name = str_replace("/","",$template_name); //获取模板目录名称
?>

			<!-- 主体 开始 -->
			<div id="bd" class="clearfix">
				<!-- 主面板 开始 -->
				<div id="main">
					<!-- 遍历文章 开始 -->
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
					<section class="preview">
						<!-- = 标题 -->
						<h3 class="preview-hd">
<?php topflg($value['top']); ?>
							<a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>">
								<?php echo $value['log_title']; ?>
							</a>
						</h3>
						<!-- 内容 开始 -->
						<dl class="preview-bd clearfix">
							<!-- = 缩略图 -->
							<dt class="preview-bd-title">
<?php
//获取缩略图
$thum_file = EMLOG_ROOT.'/content/templates/'.$template_name.'/thumbnail/gid/'.$value['gid'].'.jpg';
if (is_file($thum_file)) {
	$thum_src = TEMPLATE_URL.'/thumbnail/gid/'.$value['gid'].'.jpg'; //ID编号配图
}else{
	$thum_src = getThumbnail($value['logid']); //附件第一张图片
	if (empty($thum_src)) {
		$rand_num = 3; //随机图片数量，按实际数量设置
		if ($rand_num == 0) {
			$thum_src = TEMPLATE_URL."thumbnail/0.jpg";
			//默认图片，须命名为"0.jpg"
		}else{
			$thum_src = TEMPLATE_URL."thumbnail/random/".rand(1,$rand_num).".jpg";
		}
	}
}
?>
								<a href="<?php echo $value['log_url']; ?>">
									<img src="<?php echo $thum_src; ?>" width="130" height="130" alt="thumb" />
								</a>
							</dt>
							<!-- = 摘要描述 -->
							<dd class="preview-bd-description"><?php echo $value['log_description']; ?></dd>
						</dl>
						<!-- 内容 结束 -->
						<!-- = 相关信息 -->
						<aside class="preview-ft">
							<!-- = 作者 -->
							Post by <?php blog_author($value['author']); ?> · 
							<!-- = 时间 -->
							<time><?php echo gmdate('Y-n-j G:i l', $value['date']); ?></time> · 
							<!-- 标签 -->
							<?php blog_tag($value['logid']); ?> · 
							<!-- = 浏览量 -->
							<?php echo $value['views']; ?> view
							<!-- = 编辑 -->
							<?php editflg($value['logid'],$value['author']); ?>
						</aside>
					</section>
<?php endforeach; ?>
					<!-- 遍历文章 结束 -->
					<!-- 分页区域 开始 -->
					<div id="pagenavi">
						<?php echo $page_url;?>
					</div>
					<!-- 分页区域 结束 -->
				</div>
				<!-- 主面板 结束 -->
				
<?php
 include View::getView('side');
 include View::getView('footer');
?>