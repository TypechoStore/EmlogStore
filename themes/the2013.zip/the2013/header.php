<?php
/**
 * Template Name:The 2013
 * Description:宠辱不惊，去留无意。
 * Version:1.0
 * Author:Maxpin
 * Author Url:http://www.maxpin.net
 * Sidebar Amount:1
 * ForEmlog:5.0.1
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE HTML>
<html lang="en-US">
	<head>
		<meta charset="UTF-8">
		<title><?php echo $site_title; ?></title>
		<meta name="keywords" content="<?php echo $site_key; ?>" />
		<meta name="description" content="<?php echo $site_description; ?>" />
		<meta name="viewport" content="width=device-width, initial-scale=1" /><!-- 响应式设计所需 -->
		<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
		<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
		<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
		<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo TEMPLATE_URL; ?>media-queries.css" rel="stylesheet" type="text/css"><!-- 响应式设计所需样式 -->
		<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
		<?php
			if(function_exists('emLoadJQuery')) {
			    emLoadJQuery();
			}
		?>

		<!--[if lt IE 9]>
		<script type="text/javascript">
			(function(a,b){function h(a,b){var c=a.createElement("p"),d=a.getElementsByTagName("head")[0]||a.documentElement;return c.innerHTML="x<style>"+b+"</style>",d.insertBefore(c.lastChild,d.firstChild)}function i(){var a=l.elements;return typeof a=="string"?a.split(" "):a}function j(a){var b={},c=a.createElement,f=a.createDocumentFragment,g=f();a.createElement=function(a){if(!l.shivMethods)return c(a);var f;return b[a]?f=b[a].cloneNode():e.test(a)?f=(b[a]=c(a)).cloneNode():f=c(a),f.canHaveChildren&&!d.test(a)?g.appendChild(f):f},a.createDocumentFragment=Function("h,f","return function(){var n=f.cloneNode(),c=n.createElement;h.shivMethods&&("+i().join().replace(/\w+/g,function(a){return c(a),g.createElement(a),'c("'+a+'")'})+");return n}")(l,g)}function k(a){var b;return a.documentShived?a:(l.shivCSS&&!f&&(b=!!h(a,"article,aside,details,figcaption,figure,footer,header,hgroup,nav,section{display:block}audio{display:none}canvas,video{display:inline-block;*display:inline;*zoom:1}[hidden]{display:none}audio[controls]{display:inline-block;*display:inline;*zoom:1}mark{background:#FF0;color:#000}")),g||(b=!j(a)),b&&(a.documentShived=b),a)}var c=a.html5||{},d=/^<|^(?:button|form|map|select|textarea|object|iframe|option|optgroup)$/i,e=/^<|^(?:a|b|button|code|div|fieldset|form|h1|h2|h3|h4|h5|h6|i|iframe|img|input|label|li|link|ol|option|p|param|q|script|select|span|strong|style|table|tbody|td|textarea|tfoot|th|thead|tr|ul)$/i,f,g;(function(){var c=b.createElement("a");c.innerHTML="<xyz></xyz>",f="hidden"in c,f&&typeof injectElementWithStyles=="function"&&injectElementWithStyles("#modernizr{}",function(b){b.hidden=!0,f=(a.getComputedStyle?getComputedStyle(b,null):b.currentStyle).display=="none"}),g=c.childNodes.length==1||function(){try{b.createElement("a")}catch(a){return!0}var c=b.createDocumentFragment();return typeof c.cloneNode=="undefined"||typeof c.createDocumentFragment=="undefined"||typeof c.createElement=="undefined"}()})();var l={elements:c.elements||"abbr article aside audio bdi canvas data datalist details figcaption figure footer header hgroup mark meter nav output progress section summary time video",shivCSS:c.shivCSS!==!1,shivMethods:c.shivMethods!==!1,type:"default",shivDocument:k};a.html5=l,k(b)})(this,document)
		</script>
		<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
		<![endif]-->

		<?php doAction('index_head'); ?>
		<script type="text/javascript">
			$(function(){
				//搜索框事件
				$("#searchInput").click(function(){
					$(this).val() === "输入关键字进行搜索" ? $(this).val("") : $(this).select();
				});
				$("#searchInput").blur(function(){
					if($(this).val().length <= 0){
						$(this).val("输入关键字进行搜索");
					}
				});
			});

		</script>
	</head>
	<body>
		<!-- 外围容器 开始 -->
		<div id="wrap">
			<!-- 头部 开始 -->
			<header id="hd" class="clearfix">
				<!-- = 组合标题 -->
				<hgroup class="left">
					<!-- = 标题 -->
					<h1 id="title"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
					<!-- = 副标题 -->
					<h2 id="subtitle"><?php echo $bloginfo; ?></h2>
				</hgroup>
				<!-- = 横幅 -->
				<div id="banner">
					<a href="<?php echo BLOG_URL; ?>">
						<img src="<?php echo TEMPLATE_URL; ?>images/banner.jpg" width="466" height="78" alt="466*78 banner.jpg" />
					</a>
				</div>
				<!-- = 导航 -->
				<nav id="nav">
					<?php blog_navi();?>
					<!-- = 搜索框 -->
					<span id="search">
						<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
							<input name="keyword" id="searchInput" type="text" value="输入关键字进行搜索" />
						</form>
					</span>
				</nav>
			</header>
			<!-- 头部 结束 -->

