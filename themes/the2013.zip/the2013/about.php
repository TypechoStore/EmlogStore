<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="bd" class="clearfix">
<div id="main">
	<h3><?php echo $log_title; ?></h3>
	<?php echo $log_content; ?>
</div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>