<?php 
/*
 * 阅读日志页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

			<!-- 主体 开始 -->
			<div id="bd" class="clearfix">
				<!-- 主面板 开始 -->
				<div id="main">
					<!-- 文章 开始 -->
					<article class="preview">
						<!-- = 标题 -->
						<h3 class="preview-hd clearfix">
							<?php topflg($top); ?>
							<a href="<?php echo $log_url; ?>" title="<?php echo $log_title; ?>">
								<?php echo $log_title; ?>
							</a>
						</h3>
						<!-- = 正文 -->
						<?php echo $log_content; ?>
						<!-- = 其他信息 -->
						<aside class="preview-ft">
							<!-- = 作者 -->
							Post by <?php blog_author($author); ?> · 
							<!-- = 时间 -->
							<time><?php echo gmdate('Y-n-j G:i l', $date); ?></time> · 
							<!-- = 标签 -->
							<?php blog_tag($logid); ?> · 
							<!-- = 浏览量 -->
							<?php echo $views; ?> view
							<!-- = 编辑 -->
							<?php blog_sort($logid); ?> <?php editflg($logid,$author); ?>
						</aside>
						<!-- 相关文章 -->
						<?php doAction('log_related', $logData); ?>
						<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
						<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
					</article>
					<!-- 文章 结束 -->
					<!-- PingLun.La Begin -->
					<div id="pinglunla_here"></div><a href="http://www.pinglunla.com/" id="logo-pinglunla">评论啦</a><script type="text/javascript" src="http://s2.pinglun.la/md/pinglun.la.js" charset="utf-8"></script>
					<!-- PingLun.La End -->
				</div>
				<!-- 主面板 结束 -->

<?php
 include View::getView('side');
 include View::getView('footer');
?>