<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="bd" class="clearfix">
<div id="main">
	<h3><?php echo $log_title; ?></h3>
	<?php echo $log_content; ?>
	<!-- PingLun.La Begin -->
	<div id="pinglunla_here"></div><a href="http://www.pinglunla.com/" id="logo-pinglunla">评论啦</a><script type="text/javascript" src="http://s2.pinglun.la/md/pinglun.la.js" charset="utf-8"></script>
	<!-- PingLun.La End -->
</div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>