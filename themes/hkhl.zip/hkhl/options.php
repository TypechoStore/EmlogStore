<?php

/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(

		
        'index-img' => array(
	    'type' => 'radio',
		'name' => '首页缩略图显示方案',
		'description' => '1:调用文章中的图片作为左边的缩略图，如果没有图片则随即调用images/random下的图片显示<br/>
		2:大图模式调用文章中的第一张图片作为大图回车显示，图片最大宽度540px，如果没有则如上随即调取显示<br/>
		3:摘要模式，调取后台文章编辑中的摘要作为显示，包括摘要中的图片，如果没有摘要则显示全文<br/>
		4:纯文本模式，只调取文章指定数量的字符串作为文本显示',
		'values' => array(
			'1' => '左图右文模式',
			'2' => '大图模式',
			'3' => '摘要模式',
			'4' => '纯文本模式',
		),
		'default' => '1',
	),	
		'index-zhaiyao' => array(
		'type' => 'text',
		'name' => '截取摘要字符串字数',
		'description' => '截取指定数量的文字作为摘要显示，适用于左图右文，大图模式与纯文本模式',
		'default' => '190',
	),

	
	'footer1' => array(
		'type' => 'text',
		'multi' => true,
		'rich' => true,
		'name' => '底部关于博客编辑器',
		'description' => '支持HTML，可切换代码编辑模式',
		'default' => '<div class="textwidget">
EMLOG主题由陈子文于公元二零一三年十一月二十三日移植自花花博客(www.hlhk.cn)，出于尊重已保留原作者版权，希望各位emer保留版权
</div>',
	),

	'footer2' => array(
		'type' => 'text',
		'multi' => true,
		'rich' => true,
		'name' => '底部博主简介编辑器',
		'description' => '支持HTML，可切换代码编辑模式',
		'default' => '<div class="textwidget">
我是博客的主人：陈子文，没事喜欢捣腾EMLOG博客主题，由于本人也是小菜，所以主题难免有不足或错误之处，希望各位大神给予提出，谢谢..
</div>',
	),

	'footer3' => array(
		'type' => 'text',
		'multi' => true,
		'rich' => true,
		'name' => '底部联系方式编辑器',
		'description' => '支持HTML，可切换代码编辑模式',
		'default' => '<div class="textwidget">
QQ号码 : 8212-66862(去掉"-"即可)<br>
微信：nideyibao (中文：你的怡宝)<br>
E-Mail : chenziwen@lantk.com<br>
腾讯微博：<a title="腾讯微博" href="http://t.qq.com/chenziwen918" rel="nofollow" target="_blank">t.qq.com/chenziwen918</a><br>
新浪微博：<a title="新浪微博" href="#" rel="nofollow" target="_blank">http://weibo.com/#</a><br></div>',
	),


	'footer4' => array(
		'type' => 'text',
		'multi' => true,
		'rich' => true,
		'name' => '底部版权编辑器',
		'description' => '支持HTML，可切换代码编辑模式',
		'default' => '<div class="textwidget">
除非注明，文章均为本站原创，转载请注明链接及出处，谢谢合作。否则，请不要复制转载，转载不带出处链接、作者的，必要时将采取法律手段解决，望大家体谅。</div>',
	),












	);