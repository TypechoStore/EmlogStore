<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="wrap">
<div id="content">
<div id="contentleft">
<?php doAction('index_loglist_top'); ?>
<div class="postarea">
<?php if(_g('index-img')=='1'): ?>
<style>
.index-img {float: left;margin-right: 10px;margin-top: 38px;}
.list-title > a {margin-left: -170px;}
</style>
<?php else: ?>
<?php endif; ?>






    <?php if (!empty($logs)):foreach($logs as $value): ?><!--循环输出开始-->
	<?php if(pic_thumb1($value['content'])){
		$imgsrc = pic_thumb1($value['content']);
	}else
		$imgsrc = TEMPLATE_URL.'images/random/'.rand(1,5).'.jpg';
	?>
<div style="margin-bottom: 20px;" class="post-2428 post type-post status-publish format-standard hentry category-emotion tag-10 tag-41 tag-12">
<?php if(_g('index-img')=='1'): ?>
<img width="170" height="150" src="<?php echo $imgsrc; ?>" class="index-img">
<?php elseif(_g('index-img')=='2'): ?>

<?php elseif(_g('index-img')=='3'): ?>
<?php else: ?>
<?php endif; ?>
 <div class="postmeta"><!--div class="postmeta"-->

    <h2 class="list-title">
    <!--带连接的日志标题-->
    <a rel="bookmark" href="<?php echo $value['log_url']; ?>"><?php topflg($value['top']); ?><?php echo $value['log_title']; ?></a></h2>
    <!--带连接的日志标题-->
 </div>               <!--div class="postmeta"-->

 <!--文章信息-->
 <div class="postauthor">      <!--div class="postauthor"-->
   <p style="padding-bottom: 5px; padding-top: 5px;">作者: <?php blog_author($value['author']); ?> 发表于<?php echo gmdate('Y-n-j G:i', $value['date']); ?> | 分类:<?php blog_sort($value['logid']); ?> | 评论:(<?php echo $value['comnum']; ?>) | 浏览:(<?php echo $value['views']; ?>)  </p>
 </div>                        <!--div class="postauthor"-->
<!--文章信息-->


 <div style="margin-top: 0px;" class="entry"><!--div style="margin-top: 0px;" class="entry"-->
 <?php if(_g('index-img')=='2'): ?>
 <img max-width="540" class="index-img" src="<?php echo $imgsrc; ?>"><br />
 <?php else: ?>
 <?php endif; ?>
 
 <?php if(_g('index-img')=='3'): ?>
 <?php echo $value['log_description']; ?>
 <?php elseif(_g('index-img')=='4'): ?>
 <?php echo subString(strip_tags($value['log_description']),0,_g('index-zhaiyao'),"..."); ?>
 <?php else: ?>
 <?php echo subString(strip_tags($value['log_description']),0,_g('index-zhaiyao'),"..."); ?>
 <?php endif; ?>

 <div style="clear:both;"></div>
 </div>                                      <!--div style="margin-top: 0px;" class="entry"-->

 <p style="padding-bottom: 0px;"><?php blog_tag($value['logid']); ?></p>
</div><!--post-2428 post type-post status-publish format-standard hentry category-emotion tag-10 tag-41 tag-12-->
<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
<div class="wp-pagenavi">
<div class="pages">
<?php echo $page_url;?></div>
</div><!--div id="wp-pagenavi"-->
</div><!--div id="postarea"-->
</div><!--div id="contentleft"-->
<!--载入侧边栏-->
<?php
 include View::getView('side');
?>
<!--载入侧结束-->
</div><!--div id="content"-->
<div style="clear:both;"></div>
</div><!--div id="wrap"-->
<?php
 include View::getView('footer');
?>	