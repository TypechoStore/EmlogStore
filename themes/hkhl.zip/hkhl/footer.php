<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="footer">

<div class="footer1">
<ul id="footerwidgeted-1">
<li class="widget widget_text" id="text-4">
<h2 class="widgettitle">关于博客</h2>
<?php echo _g('footer1'); ?>
</li>
 
</ul>	
</div>	

<div class="footer2">
<ul id="footerwidgeted-2">
<li class="widget widget_text" id="text-5">
<h2 class="widgettitle">博主简介</h2>
<?php echo _g('footer2'); ?>
</li>
 
</ul>	
</div>	

<div class="footer3">
<ul id="footerwidgeted-3">
<li class="widget widget_text" id="text-6">
<h2 class="widgettitle">联系方式</h2>
<?php echo _g('footer3'); ?>
</li>
</ul>	
</div>	

<div class="footer4">
<ul id="footerwidgeted-4">
<li class="widget widget_text" id="text-7">
<h2 class="widgettitle">版权所有</h2>
<?php echo _g('footer4'); ?>
</li>
 
</ul>	
</div>

<div style="clear:both;"></div>
</div>






<div id="copyright">
<div class="copyright">
<p>Copyright &copy; 2010-2014 <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>
 · Program by <a target="_blank" title="emlog" href="http://emlog.net">emlog</a>
 · Theme <a target="_blank" title="陈子文" href="http://www.chenziwen.com">陈子文</a> 移植自 <a target="_blank" title="花花博客" href="http://www.hlhk.cn/">花花博客</a>
 
</p>
<p class="pdt4">备案号: <?php echo $icp; ?>&nbsp;&nbsp; <?php echo $footer_info; ?> <br/>
<?php doAction('index_footer'); ?>
</div>
</body>
</html>