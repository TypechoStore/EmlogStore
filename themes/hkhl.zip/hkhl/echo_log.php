<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="wrap">
<div id="content">
<div id="contentleft">
<div class="postarea" id="single">
<div class="post-2456 post type-post status-publish format-standard hentry category-emotion tag-106 tag-16 tag-10 tag-12">
<h2 class="post-title"><?php topflg($top); ?> <?php echo $log_title; ?></h2>
<div class="postauthor">
<p>时间: <?php echo gmdate('Y-n-j G:i l', $date); ?> 分类: <?php blog_sort($logid); ?> 作者: <?php blog_author($author); ?> 评论(<?php echo $comnum; ?>)  浏览: <?php echo $views; ?> views &nbsp;<?php editflg($logid,$author); ?> </p>
</div>
<div class="entry">
<?php echo $log_content; ?><!--输出全文-->
<div style="clear:both;"></div>
</div>

<div class="postcopy">
                    版权所有: 除非注明，文章均为<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>原创，转载请注明出处及链接！<br>
					</div>
					<div class="nearbypost">
  <div class="alignleftpage"><?php neighbor_log($neighborLog); ?></div><!--相邻日志-->
 </div>
</div>
 <div class="related">
 <?php doAction('log_related', $logData); ?><!--相关挂载点-->      
                     
</div>
</div>
<div class="postcomments">
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?> 
</div>

</div>
<?php
 include View::getView('side');
?>
<div style="clear:both;"></div>	
</div>
<?php
 include View::getView('footer');
?>	