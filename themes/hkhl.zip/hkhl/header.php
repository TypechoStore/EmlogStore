<?php
/*
Template Name:HKHL粉色系列
Description:移植自http://www.hlhk.cn/……<br/>5.0升级说明：整合模板设置插件，自由切换首页缩略图显示方案<br/>自由设置底部信息<br/>主题说明：<a href="http://vps.lantk.com/?post=59" target="_blank">http://vps.lantk.com/?post=59</a>
Version:5.0
Author:陈子文
Author Url:http://vps.lantk.com
Sidebar Amount:1
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!--head标签开始-->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>css/style.css" rel="stylesheet" type="text/css" /><!--加载主题CSS-->
<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<!--head标签结束-->

<!--body标签开始-->
<body>
<div id="header">                           <!--div id="header"-->
  <div class="headerleft">       <!--div class="headerleft"-->
    <h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
    <p><?php echo $bloginfo; ?></p>
  </div>                         <!--div class="headerleft"-->

<div class="headerright"><!--div class="headerright"-->
   
   <?php blog_navi();?>
  </div>                 <!--div class="headerright"-->
</div>                                     <!--div id="header"-->
<div style="clear:both;"></div>
