<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="contentleft">
<?php doAction('index_loglist_top'); ?>

<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
<div class="list">
<h2><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
<div class="date">栏目： <?php blog_sort($value['logid']); ?> &nbsp;&nbsp;作者： <?php blog_author($value['author']); ?> &nbsp;&nbsp;时间： <?php echo gmdate('Y-n-j', $value['date']); ?> <a href="<?php echo $value['log_url']; ?>"> &nbsp;&nbsp;浏览: <?php echo $value['views']; ?></a></div>
<?php echo $value['log_description']; ?>
</div>
<hr />
<div style="clear:both;"></div>
<?php 
endforeach;
else:
?>
<h2>未找到</h2>
<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>

<div id="pagenavi"><?php echo $page_url;?></div>

</div><!-- end #contentleft-->
</div><!--end #content-->
<?php include View::getView('side');?>
<div style="clear:both;"></div>
<?php include View::getView('footer');?>