<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="contentleft">
<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
<div class="date">栏目：<?php blog_sort($logid); ?> &nbsp;&nbsp;时间：<?php echo gmdate('Y-n-j', $date); ?></div>
<?php echo $log_content; ?>
<p class="tag"><?php blog_tag($logid); ?></p>
<?php doAction('log_related', $logData); ?>
<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
</div><!--end #content-->
</div><!--end #contentleft-->
<?php include View::getView('side');?>
<div style="clear:both;"></div>
<?php include View::getView('footer');?>