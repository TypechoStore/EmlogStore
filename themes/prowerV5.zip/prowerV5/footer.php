<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>



</div>
<aside id="footer_box">
	<div id="sponsor">
		<a href="#"><img src="<?php echo TEMPLATE_URL; ?>images/logo.png" width="250" height="100" alt="日本VPS主机" title="日本VPS主机"></a>
		<a style="margin:0 20px;" href="#"><img src="<?php echo TEMPLATE_URL; ?>images/logo.png" width="250" height="100" alt="WordPress问答" title="WordPress问答"></a>
		<a href="#"><img src="<?php echo TEMPLATE_URL; ?>images/logo.png" width="250" height="100" alt="精美网页设计欣赏" title="精美网页设计欣赏"></a>
	</div>
	</br>
	<div id="linkcat"><?php widget_link(''); ?></div>
	
</aside>

<footer id="footer">
	<p>&copy; 2012 <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a> . Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> . Theme by <a href="http://www.prower.cn" target="_blank">Prower</a>. Transplant by <a href="http://foxzld.com/" target="_blank">LonelyFox</a></p>
</footer>


</body>
</html>