<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">	
<article class="post">
		<h1><?php echo $log_title; ?></h1>
		
		<?php echo $log_content; ?>
		
		
		<div style="clear:both;"></div>
		
			<?php doAction('log_related', $logData); ?>
     		
	</article>
	
    <article id="comments">	
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</article>
	</div>

	
<?php

 include View::getView('footer');
?>