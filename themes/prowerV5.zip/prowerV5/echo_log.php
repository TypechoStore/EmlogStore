<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="content">	
<article class="post">
		<h1><?php topflg($top); ?><?php echo $log_title; ?></h1>
		<small class="meta">作者：<?php blog_author($author); ?> 发布于：<?php echo gmdate('Y-n-j G:i l', $date); ?> 
	 <?php editflg($logid,$author); ?></small>
		<?php echo $log_content; ?>
		<p class="att"><?php blog_att($logid); ?></p>
		<small class="meta"><?php blog_sort($logid); ?> | <?php blog_tag($logid); ?> | </small>
		<div style="clear:both;"></div>
		
			<?php doAction('log_related', $logData); ?>
          
		  
		
	</article>
	<div id="postnav">
             <?php neighbor_log($neighborLog); ?>
            
          </div>
    <article id="comments">	
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</article>
	</div>

<?php

 include View::getView('footer');
?>