<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="outerwrapper">
	<div id="innerwrapper">
    <div id="maincol">
    	<div class="postwrap">
        	<div class="postmeta2">
            	<div class="meta2inner">
                	<div class="pday"><?php echo gmdate('j', $date); ?></div>
                    <div class="pmonth"><?php echo gmdate('M', $date); ?>/<?php echo gmdate('y', $date); ?></div>
                </div>
            </div>
            <h2 class="posttitle"><?php topflg($top); ?><?php echo $log_title; ?></h2>
            <div class="postmeta">by <?php blog_author($author); ?> under <?php blog_sort($logid); ?></div>
            <div class="clr16"></div>
            <div class="postcontent"><?php echo $log_content; ?></div>
            <div class="clr"></div>
            <span class="linkpages"></span>
            <div class="cleared"></div>
            <div class="roubcornrcontent">
            	<span class="posttags-single"><?php blog_tag($logid); ?></span>
                <div class="clr"></div>
            </div>
            <div class="clr"></div>
            <div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
        <div class="clr"></div>
        </div>
        <!-- Closes topPost -->
        <small></small>
        <div id="comments">
        <div class="roubcornrcontent">
			<?php blog_comments($comments); ?>
			<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
             </div><!--end .roubcornrcontent-->
                </div><!--end #comments-->  
    </div>
    <!-- Closes Main -->
    <div id="rightcol">
    <?php
	include View::getView('side');
	?>
    </div>
    <div class="clr"></div>
    <div id="bottompanel"></div>
    <!-- Bottom Panel ends -->
    <div class="copyr">&copy; <?php echo date('Y') ?> <a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>"><?php echo $blogname; ?></a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a></div>
    <div class="clr16"></div>
    </div>
</div>
<?php
 include View::getView('footer');
?>