<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="layoutbottom"></div>
</div>
<div id="credit" align="center">
	<abbr title="iDream/1.0.2">iDream</abbr> theme by <a href="http://www.templatesnext.org/">Templates Next</a> 
    | Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">Emlog</a> <?php echo $footer_info; ?>
</div>
<?php doAction('index_footer'); ?>
</body>
</html>