<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="outerwrapper">
    <div id="innerwrapper">
    <!-- Contents Starts here -->
    <!-- main column Starts here -->
    <div id="maincol">
    <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
	$img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?> 
    <div class="postwrap">
    <div class="postmeta2">
        <div class="meta2inner">
            <img src="<?php echo $avatar; ?>" class="tavatar" width="38px" height="38px" />
        </div>
    </div>
    <div class="tcontent"><?php echo $val['t'].'<br/>'.$img;?></div>
    <div class="postmeta">by <?php echo $author; ?> in <?php echo $val['date'];?></div>
    <div class="clr"></div>
    </div>
    <?php endforeach; ?>
    <!-- Closes topPost -->
    <br />
    <div id="nextprevious">
        	<div class="nav">
            <div class="wp-pagenavi">
			<?php echo $pageurl;?>
            </div>
            </div>
        <div class="clr"></div>
    </div>
    <div class="clr"></div>
    </div><!-- Closes maincol -->
    <!-- right column Starts here -->
    <div id="rightcol">
    <?php
	 include View::getView('side');
	?>
    </div>
    <div class="clr"></div>
    <div id="bottompanel">
    <div class="roundcornrrbox">
        <div class="topleftcorner"><div class="toprightcorner"></div></div>
        <div class="roundcrrcnt">
            <div class="col1">
			<h3>最新发表</h3>
				<ul>
				<?php
				global $CACHE; 
				$newLogs_cache = $CACHE->readCache('newlog');
				foreach($newLogs_cache as $value): ?>
				<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
				<?php endforeach; ?>
				</ul>
            </div>
            
            <div class="col2">                      
				<h3>随便看看</h3>
                <ul>
				<?php
				$index_randlognum = Option::get('index_randlognum');
				$Log_Model = new Log_Model();
				$randLogs = $Log_Model->getRandLog($index_randlognum);
				foreach($randLogs as $value): ?>
                <li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
                <?php endforeach; ?>
                </ul>
			</div>
            
            <div class="col3">
			<h3>关注热点</h3>
            <ul id="blogtags">
            <?php
			$date = time() - 3600 * 24 * 60;
			$Log_Model = new Log_Model();
			$hotlogs = $Log_Model->getLogsForHome("AND date > {$date} ORDER BY comnum DESC,date DESC", 1, 16);
			foreach($hotlogs as $key=>$value): ?>
				<li><a href="<?php echo $value['log_url']; ?>"><?php echo $value['title']; ?></a></li>
			<?php endforeach;?> 
            </ul>
			 </div>   
            <div class="clr"></div>
        </div>
        <!-- Bottom Panel ends -->
        <div class="bottomleftcorner"><div class="bottomrightcorner"></div></div>
    </div>
</div>
    <div class="copyr">&copy; <?php echo date('Y') ?> <a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>"><?php echo $blogname; ?></a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a></div>
    <div class="clr16"></div>
    </div><!-- Closes innerwrapper -->
</div><!-- Closes outerwrapper -->

<?php
 include View::getView('footer');
?>