<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="outerwrapper">
    <div id="innerwrapper">
    <!-- Contents Starts here -->
    <!-- main column Starts here -->
    <div id="maincol">
    <?php doAction('index_loglist_top'); ?>
    <?php foreach($logs as $value): ?>
    <div class="postwrap">
    <div class="postmeta2">
        <div class="meta2inner">
            <div class="pday"><?php echo gmdate('j', $value['date']); ?></div>
            <div class="pmonth"><?php echo gmdate('M', $value['date']); ?>/<?php echo gmdate('y', $value['date']); ?></div>
        </div>
    </div>
    <h2 class="posttitle"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
    <div class="postmeta">by <?php blog_author($value['author']); ?> under <?php blog_sort($value['logid']); ?></div>
    <div class="clr16"></div>
    <div class="postcontent"><?php echo $value['log_description']; ?></div>
    <div class="clr"></div>
    <div class="roubcornrcontent">
		<span class="posttags"><?php blog_tag($value['logid']); ?></span>
		<span class="postcomments"><a href="<?php echo $value['log_url']; ?>#comments" title="Comment on <?php echo $value['log_title']; ?>"><?php echo $value['comnum']; ?> Comments</a></span>
		<span class="postmore"><a href="<?php echo $value['log_url']; ?>">more...</a></span>
	<div class="clr"></div>
	</div>
    <div class="clr"></div>
    </div>
    <?php endforeach; ?>
    <!-- Closes topPost -->
    <br />
    <div id="nextprevious">
        	<div class="nav">
            <div class="wp-pagenavi">
			<?php echo $page_url;?>
            </div>
            </div>
        <div class="clr"></div>
    </div>
    <div class="clr"></div>
    </div><!-- Closes maincol -->
    <!-- right column Starts here -->
    <div id="rightcol">
    <?php
	 include View::getView('side');
	?>
    </div>
    <div class="clr"></div>
    <div id="bottompanel">
    <div class="roundcornrrbox">
        <div class="topleftcorner"><div class="toprightcorner"></div></div>
        <div class="roundcrrcnt">
            <div class="col1">
			<h3>最新发表</h3>
				<ul>
				<?php
				global $CACHE; 
				$newLogs_cache = $CACHE->readCache('newlog');
				foreach($newLogs_cache as $value): ?>
				<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
				<?php endforeach; ?>
				</ul>
            </div>
            
            <div class="col2">                      
				<h3>随便看看</h3>
                <ul>
				<?php
				$index_randlognum = Option::get('index_randlognum');
				$Log_Model = new Log_Model();
				$randLogs = $Log_Model->getRandLog($index_randlognum);
				foreach($randLogs as $value): ?>
                <li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
                <?php endforeach; ?>
                </ul>
			</div>
            
            <div class="col3">
			<h3>关注热点</h3>
            <ul id="blogtags">
            <?php
			$date = time() - 3600 * 24 * 60;
			$Log_Model = new Log_Model();
			$hotlogs = $Log_Model->getLogsForHome("AND date > {$date} ORDER BY comnum DESC,date DESC", 1, 16);
			foreach($hotlogs as $key=>$value): ?>
				<li><a href="<?php echo $value['log_url']; ?>"><?php echo $value['title']; ?></a></li>
			<?php endforeach;?> 
            </ul>
			 </div>   
            <div class="clr"></div>
        </div>
        <!-- Bottom Panel ends -->
        <div class="bottomleftcorner"><div class="bottomrightcorner"></div></div>
    </div>
</div>
    <div class="copyr">&copy; <?php echo date('Y') ?> <a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>"><?php echo $blogname; ?></a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a></div>
    <div class="clr16"></div>
    </div><!-- Closes innerwrapper -->
</div><!-- Closes outerwrapper -->

<?php
 include View::getView('footer');
?>