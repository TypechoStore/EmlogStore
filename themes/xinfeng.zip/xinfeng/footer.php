<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>
<div style="clear:both;"></div>
<div id="footer"><div id="footerbar">
<p>
CopyRight &copy; <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a> Powered By <a href="http://www.emlog.net" title="emlog 5.0.0">Emlog</a> Skin by <a href="http://lanyes.org" title="蓝叶">蓝叶</a> <?php echo $icp; ?> <?php echo $footer_info; ?>
</p><script src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript"><!--
    	jQuery(document).ready(function($){
    	//友情链接自动添加fav图标
    	$("#link li a").each(function(e){
    	$(this).prepend("<img src=http://www.google.com/s2/favicons?domain="+this.href.replace(/^(http:\/\/[^\/]+).*$/, '$1').replace( 'http://', '' )+" style=float:left;margin-right:5px;>");
    	});
    	});
    	//--></script>
<?php doAction('index_footer'); ?>
</div></div>
</body>
</html>