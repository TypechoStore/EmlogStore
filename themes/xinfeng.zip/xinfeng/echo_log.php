<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="contentleft">
	<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
	<p class="date"><?php blog_sort($logid); ?> 作者：<?php blog_author($author); ?> 时间：<?php echo gmdate('Y-n-j G:i l', $date); ?> 
	 <?php editflg($logid,$author); ?>
	</p>
	<?php echo $log_content; ?>
	<p class="att"><?php blog_att($logid); ?></p>

	<p class="tag"><?php blog_tag($logid); ?></p>
	<br /><br />
	<?php doAction('log_related', $logData); ?>
	<div class="nextlog"><p><b>相邻日志：</b></p><?php neighbor_log($neighborLog); ?></div>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
</div>
<!--end content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>