<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!--end #content-->
<div style="clear:both;"></div>

<div class="footer">

	Copyright © <?php echo date('Y'),' '; ?><a href="<?php echo BLOG_URL; ?>" rel="home"><?php echo $blogname; ?></a><sup>&reg;</sup> 
	|  Power by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">Emlog</a> 
	</br>
   
	
	
	Theme by <a href="http://blog.wwawwa.com/" target="_blank">Emric</a> Transplant by <a href="http://foxzld.com/" target="_blank">LonelyFox</a>
 </br>
 
    <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> 
		
	<?php doAction('index_footer'); ?>
</div>

<!--
<div class="footer2">

	Copyright © <?php echo date('Y'),' '; ?><a href="<?php echo BLOG_URL; ?>" rel="home"><?php echo $blogname; ?></a><sup>&reg;</sup> | All rights reserved. 
		| <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> 
		| Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> 
	|<?php doAction('index_footer'); ?>
	
	Theme by <a href="http://blog.wwawwa.com/" target="_blank">emric</a> Transplant by <a href="http://foxzld.com/" target="_blank">LonelyFox</a>

</div>
-->
</body>
</html>