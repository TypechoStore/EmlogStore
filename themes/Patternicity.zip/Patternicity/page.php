<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
	<div class="post">
				<h2 class="title"><?php echo $log_title; ?></h2>
				            <div class="content">	
			<?php echo $log_content; ?>  
			
			<?php doAction('log_related', $logData); ?>
			</div>			
			<div class="info">
	   <?php echo gmdate('Y-n-j G:i l', $date); ?> &nbsp;&bull;&nbsp;
	   <?php blog_sort($logid); ?> &nbsp;&bull;&nbsp;
		<a href="<?php echo $value['log_url']; ?>#comments" title="查看《<?php echo $log_title; ?>》上的评论"><?php echo $comnum; ?>  Notes</a>&nbsp;&bull;&nbsp;
		<a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" rel="bookmark">Look</a>
	    </div>
	</div>
		<div id="comments">
    <div class="comt">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
	</div>

	<div style="clear:both;"></div>
</div><!--end #content-->
<?php
 
 include View::getView('footer');
?>