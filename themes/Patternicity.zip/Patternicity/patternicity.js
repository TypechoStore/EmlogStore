//图片hover动画
jQuery(function(){
	jQuery(".content img").hover(function(){
			jQuery(this).animate({"opacity":"0.8"},200);
		},function(){jQuery(this).animate({"opacity":"1"},200);})
	});