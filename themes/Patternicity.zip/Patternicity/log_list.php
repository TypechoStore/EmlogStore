<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>




<div id="content">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>		
	<div class="post">
	<div class="tags"><?php blog_tag($value['logid']); ?></div>
	<h2 class="title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
    <div class="content">
	       <?php echo $value['log_description']; ?>
    </div>			
	<div class="info">
	   <?php echo gmdate('Y-n-j G:i l', $value['date']); ?>&nbsp;&bull;&nbsp;
	   <?php blog_sort($value['logid']); ?> &nbsp;&bull;&nbsp;
		<a href="<?php echo $value['log_url']; ?>#comments" title="查看《<?php echo $value['log_title']; ?>》上的评论"><?php echo $value['comnum']; ?>  Notes</a>&nbsp;&bull;&nbsp;
		<a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" rel="bookmark">Look</a>
	</div>
	</div>
	<?php endforeach; ?>
	
  

    </div>
	
	<div id="pagenavi">
	<?php echo $page_url;?>
    </div>
	
	
	

<?php

 include View::getView('footer');
?>