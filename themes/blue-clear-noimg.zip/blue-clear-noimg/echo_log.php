<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div style="width:970px; height:30px;"></div>
<div id="content">
<div id="contentleft">
	<div class="main">
	<div class="main-border">
		<div class="main-title-log">
		<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
		<span>作者：<?php blog_author($author); ?> 发布于：<?php echo gmdate('Y-n-j G:i l', $date); ?><?php blog_sort($logid); ?> <?php editflg($logid,$author); ?><span>
		</div>
		<div class="note"><?php echo $log_content; ?></div>
		<div class="att"><?php blog_att($logid); ?></div>
		<p> 文章除注明外均为原创，转载请注明出处：<a href="http://www.diysun.com/liuyan.html">冷猫的博客</a></br>
		本文地址：:<a href="<?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];?>"><?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];?></a>
<!-- JiaThis Button BEGIN -->
<div id="ckepop">
	<span class="jiathis_txt">分享到：</span>
	<a class="jiathis_button_tools_1"></a>
	<a class="jiathis_button_tools_2"></a>
	<a class="jiathis_button_tools_3"></a>
	<a class="jiathis_button_tools_4"></a>
	<a href="http://www.jiathis.com/share?uid=1544206" class="jiathis jiathis_txt jiathis_separator jtico jtico_jiathis" target="_blank">更多</a>
	<a class="jiathis_counter_style"></a>
</div>
<!-- JiaThis Button END --><br/>
<div class="nextlog"><?php neighbor_log($neighborLog); ?></div></p>
	<!--无觅插件-->
	<div class="wumii-hook">
    <input type="hidden" name="wurl" value="<?php echo Url::log($logid); ?>" />
    <input type="hidden" name="wtitle" value="<?php echo $log_title; ?>" />
	</div>
	<script>
    var wumiiSitePrefix = "<?php echo BLOG_URL; ?>";
	</script>
	<!--end-->
	</div>
	<div class="tag-readmore">
		<span class="tag"><?php blog_tag($logid); ?></span>
		<span class="readmore1"><a href="javascript:scroll(0,0)" title="回到顶部" style="cursor:pointer;">TOP</a></span>
	</div>
	</div><!--end #main-->
	<!--
	<div class="main">
		<?php doAction('log_related', $logData); ?>
		<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	</div>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	-->
		<?php blog_comments($comments,$allow_remark,$params,$comnum); ?>
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
</div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>