<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div style="padding-top:5px; width:970px; height:25px;">
<?php doAction('index_loglist_top'); ?>
</div>
<div id="contentleft">
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
	<div class="main">
	<div class="main-border">
		<div class="main-txt">
		<div class="main-title">
		<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
		<span>On <?php echo gmdate('m.d.y', $value['date']); ?>&nbsp;,
		<a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?> Comments</a>&nbsp;
		<a href="<?php echo $value['log_url']; ?>"><?php echo $value['views']; ?> Views</a>
		<?php editflg($value['logid'],$value['author']); ?>
		<span>
		</div>
		<div class="note-list"><?php echo $value['log_description']; ?></div>
		</div>
		<div class="clear"></div>
	</div>
	<div class="tag-readmore">
		<span class="tag"><?php blog_sort($value['logid']); ?></span>
		<span class="readmore1"><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>">阅读全文</a></span>
	</div>
	</div>
	<div style="clear:both;"></div>
<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>

<div id="pagenavi">
<!--<span>共<?php echo ceil($sta_cache['lognum']/$index_lognum);?>页</span>-->
	<?php echo $page_url;?>
</div>
<div style="height:20px;"></div>

</div><!-- end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>