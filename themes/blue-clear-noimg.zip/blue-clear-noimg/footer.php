<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--end #content-->
<div style="clear:both; border-top:1px solid #ccc; border-bottom:1px solid #ccc; background-color:#fff; font-size:1px; height:1px;"></div>
<div id="footerbar">
<div id="foot">
	<div id="foot_info">
		© 2012 <a href=# target=_self style="zoom:1;"><?php echo $blogname; ?></a>. Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>.
		<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a><?php doAction('index_footer'); ?>
		&nbsp;
		<?php echo $footer_info; ?>
	</div>
	<div id="auth">
		Theme by ak92 & <a href="http://aisheji.org">Tod</a>
	</div>
	<div style="clear:both;"></div>
</div><!--end #footerbar-->
</div><!--end #wrap-->
</body>
</html>