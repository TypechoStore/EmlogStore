<?php 
/*
* 侧边栏组件、页面模块
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
	<ul id="bloggerinfo">
		<strong><?php echo $title; ?></strong>
		<div id="bloggerinfoimg">
		<?php if (!empty($user_cache[1]['photo']['src'])): ?>
		<img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="<?php echo $user_cache[1]['photo']['width']; ?>" height="<?php echo $user_cache[1]['photo']['height']; ?>" alt="blogger" />
		<?php endif;?>
		</div>
		<p><b><?php echo $name; ?></b>
		<?php echo $user_cache[1]['des']; ?></p>
	</ul>
<?php }?>
<?php
//widget：日历
function widget_calendar($title){ ?>
	<ul>
		<strong><?php echo $title; ?></strong>
		<div id="calendar">
		</div>
		<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
	</ul>
<?php }?>
<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
	<ul id="blogtags">
		<strong><?php echo $title; ?></span></strong>
		<?php foreach($tag_cache as $value): ?>
		<li><a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇日志"><?php echo $value['tagname']; ?>(<?php echo $value['usenum']; ?>)</a></li>
		<?php endforeach; ?>
	</ul>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	<ul id="blogsort">
		<strong><?php echo $title; ?></strong>
		<?php foreach($sort_cache as $value): ?>
		<li>
		<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
		<a href="<?php echo BLOG_URL; ?>rss.php?sort=<?php echo $value['sid']; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/rss.png" alt="订阅该分类"/></a>
		</li>
		<?php endforeach; ?>
	</ul>
<?php }?>
<?php
//widget：最新碎语
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	?>
	<ul id="twitter">
		<strong><?php echo $title; ?></strong>
		<?php foreach($newtws_cache as $value): ?>
		<?php $img = empty($value['img']) ? "" : '<a title="查看图片" class="t_img" href="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" target="_blank">&nbsp;</a>';?>
		<li><?php echo $value['t']; ?><?php echo $img;?><p><?php echo smartDate($value['date']); ?></p></li>
		<?php endforeach; ?>
		<?php if ($istwitter == 'y') :?>
		<p><a href="<?php echo BLOG_URL . 't/'; ?>">更多&raquo;</a></p>
		<?php endif;?>
	</ul>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
	<ul id="newcomment">
		<strong><?php echo $title; ?></strong>
		<?php
		foreach($com_cache as $value):
		$url = Url::comment($value['gid'], $value['page'], $value['cid']);
		?>
		<li id="comment"><?php echo $value['name']; ?>  <a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a></li>
		<?php endforeach; ?>
	</ul>
<?php }?>
<?php
//widget：最新日志
function widget_newlog($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
	<ul id="newlog">
		<strong><?php echo $title; ?></strong>
		<?php foreach($newLogs_cache as $value): ?>
		<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
		<?php endforeach; ?>
	</ul>
<?php }?>
<?php
//widget：热门日志
function widget_hotlog($title){
	$index_hotlognum = Option::get('index_hotlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getHotLog($index_hotlognum);?>
	<ul id="hotlog">
		<strong><?php echo $title; ?></strong>
		<?php foreach($randLogs as $value): ?>
		<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
		<?php endforeach; ?>
	</ul>
<?php }?>
<?php
//widget：随机日志
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	<ul id="randlog">
		<strong><?php echo $title; ?></strong>
		<?php foreach($randLogs as $value): ?>
		<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
		<?php endforeach; ?>
	</ul>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
	<ul id="logserch">
		<strong><?php echo $title; ?></strong>
		<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
		<input name="keyword" class="input_out" type="text" /> <button type="submit">搜索</button>
		</form>
	</ul>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
	<ul id="record">
		<strong><?php echo $title; ?></strong>
		<?php foreach($record_cache as $value): ?>
		<li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
		<?php endforeach; ?>
	</ul>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
	<ul>
		<strong><?php echo $title; ?></span></strong>
		<p><?php echo $content; ?></p>
	</ul>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="link">
	<?php foreach($link_cache as $value): ?>
	<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	?>
	<ul>
	<?php 
	foreach($navi_cache as $value):
		if($value['url'] == 'admin' && (ROLE == 'admin' || ROLE == 'writer')):
			?>
			<li><a href="<?php echo BLOG_URL; ?>admin/write_log.php"><span>写日志</span></a></li>
			<li><a href="<?php echo BLOG_URL; ?>admin/"><span>管理站点</span></a></li>
			<li><a href="<?php echo BLOG_URL; ?>admin/?action=logout"><span>退出</span></a></li>
			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
		$value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
		$current_tab = (BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url']) ? ' class="hover"' : '';
		?>
		<li<?php echo $current_tab;?>><a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><span><?php echo $value['naviname']; ?></span></a></li>
	<?php endforeach; ?>
	</ul>
<?php }?>
<?php
//blog：置顶
function topflg($istop){
	$topflg = $istop == 'y' ? "<img src=\"".TEMPLATE_URL."/images/import.gif\" title=\"置顶日志\" /> " : '';
	echo $topflg;
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == 'admin' || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
	分类：<a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
	<?php endif;?>
<?php }?>
<?php
//blog：日志标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '标签:';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "	<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
		}
		echo $tag;
	}
}
?>
<?php
//blog：日志作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻日志
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog):?>
	<a class="l" href="<?php echo Url::log($prevLog['gid']) ?>" title="<?php echo $prevLog['title'];?>">&laquo; 上一篇</a>
	<?php endif;?>
	<?php if($nextLog):?>
	<a class="r" href="<?php echo Url::log($nextLog['gid']) ?>" title="<?php echo $nextLog['title'];?>">下一篇&raquo;</a>
	<?php endif;?>
<?php }?>
<?php
//blog：引用通告
function blog_trackback($tb, $tb_url, $allow_tb){
    if($allow_tb == 'y' && Option::get('istrackback') == 'y'):?>
	<div id="trackback_address">
	<p>引用地址: <input type="text" style="width:350px" class="input" value="<?php echo $tb_url; ?>">
	<a name="tb"></a></p>
	</div>
	<?php endif; ?>
	<?php foreach($tb as $key=>$value):?>
		<ul id="trackback">
		<li><a href="<?php echo $value['url'];?>" target="_blank"><?php echo $value['title'];?></a></li>
		<li>BLOG: <?php echo $value['blog_name'];?></li><li><?php echo $value['date'];?></li>
		</ul>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：评论列表
function blog_comments($comments){
    extract($comments);
	$isGravatar = Option::get('isgravatar');
	?>
	<div id="contabcomment1">
		<div id="comment-list">
			<ul class="parents">
				<ins style="display:none;clear:both;" id="AjaxCommentBegin"></ins>
				<?php
				foreach($commentStacks as $cid):
				$comment = $comments[$cid];
				$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
				?>
				<li id="comment-<?php echo $comment['cid']; ?>" class="depth-1">
					<dl><dd><a name="<?php echo $comment['cid']; ?>"></a>
					<cite><?php echo $comment['poster']; ?></cite>
					<span class="revertcomment"><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复该留言</a></span>
					<div id="post">Post:<?php echo $comment['date']; ?></div>
					<div class="msgarticle">
						<?php echo $comment['content']; ?>
						<?php blog_comments_children($comments, $comment['children']); ?>
						<a id="AjaxCommentEnd204351" style="display:none;"></a>
					</div>
					</dd></dl>
				</li>
				<?php endforeach; ?>
				<ins style="display:none;clear:both;" id="AjaxCommentEnd"></ins>
			</ul>
		</div>
	</div>
    <div id="pagenavi" class="c mt10 list_page">
	    <?php echo $commentPageUrl;?>
    </div>
<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<li id="comment-<?php echo $comment['cid']; ?>" class="depth-1">
		<dl><dd><a name="<?php echo $comment['cid']; ?>"></a>
		<cite><?php echo $comment['poster']; ?></cite>
		<?php if($comment['level'] < 4): ?><span class="revertcomment"><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复该留言</a></span><?php endif; ?>
		<div id="post">Post:<?php echo $comment['date']; ?></div>
		<div class="msgarticle">
			<?php echo $comment['content']; ?>
			<a id="AjaxCommentEnd204403" style="display:none;"></a>
		</div>
		</dd></dl>
	</li>
	<?php blog_comments_children($comments, $comment['children']);?>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
	<div id="comment-place">
		<div id="post-comment-body">
			<div id="comment-post">
				<form  method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
					<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
					<div id="author_info">
						<div class="user-info">
							<ul>
								<p><a style="display:none;" href="javascript:void(0);" onclick="cancelReply()" id="cancel-reply" rel="nofollow">取消回复</a></p>
								<?php if(ROLE == 'visitor'): ?>
								<p><input type="text" onmouseout="this.className='input_out'" onmousemove="this.className='input_move'" onblur="this.className='input_off';this.onmouseout=function(){this.className='input_out'};" onfocus="this.className='input_on';this.onmouseout=''" tabindex="1" size="28" class="input_out" name="comname" value="<?php echo $ckname; ?>"> <label for="inpName">昵称(必填)</label></p>
								<p><input type="text" onmouseout="this.className='input_out'" onmousemove="this.className='input_move'" onblur="this.className='input_off';this.onmouseout=function(){this.className='input_out'};" onfocus="this.className='input_on';this.onmouseout=''" tabindex="2" size="28" class="input_out" name="commail" value="<?php echo $ckmail; ?>"> <label for="inpEmail">邮箱</label></p>
								<p><input type="text" onmouseout="this.className='input_out'" onmousemove="this.className='input_move'" onblur="this.className='input_off';this.onmouseout=function(){this.className='input_out'};" onfocus="this.className='input_on';this.onmouseout=''" tabindex="3" size="28" class="input_out" name="comurl" value="<?php echo $ckurl; ?>" > <label for="inpHomePage">网址</label></p>
								<?php endif; ?>
							</ul>
						</div>
					</div>
					<div id="post-comment-text">
						<textarea tabindex="5" rows="8" cols="50" onfocus="GetActiveText(this.id);" onclick="GetActiveText(this.id);" onchange="GetActiveText(this.id);" id="txaArticle" name="comment" id="comment"></textarea>
					</div>
					<div id="submit-box">
						<span>
						<input type="submit" class="post-comment-button" type="submit" id="comment_submit" value="提交评论" tabindex="6" name="btnSumbit"> 
						</span>
					◎欢迎参与讨论，请在这里发表您的看法、交流您的观点。<?php echo $verifyCode; ?><input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/>
					</div>
					<script type="text/javascript" language="JavaScript">
					var commenttextarea = document.getElementById('txaArticle');
					commenttextarea.onkeydown = function quickSubmit(e) {
					if (!e) var e = window.event;
					if (e.ctrlKey &amp;&amp; e.keyCode == 13){
					return VerifyMessage();
					}
					}
					</script>
					<script type="text/javascript" language="JavaScript">objActive="txaArticle";ExportUbbFrame();</script>
				</form>
				<p class="postbottom"></p>
				<script type="text/javascript" language="JavaScript">LoadRememberInfo();</script>
			</div>
		</div>
	</div>
	<?php endif; ?>
<?php }?>
<?php
function related_logs($logData = array())
{
	$related_log_type = 'sort';//相关日志类型，sort为分类，tag为日志；
	$related_log_sort = 'rand';//排列方式，views_desc 为点击数（降序）comnum_desc 为评论数（降序） rand 为随机 views_asc 为点击数（升序）comnum_asc 为评论数（升序）
	$related_log_num = '10'; //显示文章数，排版需要，只能为10
	$related_inrss = 'y'; //是否显示在rss订阅中，y为是，其它值为否
	global $value;
	$DB = MySql::getInstance();
	$CACHE = Cache::getInstance();
	extract($logData);
	if($value)
	{
		$logid = $value['id'];
		$sortid = $value['sortid'];
		global $abstract;
	}
	$sql = "SELECT gid,title,date FROM ".DB_PREFIX."blog WHERE hide='n' AND type='blog'";
	if($related_log_type == 'tag')
	{
		$log_cache_tags = $CACHE->readCache('logtags');
		$Tag_Model = new Tag_Model();
		$related_log_id_str = '0';
		foreach($log_cache_tags[$logid] as $key => $val)
		{
			$related_log_id_str .= ','.$Tag_Model->getTagByName($val['tagname']);
		}
		$sql .= " AND gid!=$logid AND gid IN ($related_log_id_str)";
	}else{
		$sql .= " AND gid!=$logid AND sortid=$sortid";
	}
	switch ($related_log_sort)
	{
		case 'views_desc':
		{
			$sql .= " ORDER BY views DESC";
			break;
		}
		case 'views_asc':
		{
			$sql .= " ORDER BY views ASC";
			break;
		}
		case 'comnum_desc':
		{
			$sql .= " ORDER BY comnum DESC";
			break;
		}
		case 'comnum_asc':
		{
			$sql .= " ORDER BY comnum ASC";
			break;
		}
		case 'rand':
		{
			$sql .= " ORDER BY rand()";
			break;
		}
	}
	$sql .= " LIMIT 0,$related_log_num";
	$related_logs = array();
	$query = $DB->query($sql);
	while($row = $DB->fetch_array($query))
	{
		$row['gid'] = intval($row['gid']);
		$row['title'] = htmlspecialchars($row['title']);
		$related_logs[] = $row;
	}
	$out = '';
	if(!empty($related_logs))
	{
		foreach($related_logs as $val)
		{
			$out .= "<li><span>".gmdate('Y-n-j G:i:s', $date)."</span><a href=\"".Url::log($val['gid'])."\" title=\"{$val['title']}\">{$val['title']}</a></li>";
		}
	}
	if(!empty($value['content']))
	{
		if($related_inrss == 'y')
		{
			$abstract .= $out;
		}
	}else{
		echo $out;
	}
}

?>
<?php
//首页最新
function new_logs(){
	global $CACHE;
	$newLogs_cache = $CACHE->readCache('newlog');?>
	<ul>
		<?php foreach($newLogs_cache as $value): ?>
		<li><span style="color: #006600">[最新]</span><a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>"><?php echo $value['title']; ?></a></li>
		<?php endforeach; ?>
	</ul>
<?php
}
?>
<?php
//index焦点图
function top_logs(){
	$log_Model = new Log_Model;
	$logs = $log_Model->getLogsForHome("and top='y' ORDER BY `date` DESC", 1, 5);
	?>
	<ul id="noborder">
		<?php foreach($logs as $row){?>
		<li>[推荐]<a href="<?php echo Url::log($row['gid']);?>" title="<?php echo $row['title'];?>"><?php echo $row['title'];?></a></li>
		<?php } ?>
	</ul>
<?php
}
?>
<?php
//get thumbs（图片链接）
function pic_thumb($content){
    //preg_match_all全局匹配content中的图片地址，并存入$img变量
    preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $content, $img);
    //当图片存在时，获取第一张图片，地址保存在$imgsrc中
    $imgsrc = !empty($img[1]) ? $img[1][0] : '';
	if($imgsrc){
		return $imgsrc;
	}else{
		$imgFileArray = glob("content/templates/LYHcms/images/autolistimg/*.*");
		return BLOG_URL.$imgFileArray[array_rand($imgFileArray)];
	}
}
?>
<?php
//index分类列表
function index_list($sort,$num){
	$log_Model = new Log_Model;
	$logs = $log_Model->getLogsForHome("and sortid=$sort and hide='n' ORDER BY `date` DESC", 1, $num);
	$i=0;
	global $CACHE;
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<div class="block b">
		<?php if(!empty($log_cache_sort[$logs['0']['gid']])): ?>
		<div class="subject"><span><a href="<?php echo Url::sort($log_cache_sort[$logs['0']['gid']]['id']); ?>">更多&gt;&gt;</a></span><a href="<?php echo Url::sort($log_cache_sort[$logs['0']['gid']]['id']); ?>"><?php echo $log_cache_sort[$logs['0']['gid']]['name']; ?></a></div>
		<?php endif;?>
		<div class="toppic"><img width="100" height="70" src="<?php echo pic_thumb($logs['0']['content']);?>"><a title="<?php echo $logs['0']['title'];?>" href="<?php echo Url::log($logs['0']['gid']);?>"><?php echo utf_substr($logs['0']['title'],20);?>...</a><?php echo utf_substr($logs['0']['content'],60);?>...</div>
		<ul class="topnew">
			<?php
			foreach($logs as $row){
				$i++;
				if($i!=1){
				?>
				<li><span>[<?php echo gmdate('Y-n-j', $row['date']); ?>]</span>·<a title="<?php echo $row['title'];?>" href="<?php echo Url::log($row['gid']);?>"><?php echo $row['title'];?></a></li>
				<?php
				}
			}
			?>
		</ul>
	</div>
<?php
}
?>
<?php
//中文截词
function utf_substr($str,$len)
{
	$str=strip_tags($str);
	for($i=0;$i<$len;$i++)
	{
		$temp_str=substr($str,0,1);
		if(ord($temp_str) > 127)
		{
			$i++;
			if($i<$len)
			{
				$new_str[]=substr($str,0,3);
				$str=substr($str,3);
			}
		}
		else
		{
			$new_str[]=substr($str,0,1);
			$str=substr($str,1);
		}
	}
	return join($new_str);
}
?>
<?php
//顶部分类调用
function top_list($sort,$num){
	$log_Model = new Log_Model;
	$logs = $log_Model->getLogsForHome("and sortid=$sort and hide='n' ORDER BY `date` DESC", 1, $num);
	global $CACHE;
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<div class="p_tit_01"><h3><?php if(!empty($log_cache_sort[$logs['0']['gid']])): ?><a href="<?php echo Url::sort($log_cache_sort[$logs['0']['gid']]['id']); ?>"><?php echo $log_cache_sort[$logs['0']['gid']]['name']; ?></a><?php endif;?></h3></div>
	<ul>
		<?php
		foreach($logs as $row){
		?>
		<li><a href="<?php echo Url::log($row['gid']);?>" title="<?php echo $row['title'];?>"><img src='<?php echo pic_thumb($row['content']);?>' border='0' width='120' height='120' alt='<?php echo $row['title'];?>'><span><?php echo $row['title'];?></span></a></li>
		<?php } ?>
	</ul>
<?php
}
?>