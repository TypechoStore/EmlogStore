<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php doAction('index_loglist_top'); ?>
<?php
if($pageurl == Url::logPage()){
	include View::getView('index');
}else{
?>
<div class="pleft mt1">
	<div class="p_video">
		<?php top_list(9,5);?>
	</div>
	<div class="loglist b">
		<div class="title">日志列表</div>
		<ul class="newslist">
			<?php foreach($logs as $value): ?>
			<li><span><?php echo gmdate('n.j', $value['date']); ?></span>·<a title="<?php echo $value['log_title']; ?>" href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></li>
			<?php endforeach; ?>
		</ul>
		<div class="c mt10 list_page" id="pagenavi"><?php echo $page_url;?></div>
	</div>
</div>
<?php
}
 include View::getView('side');
 include View::getView('footer');
?>