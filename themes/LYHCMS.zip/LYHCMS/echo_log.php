<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="pleft mt1">
	<div class="vieboxs contentleft">
		<div class="topic-content">
			<dt>
				<div class="post-date"><small><?php echo gmdate('n月', $date); ?></small><span><?php echo gmdate('j日', $date); ?></span></div>
				<div class="post-title">
					<h4>时间：<?php echo gmdate('Y-n-j G:i:s', $date); ?></h4>
					<h1><a href="<?php echo Url::log($logid); ?>"><?php echo $log_title; ?></a></h1>
					<h6><?php blog_sort($logid); ?>&nbsp;&nbsp;|&nbsp;&nbsp;评论: <?php echo $comnum; ?>&nbsp;&nbsp;|&nbsp;&nbsp;浏览:<span><?php echo $views; ?></span>
					<div id="ckepop">
						<div class="bshare-custom">
						<!-- JiaThis Button BEGIN -->
						<div class="jiathis_style">
							<span>分享到:</span>
							<a class="jiathis_button_qzone"></a>
							<a class="jiathis_button_tsina"></a>
							<a class="jiathis_button_tqq"></a>
							<a class="jiathis_button_renren"></a>
							<a class="jiathis_button_weixin"></a>
							<a href="http://www.jiathis.com/share" class="jiathis jiathis_txt jtico jtico_jiathis" target="_blank"></a>
							<a class="jiathis_counter_style"></a>
						</div>
						<script type="text/javascript" src="http://v3.jiathis.com/code/jia.js?uid=1364561057997430" charset="utf-8"></script>
						<!-- JiaThis Button END -->
						</div>
					</div></h6>
				</div>
			</dt>
			<dd class="post-info">
				<?php echo $log_content; ?>
				<h3 class="post-tag"><?php blog_tag($logid); ?></h3>
				<div class="doc-info">
					<h3>文档信息</h3>
					<ul>
						<li>版权声明：自由转载-非商用-非衍生-保持署名</li>
						<li>原文网址：<a rel="bookmark" href="<?php echo Url::log($logid); ?>"><?php echo Url::log($logid); ?></a></li>
						<li>订阅关注：<a href="<?php echo BLOG_URL; ?>/rss.php"><?php echo BLOG_URL; ?>/rss.php</a></li>
						</li>
					</ul>
				</div>
				<div class="post-nav"><?php neighbor_log($neighborLog); ?></div>
				<?php doAction('log_related', $logData); ?>
			</dd>
			<ins id="AjaxCommentEnd" style="display:none;clear:both;"></ins>
		</div>

<!-- UJian Button BEGIN友荐插件开始 -->
<center>
	<div class="ujian-hook"></div>
<script type="text/javascript" src="http://v1.ujian.cc/code/ujian.js?uid=1692478"></script>
<a href="http://www.ujian.cc" style="border:0;"><img src="http://img.ujian.cc/pixel.png" alt="友荐云推荐" style="border:0;padding:0;margin:0;" /></a>
</center>
<!-- UJian Button END友荐插件结束 -->
		<div id="comments">
			<div class="comment-title">
				<h3><ul>
					<li onclick="setTab('tabcomment',1,2)" class="current" id="tabcomment1">评论:(<?php echo $comnum; ?>)</li>
					<li onclick="setTab('tabcomment',2,2)" id="tabcomment2">隐藏评论</li>
				</ul><span id="gotocomment">【评论很精彩，有内幕、有真相！】</span></h3>
			</div>
			<?php blog_comments($comments); ?>
			<div class="nodis" id="contabcomment2" style="display: none;"><div class="error-tip">广告投放服务，如有需要可联系业务QQ2254872142</div></div>
		</div>
		<center>
		<!----广告代码换成自己的就好------>
		<a target="_blank" href="####"><img width="640" height="60" border="0" alt="GPS自动循环定位QQ营销系统" title="GPS自动循环定位QQ营销系统" src="http://drmcmm.baidu.com/media/id=nHD3PjcLPW0s&gp=401&time=nHnvnWmdrjbdnf.gif"></a>
		<!----广告代码------>
		</center>
		<div id="divCommentPost" class="post">
			<div id="post-comment-title"><span id="comment-reply">已有 <font color="#FF0000"><?php echo $comnum; ?></font> 位网友发表了一针见血的评论,你还等什么？</span></div>
			<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
		</div>
		<div class="related-post">
			<h3>【相关文章】</h3>
			<!----------10个------------>
			<ul>
				<?php related_logs($logData);?>
			</ul>
		</div>
	</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>