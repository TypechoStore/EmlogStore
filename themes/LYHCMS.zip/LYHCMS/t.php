<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="pleft mt1">
	<div class="vieboxs contentleft" style="border:none;">
		<ul class="quicktabs_tabs quicktabs-style-nostyle">
			<li class="qtab-0 active first"><a class="qt_ajax_tab active" id="quicktabs-tab-1-0" href="/nolink?quicktabs_1=0#quicktabs-1" disabled="false">最新段子</a></li>
		</ul>
		<div class="quicktabs_main quicktabs-style-nostyle" id="quicktabs_container_1">
			<div class="quicktabs_tabpage" id="quicktabs_tabpage_1_0">
				<?php 
				foreach($tws as $val):
				$author = $user_cache[$val['author']]['name'];
				$avatar = empty($user_cache[$val['author']]['avatar']) ? 
							BLOG_URL . 'admin/views/images/avatar.jpg' : 
							BLOG_URL . $user_cache[$val['author']]['avatar'];
				$tid = (int)$val['id'];
				$img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
				?> 
				<div class="views-row views-row-4 views-row-even views-row-last">
					<p class="views-field-phpcode-1">
						<?php echo $val['t'].'<br/>'.$img;?><br><?php echo $val['date'];?>
					</p>
					<p class="views-field-field-oriwriter-value">
						&mdash;&mdash;<?php echo $author; ?>
					</p>
					<div class="views-field-comment-count">
						<div class="bshare-custom" style="float:right;">
						<!-- JiaThis Button BEGIN -->
						<div class="jiathis_style">
							<span>分享到:</span>
							<a class="jiathis_button_qzone" title="分享到QQ空间"><span class="jiathis_txt jtico jtico_qzone"></span></a>
							<a class="jiathis_button_tsina" title="分享到新浪微博"><span class="jiathis_txt jtico jtico_tsina"></span></a>
							<a class="jiathis_button_tqq" title="分享到腾讯微博"><span class="jiathis_txt jtico jtico_tqq"></span></a>
							<a class="jiathis_button_renren" title="分享到人人网"><span class="jiathis_txt jtico jtico_renren"></span></a>
							<a class="jiathis_button_weixin" title="分享到微信"><span class="jiathis_txt jtico jtico_weixin"></span></a>
							<a target="_blank" class="jiathis jiathis_txt jtico jtico_jiathis" href="http://www.jiathis.com/share"></a>
							<a class="jiathis_counter_style"><span class="jiathis_button_expanded jiathis_counter jiathis_bubble_style" id="jiathis_counter_20" title="累计分享0次">0</span></a>
						</div>
						<script charset="utf-8" src="http://v3.jiathis.com/code/jia.js?uid=1364561057997430" type="text/javascript"></script><script charset="utf-8" src="http://v3.jiathis.com/code/plugin.client.js" type="text/javascript"></script><div style="position:absolute;width:0px;height:0px;"><object width="0" height="0" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab" id="JIATHISSWF" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"><param value="always" name="allowScriptAccess"><param value="true" name="swLiveConnect"><param value="http://www.jiathis.com/code/swf/m.swf" name="movie"><param value="z=a" name="FlashVars"><embed width="0" height="0" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" swliveconnect="true" allowscriptaccess="always" flashvars="z=a" src="http://www.jiathis.com/code/swf/m.swf" name="JIATHISSWF"></object></div>
						<!-- JiaThis Button END -->
						</div>
						<a class="comment-click ajvicomzero" href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">评论(<span id="rn_<?php echo $tid;?>"><?php echo $val['replynum'];?></span>)</a>
						<a title="添加评论" class="comment-link" href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">添加评论</a>
					</div>
					<div class="views-field-ops-1">
					</div>
					<ul id="r_<?php echo $tid;?>" class="r"></ul>
					<?php if ($istreply == 'y'):?>
					<div class="comment-form ajaxviform" id="rp_<?php echo $tid;?>" style="display: none;">
						<a title="关闭" class="formcloselink" href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">关闭</a>
						<input type="submit" class="form-submit ctools-use-modal ctools-modal-modal-comment-login-resize ctools-use-modal-processed" value="保存" id="edit-submit" name="op" onclick="reply('<?php echo DYNAMIC_BLOGURL; ?>index.php?action=reply',<?php echo $tid;?>);">
						<div id="edit-comment-wrapper" class="form-item">
							<div class="resizable-textarea">
								<span><textarea class="form-textarea resizable required ajaxComments textarea-processed" id="rtext_<?php echo $tid; ?>" rows="8" cols="60"></textarea></span>
							</div>
						</div>
						<div style="clear:both;float:none;height:0;line-height:0;"></div>
						<p class="tinfo" style="display:<?php if(ROLE == 'admin' || ROLE == 'writer'){echo 'none';}?>">
						昵称：<input type="text" id="rname_<?php echo $tid; ?>" value="" class="input_out" />
						<span style="display:<?php if($reply_code == 'n'){echo 'none';}?>">验证码：<input type="text" id="rcode_<?php echo $tid; ?>" value=""  class="input_out" /><?php echo $rcode; ?></span>
						<span id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></span>
						</p>
					</div>
					<?php endif;?>
				</div>
				<?php endforeach;?>
				<div id="pagenavi" class="c mt10 list_page"><?php echo $pageurl;?></div>
			</div>
		</div>
	</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>