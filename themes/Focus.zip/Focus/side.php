<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="sidebar">
 

  <div class="top-tab">
      <ul class="tab-header">
        <li class="cur"><a href="javascript:void(0);">热门点击</a><i>|</i></li>
        <li><a href="javascript:void(0);">最近更新</a><i>|</i></li>
        <li><a href="javascript:void(0);">推荐列表</a></li>
      </ul>
      <div class="tab-content">
        <div class="tabtag">
          <ul>
            <?php home_getloglist("hot","9"); ?>
          </ul>
        </div>
        <div class="tab-list">
          <ul>
            <?php home_getloglist("newpost","9"); ?>
          </ul>
        </div>
        <div class="tab-list">
          <ul>
            <?php home_getloglist("rand","9"); ?>
          </ul>
        </div>
      </div>
    </div>
 <script type="text/javascript">
$('#tab-header li').mouseover(function(){
	$(this).addClass("cur").siblings().removeClass();
	$("#tab-content > ul").eq($('#tab-header li').index(this)).show(250).siblings().hide(250);
});</script> 
  <ul>
  <?php 
  $widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
  doAction('diff_side');
  foreach ($widgets as $val){
    $widget_title = @unserialize($options_cache['widget_title']);
    $custom_widget = @unserialize($options_cache['custom_widget']);
    if(strpos($val, 'custom_wg_') === 0){
      $callback = 'widget_custom_text';
      if(function_exists($callback)){
        call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
      }
    }else{
      $callback = 'widget_'.$val;
      if(function_exists($callback)){
        preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
        $wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
        call_user_func($callback, htmlspecialchars($wgTitle));
      }
    }
  }
  ?>
  </ul>
<div id="float">
          <li class="sidebox"><ul class="sidetext clearfix">
	<h3 class="tit"><strong>为你推荐</strong></h3>		  
           <?php getdatelogs(9);?>
			  </ul></li>	</div>
	
</div>