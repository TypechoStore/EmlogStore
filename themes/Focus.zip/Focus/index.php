<?php 
/*
* 站点首页页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="contentwrap">
  
    <div id="content"><div id="topl">
	<div class="side-about clearfix"><div class="fxbox">
	<li><a class="bb" href="http://feed.feedsky.com/asim" title="关注我的Google+" target="_blank">Google+</a></li>
    <li><a class="bb1" href="http://asim.cn/rss.php" title="订阅我的博客" target="_blank">rss+</a></li>
	<li><a class="bb2" href="http://asim.cn/t" title="新浪微博" target="_blank">weibo+</a></li>
	<li><a class="bb3" href="http://list.qq.com/cgi-bin/qf_invite?id=e0e7113f67c0218f5e0d8cbf4d24f241277d736c2eaa253d" title="腾讯微博" target="_blank">QQ+</a></li>
	<li><a class="bb4" href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=as@asim.cn" title="给我发邮件" target="_blank">Email+</a></li>
		</div><div class="xmenu"><ul class="myinfo">
      
      <li class="qside">
        <a href="">分类导航</a>
        <div class="side-out">
          <a href="http://asim.cn/sort/sysoplogs" >站务日志</a>
          <a href="http://asim.cn/sort/moodessay" >心情随笔</a>
          <a href="http://asim.cn/sort/internet" >互联网</a>
          <a href="http://asim.cn/sort/templates" >EMLOG模板</a>
          <a href="http://asim.cn/sort/emlogskill" >EMLOG技巧</a>
          <a href="http://asim.cn/sort/feature" >精品推荐</a>
          
        </div>
      </li>
	  <li class="qside2">
        <a href="">我的作品</a>
        <div class="side-out">
          <a href="http://asim.cn/classic-x" >classic X</a>
          <a href="http://asim.cn/miblog" >miblog</a>
          <a href="http://asim.cn/default-as" >default AS</a>
          <a href="http://asim.cn/iblog" >iBlog</a>
          <a href="http://asim.cn/ascms" >ascms</a>
          <a href="http://asim.cn/" >iBlog X</a>
          
        </div>
      </li>
	  <li class="qside3">
        <a href="">二维码</a>
        <div class="side-out" >
          <img src="<?php echo TEMPLATE_URL; ?>images/erwei.png" />
        </div>
      </li>
    <li class="qside4">
        <a href="http://asim.cn/submission.html">投稿</a>
      </li>	
	</ul></div>
  </div><div class="clear"></div>
  <div class="ebox">
    
    <div clas3s="tool-content" i3d="tool-content">
      <div class="tab-tag cur">
          <ul>
            <?php $tag_cache = $CACHE->readCache('tags'); ?>
            <?php 
              shuffle($tag_cache);
              $tag_cache = array_shift(array_chunk($tag_cache,23));
              shuffle($tag_cache);
              foreach($tag_cache as $value): ?>
            <li><a href="<?php echo Url::tag($value['tagurl']); ?>"><?php echo $value['tagname']; ?></a></li>
            <?php endforeach;?>
          
          </ul>
          
        </div>
      
      
    </div>
  </div></div>
	
    <div class="slider">
      <div id="scroll">
        <div class="child"><a href="http://asim.cn/classic-x"><img src="http://fuihu.u.qiniudn.com/content/uploadfile/201405/thum-a46c1399356153.png" /></a></div>
        <div class="child"><a href="http://asim.cn/default-as"><img src="http://fuihu.u.qiniudn.com/wp-content/uploads/2014/04/defaultAS-295x300.png" /></a></div>
        <div class="child"><a href="http://asim.cn/iblog"><img src="http://fuihu.u.qiniudn.com/wp-content/uploads/2014/04/AE-300x197.png" /></a></div>
        <div class="child"><a href="http://asim.cn/ascms"><img src="http://fuihu.u.qiniudn.com/content/uploadfile/201405/31eb1398979449.jpg" /></a></div>
      </div>
      <a href="#" id="btn_prev" class="sliderbtn">prev</a>
      <a href="#" id="btn_next" class="sliderbtn">next</a>
      <div id="slider_bar"></div>
    </div>
    <ol class="homewrap">
      <?php foreach($logs as $value): ?>
      <li class="excerpt">
        <div class="excerptimg"><a href="<?php echo $value['log_url']; ?>"><img src="<?php get_imgsrc($value['content']); ?>" alt="<?php echo $value['log_title']; ?>" /></a></div>
        <div class="excerptinfo clearfix">
          <h1><a href="<?php echo $value['log_url']; ?>" title="《<?php echo $value['log_title']; ?>》"><?php echo $value['log_title']; ?></a></h1>
          <div class="excerptdes">
            <p><?php echo subString(strip_tags($value['log_description']),0,55) ?> ...</p>
          </div>
          <ul class="excerpttag"><?php blog_tag($value['logid']); ?></ul>
        </div>
        <div class="excerptvisit">
          <a class="comm" href="<?php echo $value['log_url']; ?>#comment" title="《<?php echo $value['log_title']; ?>》上的评论"><i></i><?php echo $value['comnum']; ?> 讨论</a>
          <span class="view"><i></i><?php echo $value['views']; ?>&nbsp;℃</span>
        </div>
      </li>
      <?php endforeach; ?>
    </ol>
    <div class="pagenavi"><?php echo $page_url;?></div>
  </div>
<!-- end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>