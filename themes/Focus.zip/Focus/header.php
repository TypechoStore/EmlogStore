<?php
/*
Template Name:Focus
Description:更多相关情况请关注http://www.asooe.com
Version:1.0
Author:asooe
Author Url:http://www.asooe.com
Sidebar Amount:1
ForEmlog:4.2+
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>main.css" />
<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="header-frame">
  <div id="header">
    <div><a id="logo" href="<?php echo BLOG_URL; ?>" title="<?php echo $bloginfo; ?>"><?php echo $bloginfo; ?></a></div>
    <ul id="nav">
      <div id="menu"><?php blog_navi();?></div> 
    </ul>
   <div class="tab-search">
            <form id="searchform" name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
              <input type="text" name="keyword" id="search_input" placeholder="Search...and Enter" x-webkit-speech />
            </form>
          </div> 
  </div>
</div>
