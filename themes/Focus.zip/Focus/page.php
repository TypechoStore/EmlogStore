<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="contentwrap">
  <div class="crumbs">
    <div class="breadcrumbs clearfix">
      <a href="<?php echo BLOG_URL; ?>">首页</a><span></span>
      <a href="#"><?php echo $log_title; ?></a>
    </div>
   </div>
  <div id="content">
    <div class="newpage"><?php echo $log_content; ?></div>
    <!--
    <div class="share">
      <div id="ckepop">
        <span class="jiathis_txt">分享到：</span>
        <a class="jiathis_button_tsina">新浪微博</a>
        <a class="jiathis_button_qzone">QQ空间</a>
        <a class="jiathis_button_douban">豆瓣</a>
        <a class="jiathis_button_renren">人人网</a>
        <a class="jiathis_button_tqq">腾讯微博</a>
        <a class="jiathis_button_hi">百度空间</a>
        <a class="jiathis_button_t163">网易微博</a>
        <a class="jiathis_button_gmail">Gmail邮箱</a>
      </div>
      <script type="text/javascript" src="http://v2.jiathis.com/code/jia.js?uid=1528361" charset="utf-8"></script>
    </div>
    -->
    <h3 class="comment-header">
      <span>也来说两句：</span>
      <a href="#comment">快速评论</a><a name="comments"></a>
    </h3>
    <?php blog_comments($comments); ?>
    <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
  </div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>