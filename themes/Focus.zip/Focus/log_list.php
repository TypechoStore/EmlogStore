<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
  if($pageurl == Url::logPage()){
    include View::getView('index');
  }else{
?>
<div id="contentwrap">
  
  <div id="content">
  
  <div class="crumbs">
    <div class="breadcrumbs clearfix">
      <a href="<?php echo BLOG_URL; ?>">首页</a><span></span>
      <a href="javascript:void(0);">
      <?php 
        if ($params[1]=='sort'){ 
          if(isset($_GET['sort'])){
            $sortname= $sort_cache[$_GET['sort']]['sortname'];
          }else{
            foreach($sort_cache as $val){
              if($val['alias']!='' && $params[2]==$val['alias']) $sortname= $val['sortname'];}}?>
              <?php echo $sortname;?>
        <?php }elseif ($params[1]=='tag'){ ?>
          <?php echo urldecode($params[2]);?>
        <?php }elseif($params[1]=='author'){ ?>
          <?php echo blog_author($author);?>
        <?php }elseif($params[1]=='keyword'){ ?>
          <?php echo urldecode($params[2]);?>
        <?php }elseif($params[1]=='record'){ ?>
           <?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?>
        <?php }else{?><?php }?>
      </a><span></span>
    </div>
  </div>
  
    <div class="list-top">
      <div class="list-feed">订阅地址：<input type="text" value="http://asim.cn/rss.php" disabled />订阅模板发布更新</div>
      <div class="qq-feed">
        <form method="post" target="_blank" action="http://list.qq.com/cgi-bin/qf_compose_send" class="subscribe-mail">
          <input type="hidden" value="qf_booked_feedback" name="t">
          <input type="hidden" value="e0e7113f67c0218f5e0d8cbf4d24f241277d736c2eaa253d" name="id">
          QQ 订阅：<input type="text" class="ipt" name="to" value="输入你的邮箱地址" onblur="if (this.value == '') {this.value = '输入你的邮箱地址';}" onfocus="if (this.value == '输入你的邮箱地址') {this.value = '';}" id="to">
          <input type="submit" value="确认订阅" class="feed-btn">
        </form>
      </div>
    </div>
    <ol class="listwrap">
      <?php foreach($logs as $value): ?>
      <li class="excerpt">
        <div class="excerptimg"><a href="<?php echo $value['log_url']; ?>"><img src="<?php get_imgsrc($value['content']); ?>" alt="<?php echo $value['log_title']; ?>" /></a></div>
        <div class="excerptinfo clearfix">
          <h1><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></h1>
          <div class="excerptdes">
            <p><?php echo subString(strip_tags($value['log_description']),0,58) ?> ...</p>
          </div>
          <ul class="excerpttag"><?php blog_tag($value['logid']); ?></ul>
        </div>
        <div class="excerptvisit">
          <a class="comm" href="<?php echo $value['log_url']; ?>" title="《<?php echo $value['log_title']; ?>》上的评论"><i></i><?php echo $value['comnum']; ?> 讨论</a>
          <span class="view"><i></i><?php echo $value['views']; ?> ℃</span>
        </div>
      </li>
      <?php endforeach; ?>
    </ol>
    <div class="pagenavi"><?php echo $page_url;?></div>
  </div>
<!-- end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
}?>