<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="wrapper">
		<div id="content-wrapper">
			<div id="content">
	<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
				<div class="post-wrapper">
					<div class="date">
						<span class="month">Mar</span>
						<span class="day"><?php echo gmdate('j', $value['date']); ?> </span>
					</div>
					<div style="float: right; width: 404px; clear: right; margin-top: 15px; margin-bottom: 15px; padding-top: 10px;  margin-left: 5px;">
	
			<span class="titles"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>" rel="bookmark" title="Permanent Link to <?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></span>
</div><div style="clear: both;"> </div>

			<div class="post">

			<p><?php echo $value['log_description']; ?></p>
<p class="att"><?php blog_att($value['logid']); ?></p>
			</div>
			
			<div class="post-footer">作者:<?php blog_author($value['author']); ?><strong>|</strong><?php blog_sort($value['logid']); ?><strong>|</strong>被围观<?php echo $value['views']; ?>次<strong>|</strong><a href="<?php echo $value['log_url']; ?>#comments" title="“<?php echo $value['log_title']; ?>”的评论"><?php echo $value['comnum']; ?> Comment »<?php editflg($value['logid'],$value['author']); ?></a></div>

			</div>
			<?php endforeach; ?>
			<div class="post-footer"><p class="pagination"><?php echo $page_url;?> </p></div>	
				 

</div>

		   <p class="pagination"> </p>
			</div>
		
	<?php include ('side.php');?>
</ul>

</div>

                
                </div>
             </div>
   
<?php
 				
 include View::getView('footer');
?>