<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="wrapper">
		<div id="content-wrapper">
			<div id="content">
		<div class="post-wrapper">
 
			<h3 class="post-title"><?php topflg($top); ?><a href="" rel="bookmark" title="Permanent Link to <?php echo $log_title; ?>"><?php echo $log_title; ?></a></h3>
			<div class="post">
				<div class="post-footer">by <?php blog_author($author); ?><strong>|</strong><?php blog_sort($logid); ?><strong>|</strong>被围观<?php echo $views; ?>次<strong>|</strong><?php echo $comnum; ?> Comments »<?php editflg($logid,$author); ?></a></div>
			<p><?php echo $log_content; ?></p>
	<div class="post-footer"><?php blog_att($logid); ?></div>
			</div>	
		<div class="post-footer"><?php blog_tag($logid); ?></div>
				
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
				<?php doAction('log_related', $logData); ?>
			</div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>		
			   <p class="pagination"> </p>
 	</div>
	<?php include ('side.php');?>							
			</div>	
		</div>
		   <div id="sidebar-wrapper">        
                </div>            
            </div>        
        </div>
        	
 
<?php
 include View::getView('footer');
?>