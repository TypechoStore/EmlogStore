<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="wrapper">
		<div id="content-wrapper">
			<div id="content">
		<div class="post-wrapper">
			<h3 class="post-title"><a href="" rel="bookmark" title="Permanent Link to <?php echo $log_title; ?>"><?php echo $log_title; ?></a></h3>	
			<p><?php echo $log_content; ?></p>
</div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>		
			   <p class="pagination"> </p>
 	</div>
	 	<?php include ('side.php');?>						
			</div>	
		</div>
		   <div id="sidebar-wrapper">        
                </div>            
            </div>        
        </div>
<?php
 include View::getView('footer');
?>