jQuery(function($){
    $('.top').click(function(){$('html,body').animate({scrollTop: '0px'}, 800);return false;});
    $('.bot').click(function(){$('html,body').animate({scrollTop:$('#top_bottom').offset().top}, 800);return false;});
});