<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div style="clear:both;"></div>
<div id="footer">
	<div class="mbox">
		<p>
			Copyright &copy;2013 <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>
			 | Powered by
			<a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>.
			 | 原作者: <a href="http://viluo.com/" target="_blank">viLuo</a> | 模板增强: <a href="http://lovesugar.info" target="_blank">爱冰博客</a>
		</p>
		<p>
			<a href="http://lovesugar.info/m">手机版</a>
			 | <a href="mailto:liuhaotian0520@163.com">联系站长</a>
			 | <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>
			 | <a href="http://lovesugar.info/sitemap.xml" rel="sitemap">sitemap</a>
			<?php echo $footer_info; ?>
			<?php doAction('index_footer'); ?>
		</p>
		<a class="gotop" href="javascript:;">回到顶部</a>
	</div>
<?php doAction('index_footer'); ?>
</div>

<div id="goto"><div class="top">向上</div><div class="bot">向下</div></div><div id="top_bottom"></div>
<script src="<?php echo TEMPLATE_URL; ?>script/jquery.lavalamp-1.3.4.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>script/theme_script.js" type="text/javascript"></script>

<!--[if IE 6]>
<script src="http://letskillie6.googlecode.com/svn/trunk/letskillie6.zh_CN.pack.js">
</script>
<![endif]-->
</body>
</html>