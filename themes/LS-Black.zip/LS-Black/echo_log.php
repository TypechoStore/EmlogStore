<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content" class="single">
	<div class="sitemap cbx">
		<a href="<?php echo BLOG_URL; ?>" title="返回博客主页">首页</a>
		&nbsp;&raquo;&nbsp;
		<?php blog_sort_4_new($logid); ?>
		<?php echo $log_title; ?>
	</div>
	<div class="cbx post">
		<h2>
			<?php echo $log_title; ?>
		</h2>
		<div class="postmeta">
			<ul>
				<li class="meta-date">
					<?php echo gmdate('Y-n-j G:i', $date); ?>
				</li>
				<li class="meta-cat">
					<?php blog_sort($logid); ?>
				</li>
				<li class="meta-views">
					<?php echo $views; ?> views
				</li>
				<li class="meta-comments">
					<a href="#comments"
						title="<?php echo $log_title; ?>上的评论"><?php echo $comnum; ?> 条评论</a>
				</li>
				<li class="meta-tags">
					<?php blog_tag($logid); ?>
				</li>
			</ul>
			<div class="clear"></div>
		</div>
		<div class="post-content">
			<div class="post-content-text">
				<?php echo $log_content; ?>
				<p class="att"><?php blog_att($logid); ?></p>
			</div>
			<?php doAction('log_related', $logData); ?>
			<div style="line-height: 23px;font-size: 14px;text-indent:2em;">
			<p>版权所有：<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a> => <a href="<?php echo BLOG_URL.'?post='.$logid?>">《<?php echo $log_title; ?>》</a></p>
			<p>本文地址：<a href="<?php echo BLOG_URL.'?post='.$logid?>"><?php echo BLOG_URL.'?post='.$logid?></a></p>
			<p>除非注明，文章均为 <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a> 原创，欢迎转载！转载请注明本文地址，谢谢。</p>
			</div>
			<div class="clear"></div>
		</div>
	</div>
	<div id="prext" class="cbx">
		<?php neighbor_log($neighborLog); ?>
	</div>
	<div id="comments">
		<?php blog_comments($comments); ?>
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>
