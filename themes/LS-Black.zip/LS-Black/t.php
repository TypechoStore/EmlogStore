<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content" class="single">
	<div class="sitemap cbx">
		<a href="<?php echo BLOG_URL; ?>" title="返回博客主页">首页</a>
		&nbsp;&raquo;&nbsp;碎语
	</div>
	<div class="tw">
		<ol>
			<?php 
			foreach($tws as $val):
			$author = $user_cache[$val['author']]['name'];
			$avatar = empty($user_cache[$val['author']]['avatar']) ? 
						BLOG_URL . 'admin/views/images/avatar.jpg' : 
						BLOG_URL . $user_cache[$val['author']]['avatar'];
			$tid = (int)$val['id'];
			?> 
			<li class="li">
				<div class="tw-body">
					<div class="tw-text">
						<div class="gravatar">
							<img src="<?php echo $avatar; ?>" width="32px" height="32px" />
						</div>
						<div class="tw-meta">
							<span class="author"><?php echo $author; ?></span>
							<span class="time">(<?php echo $val['date'];?>)</span>
						</div>
						<div class="tw-p">
							<?php echo $val['t'];?>
							<span class="reply" style="display: none;"> <a href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">回复(<span id="rn_<?php echo $tid;?>"><?php echo $val['replynum'];?></span>)</a> </span>
						</div>
					</div>
				</div>

				<ul id="r_<?php echo $tid;?>" class="r"></ul>
				<div class="huifu" id="rp_<?php echo $tid;?>" style="display:none;">   
					<textarea id="rtext_<?php echo $tid; ?>"></textarea>
					<p>
					<span class="tinfo" style="display:<?php if(ROLE == 'admin' || ROLE == 'writer'){echo 'none';}?>">
					昵称：<input type="text" class="textinupt" id="rname_<?php echo $tid; ?>" value="<?php echo $ckname; ?>" />
					<span style="display:<?php if($reply_code == 'n'){echo 'none';}?>">验证码：<input type="text" id="rcode_<?php echo $tid; ?>" value="" /><?php echo $rcode; ?></span>
					</span>
					<input type="button" tabindex="6" value="回复" id="submit" onclick="reply('<?php echo DYNAMIC_BLOGURL; ?>index.php?action=reply',<?php echo $tid;?>);">
					</p>
					<div class="msg"><span id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></span></div>
				</div>
			</li>
			<?php endforeach;?>
			<li id="pagenavi"><?php echo $pageurl;?><span></span></li>
		</ol>
	</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>