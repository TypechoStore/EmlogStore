<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
if(isset($_GET["setting"])){include View::getView('setting');exit();}
?>
<div class="wrapper-outer  wrapper">
<div class="wrapper clearfix pt10">
<div class="con-leftt" style="width:100%">
<div class="container trqsmargina ">
	<div class="container trqsmargina">
<!--新图片广告1-->
<?php if($qbkggn== 1 ){?>
<div class="tupianwk">
	<div class="ibtad">
	<a href="<?php echo $dblj1;?>" target="_blank"><img src="<?php echo $dbtp1;?>" style="width: 100%;height:50px;margin-bottom: 8px;"></a>
		<a href="<?php echo $dblj2;?>" target="_blank"><img src="<?php echo $dbtp2;?>" style="width: 100%;height:50px;margin-bottom: 8px;"></a>
			<a href="<?php echo $dblj3;?>" target="_blank"><img src="<?php echo $dbtp3;?>" style="width: 100%;height:50px;margin-bottom: 8px;"></a>
				<a href="<?php echo $dblj4;?>" target="_blank"><img src="<?php echo $dbtp4;?>" style="width: 100%;height:50px;margin-bottom: 8px;"></a>
					<a href="<?php echo $dblj5;?>" target="_blank"><img src="<?php echo $dbtp5;?>" style="width: 100%;height:50px;"></a>
	</div>
				</div>
					            <?php }?>
<!--结束-->
	<!--滚动广告文字-->
<?php if($tupianqiyong== 1 ){?>
	<div class="gdgg">		
    <marquee behavior="scroll" direction="right">
<?php echo $gdgg;?>
    </marquee>
	</div>
            <?php }?>
	<!--结束-->
<!--热门文字广告-->
<?php if($wzggqiyong== 1 ){?>
<div class="wzgg">
<?php echo $wzgg;?>
</div>
            <?php }?>
<!--结束-->
<!--左边代码-->
<div class="col-lg-4  trindexhot trsyqsa wuisoph">
<div class="trindexhottt">
<div style="display:none;"></div>
<div style="text-align:center;">找资源 要学会搜索 两个字最准确</div></div>
      <form action="<?php echo BLOG_URL; ?>index.php" method="get" id="search" style="text-align: center;">
	  <h4><font color="black" class="gjc"></font>
        <input name="keyword" value="" onblur="if(this.value==''){this.value='';}" onfocus="if(this.value==''){this.value=''}" class="seach_cha" type="text">
        <input value="搜索" class="seach_dian" type="submit">
		<input class="chongzhi_dian" type="reset" value="重置">
		</h4>
      </form>
<!--广告区-->
<div class="zhenghe">
<div class="zdgg">
<a href="<?php echo $adurl1;?>" target="_blank"><img src="<?php echo $adimg1;?>" style="width: 100%;"></a>
</div>
<!--结束-->
<!--30天热门文章排行-->
<div class="rmph">
<ul class="trindexhotul phb_cont clearfix ">
      <?php getdatelogss(9);?>
</ul>
</div>
</div>
<!--结束-->
</div>
		<div class="cmsbox wuisodd">
		<div class="xyyy"><h3 class="countt"><i class="fa fa-line-chart" aria-hidden="true"></i>今日更新
		<div class="tline"></div></h3>
	<div class="count">
	<div style="margin-right: 5px;color: #03A9F4;text-align: center;">
	<p><?php
$Log_Model = new Log_Model();
$today = strtotime(date('Y-m-d'));//今天凌晨时间戳
$threeday = strtotime(date('Y-m-d',strtotime('-3 day')));//3天前凌晨时间戳
$tenday = strtotime(date('Y-m-d',strtotime('-10 day')));//10天前凌晨时间戳
$today_sql = "and date>$today";
$today_num = $Log_Model->getLogNum('n', $today_sql);
$threeday_sql = "and date>$threeday";
$threeday_num = $Log_Model->getLogNum('n', $threeday_sql);
$tenday_sql = "and date>$tenday";
$tenday_num = $Log_Model->getLogNum('n', $tenday_sql);
if($tenday_num=='0'){echo '这博客已经废了，都10几天了，没有更新内容。';}
elseif($threeday_num=='0'){echo '这博客快要荒废了，连续3天都没有更新文章了。';}
elseif($today_num=='0'){echo '今日站长很懒，一篇文章都没更新。';}
else{echo ' <b>今日已更新<b style="color:red">'.$today_num.'</b>个资源，</b> ';}
?><b>本站共分享了<b style="color:red"><?php echo $sta_cache['lognum'];?></b>个资源</b></p>
</div>
</div>
</div>
			<!--分页开始-->
<div class="newlist_ctrl">
<?php $page_loglist = my_page($lognum, $index_lognum, $page, $pageurl); echo $page_loglist; ?>
<span class="wuwxts">温馨提示：看更多资源可以在左边翻页</span></div>			<!--分页结束-->
<!-- 列表 -->
<div class="cmslist cmslist2 xylist">
			<ul>
<?php 
if (!empty($logs)):$ii=1;
$iii=$ii+1;
foreach($logs as $key=>$value): 
$search_pattern = '%<img[^>]*?src=[\'\"]((?:(?!\/admin\/|>).)+?)[\'\"][^>]*?>%s';
preg_match($search_pattern, $value['content'], $img);
$value['img'] = isset($img[1])?$img[1]:TEMPLATE_URL.'pic/ap'.rand(1,10).'.jpg';

?>
     <li>
		 <img src="/content/templates/FLY/images/<?php echo $ii++; ?>.gif" width="13" height="13" alt="1" style="margin-right:4px;"><span class="cms_daye_time" style="font-size:13px;color:#ff1100;float: right; <?php if(((date('Ymd',time())-date('Ymd',$value['date']))< 1)){?>
       color:#ff1100;
          <?php }?>">&nbsp;<?php echo gmdate('m-d', $value['date']); ?></span>
					<a <?php if($value['top']=='y'):?>style="background: linear-gradient(to right, red, blue,green);
        -webkit-background-clip: text;
        color: transparent;"<?php endif; ?> href="<?php echo $value['log_url']; ?>" target="_blank" title="<?php echo $value['title']; ?>">
					<span style="font-size:14px;<?php if(((date('Ymd',time())-date('Ymd',$value['date']))< 1)){?>
       color:#f44336;
          <?php }?>"><?php echo $value['title']; ?></span></a>
				</li>

<?php 
endforeach;
?>
          </ul>  
				</div>
<?php
if($ads== 1 ){
?>
<?php }?>
			<?php endif;?>
			<?php if($ads== 1 ){?>
			<!--
			<article class="excerpt"><a href="<?php echo $adurl2;?>" target="_blank"><img src="<?php echo $adimg2;?>" style="width: 100%;"></a></article>
			-->
			<?php }?>
			</div>
					</div>
		<!--广告位2-->
		<div class="container trqsmargina">
							<div class="ggw3">
<a href="<?php echo $adurl2;?>" target="_blank"><img src="<?php echo $adimg2;?>" style="width: 100%;"></a>
		</div>
		<!--结束-->
		<!--<?php if (blog_tool_ishome()) {?>-->
			<!-- cms开始 -->
			<?php
				if ($pageurl == Url::logPage()) {
				$db = MySql::getInstance();
				global $CACHE;
				global $arr_sortico1;
				$sort_cache = $CACHE->readCache('sort');
				$sort_id = array_unique(explode(',', trim($cms_id)));
				$out = "<div class='gezi index_cms'>";
				foreach ($sort_id as $key => $i) {
					$out .= "<div class='col-sm-6 {$key}'><div class='panel panel-default'><span class='icon'><i class='".$arr_sortico1[$i]."'></i></span> <div class='panel-heading'><h3 class='panel-title'>".$sort_cache[$i]['sortname']."<span class='more pull-right'><a title='更多' href='".Url::sort($i)."'><i class='fa fa-ellipsis-h'></i></a></span></h3></div><div class='panel-body  panel_cms'><ul>";
					$logss = $db->query('SELECT * FROM ' . DB_PREFIX . "blog WHERE sortid='{$i}' AND type='blog' AND hide='n' order by date DESC limit 0,5");
					while($trow = $db->fetch_array($logss)) {;
						$date = gmdate('Y年m月d日', $trow['date']);
						$trow['title'] = mb_substr($trow['title'], 0, 12, 'utf-8');
						$url = Url::log($trow['gid']);
						$out .= "<li><a href=\"{$url}\"><time>{$date}</time><i class=\"fa fa-chevron-right\"></i> {$trow['title']}</a></li>";
					}
					$out .= "</ul></div></div></div>";
				}
				$out .= "</div>";
				echo $out;
				};
			?>
			<!-- cms结束 -->
						</div>
					</div>			
<!--华丽的分割线-->
			<?php }?>

			<?php if (blog_tool_ishome()) {?>
			<?php }else{?>
			<?php }?>
<style>body{color:#555;font-size:12px;font-family:"微软雅黑", "黑体", Arial; repeat-y center top;background-size:100% auto}.wuisodd{padding:18px 12px;min-height:630px;padding-bottom: 0;box-shadow: 0px 0px 10px #ccc;background:rgba(255, 255, 255, 0.66);}.yxdf{float: left;    margin: 18px;}.tline{
    border-bottom: 1px #03a9f4 solid;
    margin-top: 12px;
    width: 752px;}.wuwxts{max-height:22px;margin-left:8px;}.count{float: right;padding-top:8px;font-size: 14px;}.countt{border-bottom: 3px #03a9f4 solid;font-size: 18px;color: #03a9f4;float: left;height: 33px;width: 120px;margin-top: auto;}.xysoso{    text-align: center;float: none;margin:0 20%;}.gtgg{   text-align: center; min-height: 180px;}.wuisoph{ padding:0 12px 12px 12px; background:rgba(255, 255, 255, 0.66);width: 366px;float:left;height: 687px;}
	@media only screen and (max-width: 650px){.tline{border:0px;}
.topBar .t-fr {
    padding-right: 6px;
}.xylist{width: 98%;}.gtgg{min-height: 0;}.logo, .search-fr {text-align: center;}.wuisoph{ padding:0 12px 12px 12px; background:#fff;width: 105%;height: auto;}
.rmph{
	display: none;
}
.ggw3{width:100%}
#navul {
    position: absolute;
    top: 0;
    left: 0;
    height: 0;
    background: url(http://www.89sky.cn/content/templates/wuiso_cn/images/nva.png) 20px 5px no-repeat;
    padding-top: 30px;
    overflow: hidden;
    cursor: pointer;
    z-index: 999;
}.cmsbox {
    width: 100%;
    float: right;
}
.ggw3 {
    width: 100%;
    margin-left: auto;
	height: auto;
}
.cmslist2 li {
    width: 100%;
}.wuisodd{padding:2px 6px;}.xdcc{display:none}.yxdf{float:none;margin:0}.countt{margin-left: 12px;margin-top: 15px;}.count{float: none;text-align: center;}.wzgg{display: none;}body{background: #fff;}
}
.phb_cont li {padding:0;
    margin-top: 3px;
    height: 27px;
    line-height: 27px;
    font-size: 14px;
}@media only screen and (max-width: 1100px){
#iautobox {
    position: relative;
   padding-top:5px;
}.cmsbox {
    width: 100%;
    float: right;
	height: auto;
    min-height: auto;
	}
	}
</style>
<style>
.trindexhot {left: -10px;margin-bottom: 10px;}
.trindexhottt {    
    height: 50px;
    width: 100%;
    border-bottom: 2px solid #44C2F1;
    font-size: 18px;
    color: #44C2F1;
    line-height: 50px;
    margin: 0 0 10px 0;}
.trindexhotico { padding: 5px; background: #00C357; color: #fff; font-size: 20px; margin: 8px 15px 0 0; float: left; }
.trindexhotul { }
.trindexhotul li { height: 40px; line-height: 40px; overflow: hidden; }
.trindexhotul li span { float: left; color: #fff; margin: 6px 10px 0 0; ; display: inline-block; border-radius: 3px; width: 25px; height: 25px; line-height: 25px; text-align: center; }
.trindexhotul li span a { color: #999; }
.trindexhotul li a { }
</style>
<style>
.am_footer {
    clear: both;
    background: url(http://www.51bbw.cn/wp-content/themes/51bbw/images/bg-foot.gif);
    width: 100%;
    padding: 35px 0 0 0;
}.am_footer {
    margin-bottom: -5px;
}.am_footer_con {
    padding: 0px;
}.am_footer_con {
    max-width: 1500px;
    text-align: center;
    margin: 0 auto;
    overflow: hidden;
    padding: 0 10px 40px;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
}.am_footer_link {
    overflow: hidden;
    display: inline-block;
    vertical-align: top;
    margin-right: 80px;
}.am_footer_link span, .am_footer_don span {
    text-align: left;
    font-size: 15px;
    color: #5F5F5F;
    padding-bottom: 10px;
    display: block;
}.am_footer ul {
    padding-left: 0em;
}abbr, acronym, address, applet, article, aside, audio, b, big, blockquote, body, canvas, caption, center, cite, code, dd, del, details, dfn, dl, dt, em, embed, fieldset, figcaption, figure, footer, form, h1, h2, h3, h4, h5, h6, header, html, iframe, img, ins, kbd, label, legend, li, mark, menu, nav, object, ol, output, p, pre, q, ruby, s, samp, section, small, span, strike, strong, sub, summary, sup, table, tbody, td, tfoot, th, thead, time, tr, tt, u, ul, var, video {
    cursor: url(http://www.51bbw.cn/wp-content/themes/51bbw/images/cursor.ico),auto;
}.am_footer_link li {
    display: inline-block;
}.am_footer_link li a {
    color: #747474;
    font-size: 14px;
    margin-right: 15px;
}.am_footer_don {
    display: inline-block;
    max-width: 400px;
    vertical-align: top;
}.am_footer_don dt {
    position: relative;
    float: left;
    width: 38px;
    height: 38px;
}.bdsharebuttonbox {
    line-height: 30px !important;
    height: 30px !important;
    overflow: hidden !important;
    vertical-align: top !important;
}.bdshare-button-style0-16 {
    zoom: 1;
}.bdsharebuttonbox a.bds_sqq {
    background-position: 0 -98px !important;
}
.bdsharebuttonbox a:hover {
    opacity: 1 !important;
}
.bdsharebuttonbox a {
    width: 29px !important;
    height: 24px !important;
    display: inline-block !important;
    margin-right: 5px !important;
    background: url(http://www.51bbw.cn/wp-content/themes/51bbw/images/share.png) no-repeat !important;
    cursor: pointer !important;
    margin-bottom: 0 !important;
    opacity: .8 !important;
    vertical-align: top !important;
}.bdsharebuttonbox a.bds_weixin {
    background-position: 0 -33px !important;
}.bdsharebuttonbox a.bds_qzone {
    background-position: 0 -65px !important;
}.bdsharebuttonbox a.bds_tsina {
    background-position: 0 0 !important;
}.bdsharebuttonbox a.bds_copy {
    background-position: 0 -516px !important;
}
.newlist_ctrl{    
text-align: center;
    padding: 12px 0 0;
    clear: both;
    outline: 0;
    zoom: 1;}
	.cmslist2 li {}

@media only screen and (max-width: 1100px)
(index):675
#iautobox {
    position: relative;
    padding-top: 5px;
}
@media only screen and (max-width: 1100px)
respond.css?v=2.75:8
.wrapper-outer, .wrapper {
    width: 100%;
}
@media only screen and (max-width: 1100px)
(index):678
.cmsbox {
    width: 100%;
    float: right;
}
@media only screen and (max-width: 650px)
(index):667
.wuisodd {
    padding: 2px 6px;
}
@media only screen and (max-width: 650px)
(index):651
.wuisoph {
    padding: 0 12px 12px 12px;
    background: #fff;
    width: 100%;
    float: right;
}
@media only screen and (max-width: 1100px)
(index):675
#iautobox {
    position: relative;
    padding-top: 5px;
}
@media only screen and (max-width: 650px)
(index):651
.xylist {
    width: 100%;
}
@media only screen and (max-width: 650px)
(index):1
.navbar-collapse collapse in {
	width: 100%;
    margin-left: 1px;
}
.seach_dian{
    display: inline-block;
    border: 1px solid #4cb8e0;
    background: #44c2f1;
    color: #FFF;
    height: 32px;
    width: 15%;
    font-size: 14px;
    line-height: 0px;
    border-radius: 0px;
    text-align: center;}
.ibtad{    margin-bottom: 10px;
    width: 1150px;
    margin-left: -10px;
    padding: 15px;
    height: auto;
    background-color: white;}
.gdgg{
    background-color: white;
    width: 100%;
    background: rgba(255, 255, 255, 0.66);
    margin: 5px 0;
    border: 1px #0a0c0c61 solid;
    width: 1150px;
    margin-left: -10px;}
.rmph{width:100%}
}
</style>
</section>
<?php include View::getView('footer');?>