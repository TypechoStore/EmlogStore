<?php
/*
Template Name:KeCi
Description:<font color=red>＊</font>该主题为七彩网络原创主题<br><font color=red>＊</font>采用Bootstrap框架<br><font color=red>＊</font>响应式设计,全站Pjax<br><font color=red>＊</font>该版本为免费开源版，不提供任何售后服务<br>＊</font>本模板在FLY1.4基础二开<br><a href="../?setting" target="_blank">设置</a>
Version:1.6
Author:七彩网络
Author Url:http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes
Sidebar Amount:4
ForEmlog:5.3.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('inc/functions');
require_once View::getView('module');
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
	<meta charset="UTF-8">
	<meta name="generator" content="emlog" />
	<meta name="mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="keywords" content="<?php echo $site_key; ?>">
	<meta name="description" content="<?php echo $site_description; ?>">
	<meta name="apple-mobile-web-app-title" content="<?php echo $blogname; ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <?php if(isset($sortName)): ?>
    <link rel="canonical" href="<?php echo Url::sort($sortid);?>" />
    <?php elseif(isset($logid)):?>
    <link rel="canonical" href="<?php echo Url::log($logid);?>" />
    <?php else:?><?php endif;?>
	<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
	<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
	<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
	<link rel="apple-touch-icon-precomposed" href="<?php echo TEMPLATE_URL; ?>favicon.ico">
	<title><?php echo $site_title; ?></title>
	<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/font-awesome.min.css" type='text/css' media='all' />
	<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/bootstrap.min.css" type='text/css' media='all' />
	<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/style.css" type='text/css' media='all' />
	<script src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js"></script>
    <script src="<?php echo TEMPLATE_URL; ?>js/jquery.pjax.js"></script>	
    <script src="<?php echo TEMPLATE_URL; ?>js/bootstrap.min.js"></script>	
	<script src="http://cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>
<script src="http://cdn.bootcss.com/jquery.pjax/1.9.5/jquery.pjax.min.js"></script>
<script type="text/javascript" language="javascript">
$(function() {
$(document).pjax('a[target!=_blank]', '.cmslist cmslist2 xylist', {fragment:'.cmslist cmslist2 xylist', timeout:6000}); //这是a标签的pjax。#content 表示执行pjax后会发生变化的id，改成你主题的内容主体id或class。timeout是pjax响应时间限制，如果在设定时间内未响应就执行页面转跳，可自由设置。
$(document).on('submit', 'form', function (event) {$.pjax.submit(event, '.cmslist cmslist2 xylist', {fragment:'.cmslist cmslist2 xylist', timeout:6000});}); //这是提交表单的pjax。form表示所有的提交表单都会执行pjax，比如搜索和提交评论，可自行修改改成你想要执行pjax的form id或class。#content 同上改成你主题的内容主体id或class。
    $(document).on('pjax:send', function() {
          $(".pjax_loading,.pjax_loading1").css("display", "block");//参考的loading动画代码
          //执行pjax开始，在这里添加要重载的代码，可自行添加loading动画代码。例如你已调用了NProgress，在这里添加 NProgress.start();
          });
    $(document).on('pjax:complete', function() {
          $(".pjax_loading,.pjax_loading1").css("display", "none");//参考的loading动画代码
          //执行pjax结束，在这里添加要重载的代码，可自行添加loading动画结束或隐藏代码。例如NProgress的结束代码 NProgress.done();
          });
});
</script>
	<?php doAction('index_head'); ?>
    <?php include View::getView('inc/head');?>
</head>
<body class="nav-fixed">
<div class="qctop">
<div class="qctop_1a">
<div class="qctop_1"><?php echo $wzmiaoshu;?></div>
</div>
<div class="qctop_2">
		<div class="navbar-header">
			<a href="<?php echo BLOG_URL; ?>" class="navbar-brand logo"><img src="<?php echo $logo ?  $logo : ''.TEMPLATE_URL."img/logo.png";?>" alt="<?php echo $site_title; ?>"></a>
		</div>
		<!--广告3-->
		<div class="ggtu">
		<a href="<?php echo $adurl3;?>" target="_blank"><img src="<?php echo $adimg3;?>" style="height: 60px;margin-left: 10px;margin-top: 11px;"></a>
		</div><!--结束-->
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
				<span class="fa fa-bars"></span>
			</button>
</div>
</div>
<!--导航上半部分-->
<nav class="navbar navbar-default navbar-fixed-top">
	<div class="container">
		<div class="collapse navbar-collapse" id="navbar-collapse">
			<!-- navbar-right -->
			<ul class="nav navbar-nav nav-top">
			<?php blog_navi();?>
			</ul>
			<!--顶部右侧联系QQ-->
			<div class="QQzx">
			<a href="http://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo $side_qq;?>&amp;site=qq&amp;menu=yes"><img src="content/templates/FLY/images/qqzx.png" style="height: 50px;width: auto;"></a>
			</div><!--结束-->
			<div class="nav-hide">
			<!--搜索框开始-->

			<!--搜索框结束-->
			</div>
		</div>

	</div>
</nav>
<div id="<?php echo get_template_name();?>">