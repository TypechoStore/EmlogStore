<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--end #content-->
<div style="clear:both;"></div>
<div id="footerbar">
Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> 
<p class="rss"><a href="<?php echo BLOG_URL; ?>rss.php">Entries (RSS)</a> </p>Theme by <a href="http://blog.purstar.net" target="_blank">五洋</a><a href="javascript:window.external.AddFavorite('http://blog.purstar.net','DotA Theme')" class="fav" title="加入收藏夹">加入收藏夹</a>
		<a href= href="<?php echo BLOG_URL; ?>rss.php" class="rss" title="RSS订阅" target="_blank">RSS订阅</a>
<a href="javascript:scroll(0,0)" mce_href="javascript:scroll(0,0)">返回顶部</a>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js"></script>
<script>
(function() {
	var $backToTopTxt = "返回顶部", $backToTopEle = $('<div class="backToTop"></div>').appendTo($("body"))
		.text($backToTopTxt).attr("title", $backToTopTxt).click(function() {
			$("html, body").animate({ scrollTop: 0 }, 120);
	}), $backToTopFun = function() {
		var st = $(document).scrollTop(), winh = $(window).height();
		(st > 0)? $backToTopEle.show(): $backToTopEle.hide();	
		//IE6下的定位
		if (!window.XMLHttpRequest) {
			$backToTopEle.css("top", st + winh - 166);	
		}
	};
	$(window).bind("scroll", $backToTopFun);
	$(function() { $backToTopFun(); });
})();
</script>
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
<?php doAction('index_footer'); ?>
</div><!--end #footerbar-->
</div><!--end #wrap-->
<!--end #top-->
</body>
</html>