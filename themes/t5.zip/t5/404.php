﻿<?php 
/*
* 自定义404页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>您所请求的页面未找到</title>
<style type="text/css">
<!--
.main{
	position:absolute;
	top:50%;
	left:50%;
	width:500px;
	height:260px;
	margin-left:-250px;
	margin-top:-130px;
}
-->
</style>
</head>
<body>
<div class="main">
	<img src="<?php echo TEMPLATE_URL; ?>img/404.png" width="500" height="260" />
</div>
</body>
</html>