<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
//blog：自建页面评论列表
function page_comments($comments){
    extract($comments);
    if($commentStacks): ?>
	<a name="comments"></a>
	<?php endif; ?>
	<?php
	$isGravatar = Option::get('isgravatar');
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<div class="page-comment" id="comment-<?php echo $comment['cid']; ?>">
		<a name="<?php echo $comment['cid']; ?>"></a>
		<?php if($isGravatar == 'y'): ?><div class="page-avatar"><img src="<?php echo getGravatar($comment['mail']); ?>" /><div class="page-comment-poster"><?php echo $comment['poster']; ?></div><br /><div class="page-comment-time" style="color:#fff; padding-left:-13px;"><?php echo $comment['date']; ?></div></div><?php endif; ?>
		<div class="page-comment-info">
			<div class="page-comment-content"><?php echo $comment['content']; ?></div>
		</div>
	</div>
	<?php endforeach; ?>
    <div id="pagenavi">
	    <?php echo $commentPageUrl;?>
    </div>
<?php }?>
