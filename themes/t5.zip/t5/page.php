<?php 
/*
* 自建页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('defined');
?>
    <div id="main">
    	<div class="page-left-header">
        <p><?php echo $log_title; ?></p>
        </div>
    	<div class="page-left-content">
        <p><?php echo $log_content; ?></p>
        </div>
    </div>
<?php
 include View::getView('footer');
?>