<script src="<?php echo TEMPLATE_URL; ?>js/jquery-1.7.1.min.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/masonry.min.js"></script>
<script>
$(function(){
	var $main=$('#main');
	$main.imagesLoaded(function(){
		$main.masonry({
			itemSelector    : '.log',
		});
	});
});
</script>
<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
    <div id="main">
         <?php foreach($logs as $value): ?>
         <?php
		//获取缩略图
$thum_src = getThumbnail($value['logid']); //附件第一张图片
		 ?>
    	<div class="log">
        <?php
			if(!empty($thum_src)){
				echo "<div class='log-img'><a href='".$value['log_url']."'><img src='".$thum_src."' border='0' title='".$value['log_title']."' /></a></div>";
			}
            ?>
			<div class="log-main">
            	<div class="log-title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></div>
                <div class="log-info"><?php echo gmdate('Y-n-j', $value['date']); ?> <a href="<?php echo $value['log_url']; ?>">阅读(<?php echo $value['views']; ?>)</a> <a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a>
                </div>
                <div class="log-desc">
                	<?php echo $value['log_description']; ?>
                </div>
            </div>
        </div>
        
        <?php endforeach; ?>
    </div>
<?php
 include View::getView('footer');
?>