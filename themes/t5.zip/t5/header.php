﻿<?php
/*
Template Name:鱼叔的板子铺(T5)
Description:自用模板，纯原创。
Version:2.1.2
Author:梦寐鱼求
Author Url:http://www.sinkery.com
Sidebar Amount:0
ForEmlog:5.0.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link type="text/css" rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/main.css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div class="wrap">
	<div class="header">
    	<div class="logo">
				<?php
				global $CACHE;
				$user_cache = $CACHE->readCache('user');
$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];
				?>
                <?php if (!empty($user_cache[1]['photo']['src'])){ ?>
            	<a href="<?php echo BLOG_URL; ?>"><img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="168" height="168" /></a>
                <?php }else{ ?>
                <a href="<?php echo BLOG_URL; ?>"><img src="<?php echo TEMPLATE_URL; ?>img/logo.jpg" width="168" height="168" /></a>
                <?php }?>
                </div>
        
        <div class="menu">
        	<div class="menu-menu">
            	<?php blog_navi();?>
            </div>
            <div class="menu-tag">
            	<?php echo widget_sort($title); ?>
            </div>
            <div class="search">
            	<form name="keyform" method="get" action="" class="search-box">
            		<input name="keyword" class="search-input" type="text" value="搜索从这里开始" onFocus="if(value==defaultValue){value='';}"
onBlur="if(!value){value=defaultValue;}" />
                </form>
            </div>
        </div>
    </div>