<?php 
/*
* 底部部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
    <div class="footer">
    	<div class="copyright">Designed by <a href="http://www.sinkery.com">梦寐鱼求</a> | Powered by <a href="http://www.emlog.net">emlog</a> | <script src="http://s23.cnzz.com/stat.php?id=4674996&web_id=4674996" language="JavaScript"></script>
 | <a href="#">回到顶部</a>
        </div>
    </div>
</div>
<a href="#"><div class="top"></div></a>
</body>
</html>