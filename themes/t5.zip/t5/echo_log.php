<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
    <div id="main">
    	<div class="main-left">
        	<div class="main-left-header">
            	<p><?php echo $log_title; ?></p>
                <p><span><?php echo gmdate('Y-n-j', $date); ?><?php blog_tag($logid); ?> <?php blog_sort($logid); ?></p>
                <div class="clear"></div>
            </div>
            <div class="main-left-content">
                <p><?php echo $log_content; ?></p>
            </div>
            <div class="neighbour"><?php echo neighbor_log($neighborLog); ?></div>
        </div>
        <div class="main-right">
        	<div class="main-right-comment">
        		<?php blog_comments($comments); ?>
				<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    		</div>
        </div>
    </div>
<?php
 include View::getView('footer');
?>