<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
	<div id="post-<?php echo $value['logid']; ?>"><!-- post div -->
		<h2 class="title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>" rel="bookmark"><?php echo $value['log_title']; ?></a></h2>
		<div class="post-info-top">
			<span class="post-info-date">
				<?php echo gmdate('Y-m-d H:s', $value['date']); ?> | 分类:<?php blog_sort($value['logid']); ?> | 作者：<?php blog_author($value['author']); ?> <?php editflg($value['logid'],$value['author']); ?>
			</span>
			<span id="addcomment"><a href="<?php echo $value['log_url']; ?>#comments" rel="nofollow" ><?php echo $value['comnum']; ?> 评论</a></span>
			<span id="gotocomments"><?php echo $value['views']; ?> 点击 </span>
		</div>
		<div class="clear"></div>
		<div class="entry">
			<?php echo $value['log_description']; ?>
		<p align="right"><a href="<?php echo $value['log_url']; ?>" title="阅读更多..."><img style="border:0px solid #555;padding:0;" src="<?php echo TEMPLATE_URL; ?>images/more.gif" border=0></a></p>
		</div><!-- END entry -->
	</div><!-- END post -->
	<ul></ul>
	<div class="clear"></div>
	<?php endforeach; ?>
<div class="clear"></div>
<div id="pagenavi">
	<div class="pagenavi"><?php echo $page_url;?></div>
	<div class="clear"></div>
</div><br>
</div><!--content-->
<?php include View::getView('side');?>
<?php  include View::getView('footer');?>