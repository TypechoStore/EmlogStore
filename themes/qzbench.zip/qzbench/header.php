<?php
/*
Template Name:qzBench
Description:移植zBench，(*^__^*) 嘻嘻 （The template From zwwooooo, by qzz for emlog）
Version:2.1
Author:qzz
Author Url:http://blog.qzee.net/
Sidebar Amount:1
ForEmlog:4.1.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
$class=$_GET[sort]; 
$class.=$sortid;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js"></script>
<script type="text/javascript">
jQuery(document).ready(function(){
jQuery('#tab-title span').click(function(){
	jQuery(this).addClass("selected").siblings().removeClass();
	jQuery("#tab-content > ul").slideUp('1500').eq(jQuery('#tab-title span').index(this)).slideDown('1500');
});
});
$(document).ready(function() {
$('h2 a').click(function(){
myloadoriginal = this.text;
$(this).text('加载中，请稍候...');
var myload = this;
setTimeout(function() { $(myload).text(myloadoriginal); }, 2012);
});
});
</script>
<!-- 图片延迟加载 -->
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/lazyload.js"></script>
<script type="text/javascript">
	$(function() {          
    	$(".article img").not("#respond_box img").lazyload({
        	placeholder:"<?php echo TEMPLATE_URL; ?>images/image-pending.gif",
            effect:"fadeIn"
          });
    	});
</script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>



<body>
<div id="nav">
	<div id="menus">
		<ul>
		<li class="<?php if($class=="" && $curpage != CURPAGE_TW){echo 'current_page_item'; }else{echo 'page_item';} ?>"><a  class="home" href="<?php echo BLOG_URL; ?>">首页</a></li>
<?php if($istwitter == 'y'):?>
	<li class="<?php echo $curpage == CURPAGE_TW ? 'current_page_item' : 'page_item';?>"><a href="<?php echo BLOG_URL; ?>t/">微语</a></li>
	<?php endif;?>
	<!--如果需要导航栏的目录，请去掉下面// -->
	<?//php menu_sort($class);?>
	<?php 
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach ($navi_cache as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
	?>
	<li class="<?php echo isset($logid) && $key == $logid ? 'current_page_item' : 'page_item';?>"><a href="<?php echo $val['url']; ?>" <?php echo $newtab; ?>><?php echo $val['naviname']; ?></a></li>
	<?php endforeach;?>
	<?php doAction('navbar', '<li class="page_item">', '</li>'); ?>
	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
	<li class="page_item"><a href="<?php echo BLOG_URL; ?>admin/">后台</a></li>
	<li class="page_item"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
	<?php else: ?>
	<li class="page_item"><a href="<?php echo BLOG_URL; ?>admin/">管理</a></li>
	<?php endif; ?>	
		</ul>
	</div>
	<div id="search">
		<form id="searchform" method="get" action="<?php echo BLOG_URL; ?>index.php">
			<input type="text" onclick="this.value=''" value="站内搜索" size="35" maxlength="50" name="keyword" id="s" />
			<input type="submit" id="searchsubmit" value=" " />
		</form>
	</div>
</div>

<div id="wrapper">
	<div id="header">
		<h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
		<h2><?php echo $bloginfo; ?></h2>
		<div class="clear"></div>
		
		<!-- 顶部Banner 955*180 需要的话就去掉注释吧~
		<div id="header_image">
			<div id="header_image_border">
				<a></a>
			</div>
		</div>
		-->
	</div>
