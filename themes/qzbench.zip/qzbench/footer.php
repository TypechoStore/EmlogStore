<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--wrapper-->
<div class="clear"></div>
<div id="footer">
	<div id="footer-inside">
		<p>
			&copy; 2011 <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>. All rights reserved.
			<br> &nbsp; &nbsp; Theme:<a href="http://blog.qzee.net/">qzbench</a>.
			Powered by <a href="http://emlog.net/">emlog</a>  
		<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a><span style="vertical-align:middle"><?php doAction('index_footer'); ?>
		</p>
		<span id="back-to-top">&uarr; <a href="#" rel="nofollow" title="Back to top">返回顶部</a></span>
	</div>
</div><!--footer-->
</body>
</html>