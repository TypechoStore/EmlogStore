<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!-- content START -->
<h2 class="title">碎语</h2>
<div id="content">
	<div id="comments-div">
	<span id="comments-addcomment"><a href="" rel="nofollow">碎碎念 (<?php echo count($tws);?>)</a>
	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?> | <a href="<?php echo BLOG_URL . 'admin/twitter.php' ?>">唠叨几句</a><?php endif; ?></span>
	<h2 id="comments">欢迎大家随便聊什么吧~( 广告就不要啦 &gt;_&lt;~~ )</h2>
	</div>
<!--t yu star-->
<ol class="commentlist" id="thecomments">
<?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
?>
<li class="comment byuser comment-author-toby even thread-even depth-1" id="comment-<?php echo $comment['cid']; ?>">
	<div id="comment-2">
		<div class="comment-author vcard">
			<img alt="Avatar" src="<?php echo $avatar; ?>" class='avatar avatar-40 photo' height="32" width="32"><cite class="fn"><?php echo $author; ?></cite>
			<span class="comment-meta commentmetadata">
				<a href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>t/?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');" onclick="commentReply(<?php echo $comment['cid']; ?>,this)"><?php echo $val['date'];?></a>
			</span>
		</div>
		<div class="comment-text">
		<p><?php echo $val['t'];?></p>
		</div>
		<div class="reply">
		<a class='comment-reply-link' href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>t/?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">评论(<span id="rn_<?php echo $tid;?>"><?php echo $val['replynum'];?></span>)</a>
		</div>
	</div>
</li>
	<!-- t yu son -->
	<p><ul class='children' id="r_<?php echo $tid;?>">
	</ul></p>
	<!-- t yu son end-->
</ol>
<!-- t yu end -->
<a name="comments"></a>
<!-- comments START -->
<ol id="thecomments" class="commentlist">
	<li class="hreview clearfix evencomment">
    <div style="display:none;" id="rp_<?php echo $tid;?>">
		<p class="comment-form-comment">
		<textarea aria-required="true" rows="8" cols="45" name="comment" id="rtext_<?php echo $tid; ?>" onkeydown="if(event.ctrlKey){if(event.keyCode==13){document.getElementById('submit').click();return false}};"></textarea></p>
		
		<p class="comment-form-author" style="display:<?php if(ROLE == 'admin' || ROLE == 'writer'){echo 'none';}?>">
        <input type="text" id="rname_<?php echo $tid; ?>" value="" /> <label for="author"><small>昵称</small></label>
		</p>
		<p class="form-submit">
			<span style="display:<?php if($reply_code == 'n'){echo 'none';}?>">验证码：<input type="text" id="rcode_<?php echo $tid; ?>" value="" /><?php echo $rcode; ?></span>
			<input type="button" onclick="reply('<?php echo DYNAMIC_BLOGURL; ?>t/index.php?action=reply',<?php echo $tid;?>);" id="submit" value="评论" /> <span id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></span>
		</p>
    </div>
</li>
<!-- comments end -->
<?php endforeach;?>
	<div id="pagenavi">
	<div class="pagenavi"><?php echo $pageurl;?></div>
	</div>
</ol>
</div>
<!-- content end -->
<!-- sidebar footer -->
<?php include View::getView('side');
 include View::getView('footer');
?>

