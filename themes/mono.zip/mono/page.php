<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="contents">
<div id="left_col">
<div class="post_even">
    <div class="post clearfix">
      <dl class="post_meta">
        <dt class="meta_date"><?php echo gmdate('Y', $date); ?></dt>
         <dd class="post_date"><?php echo gmdate('n', $date); ?><span>/<?php echo gmdate('j', $date); ?></span></dd>      
         <dt class="meta_comment"><a href="<?php echo $value['log_url']; ?>#comment-post">抢沙发</a></dt>
         <dd><?php editflg($value['logid'],$value['author']); ?></dd>
      </dl>	
      <div class="post_content_wrapper clearfix">
       <h2><?php echo $log_title; ?></h2>
       <div class="post_content">
        <?php echo $log_content; ?>
       </div>
	   <p class="att"><?php blog_att($logid); ?></p>
      </div>
    </div>
</div>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
<!--end content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>