<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="contents">
<div id="left_col">
<div class="hots">
	<?php 
    $Log_Model = new Log_Model();
    $hotlogs = $Log_Model->getLogsForHome("ORDER BY views DESC,date DESC", 1, 8);?>
	<ul>
	<?php foreach($hotlogs as $value): ?>
		<li><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo subString($value['log_title'],0,55);?></a></li>
		<?php endforeach;?>	
	</ul>
	<strong>Hot</strong>
</div>
<div class="clear"></div>
<?php foreach($logs as $value): ?>    
<div class="post_even">
    <div class="post clearfix">
      <div class="post_content_wrapper">
       <h2 class="title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
       <div class="post_content">
        <?php echo $value['log_description']; ?>
       </div>
      </div>
      <dl class="post_meta">
        <dt class="meta_date"><?php echo gmdate('Y', $value['date']); ?></dt>
         <dd class="post_date"><?php echo gmdate('n', $value['date']); ?><span>/<?php echo gmdate('j', $value['date']); ?></span></dd>
         <dt>分类：</dt>
         <dd><br /><?php blog_sort($value['logid']); ?></dd>
         <dt>TAGS</dt>
		 <dd><br /><?php blog_tag($value['logid']); ?></dd>        
        <dt class="meta_comment"><a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?>条评论</a></dt>
        <dd><?php editflg($value['logid'],$value['author']); ?></dd>
      </dl>
    </div>
</div>    	
<?php endforeach; ?>
<div id="pagenavi"><?php echo $page_url;?></div>
</div>
<!--end content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>