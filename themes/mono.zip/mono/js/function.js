/*
 *Author:Jimco
 *Url:http://www.xiejiancong.com/
 */
 /** Smiles and toggle **/
$(function(){$(".title-list ul").children("li").each(function(a){$(this).mousemove(function(){$(".content-list").each(function(b){b==a?$(this).slideDown():$(this).slideUp()})})});$(".logo").click(function(){var a=$(this).css("left")=="20px"?($.browser.msie?document.compatMode=="CSS1Compat"?document.documentElement.clientWidth:document.body.clientWidth:self.innerWidth)-178:20;$(this).animate({left:a+"px"},1E3)});$("#smiles img").click(function(){var a=$(this).attr("id");$("#comment").insertAtCaret("|"+
a+"|")});$(document).keypress(function(a){(a.ctrlKey&&a.which==13||a.which==10)&&$("#comment_submit").click()})});function toggleInput(){$("#userinfo").toggle("normal");return!1};
(function(q){q.fn.extend({insertAtCaret:function(a){var c=
q(this)[0];if(document.selection)this.focus(),sel=document.selection.createRange(),sel.text=a,this.focus();else if(c.selectionStart||c.selectionStart=="0"){var h=c.selectionStart,g=c.selectionEnd,i=c.scrollTop;c.value=c.value.substring(0,h)+a+c.value.substring(g,c.value.length);this.focus();c.selectionStart=h+a.length;c.selectionEnd=h+a.length;c.scrollTop=i}else this.value+=a,this.focus()}})})(jQuery);

