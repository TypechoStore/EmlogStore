<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="contents" class="clearfix">
<div id="left_col">
<div class="post_even">
    <div class="post clearfix">
      <dl class="post_meta">
        <dt class="meta_date"><?php echo gmdate('Y', $date); ?></dt>
         <dd class="post_date"><?php echo gmdate('n', $date); ?><span>/<?php echo gmdate('j', $date); ?></span></dd>
         <dt>分类：</dt>
         <dd><br /><?php blog_sort($logid); ?></dd>
         <dt>TAGS</dt>
		 <dd><br /><?php blog_tag($logid); ?></dd>      
         <dt class="meta_comment"><a href="<?php echo $value['log_url']; ?>#comment-post">抢沙发</a></dt>
         <dd><?php editflg($value['logid'],$value['author']); ?></dd>
      </dl>	  
      <div class="post_content_wrapper clearfix">
       <h2><?php topflg($top); ?><a><?php echo $log_title; ?></a></h2>
	   <?php include View::getView('saying');?>
       <div class="post_content">
        <?php echo $log_content; ?>
       </div>
	   <p class="att"><?php blog_att($logid); ?></p>
	   <?php doAction('log_related', $logData); ?>
	   <div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	   <?php blog_trackback($tb, $tb_url, $allow_tb); ?>
      </div>
    </div>
	<?php blog_comments($comments); ?>
    <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
</div>
<!--end content-->
<?php
 include View::getView('widgets');
 include View::getView('footer');
?>