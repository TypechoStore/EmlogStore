<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>
<div id="footer">
<div class="left">
<p>Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">emlog</a> | Theme by <a href="http://www.xiejiancong.com" target="_blank">Jimco</a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a></p>
<?php echo $footer_info; ?>
<?php doAction('index_footer'); ?>
</div>
<div id="return_top"><a href="#wrapper"></a></div>
</div>
<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.2.6.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/function.js" type="text/javascript"></script>
</body>
</html>