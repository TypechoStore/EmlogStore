<?php
/*
Template Name:清爽蓝色天空第二版
Description:在第一版的基础上做了一些改动和优化。
Version:2.0
Author:蓝叶
Author Url:http://lanyes.org
Sidebar Amount:1
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="<?php echo BLOG_URL; ?>" />
<title><?php echo $site_title; ?></title>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>master.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body><div id="bgbox" style="position:absolute; width:100%; height:100%; z-index:-1">
<img style="position:fixed;" src="<?php echo TEMPLATE_URL; ?>images/skin01.jpg" height="100%" width="100%" /></div> 
<div id="header" class="w">
		<h1 class="logo"><a href="<?php echo BLOG_URL; ?>" title="<?php echo $bloginfo; ?>"><IMG alt="<?php echo $blogname; ?>" src="<?php echo TEMPLATE_URL; ?>images/logo.png" /></A></h1>
		<div id="menu"><?php blog_navi();?></div>
		<div class="clear"></div>
</div>
<div id="main" class="w">