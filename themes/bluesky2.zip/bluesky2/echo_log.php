<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<ul>
<li>
	<h2 class="content_h2"><?php topflg($top); ?><?php echo $log_title; ?></h2>
	<div class="act"><span id="shouadmin"><?php blog_author($author); ?></span> <span id="shoufenlei"><?php blog_sort($logid); ?></span> <span id="shoutime"><?php echo gmdate('Y-n-j G:i'); ?></span></div>
	<div class="editor"><?php editflg($logid,$author); ?></div>
	<div class="clear line"></div>
	<div class="post"><?php echo $log_content; ?></div>
	<div class="fujian"><?php blog_att($logid); ?></div>
	<div class="tag echo_tag"><span id="shoutag"><?php blog_tag($logid); ?></span> <span id="shouliulan">浏览：<?php echo $views; ?></span> </div>
    
	<?php doAction('log_related', $logData); ?>
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>

	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</li>
</ul>
</div>
<!--end content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>