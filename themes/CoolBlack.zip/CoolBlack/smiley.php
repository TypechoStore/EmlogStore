﻿<?php 
/**
 * 评论表情管理
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<a href="javascript:grin('[S1]')" title="挤眼"><img src="<?php echo TEMPLATE_URL; ?>image/face/1.gif" alt="挤眼"/></a>
<a href="javascript:grin('[S2]')" title="亲亲"><img src="<?php echo TEMPLATE_URL; ?>image/face/2.gif" alt="亲亲"/></a>
<a href="javascript:grin('[S3]')" title="咆哮"><img src="<?php echo TEMPLATE_URL; ?>image/face/3.gif" alt="咆哮"/></a>
<a href="javascript:grin('[S4]')" title="开心"><img src="<?php echo TEMPLATE_URL; ?>image/face/4.gif" alt="开心"/></a>
<a href="javascript:grin('[S5]')" title="想想"><img src="<?php echo TEMPLATE_URL; ?>image/face/5.gif" alt="想想"/></a>
<a href="javascript:grin('[S6]')" title="可怜"><img src="<?php echo TEMPLATE_URL; ?>image/face/6.gif" alt="可怜"/></a>
<a href="javascript:grin('[S7]')" title="糗大了"><img src="<?php echo TEMPLATE_URL; ?>image/face/7.gif" alt="糗大了"/></a>
<a href="javascript:grin('[S8]')" title="委屈"><img src="<?php echo TEMPLATE_URL; ?>image/face/8.gif" alt="委屈"/></a>
<a href="javascript:grin('[S9]')" title="哈哈"><img src="<?php echo TEMPLATE_URL; ?>image/face/9.gif" alt="哈哈"/></a>
<a href="javascript:grin('[S10]')" title="小声点"><img src="<?php echo TEMPLATE_URL; ?>image/face/10.gif" alt="小声点"/></a>
<a href="javascript:grin('[S11]')" title="右哼哼"><img src="<?php echo TEMPLATE_URL; ?>image/face/11.gif" alt="右哼哼"/></a>
<a href="javascript:grin('[S12]')" title="左哼哼"><img src="<?php echo TEMPLATE_URL; ?>image/face/12.gif" alt="左哼哼"/></a>
<a href="javascript:grin('[S13]')" title="疑问"><img src="<?php echo TEMPLATE_URL; ?>image/face/13.gif" alt="疑问"/></a>
<a href="javascript:grin('[S14]')" title="坏笑"><img src="<?php echo TEMPLATE_URL; ?>image/face/14.gif" alt="坏笑"/></a>
<a href="javascript:grin('[S15]')" title="赚钱啦"><img src="<?php echo TEMPLATE_URL; ?>image/face/15.gif" alt="赚钱啦"/></a>
<a href="javascript:grin('[S16]')" title="悲伤"><img src="<?php echo TEMPLATE_URL; ?>image/face/16.gif" alt="悲伤"/></a>
<a href="javascript:grin('[S17]')" title="耍酷"><img src="<?php echo TEMPLATE_URL; ?>image/face/17.gif" alt="耍酷"/></a>
<a href="javascript:grin('[S18]')" title="勾引"><img src="<?php echo TEMPLATE_URL; ?>image/face/18.gif" alt="勾引"/></a>
<a href="javascript:grin('[S19]')" title="厉害"><img src="<?php echo TEMPLATE_URL; ?>image/face/19.gif" alt="厉害"/></a>
<a href="javascript:grin('[S20]')" title="握手"><img src="<?php echo TEMPLATE_URL; ?>image/face/20.gif" alt="握手"/></a>
<a href="javascript:grin('[S21]')" title="耶"><img src="<?php echo TEMPLATE_URL; ?>image/face/21.gif" alt="耶"/></a>
<a href="javascript:grin('[S22]')" title="嘻嘻"><img src="<?php echo TEMPLATE_URL; ?>image/face/22.gif" alt="嘻嘻"/></a>
<a href="javascript:grin('[S23]')" title="害羞"><img src="<?php echo TEMPLATE_URL; ?>image/face/23.gif" alt="害羞"/></a>
<a href="javascript:grin('[S24]')" title="鼓掌"><img src="<?php echo TEMPLATE_URL; ?>image/face/24.gif" alt="鼓掌"/></a>
<a href="javascript:grin('[S25]')" title="馋嘴"><img src="<?php echo TEMPLATE_URL; ?>image/face/25.gif" alt="馋嘴"/></a>
<a href="javascript:grin('[S26]')" title="抓狂"><img src="<?php echo TEMPLATE_URL; ?>image/face/26.gif" alt="抓狂"/></a>
<a href="javascript:grin('[S27]')" title="抱抱"><img src="<?php echo TEMPLATE_URL; ?>image/face/27.gif" alt="抱抱"/></a>
<a href="javascript:grin('[S28]')" title="围观"><img src="<?php echo TEMPLATE_URL; ?>image/face/28.gif" alt="围观"/></a>
<a href="javascript:grin('[S29]')" title="威武"><img src="<?php echo TEMPLATE_URL; ?>image/face/29.gif" alt="威武"/></a>
<a href="javascript:grin('[S30]')" title="给力"><img src="<?php echo TEMPLATE_URL; ?>image/face/30.gif" alt="给力"/></a>