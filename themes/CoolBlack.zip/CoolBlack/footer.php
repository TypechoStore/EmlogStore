<footer>
<?php if(_g(footer_link)==1)bottom_link(); ?>
<div class="footer-bottom">
	<!--请尊重作者，保留主题版权-->
	<p>Powered by <a href="http://www.emlog.net" title="采用emlog系统" target="_blank">emlog</a> Theme by <a href="http://ilt.me" target="_blank">IT技术宅</a></p>
    <p>Copyright @ 2015 IT技术宅 版权所有 备案<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a></p> 
<p>个人博客免責：本站文章內容出自原创和互联网, 如有侵权请通知,将不负责任何法律责任  </p>
  </div>
</footer>
 <?php doAction('index_footer'); ?>
</body></html>