<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="mask"></div>
<a href="#top" id="top-link" class="no-click no-print"><img src="<?php echo TEMPLATE_URL; ?>images/top.png" /></a>
<div id="top">
<div id=pageflip>
    <a href="<?php echo BLOG_URL; ?>rss.php" target="_blank">
        <img src="<?php echo TEMPLATE_URL; ?>images/page_flip.png">
    </a>
    <div class=msg_block></div>
</div>
</div>
<div class="dawn">
	<div id="nav">
		<div id="content">
			<div class="inhear">
				<div class="shupi"></div>
				<div class="name"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></div>
				<div class="clear"></div>
				<div class="des"><?php echo $bloginfo; ?></div>
				<div class="clear"></div>
				<div class="chuban"><?php echo BLOG_URL; ?></div>
				<div class="clear"></div>
				<div id="read"><a href="<?php echo BLOG_URL; ?>">开始阅读 Go ->></a></div>
			</div>
		</div>
	</div>
	<div class="dawnfoot"></div>
</div>


<div class="dawn">

	<div class="ind">
		<?php blog_navi();?>
		<div id="search">
			<form id="searchform" name="keyform" action="<?php echo BLOG_URL; ?>" method="get" >
			<input type="text" name="keyword" id="s" />
			</form>
		</div>
	</div>
	
	<div id="nav">
		<div id="content">
			<div class="inhear">
				<div class="mulu">

				</div>
				<div class="mulupshang"></div>
				<div id="mulup">
<?php doAction('index_loglist_top'); ?>
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
					<div class="title">
<?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/right.png" style="float:left;margin-top:5px;" />&nbsp;<?php echo $value['log_title']; ?></a>
						<div class="titletime"><?php echo gmdate('Y-n-j', $value['date']); ?> </div>
                    </div>
					<div class="title1">
<?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/right.png" style="float:left;margin-top:5px;" />&nbsp;<?php echo $value['log_title']; ?></a>
						<div class="titletime"><?php echo gmdate('Y-n-j', $value['date']); ?> & Comments：<?php echo $value['comnum']; ?></div>
                    </div>
					<div class="deslog">
						<?php echo $value['log_description']; ?>
                        <div class="readmore1"><a href="<?php echo $value['log_url']; ?>">[继续阅读...]</a></div>
                    </div>
<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
				</div>
				<div class="mulupxia"></div>
				<div id="pagenavi1">
					<?php echo $page_url;?>
                </div>
			</div>
		</div>
	</div>
	<div class="dawnfoot"></div>
</div>
<?php
 include View::getView('footer');
?>