<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="mask"></div>
<a href="#top" id="top-link" class="no-click no-print"><img src="<?php echo TEMPLATE_URL; ?>images/top.png" /></a>
<div id="top">
<div id=pageflip>
    <a href="<?php echo BLOG_URL; ?>rss.php" target="_blank">
        <img src="<?php echo TEMPLATE_URL; ?>images/page_flip.png">
    </a>
    <div class=msg_block></div>
</div>
</div>
<div class="dawn">
	<div class="ind">
		<?php blog_navi();?>
		<div id="search">
			<form id="searchform" name="keyform" action="<?php echo BLOG_URL; ?>" method="get" >
			<input type="text" name="keyword" id="s" />
			</form>
		</div>
	</div>
    <div id="nav">
		<div id="content">
			<div class="inhear">
				<div class="ntop">
					<div class="fenlei"><img src="<?php echo TEMPLATE_URL; ?>images/fenlei.png" /><span><?php echo $log_title; ?></span></div>
				</div>
				<div class="logname">
					<b><?php topflg($top); ?><?php echo $log_title; ?></b>
				</div>
				<div class="lognamexia"></div>
				<div class="nlog"><?php echo $log_content; ?></div>
				<div class="lognameshang"></div>
				<div class="nfoot">
					<span style="float:right; margin-right:30px;">最终解释权归本博客博主所有</span>
				</div>
			</div>
		</div>
	</div>
	<div class="dawnfoot"></div>	
</div>
<div id="comments">
	<div class="comlist">
		<div id="comtop"><a href="#respond" ></a></div>
		<div id="commentsep"></div>
<?php blog_comments($comments); ?>
	</div>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
<?php
 include View::getView('footer');
?>