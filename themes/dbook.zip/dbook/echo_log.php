<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="mask"></div>
<a href="#top" id="top-link" class="no-click no-print"><img src="<?php echo TEMPLATE_URL; ?>images/top.png" /></a>
<div id="top">
<div id=pageflip>
    <a href="<?php echo BLOG_URL; ?>rss.php" target="_blank">
        <img src="<?php echo TEMPLATE_URL; ?>images/page_flip.png">
    </a>
    <div class=msg_block></div>
</div>
</div>
<div class="dawn">
	<div class="ind">
		<?php blog_navi();?>
		<div id="search">
			<form id="searchform" name="keyform" action="<?php echo BLOG_URL; ?>" method="get" >
			<input type="text" name="keyword" id="s" />
			</form>
		</div>
	</div>
    <div id="nav">
		<div id="content">
			<div class="inhear">
				<div class="ntop">
					<div class="fenlei"><img src="<?php echo TEMPLATE_URL; ?>images/fenlei.png" /><span><?php blog_sort($logid); ?></span></div>
					<div class="ndes">
						<img src="<?php echo TEMPLATE_URL; ?>images/date.png" /><span><?php echo gmdate('Y-n-j', $date); ?></span>
						<img src="<?php echo TEMPLATE_URL; ?>images/view.png" /><span><?php echo $views; ?></span>
						<img src="<?php echo TEMPLATE_URL; ?>images/pinglun.png" /><span><a href="#respond"><?php echo $comnum; ?></a></span>	
						&nbsp;&nbsp;				
					</div>
				</div>
				<div class="logname">
					<b><?php topflg($top); ?><?php echo $log_title; ?></b>
				</div>
				<div class="lognamexia"></div>
				<div class="nlog"><?php echo $log_content; ?></div>
				<div class="lognameshang"></div>
				<div class="nfoot">
<?php neighbor_log($neighborLog); ?>				
				</div>
			</div>
		</div>
	</div>
	<div class="dawnfoot"></div>	
</div>
<div id="comments">
	<div class="comlist">
		<div id="comtop"><a href="#respond" ></a></div>
		<div id="commentsep"></div>
<?php blog_comments($comments); ?>
	</div>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
<?php
 include View::getView('footer');
?>