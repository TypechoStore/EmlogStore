var skyscrollSpeed = 120;
var skystep = 1;
var skycurrent = 0;
var skyimageWidth = 2247;
var skyheaderWidth = 800;   
var skyrestartPosition = -(skyimageWidth - skyheaderWidth);
function scrollsky(){
	skycurrent -= skystep;
	if (skycurrent == skyrestartPosition){
		skycurrent = 0;
	}
	$('#top,#foot').css("background-position",skycurrent+"px 0");
}
var skyinit = setInterval("scrollsky()", skyscrollSpeed);


$(document).ready(function() {
    $("#read a,.name a,.title a,.nfoot a:first,.fenlei a").hover(function() {
        $(this).animate({ paddingLeft: "20px" }, { queue: false, duration: 500 });
    }, function() {
        $(this).animate({ paddingLeft: "0" }, { queue: true, duration: 500 });
    });
});


$(document).ready(function() {
    $(".nfoot a:last").hover(function() {
        $(this).animate({ paddingRight: "20px" }, { queue: false, duration: 500 });
    }, function() {
        $(this).animate({ paddingRight: "0" }, { queue: true, duration: 500 });
    });
});

$(document).ready(function() {
    $(".ind li").hover(function() {
        $(this).animate({ width: "142px" }, { queue: false, duration: 500 });
    }, function() {
        $(this).animate({ width: "60px" }, { queue: true, duration: 500 });
    });
});



var str=location.href; //ȡ��������ַ��
if(str==url){
	
$(document).ready(function(){
$(".dawn:first").show(); 

$(".name a,#read a").click(function(){
$(".dawn:visible").slideUp("slow");
$(".dawn:last").slideDown("slow");
return false;
});
 });

}else
{
$(document).ready(function(){
$(".dawn:first").hide(); 

$(".dawn:last").slideDown("slow");

$("#pagenavi1 a:contains('1')").attr("href","?page=1");

 });

}


$(document).ready(function(){
$(".deslog:not(:first)").hide(); 
$(".title1:not(:first)").hide();
$(".title1:first").show();
$(".title:first").hide();
//���� dd���ǵ�һ����. E:first:�൱��E:eq(0) 
// $("dd:not(:last)").hide();  //����$("dd:not(:last)").hide();
$(".deslog:first").slideDown("slow");
$(".title a").click(function(){
$(".deslog:visible").slideUp("slow");
$(this).parent().next().next().slideDown("slow");
$(".title:hidden").show();
$(".title1:visible").hide();
$(this).parent().hide();

$(this).parent().next().show();


return false;
});
 });





$(function(){
  $('.readmore1 a,.title1 a').click(function(e){
     e.preventDefault();
    var htm='Opening',i=9,
      t=$(this).html(htm).unbind('click');
    (function ct(){
      i<0?(i=9,t.html(htm),ct()):(t[0].innerHTML+='.',i--,setTimeout(ct,200));
    })();
    window.location=this.href;//opera fixed
  });
});


$(function(){
	
		$(".comment-children:odd").addClass ("childrenh");

});

$(".s1").focus(function() { 
    $(this).animate({ width: "250px"}, 1000); 
}).blur(function() { 
    $(this).animate({ width: "160px"}, 1000); 
});

$("#s").focus(function() { 
    $(this).animate({ width: "100px"}, 1000); 
}).blur(function() { 
    $(this).animate({ width: "5px"}, 1000); 
});

$(document).ready(function(){
$("#author1").addClass("author11");
$("#author1").focus(function(){
	$(this).removeClass("author11").addClass("author22").blur(function(){
			if($(this).val()==""){
				$(this).removeClass("author22").addClass("author11");
				}													   
		});
	});
});
$(document).ready(function(){
$("#email1").addClass("email11");
$("#email1").focus(function(){
	$(this).removeClass("email11").addClass("email22").blur(function(){
			if($(this).val()==""){
				$(this).removeClass("email22").addClass("email11");
				}													   
		});
	});
});
$(document).ready(function(){
$("#url1").addClass("url11");
$("#url1").focus(function(){
	$(this).removeClass("url11").addClass("url22").blur(function(){
			if($(this).val()==""){
				$(this).removeClass("url22").addClass("url11");
				}													   
		});
	});
});

/*����*/
$(document).ready(function(){
	$("#pageflip").hover(function() {
		$("#pageflip img , .msg_block").stop()
			.animate({
				width: '307px', 
				height: '319px'
			}, 500); 
		} , function() {
		$("#pageflip img").stop() 
			.animate({
				width: '50px', 
				height: '52px'
			}, 220);
		$(".msg_block").stop() 
			.animate({
				width: '50px', 
				height: '50px'
			}, 200);
	});	
});