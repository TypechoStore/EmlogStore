<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="clear"></div>
<div id="foot">	
	<div class="footc">
		Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> | Themes by By <a href="http://www.lwdaixie.com" id="dbook">鲁韵</a> | <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> | Copyright 2013
<!--[if lte IE 6]>
<script src="http://letskillie6.googlecode.com/svn/trunk/letskillie6.zh_CN.pack.js "></script>
<![endif]-->
<link href="<?php echo TEMPLATE_URL; ?>phzoom.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/phzoom.js"></script>
<script type="text/javascript">
jQuery(document).ready(function($){$("a[href$=jpg],a[href$=gif],a[href$=png],a[href$=jpeg],a[href$=bmp]").phzoom({});}); 
</script>
	</div>
</div> 
<?php doAction('index_footer'); ?>
<script> url="<?php echo BLOG_URL; ?>"; </script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/top.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.scrollTo-1.4.0-min.js"></script>
<script type="text/javascript">
//plugin
jQuery.fn.topLink = function(settings) {
	settings = jQuery.extend({
		min: 1,
		fadeSpeed: 300
	}, settings);
	return this.each(function() {
		//listen for scroll
		var el = $(this);
		el.hide(); //in case the user forgot
		$(window).scroll(function() {
			if($(window).scrollTop() >= settings.min)
			{
				el.fadeIn(settings.fadeSpeed);
			}
			else
			{
				el.fadeOut(settings.fadeSpeed);
			}
		});
	});
};

//usage w/ smoothscroll
$(document).ready(function() {
	//set the link
	$('#top-link').topLink({
		min: 400,
		fadeSpeed: 300
	});
	//smoothscroll
	$("#mask").animate({opacity:0.7});
	$('#top-link').click(function(e) {
		e.preventDefault();
		$("#mask").fadeIn(500);
		setTimeout(function() {
           $.scrollTo('#top',500);
        }, 500);	
		$("#mask").delay(500).fadeOut(500);
	});
});

$(document).ready(function() {

	$('#comtop a,.ndes a:first').click(function(e) {
		e.preventDefault();
		$("#mask").fadeIn(500);
		setTimeout(function() {
            $.scrollTo('#foot',500);
        }, 500);
		$("#mask").delay(500).fadeOut(500);
	});

});
</script>
</body>
</html>