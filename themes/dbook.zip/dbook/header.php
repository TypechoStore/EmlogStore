<?php
/*
Template Name:定制模板
Description:仿9339浮云个性模板
Version:1.2
Author:erx@qq.com
Author Url:http://www.ewceo.com
Sidebar Amount:0
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
if(function_exists('emLoadJQuery')) {
    emLoadJQuery();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>reset.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>dawn.css" rel="stylesheet" type="text/css" /> 
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/lazyload.js"></script>
<script type="text/javascript">
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?"":e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('A(d).r(5(6){6("\\8\\1\\D\\1\\f\\1\\h\\7\\3\\c\\9").x({w:"\\i\\1\\4\\2\\y\\z",M:"\\O\\p\\g\\a\\g\\7\\2\\o\\a\\0\\7\\v\\u\\N\\K\\n\\H\\v\\u\\G\\J\\E\\n\\I\\7\\p\\L\\3\\c\\1\\9\\2\\F\\e\\9\\h\\2\\C\\8\\9\\3\\i",B:P})});$(d).r(5(){$("\\m\\4\\j\\0\\0\\k").16(5(){$(17).18("\\a\\h\\2\\i","\\a\\f\\f\\g\\13\\e\\e\\b\\b\\b\\8\\14\\b\\4\\1\\3\\1c\\3\\2\\8\\o\\0\\c");$("\\m\\4\\j\\0\\0\\k").1d("\\1e\\19")})});5 l(6){1a t=d.1b(6);s(t){q 12}T{q U}};$(5(){s(!l("\\4\\j\\0\\0\\k"))V("\\Q\\R\\S\\Z\\10\\11\\W\\X\\Y\\15")})',62,77,'x6f|x61|x65|x69|x64|function|dbook1|x20|x2e|x67|x68|x77|x6d|document|x2f|x74|x70|x72|x66|x62|x6b|dbook0|x23|x4c|x63|x3f|return|ready|if|dbook2|x45|x54|effect|lazyload|x49|x6e|jQuery|threshold|x79|x76|x52|x73|x5f|x41|x3b|x55|x50|x3e|placeholder|x4d|x3c|200|u8bf7|u52ff|u4fee|else|false|alert|u4f5c|u8005|u4fe1|u6539|u6a21|u677f|true|x3a|x6c|u606f|each|this|attr|u97f5|var|getElementById|x78|html|u9c81'.split('|'),0,{}))
</script>
</head>
<!--[if lt IE 7]>
<style type="text/css">
.dawn,#top,#foot,.dawnfoot,.comshadow,{display:none;} //隐藏页面其他元素
#ie{display:block;}     //对IE显示特定模块
</style>
<div id="ie">
  <div id="ie-body">
	  <div class="red">
		  <p><br />欢迎光临本站</p>
		  <p>您正在使用一个落后的浏览器浏览网页</p>
		  <p>本站无法在 IE 7 以下版本的 IE 系列浏览器中正常访问。</p>
		  <p>为了获得更好的浏览体验, 请升级到更高级的浏览器</p>
		  <p>如果您升级到 Internet Explorer 8 或转换到另一些浏览器，本站将能为您提供更好的服务。</p>
		  <p>本站推荐使用以下浏览器：Firefox, Chrome, Opera, Safari </p>
		  <p><br>Copyright &copy; 2013. All Rights Reserved.</p>
       </div>
  </div>
</div>
<![endif]-->
<body>
