<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="top">
<div id=pageflip>
    <a href="<?php echo BLOG_URL; ?>rss.php" target="_blank">
        <img src="<?php echo TEMPLATE_URL; ?>images/page_flip.png">
    </a>
    <div class=msg_block></div>
</div>
</div>
<div class="dawn">
	<div class="ind">
		<?php blog_navi();?>
		<div id="search">
			<form id="searchform" name="keyform" action="<?php echo BLOG_URL; ?>" method="get" >
			<input type="text" name="keyword" id="s" />
			</form>
		</div>
	</div>
    <div id="nav">
		<div id="content">
			<div class="inhear">
				<div class="ntop">
					<div class="fenlei"><img src="<?php echo TEMPLATE_URL; ?>images/fenlei.png" /><span><?php blog_sort($logid); ?></span></div>

				</div>
				<div class="logname">
					<b><?php topflg($top); ?><?php echo $log_title; ?></b>
				</div>
				<div class="lognamexia"></div>
				<div class="nlog">该模板没有提供当前功能</div>
				<div class="lognameshang"></div>
				<div class="nfoot">
			
				</div>
			</div>
		</div>
	</div>
	<div class="dawnfoot"></div>	
</div>
<?php
 include View::getView('footer');
?>