<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
	<div id="postlist">
	<?php doAction('index_loglist_top'); ?>
    <?php foreach($logs as $value): ?>
		<div class="post-home">
		<div class="post-title"><h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2></div>
		<div class="post-content">
				<?php echo $value['log_description']; ?>
				<div class="clear"></div>
		</div>
		<div class="post-messages"><div class="post-messages-1"><?php blog_author($value['author']); ?>/<?php echo gmdate('Y-m-d', $value['date']); ?> / 标签: <?php blog_tag($value['logid']); ?> / 分类: <?php blog_sort($value['logid']); ?></div></div>
		<div class="post-messages-2"><a href="<?php echo $value['log_url']; ?>#comments" class="CommentsNumber"><?php if($value['comnum']==0){echo '抢沙发';}elseif($value['comnum']==1){echo '1条评论';}else{echo $value['comnum'].'条评论';} ?></a></div>
		</div> 
	<?php endforeach; ?>
		<div class="pagenavi"><?php echo $page_url;?></div>
	</div>

<div class="clear">
</div>

<?php
 include View::getView('footer');
?>