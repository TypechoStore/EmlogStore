<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content"><div class="mbx-dh"></div><div id="postlist">
    <ul>
    <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];	$img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?> 
    <li class="li">
    <div class="post-home-state">	<div class="post-messages-2-state"><?php echo $val['date'];?> </div>	<div class="post-content"><img class="avatar" src="<?php echo $avatar; ?>" width="28px" height="28px" /><p><?php echo $val['t'].'<br/>'.$img;?></p></div>	</div>
    <div style="clear:both;"></div>
   	<ul id="r_<?php echo $tid;?>" class="r"></ul>
    </li>
    <?php endforeach;?>
    </ul>
    	<div class="pagenavi"><?php echo $pageurl;?></div></div>	
<!--end content--><?php include View::getView('footer');?>