<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div class="mbx-dh">
</div>
	<div id="postlist">
		<div class="post-single">
			<?php if($log_title=="标签"): ?>
            <?php global $CACHE;
             $tag_cache = $CACHE->readCache('tags');?>
		<div class="post-title"><h2><?php echo $log_title; ?></h2></div>
		<div class="post-content">
				 <?php shuffle($tag_cache); ?>
                 <?php foreach($tag_cache as $value): ?>
                 <span style="font-size:<?php echo $value['fontsize']; ?>pt; line-height:30px;">
                 <a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇日志" style="color:rgb(<?php echo(rand(0,255)); ?>,<?php echo(rand(0,255)); ?>,<?php echo(rand(0,255)); ?>)"><?php echo $value['tagname']; ?></a></span>
                 <?php endforeach; ?>
		</div>
		<?php else: ?>
		<div class="post-title"><h2><?php echo $log_title; ?></h2></div>
		<div class="post-content"><?php echo $log_content; ?><div class="clear"></div></div>
		<?php endif; ?>
		</div>
		<div id="comments">
		<?php blog_comments($comments,$params); ?>
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
		</div>
	</div>
<?php
 include View::getView('footer');
?>