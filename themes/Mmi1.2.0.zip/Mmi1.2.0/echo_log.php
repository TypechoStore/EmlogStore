<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div class="mbx-dh">
<a href="<?php echo BLOG_URL; ?>">Home</a> » <?php blog_sort($logid); ?> » <?php echo $log_title; ?>
</div>
	<div id="postlist">
		<div class="post-single">
			<div class="post-title"><h2><?php topflg($top); ?><?php echo $log_title; ?></h2></div>
			<div class="post-content"><?php echo $log_content; ?><div class="clear"></div><span class="more-link"><?php editflg($logid,$author); ?></span></div>
			<!--分享条,想加自己加 <div class="post_share"></div> -->
			<div class="post_share"><?php blog_att($logid); ?></div>
			<div class="post-messages"><div class="post-messages-1"><?php echo gmdate('Y-n-j G:i l', $date); ?> / 标签: <?php blog_tag($logid); ?> / 分类: <?php blog_sort($logid); ?></div>
			<div class="post-messages-2"><?php blog_author($author); ?></div>
		</div>
	</div>

	<div id="comments">
	<?php blog_comments($comments,$params); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
	</div>
	</div>
<?php
 include View::getView('footer');
?>