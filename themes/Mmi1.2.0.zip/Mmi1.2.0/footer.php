<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="clear">
</div></div>
	<div class="footer_links">
				<ul><?php widget_link(''); ?></ul>
     </div>
	 <div class="copyright">All rights reserved. Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> . Theme Mmi by <a href="http://maizihuakai.com">麦子花开</a>. Translate by <a href="http://iuuuu.net">ooxx</a>.<?php echo $footer_info; ?></div>
<?php doAction('index_footer'); ?>
</div>
<!--[if ie 6]>
	<script src="http://letskillie6.googlecode.com/svn/trunk/letskillie6.zh_CN.pack.js"></script>
<![endif]-->
</body>
</html>