<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>
<!-- content end -->
<div id="footer">
<div class="footer_mid">
<span class="wplogo"><a href="http://www.emlog.net/" target="_blank" title="Powerd by emlog <?php echo Option::EMLOG_VERSION;?>">Emlog <?php echo Option::EMLOG_VERSION;?></a></span>
<span>Copyright &copy; 2012 <?php echo $blogname; ?>. Theme by <a href="http://www.alanoy.com" target="_blank">Alan Ouyang</a> ＆<a href="http://www.loek.us" title="由loekman移植" target="_blank">loekman</a>. <?php echo $footer_info; ?></span>
<span class="go_top"><a href="#header">Go Top</a></span>
</div>
<?php doAction('index_footer'); ?>
</div>
<!-- [footer] -->
</div>
<!-- [wrap] -->
</body>
</html>