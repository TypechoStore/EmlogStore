<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="contentwrap">
  <div class="entry single" id="post-1">
    <h2 class="entrytitle" id="post-1"><?php topflg($top); ?><a><?php echo $log_title; ?></a></h2>
    <div class="entrymeta1">
	<span class="meta-date"><?php echo gmdate('Y-n-j', $date); ?></span>
	<span class="meta-category"><?php blog_sort($logid); ?></span>
	<span class="meta-comment"><a href="#commentform"><?php echo $comnum; ?> 条评论</a></span>
	<?php editflg($logid,$author); ?>
	</div>
    <!-- [entrymeta1] -->
    <div class="entrybody">
    <p>
	<?php echo $log_content; ?>
    </p>
	<div class="entrymeta2">
	<span class="single_tags">
    <?php blog_tag($logid); ?>
    </span>
	</div>
	</div>
<div id="commentblock">
  <div id="commentbox">
    <h3 id="comments">
      <?php echo $comnum; ?> 条评论 / <a href="#commentform">点击此处发表评论</a></h3>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div></div>
  </div>
<div class="clear"></div>
</div>
<?php include View::getView('side'); ?>
<?php include View::getView('footer'); ?>