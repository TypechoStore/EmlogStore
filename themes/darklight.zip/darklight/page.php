<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="contentwrap">
  <div class="entry single" id="post-1">
    <h2 class="entrytitle" id="post-1"><a><?php echo $log_title; ?></a></h2>
    <div class="entrymeta1">
	<span class="meta-comment"><a href="#commentbox">发表评论</a></span>
	<?php editflg($logid,$author); ?>
	</div>
    <!-- [entrymeta1] -->
    <div class="entrybody">
	<?php echo $log_content; ?>
	</div>
<div id="commentblock">
  <div id="commentbox">
    <h3 id="comments">
      <?php echo $comnum; ?> 条评论 / <a href="#commentform">点击此处发表评论</a></h3>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div></div>
  </div>
<div class="clear"></div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>