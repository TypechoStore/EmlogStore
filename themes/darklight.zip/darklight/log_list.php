<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="contentwrap">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
  <div class="entry">
    <h2 class="entrytitle" id="post-1"><?php topflg($value['top']); ?><a title="<?php echo $value['log_title']; ?> 的永久链接" href="<?php echo $value['log_url']; ?>" rel="bookmark">
      <?php echo $value['log_title']; ?>
      </a></h2>
    <div class="entrymeta1">
	<span class="meta-date"><?php echo gmdate('Y-n-j', $value['date']); ?></span>
	<span class="meta-category"><?php blog_sort($value['logid']); ?></span>
	<span class="meta-comment"><a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?> 条评论</a></span>
	<?php editflg($value['logid'],$value['author']); ?>
	</div>
    <!-- [entrymeta1] -->
    <div class="entrybody"><p> <?php echo $value['log_description']; ?> </p></div>
    <!-- [entrybody] -->
    <div class="entrymeta3">
	<span class="single_tags"><?php blog_tag($value['logid']); ?></span>
	</div>
  </div>
<?php endforeach; ?>
<div class="clear"></div>
<div class="wp-pagenavi">
<?php echo $page_url;?></div>
</div>

<?php include View::getView('side'); ?>
<?php include View::getView('footer'); ?>