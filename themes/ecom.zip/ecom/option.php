<?php
/*
 * 配置文件
 */

//首页新闻动态分类ID	
$index_list = 1;

//首页新闻动态条数
$index_side_num = 5;

//联系方式
$email = "Email：sales@ewceo.com";
$itel = "电  话：0888-87654321";
$imob = "手  机：18988888888";
$iqq = "Q    Q：<a target='_blank' href='http://wpa.qq.com/msgrd?v=3&uin=12345678&site=qq&menu=yes' title='点击Q我'>12345678</a>";
$ipost = "邮  编：123000";

//固定链接
$abouturl = "http://www.ewceo.com/"; //关于我们
$contacturl = "http://www.ewceo.com/"; //联系我们
$guestbookurl = "http://www.ewceo.com/"; //在线留言
$productsurl = "http://www.ewceo.com/"; //产品展示

?>
