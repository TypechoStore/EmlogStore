<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
        <div id="footer">
            <div class="nav">
			    <a href="<?php echo $guestbookurl; ?>">在线留言</a><span>|</span><a href="<?php echo $abouturl; ?>" title="关于我们">关于我们</a><span>|</span><a href="<?php echo $contacturl; ?>">联系我们</a><span>|</span><a href="javascript://" onclick="AddFavorite(window.location,document.title)">收藏本站</a><span>|</span><a href="<?php echo BLOG_URL; ?>m">网站手机版</a><span>|</span><a href="<?php echo BLOG_URL; ?>rss.php">网站RSS信息</a><span>|</span><a href="<?php echo BLOG_URL; ?>admin/">网站管理</a>
			</div>
            <div class="text">
<a href="<?php echo BLOG_URL; ?>" target="_blank"><?php echo $blogname; ?></a> 版权所有 2012-2013&copy; &nbsp;<a href="http://www.miitbeian.gov.cn" target="_blank"><?php echo $icp; ?></a> All Rights Reserved. &nbsp;<?php echo $footer_info; ?><br />
<!--保留作者信息是种美德，修改模板作者信息可能导致出错，确需去除请联系作者获取拓展版-->
<span>Powered by <a href="http://www.emlog.net" target="_blank" title="emlog <?php echo Option::EMLOG_VERSION;?>"><b>Emlog</b></a>
&nbsp;Themes by <a id="ecom" href="http://www.ewceo.com" target="_blank" title="易玩稀有">ewCEO.com</a></span>
            </div>
        </div>
    </div>
</body>
</html>