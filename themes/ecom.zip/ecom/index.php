<?php 
/*
* 首页[index]
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="main">
    <div id="left">
<div class="Btbutton">
     <a href="<?php echo $contacturl; ?>" title="联系我们" class="lb">
	     <span>CONTACT</span>
		 <br>
		 <b>联系我们</b>
	 </a>
	 <a href="<?php echo $guestbookurl; ?>" title="在线留言" class="rb">
	     <span>GUESTBOOK</span>
		 <br>
		 <b>在线留言</b>
	 </a>
</div>
		<h3 class="title">
		    <a href="<?php echo Url::sort($index_list); ?>" title="More" class="more">More</a>
			<span>新闻动态</span><b>/NEWS</b>
		</h3>
		<ul class="list2">
        	<!--此处调用设置见option.php文件-->
			<?php indexlist($index_list, 'view', $index_side_num, $long="360"); ?>
		</ul>
		<h3 class="titlec">
			<span>联系方式</span>
			<b>CONTACT</b>
		</h3>
		<div class="text editor">
        	<p><strong><?php echo $blogname; ?></strong></p>
            <!--以下各项联系方式在option.php中设置-->
			<p><?php echo $email."<br />".$itel."<br />".$imob."<br />".$iqq."<br />".$ipost; ?></p>
		</div>
	</div>
	<div id="right">
	    <h3 class="title">
		    <a href="<?php echo $abouturl; ?>" title="More" class="more">More</a>
			<span>公司简介</span>
			<b>About Us</b>
		</h3>
		<div class="text">
		    <div class="editor">
			    <p style="padding-top: 2px">
	<strong><img alt="" src="<?php echo TEMPLATE_URL; ?>images/1204452.gif" style="width: 171px; height: 173px; float: left; margin-left: 0px; margin-right: 0px;">关于"为合作伙伴创造价值"</strong><br>
	<?php echo $blogname; ?>认为客户、供应商、公司股东、公司员工等一切和自身有合作关系的单位和个人都是自己的合作伙伴，并只有通过努力为合作伙伴创造价值，才能体现自身的价值并获得发展和成功。</p>
<p>
	<strong>关于"诚实、宽容、创新、服务"</strong><br>
	<?php echo $blogname; ?>认为诚信是一切合作的基础，宽容是解决问题的前提，创新是发展事业的利器，服务是创造价值的根本。</p>
<p>
	<span class="seolabel"><?php echo $blogname; ?></span>主 打产品——EWCEO企业网站管理系统采用PHP+Mysql架构，全站内置了SEO搜索引擎优化机制，支持用户自定义界面语言，拥有企业网站常用的...</p>

			</div>
		</div>
		<h3 class="title line">
		    <a href="<?php echo $productsurl; ?>" title="More" class="more">More</a>
		    <span>产品展示</span>
			<b>Products</b>
		</h3>
		<div class="list" id="caseimg">
		   <div id="indemo">
		    <ul id="demo1">
				<?php slide_pic(6); ?>
		    </ul>
			<ul id="demo2"></ul>
		   </div>	
			<div class="clear"></div>
<script type="text/javascript">
<!--
var speed=20;
var tab=document.getElementById("caseimg");
var tab1=document.getElementById("demo1");
var tab2=document.getElementById("demo2");
tab2.innerHTML=tab1.innerHTML;
function Marquee(){
if(tab2.offsetWidth-tab.scrollLeft<=0)
tab.scrollLeft-=tab1.offsetWidth
else{
tab.scrollLeft++;
}
}
var MyMar=setInterval(Marquee,speed);
tab.onmouseover=function() {clearInterval(MyMar)};
tab.onmouseout=function() {MyMar=setInterval(Marquee,speed)};
-->
</script>
		</div>
	</div>
	<div class="clear"></div>
</div>


<div class="Link Textlink">
     <span>友情链接：</span>
     <ul>
    	<?php 
		global $CACHE; 
		$link_cache = $CACHE->readCache('link');
		foreach($link_cache as $value): ?>
		<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
		<?php endforeach; ?>
        <li><a href="http://www.ewceo.com/">易玩稀有</a></li>
	</ul>
    <div class="clear"></div>
</div>
<?php
 include View::getView('footer');
?>