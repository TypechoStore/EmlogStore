<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
if($pageurl == Url::logPage()){
	include View::getView('index');
	exit;
}
?>
<div id="web">
    <div id="right">
	    <h3 class="title"><span>快速导航</span></h3>
		<div class="webnav"> 
			<div id="web-sidebar">
<?php $sort_cache = $CACHE->readCache('sort');?>
     <?php foreach($sort_cache as $value): ?>
				<dl>
                	<dt><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?></a></dt>
                </dl>
	<?php endforeach; ?>
			</div>
		</div>
		<h3 class="title line"><span>联系方式</span></h3>
		<div class="text">
        	<p><strong><?php echo $blogname; ?></strong></p>
            <!--以下各项联系方式在option.php中设置-->
			<p><?php echo $email."<br />".$itel."<br />".$imob."<br />".$iqq."<br />".$ipost; ?></p>
		</div>
    </div>
    <div id="left">
	    <h3 class="title">
		   <span>您现在的位置：</span>
		   <a href="../" title="首页">首页</a>&nbsp;&gt;&nbsp;
		   <a href="<?php echo Url::sort($index_list); ?>"><?php echo $sortName; ?></a>
		</h3>
		<div class="webcontent">
        	<div id="news_list">
            <ul>
<?php foreach($logs as $value): ?>
                <li><span><?php echo gmdate('Y/n/j', $value['date']); ?></span><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></li>
<?php endforeach; ?>
			</ul> 
         	<div id="pagenavi"><?php echo $page_url;?></div>
        	</div>
	 	</div>
	</div>
    <div class="clear"></div>
</div>
<?php
 include View::getView('footer');
?>