<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="web">
    <div id="right">
	    <h3 class="title"><span>快速导航</span></h3>
		<div class="webnav"> 
			<div id="web-sidebar">
<?php $sort_cache = $CACHE->readCache('sort');?>
     <?php foreach($sort_cache as $value): ?>
				<dl>
                	<dt><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?></a></dt>
                </dl>
	<?php endforeach; ?>
			</div>
		</div>
		<h3 class="title line"><span>联系方式</span></h3>
		<div class="text">
        	<p><strong><?php echo $blogname; ?></strong></p>
            <!--以下各项联系方式在option.php中设置-->
			<p><?php echo $email."<br />".$itel."<br />".$imob."<br />".$iqq."<br />".$ipost; ?></p>
		</div>
    </div>
    <div id="left">
	    <h3 class="title">
		   <span>您现在的位置：</span>
		   <a href="../" title="首页">首页</a>&nbsp;&gt;&nbsp;
		   <?php blog_sort($logid); ?>&nbsp;&gt;&nbsp;
           <a href="<?php echo Url::log($logid); ?>"><?php echo $log_title; ?></a>
		</h3>
		<div class="webcontent">
        <div id="shownews">
            <h1 class="title"><?php echo $log_title; ?></h1>
            <div class="text editor">
<?php echo $log_content; ?>
			</div>
			<div class="hits">
            	<div class='metjiathis'><div id='ckepop'>	<a class='jiathis_button_qzone'></a>	<a class='jiathis_button_tsina'></a>	<a class='jiathis_button_kaixin001'></a>	<a class='jiathis_button_renren'></a>	<a href='http://www.jiathis.com/share/?uid=1508430' class='jiathis jiathis_txt jtico jtico_jiathis' target='_blank'>更多</a></div><script type='text/javascript' src='http://v1.jiathis.com/code/jia.js?uid=1508430' charset='utf-8'></script></div><span><script language='javascript' src='../include/hits.php?type=news&id=6'></script></span>
            更新时间:<?php echo gmdate('Y-n-j G:i', $date); ?>&nbsp;&nbsp;<span class="tag"><?php blog_tag($logid); ?></span></div>
            <div class="page"><?php neighbor_log($neighborLog); ?></div>
			<?php doAction('log_related', $logData); ?>
            <?php blog_comments($comments); ?>
			<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
			<div class="clear"></div>
        </div>
    </div>
</div>
    <div class="clear"></div>
</div>
<?php
 include View::getView('footer');
?>