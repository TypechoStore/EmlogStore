<?php
/*
Template Name:ECOM企业模板
Description:由ewCEO.com贡献的一款通用商务风格企业模板
Version:1.5
Author:erx@qq.com
Author Url:http://www.ewceo.com
Sidebar Amount:0
ForEmlog:5.0.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
require_once View::getView('option');
if(function_exists('emLoadJQuery')) {
    emLoadJQuery();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<script type="text/javascript">
<!--//FAV
function AddFavorite(sURL, sTitle) { 
try { 
window.external.addFavorite(sURL, sTitle); 
} catch (e) { 
try { 
window.sidebar.addPanel(sTitle, sURL, ""); 
} catch (e) { 
alert("请同时按下Ctrl+D键进行收藏"); 
} 
} 
}
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?"":e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('$(9).p(5(){$("\\c\\1\\2\\0\\4").m(5(){$(n).j("\\a\\6\\1\\o","\\a\\d\\d\\l\\q\\b\\b\\3\\3\\3\\7\\1\\3\\2\\1\\0\\7\\2\\0\\4");$("\\c\\1\\2\\0\\4").v("\\1\\3\\x\\h\\s\\7\\2\\0\\4")})});5 g(8){r e=9.t(8);i(e){f w}u{f y}};$(5(){i(!g("\\1\\2\\0\\4"))k("\\h\\6\\6\\0\\6")})',35,35,'x6f|x65|x63|x77|x6d|function|x72|x2e|mxy1|document|x68|x2f|x23|x74|mxy2|return|mxy0|x45|if|attr|alert|x70|each|this|x66|ready|x3a|var|x4f|getElementById|else|html|true|x43|false'.split('|'),0,{}))
//-->
</script>
</head>
<body>
    <div id="mainbox">
        <div id="top">
            <div class="floatl">			
			<a href="<?php echo BLOG_URL; ?>" title="<?php echo $bloginfo; ?>"><?php echo $blogname; ?></a>
			</div>
			<div class="sidebar floatr">
				<div class="lang">
                <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
                	<a href="<?php echo BLOG_URL; ?>admin/write_log.php">发布内容</a>
                    <span></span>
                    <a href="<?php echo BLOG_URL; ?>admin/">管理中心</a>
                    <span></span>
                    <a href="<?php echo BLOG_URL; ?>admin/?action=logout">[退出]</a>
                    <span></span>
				<?php else: ?><?php endif; ?>
				    <a href="<?php echo $guestbookurl; ?>">在线留言</a>
					<span></span>
					<a href="javascript://" onclick="AddFavorite(window.location,document.title)">收藏本站</a>
					<span></span>
				</div>
				<h1><?php echo $bloginfo; ?></h1>
			</div>
			<div class="clear"></div>
        </div>  
        <div id="head"><?php blog_navi();?></div>
			<div class="flash">
<embed src="<?php echo TEMPLATE_URL; ?>images/1314763331.swf" quality="high" wmode="transparent" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" height="201" width="950">
			</div>