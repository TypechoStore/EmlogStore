<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="web" style="text-align:center;padding:150px 0 200px">
对不起，本站目前没有开启当前页功能！
</div>
<?php
 include View::getView('footer');
?>