<?php
if (!defined('EMLOG_ROOT')) {
    exit('error!');
}
?>
</div><!--end #content-->
<div style="clear:both;"></div>
    <?php footer_link(); ?>
<div id="footerbar">
    Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION; ?>">emlog</a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a><br />
<?php echo $footer_info; ?> <?php doAction('index_footer'); ?>
</div><!--end #footerbar-->
</div><!--end #wrap-->
</body>
</html>
<script>
    jQuery(function($) {
        $.scrolltotop({
            className: 'totop',
            controlHTML: '<div class="totop" id="topcontrol" style="position: fixed; bottom: 25px; right: 25px; opacity: 1; cursor: pointer;"><a href="javascript:;"><b>回到顶部↑</b></a></div>',
            offsety: 0
        });
    });

    var timeout = 500;
    var closetimer = 0;
    var ddmenuitem = 0;
    function jsddm_open() {
        jsddm_canceltimer();
        jsddm_close();
        ddmenuitem = $(this).find('ul').eq(0).css('visibility', 'visible');
    }
    function jsddm_close() {
        if (ddmenuitem)
            ddmenuitem.css('visibility', 'hidden');
    }
    function jsddm_timer() {
        closetimer = window.setTimeout(jsddm_close, timeout);
    }
    function jsddm_canceltimer() {
        if (closetimer) {
            window.clearTimeout(closetimer);
            closetimer = null;
        }
    }
    $(document).ready(function() {
        $('#jsddm > li').bind('mouseover', jsddm_open);
        $('#jsddm > li').bind('mouseout', jsddm_timer);
    });
    document.onclick = jsddm_close;
</script>
<script type="text/javascript" id="bdshare_js" data="type=slide&mini=1" ></script> 
<script type="text/javascript" id="bdshell_js"></script> 
<script type="text/javascript">
    document.getElementById('bdshell_js').src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date() / 3600000);
</script>
<!-- Baidu Button END -->