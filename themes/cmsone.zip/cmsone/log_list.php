<?php
/**
 * 首页
 */
if (!defined('EMLOG_ROOT')) {
    exit('error!');
}
?>
<div id="contentleft">
    <?php if (blog_tool_ishome()) : ?>
        <div class="maindex">
            <?php
            blog_image_slide(5);
            blog_ndayhot(8, 60);
            ?>
            <script>
                $(document).ready(function() {
                    $('.box_skitter_normal').css({width: 360, height: 260}).skitter({animation: 'blind', interval: 2000, hideTools: true, theme: 'minimalist'});
                });
            </script>
        </div>
    <?php endif; ?>

    <div id="mainlist">
        <?php
        if (!empty($logs)):
            foreach ($logs as $value):
                $logdes = blog_tool_purecontent($value['log_description'], 300);
                $cover_img = '';
                ?>
                <h3><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h3>
                <div class="date"><?php blog_author($value['author']); ?> 于 <?php echo gmdate('Y-n-j G:i', $value['date']); ?> 发布<?php blog_sort($value['logid']); ?> <?php blog_tag($value['logid']); ?></div>
                <div class="logdes">
                    <?php blog_cover($value['logid'], $cover_img); ?>
                    <p>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $logdes; ?></p>
                </div>
                <div class="clear"></div>
                <div class="infobar">
                    <div class="count">
                        有 <a href="<?php echo $value['log_url']; ?>"><?php echo $value['views']; ?></a> 人浏览，
                        获得评论 <a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?>条</a>，
                        <a href="<?php echo $value['log_url']; ?>" class="readmore">浏览全文&gt;&gt;</a>
                    </div>
                    <!-- Baidu Button BEGIN -->
                    <div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare" data="{'comment':'','text':'<?php echo $value['log_title']; ?>','url':'<?php echo $value['log_url']; ?>','pic':'<?php echo $cover_img; ?>'}">
                        <a class="bds_qzone"></a>
                        <a class="bds_tsina"></a>
                        <a class="bds_tqq"></a>
                        <a class="bds_renren"></a>
                        <span class="bds_more"></span>
                    </div>
                    <!-- Baidu Button END -->
                </div>
                <?php
            endforeach;
        else:
            ?>
            <h2>未找到</h2>
            <p>抱歉，没有符合您查询条件的结果。</p>
        <?php endif; ?>
        <div id="pagenavi"><?php echo $page_url; ?></div>

        <!-- 分类列表-->
        <?php if (blog_tool_ishome()) : ?>
            <div id="sortbox">
                <?php
                $sort_cache = $CACHE->readCache('sort');
                if (!empty($sort_cache)):
                    foreach ($sort_cache as $value):
                        if ($value['pid'] != 0)
                            continue;
                        ?>
                        <div class="sortitem">
                            <h2><?php echo $value['sortname']; ?></h2>
                            <em class="sortmore"><a href="<?php echo Url::sort($value['sid']) ?>" title="查看<?php echo $value['sortname']; ?>中的全部文章">更多</a></em>
                            <ul>
                                <?php
                                $sqlSegment = '';
                                if ($value['pid'] != 0 || empty($value['children'])) {
                                    $sqlSegment = "and sortid={$value['sid']}";
                                } else {
                                    $sortids = array_merge(array($value['sid']), $value['children']);
                                    $sqlSegment = "and sortid in (" . implode(',', $sortids) . ")";
                                }
                                $sqlSegment .= " order by date desc";
                                $logs = $Log_Model->getLogsForHome($sqlSegment, 1, 10);
                                foreach ($logs as $row) :
                                    ?>
                                <li><a href="<?php echo $row['log_url']; ?>" title="<?php echo $row['log_title']; ?>"><?php echo subString($row['log_title'], 0, 17); ?></a><span><?php echo gmdate('Y.n.j', $row['date']); ?></span></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        <?php
                    endforeach;
                endif;
                ?>
            </div>
        <?php endif; ?>

    </div><!-- end #mainlist-->
</div><!-- end #contentleft-->
<?php
include View::getView('side');
include View::getView('footer');
?>