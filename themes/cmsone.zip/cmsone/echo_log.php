<?php
/**
 * 文章页面
 */
if (!defined('EMLOG_ROOT')) {
    exit('error!');
}
?>
<div id="contentleft">
    <h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
    <p class="date"><?php blog_author($author); ?> 发布于：<?php echo gmdate('Y-n-j G:i', $date); ?> <?php blog_sort($logid); ?> <?php blog_tag($logid); ?> <?php editflg($logid, $author); ?></p>
    <div class="logcontent"><?php echo $log_content; ?></div>
<?php doAction('log_related', $logData); ?>
    <div class="clear"></div>
    <div class="infobar">
        <div class="count">
            有 <?php echo $views; ?> 人浏览，获得评论 <?php echo $comnum; ?> 条
        </div>
        <!-- Baidu Button BEGIN -->
        <div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare">
            <a class="bds_qzone"></a>
            <a class="bds_tsina"></a>
            <a class="bds_tqq"></a>
            <a class="bds_renren"></a>
            <span class="bds_more"></span>
        </div>
    </div>
    <!-- Baidu Button END -->
    <div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid, $ckname, $ckmail, $ckurl, $verifyCode, $allow_remark); ?>
</div>
<?php
include View::getView('side');
include View::getView('footer');
?>