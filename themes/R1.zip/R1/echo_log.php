<?php 
/**
 * 输出日志
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');} 
?>
  	<div class="logecho">
    	<div class="logtitle"><?php echo $log_title; ?></div>
      <div class="echoinfo"><?php echo gmdate('Y-m-d', $date); ?> <?php blog_sort($logid); ?></div>
      <div class="echocontent"><?php echo $log_content; ?></div>
      <div class="neighbor"><?php neighbor_log($neighborLog); ?></div>
    </div>
   	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
		<?php blog_comments($comments); ?>
  </div>
<?php
 include View::getView('footer');
?>