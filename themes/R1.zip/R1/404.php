<?php 
/**
 * 自定义404页面
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>404 Not Found</title>
<style>
*{
	margin:0;
	padding:0;
	font-family:"微软雅黑";
}
.notfound{
	margin-top:250px;
	text-align:center;
}
.info{
	font-size:24px;
}
.back{
	display:inline-block;
	width:100px;
	height:50px;
	line-height:50px;
	text-align:center;
	color:#7f7f7f;
	margin-top:30px;
	font-size:14px;
	-moz-transition:color 0.4s, background 0.4s;
	-webkit-transition:color 0.4s, background 0.4s;
	transition:color 0.4s, background 0.4s;
}
.back:hover{
	color:#169ADA;
	background:#e7e7e7;
	-moz-transition:color 0.4s, background 0.4s;
	-webkit-transition:color 0.4s, background 0.4s;
	transition:color 0.4s, background 0.4s;
}
</style>
</head>
<body>
<div class="notfound">
	<div class="info">您所请求的页面未找到 :(</div>
  <a href="<?php echo BLOG_URL; ?>"><div class="back">返回首页</div></a>
</div>
</body>
</html>