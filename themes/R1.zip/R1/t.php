<?php 
/**
 * 	说说
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');} 
?>
		<div class="t">
  		<?php foreach($tws as $val): $tid = (int)$val['id']; ?>
  		<div class="talk">
      	<div class="ttime"><?php echo $val['date']; ?></div>
    		<div class="tcontent"><?php echo $val['t']; ?></div>
    	</div>
    	<?php endforeach; ?>
      <div class="page"><?php echo $pageurl;?></div>
  	</div>
  </div>
<?php
 include View::getView('footer');
?>