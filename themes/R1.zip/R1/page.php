<?php 
/**
 * 自建页面
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');} 
?>
  	<div class="logecho">
    	<div class="logtitle"><?php echo $log_title; ?></div>
      <div class="echocontent"><?php echo $log_content; ?></div>
    </div>
    <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
		<?php blog_comments($comments); ?>
  </div>
<?php
 include View::getView('footer');
?>