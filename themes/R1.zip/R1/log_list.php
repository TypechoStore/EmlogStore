<?php 
/**
 * 日志列表
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');} 
?>
		<div class="loglist">
  		<?php foreach($logs as $value): ?>
    	<div class="block">
    		<div class="logtitle"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a><span class="logdate"><?php echo gmdate('Y-m-d', $value['date']); ?></span></div>
      	<div class="logdesc"><?php echo $value['log_description']; ?></div>
    	</div>
    	<?php endforeach; ?>
    	<div class="page"><?php echo $page_url;?></div>
		</div>
  </div>
<?php
 include View::getView('footer');
?>