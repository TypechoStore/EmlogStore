<?php 
/**
 * 	链接
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');} 
?>
		<div class="link">
    	<div class="logtitle"><?php echo $log_title; ?></div>
    	<?php echo widget_link(); ?>
    </div>
  </div>
<?php
 include View::getView('footer');
?>