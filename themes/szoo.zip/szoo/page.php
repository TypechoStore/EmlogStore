<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<article id="post-1" class="post-1 post type-post status-publish format-standard hentry category-uncategorized">
	<header class="entry-header">
		<div class="post-format-indicator"> </div>
		<h1 class="page-title"><?php echo $log_title; ?></h1>
			<div class="entry-meta">
			</div><!-- .entry-meta -->
	</header><!-- .page-header -->
			<div class="entry-content">
			<?php echo $log_content; ?>
			</div><!-- .entry-content -->
			<footer class="entry-meta">
			</footer><!-- .entry-meta -->
</article><!-- #post-## -->
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<?php include View::getView('footer'); ?>