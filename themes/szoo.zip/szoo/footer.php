<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

	</div><!-- #main -->
	<?php  include View::getView('side'); ?>
	<footer id="colophon" class="site-footer" role="contentinfo">
		
		<div class="site-info">
			<?php echo $footer_info; ?><span class="sep"> | </span>
			THEME BY <a href="http://1osu.com" target="_blank">OSU!</a> MADE FOR Powered <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">emlog</a> 
			<span class="sep"> | </span>
			<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> 
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php doAction('index_footer'); ?>

</body>
</html>


