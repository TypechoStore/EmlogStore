<?php 
/*
* 自定义404页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />

<link rel="profile" href="http://gmpg.org/xfn/11" />




<link rel="stylesheet" id="pachyderm-style-css"  href="<?php echo TEMPLATE_URL; ?>style.css" type="text/css" media="all" />
<link rel="stylesheet" id="pachyderm-gudea-css"  href="http://fonts.googleapis.com/css?family=Gudea%3A400%2C400italic%2C700&#038;subset=latin%2Clatin-ext&#038;ver=3.5.1" type="text/css" media="all" />
<link rel="stylesheet" id="pachyderm-berkshire-swash-css"  href="http://fonts.googleapis.com/css?family=Berkshire+Swash&#038;subset=latin%2Clatin-ext&#038;ver=3.5.1" type="text/css" media="all" />
<link rel="stylesheet" id="pachyderm-poiret-one-css"  href="http://fonts.googleapis.com/css?family=Poiret+One&#038;subset=latin%2Clatin-ext%2Ccyrillic&#038;ver=3.5.1" type="text/css" media="all" />

<!--[if lt IE 9]>
<script src="<?php echo TEMPLATE_URL; ?>/js/html5.js" type="text/javascript"></script>
<![endif]-->
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>

</head>
<body class="home blog logged-in admin-bar no-customize-support custom-background active-sidebar-primary-sidebar">
<div id="page" class="hfeed site">
	
	<header id="masthead" class="site-header" role="banner">
		
			<a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>" rel="home">
				<img src="<?php echo TEMPLATE_URL; ?>img/zoo.png" alt="" />
			</a>
		
		<hgroup>
			<h1 class="site-title"><a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>" rel="home"><?php echo $blogname; ?></a></h1>
			<h2 class="site-description"><?php echo $bloginfo; ?></h2>
		</hgroup>

		<nav id="site-navigation" class="navigation-main" role="navigation">


			<div class="menu"><ul><li><a href="<?php echo BLOG_URL; ?>">>>>>>>>>>>>>404<<<<<<<<<<<  is  wrong, click back</a></li></ul></div>
		</nav><!-- #site-navigation -->
	</header><!-- #masthead -->

	<div id="main" class="site-main">

<article id="post-1" class="post-1 post type-post status-publish format-standard hentry category-uncategorized">
	<header class="entry-header">
		<div class="post-format-indicator"> </div>
		<h1 class="page-title">抱歉出错了！</h1>
	</header><!-- .page-header -->
			<div class="entry-content">
			404
			</div><!-- .entry-content -->
</article><!-- #post-## -->

<?php include View::getView('footer'); ?>