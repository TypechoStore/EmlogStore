<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="primary" class="content-area">
		<div id="content" class="site-content" role="main">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<article id="post-1" class="post-1 post type-post status-publish format-standard hentry category-uncategorized">
	<header class="entry-header">
		<div class="post-format-indicator">
					</div>
					<span class="comments-link"><a href="<?php echo $value['log_url']; ?>#comments" title="《<?php echo $value['log_title']; ?>》上的评论"><?php echo $value['comnum']; ?></a></span>
				<h1 class="entry-title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h1>

				<div class="entry-meta">
		  
		  作者：<?php blog_author($value['author']); ?> 发布于：<?php echo gmdate('Y-n-j G:i l', $value['date']); ?> 
				<?php blog_sort($value['logid']); ?> 
				<?php editflg($value['logid'],$value['author']); ?>
				</div><!-- .entry-meta -->
			</header><!-- .entry-header -->

		<div class="entry-content"><?php echo $value['log_description']; ?></div><!-- .entry-content -->
	
	<footer class="entry-meta">
					
					
	</footer><!-- .entry-meta -->
</article><!-- #post-## -->
<?php endforeach; ?>

		</div><!-- #content -->
	</div><!-- #primary -->
<div id="pagenavi">
	<?php echo $page_url;?>
</div>

<?php include View::getView('footer'); ?>
	