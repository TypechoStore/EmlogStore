<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<article id="post-1" class="post-1 post type-post status-publish format-standard hentry category-uncategorized">
	<header class="entry-header">
		<div class="post-format-indicator"> </div>
		<h1 class="page-title"><?php topflg($top); ?><?php echo $log_title; ?></h1>
			<div class="entry-meta">
			作者：<?php blog_author($author); ?> 
			发布于：<?php echo gmdate('Y-n-j G:i l', $date); ?>
			<?php blog_sort($logid); ?> | <?php blog_tag($logid); ?> <?php editflg($logid,$author); ?>
			</div><!-- .entry-meta -->
	</header><!-- .page-header -->
			<div class="entry-content">
			<?php echo $log_content; ?>
			
			</div><!-- .entry-content -->
			
			<footer class="entry-meta">
				<?php doAction('log_related', $logData); ?>
			</footer><!-- .entry-meta -->
</article><!-- #post-## -->
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	
<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
<?php include View::getView('footer'); ?>