<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="main clearfix">
  <div class="main-left fl">
    <div class="skin">
      <div class="skin-lists">
				        <ul id="skin-list">
	<li class="showdetail" key="2">
	<h2><?php echo $log_title; ?></h2>
	<div id="zhengwen"><?php echo $log_content; ?></div><br>
	<div><?php blog_tag($logid); ?></div>
	<?php doAction('log_related', $logData); ?>
	<div class="nextlog">
	<div id="z"></div>
	<div id="y"><br>
	<div id="c">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?></div>
	<div style="clear:both;"></div>
	</div>
  </li>
		</ul>

			  </div>
    </div>
  </div>
  <div class="main-right">
<?php
 include View::getView('side');

?>
<!--end #siderbar-->
  </div>
  
</div>
<!--end #contentleft-->
<?php
 include View::getView('footer');
?>


<div id="content">