<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="main clearfix">
  <div class="main-left fl">
    <div class="skin">
      <div class="skin-lists">
		<?php doAction('index_loglist_top'); ?>
		<?php foreach($logs as $value): ?>
        <ul id="skin-list">
	<li class="showdetail" key="2">
	<h2><a href="<?php echo $value['log_url']; ?>"><b id="biaoti"><?php echo $value['log_title']; ?></b></a><span><?php echo gmdate('Y-n-j G:i', $value['date']); ?></span></h2>
	<div id="jianjie"><?php echo $value['log_description']; ?></div>
	<p><span class="num">有<?php echo $value['views']; ?>人强势撸过</span><a class="install-skin notse6" href="<?php echo $value['log_url']; ?>">查看全文</a></p>
  </li>
		</ul>
		<?php endforeach; ?>
		<div id="pagenavi">
			<?php echo $page_url;?>
		</div>
      </div>
    </div>
  </div>
  <div class="main-right">
	<?php
	 include View::getView('side');
	?>
  </div>
  
</div>
<!-- end #contentleft-->
	<?php
	 include View::getView('footer');
	?>