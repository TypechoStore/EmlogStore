<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="main clearfix">
  <div class="main-left fl">
    <div class="skin">
      <div class="skin-lists">
				        <ul id="skin-list">
	<li class="showdetail" key="2">
	<h2 id="biaoti"><?php topflg($top); ?><?php echo $log_title; ?><span><?php echo gmdate('Y-n-j G:i', $date); ?> <?php editflg($logid,$author); ?></span></h2>
	<div id="zhengwen"><?php echo $log_content; ?></div><br>
	<div><?php blog_tag($logid); ?></div>
	<?php doAction('log_related', $logData); ?>
	<div class="nextlog">
	<div id="z"><?php shang_text($neighborLog); ?></div>
	<div id="y"><?php xia_text($neighborLog); ?></div><br>
	<div id="c"><?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?></div>
	<?php blog_comments($comments); ?>
	<div style="clear:both;"></div>
	</div>
  </li>
		</ul>

			  </div>
    </div>
  </div>
  <div class="main-right">
<?php
 include View::getView('side');

?>
<!--end #siderbar-->
  </div>
 <div style="clear:both;"></div> 
</div>
<!--end #contentleft-->
<?php
 include View::getView('footer');
?>