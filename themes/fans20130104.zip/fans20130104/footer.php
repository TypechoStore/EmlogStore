<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--end #content-->
<div style="clear:both;"></div>
<div class="footer">
  <p id="lianjie">Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">EMLOG</a> Style by <a href="http://se.360.cn" title="360浏览器" target="_blank">360.CN</a> & <a href="http://emlog.asia" title="emlog之家" target="_blank">FANS</a>  <br>
    <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?> </p>
</div>
</body>
</html>