<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<ul>
<li>
	<h2 class="content_h2"><?php topflg($top); ?><?php echo $log_title; ?></h2>
	<div class="act"><?php blog_sort($logid); ?> </div>
	<div class="editor"><?php editflg($logid,$author); ?></div>
	<div class="clear line"></div>
    <div class="bloger">作者：<?php blog_author($author); ?> 发布于：<?php echo gmdate('Y-n-j G:i l', $date); ?></div>
	<div class="post"><?php echo $log_content; ?></div>
	<div class="fujian"><?php blog_att($logid); ?></div>
	<div class="tag echo_tag"><?php blog_tag($logid); ?> 热度：<?php echo $views; ?> </div>
    <div><a href="javascript:void(0);" onclick="window.open('http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url='+encodeURIComponent(document.location.href));return false;" title="分享到QQ空间"><img src="http://qzonestyle.gtimg.cn/ac/qzone_v5/app/app_share/btn_share.png" alt="分享到QQ空间" /></a>  <a href="javascript:void(0);" onclick="window.open('http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?to=pengyou&url='+encodeURIComponent(document.location.href));return false;" title="分享到朋友社区"><img src="http://qzonestyle.gtimg.cn/ac/qzone_v5/app/qzshare/to-py.png" alt="分享到朋友社区" /></a>  <a href="javascript:void(0)" onclick="postToWb();" class="tmblog" title="分享到腾讯微博"><img alt="分享到腾讯微博" src="http://kushiw.com/content/templates/kushiw/images/t_share.gif"></a><script type="text/javascript"> 
	function postToWb(){
		var _t = encodeURI(document.title);
		var _url = encodeURIComponent(document.location);
		var _appkey = encodeURI("0017a1193be046dbbe5fd44365067e45");//你从腾讯获得的appkey
		var _pic = encodeURI('');//（例如：var _pic='图片url1|图片url2|图片url3....）
		var _site = 'http://kushiw.com';//你的网站地址
		var _u = 'http://v.t.qq.com/share/share.php?title='+_t+'&url='+_url+'&appkey='+_appkey+'&site='+_site+'&pic='+_pic;
		window.open( _u,'', 'width=700, height=680, top=0, left=0, toolbar=no, menubar=no, scrollbars=no, location=yes, resizable=no, status=no' );
	}
</script> <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=2231611712&site=qq&menu=yes"  title="点击给博主发信息"><img border="0" src="http://wpa.qq.com/pa?p=2:2231611712:50" alt="点击给博主发信息"></a></div>
	<?php doAction('log_related', $logData); ?>
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</li>
</ul>
</div>
<!--end content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>