﻿<div class="clear"></div>
</div>
<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<DIV id="footer" class="w">
<DIV id="footlink"><SPAN style="cursor:pointer;" onclick="window.scrollTo(0,0);">TOP</SPAN></DIV>
<DIV id="copyright">
<P>
CopyRight &copy; <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a> Powered By <a href="http://www.emlog.net" title="emlog 5.0.0">Emlog</a> Skin by <a href="http://lanyes.org" title="蓝叶">蓝叶</a> <?php echo $icp; ?> <?php echo $footer_info; ?></P>
</DIV>
<script type="text/javascript"><!--
    	jQuery(document).ready(function($){
    	//友情链接自动添加fav图标
    	$("#link li a").each(function(e){
    	$(this).prepend("<img src=http://www.google.com/s2/favicons?domain="+this.href.replace(/^(http:\/\/[^\/]+).*$/, '$1').replace( 'http://', '' )+" style=float:left;margin-right:5px;>");
    	});
    	});
    	//--></script>
<?php doAction('index_footer'); ?>
<div class="clear"></div>
</DIV>

</body>
</html>