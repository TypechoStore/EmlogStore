<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="clear"></div>
<div id="footer">
	<br/><br/>
Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog </a><?php echo Option::EMLOG_VERSION;?>  Designed by <a href="http://www.gw269.com" title="GW's Life">GW</a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?><?php else: ?>  <a href="<?php echo BLOG_URL; ?>admin/">管理</a>  <?php endif; ?> <a href="<?php echo BLOG_URL; ?>/m/">WAP</a> <a href="<?php echo BLOG_URL; ?>rss.php">RSS</a>
<?php doAction('index_footer'); ?>
</div>
</div>
</body>
</html>