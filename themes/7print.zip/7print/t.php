<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<h2>此模板暂无微语页面</h2>
<?php
 include View::getView('footer');
?>