<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>				<div class="post article">					<div class="cnt clear">						<h2 class="title"><?php echo $log_title; ?></h2>						<div class="text">							<?php echo $log_content; ?>						</div>					</div>                </div>				<div class="line"></div>				<div class="comment">					<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>					<?php blog_comments($comments); ?>				</div>				<div class="line"></div>                <div class="page clear">                </div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>