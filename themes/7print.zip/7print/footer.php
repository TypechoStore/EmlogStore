<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>                <div class="line"></div>                <div class="foot">					 <span title="Copyright" style="cursor:pointer;">&copy;</span>&nbsp;<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>&nbsp;|&nbsp;Powered by <a href="http://www.emlog.net" title="采用emlog系统">emlog</a>&nbsp;|&nbsp;Theme by <a href="http://angel.vip7.cc" title="南园北哲">Angel</a>					 <?php doAction('index_footer'); ?>				</div>            </div>        </div>    </div></div></body></html>