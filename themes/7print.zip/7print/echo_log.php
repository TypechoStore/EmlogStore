<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
				<div class="post article">					<div class="cnt clear">						<h2 class="title"><?php topflg($top); ?><?php echo $log_title; ?></h2>						<div class="text">							<?php echo $log_content; ?>						</div>					</div>					<div class="info">                        <div class="tag clear">							<?php blog_tag($logid); ?>						</div>                        <div class="other clear">                            <a href="#" class="itm time"><?php echo gmdate('Y-n-j', $date); ?></a>                        </div>                    </div>                    <a class="icn" href="#"></a>                </div>				<div class="line"></div>				<div class="comment">					<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>					<?php blog_comments($comments); ?>				</div>				<div class="line"></div>                <div class="page clear">                </div>
<?php
 include View::getView('footer');
?>