<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?><?php doAction('index_loglist_top'); ?><?php if (!empty($logs)):foreach($logs as $value): ?>				<div class="post article">					<div class="cnt clear">						<h2 class="title"><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>						<div class="text">							<?php echo $value['log_description']; ?>						</div>					</div>					<div class="info">						<div class="tag clear">							<?php blog_tag($value['logid']); ?>						</div>						<div class="other clear">							<a href="<?php echo $value['log_url']; ?>" class="itm time"><?php echo gmdate('Y-n-j', $value['date']); ?></a>						</div>					</div>					<a class="icn" href="<?php echo $value['log_url']; ?>"></a>				</div>
<?php 
endforeach;
else:
?><!--<p>抱歉，没有符合您查询条件的结果。</p>-->
<?php endif;?>
<div id="pagenavi">
	<?php echo $page_url;?>
</div>
<?php
 include View::getView('footer');
?>