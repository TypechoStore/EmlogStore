<?php
/*
Template Name:7Print
Description:仿lofter洁白模板
Version:1.0
Author:Angel
Author Url:http://angel.vip7.cc
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<!--[if IE 6]>
<script src="<?php echo TEMPLATE_URL; ?>iefix.js" type="text/javascript"></script>
<![endif]-->
<?php doAction('index_head'); ?>
</head>
<body>
<div class="doc">
	<div class="bd">
		<div class="bdc">
			<div class="bdcc">
				<div class="clear">
					<?php blog_navi();?>
					<div class="search">
						<form action="<?php echo BLOG_URL; ?>index.php" method="get">
							<input type="text" name="keyword" />
							<button type="submit">&nbsp;</button>
						</form>
					</div>
				</div>
				<div class="line"></div>
				<h1 class="logo"><a href="<?php echo BLOG_URL; ?>"><b><?php echo $blogname; ?></b></a></h1>
				<div class="line"></div>