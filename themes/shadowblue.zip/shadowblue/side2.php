<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="sidebar-3" class="sidebar footbar">
    <ul class="top-level">
        <li id="recent-comments-7" class="widget widget_recent_comments">
            <h2>评论</h2>
			<ul id="recentcomments">
            <?php widget_newcomm(''); ?>
			</ul>
        </li>
        <li id="recent-posts-5" class="widget widget_recent_entries">
            <h2>手气</h2>
			<ul>
            <?php widget_random_log(''); ?>
			</ul>
        </li>
    </ul>
</div>
