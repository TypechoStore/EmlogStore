<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="sidebar-4" class="sidebar footbar">
    <ul class="top-level">
        <li id="linkcat-2" class="linkcat widget">
            <h2>友链</h2>
            <ul>
                <?php widget_link(''); ?>
            </ul>
        </li>
        <li id="categories-3" class="widget widget_categories">
            <h2>分类</h2>
            <ul>
                <?php widget_sort(''); ?>
            </ul>
        </li>
    </ul>
</div>
