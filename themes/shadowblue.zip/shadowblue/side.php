<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="sidebar-2" class="sidebar footbar">
    <ul class="top-level">
        <li id="search" class="widget">
<form method="get" id="searchform" action="<?php echo BLOG_URL; ?>/">
<div>
	<input type="text" value="" name="q" id="s" size="15" />
	<input type="submit" id="searchsubmit" value="搜索" />
	<input type="reset" id="searchreset" value="重置" />
</div>
</form>
<li>
<h2>Hosting</h2>
<a href="http://www.hcunit.com/aff.php?aff=214" target="_blank"><img src="http://www.hcunit.com/pics/hcunit_ad4.jpg" alt="恒创主机" width="250" height="250" /></a>
</li>
        </li>
    </ul>
</div>
