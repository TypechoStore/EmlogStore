<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
  <div class="in">
    <div class="inner solo">
<div id="nav" class="solo" style="height: 30px; display: block; ">
<ul class="wp-tag-cloud top-level">
<a href="<?php echo BLOG_URL; ?>" rel="homepage">Homepage</a> » <?php blog_sort($logid); ?> » <a href="<?php echo $log_url; ?>"><?php echo $log_title; ?></a>
</ul>
</div>
      <div class="line-x"></div>
      <!--/.line-x-->
      <div id="main">
        <div class="main-in solo">
          <div id="content">
            <div class="story solo only-story">
              <div class="story-in solo">
                <div class="meta">
                  <div class="avatar">
                    <img width="40" height="40" class="avatar avatar-40 photo" src="<?php echo TEMPLATE_URL; ?>img/avatar.jpg" alt=""/>
                  </div>
                  <p>
                    <?php blog_author($author); ?>
                    <?php echo gmdate('Y.m.d', $date); ?>
                  </p>
                  <p>
                    <?php blog_sort($logid); ?>
                  </p>
                  </div>
                <div class="entry">
                  <h2><?php echo $log_title; ?></h2>
                  <div class="entry-text solo">
                    <?php echo $log_content; ?><div style="clear:both;"></div>
					<p class="att"><?php blog_att($logid); ?></p>
                  </div>
                  <br class="clear" />
                </div>
              </div>
              <p class="postmetadata">
                Tags: <?php blog_tag($logid); ?>
                 | <?php editflg($logid,$author); ?>
              </p>
              <div class="navigation">
                <?php neighbor_log($neighborLog); ?>
              </div>
            </div>
            <div class="comments-templates solo">
			<ol class="commentlist">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
            </ol>
            </div>
          </div>
          <!--/content-->
        </div>
        <!--/.main-in-->
      </div>
      <!--/main-->
<div class="line-x line-footbar"></div>
<!--/.line-x-->
<div class="footbar-wrap">
<!--<a class="switchFootbar" title="切换Footbar" href="#">切换Footbar</a>-->
<div id="footbar" class="solo">
<?php
 include View::getView('side');
 include View::getView('side2');
 include View::getView('side3');
?>
</div>
<!--/footbar-->
</div>
    </div>
    <!--/.inner-->
  </div>
  <!--/.in-->
</div>
<!--/container-->
<?php
 include View::getView('footer');
?>
