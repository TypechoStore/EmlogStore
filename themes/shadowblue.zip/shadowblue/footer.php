<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>
<!--/wrap-->
<div id="footer" class="textshadow">
  <p>&copy;<a target="_blank" href="http://creativecommons.org/licenses/by-nc-nd/3.0/deed.zh">Copyright</a><a href="<?php echo BLOG_URL; ?>" title="Home">
    <?php echo $blogname; ?>
    </a>/<a title="ShadowBlue 主题开发页面" href="http://interjc.net/dev/shadowblue">ShadowBlue</a> . <script src="http://s19.cnzz.com/stat.php?id=3522029&web_id=3522029" language="JavaScript"></script> . <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">Emlog</a> . <a class="back-to-top" href="#">Top ↑</a></p>
  <?php doAction('index_footer'); ?>
</div>
<!--/footer-->
<div id="scroll"><a href="#" title="回到页首" class="back-to-top">回到页首</a><a href="#footbar" title="回到页尾" class="back-to-bottom">回到页尾</a></div>
</body>