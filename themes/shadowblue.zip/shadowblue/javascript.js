jQuery(function($){
//判断浏览器
if($.browser.msie){
    var ieVer = $.browser.version;
    switch(ieVer){
        case 7:
            $('#searchreset,#searchsubmit').css({'top':'3px'});
            break;
        default:
            break;
    }
}else{
    var ieVer = 100;
}
//top-sns
if(ieVer>6){
    $('#top-sns a').fadeTo(0,0.5).hover(function(){
        $(this).fadeTo(300,1);
    },function(){
        $(this).fadeTo(300,0.5);
    });
} else {
    $('#top-page .page_item ul li ul').remove();
}
//top-page
$('#top-page>ul>li:gt(8)').addClass('hidden');
$('#top-page>ul').addClass('top-level').children('li').addClass('top-level').children('ul').addClass('second-level');
$('#top-page li.page_item').hover(
    function(){
        var $self = $(this);
        $self.addClass('hover');
        $self.doTimeout('hoverNav',500,function(){
            $self.children('ul').fadeTo(0,0.8).show();
        });
    },function(){
        var $self = $(this);
        $self.removeClass('hover');
        $self.doTimeout('hoverNav',500,function(){
            $self.children('ul').hide();
        });
    }
);
//nav
if($('#nav>ul:first').height()>$('#nav').height()){
    var navDivHeight = $('#nav').height();
    var navUlHeight = $('#nav>ul:first').height();
    if(navUlHeight>90 && $('#nav>ul:first').hasClass('wp-tag-cloud')){navUlHeight=90}
    $('#nav a.switch').css('display','block').toggle(function(){
        $('#nav').animate({height:navUlHeight},{
            duration: 800,
            easing: 'easeInOutSine',
            complete: function(){
                $('#nav a.switch').attr('title','收起').addClass('switch-up');
            }
        });
        return false;
    },function(){
        $('#nav').animate({height:navDivHeight},{
            duration: 600,
            easing: 'easeInOutSine',
            complete: function(){
                $('#nav a.switch').attr('title','更多').removeClass('switch-up');
            }
        });
        return false;
    });
}
$('#nav>ul.wp-tag-cloud').addClass('top-level');
//.story
$('.story:last').addClass('last-story');
//.entry-text
$('.entry-text img, img.avatar').hover(
    function(){
        $(this).doTimeout('hoverIMG',500,function(){
            $(this).animate(
                {
                borderTopColor: '#003E7B',
                borderRightColor: '#003E7B',
                borderBottomColor: '#003E7B',
                borderLeftColor: '#003E7B'
                },
                {
                duration: 800
                }
            );
        });
    }, function(){
        $(this).doTimeout('hoverIMG',500,function(){
            $(this).animate(
                {
                borderTopColor: '#ccc',
                borderRightColor: '#ccc',
                borderBottomColor: '#ccc',
                borderLeftColor: '#ccc'
                },
                {
                duration: 800
                }
            );
        });
    });
$('.entry-text a').each(function(){
    $self = $(this);
    if(!$self.has('img').length && !$self.hasClass('more-link')){
        if(ieVer>7){
            $self.addClass('external-link');
        } else {
            $self.after('<a href="' + $self.attr('href') + '" class="external-link-old" target="_blank">&nbsp;</a>');
        }
    }
});
//.widget
$('.sidebar>ul>li').addClass('widget');
  //评论区样式
  $('.thdrpy a').attr('title','点此回复');
  if($.browser.msie && $.browser.version<8){
    $('.thdrpy').addClass('show');
  } else {
    $('div.commentmetadata').hover(
      function(){
        $(this).closest('li[id^="comment-"]').find('.thdrpy:first').show();
      },function(){
        $(this).closest('li[id^="comment-"]').find('.thdrpy:first').hide();
      }
    );
    $('.comment_text').children(':not(".comment-childs")').hover(
      function(){
        $(this).closest('li[id^="comment-"]').find('.thdrpy:first').show();
      },function(){
        $(this).closest('li[id^="comment-"]').find('.thdrpy:first').hide();
      }
    );  
    $('.comment-childs').children().not('.comment-childs').hover(
      function(){
        $(this).closest('div[id^="comment-"]').find('.thdrpy:first').show();
      },function(){
        $(this).closest('div[id^="comment-"]').find('.thdrpy:first').hide();
      }
    );
  }
  $('ol.commentlist>li:odd').addClass('comment_odd');
//搜索样式
$('#searchreset').click(function(){
    $(this).hide();
});
$('#searchform :text').focus(function(){
    $('#searchreset').show();
    if(ieVer<8){
        $('#searchform :text').css({'border-color':'#79a8e7'});
    }
});
$('#searchform :text').blur(function(){
    if($(this).attr('value')==''){
        $('#searchreset').hide();
    }
    if(ieVer<8){
        $('#searchform :text').css({'border-color':'#ccc'});
    }
});
//Hover Fade
$('#scroll a').fadeTo(0,0.3).hover(
    function(){
        $(this).fadeTo(300,0.9);
    },
    function(){
        $(this).fadeTo(600,0.3);
});
//返回页首
$('a.back-to-top').click(function(){
    $('html, body').animate({scrollTop: 0}, {duration:1200, easing:'easeInOutSine'});
    return false;
});
$('a.back-to-bottom').click(function(){
    $('html, body').scrollTo( '#footer', 1200, {easing:'easeInOutSine'} );
    return false;
});
//Hash
if(window.location.hash && $(window.location.hash).length>0){
    var locationHash = window.location.hash;
    $('html, body').scrollTo( locationHash, 300, {easing:'easeInOutSine', offset: -50});
}
//外部链接 rel="external"
$('a[rel="external"],a.url').click(function(){
	window.open(this.href);
	return false;
});
//End
});
//addComment
//addComment={moveForm:function(d,f,i,c){var m=this,a,h=m.I(d),b=m.I(i),l=m.I("cancel-comment-reply-link"),j=m.I("comment_parent"),k=m.I("comment_post_ID");if(!h||!b||!l||!j){return}m.respondId=i;c=c||false;if(!m.I("wp-temp-form-div")){a=document.createElement("div");a.id="wp-temp-form-div";a.style.display="none";b.parentNode.insertBefore(a,b)}h.parentNode.insertBefore(b,h.nextSibling);if(k&&c){k.value=c}j.value=f;l.style.display="";l.onclick=function(){var n=addComment,e=n.I("wp-temp-form-div"),o=n.I(n.respondId);if(!e||!o){return}n.I("comment_parent").value="0";e.parentNode.insertBefore(o,e);e.parentNode.removeChild(e);this.style.display="none";this.onclick=null;return false};try{m.I("comment").focus()}catch(g){}return false},I:function(a){return document.getElementById(a)}};