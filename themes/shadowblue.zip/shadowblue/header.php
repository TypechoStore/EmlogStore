<?php
/*
Template Name:ShadowBlue
Description:移植自wp同名模板
Version:1.0
Author:capricornusoel
Author Url:http://lixox.net
Sidebar Amount:0
ForEmlog:4.1.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/lib/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/lib/jquery.plugins.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/javascript.js"></script>
<?php if($curpage == CURPAGE_LOG): ?>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/comments-ajax.js"></script>
<?php endif; ?>
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<!--[if lt IE 7]>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/ie6.js"></script>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>/ie6.css" type="text/css" media="screen" />
<![endif]-->
</head>
<body class=" sidebar-hide" style="height:100%; width:100%; position:relative;">
<div id="top">
  <!--[if IE 6]>
<div id="anti_ie6" <?php if($_COOKIE['closeAnti']==1){echo 'class="hidden"';}?>>
<div class="in">
<span class="warning">Tips: </span><p>尊敬的用户，您正在使用<a href="http://interjc.net/a/anti-ie6">老掉牙的IE 6.0</a>，我们强烈推荐您升级为<a target="_blank"  href="http://www.google.cn/chrome/intl/zh-CN/landing_chrome.html">Chrome</a>、<a target="_blank" href="http://firefox.com.cn/">Firefox</a>或<a href="http://www.microsoft.com/china/windows/internet-explorer/">IE8</a></p>
<a href="#" title="关闭后一周内不再显示" class="close">X</a>
</div>
</div>
  <![endif]-->
  <div class="in">
    <div id="top-page">
      <ul class="top-level">
        <li class="<?php echo $curpage == CURPAGE_HOME ? 'current_page_item page_item' : 'page_item';?>"><a href="<?php echo BLOG_URL; ?>">Home</a></li>
	<?php if($istwitter == 'y'):?>
	<li class="<?php echo $curpage == CURPAGE_TW ? 'current_page_item page_item' : 'page_item';?>"><a href="<?php echo BLOG_URL; ?>t/">微语</a></li>
	<?php endif;?>
	<?php 
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach ($navi_cache as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	$newtab = $val['newtab'] == 'y' ? 'target="_blank"' : '';
    $val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
	?>
	<li class="<?php echo isset($logid) && $key == $logid ? 'current_page_item page_item' : 'page_item';?>"><a href="<?php echo $val['url']; ?>" <?php echo $newtab; ?>><?php echo $val['naviname']; ?></a></li>
	<?php endforeach;?>
	<?php doAction('navbar', '<li class="page_item">', '</li>'); ?>
      </ul>
    </div><!--/top-page-->
    <div id="top-sns">
    <ul>
    <li><a href="<?php echo BLOG_URL; ?>rss.php" class="feed" title="订阅本站">Feed</a></li>
    <li><a href="mailto:jingzipanda@gmail.com" class="email" title="邮箱">Email</a></li>
    <li><a href="http://facebook.com" class="facebook" title="Facebook" rel="external">Facebook</a></li>
    <li><a href="http://twitter.com" class="twitter" title="Follow me via Twitter" rel="external">Twitter</a></li>
    </ul>
    </div><!--/top-sns-->
  </div>
  <!--/.in-->
</div>
<!--/top-->
<div id="wrap">
  <div id="header" class="solo">
    <div class="title">
      <div class="logo"><a href="<?php echo BLOG_URL; ?>"></a></div>
      <div class="text">
        <h1><a href="<?php echo BLOG_URL; ?>">
          <?php echo $blogname; ?>
          </a></h1>
        <p>
          <?php echo $bloginfo; ?>
        </p>
      </div>
      <!--.text-->
    </div>
    <!--.title-->
    <div class="advertisement" >
    <div class="ad-in" style="background-image:url(<?php echo TEMPLATE_URL; ?>img/banner.jpg);">
</div>
    </div>
  </div>
  <!--/header-->