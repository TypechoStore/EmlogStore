<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
  <div class="in">
    <div class="inner solo">
<div id="nav" class="solo" style="height: 30px; display: block; ">
<ul class="wp-tag-cloud top-level">
<?php
global $CACHE;
$tag_cache = $CACHE->readCache('tags');
?>
<?php shuffle($tag_cache);$tag_cache = array_slice($tag_cache,0,19);foreach($tag_cache as $value): ?>
<li style="line-height:30px;">
<a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇日志" style="text-decoration:none;"><?php echo $value['tagname']; ?></a></li>
<?php endforeach; ?>
</ul>
</div>
      <div class="line-x"></div>
      <!--/.line-x-->
      <div id="main">
        <div class="main-in solo">
          <div id="content">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
            <div class="story solo">
              <div class="story-in solo">
                <div class="meta">
                  <div class="avatar">
                    <img width="40" height="40" class="avatar avatar-40 photo" src="<?php echo TEMPLATE_URL; ?>img/avatar.jpg" alt=""/>
                  </div>
                  <p>
                    <?php blog_author($value['author']); ?>
                    <?php echo gmdate('Y.m.d', $value['date']); ?>
                  </p>
                  <p>
                    <?php blog_sort($value['logid']); ?>
                  </p>
                  </div>
                <div class="entry">
                  <h2><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
                  <div class="entry-text solo">
                    <?php echo $value['log_description']; ?><div style="clear:both;"></div>
                  </div>
                  <br class="clear" />
                </div>
              </div>
              <p class="postmetadata">
                Tags: <?php blog_tag($value['logid']); ?>
                    | 
                    <a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?>评论 &#187;</a>
              </p>
            </div>
<?php endforeach; ?>
            <div class="navigation">
              <div class="pagebar"><?php echo $page_url;?></div>
            </div>
          </div>
          <!--/content-->
        </div>
        <!--/.main-in-->
      </div>
      <!--/main-->
<div class="line-x line-footbar"></div>
<!--/.line-x-->
<div class="footbar-wrap">
<!--<a class="switchFootbar" title="切换Footbar" href="#">切换Footbar</a>-->
<div id="footbar" class="solo">
<?php
 include View::getView('side');
 include View::getView('side2');
 include View::getView('side3');
?>
</div>
<!--/footbar-->
</div>
    </div>
    <!--/.inner-->
  </div>
  <!--/.in-->
</div>
<!--/container-->
<?php
 include View::getView('footer');
?>
