<?php
/*
Template Name: aappz
Description: 随便仿制的主题，有什么需求大家到我主页咨询吧。有空就做做模板分享给大家，希望大家喜欢(*^__^*) 嘻嘻。
Version:3.0
Author:qzz
Author Url:http://blog.qzee.net/
Sidebar Amount:1
ForEmlog:4.1.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
$class=$_GET[sort]; 
$class.=$sortid;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/style.css" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/bg4.css" type="text/css" media="screen" />
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>jquery.min.js"></script>
<script type="text/javascript">
jQuery(document).ready(function(){
jQuery('#tab-title span').click(function(){
	jQuery(this).addClass("selected").siblings().removeClass();
	jQuery("#tab-content > ul").slideUp('1500').eq(jQuery('#tab-title span').index(this)).slideDown('1500');
});
});
$(document).ready(function() {
$('h2 a').click(function(){
myloadoriginal = this.text;
$(this).text('加载中，请稍候...');
var myload = this;
setTimeout(function() { $(myload).text(myloadoriginal); }, 2012);
});
});
</script>
<script>function searchdb()
            {
				 if(document.getElementById('searchtxt').value=='')
				 alert("搜索不允许为空");
				 else
				 document.location.href="?keyword="+document.getElementById('keyword').value;
			}
</script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="topbar">
	<dl>
	<dt>
	<ul id="menu">
		<li><a class="home" href="<?php echo BLOG_URL; ?>" style="<?php if($class=="" && $curpage != CURPAGE_TW){echo 'color:#cc0000'; }else{echo ' ';} ?>">首页</a></li>
	<?php if($istwitter == 'y'):?>
	<li><a href="<?php echo BLOG_URL; ?>t/" style="<?php echo $curpage == CURPAGE_TW ? 'color:#cc0000' : ' ';?>">微语</a></li>
	<?php endif;?>
	<!--如果需要导航栏的目录，请去掉下面的斜杠// -->
	<?//php menu_sort($class);?>
	<?php 
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach ($navibar as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
	?>
	<li><a href="<?php echo $val['url']; ?>" <?php echo $newtab; ?> style="<?php echo isset($logid) && $key == $logid ? 'color:#cc0000' : ' ';?>"><?php echo $val['naviname']; ?></a></li>
	<?php endforeach;?>
	<?php doAction('navbar', '<li class="page_item">', '</li>'); ?>
	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
	<li class="page_item"><a href="<?php echo BLOG_URL; ?>admin/">后台</a></li>
	<li class="page_item"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
	<?php else: ?>
	<li class="page_item"><a href="/admin">登陆</a></li>
	<?php endif; ?>
	</ul>
	</dt>
	<dd><form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
	<div id="top-search">
		<input type="text" class="txt" id="tops" name="keyword" size="36" value="" /><input type="button" class="btn" id="topbtn" onclick="searchdb()" name="submit" value="Search" />
	</div></form></dd>
	</dl>
</div>
<div id="wrap">
	<div id="header"><a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>">
			<div class="blog-name">
				<?php echo $bloginfo; ?>
			</div></a>
</div><div id="container"><div id="content">