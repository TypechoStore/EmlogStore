<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
$wiget="article";
?>
<!-- content START -->
<div id="content-inner">
			<div class="post">
<div class="post-data" id="post-<?php echo $logid;?>">
<div class="date en"><?php echo gmdate('Y-m-d H:s', $date); ?> </div>
			<h3 class="en">
			<span>Category: <?php blog_sort($sortid, $logid); ?></span>
			<span>Author: <?php blog_author($author); ?></span> <?php editflg($logid,$author); ?>
			</h3>
			<h2><?php topflg($top); ?><a class="title" href="<?php echo $value['log_url']; ?>" rel="bookmark"><?php echo $log_title; ?></a></h2>
		</div>
		<div class="post-txt">
		<?php echo $log_content; ?>
		</div>
		<div class="related">
		<span class="addtrackback">( <?php echo count($tb); ?> ) <?php blog_trackbackurl($tb, $tb_url, $allow_tb); ?></span>
			<ul>
			<li><span class="en">tag:</span><?php blog_tag($logid); ?></li>
			<li><span class="en"></span><?php blog_att($logid); ?></li>
			</ul>
		</div>
	<hr>
	<div class="navigation">
	<ul>
      	 <?php neighbor_log($neighborLog); ?>     
	</ul>	
	</div>
<div id="comments">
<div id="coms-title"><a class="curtab" rel="nofollow">评论</a> | <span class="addcomment"><a rel="nofollow"  href="#respond">发表评论</a></span></div>
	<div class="coms-title" >欢迎大家随便聊什么吧~( 广告就不要啦>_<~~ )</div>
	<!-- comments START -->
<ol class="coms-list">
<?php blog_comments($comments); ?>	
</ol>
	<!-- comments END -->
<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<!-- comments END -->
</div>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
	</div></div>
<!-- main END -->
<?php
 include View::getView('side');
 include View::getView('footer');
?>