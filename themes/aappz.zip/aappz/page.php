<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!-- content START -->
<div id="content-inner">
			<div class="post">
<div class="post-data" id="post-<?php echo $logid;?>">
<div class="date bk"><?php echo $log_title; ?><span><?php echo gmdate('Y-m-d H:s', $date); ?></span> </div>
			<h3 class="en">
			<span>Category: <?php blog_sort($sortid, $logid); ?></span>
			<span>Author: <?php blog_author($author); ?></span>
			<?php editflg($logid,$author); ?>
			</h3>
			<h2></h2>
		</div>
		<div class="post-txt">
		<?php echo $log_content; ?>
		</div>
<div id="comments">
<div id="coms-title"><a class="curtab" rel="nofollow">评论</a> | <span class="addcomment"><a rel="nofollow"  href="#respond">发表评论</a></span></div>
	<div class="coms-title" >欢迎大家随便聊什么吧~( 广告就不要啦>_<~~ )</div>
	<!-- comments START -->
<ol class="coms-list">
<?php blog_comments($comments); ?>	
</ol>
	<!-- comments END -->
<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<!-- comments END -->
</div>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<!-- main END -->
</div></div></div>
<!-- sidebar START -->
<?php
 include View::getView('side');
 include View::getView('footer');
?>