<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content-inner">
			<div class="post">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<div class="post-data" id="post-<?php echo $value['logid']; ?>">
<div class="date en"><?php echo gmdate('Y-m-d H:s', $value['date']); ?></div>
			<h3 class="en"><span>Category: <?php blog_sort($value['logid']); ?></span><span>Author: <?php blog_author($value['author']); ?></span><span>Comments: <a href="<?php echo $value['log_url']; ?>#comments" rel="nofollow" ><?php echo $value['comnum']; ?> 评论</a></span><span>Click: <?php echo $value['views']; ?> </span></h3>
			<h2><?php topflg($value['top']); ?><a class="title" href="<?php echo $value['log_url']; ?>" rel="bookmark"><?php echo $value['log_title']; ?></a></h2>
		</div>
		<div class="post-txt">
		<?php echo $value['log_description']; ?>
		</div>
		<div class="under"><?php blog_tag($value['logid']); ?></div>
<?php endforeach; ?>
	<div class='pagenavi en loop-pages'>
	<div class="pagenavi"><?php echo $page_url;?></div>
	</div>
</div>
	</div></div>
<!-- main END -->
<?php
 include View::getView('side');
 include View::getView('footer');
?>