<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<script>
    function change_bg(i) {
        var a = new Array();
        var b = new Array();
        var c = document.body.style;
        document.cookie = "bg_i=" + i;
        arr = document.cookie.match(new RegExp("(^| )bg_i=([^;]*)(;|$)"));
        a[0] = ("url(<?php echo TEMPLATE_URL; ?>images/bg-14.jpg)|fixed|50% 0");
        a[1] = ("url(<?php echo TEMPLATE_URL; ?>images/bg-3.jpg)|scroll|0 0");
        a[2] = ("url(<?php echo TEMPLATE_URL; ?>images/bg-4.jpg)|fixed|50% 0");
        a[3] = ("url(<?php echo TEMPLATE_URL; ?>images/bg-2.jpg)|fixed|50% 0");
        a[4] = ("url(<?php echo TEMPLATE_URL; ?>images/bg-0.jpg)|fixed|50% 0");
        a[5] = ("url(<?php echo TEMPLATE_URL; ?>images/bg-11.jpg)|fixed|50% 0");
        a[6] = ("url(<?php echo TEMPLATE_URL; ?>images/bg-13.jpg)|fixed|50% 0");
        a[7] = ("url(<?php echo TEMPLATE_URL; ?>images/bg-8.jpg)|fixed|50% 0");
        b = a[i].split("|");
        c.background = b[0];
        c.backgroundRepeat = "no-Repeat";
        c.backgroundAttachment = b[1];
        c.backgroundPosition = c[2];
    }
    arr = document.cookie.match(new RegExp("(^| )bg_i=([^;]*)(;|$)"));
    if (arr != null) {
        change_bg(arr[2]);
    }
    else
    {
        change_bg(Math.floor(Math.random() * 6));
    }
</script>
<div id="sidebar">
<li>
<h3>背景切换</h3>
<ul>
选择背景
<select  onchange="change_bg(this.value)">
	<option value="0" >我爱单反</option>
	<option value="1" >木质壁纸</option>
	<option value="2">清新海风</option>
	<option value="3" >灰色天气</option>
	<option value="4" >夏天的树</option>
	<option value="5">音乐气息</option>
	<option value="6" >晚霞天气</option>
	<option value="7" >星巴克</option>
</select>
</ul>
</li>
<ul>
<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>
</ul>
</div>