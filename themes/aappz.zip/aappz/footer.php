<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="footer">
	<div class="copyright">
		&copy; 2012 <em><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></em> All rights reserved. <?php echo $footer_info; ?> <a href="http://www.miibeian.gov.cn" target="_blank"><strong>  <?php echo $icp; ?></strong></a> <br />
<!--请保留主题作者qzz 谢谢您的支持!!同时欢迎友链我哦~-->
		 <em>Theme: <a href="http://blog.qzee.net/" title="template by qz">qzz</a>. Powered by <strong><a href="http://emlog.net/">emlog</a></strong></em><br /><?php doAction('index_footer'); ?> 
	</div>
</div><!--end footer-->
</body>
</html>
