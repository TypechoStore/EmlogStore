<?php
$hostname = '127.0.0.1'; // 数据库地址（主机名）
$username = 'root'; // 数据库用户名
$password = ''; // 数据库密码
$database = 'emlog'; // 数据库
$tablename = 'emlog_blog';  // 如有表前缀必须填写完整