<?php header('content-type:text/html;charset="utf-8"') ?>
<script type="text/javascript">
    if(confirm('修改数据库较为敏感，为避免发生不可逆转失误，请对该表进行事先备份，是否确认执行？'))
        window.location.href='./eidt_blog.php';
    else
        document.write('已经取消操作');    
</script>