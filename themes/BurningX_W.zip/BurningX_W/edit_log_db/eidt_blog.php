<?php
header('Content-type:text/html;charset=utf-8');
include ('dbconfig.php');


@$link = mysql_connect($hostname,$username,$password) OR  die ('数据库发生错误，错误编号是：'.mysql_errno().'错误信息是：'.mysql_error());
mysql_select_db($database,$link);
mysql_set_charset('utf8',$link);
$sql[] = "ALTER TABLE `".$tablename."` ADD `show_position` ENUM('l','r','c') DEFAULT 'l' NOT NULL;";
$sql[] = "ALTER TABLE `".$tablename."` ADD `headline` ENUM('y','n') DEFAULT 'n' NOT NULL;";
$sqlIndex[] = "ALTER TABLE `".$tablename."` ADD INDEX `show_position` (`show_position`);";
$sqlIndex[] = "ALTER TABLE `".$tablename."` ADD INDEX `headline` (`headline`)";
foreach($sql as $v)
{
    if(!mysql_query($v,$link))
    {
        echo "sql执行错误：";
        echo "错误号：".mysql_errno();
        echo "错误信息：".mysql_error();
        exit;
    }
}
// 执行添加索引
foreach($sqlIndex as $v)
{
    if(!mysql_query($v,$link))
    {
        echo "sql执行错误：";
        echo "错误号：".mysql_errno();
        echo "错误信息：".mysql_error();
        exit;
    }
}

mysql_close($link);
die('添加成功');