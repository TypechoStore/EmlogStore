<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
  <div class="am-g ">
  <div class="am-u-md-7 am-u-md-offset-1">  
<article class="am-article">
  <div class="am-article-hd">
  <div class="am-u-sm-3 am-u-sm-centered">
    <h1 class="am-article-title"><?php topflg($top); ?><?php echo $log_title; ?></h1></div>

  </div>

  <div class="am-article-bd"> 
    <p class="am-article-lead">&nbsp;&nbsp;&nbsp;&nbsp;posted on <?php echo gmdate('Y-n-j', $date); ?> By <?php blog_author($author); ?> <?php blog_sort($logid); ?> <?php editflg($logid,$author); ?></p>
	
	<p><?php echo $log_content; ?>	<p class="tag"><?php blog_tag($logid); ?></p></p>
	<?php doAction('log_related', $logData); ?>
	<div class="nextlog"><?php neighbor_log($neighborLog); ?>
  </div>
</article>


	

	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
</div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>