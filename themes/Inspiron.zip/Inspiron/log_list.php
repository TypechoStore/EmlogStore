<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php include View::getView('side');?>
<div id="content" >
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<div class="post"><!--Post Start-->
<div class="info_index"><!-- Post Time Info , Category and Comments Start-->
<ul>
<?php topflg($value['top']); ?>
<li class="time">
<?php echo gmdate('Y-n-j G:i l', $value['date']); ?> 
</li>
<li class="category"> 
<?php blog_sort($value['logid']); ?>
<li class="view">
<a href="<?php echo $value['log_url']; ?>"><?php echo $value['views']; ?> veiw</a>
</li>
<li class="comments" >          
<a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?> comments</a>
</li>
<li class="author" >
Posted By <?php blog_author($value['author']); ?>
</li>
<li class="edit">
<?php editflg($value['logid'],$value['author']); ?>
</li>
</ul>
</div> <!-- Post Time Info , Category, Tags End-->
 <div><!-- Title Start-->
  <h1><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h1>
  </div><!-- Title End-->
<div class="post-text"><!-- Text Start-->
<?php echo $value['log_description']; ?>
<div class="read" >
<ul class="tags">
<?php blog_tag($value['logid']); ?></ul>
</div>
 </div><!-- Text End-->
 </div><!-- Post End-->
<?php endforeach; ?>

</div>
<!--Content End-->
<div id="navigation">
	<?php echo $page_url;?>
</div>

<?php include View::getView('footer');?>
