<?php
/*
Template Name:Inspiron
Description:两栏模板 灵气个性 ……
Version:1.1
Author:小刀
Author Url:http://read.hicc.me
Sidebar Amount:1
ForEmlog:4.1.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<!-- <link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>style_rtl.css" type="text/css" media="screen" /> -->
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body  class="class="home blog logged-in"">
<!--[if IE]>
<div class="alert">You're running an older and buggy version browser: For your safety update to a modern web browser.</div>
<![endif]-->
<!--[if IE 7]>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>ie7.css" type="text/css" media="screen" />
<![endif]-->
<div id="container">
  <div id="header">
		<div id="logo">
			<h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
	</div>
					<div id="me_text"><?php echo $bloginfo; ?>
  <!--Rss\weibo\renren -->
  <ul>
	<li class="nobullet">
	<img class="icon" src="<?php echo TEMPLATE_URL; ?>images/rss_16.png" alt="Subscribe!" width="12" height="12" /> <a href="<?php echo BLOG_URL; ?>rss.php">Subscribe</a>
	</li>
	<li class="nobullet">
	<img class="icon" src="<?php echo TEMPLATE_URL; ?>/images/twitter_16.png" alt="Follow Me!" width="12" height="12" />
	<a href="http://www.weibo.com/ixiaodao"  > Follow on weibo </a>
	</li>
</ul>
</div><!--Description and links End-->
</div><!--Header End-->
<div id="wrap_container" >
 <div class="search" ><!--Search Start -->
<form id="searchform" name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
        <input type="submit" class="hidden" id="searchsubmit"  />
        <input name="keyword" type="text" value="Search: type and hit enter!" onfocus="if (this.value == 'Search: type and hit enter!') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search: type and hit enter!';}"  name="s" id="search" />
</form>
</div><!--Search End -->
<div class="navigation"">
    <ul id="menu-my-menu" class="menu">
	<li class="<?php echo $curpage == CURPAGE_HOME ? 'current' : 'common';?>"><a href="<?php echo BLOG_URL; ?>">首页</a></li>
	<?php if($istwitter == 'y'):?>
	<li class="<?php echo $curpage == CURPAGE_TW ? 'current' : 'common';?>"><a href="<?php echo BLOG_URL; ?>t/"><?php echo Option::get('twnavi');?></a></li>
	<?php endif;?>
	<?php 
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach ($navi_cache as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	$newtab = $val['newtab'] == 'y' ? 'target="_blank"' : '';
    $val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
	?>
	<li class="<?php echo isset($logid) && $key == $logid ? 'current' : 'common';?>"><a href="<?php echo $val['url']; ?>" <?php echo $newtab; ?>><?php echo $val['naviname']; ?></a></li>
	<?php endforeach;?>
	<?php doAction('navbar', '<li class="common">', '</li>'); ?>
	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
	<li class="common"><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
	<li class="common"><a href="<?php echo BLOG_URL; ?>admin/">管理中心</a></li>
	<li class="common"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
	<?php else: ?>
	<li class="common"><a href="<?php echo BLOG_URL; ?>admin/">登录</a></li>
	<?php endif; ?>
   	</ul>
  </div>
  </div>
  <div id="main">