<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!-- #main -->
<div style="clear:both;"></div>
<div id="footer">
<h6 class="right">
Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">emlog</a>
 - Designed by <a href="http://read.hicc.me/" target="_blank">小刀</a>
 - <a href="<?php echo BLOG_URL; ?>m/" target="_blank">WAP浏览</a>
 - <a href="<?php echo BLOG_URL; ?>rss.php" title="RSS订阅">RSS订阅</a>
-<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
<?php doAction('index_footer'); ?>
</h6>
 <h6>
&copy; <?php echo $blogtitle; ?>  
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h6>
</div><!--end #footer-->
</div><!--end #Container-->
</body>
</html>