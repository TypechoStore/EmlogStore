<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php include View::getView('side');?>
<div id="content" >
    <div class="post single"><!--Post Start-->
 <div class="info_index"><!-- Post Time Info , Category and Comments Start-->
 <ul>
<?php topflg($top); ?>
<li class="time">
<?php echo gmdate('Y-n-j G:i l', $date); ?>
</li>
<li class="category"> 
<?php blog_sort($logid); ?>
<li class="tag">
<img class="icon3" src="<?php echo TEMPLATE_URL; ?>images/tag_16.png" alt="TAGS" width="12" height="12" /><?php blog_tag($logid); ?>
</li>             
<li class="author" >
Posted By <?php blog_author($author); ?>
</li>
<li class="edit">
<?php editflg($logid,$author); ?>
</li>
 </ul></div> <!-- Post Time Info , Category, Tags End-->
 <div class="title"><!-- Title Start-->
 <h1><?php echo $log_title; ?></h1>
  </div>
 <div class="text_content">
 <?php echo $log_content; ?>
	<p class="att"><?php blog_att($logid); ?></p>
	<?php doAction('log_related', $logData); ?>
 </div><!-- Text End-->
 </div> <!--Single Post End -->
	<div id="post_navigation"><?php neighbor_log($neighborLog); ?></div>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
</div>
<!--Content End-->

 <?php include View::getView('footer');
