<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
    <footer>
      <div class="hf_block">
      <div class="f_block">
<div id="pagenavi">
<?php echo $page_url;?>
</div>
<!--footer-->
	<div class="flink">
	
<?php include View::getView('side');?>

    </div>
        
      </div>
      <div id="f_bg"></div>
    </div>
    </footer>
  
</div>

</body>
</html>