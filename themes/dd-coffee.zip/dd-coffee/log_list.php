<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="posts" class="content clearfix">
<?php doAction('index_loglist_top'); ?>

<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
      <article class="post">
        <figure class="post_block rich-content">
		
              <h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
              
                <div class="photo_view"></div>
				
                <p class="post_content">

				<?php echo ''.subString(strip_tags($value['log_description'],$img),0,200).''; ?></p>
				
				<p></p>  
				
                <p class="post_content" style="text-align:right"><a href="<?php echo $value['log_url']; ?>">阅读全文→</a></p>

            <div class="post_info rich-content">
              <span><a href="<?php echo $value['log_url']; ?>"><?php echo gmdate('Y-n-j l', $value['date']); ?></a></span>
              <span><a href="<?php echo $value['log_url']; ?>">热度:<?php echo $value['views']; ?>&deg;C</a></span>
			  <span><a href="<?php echo $value['log_url']; ?>"><?php echo $value['comnum']; ?>条评论</a></span>
			  <span class="tags">
<?php blog_tag($value['logid']); ?>
              </span>
              
            </div>
          
        </figure>
      </article>
<?php 
endforeach;
else:
?>
      <article class="post">
        <figure class="post_block rich-content">
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
	        </figure>
      </article>
<?php endif;?>

</div>

<?php include View::getView('footer');?>