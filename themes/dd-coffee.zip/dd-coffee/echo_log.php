<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="posts" class="content clearfix">

      <article class="post">
        <figure class="post_block rich-content">
            
              <div id="viewPost_pagination">
			  <?php neighbor_log($neighborLog); ?>
              </div>
            
              <h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
              
                <p class="post_content"><?php echo $log_content; ?></p>

            <div class="post_info rich-content">
              <span><a href="javascript:;"><?php echo gmdate('Y-n-j l', $date); ?></a></span>
			  <span><a href="<?php echo $value['log_url']; ?>">热度:<?php echo $views; ?>&deg;C</a></span>
			  <span><a href="<?php echo $value['log_url']; ?>"><?php echo $comnum; ?>条评论</a></span>
			  <span class="tags"><?php blog_tag($logid); ?></span>
            </div>
          
        </figure>
      </article>

          <article class="post">
            <figure class="post_block rich-content">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
            </figure>
          </article>
   
  </div>

<?php include View::getView('footer');?>