<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="posts" class="content clearfix">

      <article class="post">
        <figure class="post_block rich-content">
            
              <h2><?php echo $log_title; ?></h2>
              
                <p class="post_content"><?php echo $log_content; ?></p>

            <div class="post_info rich-content">
			  <span><a href="<?php echo $value['log_url']; ?>">热度：<?php echo $views; ?>&deg;C</a></span>
            </div>
          
        </figure>
      </article>

          <article class="post">
            <figure class="post_block rich-content">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
            </figure>
          </article>
   
  </div>

<?php include View::getView('footer');?>