<?php
/*
Template Name:咖啡因折页
Description:点仿点点网模板
Version:0.1
Author:loekman
Author Url:http://wenlu.me
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>style.css" />
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery-1.7-latest.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/01960.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/C8D0A.js"></script>
<!--[if lt IE 9]> 
  <script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/93D6C.js"></script>
<![endif]-->
<!--[if IE 6]>
    <script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/4B74A.js"></script>
    <script type="text/javascript">DD_belatedPNG.fix("#center, .#admin_actor, #admin_actor_over, #search-btn, #footer_shadow_bottom, #header_shadow_top, #header_shadow_left, .post_shadow_left, .post_shadow_right, #audio_cover, #f_bg, #wb_block a, #viewPost_pagination a, #nothing img");</script>
<![endif]-->

<script type="text/javascript">
var photos = [];
  $(document).ready(function(){
    $("html").niceScroll({cursorcolor:"#E62020",cursoropacitymax:1,touchbehavior:false,cursorwidth:"10px",cursorborder:"0",cursorborderradius:"5px"});
    var tm = $(".flashgallery").attr("title");
    
    addShadow();//添加背景和阴影
    $("nav.cf_nav li").not("#search").hover(function(){
      $(".nav_block",this).animate({left:"0"},200);
      
    },function(){
      $(".nav_block",this).animate({left:"-64px"},200);
    })
    
    $("#search .search_block").hover(function(){
      $("#search-text").css("visibility","visible").animate({width:"140px"},200,function(){
        $("#search-btn").css({"background-color":"#E5E2DF","right":"3px"});
      });
    },function(){
      $("#search-text").animate({width:"52px"},200,function(){
        $("#search-btn").css({"background-color":"","right":"17px"});
        $(this).css("visibility","hidden");
      });
    })
    
    //字符限制
    $("#cf_hd .hd").wordLimit();
    $("#cf_hd p.ltitle").wordLimit();
    $("nav_block span").wordLimit();
    $(".reblogFrom").wordLimit(8);
    
  })
  function addShadow(){
    $("#posts article:even .post_block").addClass("even");
    $("#posts article:odd .post_block").addClass("odd")
    var a='<div class="post_shadow_left"></div><div class="post_shadow_right"></div>';
    var b='<div id="footer_shadow_bottom"></div>';
    var c=$("#posts article").length;
    $("#posts article:even").append(a);
    if(!c%2){$("footer").append(b)}else{return false}
    //$("#posts article:last").find("div.post_shadow_left").remove();;
  }
</script>
<style type="text/css">
body{
  background-color:#382B25; 
  background-image:   url(<?php echo TEMPLATE_URL; ?>images/93947.jpg);  ; 
  background-repeat:   repeat;  ;
  
}
.cf_nav li{
  border-bottom-color: #5A443B;
}
.cf_nav li a, .cf_nav li a:visited, .cf_nav li a:hover{
  color: #B69A8F;
}
.cf_nav li a span.hover{
  background-color:#5A443B;
  color: #fff;
}
</style>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<nav class="cf_nav clearfix">
  <ul>
<?php blog_navi();?>
    <li id="search">
      <div class="search_block clearfix">
        <form action="<?php echo BLOG_URL; ?>index.php" method="get" class="clearfix">
          <input type="text" value="" class="cf_search" name="keyword" autocomplete="off" id="search-text" /><input type="submit" value="搜索" class="cf_search_btn" id="search-btn" />
        </form>
      </div>
    </li>
  </ul>
</nav>
<div id="wraper" class="clearfix">
  <header class="hf_block">
    <div id="cf_hd">
      
      <div class="admin_actor_box">
          <a href="<?php echo BLOG_URL; ?>">
	<?php if (!empty($user_cache[1]['photo']['src'])): ?>
	<img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="64" height="64" alt="<?php echo $blogname; ?>" />
	<?php endif;?>
          <div id="admin_actor_over"></div>
          </a>
      </div>
      
      <h1 class="hd"><a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>"><?php echo $blogname; ?></a></h1>
      <p class="ltitle"><?php echo $bloginfo; ?></p>
      <p class="cf_foot">&copy; <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a> | Powered by <a href="http://www.emlog.net" target="_blank" title="采用emlog系统">Emlog</a></p>
    </div>
      
    <div id="header_shadow_top"></div>
    <div id="header_shadow_left"></div>
  </header>