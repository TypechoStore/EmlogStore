<?php

/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
		'logoz' => array(
	    'type' => 'radio',
		'name' => 'LOGO样式',
		'values' => array(
			'yes' => '文字',
			'no' => '图片',
		),
		'default' => 'yes',
	),
		//设置logo
		'logo0' => array(
        'type' => 'image',
        'name' => 'logo',
        'values' => array(
            TEMPLATE_URL . 'img/logo.png',
        ),
		'description' => '<a style="color:red;">站点logo',
    ),
		//设置评论框背景图
		'commentimg' => array(
        'type' => 'image',
        'name' => '评论框图片',
        'values' => array(
            TEMPLATE_URL . 'img/inputbg.png',
        ),
		'description' => '<a style="color:red;">评论回复框的背景图片',
    ),
		//相册按钮与列表
		'album' => array(
	    'type' => 'radio',
		'name' => '是否显示相册',
		'values' => array(
			'yes' => '显示',
			'no' => '不显示',
		),
		'default' => 'yes',
	),
		//设置分类关键词
	 	'sortKeywords' => array(
		'type' => 'text',
		'name' => '分类关键词设置',
		'description' => '<a style="color:red;"><a style="color:red;">多个关键词之间用半角逗号隔开</a>',
		'depend' => 'sort',
		'default' => '设置关键词，请不要留空',
	),
		//站长邮箱
		'email' => array(
		'type' => 'text',
		'name' => '站长邮箱',
		'description' => '<a style="color:red;">必填的站长邮箱</a>',
		'default' => 'lpj.vip@foxmail.com',
	),
		//文章页面版权设置
	    'copyright' => array(
	    'type' => 'radio',
		'name' => '内页版权',
		'values' => array(
			'yes' => '显示',
			'no' => '隐藏',
		),
		'default' => 'yes',
	),
		//文章页面相关文章与随机文章
		'hot' => array(
	    'type' => 'radio',
		'name' => '内容页面相关文章',
		'values' => array(
			'yes' => '显示',
			'no' => '隐藏',
		),
		'default' => 'yes',
	),
		//站点统计代码
	    'tongji' => array(
		'type' => 'text',
		'name' => '第三方统计代码',
		'description' => '<a style="color:red;">百度统计等等</a>',
		'multi' => true,
		'default' => '',
	),
		//设置背景图颜色
		'body_color' => array(
		'type' => 'text',
		'name' => '设置背景颜色',
		'description' => '<a style="color:red;">推荐使用网页颜色，#开头的颜色值</a>',
		'default' => 'white',
	),
		//是否开启背景图片
		'body_img_yes' => array(
		'type' => 'radio',
		'name' => '背景图片设置',
		'description' => '<a style="color:red;">背景图片选择</a>',
		'values' => array(
			'yes' => 'DIY背景图<a style:"color:green;">（选择了这项才可以显示上传的背景图哦）</a><br/>',
			'no' => '关闭背景图<br/>',
			'bj1' => '主题自带背景图一',
			'bj2' => '主题自带背景图二',
			'bj3' => '主题带自背景图三',
		),
		'default' => 'yes',
	),
		//设置背景图
		'body_img' => array(
		'type' => 'image',
		'name' => 'DIY设置背景图',
		'description' => '<a style="color:red;">选择文件上传你的背景图</a>',
		'default' => ''.TEMPLATE_URL.'img/body.jpg',
	),
		//设置背景图定位
		'body_position' => array(
		'type' => 'text',
		'name' => '设置背景图定位',
		'description' => '<a style="color:red;">第一个值是水平位置，第二个值是垂直位置。左上角是 0% 0%。右下角是 100% 100%。如果您仅规定了一个值，另一个值将是 50%。默认为0% 0%</a>',
		'default' => '0% 0%',
	),	
		//设置背景图尺寸
		'body_size' => array(
		'type' => 'text',
		'name' => '设置背景图像的尺寸',
		'description' => '<a style="color:red;">设置背景图像的高度和宽度。第一个值设置宽度，第二个值设置高度。如果只设置一个值，则第二个值会被设置为 "auto"。默认值为空，无特殊要求可不填写，PS：该属性不支持IE6,7,8</a>',
		'default' => '',
	),	
		//如何重复背景图
		'body_repeat' => array(
		'type' => 'radio',
		'name' => '设置如何重复背景图像',
		'values' => array(
			'repeat' => '背景图像将在垂直方向和水平方向重复<br/>',
			'repeat-x' => '背景图像将在水平方向重复<br/>',
			'repeat-y' => '背景图像将在垂直方向重复<br/>',
			'no-repeat' => '背景图像将仅显示一次<br/>',
		),
		'default' => 'repeat',
	),
	
		//背景图是否随页面滚动而滚动
		'body_attachment' => array(
		'type' => 'radio',
		'name' => '设置背景图是否随页面滚动',
        'values' => array(
			'scroll' => '背景图随页面滚动而滚动<br/>',
			'fixed' => '背景图不随页面滚动而滚动',
		),
		'default' => 'fixed',
	),
		//页面加载耗时
		'timer' => array(
	    'type' => 'radio',
		'name' => '页面加载耗时',
		'values' => array(
			'yes' => '显示',
			'no' => '隐藏',
		),
		'default' => 'no',
	),
		//侧边栏屏幕跟随
		'stool' => array(
		'type' => 'checkbox',
		'name' => '侧边栏屏幕跟随',
		'description' => '<a style="color:red;">这里貌似有话要说，但是不记得了，标题固定了要改就去module改吧，还有什么来着。。。</a>',
		'values' => array(
			'widget_blogger' => '<span style="color:blue;">个人资料</span>',
			'widget_calendar' => '<span style="color:green;">日历</span>',
			'widget_tag' => '<span style="color:pink;">标签</span>',
			'widget_sort' => '<span style="color:red;">分类</span>',
			'widget_twitter' => '<span style="color:aqua;">最新微语</span>',
			'widget_newcomm' => '<span style="color:#F60;">最新评论</span>',
			'widget_newlog' => '<span style="color:#11f;">最新文章</span>',
			'widget_hotlog' => '<span style="color:#00f;">热门文章</span><br/>',
			'widget_random_log' => '<span style="color:#062;">随机文章</span>',
			'widget_search' => '<span style="color:#123;">搜索</span>',
			'widget_archive' => '<span style="color:#369;">归档</span>',
			'widget_link' => '<span style="color:#218;">链接</span>',
			'ccc' => '<span style="color:blue;">自定义悬浮</span>',
				),
		'default' => array(
			'',
		),
		),
		//diy悬浮栏代码设置
	'ccc' => array(
		'type' => 'text',
		'name' => '自定义悬浮框',
		'description' => '<a style="color:red;">这里填写自定义悬浮框代码<br/>代码例：↓</a>',
		'multi' => true,
		'default' => '<aside class="widget widget_text"id="text-2">
        <h3 class="widget-title"><i class="icon-st"></i>标题</h3>
        <div class="textwidget">
	你自己的内容代码
		</div>
		<div class="clear"></div>
</aside>',
	),
		//页脚广告
		'adindexxs' => array(
	    'type' => 'radio',
		'name' => '页面顶部广告显示',
		'values' => array(
			'style="display: block;"' => '显示',
			'style="display:none;"' => '隐藏',
		),
		'default' => 'style="display:none;"',
	),
		'adindex' => array(
		'type' => 'text',
		'name' => '全局顶部广告',
		'description' => '<a style="color:red;">这里填写页面顶部广告代码</a>',
		'multi' => true,
		'default' => '<h1>页头广告招租</h1>',
	),
		'adfooterxs' => array(
	    'type' => 'radio',
		'name' => '页面底部广告显示',
		'values' => array(
			'style="display: block;"' => '显示',
			'style="display:none;"' => '隐藏',
		),
		'default' => 'style="display:none;"',
	),
		'adfooter' => array(
		'type' => 'text',
		'name' => '全局底部广告',
		'description' => '<a style="color:red;">这里填写页面底部广告代码</a>',
		'multi' => true,
		'default' => '<h1>广告招租</h1>',
	),
	
		'zz' => array(
		'type' => 'text',
		'name' => '作者有话说',
		'description' => '<a style="color:red;">说点什么额。。。。</a>',
	),
		
);