<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<nav class="crumbs">现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a>>微语
    </nav>
    <?php doAction('index_loglist_top'); ?>
    
<article id="primary" class="site-content">
<?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?> 
	<section class="content">
		<header class="entry-header">
			<div class="title-heavy"><div class="heavy-l"></div><div class="heavy-r"></div></div>
			<h1 class="entry-title"><?php echo $val['t'].'<br/>'.$img;?></h1>
            <span style="float:left;"><i class="icon-cat"></i><?php echo $author; ?></span>
            <span style="float:right"><i class="icon-date"></i><?php echo $val['date'];?></span>
            <div class="clear"></div>
		</header>
	</section>
	<!-- #content -->
	<?php endforeach;?>
    <nav id="pagenavi"><?php echo $pageurl;?></nav>
</article>
<?php
 include View::getView('side');
 include View::getView('footer');
?>