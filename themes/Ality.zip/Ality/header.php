<?php
/*
Template Name:Jseven-Ality
Description:<h3>主题特色</h3><li><a>响应式布局</a>-<a>支持后台背景图设置</a>-<a>站点LOGO在线上传</a></li><li><a>适合不同分辨率的设备</a></li><li><a>支持Retina（视网膜）显示</a>-<a>自动缩略图</a></li><li><a style="color:red;">等等一系列设置，自己体验吧</a></li>
Version:1.0
Author:刘培杰
Author Url:http://azt-lmt.com
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
extract(_g());
require_once View::getView('module');
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="zh-CN"><![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="zh-CN"><![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="zh-CN"><![endif]-->
<!--[if (gte IE 9)|!(IE)]><html lang="zh-CN"><![endif]-->
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width initial-scale=1.0, user-scalable=no">
<link rel="shortcut icon" href="<?php echo BLOG_URL; ?>favicon.ico">
<?php if (blog_tool_ishome()) :?> 
<title><?php echo $blogname; ?>-<?php echo $site_description; ?></title>
<?php else:?> 
<title><?php echo $site_title; ?></title> 
<?php endif;?> 
<?php if (isset($logid)) : ?>
<meta name="keywords" content="<?php log_key_words($logid); ?>" />
<?php elseif (isset($sortName)) : ?>
<meta name="keywords" content="<?php echo _g('sortKeywords.'.$sortid); ?>" />
<?php else : ?>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<?php endif; ?>
<meta name="description" content="<?php echo $site_description; ?>" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" /><meta name="generator" content="emlog" />
<link rel="shortcut icon" href="<?php echo BLOG_URL; ?>favicon.ico">
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<link rel="stylesheet" id="style-css" href="<?php echo TEMPLATE_URL; ?>style.css?ver=2014.8.1" type="text/css" media="all">
<link rel="stylesheet" id="mediaqueries-css" href="<?php echo TEMPLATE_URL; ?>css/mediaqueries.css?ver=1.0" type="text/css" media="all">
<?php doAction('index_head'); ?>
<!--[if lt IE 8]><link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/ie7/ie7.css" /><![endif]-->
<?php
if(_g('body_attachment')=='scroll'){
    $a='scroll';
}else{
    $a='fixed';
}
if(_g('body_repeat')=='repeat'){
    $b='repeat';
}elseif(_g('body_repeat')=='repeat-x'){
    $b='repeat-x';
}elseif(_g('body_repeat')=='repeat-y'){
	$b='repeat-y';
}else{
	$b='no-repeat';
}
if(_g('body_img_yes')=="yes"){
    $c = _g('body_img');
}elseif(_g('body_img_yes')=="bj1"){
	$c = 'http://azt-lmt.com/content/templates/Ality/img/bj1.png';
	}elseif(_g('body_img_yes')=="bj2"){
	$c = 'http://azt-lmt.com/content/templates/Ality/img/bj2.png';
	}elseif(_g('body_img_yes')=="bj3"){
	$c = 'http://azt-lmt.com/content/templates/Ality/img/bj3.png';
}else{
    $c = '';
}
if(_g('body_repeat')=='repeat'){
    $d='repeat';
}elseif(_g('body_repeat')=='repeat-x'){
    $d='repeat-x';
}elseif(_g('body_repeat')=='repeat-y'){
	$d='repeat-y';
}else{
	$d='no-repeat';
}
?>
<style>
body{
      background-color:<?php echo _g('body_color'); ?>;
	  background-position:<?php echo _g('body_position'); ?>;
	  background-size:<?php echo _g('body_size'); ?>;
	  background-repeat:<?php echo $b; ?>;
	  background-attachment:<?php echo $a; ?>;
	  background-image:url("<?php echo $c; ?>");
}
.logo {
	background: url("<?php echo _g('logo0'); ?>") no-repeat;
	width: 220px;
	height: 53px;
	text-indent: -10000px;
	cursor: pointer;
}
#comment{
	background: url(<?php echo _g('commentimg'); ?>) repeat-x top;
	}
</style>
</head>
<body class="home blog logged-in admin-bar  customize-support">
<div id="main" class="wrapper">
	<div id="header-top">
		<nav id="top-nav" class="main-nav">
			<div class="home_h"><i class="icon-home_h"><a href="<?php echo BLOG_URL; ?>" title="转到首页"></a></i></div>
            <ul class="menu sf-js-enabled sf-shadow" id="menu-%e5%95%8a%e5%95%8a%e5%95%8a">
			<?php blog_navi();?></ul>
			<div class="clear"></div>
		</nav>
	</div>
	<?php include View::getView('inc/simple-menu');?>
	<div id="page" class="page-site">
		<header id="header">
			<div class="header-clear"></div>
			<div class="main-header">
				<?php include View::getView( 'inc/logo' ); ?>
				<?php include View::getView( 'inc/nav-set' ); ?>
				<div class="clear"></div>
			</div>
			<div class="clear"></div>
			<nav id="site-nav" class="main-nav">
           <div class="menu-%e5%95%8a%e5%95%8a%e5%95%8a-container">
          <UL class="menu sf-js-enabled sf-shadow"><?php blog_sort_navi();?></UL>
				</div>
				<ul><li class="fill"></li></ul>
			</nav>
			<!-- #site-nav -->
			<div class="clear"></div>
		</header>
		<!-- #header -->
	<div id="search-main">
	<div id="searchbar">
	<form method="get" id="searchform" action="<?php echo BLOG_URL; ?>index.php"/>
	<input type="text" value="" name="keyword" id="s" placeholder="EMLOG搜索" required />
	<input type="submit" id="searchsubmit" value="搜索" />
	</form>
	<form action="http://www.baidu.com/baidu" target="_blank">
	<input name=word class="swap_value" placeholder="百度站内搜索" required >
	<input type="submit" class="submit" name="submit" id="searchsubmit" value="百度" />
	<input name=tn type=hidden value="bds">
	<input name=cl type=hidden value="3">
	<input name=ct type=hidden value="2097152">
	<input name=si type=hidden value="<?php echo BLOG_URL; ?>">
	<input name=si type=hidden value="">
	</form>
	</div></div>
<div id="hd-main" class="post post type-post status-publish format-standard hentry category-uncategorized">
 <?php include View::getView( 'inc/album' ); ?>
</div>