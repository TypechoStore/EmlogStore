<div id="sidebar" class="widget-area">
	<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>
<div class="sidebar-roll">
<?php if (in_array('widget_blogger', _g('stool'))):?>
<?php widget_blogger($title);?> 
<?php else: ?>	
<?php endif; ?>
<?php if (in_array('widget_calendar', _g('stool'))):?>
<?php widget_calendar($title);?>
<?php else: ?>	
<?php endif; ?>
<?php if (in_array('widget_tag', _g('stool'))):?>
<?php widget_tag($title);?> <?php else: ?>	
<?php endif; ?>
<?php if (in_array('widget_sort', _g('stool'))):?>
<?php widget_sort($title);?> 
<?php else: ?>	
<?php endif; ?>
<?php if (in_array('widget_twitter', _g('stool'))):?>
<?php widget_twitter($title);?> 
<?php else: ?>	
<?php endif; ?>
<?php if (in_array('widget_newcomm', _g('stool'))):?>
<?php widget_newcomm($title);?> 
<?php else: ?>	
<?php endif; ?>
<?php if (in_array('widget_newlog', _g('stool'))):?>
<?php widget_newlog($title);?> 
<?php else: ?>	
<?php endif; ?>
<?php if (in_array('widget_hotlog', _g('stool'))):?>
<?php widget_hotlog($title);?> 
<?php else: ?>	
<?php endif; ?>
<?php if (in_array('widget_random_log', _g('stool'))):?>
<?php widget_random_log($title);?> 
<?php else: ?>	
<?php endif; ?>
<?php if (in_array('widget_search', _g('stool'))):?>
<?php widget_search($title);?> 
<?php else: ?>	
<?php endif; ?>
<?php if (in_array('widget_archive', _g('stool'))):?>
<?php widget_archive($title);?> 
<?php else: ?>	
<?php endif; ?>
<?php if (in_array('widget_link', _g('stool'))):?>
<?php widget_link($title);?>
<?php else: ?>	
<?php endif; ?>
<?php if (in_array('ccc', _g('stool'))):?>
<?php echo _g('ccc');?>
<?php else: ?>	
<?php endif; ?>
</div></div>
<div class="clear"></div>