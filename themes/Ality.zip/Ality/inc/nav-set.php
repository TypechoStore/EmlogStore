<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="set-main">
<?php if ($album == "yes"): ?>
	<div id="nav-hd">
		<a class="menu-hd" href="#"><i class="icon-hd"></i></a>
	</div><?php else:?> <?php endif ;?>
	<div id="nav-search">
		<a class="menu-search" href="#"><i class="icon-search"></i></a>
	</div>
	<div id="nav-login">
		<a href="#login" class="flatbtn" id="login-main" ><i class="icon-login"></i></a>
	</div>
</div>