<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<hgroup class="logo-main">
 <?php if ($logoz == "yes"): ?>
	<div class="title-main">
		<h1 class="site-title"><a href="<?php echo BLOG_URL; ?>" rel="home"><?php echo $blogname; ?></a></h1>
		<h2 id="site-description"><?php echo $bloginfo; ?></h2>
	</div>
<?php else: ?>
	<a href="<?php echo BLOG_URL; ?>" rel="home" title="<?php echo $blogname; ?>"><h1 class="logo"><?php echo $blogname; ?></h1></a>
<?php endif;?>
</hgroup>
