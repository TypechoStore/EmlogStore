﻿<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="login">
<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
	<div class="login-user">
	<h1>用户资料</h1>
    <span ><a href="<?php echo BLOG_URL; ?>admin/blogger.php">
	<?php if($user_cache[$author]['photo']['src']):?>
		<?php if (!empty($user_cache[$author]['photo']['src'])): ?>
			<img src="<?php echo BLOG_URL.$user_cache[$author]['photo']['src']; ?>" height="63" width="63" data-bd-imgshare-binded="1">
		<?php endif; ?>
	<?php else:?>
		<img src="<?php echo getGravatar($user_cache[UID]['mail']); ?>"  height="63" width="63" data-bd-imgshare-binded="1">
	<?php endif; ?>
		</a>
    </span>
   <?php $aql = "SELECT * FROM ".DB_PREFIX."user WHERE uid='".UID."'";
      $ery=mysql_query($aql);
          while ($rest = mysql_fetch_array($ery)) {
      echo "用户账号:".$rest['username'].
	  "<br/>用户名称:".$rest['nickname'];?>
 <?php } ?>
		<br/>
        <a href="<?php echo BLOG_URL; ?>admin">后台管理</a>
		<a href="<?php echo BLOG_URL; ?>admin/?action=logout" title=""> 退出</a>
  </div>
<?php else : ?>
		<h1>用户登录</h1>
		<form action="<?php echo BLOG_URL; ?>admin/index.php?action=login" method="post" id="loginform" name="f">
		<fieldset id="inputs">
		<input id="user" type="text"  name="user" id="log" placeholder="名称" required>
		<input id="password" type="password" name="pw" id="pw" placeholder="密码" required>
		</fieldset>
		<fieldset id="actions">
		<input type="submit" id="submit" value="登录">
		<input type="hidden" name="redirect_to" value="/" />
		<a href="http://azt-lmt.com/index.php?plugin=yfjt_qq_login&goto=qq" title="使用QQ账号登小站"><img width="30" height="30" src="<?php echo TEMPLATE_URL; ?>img/qq.gif"/></a>
		<label><input type="checkbox" name="rememberme" id="modlogn_remember" value="yes"  checked="checked" alt="Remember Me" >记住登录信息</label>
		</fieldset>
		</form>
<?php endif ;?>
</div>