<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php if ($copyright == "yes"): ?>
<div class="authorbio">
<img alt="" src="<?php echo getGravatar($user_cache[UID]['mail']); ?>" class="avatar avatar-32 photo" height="32" width="32" style="opacity: 1;">
<ul class="spostinfo">
	<li><strong>版权声明：</strong>本站原创文章，由 <?php blog_author($author); ?> 发表在 <?php echo $blogname; ?> ，于 <?php echo gmdate('Y年n月j日', $date); ?> 最后更新</li>
	<li><strong>转载请注明：</strong><a href="#" onclick="copy_code('<?php echo Url::log($logid);?>'); return false;" rel="bookmark" title="本文固定链接 <?php echo Url::log($logid);?>"><?php echo $log_title; ?>丨<?php echo $blogname;?> +复制链接</a></li>
</ul></div><?php endif;?>