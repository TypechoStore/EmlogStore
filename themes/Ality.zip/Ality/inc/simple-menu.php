<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="simple-top">
	<a id="simple-menu" href="#sidr"><i class="icon-simple-menu"></i></a>
		<hgroup class="logo-simple">
        <?php if ($logoz == "yes"): ?>
        <div class="site-title"><a href="<?php echo BLOG_URL; ?>" rel="home" title="<?php echo $blogname; ?>"><h1 class="logo-title"><?php echo $blogname; ?></h1></a></div>
		<?php else :?>
		<div class="site-title"><a href="<?php echo BLOG_URL; ?>" rel="home" title="<?php echo $blogname; ?>"><h1 class="logo-x"><?php echo $blogname; ?></h1></a></div>
		<?php endif ;?>
        </hgroup>
	
	<div id="set-top">
    <?php if ($album == "yes"): ?>
    	<div id="nav-hd">
			<a class="menu-hd" href="#"><i class="icon-hd"></i></a>
		</div>
        <?php else:?>
        <?php endif;?>
		<div id="nav-search">
			<a class="menu-search" href="#"><i class="icon-search"></i></a>
		</div>
		<div id="nav-login">
			<a href="#login" class="flatbtn" id="logint-main" ><i class="icon-login"></i></a>
		</div>
	</div>
</div>