<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<a href="<?php echo $value['log_url']; ?>">
                <?php $thum_src = getThumbnail($value['logid']);$imgFileArray = glob("content/templates/Ality/img/random/*.*");$imgsrc = preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);$imgsrc = !empty($img[1]) ? $img[1][0] : ''; ?>
<?php if ($thum_src):?> 
<img src="<?php echo $thum_src; ?>"  class="home-thumb" alt=""  />
<?php elseif($imgsrc): ?>
<img src="<?php echo $imgsrc; ?>"  class="home-thumb" alt="" />
<?php else: ?>
<img src="<?php echo BLOG_URL; ?><?php echo $imgFileArray[array_rand($imgFileArray)]; ?>"   class="home-thumb" alt=""/>
<?php endif; ?>
</a>