<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php if ($hot == "yes"): ?>
<div id="single-widget">
<?php blog_hotlog($title);?>
<?php blog_random_log($title);?>
<div class="clear"></div>
</div><?php endif;?>