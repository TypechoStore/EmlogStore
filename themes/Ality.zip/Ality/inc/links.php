<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="links">
	<ul>
	<?php
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');{
	?>
     <li>
	<?php foreach($link_cache as $value): ?><img href="<?php echo $value['url']; ?>" src="http://www.521php.com/api/fav/?url=<?php echo $value['url']; ?>" width="15px" height="15px"/>
	<a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?>　</a>  
	 <?php endforeach; ?>
	</li>
<?php }?>
	</ul>
<div class="clear"></div>
</div>