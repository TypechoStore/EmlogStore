<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="authorbio">看了本文是不是觉得很赞，那就赶紧点击下面按钮分享给身边的朋友吧！
<div class="bdsharebuttonbox">
<a href="#" class="bds_copy" data-cmd="copy" title="复制本页网址"></a>
<a href="#" class="bds_print" data-cmd="print" title="打印"></a>
<a href="#" class="bds_bdysc" data-cmd="bdysc" title="分享到百度云收藏"></a>
<a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a>
<a href="#" class="bds_tqf" data-cmd="tqf" title="分享到腾讯朋友"></a>
<a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a>
<a href="#" class="bds_sqq" data-cmd="sqq" title="分享到QQ好友"></a>
<a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a>
<a href="#" class="bds_fx" data-cmd="fx" title="分享到飞信"></a>
<a href="#" class="bds_tieba" data-cmd="tieba" title="分享到百度贴吧"></a>
<a href="#" class="bds_renren" data-cmd="renren" title="分享到人人网"></a>
<a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a>
<a href="#" class="bds_qq" data-cmd="qq" title="分享到QQ收藏"></a>
<a href="#" class="bds_kaixin001" data-cmd="kaixin001" title="分享到开心网"></a>
<a href="#" class="bds_mogujie" data-cmd="mogujie" title="分享到蘑菇街"></a>
<a href="#" class="bds_douban" data-cmd="douban" title="分享到豆瓣网"></a>
<a href="#" class="bds_qy" data-cmd="qy" title="分享到奇艺奇谈"></a>
<a href="#" class="bds_mail" data-cmd="mail" title="邮件分享"></a></div>
<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"1","bdSize":"16"},"share":{}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>
</div>