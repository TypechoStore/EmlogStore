<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<ul id="scroll">
	<li><a class="scroll_t" ><i class="icon-scroll_t"></i></a></li>
	<?php if (isset($logid) || !empty($tws)) : ?>
		<li><a class="scroll_c" ><i class="icon-scroll_c"></i></a></li>
	<?php else: ?><?php endif; ?>
	<li><a class="scroll_b"><i class="icon-scroll_b"></i></a></li>
</ul>