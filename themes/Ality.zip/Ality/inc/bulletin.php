<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="bulletin_div" class="bulletin_div">
	<div id="bulletin_begin">
		<ul>
		<li>博主正在偷文章中。。。。</li>
		</ul>
	</div>
	<div id="bulletin_end"></div>
</div>
<script type="text/javascript">ScrollImgLeft();</script>