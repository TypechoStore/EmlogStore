<?php 
/**
 * 侧边栏组件、页面模块
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\" class='upp'>".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
		<aside class="widget widget_recent_comments"id="recent_comments-2">
        <h3 class="widget-title"><i class="icon-st"></i>个人资料</h3>
        <div class="message-widget"id="message">
          <ul>
            站长昵称：<?php echo $name; ?><br/>
            个人说明：<?php echo $user_cache[1]['des']; ?>
        </UL>
    </div>
    </aside>
<?php }?>
<?php
//widget：日历
function widget_calendar($title){ ?>
	<aside  class="widget widget_calendar">
    <div id="calendar_wrap">
	<div id="wp-calendar">
    </div>
	</div>
    	<script>sendinfo('<?php echo Calendar::url(); ?>','wp-calendar');</script>
    </aside>
<?php }?>
<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
<aside class="widget widget_tag_cloud" id="tag_cloud-2">      
        <h3 class="widget-title"><i class="icon-st"></i>标签</h3>
        <div class="tagcloud">
		<?php 
		shuffle ($tag_cache);
		 $tag_cache = array_slice($tag_cache,0,43);
		foreach($tag_cache as $value): ?>
        <a  href="<?php echo Url::tag($value['tagurl']); ?>"  class="tag-link-<?php echo rand(12, 49) ?>" style="font-size: 14px;"><?php echo $value['tagname']; ?>(<?php echo $value['usenum']; ?>)</a><?php endforeach; ?>
        </div><div class="clear"></div>
    </aside>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
<aside class="widget widget_tag_cloud" id="tag_cloud-2">      
        <h3 class="widget-title"><i class="icon-st"></i>分类</h3>
      <ul><li>
	<?php foreach($sort_cache as $value):if ($value['pid'] != 0) continue;?><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?></a> &nbsp;<?php endforeach; ?>
</li></ul><div class="clear"></div>
    </aside>
<?php }?>
<?php
//widget：最新微语
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	
	?>
<aside class="widget widget_tag_cloud" id="tag_cloud-2">
        <h3 class="widget-title"><i class="icon-st"></i>最新微语</h3>
          <ul> 
    <?php foreach($newtws_cache as $value):?><li>
    <a href="<?php echo BLOG_URL; ?>t" title="<?php echo $value['autohor']; ?>"><?php echo $value['t']; ?><?php echo $img;?></a><SPAN style="float:right;"><?php echo gmdate('Y-n-j G:i', $value['date']); ?></SPAN></li>
    <?php endforeach; ?>
    </ul>
</aside>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE;
	$com_cache = $CACHE->readCache('comment');
	?>
<aside class="widget widget_recent_comments"id="recent_comments-2">
        <h3 class="widget-title"><i class="icon-st"></i>最新评论</h3>
        <div class="message-widget"id="message">
          <ul>
		<?php
		foreach($com_cache as $value):
		$articleUrl = Url::log($value['gid']);
		$url = Url::comment($value['gid'], $value['page'], $value['cid']);
		$db = MySql::getInstance();
		$sql = "SELECT title FROM ".DB_PREFIX."blog WHERE gid=".$value['gid'];
		$ret = $db->query($sql);
		$row = $db->fetch_array($ret);
		$articleTitle = $row['title'];
		$db = MySql::getInstance();
		$sql = "SELECT url FROM ".DB_PREFIX."comment WHERE cid=".$value['cid'];
		$ret = $db->query($sql);
		$row = $db->fetch_array($ret);
		$value['content']=preg_replace("/{smile:(([1-4]?[0-9])|50)}/",'<img class="lazy" src="' . TEMPLATE_URL. 'img/smilies/$1.gif" />',$value['content'])
		?>
		<li>
        
        <a href="<?php echo $url; ?>" title="发表于&gt;<?php echo $articleTitle; ?>，点击查看详情">
							<img class="avatar" src="<?php echo getGravatar($value['mail'], 35); ?>" alt="avatar" data-original="<?php echo getGravatar($value['mail'], 35); ?>" style="opacity: 1;">							<strong><div class="comment_author"><?php echo $value['name']; ?></div></strong><?php echo $value['content']; ?></a>
              </li>
		<?php endforeach; ?>
		</ul>
      </div>
    </aside>
<?php }?>
<?php
//widget：最新文章
function widget_newlog($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
<aside class="widget widget_random_post"id="random_post-2">
        <h3 class="widget-title"><i class="icon-st"></i>最新文章</h3>
        <div id="random_post_widget">
          <ul>
	<?php foreach($newLogs_cache as $value): ?> 
    <li class="zan-list clearfix">
    <a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>"><?php echo mb_substr($value['title'],0,50,'utf8');?></a></li><?php endforeach; ?>
    </ul>
    </aside>
<?php }?>
<?php
//widget：热门文章
function widget_hotlog($title){
	$index_hotlognum = Option::get('index_hotlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getHotLog($index_hotlognum);?>
<aside class="widget widget_random_post"id="random_post-2">
        <h3 class="widget-title"><i class="icon-st"></i>热门文章</h3>
        <div id="random_post_widget">
          <ul>
<?php foreach($randLogs as $value): ?>
<li class="zan-list clearfix"><a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>"><?php echo mb_substr($value['title'],0,50,'utf8');?></a></li><?php endforeach; ?>
</ul>
</aside>
<?php }?>
 <?php
//widget：随机文章
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
 <aside class="widget widget_random_post"id="random_post-2">
        <h3 class="widget-title"><i class="icon-st"></i>随机文章</h3>
        <div id="random_post_widget">
          <ul>
		  <?php foreach($randLogs as $value): ?>
          <li><a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>" rel="bookmark"><?php echo mb_substr($value['title'],0,50,'utf8');?></a></li><?php endforeach; ?>
</ul>
</div>
</aside>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
<aside class="widget widget_search"id="search-2">
       <div id="searchbar">
        <form method="get" id="searchform" class="form-inline clearfix hidden-xs" action="<?php echo BLOG_URL; ?>index.php">
        <input class="form-control" type="text" name="keyword" id="s" placeholder="搜索关键词..." />
        <input type="submit" id="searchsubmit" value="搜索">
      </form>
      </div>
    </aside>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
<aside class="widget widget_archive" id="archives-2">
        <h3 class="widget-title"><i class="icon-st"></i>归档</h3>
        <ul>
		<?php foreach($record_cache as $value): ?><li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a><?php endforeach; ?></li>
    </ul>
    <div class="clear"></div>
    </aside>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){?>
<aside class="widget widget_text"id="text-2">
        <h3 class="widget-title"><i class="icon-st"></i><?php echo $title; ?></h3>
        <div class="textwidget">
	<?php echo $content; ?></div>
<div class="clear"></div>
	</aside>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
    //if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
	?>
<aside class="widget widget_tag_cloud" id="tag_cloud-2">      
        <h3 class="widget-title"><i class="icon-st"></i>链接</h3>
      <ul>
	<?php foreach($link_cache as $value): ?>
	<a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a>&nbsp;
	<?php endforeach; ?></ul>
	<div class="clear"></div>
    </aside>
<?php }?> 
<?php
//blog：热门文章
function blog_hotlog($title){
	$index_hotlognum = Option::get('index_hotlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getHotLog($index_hotlognum);?>
<aside class="widget widget_random_post"id="random_post">
    <h3 class="widget-title">热门文章</h3>
        <div id="random_post_widget">
          <ul>
<?php foreach($randLogs as $value): ?>
<li><a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>"><?php echo mb_substr($value['title'],0,50,'utf8');?></a></li><?php endforeach; ?>
</ul>
</aside>
<?php }?>
 <?php
//blog：随机文章
function blog_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
 <aside class="widget widget_random_post"id="random_post">
        <h3 class="widget-title">随机文章</h3>
        <div id="random_post_widget">
          <ul>
		  <?php foreach($randLogs as $value): ?>
          <li><a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>" rel="bookmark"><?php echo mb_substr($value['title'],0,50,'utf8');?></a></li><?php endforeach; ?>
</ul>
</div>
</aside>
<?php }?>
<?php
//blog：MINI导航
function blog_mini_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	?>
<?php
	foreach($navi_cache as $value):
        if ($value['pid'] != 0) {
            continue;
        }
		if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):
			?>
            
	<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/'); $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'current-menu-item current_page_item' : '';?>
        <div class="menu-%e5%95%8a%e5%95%8a%e5%95%8a-container">
            <ul class="menu">
        <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-<?php echo $current_tab;?>">
<a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>>
<?php echo $value['naviname']; ?>
</a></li></ul></div>
<?php endforeach; ?>
<?php }?>
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	?>
<?php
	foreach($navi_cache as $value):
        if ($value['pid'] != 0) {
            continue;
        }
		if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):
			?>
            <li id="menu-item" class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="<?php echo BLOG_URL; ?>admin"><i class="fa fa-cog"></i> 管理</a>
    <ul class="dropdown-menu">
	 <li  class="menu-item menu-item-type-post_type menu-item-object-page"><a href="<?php echo BLOG_URL; ?>admin/comment.php">评论</a></li>
     <li  class="menu-item menu-item-type-post_type menu-item-object-page"><a href="<?php echo BLOG_URL; ?>admin/write_log.php">发表</a></li>
     <li  class="menu-item menu-item-type-post_type menu-item-object-page"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
</ul></li>
	<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/'); $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'current-menu-item current_page_item' : '';?>
        <li id="menu-item" class="menu-item menu-item-type-post_type menu-item-object-page  <?php echo $current_tab;?>" <?php if($value['naviname'] == "首页"):?> style="display:none;"<?php endif;?>>
			<a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>>
				<?php echo $value['naviname']; ?>
			</a>
<?php if (!empty($value['children'])) :?>
      <ul class="sub-menu sf-js-enabled sf-shadow">
                <?php foreach ($value['children'] as $row){
                        echo '<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-<?php echo $current_tab;?>"><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></li>';
                }?>
			</ul>
            <?php endif;?>
            <?php if (!empty($value['childnavi'])) :?>
      <ul class="sub-menu sf-js-enabled sf-shadow">
                <?php foreach ($value['childnavi'] as $row){
                        $newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';
                        echo '<li  class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-<?php echo $current_tab;?>"><a href="' . $row['url'] . "\" $newtab >" . $row['naviname'].'</a></li>';
                }?>
			</ul>
            <?php endif;?>
</li>
<?php endforeach; ?>
<li id="menu-item" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="<?php sbkk_logs();?>"><i class="fa   fa-hand-o-right"></i> 随便看看</a></li>
<?php }?>
<?php
//blog：分类导航
function blog_sort_navi(){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	<ul>
	<?php
	foreach($sort_cache as $value):
		if ($value['pid'] != 0) continue;
	?>
	<li class="cat-item cat-item current-cat">
	<a href="<?php echo Url::sort($value['sid']); ?>" ><?php echo $value['sortname']; ?></a>
	<?php if (!empty($value['children'])): ?>
		<ul class="children">
		<?php
		$children = $value['children'];
		foreach ($children as $key):
			$value = $sort_cache[$key];
		?>
		<li class="cat-item cat-item">
			<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?></a>
		</li>
		<?php endforeach; ?>
		</ul>
    </li>
	<?php endif; ?>
	<?php endforeach; ?>
	</ul>
<?php }?>
<?php
//blog：置顶
function topflg($top, $sortop='n', $sortid=null){
    if(blog_tool_ishome()) {
       echo $top == 'y' ? "<span class=\"sticky-ico\" />荐</span>" : '';
    } elseif($sortid){
       echo $sortop == 'y' ? "<span class=\"sticky-ico\" />荐</span>" : '';
    }
	
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == 'admin' || $author == UID ? '<span class="edit"><i class="icon-edit"></i> <a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" class="post-edit-link" target="_blank">编辑</a></span>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
    <a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>" rel="category tag"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
    <?php else: ?>
    <a rel="category tag">暂无分类</a>
	<?php endif;?>
<?php }?>
<?php
//blog：日志标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '本文标签：';
		foreach ($log_cache_tags[$blogid] as $key=>$value){
			$tag .= "<a href=\"".Url::tag($value['tagurl'])."\" class=\"tag".$key."\">".$value['tagname'].'</a>';
		}
		echo $tag.'';
	}else {
		echo '此文暂无标签';
	}
}
?>
<?php
//blog：文章作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" class='upp' $title>$author</a>";
}
?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
	extract($neighborLog);?>
    <span style="float:left;">
	<?php if($prevLog):?>
	<a href="<?php echo Url::log($prevLog['gid']) ?>" title="<?php echo $prevLog['title'];?>">【上一篇】<?php echo $prevLog['title'];?></a>
    <?php else: ?>
    <a title="没错这就是本分类第一篇文章">【上一篇】这就是第一篇了</a>
	<?php endif;?></span><span style="float:right;">
	<?php if($nextLog):?>
		<a href="<?php echo Url::log($nextLog['gid']) ?>" title="<?php echo $nextLog['title'];?>">【下一篇】<?php echo $nextLog['title'];?></a>
        <?php else: ?>
    <a title="没错这就是本分类最后一篇文章">【下一篇】这就是最后一篇了</a>
	<?php endif;?></span>
    <div class="clear"></div>
<?php }?>
<?php
//blog：评论列表
function blog_comments($comments,$comnum,$params){
    extract($comments);
    if($commentStacks): ?>

	<a name="comments" class="comment-top"></a>
	<h2 class="comments-title">
		<?php echo $comnum;?> 条评论</h2>
	<?php endif; ?>
     <ol class="comment-list">
     	<?php
	$isGravatar = Option::get('isgravatar');
	$comnum = count($comments);
	foreach($comments as $value){
		if($value['pid'] != 0){
			$comnum--;
			}
		}
			$page = isset($params[5])?intval($params[5]):1;
			$i= $comnum - ($page - 1)*Option::get('comment_pnum');
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['content'] = preg_replace("/{smile:(([1-4]?[0-9])|50)}/",'<img src="' . TEMPLATE_URL. 'img/smilies/$1.gif" />',$comment['content']);
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank" class="upps">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<a name="<?php echo $comment['cid']; ?>"></a>
     <li class="comment even thread-even depth" id="comment-<?php echo $comment['cid']; ?>">
			<div id="div-comment-<?php echo $comment['cid']; ?>" class="comment-body-<?php echo $comment['cid']; ?>">
		<div class="comment-author vcard"><?php if($isGravatar == 'y'): ?>
		<img class="avatar" src="<?php echo getGravatar($comment['mail']); ?>" alt="avatar" data-original="<?php echo getGravatar($comment['mail']); ?>"><?php endif; ?>
		<strong><?php echo $comment['poster']; ?></strong>
        <?php $mail_str="\"".strip_tags($comment['mail'])."\"";echo_levels($mail_str,"\"".$comment['url']."\""); ?>
		<span class="comment-meta commentmetadata">
			<a>
			<?php echo $comment['date']; ?></a>
				<span style="color:#04a4cc;">
				<?php if ($i == 1){ echo "呦，果断人中龙凤!坐上了沙发<sup>#</sup>";}
				elseif ($i == 2){echo "自古二楼出人才。坐上了椅子<sup>#</sup>";}
				elseif ($i == 3){ echo "越有内涵的人越低调出现。爱坐板凳<sup>#</sup>";}
				elseif ($i == 4){ echo "四楼，你来晚了。不过可以坐地板<sup>#</sup>";}
				elseif ($i == 5){ echo "五楼，你真的来晚了。一生复能几，倏如流电惊。<sup>#</sup>";}
				elseif ($i == 6){ echo "六楼，你的出现，全场震动。<sup>#</sup>";}
				elseif ($i == 7){ echo "七楼，是鸟总会有飞的一天。<sup>#</sup>";}
				elseif ($i == 8){ echo "八楼，手拿菜刀砍电线，一路火花带闪电。<sup>#</sup>";}
				elseif ($i == 9){ echo "九楼，早起的鸟儿有虫吃。后面什么来着？<sup>#</sup>";}
				elseif ($i == 10){ echo "十楼，成不了楷模，当个凯子也是可以的。<sup>#</sup>";}
				elseif ($i == 11){ echo "十一楼，楼上的，你们没话了。。。<sup>#</sup>";}
				elseif ($i == 66){ echo "六十六楼，你的出现，真的全场震动了，六六大顺啊！<sup>#</sup>";}	
				elseif ($i == 100){ echo "恭喜！幸运的100......分，不对，是楼<sup>#</sup>";}
				else{ echo " $i 楼<sup>#</sup>";}?></span>
		</span>
	</div>
	<p><?php echo $comment['content']; ?><span class="reply" style="float:right;"><a class="comment-reply-login" style="color: #8b8b8b;" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a></span></p>
			</div>
		<?php blog_comments_children($comments, $comment['children']); ?>
	</li>
	<?php $i--;endforeach; ?></ol>
	<?php if($commentPageUrl) {?>
<nav id="pagenavi"><?php echo $commentPageUrl;?></nav>
    <?php } ?>
<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child) {
	$comment = $comments[$child];
	$comment['content'] = preg_replace("/{smile:(([1-4]?[0-9])|50)}/",'<img src="' . TEMPLATE_URL. 'img/smilies/$1.gif" />',$comment['content']);
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank" class="upps">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<ul class="children">
		<a name="<?php echo $comment['cid']; ?>"></a>
     <li class="comment byuser comment-author-123456 bypostauthor odd alt depth-<?php echo $comment['cid']; ?> parent" id="comment-<?php echo $comment['cid']; ?>">
			<div id="div-comment-<?php echo $comment['cid']; ?>" class="comment-body">
		<div class="comment-author vcard"><?php if($isGravatar == 'y'): ?>
		<img class="avatar" src="<?php echo getGravatar($comment['mail']); ?>" alt="avatar" data-original="<?php echo getGravatar($comment['mail']); ?>"><?php endif; ?>
		<strong><?php echo $comment['poster']; ?></strong>
        <?php $mail_str="\"".strip_tags($comment['mail'])."\"";echo_levels($mail_str,"\"".$comment['url']."\""); ?>
		<span class="comment-meta commentmetadata">
			<a>
			<?php echo $comment['date']; ?></a></span>
			
		</span>
	</div>
	<p><?php echo $comment['content']; ?><span class="reply" style="float:right;"><a class="comment-reply-login" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)" style="color: #8b8b8b;">回复</a></span></p>
			</div>
			<?php blog_comments_children($comments, $comment['children']);?>
	</li>
</ul><!-- .children -->
	<?php } ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
<div id="comment-place">
	<div class="comment-post" id="comment-post">
    <div id="comments" class="comments-area">
    <div id="respond" class="comment-respond">
		<h3 id="reply-title" class="comment-reply-title"><i class="fa fa-pencil"></i> 欢迎留言 <small><span class="cancel-reply" id="cancel-reply" style="display:none"><a href="javascript:void(0);" onclick="cancelReply()" id="cancel-comment-reply-link" >取消回复</a></span></small></h3>
		<form action="<?php echo BLOG_URL; ?>index.php?action=addcom" method="post" id="commentform" class="comment-form">
			<div id="commentform-error" class="alert hidden"></div>	
            <?php if(ROLE == 'visitor'): ?>
<form action="<?php echo BLOG_URL; ?>index.php?action=addcom" method="post" id="commentform">
				<div id="comment-author-info">
					<p class="comment-form-author">
					  <input type="text" name="comname" id="author" value="<?php echo $ckname; ?>" tabindex="3">
						<label for="author">昵称（必填）</label>
					</p>
					<p class="comment-form-email">
					  <input type="text" name="commail" id="email" value="<?php echo $ckmail; ?>" tabindex="4">
						<label for="email">邮箱（必填）</label>
					</p>
					<p class="comment-form-url">
					  <input type="text" name="comurl" id="url" value="<?php echo $ckurl; ?>"  tabindex="5">
						<label for="url">网址（选填）</label>
					</p>
	  </div>
                <?php else:
          $CACHE = Cache::getInstance();
	       $user_cache = $CACHE->readCache('user');
        ?>
        <div class="user_avatar">
        <?php if($user_cache[$author]['photo']['src']):?>
<?php if (!empty($user_cache[$author]['photo']['src'])): ?>
<img src="<?php echo BLOG_URL.$user_cache[$author]['photo']['src']; ?>" class="avatar avatar-32 photo" height="32" width="32" style="opacity: 0.5;">
<?php endif; ?>
<?php else:?>
<img src="<?php echo getGravatar($user_cache[UID]['mail']); ?>" class="avatar avatar-32 photo" height="32" width="32" style="opacity: 0.5;">
<?php endif; ?>
<?php 
          $aql = "SELECT * FROM ".DB_PREFIX."user WHERE uid='".UID."'";
      $ery=mysql_query($aql);
          while ($rest = mysql_fetch_array($ery)) {
          
      echo "用户账号:".$rest['username']."丨用户名称:".$rest['nickname'];?>    
 <?php } ?>----<a href="<?php echo BLOG_URL; ?>admin/?action=logout" title="登出此帐户">登出？</a></div>
		<?php endif; ?>
				<p class="comment-form-comment"> <?php include View::getView('inc/smiley');?><textarea id="comment" name="comment" rows="8" tabindex="6" onkeydown="if(event.altKey && window.event.keyCode == 83) {document.getElementById('submit').click();return false;}; if(event.ctrlKey&&event.keyCode==13){document.getElementById('submit').click();return false;};"></textarea>  
            <div id="loading" style="display: none;"> 正在提交, 请稍候...</div>  
            <div id="error" style="display: none;">#</div>        
		  <p class="form-submit"><?php echo $verifyCode; ?>
			<input id="submit" name="submit" type="submit" tabindex="5" value="提&nbsp;交(ctrl+ender)">
			<input id="reset" name="reset" type="reset" tabindex="6" value="重&nbsp;写">
			<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
			<input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/></p>
			</form>
			<script type="text/javascript">
				document.getElementById("comment").onkeydown = function (moz_ev){
				var ev = null;
				if (window.event){
				ev = window.event;
				}else{
				ev = moz_ev;
				}
				if (ev != null && ev.ctrlKey && ev.keyCode == 13){
				document.getElementById("submit").click();}
				}
			</script>
     
	</div></div></div></div>
<?php endif; ?>
</div>
    <?php }?>

<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>

<?php
//获取附件第一张图片
function getThumbnail($blogid){
    $db = MySql::getInstance();
    $sql = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$blogid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";
    //die($sql);
    $imgs = $db->query($sql);
    $img_path = "";
    while($row = $db->fetch_array($imgs)){
         $img_path .= BLOG_URL.substr($row['filepath'],3,strlen($row['filepath']));
    }
    return $img_path;
}
?>
<?php
function handlearticledes($des) {
	$str = preg_replace("/(<\/?)(\w+)([^>]*>)/e",'',$des);
	$str = preg_replace("/阅读全文&gt;&gt;/",'',$str);
	$str = strip_tags($str,""); 
    $str = ereg_replace("\t","",$str); 
    $str = ereg_replace("\r\n","",$str); 
    $str = ereg_replace("\r","",$str); 
    $str = ereg_replace("\n","",$str); 
    $str = ereg_replace(" "," ",$str); 
	return mb_substr($str,0,200,'utf8').'...';
}
?>
<?php
function index_t(){
	$t = MySql::getInstance();
	?>
	<?php
	$sql = "SELECT id,content,img,author,date,replynum FROM ".DB_PREFIX."twitter ORDER BY `date` DESC LIMIT 3";
	$list = $t->query($sql);
	while($row = $t->fetch_array($list)){
	?><li>
<a href="<?php echo BLOG_URL; ?>t" rel="bookmark"><i class="icon-bulletin"></i><?php echo $row['content'];?></a></li>
<?php }?>
<?php } ?>
<?php
function timer_start() {
  global $timestart;
  $mtime = explode( ' ', microtime() );
  $timestart = $mtime[1] + $mtime[0];
  return true;
}
timer_start();
function timer_stop( $display = 0, $precision = 3 ) {
  global $timestart, $timeend;
  $mtime = explode( ' ', microtime() );
  $timeend = $mtime[1] + $mtime[0];
  $timetotal = $timeend - $timestart;
  $r = number_format( $timetotal, $precision );
  if ( $display )
    echo $r;
  return $r;
}
?>
<?php
//文章关键词
function log_key_words($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .="".$value['tagname'].',';
		}
		echo substr($tag,0,-1);
	}
}
?>
<?php
//随便看看
function sbkk_logs() {
$db = MySql::getInstance();
$sql = "SELECT gid FROM ".DB_PREFIX."blog WHERE type='blog' and hide='n' ORDER BY rand() LIMIT 0,1";
$sbkk_logs_list = $db->query($sql);
while($row = $db->fetch_array($sbkk_logs_list)){ 
echo Url::log($row['gid']);}
}?>
<?php
//comment：输出评论人等级
function echo_levels($comment_author_email,$comment_author_url){
  $DB = MySql::getInstance();
  global $CACHE;$user_cache = $CACHE->readCache('user'); 
  $adminEmail = '"'.$user_cache[1]['mail'].'"';
  if($comment_author_email==$adminEmail)
  {
    echo '<a class="vip" href="mailto:'.$user_cache[1]['mail'].'" title="管理员认证"></a><a class="vip7" title="特别认证"></a>';
  }
  $sql = "SELECT cid as author_count,mail FROM ".DB_PREFIX."comment WHERE mail != '' and mail = $comment_author_email and hide ='n'";
  $res = $DB->query($sql);
  $author_count = mysql_num_rows($res);
   if($author_count>=2 && $author_count<10 && $comment_author_email!=$adminEmail)
    echo '<a class="vip1" title="路过酱油 LV.1"></a>';
  else if($author_count>=10 && $author_count<20 && $comment_author_email!=$adminEmail)
    echo '<a class="vip2" title="偶尔光临 LV.2"></a>';
  else if($author_count>=20 && $author_count<40 && $comment_author_email!=$adminEmail)
    echo '<a class="vip3" title="常驻人口 LV.3"></a>';
  else if($author_count>=40 && $author_count<80 && $comment_author_email!=$adminEmail)
    echo '<a class="vip4" title="以博为家 LV.4"></a>';
  else if($author_count>=80 &&$author_count<160 && $comment_author_email!=$adminEmail)
    echo '<a class="vip5" title="情牵小博 LV.5"></a>';
  else if($author_count>=160 && $author_coun<320 && $comment_author_email!=$adminEmail)
    echo '<a class="vip6" title="为博终老 LV.6"></a>';
  else if($author_count>=50 && $author_coun<60 && $comment_author_email!=$adminEmail)
    echo '<a class="vip7" title="三世情牵 LV.7"></a>';
}
?>