<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<nav class="crumbs">现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a>
    ><?php blog_sort($logid); ?>>正文_<?php echo $log_title; ?>
    </nav>
<div id="primary" class="site-content">
	<section class="content">
			<article id="post" class="post post type-post status-publish format-standard hentry category">
				<header class="single-header">
					<h1 class="single-title"><?php echo $log_title; ?></h1>
					<div class="single-meta">
						<span class="date"><i class="icon-date"></i><?php echo gmdate('20y年m月d日', $date); ?></span>
						<span class="cat"><i class="icon-cat"></i><?php blog_sort($logid); ?></span>
						<span class="comment"><i class="icon-comment"></i><?php if($comnum):?><?php echo $comnum; ?>条评论<?php else:?>暂无评论<?php endif;?></span>
						<span class="views"><i class="icon-views"></i>阅读<?php echo $views; ?>次</span>
						<?php editflg($logid,$author); ?>
					</div>
					<!-- .entry-meta -->
				</header>
				<!-- .single-header -->

				<div class="single-content">
					<?php echo $log_content; ?>
					<?php doAction('log_related', $logData); ?>
					<div class="clear"></div>
				</div>
				<!-- .single-content -->
			</article>
	</section>
    <div class="single-tag"><?php blog_tag($logid); ?></div>
    <?php include View::getView('inc/share');?>
    <?php include View::getView('inc/copyright');?>
	<?php include View::getView('inc/hot');?>
    <!-- #content -->
	<nav class="nav-single">
		<?php neighbor_log($neighborLog); ?>
	</nav>
     <div id="comments" class="comments-area">
	<?php blog_comments($comments,$comnum,$params); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
<!-- #primary -->
<?php
 include View::getView('side');
 include View::getView('footer');
?>