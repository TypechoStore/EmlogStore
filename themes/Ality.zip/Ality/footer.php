<div id="ad-main" class="post post type-post status-publish format-standard hentry category-uncategorized" <?php echo _g('adfooterxs');?>><?php echo _g('adfooter');?>
</div><br/>
<?php include View::getView( 'inc/login' ); ?>
<?php include View::getView( 'inc/links' ); ?>
</div><footer id="footer">
	<div class="site-info">
		Copyright &copy; <?php echo $blogname; ?>  保留所有权利.&nbsp;&nbsp;<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>
		<span class="info-add">
            自豪的采用 <a href="http://www.emlog.net" title="采用emlog系统">EMLOG</a> 驱动.主题设计<a title="主题设计：知更鸟" href="http://zmingcx.com" target="_blank" rel="nofollow"> 知更鸟</a>. 主题移植 <a href="http://azt-lmt.com" rel="nofollow" target="_blank" title="一个爱折腾的高三党">刘培杰</a> <?php if ($timer == "yes"): ?>. 加载耗时 <?php timer_stop(3) ?>s <?php else:?><?php endif;?><?php if(_g('tongji')){?><?php echo _g('tongji'); ?><?php }else{?><?php }?><?php echo $footer_info; ?>
		</span>
	</div>
	<!-- .site-info -->
    <div id="sidr" class="sidr left"><?php blog_mini_navi();?></div>
<?php include View::getView( 'inc/scroll' ); ?>
</footer>
<?php doAction('index_footer'); ?>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js?ver=1.4.2"></script><style type="text/css" adt="123"></style>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/script.js?ver=1.0"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.sidr.min.js?ver=1.2.1"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.lazyload.min.js?ver=1.9.3"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/script-pc.js?ver=1.0"></script>
<!--[if lt IE 9]>
<script src="<?php echo TEMPLATE_URL; ?>js/html5.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/css3-mediaqueries.js" type="text/javascript"></script>
<![endif]-->
<!--[if lt IE 7]><script src="<?php echo TEMPLATE_URL; ?>js/ie6.js" type="text/javascript"></script><![endif]-->
<!-- #footer -->
<script type="text/javascript">
$(".sidebar-roll").smartFloat();
</script>
</div><!-- #page -->
</div><!-- #main -->
</div>
</div>
</body>
</html>