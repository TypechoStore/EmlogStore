/**
 * script v1.0 by Ality.
 * 用于PC端
 */

// 悬停
$(document).ready(function(){
$('.content').hover(
	function() {
		$(this).find('.heavy-r').stop(true,true).fadeIn();
	},
	function() {
		$(this).find('.heavy-r').stop(true,true).fadeOut();
	}
);
});
// Pop-up box
$(function() {
    $("a").each(function(b) {//这里是控制标签
        if (this.title) {
            var c = this.title;
            var a = 30;
            $(this).mouseover(function(d) {
                this.title = "";
                $("body").append('<div id="tooltip">' + c + "</div>");
                $("#tooltip").css({
                    left: (d.pageX + a) + "px",
                    top: d.pageY + "px",
                    opacity: "0.8"
                }).show(250)
            }).mouseout(function() {
                this.title = c;
                $("#tooltip").remove()
            }).mousemove(function(d) {
                $("#tooltip").css({
                    left: (d.pageX + a) + "px",
                    top: d.pageY + "px"
                })
            })
        }
    })
});
