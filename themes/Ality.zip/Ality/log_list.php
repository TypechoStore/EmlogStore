<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="ad-main" class="post post type-post status-publish format-standard hentry category-uncategorized" <?php echo _g('adindexxs');?>><?php echo _g('adindex');?>
</div>
<?php if("http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] == BLOG_URL): ?>
<nav class="crumbs">现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a>
    </nav>
<?php else: ?>
<nav class="crumbs">现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a>
   > <?php echo $sortName;?><?php echo $tagurl;?><?php echo $_GET['keyword'];?>
    </nav>
    <?php endif ;?>
    <?php include View::getView('inc/bulletin');?>
    <?php doAction('index_loglist_top'); ?>
<div id="primary" class="site-content">
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?> 
<article id="post" class="post post type-post status-publish format-standard hentry category-uncategorized">
	<section class="content">
<?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?>
		<header class="entry-header">
        <?php if(date('ymd',gmmktime()) - gmdate('ymd', $value['date']) <= 2) echo '<a title="最近两天内更新"><span class="new-ico" >NEW</span></a>'; ?>
			<div class="title-heavy"><div class="heavy-l"></div><div class="heavy-r"></div></div>
			<h1 class="entry-title"><a href="<?php echo $value['log_url']; ?>" rel="bookmark" title="详细阅读 <?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></h1>
		</header>
		<!-- .entry-header -->
		<div class="entry-content">
			<figure class="thumbnail">
				<?php include View::getView( 'inc/thumbnail' ); ?>
			</figure> 
			<div class="entry-site">
				<?php echo $value['log_description'] = handlearticledes(subString(trim(strip_tags($value['log_description'])), 0,380));?>
				<div class="clear"></div>
			</div>
			<div class="clear"></div>
			<div class="entry-meta">
				<span class="meta-site">
					<span class="date"><i class="icon-date"></i> <?php echo gmdate('Y年m月d日', $value['date']); ?></span>
					<span class="cat"><i class="icon-cat"></i><?php blog_sort($value['logid']); ?> </span>
					<span class="comment"><i class="icon-comment"></i><a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?>条评论</a></span>
						<span class="views"><i class="icon-views"></i>阅读<?php echo $value['views']; ?>次</span>
						<?php editflg($value['logid'],$value['author']); ?>
				<span class="entry-more"><a href="<?php echo $value['log_url']; ?>" rel="bookmark" title="阅读全文 <?php echo $value['log_title']; ?>">阅读全文</a></span>
			</div>
			<!-- .entry-meta -->
		</div>
		<!-- .entry-content -->
	</section></article>
    <?php endforeach;else:?>
    <section class="content">
		<header class="entry-header">
			<div class="title-heavy"><div class="heavy-l"></div><div class="heavy-r"></div></div>
			<h1 class="entry-title"><a rel="bookmark" title="Sorry,没找到！！！">Sorry,没找到相关 <?php echo $sortName;?><?php echo $tagName;?><?php echo $_GET['keyword'];?> 的内容！！！</a></h1>
		</header>
		<!-- .entry-header -->
		<div class="entry-content">
			<div class="entry-site">
				站长太懒了，还没在这块添加文章，请通知站长赶紧添加吧
				<div class="clear"></div>
			</div>
			<div class="clear"></div>
			<!-- .entry-meta -->
		</div>
		<!-- .entry-content -->
	</section>
    <?php include View::getView('contact');?>
    </article>
  <?php endif;?> 
	<!-- #content -->
    <nav id="pagenavi"><?php echo $page_url;?></nav>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>