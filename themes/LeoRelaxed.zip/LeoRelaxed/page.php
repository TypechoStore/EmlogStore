<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="container">
<div id="posts">
<div class="post">
<h2><?php echo $log_title; ?></h2>
	<div class="entry">
	<p><?php echo $log_content; ?></p>					 
</div>
	<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
  </div>
 <?php include ('side.php');?>
	</div>
 	</div>
 	 </div>
 	 </div>
<?php include ('footer.php');?>