<?php
/*
Template Name:LeoRelaxed
Description:一款蓝色的清爽主题
Version:1.0
Author:leo
Author Url:http://www.asxyu.com
Sidebar Amount:1
ForEmlog:4.2.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
	<div id="container">
	<div id="header">

	<h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
	
   <h3><?php echo $bloginfo; ?></h3>
	<div id="search">
              <form method="post" id="searchform" action="">
	<div>
<input type="text" name="s" id="s" onblur="this.value=(this.value=='') ? 'Search' : this.value;" onfocus="this.value=(this.value=='Search') ? '' : this.value;" value="Search">
	</div>
</form>	</div>
	
</div>
	<div id="navbar">
	<ul>
	<li class="<?php echo $curpage == CURPAGE_HOME ? 'current_page_item' : 'common';?>"><a href="<?php echo BLOG_URL; ?>">首页</a></li>
	<?php if($istwitter == 'y'):?>
	<li class="<?php echo $curpage == CURPAGE_TW ? 'current_page_item' : 'common';?>"><a href="<?php echo BLOG_URL; ?>t/">微语</a></li>
	<?php endif;?>
	<?php 
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach ($navi_cache as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	$val['is_blank'] = $val['newtab'] == 'y' ? 'target="_blank"' : '';
    $val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
	?>
	<li class="<?php echo isset($logid) && $key == $logid ? 'current_page_item' : 'common';?>"><a href="<?php echo $val['url']; ?>" target="<?php echo $val['is_blank']; ?>"><?php echo $val['naviname']; ?></a></li>
	<?php endforeach;?>
	<?php doAction('navbar', '<li class="common">', '</li>'); ?>
 	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
 
	<?php endif; ?>
				</ul>
 
  </div><!-- end #nav-->