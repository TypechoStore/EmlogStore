<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
<div id="posts">
<div class="post">
<h2><?php topflg($top); ?><a href="" title="<?php echo $log_title; ?>"><?php echo $log_title; ?></a></h2>
	<p>	Psot By <?php blog_author($author); ?> | <?php echo gmdate('Y-n-j G:i', $value['date']); ?>   
	<?php blog_sort($value['logid']); ?>  |
	已有<?php echo $comnum; ?>发出评论 | 
	被围观:<?php echo $views; ?>次
	<?php editflg($logid,$author); ?>
	<p class="tag"><?php blog_tag($logid); ?></p>
					</div>	
	<div class="entry">
	<p><?php echo $log_content; ?></p>		
	<p class="att"><?php blog_att($logid); ?></p>		
				 
	<?php doAction('log_related', $logData); ?>
</div>
		<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
 
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
			<?php include ('side.php');?>
		</div>
 
		</div>
	
		
<?php
 include View::getView('footer');
?>