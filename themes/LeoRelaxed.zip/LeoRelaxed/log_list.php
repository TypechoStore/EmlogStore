<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
<div id="posts">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>	
<div class="post">				
<h2><?php topflg($value['top']); ?>
<a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>">
<?php echo $value['log_title']; ?></a>
	</h2>				
	 	<div class="date">				
Psot By <?php blog_author($value['author']); ?> | 
<?php echo gmdate('Y-n-j G:i', $value['date']); ?>  | 
<?php blog_sort($value['logid']); ?>  | 
<a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a> | 
<span>浏览:<?php echo $value['views']; ?>次</span>
<?php editflg($value['logid'],$value['author']); ?>
</div>
<div class="tags">
<p class="tag"><?php blog_tag($value['logid']); ?>
	</p>				
		</div>		
	<div class="entry">
<p><?php echo $value['log_description']; ?>
	</p>	
		</div>
 
</div>
<?php endforeach; ?>
<ol class="pagination">
        <ol class="page-navigator"><li class="current">
	<?php echo $page_url;?></li>
</ol>  
      </ol>
</div><!-- end #contentleft-->
 
<?php include ('side.php');?>
<?php include ('footer.php');?>