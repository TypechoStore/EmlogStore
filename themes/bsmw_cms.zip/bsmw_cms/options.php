<?php

/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
	'index_num' => array(
		'type' => 'text',
		'name' => '首页日志显示数量',
		'default' => '13',
	),
	'index_top' => array(
		'type' => 'text',
		'name' => '首页置顶图文数量',
		'default' => '1',
	),	
//首页logo设置
'index_logo' => array(
     'type' => 'image',
	'name' => '首页 → LOGO设置',
	'values' => array(
	TEMPLATE_URL . 'images/logo.png',
	),
	'default' => ''.TEMPLATE_URL.'images/logo.png',
),
//首页logo设置

//首页banner设置
'index_banner' => array(
     'type' => 'image',
	'name' => '首页相关 → banner横幅设置(图片尺寸630x250)',
	'values' => array(
	TEMPLATE_URL . 'images/art.jpg',
	),
	'default' => ''.TEMPLATE_URL.'images/art.jpg',
),
	'banner_bt' => array(
		'type' => 'text',
		'name' => '首页相关 → banner说明标题',
		'default' => '渡人如渡己，渡已，亦是渡',
	),
	'banner_nr' => array(
		'type' => 'text',
		'name' => '首页相关 → banner说明内容',
		'default' => '当我们被误解时，会花很多时间去辩白。 但没有用，没人愿意听，大家习惯按自己的所闻、理解做出判别，每个人其实都很固执。与其努力且痛苦的试图扭转别人的评判，不如默默承受，给大家多一点时间和空间去了解。而我们省下辩解的功夫，去实现自身更久远的人生价值。其实，渡人如渡己，渡已，亦是渡人。',
	),
//首页banner设置

	'admin_mail' => array(
		'type' => 'text',
		'name' => '管理员邮箱',
		'default' => 'chenziwen@lantk.com',
	),
//前台风格
	'index_skin' => array(
	    'type' => 'radio',
		'name' => '前台皮肤选择',
		'values' => array(
			'skin1' => '默认皮肤',
			'skin2' => '海边美女',
			'skin3' => '纸飞机',
			'skin4' => '山茶花',
			'skin5' => '彩虹精灵',
			'skin6' => '蓝天白云',
			'skin8' => '向日葵',
			'skin7' => '随机皮肤',
		),
		'default' => 'skin1',
	),
//首页图志
	'index_picblog' => array(
	    'type' => 'radio',
		'name' => '首页图志方案',
		'values' => array(
			'top' => '置顶文章',
			'sort' => '分类文章',
			'new' => '最新文章',
		),
		'default' => 'new',
	),
	'indextop_sortop' => array(
		'type' => 'text',
		'name' => '分类文章ID',
		'default' => '1',
	),






);
