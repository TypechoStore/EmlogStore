<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php if($pageurl == Url::logPage()){ ?>
<?php include View::getView('index'); ?>
<?php }else{ ?>
<?php doAction('index_loglist_top'); ?>
<?php include View::getView('list');include View::getView('side');?>
</div><?php include View::getView('side_nav');?></div>
<?php } ?><?php include View::getView('bottom');?>