<?php 
/**
 * 侧边栏浮动导航
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="control">
    <li>
       <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
       <a href="<?php echo BLOG_URL; ?>admin/">站点设置</a>
       <a target="_blank" href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a>
       <a target="_blank" href="<?php echo BLOG_URL; ?>admin/twitter.php">发说说</a>
       <?php else: ?>
       <a href="<?php echo BLOG_URL; ?>admin/">后台管理</a>
       <?php endif; ?>
       <a target="_blank" href="http://chenziwen.ys168.com">个人网盘</a>
       <a target="_blank" href="http://list.qq.com/cgi-bin/qf_invite?id=7c58b5af13adf74016bc21f40fedb7e2d086273484acd490">订阅邮箱</a>
<!--		
	   <a href="#" onclick="change_css('skin','<?php echo TEMPLATE_URL; ?>css/body5.css','myskin');">默认皮肤</a>
	   <a href="#" onclick="change_css('skin','<?php echo TEMPLATE_URL; ?>css/body6.css','myskin')">纸飞机</a>
       <a href="#" onclick="change_css('skin','<?php echo TEMPLATE_URL; ?>css/body7.css','myskin')">彩虹精灵</a>
       <a href="#" onclick="change_css('skin','<?php echo TEMPLATE_URL; ?>css/body8.css','myskin')">山茶花</a>
       <a href="#" onclick="change_css('skin','<?php echo TEMPLATE_URL; ?>css/body9.css','myskin')">海边美女</a>
       <a href="#" onclick="change_css('skin','<?php echo TEMPLATE_URL; ?>css/body1.css','myskin')">蓝天白云</a>
-->      
       <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
       <a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a>
       <?php else: ?>
       <?php endif; ?>
    </li>
 </div>
