<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<script type="text/javascript"> jQuery(function(){ jQuery('#loading-one').empty().append('页面加载完毕.').parent().fadeOut('slow'); });</script>
<div id="loading" style="position:fixed !important;position:absolute;top:0;left:0;height:100%; width:100%; z-index:999; background:#000 url(http://blog.chenziwen.com/content/uploadfile/201403/799b1393912010.jpg) no-repeat center; opacity:0.6; filter:alpha(opacity=60);font-size:14px;line-height:20px;"> <p id="loading-one" style="color:#fff;position:absolute; top:50%; left:50%; margin:50px 0 0 -50px; padding:3px 10px;">页面载入中,请稍后...</p> </div>
<?php
//首页分类
function index_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	<?php foreach($sort_cache as $value): ?>
	<li>
	<a rel="bookmark" href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?> (共 <?php echo $value['lognum'] ?> 篇文章)</a>
	</li>
	<?php endforeach; ?>
<?php }?>
<?php include View::getView('user');?>
<div id="mainbody">
<?php doAction('index_loglist_top'); ?>
<?php include View::getView('banner');?>
<div id="index_zhong1">
<div class="box2">
<DIV CLASS="NEW_INFO LEFT">
<H2><FONT color="#990000">最新</FONT>动态</H2>
<UL id="TOP_ART" CLASS="TOP_ARTICLES">
<?php
//widget：最新微语
function index_t($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	?>
	<?php foreach($newtws_cache as $value): ?>
	<?php $img = empty($value['img']) ? "" : '<a title="查看图片" id="t_img" href="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" target="_blank"> 有图有真相,快点戳我</a>';?>
	<?php echo $value['t']; ?><?php echo $img;?>
	<?php endforeach; ?>
    <?php if ($istwitter == 'y') :?>
	<?php endif;?>
<?php }?>
<DIV class='TS'><a href="<?php echo BLOG_URL; ?>t" title="最新碎语"><?php index_t("1"); ?></a></DIV>
<?php index_sort(""); ?>
</DIV>
</div>
</div>
<div id="index_zhong">
	<div class="box1">
	<h2><font color="#990000">图志</font>更新</h2>
<DIV CLASS="infiniteCarousel">
<DIV CLASS="wrapper">

<UL>
<?php if(_g('index_picblog') == "top"): ?>
<?php indextop_top(4); ?>
<?php elseif(_g('index_picblog') == "sort"): ?>
<?php indextop_sort(_g('indextop_sortop'),4); ?>
<?php elseif(_g('index_picblog') == "new"): ?>
<?php indextop_new(4); ?>
<?php else: ?>
<?php indextop_new(4); ?>
<?php endif; ?><!--end if-->

 </UL>
 </DIV><a class="arrow back" href="#"><</a><a class="arrow forward" href="#">></a>
	
</DIV>	</div>
</div>
<?php echo get_flash_data(_g('index_num')); ?></ul>
<?php include View::getView('side');?></div>
<?php include View::getView('side_nav'); mysql_close();?></div>