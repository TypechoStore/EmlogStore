<?php 
/**
 * 头部用户资料
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
function index_name(){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['name'];?>
<div id="user_img">
     <div class="img_pic">
	      <img width="100" height="100" src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>">
	      <div class="blog_user">
                     <span>博主：<?php echo $name; ?>
<?php }?>
	<?php index_name(); ?>
		            <span class="ico">
			              <img src="http://ctc.qzonestyle.gtimg.cn/aoi/img/qz-vip-icon/qz-vip-icon-l/qz_vip_icon_fla_l_year_6.png">
			        </span>
		       </span>
		  </div>
		  <div class="shuoming"><span>书写生活点滴，翻阅真实回忆</span></div>
     </div>
     <div class="index_sc">
          <div class="btn-head">
		     <s class="ui-icon"></s>
		     <div class="txt"><a href="javascript:;" onclick="javascript:window.external.AddFavorite('http://blog.chenziwen.com','陈子文')" title="收藏本站到你的收藏夹">特别关心</a></div>
		  </div>
          <div class="btn-head">
			 <div class="txt">
			       <span id="like_already"><a onclick="this.style.behavior='url(#default#homepage)';this.setHomePage('http://blog.chenziwen.com');" href="#">设为首页</a></span>
			 </div>
		  </div>
     </div>
</div>
