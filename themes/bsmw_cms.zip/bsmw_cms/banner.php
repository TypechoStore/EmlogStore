<?php 
/**
 * banner页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="blank"></div>
<div class="blogs">
<ul class="bloglist">
<div class="info">
<figure> <img src="<?php echo _g('index_banner'); ?>"  alt="Panama Hat">
<figcaption><strong><?php echo _g('banner_bt'); ?></strong> <?php echo _g('banner_nr'); ?></figcaption>
</figure>
</div>