<?php
/*
Template Name:白色马尾炫彩换肤
Description:白色马尾炫彩换肤版，内置多种皮肤后台一键切换。
Version:3.0
Author:陈子文
Author Url:http://vps.lantk.com
Sidebar Amount:1
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<html>
<head>
<?php include View::getView('index_skin');?><!--载入后台风格选择默认值-->
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=10;IE=EDGE">
<meta charset="UTF-8">
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>css/animation.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>css/styles-2.css" />
<link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>css/view.css" />
<link href="<?php echo TEMPLATE_URL; ?>css/lrtk.css" rel="stylesheet" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/Sean_script.s"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/js.js"></script>
<?php doAction('index_head',$logid); ?>
<!--[if lt IE 9]>
<script src="http://blog.chenziwen.com/content/templates/Hsesjz/js/modernizr.js"></script>
<![endif]-->
<!--[if  IE 8]>
<link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>css/styles-ie.css" />
<![endif]-->
</head>
<body>
<header>
  <nav id="nav"> 
  <div class="logo">
      <a href="<?php echo BLOG_URL; ?>"><img src="<?php echo _g('index_logo'); ?>"></a>
  </div>
  <div class="index_nav">
       <?php blog_navi();?>
  </div>
  <div class="sc">      
	   <form name="keyform" method="get" action="<?php echo BLOG_URL; ?>/index.php">
	         <input placeholder="善于搜索 发现更多" value="" name="keyword" size="24" class="focus" id="searchTextbox">     
	         <button name="sa" type="submit">搜索</button> 
	   </form>      
  </div>
<script src="<?php echo TEMPLATE_URL; ?>js/silder.js"></script>
  </nav>
</header>