<?php 
/**
 * 首页风格选择
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php if(_g('index_skin') == "skin1"): ?><!--默认皮肤-->
<link id="skin" media="all" rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/body5.css">

<?php elseif(_g('index_skin') == "skin2"): ?><!--海边美女-->
<link id="skin" media="all" rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/body9.css">

<?php elseif(_g('index_skin') == "skin3"): ?><!--纸飞机-->
<link id="skin" media="all" rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/body6.css">

<?php elseif(_g('index_skin') == "skin4"): ?><!--山茶花-->
<link id="skin" media="all" rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/body8.css">

<?php elseif(_g('index_skin') == "skin5"): ?><!--彩虹精灵-->
<link id="skin" media="all" rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/body7.css">

<?php elseif(_g('index_skin') == "skin6"): ?><!--蓝天白云-->
<link id="skin" media="all" rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/body1.css">

<?php elseif(_g('index_skin') == "skin8"): ?><!--向日葵-->
<link id="skin" media="all" rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/body10.css">

<?php elseif(_g('index_skin') == "skin7"): ?><!--随机皮肤-->
<script type='text/javascript'>
document.write("<link  href='<?php echo TEMPLATE_URL; ?>css/body"+ parseInt(Math.random()*(11-5)+5) +".css' rel='stylesheet'  type='text/css' />");
</script>

<?php else: ?><!--否则输出默认皮肤-->
<link id="skin" media="all" rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/body9.css">

<?php endif; ?><!--end if-->