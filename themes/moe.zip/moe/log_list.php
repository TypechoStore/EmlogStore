<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="page">
<?php doAction('index_loglist_top'); ?>

<?php 
if (!empty($logs)):
foreach($logs as $value):
$search_pattern = '%<img[^>]*?src=[\'\"]((?:(?!\/admin\/|>).)+?)[\'\"][^>]*?>%s';
preg_match($search_pattern, $value['content'], $img);
$value['img'] = isset($img[1])?$img[1]:TEMPLATE_URL.'img/nopic.png'; 
?>
<article aos="fade-up" class="post themes type-themes status-publish has-post-thumbnail hentry category-themes group aos-init" id="post">	
		<h2 class="post-title">

			<a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>

		</h2><!--/.post-title-->
<div class="theme-excerpt"><?php echo $logdes = blog_tool_purecontent($value['content'],100); ?></div>

					<div class="browser group">

				<div class="browser-view">
<?php
//获取缩略图
preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
if (!empty($img[1])) {
    $thum_src = $img[1][0]; //正文第一张图片
}else{
    $rand_num = 0; //随机图片数量，按实际数量设置
    if ($rand_num == 0) {
        $thum_src = TEMPLATE_URL."images/default.jpg";
        //默认图片"
    }else{
        $thum_src = TEMPLATE_URL."style/images/rand/".rand(0,$rand_num).".jpg";
        //随机图片，须按"1.jpg","2.jpg","3.jpg"...的顺序命名
    }
    //上述默认图片(0.jpg)与随机图片(random目录)须保存在模板目录中的"thumbnail"目录下
 }
?>
<?php if($value['img']==TEMPLATE_URL.'img/nopic.png'){?>
<?php }else{?><a href="<?php echo $value['log_url']; ?>">
<span class="b-overlay"><img src="<?php echo $ditu;?>"></span>				
<img alt="<?php echo $value['log_title']; ?>" src="<?php echo $thum_src; ?>">

				</a>
<?php }?>


				</div>

			</div>
	<ul class="post-meta bottom group">
		<li><i class="fa fa-folder-o"></i><?php blog_sort($value['logid']); ?></li>
		<li><i class="fa fa-clock-o"></i><?php echo gmdate('Y-n-j', $value['date']); ?></li>
		<li><a "="" href="<?php echo $value['log_url']; ?>#comments"><i class="fa fa-comment"></i><?php if($value['comnum']=="0"){ echo '<a title="NO COMMENTS" href="'.$value['log_url'].'#comments">NO COMMENTS</a>'; }else{ echo  '<a title="《'.$value['log_title'].'》上的评论" href="'.$value['log_url'].'#comments">'.$value['comnum'].' COMMENTS</a>'; } ?></a></li>
	</ul>
</article>
<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>

<nav id="loli" class="pagination group">
<ul class="group">
<div class="aos-init" aos="fade-up" id="pagenavi" style="border-top:1px solid rgba(0,0,0,0.13);border-bottom:1px solid rgba(0,0,0,0.13);">
<?php echo $page_url;?>
</div></div>
</ul>
	</nav>
	</div>
	</div>
<?php
 include View::getView('footer');
?>