<?php
/*
Template Name:2018二次元主题
Description:moe
Version:1.8
Author:思源
Author Url:http://www.isiyuan.net
Sidebar Amount:0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
require_once View::getView('config');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php if(blog_tool_ishome()) :?><?php echo $blogname; ?><?php elseif(!empty($tws)):?>微言碎语 - <?php echo $blogname; ?><?php else:?><?php echo $site_title; ?><?php endif;?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!--css-->
<link rel='stylesheet' id='style-css'  href='<?php echo TEMPLATE_URL; ?>style.css' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='<?php echo TEMPLATE_URL; ?>css/styles.css' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='<?php echo TEMPLATE_URL; ?>css/font-awesome.min.css' type='text/css' media='all' />
<link rel="stylesheet" id="aos-css"  href="<?php echo TEMPLATE_URL;?>css/aos.css" type="text/css" media="all" />
<style>
#header .container {
    position: relative;
  background: url(/content/templates/pink/background.php) no-repeat center center fixed;
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}</style>
<script src="<?php echo TEMPLATE_URL; ?>js/ajax_comment.js" type="text/javascript"></script><!--jq是个不好玩的东西--！>
<!--js--><script src="http://apps.bdimg.com/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/js.js" type="text/javascript"></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>js/m.js'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>js/jquery-migrate.min.js'></script>
<?php doAction('index_head'); ?>
</head>
<body class="home blog chrome">
<header id="header">

	<div data-offset-top="294" data-spy="affix" id="topbar" class="affix-top">

		<ul class="group" id="color-bars">

			<li id="color-1"></li>

			<li id="color-2"></li>

			<li id="color-3"></li>

			<li id="color-4"></li>

			<li id="color-5"></li>

			<li id="color-6"></li>

		</ul>





					<nav id="nav-topbar" class="nav-container group">



				<div class="nav-toggle"><i class="fa fa-bars"></i></div>



				<div class="nav-text"></div>



<?php blog_navi(); ?>

<div class="group" id="header-search">
<form name="keyform" id="nav_search" method="get" action="<?php echo BLOG_URL; ?>index.php">
	<input name="keyword" id="nav_search_s" placeholder="Search" type="text" />
	</form>
		</div>

			</nav><!--/#nav-topbar-->

			</div>

	<div class="container">

		<div class="group" id="head">
							
				<div id="head-face">

			<!--这儿放你头像，本地外链都行-->

  <img alt="toux" src="<?php echo $logo;?>">

			
		</div>
<?php if(blog_tool_ishome()) :?>
<div class="wocao">
<a href="<?php echo $weibo;?>" title="微博" class="btn-one"><i class="fa fa-weibo"></i></a>
<a href="tencent://message/?uin=<?php echo $qq;?>&Site=&Menu=yes" title="QQ" class="btn-22"><i class="fa fa-qq"></i></a>
<a href="<?php echo BLOG_URL;?>rss.php" title="订阅" class="btn-11"><i class="fa fa-rss"></i></a>	
</div>
<a rel="home" title="<?php echo $blogname; ?>" href="<?php echo BLOG_URL; ?>">
		<h2 id="head-about"><?php echo $blogname; ?></h2></a>
		<h1 id="head-about"><?php echo $bloginfo; ?></h1>
<?php elseif($logid):?><a rel="home" title="<?php echo $blogname; ?>" href="<?php echo BLOG_URL; ?>">
		<h2 id="head-about"><?php echo $blogname; ?></h2></a>
		<h1 id="head-about"><?php echo $bloginfo; ?></h1>
<?php elseif($author):?><?php syauthor($author);?> 
<?php elseif($sort):?>
<h2 id="head-about">分类：<?php echo $sortName;?></h2>
<?php elseif(!empty($tws)):?><h2 id="head-about">微言微语</h2><h1 id="head-about">使用微语记录身边的新鲜事</h1>
<?php else:?><a rel="home" title="<?php echo $blogname; ?>" href="<?php echo BLOG_URL; ?>">
		<h2 id="head-about"><?php echo $blogname; ?></h2></a>
		<h1 id="head-about"><?php echo $bloginfo; ?></h1>
<?php endif;?>

			</div>
	</div>
</header>
<div id="body">



<div class="container" id="main" role="main">
