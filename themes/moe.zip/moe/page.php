<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="page">
<article id="post" class="post themes type-themes status-publish has-post-thumbnail hentry category-themes group">
	<h2 class="post-title"><?php topflg($top); ?><?php echo $log_title; ?></h2>
<ul class="post-meta group">
<li><i class="fa fa-user"></i><?php blog_author($author); ?></li>
		<li><i class="fa fa-folder-o"></i><?php blog_sort($logid); ?></li>

		<li><i class="fa fa-clock-o"></i><?php echo gmdate('Y-n-j', $date); ?></li>
<?php if($logid){?><li><a "="" href="<?php echo Url::log($logid); ?>#comments"><i class="fa fa-comment"></i><?php if($comnum=="0"){ echo '<a title="NO COMMENTS" href="'.Url::log($logid).'#comments">抢沙发</a>'; }else{ echo  '<a title="《'.$log_title.'》上的评论" href="'.Url::log($logid).'#comments">'.$comnum.' COMMENTS</a>'; } ?></a></li>
<?php }else{?>
<?php }?>
		

	</ul>
	<div class="entry">
	<?php echo $log_content; ?>
	</div>
	<p class="post-tags"><?php blog_tag($logid); ?></p>
	<div class="cpright">
				   转载请注明来源：<?php echo logurl($logid);?><?php echo $blogname; ?>/文章链接：<a href="<?php echo Url::log($logid); ?>" class="permalink"><?php echo Url::log($logid); ?></a>
				</div>
				<div class="cutline"><span>正文到此结束</span></div>

 <div class="commt_box">
 <?php if($logid){?><a class="loli" href="#commentlist-container"><i class="fa fa-comments-o"></i>吐槽<span><?php echo $comnum; ?>发</span></a>
<?php }else{?>
<?php }?>

		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
		<?php blog_comments($comments); ?>
	  </div>
</article>
</div>
<?php
 include View::getView('footer');
?>