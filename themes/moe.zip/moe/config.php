<?php
//设置页面
	 			 $qq = '85443298';
				 $weibo = 'http://weibo.com';
				 $logo = '/content/templates/moe/images/avatar.jpg';
				 $ditu = 'http://akkme.qiniudn.com/uu.png';//文章列表 鼠标滑过展示图片
				 //饮水思源 双击链接，找思源聊天
				 //tencent://message/?uin=85443298&Site=&Menu=yes  
	    ?>