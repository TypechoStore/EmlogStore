<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<footer id="footer">

	<p class="aos-init" aos="fade-up"  ><a title="Back to top" id="top" href="#"><i class="fa fa-arrow-circle-o-up"></i></a></p>
	
	  <p id="host"><?php echo $icp; ?><?php echo $footer_info; ?>Powered by <a href="http://www.emlog.net" title="采用emlog系统">emlog</a><?php 
Copyright(); 
?>

</footer>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>js/jquery.affix.js'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>js/jquery.fancybox.pack.js'></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL;?>js/aos.js"></script>
<script>
	AOS.init({
		easing: 'ease-out-back',
		duration: 1000
	});
</script> 
<style type="text/css">
body {
    cursor: url(<?php echo TEMPLATE_URL; ?>css/1.cur), auto;
}
a:hover {
    cursor: url(<?php echo TEMPLATE_URL; ?>css/1_1.cur), auto;
}
</style>


	<?php doAction('index_footer'); ?>
</body>
</html>