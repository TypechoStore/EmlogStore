<?php 
/**
 * 侧边栏组件、页面模块
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php 
function syauthor($uid){
global $CACHE;
$user_cache = $CACHE->readCache('user');
$author = $user_cache[$uid]['name'];
$mail = $user_cache[$uid]['mail'];
$des = $user_cache[$uid]['des'];?>
<h2 id="head-about"><?php echo $author;?></h2>
<h1 id="head-about"><?php echo $des;?></h1>
<?php }?>
<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="bloggerinfo">
	<div id="bloggerinfoimg">
	<?php if (!empty($user_cache[1]['photo']['src'])): ?>
	<img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="<?php echo $user_cache[1]['photo']['width']; ?>" height="<?php echo $user_cache[1]['photo']['height']; ?>" alt="blogger" />
	<?php endif;?>
	</div>
	<p><b><?php echo $name; ?></b>
	<?php echo $user_cache[1]['des']; ?></p>
	</ul>
	</li>
<?php }?>
<?php //判断内容页是否百度收录
function baidu($url){
$url='http://www.baidu.com/s?wd='.$url;
$curl=curl_init();curl_setopt($curl,CURLOPT_URL,$url);curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);$rs=curl_exec($curl);curl_close($curl);if(!strpos($rs,'没有找到')){return 1;}else{return 0;}}
function logurl($id){$url=Url::log($id);
if(baidu($url)==1){echo "百度已收录";
}else{echo "<a style=\"color:red;\" rel=\"external nofollow\" title=\"点击提交收录！\" target=\"_blank\" href=\"http://zhanzhang.baidu.com/sitesubmit/index?sitename=$url\">百度未收录</a>";}}
?>
<?php
//widget：日历
function widget_calendar($title){ ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<div id="calendar">
	</div>
	<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
	</li>
<?php }?>
<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="blogtags">
	<?php foreach($tag_cache as $value): ?>
		<span style="font-size:<?php echo $value['fontsize']; ?>pt; line-height:30px;">
		<a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇文章"><?php echo $value['tagname']; ?></a></span>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="blogsort">
	<?php
	foreach($sort_cache as $value):
		if ($value['pid'] != 0) continue;
	?>
	<li>
	<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
	<?php if (!empty($value['children'])): ?>
		<ul>
		<?php
		$children = $value['children'];
		foreach ($children as $key):
			$value = $sort_cache[$key];
		?>
		<li>
			<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
		</li>
		<?php endforeach; ?>
		</ul>
	<?php endif; ?>
	</li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：最新微语
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="twitter">
	<?php foreach($newtws_cache as $value): ?>
	<?php $img = empty($value['img']) ? "" : '<a title="查看图片" class="t_img" href="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" target="_blank">&nbsp;</a>';?>
	<li><?php echo $value['t']; ?><?php echo $img;?><p><?php echo smartDate($value['date']); ?></p></li>
	<?php endforeach; ?>
    <?php if ($istwitter == 'y') :?>
	<p><a href="<?php echo BLOG_URL . 't/'; ?>">更多&raquo;</a></p>
	<?php endif;?>
	</ul>
	</li>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="newcomment">
	<?php
	foreach($com_cache as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	?>
	<li id="comment"><?php echo $value['name']; ?>
	<br /><a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：最新文章
function widget_newlog($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="newlog">
	<?php foreach($newLogs_cache as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：热门文章
function widget_hotlog($title){
	$index_hotlognum = Option::get('index_hotlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getHotLog($index_hotlognum);?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="hotlog">
	<?php foreach($randLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：随机文章
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="randlog">
	<?php foreach($randLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="logsearch">
	<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
	<input name="keyword" class="search" type="text" />
	</form>
	</ul>
	</li>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="record">
	<?php foreach($record_cache as $value): ?>
	<li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul>
	<?php echo $content; ?>
	</ul>
	</li>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
    //if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="link">
	<?php foreach($link_cache as $value): ?>
	<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?> 
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	?>
	<div class="nav-wrap">
	<ul class="nav container-inner group" id="menu-header">
	<?php
	foreach($navi_cache as $value):

        if ($value['pid'] != 0) {
            continue;
        }

		if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):
			?>
			<li class="menu-item"><a href="<?php echo BLOG_URL; ?>admin/">管理站点</a></li>
			<li class="menu-item"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
        $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'current_page_item' : 'menu-item';
		?>
		<li class="menu-item <?php echo $current_tab;?>">
			<a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a>
			<?php if (!empty($value['children'])) :?>
            <li class="menu-item <?php echo $current_tab;?>">
                <?php foreach ($value['children'] as $row){
                        echo '<li><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></li>';
                }?>
			</li>
            <?php endif;?>

            <?php if (!empty($value['childnavi'])) :?>
            <li class="menu-item <?php echo $current_tab;?>">
                <?php foreach ($value['childnavi'] as $row){
                        $newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';
                        echo '<li><a href="' . $row['url'] . "\" $newtab >" . $row['naviname'].'</a></li>';
                }?>
			</li>
            <?php endif;?>

		</li>
	<?php endforeach; ?>
	</ul>
	</div>
<?php }?>
<?php
//blog：置顶
function topflg($top, $sortop='n', $sortid=null){
    if(blog_tool_ishome()) {
       echo $top == 'y' ? "<img src=\"".TEMPLATE_URL."/images/top.png\" title=\"首页置顶文章\" /> " : '';
    } elseif($sortid){
       echo $sortop == 'y' ? "<img src=\"".TEMPLATE_URL."/images/sortop.png\" title=\"分类置顶文章\" /> " : '';
    }
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
	<a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>" title="查看<?php echo $log_cache_sort[$blogid]['name']; ?>下的全部文章"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
	<?php else: ?>
	<?php echo "暂未分类"; ?>
	<?php endif;?>
<?php }?>
<?php
//blog：文章标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '标签:';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "	<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
		}
echo $tag; }
	else {$tag = '<a rel=\"tag\">暂无标签</a>';
		echo $tag;}
}
?>
<?php
//blog：文章作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻日志
function neighbor_log($neighborLog){extract($neighborLog);?>
<?php if($prevLog):?>
<div class="nav-previous">上一篇：<a rel="prev" href="<?php echo Url::log($prevLog['gid']) ?>"><?php echo $prevLog['title'];?></a></div>
<?php else:?>
<div class="nav-previous"><a rel="prev" href="<?php echo Url::log($prevLog['gid']) ?>">上一篇: 已经是第一篇了</a></div>
<?php endif;?>
<?php if($nextLog && $prevLog):?>
<?php endif;?>
<?php if($nextLog):?>
<div class="nav-next">下一篇：<a rel="next" href="<?php echo Url::log($nextLog['gid']) ?>"><?php echo $nextLog['title'];?></a></div>
<?php else:?>
<div class="nav-next"><a rel="next" href="<?php echo Url::log($nextLog['gid']) ?>">下一篇: 已经是最后一篇了</a></div>
<?php endif;?>
<?php }?>
<?php
function echo_levels($comment_author_email,$comment_author_url){
  $DB = MySql::getInstance();
global $CACHE;
	$user_cache = $CACHE->readCache('user'); 
	$adminEmail = '"'.$user_cache[1]['mail'].'"';
  if($comment_author_email==$adminEmail)
  {
    echo ' 博主<a class="vip" title="管理员认证"></a>';
  }
  $sql = "SELECT cid as author_count,mail FROM ".DB_PREFIX."comment WHERE mail != '' and mail in ($comment_author_email) and hide ='n'";
  $res = $DB->query($sql);
  $author_count = mysql_num_rows($res);
   if($author_count>=2 && $author_count<10 && $comment_author_email!=$adminEmail)
    echo '<a class="vip1" title="路过酱油 LV.1"></a>';
  else if($author_count>=10 && $author_count<20 && $comment_author_email!=$adminEmail)
    echo '<a class="vip2" title="偶尔光临 LV.2"></a>';
  else if($author_count>=20 && $author_count<40 && $comment_author_email!=$adminEmail)
    echo '<a class="vip3" title="常驻人口 LV.3"></a>';
  else if($author_count>=40 && $author_count<80 && $comment_author_email!=$adminEmail)
    echo '<a class="vip4" title="以博为家 LV.4"></a>';
  else if($author_count>=80 &&$author_count<160 && $comment_author_email!=$adminEmail)
    echo '<a class="vip5" title="情牵小博 LV.5"></a>';
  else if($author_count>=160 && $author_coun<320 && $comment_author_email!=$adminEmail)
    echo '<a class="vip6" title="为博终老 LV.6"></a>';
  else if($author_count>=50 && $author_coun<60 && $comment_author_email!=$adminEmail)
    echo '<a class="vip7" title="三世情牵 LV.7"></a>';
}
?>
<?php
//blog：评论列表
function blog_comments($comments){extract($comments);if($commentStacks):?>

	<?php endif;?>
  <div class="comm_charu"></div>
  <div class="comment-list">
<?php	$isGravatar = Option::get('isgravatar');$comnum = count($comments);foreach($comments as $value){if($value['pid'] != 0){$comnum--;}}$page = isset($params[5])?intval($params[5]):1;$i= $comnum - ($page - 1)*Option::get('comment_pnum');foreach($commentStacks as $cid):$comment = $comments[$cid];$comm_name = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
$comment['content'] = preg_replace("/\[S(([1-4]?[0-9])|50)\]/",'<img src="'.TEMPLATE_URL.'moe/$1.gif" alt="" />',
$comment['content']);$comment['content'] = preg_replace("/\{smile:(([1-4]?[0-9])|50)\}/",'<img src="'.TEMPLATE_URL.'moe/$1.gif" alt="" />',
$comment['content']);$comment['content'] = preg_replace("/\[img=?\]*(.*?)(\[\/img)?\]/e", '"<a href=\"$1\" target=\"_blank\" rel=\"nofollow\" title=\"新窗口查看图片\"><img style=\"width:20px;height:20px;margin:0 5px\" src=\"'.TEMPLATE_URL.'images/img.gif\" alt=\"" . basename("$1") . "\" /></a>"',
 $comment['content']);$comment['content'] = preg_replace("/\[code=?\]*(.*?)(\[\/code)?\]/e", '"<pre>$1</pre>"', 
 $comment['content']);$comment['content'] = preg_replace("/\[link=?\]*(.*?)(\[\/link)?\]/e", '"<a href=\"$1\" target=\"_blank\" rel=\"external nofollow\">$1</a>"', $comment['content']);?>
	<div class="comment" id="comment-<?php echo $comment['cid']; ?>">
		<a name="<?php echo $comment['cid']; ?>"></a>
		<?php if($isGravatar == 'y'): ?><div class="avatar"><img src="<?php echo mygetGravatar($comment['mail']); ?>" width="48" height="48"  /></div><?php endif; ?>
		<div class="comment-info">
			<span class="poster"><i class="fa fa-user mar-r-4 green"></i><?php $mail_str="\"".strip_tags($comment['mail'])."\"";echo_levels($mail_str,"\"".$comment['url']."\"");?> <?php echo $comment['poster']; ?><?php echo $comm_name;?></span><span class="comment-time"><i class="fa fa-clock-o mar-r-4"></i><?php echo $comment['date']; ?></span><span class="comment-reply"><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)"><i class="fa fa-share mar-r-4"></i>回复</a></span>
			<div class="comment-content"><?php echo $comment['content']; ?></div>			
		</div>
		<?php blog_comments_children($comments, $comment['children']); ?>
	</div>
	<?php $i--;endforeach;?></div><div class="clear"></div>
    <div id="pagenavi" style="border-top:1px solid rgba(0,0,0,0.13);border-bottom:1px solid rgba(0,0,0,0.13);"><?php echo $commentPageUrl;?></div>
<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){$isGravatar = Option::get('isgravatar');foreach($children as $child):$comment = $comments[$child];$comm_name = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];$comment['content'] = preg_replace("/\{smile:(([1-4]?[0-9])|50)\}/",'<img src="'.TEMPLATE_URL.'moe/$1.gif" alt="" />',$comment['content']);$comment['content'] = preg_replace("/\[S(([1-4]?[0-9])|50)\]/",'<img src="'.TEMPLATE_URL.'moe/$1.gif" alt="" />',$comment['content']);$comment['content'] = preg_replace("/\[img=?\]*(.*?)(\[\/img)?\]/e", '"<a href=\"$1\" target=\"_blank\" rel=\"nofollow\" title=\"新窗口查看图片\"><img style=\"width:20px;height:20px;margin:0 5px\" src=\"'.TEMPLATE_URL.'images/img.gif\" alt=\"" . basename("$1") . "\" /></a>"', $comment['content']);$comment['content'] = preg_replace("/\[code=?\]*(.*?)(\[\/code)?\]/e", '"<pre>$1</pre>"', $comment['content']);$comment['content'] = preg_replace("/\[link=?\]*(.*?)(\[\/link)?\]/e", '"<a href=\"$1\" target=\"_blank\" rel=\"external nofollow\">$1</a>"', $comment['content']);?>
	<div class="comment-children" id="comment-<?php echo $comment['cid']; ?>">
		<a name="<?php echo $comment['cid']; ?>"></a>
		<?php if($isGravatar == 'y'): ?><div class="avatar"><img src="<?php echo mygetGravatar($comment['mail']); ?>" width="36" height="36"/></div><?php endif;?>
		<div class="comment-info"><span class="poster"><i class="fa fa-user mar-r-4 green"></i><?php $mail_str="\"".strip_tags($comment['mail'])."\"";echo_levels($mail_str,"\"".$comment['url']."\"");?> <?php echo $comment['poster']; ?></span><span class="comment-time"><i class="fa fa-clock-o mar-r-4"></i><?php echo $comment['date']; ?></span><?php if($comment['level'] < 4):?><span class="comment-reply"><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)"><i class="fa fa-share mar-r-4"></i>回复</a></span><?php endif;?>
			<div class="comment-content"><?php echo $comment['content']; ?></div>			
		</div>
		<?php blog_comments_children($comments, $comment['children']);?>
	</div>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'):?>
	<div id="comment-place">
 <script src="<?php echo TEMPLATE_URL; ?>js/ajax_comment.js" type="text/javascript"></script>
	<div class="comment-post" id="comment-post">
	<div id="smilelink">
<a onclick="javascript:grin('[S1]')"><img src="<?php echo TEMPLATE_URL; ?>moe/1.gif" title="汗" alt="汗"></a>
<a onclick="javascript:grin('[S2]')"><img src="<?php echo TEMPLATE_URL; ?>moe/2.gif" title="色" alt="色"></a>
<a onclick="javascript:grin('[S3]')"><img src="<?php echo TEMPLATE_URL; ?>moe/3.gif" title="悲" alt="悲"></a>
<a onclick="javascript:grin('[S4]')"><img src="<?php echo TEMPLATE_URL; ?>moe/4.gif" title="闭嘴" alt="闭嘴"></a>
<a onclick="javascript:grin('[S5]')"><img src="<?php echo TEMPLATE_URL; ?>moe/5.gif" title="调皮" alt="调皮"></a>
<a onclick="javascript:grin('[S6]')"><img src="<?php echo TEMPLATE_URL; ?>moe/6.gif" title="笑" alt="笑"></a>
<a onclick="javascript:grin('[S7]')"><img src="<?php echo TEMPLATE_URL; ?>moe/7.gif" title="惊" alt="惊"></a>
<a onclick="javascript:grin('[S8]')"><img src="<?php echo TEMPLATE_URL; ?>moe/8.gif" title="亲" alt="亲"></a>
<a onclick="javascript:grin('[S9]')"><img src="<?php echo TEMPLATE_URL; ?>moe/9.gif" title="雷" alt="雷"></a>
<a onclick="javascript:grin('[S10]')"><img src="<?php echo TEMPLATE_URL; ?>moe/10.gif" title="馋" alt="馋"></a>
<a onclick="javascript:grin('[S11]')"><img src="<?php echo TEMPLATE_URL; ?>moe/11.gif" title="晕" alt="晕"></a>
<a onclick="javascript:grin('[S12]')"><img src="<?php echo TEMPLATE_URL; ?>moe/12.gif" title="酷" alt="酷"></a>
<a onclick="javascript:grin('[S13]')"><img src="<?php echo TEMPLATE_URL; ?>moe/13.gif" title="奸" alt="奸"></a>
<a onclick="javascript:grin('[S14]')"><img src="<?php echo TEMPLATE_URL; ?>moe/14.gif" title="怒" alt="怒"></a>
<a onclick="javascript:grin('[S15]')"><img src="<?php echo TEMPLATE_URL; ?>moe/15.gif" title="狂" alt="狂"></a>
<a onclick="javascript:grin('[S16]')"><img src="<?php echo TEMPLATE_URL; ?>moe/16.gif" title="萌" alt="萌"></a>
<a onclick="javascript:grin('[S17]')"><img src="<?php echo TEMPLATE_URL; ?>moe/17.gif" title="吃" alt="吃"></a>
<a onclick="javascript:grin('[S18]')"><img src="<?php echo TEMPLATE_URL; ?>moe/18.gif" title="贪" alt="贪"></a>
<a onclick="javascript:grin('[S19]')"><img src="<?php echo TEMPLATE_URL; ?>moe/19.gif" title="囧" alt="囧"></a>
<a onclick="javascript:grin('[S20]')"><img src="<?php echo TEMPLATE_URL; ?>moe/20.gif" title="羞" alt="羞"></a>
<a onclick="javascript:grin('[S21]')"><img src="<?php echo TEMPLATE_URL; ?>moe/21.gif" title="哭" alt="哭"></a>
<a onclick="javascript:grin('[S22]')"><img src="<?php echo TEMPLATE_URL; ?>moe/22.gif" title="嘿" alt="嘿"></a>
</div>
		<form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
			<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
			<div class="textarea"><textarea name="comment" id="comment" rows="10" tabindex="4" placeholder="既然来了说点什么吧…"></textarea></div>
<div class="comm_toolbar">
  <div class="comm_tool">
  <div class="smilebg"><div class="smile"><div class="arrow"></div> 
  <div title="插入图片" onclick="tool_img()" class="tool_img"><i class="fa fa-image"></i></div>
  <div title="插入链接" onclick="tool_link()" class="tool_link"><i class="fa fa-link"></i></div>
  <div title="插入代码" onclick="tool_code()" class="tool_code"><i class="fa fa-code"></i></div>
  <div title="签到" onclick="tool_qiand()" class="tool_qiand"><i class="fa fa-pencil"></i></div></div></div>
  <div title="插入表情" onclick="tool_bq()" class="tool_bq"><i class="fa fa-cog"></i></div>
  <div id="cmt-loading" style="float:left;padding-left:15px;height:32px;font-size:14px;color:red;line-height:30px;"></div>
  <?php if(ROLE == 'visitor'): ?>
<div class="comm_tijiao">提交评论</div>
<div class="cancel-reply" id="cancel-reply" style="display:none"><a href="javascript:void(0);" onclick="cancelReply()">取消回复</a></div>
</div>
</div>
<div class="comm_infobox"><div class="comm_close"></div>
<p><label for="author">名字：</label><input type="text" name="comname" id="comname" maxlength="49" value="<?php echo $ckname; ?>" size="22" tabindex="1"></p>
<p><label for="email">邮箱：</label><input type="text" name="commail" id="commail" maxlength="128"  value="<?php echo $ckmail; ?>" size="22" tabindex="2"></p>
<p><label for="url">网址：</label><input type="text" name="comurl" id="comurl" maxlength="128"  value="<?php echo $ckurl; ?>" size="22" tabindex="3"></p>
<input  type="submit" id="comment_submit" class="button submit" value="发射(●'◡'●)ﾉ♥" tabindex="6" />
</div>
<?php else:?>
<div class="comm_tijiao"><input type="submit" id="comment_submit" value="发射(●'◡'●)ﾉ♥" tabindex="6" /></div>
<div class="cancel-reply" id="cancel-reply" style="display:none"><a href="javascript:void(0);" onclick="cancelReply()">取消回复</a></div>
</div>
</div>
<?php endif; ?>
<input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/>
</form>
	</div>
	</div>
 	<?php endif; ?>
<?php }?>
<?php
function get_avatar($mail,$size,$default='monsterid')
{
	$email_md5=md5(strtolower($mail));//通过MD5加密邮箱
	$cache_path=TEMPLATE_PATH."cache"; //缓存文件夹路径,ljie需要换上你的主题目录名称
	if(!file_exists($cache_path))
	{
		mkdir($cache_path,0700);
	}
 $avatar_url=TEMPLATE_URL."cache/".$email_md5.'.jpg'; //头像相对路径
	$avatar_abs_url=$cache_path."/".$email_md5.'.jpg'; //头像绝对路径
	$cache_time=24*3600*7; //缓存时间为7天
	 if (empty($default)) $default = $cache_path. '/default.jpg';
	if(!file_exists($avatar_abs_url) || (time()-filemtime($avatar_abs_url)) > $cache_time)//过期或图片不存在
	{
		$new_avatar = getGravatar($mail,$size,$default);
		copy($new_avatar,$avatar_abs_url);
	}
	return $avatar_url;
}
//调用方法
//get_avatar($comment['mail'],"{$comment['poster']}{$comment['comment_nums']}")
?>
<?php 
//blog:多说获取Gravatar头像
function mygetGravatar($email, $s = 80, $d = 'mm', $g = 'g') {
	$hash = md5($email);
	$avatar = "http://cn.gravatar.com/avatar/$hash?s=$s&d=$d&r=$g";
	return $avatar;
}
?>
<?php
function timer_start() {
  global $timestart;
  $mtime = explode( ' ', microtime() );
  $timestart = $mtime[1] + $mtime[0];
  return true;
}
timer_start();
 
function timer_stop( $display = 0, $precision = 3 ) {
  global $timestart, $timeend;
  $mtime = explode( ' ', microtime() );
  $timeend = $mtime[1] + $mtime[0];
  $timetotal = $timeend - $timestart;
  $r = number_format( $timetotal, $precision );
  if ( $display )
    echo $r;
  return $r;
}
?>
<?php function convertip($ip) { $dat_path = EMLOG_ROOT.'/content/templates/moe/ip.dat'; //*数据库路径*//
if(!$fd = @fopen($dat_path, 'rb')){ return 'IP数据库文件不存在或者禁止访问或者已经被删除！';   
    } $ip = explode('.', $ip); $ipNum = $ip[0] * 16777216 + $ip[1] * 65536 + $ip[2] * 256 + $ip[3]; $DataBegin = fread($fd, 4); $DataEnd = fread($fd, 4); $ipbegin = implode('', unpack('L', $DataBegin)); if($ipbegin < 0) $ipbegin += pow(2, 32); $ipend = implode('', unpack('L', $DataEnd)); if($ipend < 0) $ipend += pow(2, 32); $ipAllNum = ($ipend - $ipbegin) / 7 + 1; $BeginNum = 0; $EndNum = $ipAllNum; while($ip1num>$ipNum || $ip2num<$ipNum) { $Middle= intval(($EndNum + $BeginNum) / 2); fseek($fd, $ipbegin + 7 * $Middle); $ipData1 = fread($fd, 4); if(strlen($ipData1) < 4) { fclose($fd); return '系统出错！';   
        } $ip1num = implode('', unpack('L', $ipData1)); if($ip1num < 0) $ip1num += pow(2, 32); if($ip1num > $ipNum) { $EndNum = $Middle; continue;   
        } $DataSeek = fread($fd, 3); if(strlen($DataSeek) < 3) { fclose($fd); return '系统出错！';   
        } $DataSeek = implode('', unpack('L', $DataSeek.chr(0))); fseek($fd, $DataSeek); $ipData2 = fread($fd, 4); if(strlen($ipData2) < 4) { fclose($fd); return '系统出错！';   
        } $ip2num = implode('', unpack('L', $ipData2)); if($ip2num < 0) $ip2num += pow(2, 32); if($ip2num < $ipNum) { if($Middle == $BeginNum) { fclose($fd); return '未知';   
            } $BeginNum = $Middle;   
        }   
    } $ipFlag = fread($fd, 1); if($ipFlag == chr(1)) { $ipSeek = fread($fd, 3); if(strlen($ipSeek) < 3) { fclose($fd); return '系统出错！';   
        } $ipSeek = implode('', unpack('L', $ipSeek.chr(0))); fseek($fd, $ipSeek); $ipFlag = fread($fd, 1);   
    } if($ipFlag == chr(2)) { $AddrSeek = fread($fd, 3); if(strlen($AddrSeek) < 3) { fclose($fd); return '系统出错！';   
        } $ipFlag = fread($fd, 1); if($ipFlag == chr(2)) { $AddrSeek2 = fread($fd, 3); if(strlen($AddrSeek2) < 3) { fclose($fd); return '系统出错！';   
            } $AddrSeek2 = implode('', unpack('L', $AddrSeek2.chr(0))); fseek($fd, $AddrSeek2);   
        } else { fseek($fd, -1, SEEK_CUR);   
        } while(($char = fread($fd, 1)) != chr(0)) $ipAddr2 .= $char; $AddrSeek = implode('', unpack('L', $AddrSeek.chr(0))); fseek($fd, $AddrSeek); while(($char = fread($fd, 1)) != chr(0)) $ipAddr1 .= $char;   
    } else { fseek($fd, -1, SEEK_CUR); while(($char = fread($fd, 1)) != chr(0)) $ipAddr1 .= $char; $ipFlag = fread($fd, 1); if($ipFlag == chr(2)) { $AddrSeek2 = fread($fd, 3); if(strlen($AddrSeek2) < 3) { fclose($fd); return '系统出错！';   
            } $AddrSeek2 = implode('', unpack('L', $AddrSeek2.chr(0))); fseek($fd, $AddrSeek2);   
        } else { fseek($fd, -1, SEEK_CUR);   
        } while(($char = fread($fd, 1)) != chr(0)){ $ipAddr2 .= $char;   
        }   
    } fclose($fd); if(preg_match('/http/i', $ipAddr2)) { $ipAddr2 = '';   
    } $ipaddr = "$ipAddr1 $ipAddr2"; $ipaddr = preg_replace('/CZ88.Net/is', '', $ipaddr); $ipaddr = preg_replace('/^s*/is', '', $ipaddr); $ipaddr = preg_replace('/s*$/is', '', $ipaddr); if(preg_match('/http/i', $ipaddr) || $ipaddr == '') { $ipaddr = '未知';   
    } $ipaddr = iconv('gbk', 'utf-8//IGNORE', $ipaddr); if( $ipaddr != '  ' ) return $ipaddr; else $ipaddr = '评论者来自火星，无法或者其所在地!'; return $ipaddr;   
} ?>
<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>
	<?php
//格式化内容工具
function blog_tool_purecontent($content, $strlen = null){
        $content = str_replace('', '', strip_tags($content));
        if ($strlen) {
            $content = subString($content, 0, $strlen);
        }
        return $content;
}
?>
<?php
function Copyright(){
	$db = MySql::getInstance();
	?>
	Theme by <a target="_blank" href="http://www.isiyuan.net/"><?php
$str = '5oCd5rqQ';
echo base64_decode($str);
?></a></p>
<?php }?>
<?php //分页函数
function sheli_fy($count,$perlogs,$page,$url,$anchor=''){
$pnums = @ceil($count / $perlogs);
$page = @min($pnums,$page);
$prepg=$page-1;                 //shuyong.net上一页
$nextpg=($page==$pnums ? 0 : $page+1); //shuyong.net下一页
$urlHome = preg_replace("|[\?&/][^\./\?&=]*page[=/\-]|","",$url);
//开始分页导航内容
$re = "";
 $urlHome = preg_replace("|[?&/][^./?&=]*page[=/-]|", "", $url); 
 if($page > 1) { 
  $i = $page - 1; 
  $re = $re.'<li class="prev left"><a href="'.$url.$i.'"><i class="fa fa-arrow-circle-o-left"></i>上一页</a></li>'; 
 }

 if($page < $pnums) { 
  $i = $page + 1; 
  $re= $re.'<li class="next right"><a href="'.$url.$i.'"><i class="fa fa-arrow-circle-o-right"></i>下一页</a></li>'; 
 }
return $re;}
?>
<?php
//获取文章缩略图
function logthum($logid){$db = Database::getInstance();$query = $db->query("SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$logid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png' OR `filepath` LIKE '%jpeg') ORDER BY `aid` ASC LIMIT 0,1");while($row = $db->fetch_array($query)){$imgpath = substr($row['filepath'],3,strlen($row['filepath']));}$imgarr = explode("/",$imgpath);$imgsurl = $imgarr[0].'/'.$imgarr[1].'/'.$imgarr[2].'/thum-'.$imgarr[3];if(empty($imgpath)){$randval = rand(0,10);return TEMPLATE_URL.'images/log-bg.jpg';}else{if(!file_exists(EMLOG_ROOT.'/'.$imgsurl)){return BLOG_URL.$imgpath;}else{return BLOG_URL.$imgsurl;}}}?>