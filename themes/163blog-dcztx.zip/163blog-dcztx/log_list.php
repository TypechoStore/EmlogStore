<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php include View::getView('side');?>
<div id="column_2" class="SG_colW73">
<div id="module_10001" class="SG_conn">
	<div class="SG_connHead">
		<span class="title">博文</span>
	</div>
<div class="SG_connBody" id="module_10001_SG_connBody">
<div class="bloglist">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<div class="blog_title_h">
<div class="blog_title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></div>
<span class="time SG_txtc">(<?php echo gmdate('Y-n-j G:i', $value['date']); ?>)</span> <?php editflg($value['logid'],$value['author']); ?>
</div>

	<div class="articalTag">
		<table>
		<tbody>
		<tr>
		<td class="blog_tag">
		<?php blog_tag($value['logid']); ?>
		</td>
		<?php blog_sort($value['logid']); ?> 
		</tr>
		</tbody>
		</table>
	</div>
	
 <div class="content">
 <?php echo $value['log_description']; ?>
 </div>
 
	<div class="tagMore">
	<div class="tag SG_txtc">
	<a href="<?php echo $value['log_url']; ?>">阅读</a>(<?php echo $value['views']; ?>)
	┆ <a href="<?php echo $value['log_url']; ?>#comment">评论</a>(<?php echo $value['comnum']; ?>)
	┆ <a href="<?php echo $value['log_url']; ?>#tb">引用</a>(<?php echo $value['tbcount']; ?>)
	┆ </div>
	<div class="more">
	<span class="SG_more"><a href="<?php echo $value['log_url']; ?>" target="_blank">查看全文</a>&gt;&gt;</span>
	</div>
	</div>
 
<div class="SG_j_linedot"></div>
<?php endforeach; ?>
<div id="pagenavi">
<span>第 <b><?php echo $page; ?></b> 页 / 共 <b><?php echo ceil($lognum/$index_lognum); ?></b> 页</span>
<?php echo $page_url;?>
</div>
 	</div>	

	</div>  
    <div class="SG_connFoot"></div>
</div>
</div>

<?php include View::getView('footer');?>