<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php include View::getView('side');?>
<div id="column_2" class="SG_colW73">
<div id="module_10001" class="SG_conn">
	<div class="SG_connHead">
		<span class="title">博文</span>
	</div>
<div class="SG_connBody" id="module_10001_SG_connBody">
<div class="bloglist">
<div class="blog_title_h">
<div class="blog_title"><?php topflg($top); ?><?php echo $log_title; ?></div>
<span class="time SG_txtc">(<?php echo gmdate('Y-n-j G:i', $date); ?>)</span> <?php editflg($logid,$author); ?>
</div>

	<div class="articalTag">
		<table>
		<tbody>
		<tr>
		<td class="blog_tag">
		<?php blog_tag($logid); ?>
		</td>
		<?php blog_sort($logid); ?>
	    </tr>
		</tbody>
		</table>
	</div>
	
 <div class="content">
<?php echo $log_content; ?>
 </div>
 
	<div class="tagMore">
	<div class="tag SG_txtc">阅读(<?php echo $views; ?>)
	┆ <a href="#comment">评论</a>(<?php echo $comnum; ?>)
	┆ <a href="#tb">引用</a>(<?php echo $tbcount; ?>)
	┆ </div>
	</div>
 
<div class="SG_j_linedot"></div>
<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
 	</div>	
	</div>  
    <div class="SG_connFoot"></div>
</div>
</div>
<?php include View::getView('footer');?>