<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php include View::getView('side');?>
<div id="column_2" class="SG_colW73">
<div id="module_10001" class="SG_conn">
	<div class="SG_connHead">
		<span class="title">页面</span>
	</div>
<div class="SG_connBody" id="module_10001_SG_connBody">
<div class="bloglist">
<div class="blog_title_h">
<div class="blog_title"><?php echo $log_title; ?></div>
<span class="time SG_txtc"></span> <?php editflg($logid,$author); ?>
</div>
	
 <div class="content">
<?php echo $log_content; ?>
 </div>
 
<div class="SG_j_linedot"></div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
 	</div>	
	</div>  
    <div class="SG_connFoot"></div>
</div>
</div>
<?php include View::getView('footer');?>