<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--#blogbody END-->
    <div class="blogfooter" id="blogfooter" style="position:relative;">
      <p class="copyright"> Copyright © <?php echo $blogname; ?>,  All Rights Reserved.</p>
      <p class="copyright">Powered by <a href="http://www.emlog.net" target="_blank" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>. Theme by <a href="http://www.dcztx.com/" target="_blank">单车走天下</a>
      <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?></p>
    </div>
</div>
</div>
<?php doAction('index_footer'); ?>
</body>
</html>