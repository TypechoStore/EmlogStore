<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>


	<div id="sider" class="fri">
	<div class="con_box htabs_art clearfix"> 
		<ul class="cooltab_nav sj_nav clearfix">
			<li><a href="#" class="active" title="new_art">最新文章</a></li>
			<li><a href="#" title="hot_art">热门文章</a></li>
			<li><a href="#" title="rand_art">随机推荐</a></li>
		</ul>   
		
		<div id="new_art" class="com_cont">   
		<ul class="index_resourse_list">
	<?php 
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
	<?php foreach($newLogs_cache as $value): ?>
	
 	<li><a href="<?php echo Url::log($value['gid']); ?>" ><?php echo $value['title']; ?></a></li>
	
	<?php endforeach; ?>
		</ul>                    
		</div>
        <div id="hot_art" class="com_cont">  
            <ul class="index_resourse_list">
	<?php
	$index_hotlognum = Option::get('index_hotlognum');
	$Log_Model = new Log_Model();
	$hotLogs = $Log_Model->getHotLog($index_hotlognum);?>
	<?php foreach($hotLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>" ><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
			</ul>      
		</div>
		<div id="rand_art" class="com_cont">  
			<ul class="index_resourse_list">
	<?php
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	<?php foreach($randLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
			</ul>
		</div>   
	</div>

<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>


<div class=" hot_box fr">
<div class="feed-mail">

<div class="gg">
<?php include View::getView('notice'); ?>
</div>
</div>
</div>





<div class=" qd_aritle"   >
		
		<ul class="index_resourse_list ">  
		
			<a ></a>
</ul>
			</div>
			




<div class="clear"></div>
<div id="rollstart"></div>
</div><!--end #siderbar-->
