<?php 
/*
* 首页
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="art_container clearfix">
<div id="art_main" class="fl"> 

<!--显示幻灯片-->
	<div id="slideshow">
    <div class="slideshow">
	<div id="featured_tag"></div>
	<div id="tag_c"></div>
	<div id="slider_nav"></div>
	<div id="slider" class="clearfix">
	<?php  home_slideshow(); ?>
	</div>
	</div>
    </div>
<?php function home_slideshow(){ require('options.php'); $db = MySql::getInstance(); $sql = $db->query ("SELECT * FROM ".DB_PREFIX."blog inner join ".DB_PREFIX."sort WHERE hide='n' AND type='blog' AND top='y' AND sortid=sid order by date DESC limit 0,$get_slideshow_num"); while($row = $db->fetch_array($sql)){ if (!empty($row['excerpt'])){ preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['excerpt'], $match); if(empty($match[0][0])) { preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'], $match); } }else{ preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'], $match); } $logpost = !empty($row['excerpt']) ? $row['excerpt'] : ''.$row['content'].''; $num = rand(1,$imgnum); $img = isset($match[0][0]) ? $match[0][0] : '<img src="'.TEMPLATE_URL.'images/log_big/'.$num.'.jpg">'; $date = gmdate('Y年m月d日', $row['date']); $content = strip_tags($logpost,''); $content = mb_substr($content,0,200,'utf-8'); $out .='
<div class="featured_post" >
	<div class="slider_image">			
	<a href="'.Url::log($row['gid']).'" title="'.$row['title'].'"   >'.$img.'</a>
	</div>
		
	<div class="slider_post">
	<h3><a href="'.Url::log($row['gid']).'" rel="bookmark" title="'.$row['title'].'">'.$row['title'].'</a></h3> 
	<div class="archive_info">
	<span class="date">'.$date.'</span>
	<span class="category"> | <a href="'.Url::sort($row['sortid']).'" title="查看 '.$row['sortname'].' 中的全部文章" rel="category tag">'.$row['sortname'].'</a></span>
	</div>    
		
	<p>'.$content.'...</p>
		
	<div class="clear"></div>
	</div>
</div>'; } echo $out; }?>
	
	
	
<!-- 首页最新消息 -->
 	<?php doAction('index_loglist_top');?>
<!-- 按时间排序日志并且获得分页，修改自系统log_model.php文件中的function getLogsForHome -->
    <?php
	$sqlSegment ='ORDER BY date DESC';
	$mylogs = $Log_Model->getLogsForHome($sqlSegment, $page, $index_lognum);
	$sta_cache = $CACHE->readCache('sta');
		$lognum = $sta_cache['lognum'];
		$pageurl .= "";
        $total_pages = ceil($lognum / $index_lognum);
        if ($page > $total_pages) {
            $page = $total_pages;
        }
		$mylogs = $Log_Model->getLogsForHome($sqlSegment, $page, $index_lognum);
		$page_url = pagination($lognum, $index_lognum, $page, $pageurl);
	?>
	

	
<!--结束-->

<!--遍历所有日志-->
	<?php if (!empty($mylogs)):	foreach($mylogs as $value): ?> 
	<li><div class="article ">
    <div class="mp_article">
	<h2><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" alt="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a><span class="new"></span></h2>
	<div class="fl thumbnail_box">
      <div class="thumbnail1">
      </div>
	<div class="thumbnail1">
	   <?php
	    preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
        $imgsrc = !empty($img[1]) ? $img[1][0] : TEMPLATE_URL.'images/log/'.rand(1,$imgnum).'.jpg';?>
		
        <a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>">
       <div class="boder_round"> <img src="<?php echo $imgsrc; ?>" width="180px" height="120px" alt="<?php echo $value['log_title']; ?>"/></div></a>
		
    </div>
    </div>
	
    <div class="preview "><?php echo subString(strip_tags($value['content']),0,200); ?></div>
        <div class="info">
		写于：<?php echo gmdate('Y-m-d', $value['date']); ?>&nbsp;|&nbsp;                       
        浏览:<a href="<?php echo $value['log_url']; ?>"> <?php echo $value['views']; ?></a>&nbsp;|&nbsp;
        评论:<a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?></a>&nbsp;|&nbsp;
        分类:<?php blog_sort($value['logid']); ?>&nbsp;|&nbsp;
		标签:<?php blog_tag($value['logid']); ?>&nbsp;|&nbsp;
		<?php editflg($value['logid'],$value['author']); ?>
    </div>


</div></ul>
    <div class="clear">
    <?php endforeach;else:?>
<div class="con_box clearfix">
	<br><h1> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;未找到</h1><br>
	<p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;抱歉，没有符合您查询条件的结果。</p>
	<br><br><br><br><br><br><br>
</div>
	<?php endif;?>

	</div>
	</div>
	</li>
	
<!--显示首页分类列表文章-->
<?php 
require('options.php'); 
	$db = MySql::getInstance(); 
	global $CACHE; 
	$sort_cache = $CACHE->readCache('sort'); 
	foreach($sort_id as $key => $i){ $key = $key+1; $out .= '<div class="con_box fl resouse_artile qd_aritle" id="cat-'.$key.'"  >'; 
	$out .= '<h2><span class="i6"><a class="more fr" rel="nofollow" href="'.Url::sort($i).'" title="查看 '.$sort_cache[$i]['sortname'].' 中的全部文章">更多 '.$sort_cache[$i]['sortname'].' 文章</a></span>'.$sort_cache[$i]['sortname'].'</h2>'; 
		$out .='<div>';
		$out .='<ul class="index_resourse_list qd_list clearfix"> '; 
		require('options.php'); 
		$sort_log_num = $sort_log_num ; 
		$logs = $db->query ("SELECT * FROM ".DB_PREFIX."blog WHERE sortid='$i' AND type='blog' AND hide='n' order by date DESC limit 0,{$sort_log_num}"); 
		while ($trow = $db->fetch_array($logs)){ 
			$date = gmdate('Y-m-d', $trow['date']); $trow['title'] = mb_substr($trow['title'],0,18,'utf-8'); $out .='<li> <span class="fr">'.$date.'</span>			
			<a href="'.Url::log($trow['gid']).'" title="'.$trow['title'].'">'.$trow['title'].'</a>
			</li>'; 
			} 
		$out .='</ul></div></div>'; 
	} echo $out; 
?>
<div class="page_navi"><?php echo $page_url;?></div>
	
</div><!-- art_main end-->

</div><!-- art_container end--> 


<?php
 include View::getView('side');
 include View::getView('footer');
 mysql_close();
?>


