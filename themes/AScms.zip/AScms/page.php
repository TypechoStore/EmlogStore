<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="breadcrumbs" class="con_box clearfix">
		<div class="bcrumbs"><strong><a href="<?php echo BLOG_URL; ?>" title="返回首页">home</a></strong>
		<a><?php echo $log_title; ?></a>
		</div>
	</div>

<div id="art_container clearfix">
<div id="art_main1" class="art_white_bg fl"> 

	 <div class="art_title clearfix">
	 <h1><?php topflg($top); ?><?php echo $log_title; ?></h1>
	 </div>
	
	 <div class="article_content">
				
	 <div class="clear"></div>
	 <?php echo $log_content; ?>
	 <div class="clear"></div>

</div><!--正文-->

<?php if($allow_remark == 'y'): ?>
<?php $comnum = ($comnum != 0) ? '目前有 '.$comnum.' 条留言' : '等您坐沙发呢！'; ?>
<h3 id="comments" style="margin-bottom:10px"><?php echo $log_title; ?>：<?php echo $comnum; ?></h3>
<?php blog_comments($comments,$params); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<?php endif; ?>
  <div class="clear"></div>

</div><!--内容-->
	
</div><!--end #art_container-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>