<?php
if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div id="shangxia">
<div id="shang" title="↑ 返回顶部"></div>
<?php if (isset($logid) && $allow_remark == 'y') :?>
<div id="cmmt" title="我要评论"></div>
<?php else: ?>
<div id="cmt" onclick="location.href='http://asim.cn/guestbook'" title="我要留言"></div>
<?php endif; ?>
<div id="xia" title="↓ 移至底部"></div>
</div>