<?php
if(!defined('EMLOG_ROOT')) {exit('error!');}
	
	// 设置
	
	// ***侧边栏 最新日志、热门日志、随机推荐 的日志数量、在后台侧边栏内设置 最新文章、热门文章、随机文章的数量。

	$top_sort_id ='0'; // 首页 独立分类ID号
	
	// 下面4个ID只是提供样板、具体需要按照你博客的分类ID自己修改
	$sort_id = array("2","1"); // 分类日志ID

	
	$get_slideshow_num = '4'; // 幻灯片日志数量
	$sort_log_num = '1'; // 首页分类日志数量
	
	
	$imgnum = '35';  // 无图片日志随机图片数量
	
	
	$islogo = 'yes'; // 显示logo 否则会显示博客名字 yes 显示logo / no 显示名字
	
	$statement = '';  // 底部说明
	$link_url = 'http://asim.cn/';  // 申请链接页面地址 带http开头
	$comment_url = 'http://asim.cn/';  // 留言页面地址 带http开头
	
	$loglist_style = 'normal'; // 按分类查看页、按标签查看页等 日志显示方式。'list'为列表 'normal' 为图片+标题+摘要等
	// 数量 更改后台 每页显示日志的数量
	
	
//**相关日志设置

	$is_related_log = 'yes'; // 是否显示相关推荐 yes 显示 / no 不显示
	$related_log_num = '6'; // 相关日志数量
	$related_log_type = 'sort';
	$related_log_sort = 'views_asc';
	$related_inrss = 'y';
	
// $related_log_type 相关类型
// 		sort     分类
// 		tag      标签
//*
// $related_log_sort 排序
// 		views_desc     点击数（降序）
//		comnum_desc    评论数（降序）
//		rand           随机
//		views_asc      点击数（升序）
//		comnum_asc     评论数（升序）
//*
// $related_inrss 是否显示在RSS输出里
//		  y		  是
//		  n		  否
//*************************************	
?>
