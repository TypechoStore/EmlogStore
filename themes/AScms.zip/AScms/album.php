<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="breadcrumbs" class="con_box clearfix">
		<div class="bcrumbs"><strong><a href="<?php echo BLOG_URL; ?>" title="返回首页">home</a></strong>
		<a>相册</a>
		</div>
	</div>
				
	 <div class="clear art_title"></div>
	 <center><?php echo $log_content; ?></center>
	 <div class="clear"></div>

<!--正文-->
<br>
<!--内容-->
	
<!--end #art_container-->
<?php

 include View::getView('footer');
?>