<?php
if(!defined('EMLOG_ROOT')) {exit('error!');}
// 侧边栏自定义公告 //
?>

<p>

<img src="<?php echo TEMPLATE_URL; ?>images/common/ad125.png" width="125" height="125" alt="<?php echo $blogname; ?>" />
<img src="<?php echo TEMPLATE_URL; ?>images/common/ad125.png" width="125" height="125" alt="<?php echo $blogname; ?>" />
<img src="<?php echo TEMPLATE_URL; ?>images/common/ad125.png" width="125" height="125" alt="<?php echo $blogname; ?>" />
<img src="<?php echo TEMPLATE_URL; ?>images/common/ad125.png" width="125" height="125" alt="<?php echo $blogname; ?>" />
</p>

