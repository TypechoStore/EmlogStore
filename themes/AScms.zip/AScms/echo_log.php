<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>

	<div id="breadcrumbs" class="con_box clearfix">
		
	</div>

<div id="art_container clearfix">
<div id="art_main1" class="art_white_bg fl"> 
<div class="bcrumbs"><strong><a href="<?php echo BLOG_URL; ?>" title="返回首页">home</a></strong>

		
		<?php  
			global $CACHE; 
			$cache_sort = $CACHE->readCache('sort');
				$log_cache_sort = $CACHE->readCache('logsort');
				$mylogid = $log_cache_sort[$logid]['id'];
				$pid = $cache_sort [$mylogid]['pid'];
		  ?>
		
                <?php if($pid != 0):?>
                <a href="<?php echo BLOG_URL ."?sort=".$pid; ?>"><?php echo $cache_sort[$pid]['sortname'];?></a>
				<a href="<?php echo BLOG_URL ."?sort=".$mylogid; ?>"><?php echo $cache_sort[$mylogid]['sortname']; ?></a>
                 <?php else:?>
				<a href="<?php echo BLOG_URL ."?sort=".$mylogid; ?>"><?php echo $cache_sort[$mylogid]['sortname']; ?></a>
                 <?php endif;?>
				 
					
		<a><?php echo $log_title; ?></a>
		</div>
	 <div class="art_title clearfix">
	 <?php 	global $CACHE;
	$user_cache = $CACHE->readCache('user');?>
            
			<h1><?php topflg($top); ?><?php echo $log_title; ?></h1>
			<p class="info">
			<?php blog_author($author); ?> 发布于 <?php echo gmdate('Y-m-d', $date); ?> + <?php echo ($views); ?> 次浏览 + <?php echo ($comnum); ?> 条评论
			<?php editflg($value['logid'],$value['author']); ?>&nbsp&nbsp&nbsp&nbsp&nbsp
			<?php editflg($logid,$author); ?>
			
			</p><!-- /info结束 -->  
			</div>
		<div class="article_content">			
		<div id='zoom'><?php echo $log_content; ?></div>
		<div class="clear"></div>		
		         			
</div><!--正文结束-->
		<div class="postcopyright">

		<p>分类： <span><?php blog_sort($logid); ?></span>　　<div class="info_tag">本文标签：  <span><?php blog_tag($logid); ?></span></div></p>

		</div> 
	
	<div class="con_pretext clearfix"><ul><?php neighbor_log($neighborLog); ?></ul></div>
	<!--上一篇 下一篇--> 
	
	<!--相关文章--> 
	<?php 
	global $value; $DB = MySql::getInstance(); $CACHE = Cache::getInstance(); extract($logData); 
	if($value) { $logid = $value['id']; $sortid = $value['sortid']; global $abstract; } $sql = "SELECT gid,title,content FROM ".DB_PREFIX."blog WHERE hide='n' AND type='blog'"; 
	if($related_log_type == 'tag') { $log_cache_tags = $CACHE->readCache('logtags'); $Tag_Model = new Tag_Model(); $related_log_id_str = '0'; foreach($log_cache_tags[$logid] as $key => $val) { $related_log_id_str .= ','.$Tag_Model->getTagByName($val['tagname']); } $sql .= " AND gid!=$logid AND gid IN ($related_log_id_str)"; }else{ $sql .= " AND gid!=$logid AND sortid=$sortid"; } switch ($related_log_sort) { case 'views_desc': { $sql .= " ORDER BY views DESC"; break; } case 'views_asc': { $sql .= " ORDER BY views ASC"; break; } case 'comnum_desc': { $sql .= " ORDER BY comnum DESC"; break; } case 'comnum_asc': { $sql .= " ORDER BY comnum ASC"; break; } case 'rand': { $sql .= " ORDER BY rand()"; break; } } $sql .= " LIMIT 0,$related_log_num"; $related_logs = array(); $query = $DB->query($sql); while($row = $DB->fetch_array($query)) { $row['gid'] = intval($row['gid']); $row['title'] = htmlspecialchars($row['title']); $related_logs[] = $row; } $out = ''; 
	if(!empty($related_logs)) { $out .= '<div class="relatedlist">'; 
	$out .= '<div class="relatedtitle">相关文章：</div><ul>'; 
	foreach($related_logs as $val) { 
	$search_pattern = '%<img[^>]*?src=[\'\"]((?:(?!\/admin\/|>).)+?)[\'\"][^>]*?>%s'; 
	preg_match($search_pattern, $val['content'], $kl_arr); $num = rand(1,$imgnum); $val['kl_image'] = isset($kl_arr[1]) ? $kl_arr[1] : ''.TEMPLATE_URL.'images/log/'.$num.'.jpg'; 
	$out .= '<li><a href="'.Url::log($val['gid']).'" title="'.$val['title'].'"><img src="'.$val['kl_image'].'" /></a>
    <p>'.$val['title'].'</p></li>'; } $out .= '</ul></div>'; } 
	if(!empty($value['content'])) { if($related_inrss == 'y') { $abstract .= $out; } }else{ echo $out; }  if ($is_related_log == "yes"){ addAction('log_related','related_log'); addAction('rss_display','related_log'); } ?>
	
	
	<div class="clear"></div> 
<?php if($allow_remark == 'y'): ?>
<?php $comnum = ($comnum != 0) ? '目前有 '.$comnum.' 条留言' : '等您坐沙发呢！'; ?>
<h3 id="comments" style="margin:0 10px 0 13px"><?php echo $log_title; ?>：<?php echo $comnum; ?></h3>
<?php blog_comments($comments,$params); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<?php endif; ?>
  <div class="clear"></div>
</div><!--内容-->
	
</div><!--end #art_container-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>