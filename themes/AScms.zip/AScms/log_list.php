<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
if($pageurl == Url::logPage()){
	include View::getView('home');
}else{
?>
<div id="breadcrumbs" class="con_box clearfix">
		<div class="bcrumbs"><strong><a href="<?php echo BLOG_URL; ?>" title="返回首页">home</a></strong>
		<?php if (isset($tag)):?>
		<a>包含标签 【<?php echo $tag; ?>】 的文章</a>
		
		<?php elseif (isset($sortid)): ?>
		<?php global $CACHE; $sort_cache = $CACHE->readCache('sort'); ?>

				<?php  $pid = $sort_cache[$sortid]['pid'];
				?>
                <?php if($pid != 0):?>
                        <a href="<?php echo BLOG_URL ."?sort=".$pid; ?>"><?php echo $sort_cache[$pid]['sortname'];?></a>
						 <a><?php echo $sort_cache[$sortid]['sortname']; ?></a>
                 <?php else:?>
				 	<a><?php echo $sort_cache[$sortid]['sortname']; ?></a>
                 <?php endif;?>
		
		<?php elseif (isset($author)): ?>
		<a>作者 【<?php echo $author; ?>】 的文章</a>
		
		<?php elseif (isset($keyword)):?>
		<a>含有搜索词 【<?php echo $keyword; ?>】 的文章</a>
		
		<?php elseif (isset($record)):?>
		<a>存档于 【<?php echo $record; ?>】 的文章</a>
		
		<?php endif; ?>
		</div>
</div>
<?php doAction('index_loglist_top'); ?>
<?php if (!empty($logs)):
?>
<!--列表显示-->
<?php if ($loglist_style == "list"):?>
<div id="art_container clearfix">
<div id="art_main" class="fl"> 

	<div class="cat_list">
	<div class="page_navi"><?php echo $page_url;?></div>
		<ul>
        <?php foreach($logs as $value): ?>
		<li><h2><span class="date fr"> <?php echo $value['views']; ?><small> ℃ </small> | <?php echo gmdate('Y-m-d', $value['date']); ?></span> <a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"  ><?php echo $value['log_title']; ?></a> </h2></li>
        <?php endforeach; ?>						
		</ul>

	<div class="page_navi"><?php echo $page_url;?></div>
	</div>

</div><!--内容-->
</div> 

<!--普通显示-->
<?php elseif ($loglist_style == "normal"): ?>
<div id="art_container clearfix">
<div id="art_main" class="fl"> 

<?php foreach($logs as $value): ?>
	<div class="art_img_box clearfix">
	<div class="fl innerimg_box">
	  <a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"  >
	  
	    <?php
	    preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
        $imgsrc = !empty($img[1]) ? $img[1][0] : TEMPLATE_URL.'images/log/'.rand(1,$imgnum).'.jpg';?>
		
        <a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>">
        <img src="<?php echo $imgsrc; ?>" width="180px" height="120px" alt="<?php echo $value['log_title']; ?>"/></a>
  
	  </a>
	</div>
    <div class="fr box_content">
		<h2><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"  ><?php echo $value['log_title']; ?></a></h2>        		<div class="info">
		
		<span>分类： <?php blog_sort($value['logid']); ?></span>丨
		<span>日期： <?php echo gmdate('Y年m月d日', $value['date']); ?></span>                        
		<span>+<small> <?php echo $value['views']; ?> 次</small></span>
		<?php $value['comnum'] = ($value['comnum']!=0) ? '<small>'.$value['comnum'].'条评论</small>' : '暂无评论'; ?>
		<span>+ <a href="<?php echo $value['log_url']; ?>#comments" title="《<?php echo $value['log_title']; ?>》上的评论"><?php echo $value['comnum']; ?></a></span>
		<span><?php editflg($value['logid'],$value['author']); ?></span>
</div>
      
      <p class="intro">
      <?php $value['log_description'] = strip_tags($value['log_description'],'');
      $value['log_description'] = mb_substr($value['log_description'],0,150,'utf-8');
      echo $value['log_description']; ?>
      </p>
</div>
</div>
<?php endforeach; ?>
<div class="page_navi"><?php echo $page_url;?></div>
</div><!--内容-->
</div> 
<?php endif; ?>

<?php else:?>

<div id="art_container clearfix">
<div id="art_main" class="fl"> 
<div class="con_box clearfix">
	<br><h1> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;未找到</h1><br>
	<p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;抱歉，没有符合您查询条件的结果。</p>
	<br><br><br><br><br><br><br>
</div>	
</div>
</div>
<?php endif;?>

<?php
 include View::getView('side');
 include View::getView('footer');
 mysql_close();}
?>