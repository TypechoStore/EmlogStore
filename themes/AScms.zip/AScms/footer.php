<?php  if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
</div><!--end #wrap-->

<div id="footer" class="clearfix">
    <div class="con_box ">
<?php if($pageurl == Url::logPage()): ?>
	    	<div class="flink">
			<strong>友情链接:</strong>
<?php global $CACHE; $link_cache = $CACHE->readCache('link'); ?>
	<?php foreach($link_cache as $value): ?>
	<a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a>
	<?php endforeach; ?>

	    	</div>

<?php endif; ?>


<div class="footer_bug">
<a rel="nofollow" href="<?php echo BLOG_URL; ?>about.html">关于ASim</a>  |
<a rel="nofollow" href="http://creativecommons.org/licenses/by-nc-sa/3.0/">授权协议</a>  |
<a rel="nofollow" href="<?php echo BLOG_URL; ?>about-me.html">联系留言</a>  |
<a rel="nofollow" href="<?php echo BLOG_URL; ?>sitemap.xml">网站地图</a>  |
<a rel="nofollow" href="<?php echo BLOG_URL; ?>rss.php">RSS订阅</a>
</div>

    </div>
    
	<div class="copyright">
    <p>   <?php echo $statement; ?></p>
<p class="powered">Copyright &copy; <?php echo $blogname; ?> All rights reserved.Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">Emlog</a>. <?php echo $footer_info; ?><?php doAction('index_footer'); ?>
designed by <a href="http://asim.cn/" rel="nofollow">asim</a>. theme is <a href="http://asim.cn/templates/ascms.html" rel="nofollow">AScms</a>. hosted on <a href="" rel="nofollow">qiniu and cefhost</a>.</p>
<!-- /powered -->
   </div>
   
   

<?php  include View::getView('top'); ?>
</div>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery_cmhello.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.cycle.all.min.js"></script>
<script>prettyPrint();</script>
</body>
</html>