<?php
/*
Template Name:AScms
Description:一个经典的内容管理模板
Version:1.0
Author:asim
Author Url:http://asim.cn/
Sidebar Amount:1
ForEmlog:5.3.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('options');
require_once View::getView('module');
//require_once View::getView('includes/function');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>images/style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>

<?php doAction('index_head'); ?>
</head>
<!--[if IE 6]>
<link href="<?php echo TEMPLATE_URL; ?>images/ie6.css" rel="stylesheet" type="text/css" />
<script src="http://letskillie6.googlecode.com/svn/trunk/letskillie6.zh_CN.pack.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/PNG.js"></script>
<script>DD_belatedPNG.fix('.png_bg');</script>
<![endif]-->
<body>

<div id="header" class="png_bg">
		<div id="header_inner">
		<?php if ($islogo == "yes"): ?>
    		<strong class="logo">
			<a href="<?php echo BLOG_URL; ?>" class="png_bg" title="<?php echo $blogname; ?>"><?php echo $blogname; ?></a>
			<p><?php echo $bloginfo; ?></p>
			</strong><div class="topad"><a href="http://asim.cn/templates/ascms.html"><img src="<?php echo TEMPLATE_URL; ?>images/common/topad.png" width="460" height="54" alt="<?php echo $blogname; ?>" /></a></div>
		<?php elseif ($islogo == "no"): ?>	
			<strong class="blogname">
			<a href="<?php echo BLOG_URL; ?>" class="png_bg" title="<?php echo $blogname; ?>"><?php echo $blogname; ?></a>
			<p><?php echo $bloginfo; ?></p>
			</strong>
		<?php endif; ?>
       <div class="header_bg png_bg">	 

	   
	   <div id="_userlogin">	
			<a  class="btn3 " href="<?php echo BLOG_URL; ?>rss.php" title="欢迎订阅我的博客" target="_blank">RSS订阅</a>
       </div>
	   
	   
	   </div>
       <div class="toplinks">   
	   
	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
			 <?php
				global $CACHE;
				$user_cache = $CACHE->readCache('user');
				$name = $user_cache[1]['name'];?>
			 <a class="btn btn-arrow btn-image btn-headermenu" href="javascript:;"><?php echo $name; ?><i class="arrow"></i></a>
				<span class="popup-arrow"><i></i></span>
				<div class="popup-layer">
					<div class="popup">
						<div class="popup-profile">
							<span class="name"><?php echo $name; ?></span>
							<span class="mail"></span>
							<a href="<?php echo BLOG_URL; ?>admin/" class="btn2 btn-primary">进入管理中心</a>
						</div>
						<div class="popup-profile-ctrl">
							<a href="<?php echo BLOG_URL; ?>admin/write_log.php" class="btn1">写日志</a>
							<a href="<?php echo BLOG_URL; ?>admin/?action=logout" class="btn1">注销</a>
						</div>
						
					</div>
				</div>
				<?php ?>
			 <?php else: ?>
				<a class="btn btn-arrow btn-headermenu" href="javascript:;">用户登陆<i class="arrow"></i></a>
				<span class="popup-arrow"><i></i></span>
				<div class="popup-layer">
					<div class="popup1">
						<form class="popup-signin" name="loginform" action="<?php echo BLOG_URL; ?>admin/index.php?action=login" method="post">
							<h4  class="popup-lf">用户名：</h4>
							<input class="ipt" size="20" type="text" name="user" id="user" value="" onfocus="this.value=''" />
							<h4 class="popup-lf">密&nbsp;&nbsp;&nbsp;&nbsp;码：</h4>
							<input class="ipt" size="20" type="password" name="pw" id="pw" value="" onfocus="this.value=''" />
							<input class="btn btn-primary"  type="submit" name="submit" value="立即登录">
							<input type="hidden" name="redirect_to" value="<?php echo $_SERVER['REQUEST_URI']; ?>" />
		                </form>
	           		</div>
           		</div>
			  
			   <?php endif; ?>   
	   
	   
	   
       </div>
	   <div id="navmenu"><ul class="menu">
<div id="top_nav">
		<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
		<div class="form clearfix">
        <label for="s" ></label>
        <input name="keyword"  type="text" class="search-keyword" onfocus="if (this.value == '众里寻他千百度') {this.value = '';}" onblur="if (this.value == '') {this.value = '众里寻他千百度';}" value="众里寻他千百度" />
        <button type="submit" class="select_class" onmouseout="this.className='select_class'" onmouseover="this.className='select_over'" />搜索</button>
		</div>
		</form>
       </div>
	   <?php blog_navi(); ?></ul></div>
<div class="clearfix"></div>
    </div>
</div>

<div id="wrapper" class="clearfix">
 
 <script type="text/javascript">
function doZoom(size)
{document.getElementById('zoom').style.fontSize=size+'px';}
</script>
