<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content" role="main">
	<article class="post-<?php echo $logid; ?>" id="post-<?php echo $logid; ?>">
			<header class="entry-header">
				<h1 class="entry-title"><?php echo $log_title; ?></h1>
			</header><!-- .entry-header -->
			<div class="entry-content"><?php echo $log_content; ?></div>
	</article>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div><!-- #content -->
<?php
 include View::getView('side');
 include View::getView('footer');
?>