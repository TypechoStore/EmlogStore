<?php get_header(); ?>

	<div id="content" role="main">
<?php if ( have_posts() ) : ?>
		<h1 class="page-title">搜索结果：<?php the_search_query(); ?></h1>
		<?php get_template_part( 'loop' ); ?>
<?php else : ?>
		<h1 class="page-title">抱歉，没有符合您搜索条件的结果。</h1>
		<article id="post-0" class="post no-results not-found">
			<div class="entry-content">
				<ol>
					<li>尝试搜索其他关键字</li>
					<li>浏览 <a href="<?php echo home_url(); ?>/archives">存档页</a> 查找要访问的页面</li>
					<li><a href="<?php echo home_url( '/' ); ?>">回到首页</a></li>
					<li><a href="javascript:history.go(-1);">返回上页</a></li>
				</ol>
			</div>
		</article>
		<script>document.getElementById("s").value="<?php the_search_query(); ?>";document.getElementById("s").focus();</script>
<?php endif; ?>
	</div><!-- #content -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>