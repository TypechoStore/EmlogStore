<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content" role="main">
	<article class="post-<?php echo $logid; ?>" id="post-<?php echo $logid; ?>">
			<header class="entry-header">
				<h1 class="entry-title"><?php topflg($top); ?><?php echo $log_title; ?></h1>
				<div class="entry-meta">
					<time pubdate="" datetime="<?php echo gmdate('Y-n-j G:i l', $date); ?>" class="entry-date"><?php echo gmdate('Y-n-j', $date); ?></time> / 
					<?php blog_sort($logid); ?> / 
					<?php blog_tag($logid); ?> /<?php editflg($logid,$author); ?>
				</div>
				<!-- .entry-meta -->
				<div class="comments-link">
					<a title="《<?php echo $log_title; ?>》上的评论" href="<?php echo Url::log($logid); ?>"><?php echo $comnum; ?></a>
				</div>
			</header><!-- .entry-header -->
			<div class="entry-content"><?php echo $log_content; ?></div>
	</article>
	<?php doAction('log_related', $logData); ?>	
	<nav id="nav-single">
	<?php neighbor_log($neighborLog); ?>
	</nav>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div><!-- #content -->
<?php
 include View::getView('side');
 include View::getView('footer');
?>