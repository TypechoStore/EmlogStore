<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content" role="main">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
	<article class="post-<?php echo $value['logid']; ?>" id="post-<?php echo $value['logid']; ?>">
		<header class="entry-header">
			<h3 class="entry-title"><a rel="bookmark" title="链向 <?php echo $value['log_title']; ?> 的固定链接" href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h3>
			<div class="entry-meta">
				<time pubdate="" datetime="<?php echo gmdate('Y-n-j G:i l', $value['date']); ?>" class="entry-date"><?php echo gmdate('Y-n-j', $value['date']); ?></time> / 
				<?php blog_sort($value['logid']); ?> / <?php blog_tag($value['logid']); ?> / <?php editflg($value['logid'],$value['author']); ?>
			</div>
			<!-- .entry-meta -->
				<div class="comments-link">
					<a title="《<?php echo $value['log_title']; ?>》上的评论" href="<?php echo $value['log_url']; ?>"><?php echo $value['comnum']; ?></a>
				</div>
		</header>
		<!-- .entry-header -->
		<div class="entry-content clearfix">
			<?php echo subString(strip_tags($value['log_description']),0,220,"..."); ?>
			<span class="more">[<a href="<?php echo $value['log_url']; ?>" title="详细阅读 <?php echo $value['log_title']; ?>" rel="bookmark">阅读全文</a>]</span>
		</div>
	</article>
		<?php endforeach; ?>
		<nav id="nav-below">
			<div class="nav-next"><?php echo $page_url;?></div>
		</nav>
</div>
<!-- end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>
</section>