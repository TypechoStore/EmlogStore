<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content" role="main">
	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
	<div class="top"><a href="<?php echo BLOG_URL . 'admin/twitter.php' ?>">写碎语</a></div>
	<?php endif; ?>
	<div id="comments">
		<ol id="commentlist" class="commentlist">
			<?php 
			foreach($tws as $val):
			$author = $user_cache[$val['author']]['name'];
			$avatar = empty($user_cache[$val['author']]['avatar']) ? 
				BLOG_URL . 'admin/views/images/avatar.jpg' : 
				BLOG_URL . $user_cache[$val['author']]['avatar'];
			$tid = (int)$val['id'];
			$img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
			?> 
		<li class="comment" id="li-comment-">
			<div id="comment-" class="comment-wrapper">
				<div class="comment-meta">
					<div class="comment-author vcard">
						<img width="28" height="auto" alt="" src="<?php echo $avatar; ?>" class="avatar avatar-28 photo">
						<?php echo $author; ?><span class="says"> 说：</span>
						<time pubdate="" datetime="约 6 小时前"><?php echo $val['date'];?></time>
					</div><!-- .comment-author .vcard -->
				</div>
			<div class="comment-content"><?php echo $val['t'].'<br/>'.$img;?></div>
			<div class="reply">
				<a href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">回复(<span id="rn_<?php echo $tid;?>"><?php echo $val['replynum'];?></span>)</a>			
			</div><!-- .reply -->
		</div><!-- #comment-## -->
		<ol id="r_<?php echo $tid;?>" class="r"></ol>
			<textarea id="rtext_<?php echo $tid; ?>" class="sytext"></textarea>
	<div class="tbutton">
		<div class="tinfo" style="display:<?php if(ROLE == 'admin' || ROLE == 'writer'){echo 'none';}?>">
			昵称：<input type="text" id="rname_<?php echo $tid; ?>" value="" />
			<span style="display:<?php if($reply_code == 'n'){echo 'none';}?>">验证码：<input type="text" id="rcode_<?php echo $tid; ?>" value="" /><?php echo $rcode; ?></span>		
		</div>
		<input class="button_p" type="button" onclick="reply('<?php echo DYNAMIC_BLOGURL; ?>index.php?action=reply',<?php echo $tid;?>);" value="回复" /> 
		<div class="msg"><span id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></span></div>
		</li>
		<?php endforeach;?>
		</ol>
	</div>
		<nav id="nav-below">
			<div class="nav-next"><?php echo $pageurl;?></div>
		</nav>
</div><!-- #content -->
<?php
 include View::getView('side');
 include View::getView('footer');
?>