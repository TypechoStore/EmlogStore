<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

</section><!-- #main -->
<footer role="contentinfo" id="colophon">
		&copy; 2013 <a rel="home" href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>
	<span class="sep"></span>Powered by <a rel="generator" target="_blank" href="http://emlog.net/">Emlog</a>
	<span class="sep"></span>Theme by <a target="_blank" href="http://www.alvinac027.com">Alvinac027</a>
	<span class="sep"></span>Designed by <a target="_blank" href="http://c7sky.com/">Cople</a>
</footer>
<div id="sticky-nav">
	<a href="#top" class="gotop" onclick="window.scrollTo(0,0);return false;"><span>返回顶部</span></a>
	<a href="#colophon" class="gobtm" onclick="window.scrollTo(0,document.body.scrollHeight);return false;"><span>前往底部</span></a>
</div>
</body>
</html>