﻿		</div>
	</div>
	<!-- main end -->
<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
	<div class="clear"></div>
	<div class="footer-wrap">
		<div id="footer">
<DIV id="footlinks">

<P>
</P>
</DIV>
<a href="#"><img src="<?php echo TEMPLATE_URL; ?>images/footer-logo.gif" style="float:left;margin: 0px 10px 0px 25px;" /></a>
<P id="copyright">
Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> 
</P>
<P id="debuginfo"><a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
</P>
		<?php doAction('index_footer'); ?>
		</div>
	</div>
	<!-- footer end -->
</body>
</html>