<?php
/*
Template Name:900123
Description:这是以我的生日命名的模板 ……
Author:小子
Author Url:http://www.1zdiy.com
Sidebar Amount:1
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once (View::getView('module'));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<title><?php echo $site_title; ?></title>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
	<div id="header">
		<div class="head-wrap">
			<div id="toptool">
			<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
			<div class="login" style="float:left">
			<a href="<?php echo BLOG_URL; ?>admin/">管理中心</a> 丨 <a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a>
			</div>
			<?php else: ?>
			<div class="tool" style="float:right;">
			<span><a href="<?php echo BLOG_URL; ?>admin/">登录</a></span>
			</div>
			<?php endif; ?>
			</div>
			<div id="head" style="clear:both">
				<ul>
					<li id="title"><h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1></li>
					<li id="tagline"><?php echo $bloginfo; ?></li>
				</ul>
			</div>
		</div>
		<div class="nav-wrap">
			<div id="nav">
            <?php blog_navi();?>
			</div>
		</div>
		<div class="clear"></div>
	</div>
	<!--header end-->
	<div class="main-wrap">
		<div class="category">
			<ul id="cate">
			<li><img src="<?php echo TEMPLATE_URL; ?>images/catec.gif" /></li>
			<?php 
			$CACHE = Cache::getInstance();
			$sort_cache = $CACHE->readCache('sort');
			foreach($sort_cache as $value): 
			?>
			<li>
				<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?></a>
			</li>
			<?php endforeach; ?>
			</ul>
		</div>
		<div id="main">
