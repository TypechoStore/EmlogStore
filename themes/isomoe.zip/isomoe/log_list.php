<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php doAction('index_loglist_top'); ?>
 <div id="right_col">
  <div id="center_contents">
<?php foreach($logs as $value): ?>
   <p class="date"><?php echo gmdate('Y/n/j G:i l', $value['date']); ?></p>
    <h3 class="post_title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h3>
    <div class="post_content cf">
	<p><?php echo $value['log_description']; ?></p>
	<ul class="post_meta">
      <li class="post_comment"><font><font class=""><a href="<?php echo $value['log_url']; ?>#comments" title="查看 <?php echo $value['log_title']; ?> 中所有评论"><?php echo $value['comnum']; ?>个评论</font></font></a></li>
      <?php blog_sort($value['logid']); ?>
    </ul>
    </div>
<?php endforeach; ?>
<div id="comments_wrapper"></div><ul class="page-numbers">
	<?php echo $page_url;?>
</ul>
	  </div><!-- #contents end -->
 </div><!-- #right_col end -->
<?php
 include View::getView('footer');
?>