<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="right_col">
  <div id="center_contents">
   <p class="date"><?php echo gmdate('Y/n/j G:i l', $date); ?></p>
    <h3 class="post_title"><?php topflg($top); ?><?php echo $log_title; ?></h3>
    <div class="post_content cf">
   <p><?php echo $log_content; ?></p>
<div id="similar_post">
<h3>相关文章</h3>
<?php $Log_Model = new Log_Model();
	  $randlogs = $Log_Model->getLogsForHome("AND sortid = {$sortid} ORDER BY rand() DESC,date DESC", 1, 5);?>
<ul>
<?php foreach($randlogs as $value): ?>
<li><a href="<?php echo $value['log_url']; ?>" title="查看文章:<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></li>
<?php endforeach; ?>
</ul>
</div>
<a href="javascript:history.back();" id="return"><img src="<?php echo TEMPLATE_URL; ?>images/return.gif" alt="返回" title="返回" width="61" height="15" class="roll"></a> 
     <ul class="post_meta">
      <?php blog_sort($logid); ?>
     </ul>
    </div>
<div id="comments_wrapper"><div id="comments">
 <div id="comment_header" class="cf">
  <ul id="comment_header_left">
   <li id="add_comment"><a href="#respond">发表评论</a></li>
  </ul>
  <ul id="comment_header_right">
    <li id="trackback_switch"><a href="javascript:void(0);">Trackback (<?php echo count($tb); ?>)</a></li>
    <li id="comment_switch" class="comment_switch_active"><a href="javascript:void(0);">评论 (<?php echo $comnum; ?>)</a></li>
  </ul>
 </div><!-- comment_header END -->
<div id="comment_area">
<!-- start commnet -->
 <?php blog_comments($comments); ?>
<!-- comments END -->
</div><!-- #comment-list END -->
<div id="trackback_area">
<!-- start trackback -->
 <?php blog_trackback($tb, $tb_url, $allow_tb); ?> 
</div><!-- #trackbacklist END -->
<div id="form_area">
 <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
</div><!-- #comment end --></div>	  </div><!-- #contents end -->
 </div><!-- #right_col end -->
<?php
 include View::getView('footer');
?>