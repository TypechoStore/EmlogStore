<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="right_col">
  <div id="center_contents">
   <p class="date"><?php echo gmdate('Y/n/j G:i l', $date); ?></p>
    <h3 class="post_title"><?php topflg($top); ?><?php echo $log_title; ?></h3>
    <div class="post_content cf">
   <p><?php echo $log_content; ?></p>
    </div>
<div id="comments_wrapper"><div id="comments">
 <div id="comment_header" class="cf">
  <ul id="comment_header_left">
   <li id="add_comment"><a href="#respond">发表评论</a></li>
  </ul>
  <ul id="comment_header_right">
    <li id="comment_switch" class="comment_switch_active"><a href="javascript:void(0);">评论 (<?php echo $comnum; ?>)</a></li>
  </ul>
 </div><!-- comment_header END -->
<div id="comment_area">
<!-- start commnet -->
 <?php blog_comments($comments); ?>
<!-- comments END -->
</div><!-- #comment-list END -->
<div id="form_area">
 <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
</div><!-- #comment end --></div>	  </div><!-- #contents end -->
 </div><!-- #right_col end -->
<?php
 include View::getView('footer');
?>