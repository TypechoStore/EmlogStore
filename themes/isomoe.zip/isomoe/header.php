<?php
/*
Template Name:私の日記
Description:仿mono-lab现用主题，原作者SHIKI...
Version:2.0
Author:魔法基佬MKⅡ
Author Url:http://hmoe.me/
Sidebar Amount:1
ForEmlog:5.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh">
<head profile="http://gmpg.org/xfn/11">
<title><?php echo $site_title; ?></title>
<link rel="alternate" type="application/rss+xml" title="订阅 <?php echo $blogname; ?>" href="<?php echo TEMPLATE_URL; ?>rss.php" />
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/style.css" type="text/css" />
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/comment-style.css" type="text/css" />
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>style.css" type="text/css" />
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>scripts/jquery.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>scripts/jquery.rollover.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>scripts/jquery.easing.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>scripts/jquery.easingscroll.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>scripts/sliding_menu.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>scripts/jquery.poshytip.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>scripts/jscript.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>scripts/comment.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>scripts/common_tpl.js"></script>
<!--[if lt IE 7]>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/ie6.css" type="text/css" media="screen" />
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>scripts/exfixed.js"></script>
<script>
$(function(){
  $('.fixed').exFixed();
});
</script>
<![endif]--> 
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<meta name="generator" content="emlog" />

</head>
<body>
 <h1 id="logo" class="fixed"><a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>"><?php echo $blogname; ?></a></h1>
 <?php blog_navi();?><div id="wrapper" class="cf">

  <div id="left_col" class="fixed">
   <ul id="global_menu" class="global_menu cf">
    <li><a href="<?php echo BLOG_URL; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/g_menu1_on.gif" alt="首页" title="首页" /></a></li>
    <?php if($istwitter == 'y'):?><li><a title="碎语" href="<?php echo BLOG_URL; ?>t/"><img src="<?php echo TEMPLATE_URL; ?>images/g_menu2.gif" alt="碎语" title="碎语" /></a></li><?php endif;?>
    <li><a href="<?php echo BLOG_URL; ?>?plugin=archiver"><img src="<?php echo TEMPLATE_URL; ?>images/g_menu3.gif" alt="归档" title="归档" /></a></li>
    <li><a href="<?php echo BLOG_URL; ?>guestbook.html"><img src="<?php echo TEMPLATE_URL; ?>images/g_menu4.gif" alt="留言板" title="留言板" /></a></li>
   </ul>   <div id="description">
    <p id="ava"><?php global $CACHE;
        $user_cache = $CACHE->readCache('user');
$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
<?php if (!empty($user_cache[1]['photo']['src'])): ?>
        <img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="85" height="85" alt="blogger" />
<?php endif;?></p>
    <h2><?php echo $bloginfo; ?><br/>Theme By <a href="http://www.shiki.me" target="_blank">SHIKI</a></h2>
    <p id="icon_mail"><a href="mailto:admin@hmoe.me" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/icon_mail.gif" alt="联系我" title="联系我" class="roll tooltip" /></a></p>
    <p id="icon_rss"><a href="<?php echo BLOG_URL; ?>rss.php" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/icon_rss.gif" alt="RSS" title="RSS" class="roll tooltip" /></a></p>
   </div>  </div>
  <div id="menu_desc" class="menu_desc fixed">
   <div><p><img src="<?php echo TEMPLATE_URL; ?>images/desc1.gif" alt="碎语" title="碎语" /></p></div>
   <div><p><img src="<?php echo TEMPLATE_URL; ?>images/desc2.gif" alt="归档" title="归档" /></p></div>
   <div><p><img src="<?php echo TEMPLATE_URL; ?>images/desc3.gif" alt="留言板" title="留言板" /></p></div>
  </div>