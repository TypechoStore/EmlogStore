jQuery(document).ready(function($) {
    //上下滑动
	$body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $("html") : $("body")) : $("html,body");
	$("#shang").mouseover(function() {
		up()
	}).mouseout(function() {
		clearTimeout(fq)
	}).click(function() {
		$body.animate({
			scrollTop: 0
		},
		600)
	});
	$("#xia").mouseover(function() {
		dn()
	}).mouseout(function() {
		clearTimeout(fq)
	}).click(function() {
		$body.animate({
			scrollTop: $(document).height()
		},
		600)
	});
	$("#comt").click(function() {
		$body.animate({
			scrollTop: $("#comments").offset().top
		},
		600)
	});

	
	//点击文章标题时预加载提示
	$(function(){
    $('#content h2 a,#contentleft #nextlog a').click(function(e){
    e.preventDefault();
    var htm='页面载入中',
      t=$(this).html(htm).unbind('click'),
      i=9;
    ct();
    window.location=this.href;//opera补丁
    function ct(){
      (i<0)?(
        i=9,
        t.html(htm),
        ct()
      ):(
        t[0].innerHTML+='z',
        i--,
        setTimeout(ct,200)
      );
    }//ct End
  });//Click Event End
});//jQuery End

$("#contentleft h2 a,#randlog li a,#newlog li a,#record li a,#blogsort li a,#record li a,#blogtags span a,#link li a,.right a,.left a").mouseover(function(e){
	this.myTitle = this.title;
	this.myHref = this.href;
	this.myHref = (this.myHref.length > 30 ? this.myHref.toString().substring(0,30)+"..." : this.myHref);
	this.title = "";
	var tooltip = "<div id='tooltip'><div class='relative'><div class='tip'></div><p>"+this.myTitle+"</p></div></div>";
	$('body').append(tooltip);
	$('#tooltip').css({"top":(e.pageY+20)+"px","left":(e.pageX-15)+"px"}).show('fast');
	}).mouseout(function(){this.title = this.myTitle;$('#tooltip').remove();
	}).mousemove(function(e){$('#tooltip').css({"top":(e.pageY+20)+"px","left":(e.pageX-15)+"px"});
});

	//dshare 分享模块
	dshare();
	function dshare() {
		var thelink = encodeURIComponent(document.location), 
			thetitle = encodeURIComponent(document.title.substring(0,60)), 
			windowName = '分享到',
			param = getParamsOfShareWindow(600, 560),
			
			ds_tqq = 'http://v.t.qq.com/share/share.php?title=' + thetitle + '&url=' + thelink + '&site=',
			ds_qzone = 'http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=' + thelink + '&title=',
			ds_tsina = 'http://v.t.sina.com.cn/share/share.php?url=' + thelink + '&title=' + thetitle,
			ds_douban = 'http://www.douban.com/recommend/?url=' + thelink + '&title=' + thetitle,
			ds_renren = 'http://share.renren.com/share/buttonshare?link=' + thelink + '&title=' + thetitle,
			ds_kaixin = 'http://www.kaixin001.com/repaste/share.php?rurl=' + thelink + '&rcontent=' + thelink + '&rtitle=' + thetitle,
			ds_facebook = 'http://facebook.com/share.php?u=' + thelink + '&t=' + thetitle,
			ds_twitter = 'http://twitter.com/share?url=' + thelink + '&text=' + thetitle;
			
	 	$('.dshare').each(function() {
			$(this).attr('title',windowName + $(this).text());
			$(this).click(function() {
				var httpUrl = eval($(this).attr('class').substring($(this).attr('class').lastIndexOf('ds_')));
				window.open(httpUrl, windowName, param);
			});
		});

		function getParamsOfShareWindow(width, height) {
			return ['toolbar=0,status=0,resizable=1,width=' + width + ',height=' + height + ',left=',(screen.width-width)/2,',top=',(screen.height-height)/2].join('');
		}
	}
$('#close-sidebar a').toggle(function(){
	$(this).text("开边栏")
	$('#sidebar').hide().prev().animate({width: "940px"}, 800);
	
	},function(){
	$(this).text("关边栏")
	$('#sidebar').delay(800).show(0).prev().animate({width: "700px"}, 800);
});
})(jQuery);