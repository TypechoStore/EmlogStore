<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
 </div>
 <div id="footer" class="fixed">
  <div id="footer_contents">

   <div id="search_area" class="cf">
    <form method="get" id="searchform" action="<?php echo BLOG_URL; ?>index.php">
     <div><input type="text" value="搜索" name="keyword" id="search_input" onfocus="this.value='';" /></div>
     <div><input type="image" src="<?php echo TEMPLATE_URL; ?>images/search_button.gif" alt="Search" title="Search" id="search_button" class="roll" /></div>
    </form>
   </div>

   <a href="javascript:void(0);" id="search_tag"><img src="<?php echo TEMPLATE_URL; ?>images/tags.gif" alt="搜索标签" title="搜索标签" width="43" height="18" class="roll" /></a>

<div id="footer_taglist">
<ul class="wp-tag-cloud">
    <?php {
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
    <?php shuffle($tag_cache);$tag_cache = array_shift(array_chunk($tag_cache,30));shuffle($tag_cache);foreach($tag_cache as $value): $color = dechex(rand(0,16777215));?>
    <a href="<?php echo Url::tag($value['tagurl']); ?>" title="标签为 <?php echo $value['tagname']; ?> 的日志有 <?php echo $value['usenum']; ?> 篇"><?php echo $value['tagname']; ?></a>
    <?php endforeach; ?>
    <?php }?></ul>
   </div>

   <div id="footer_category" class="cf">
<?php
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
    <ul id="f_cat1">
      <?php foreach($sort_cache as $value): ?>
      <li><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a></li>
      <?php endforeach; ?>
    </ul>
   </div>

   <div id="footer_link">
<?php {
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
	?>
    <ul>
      <?php foreach($link_cache as $value): ?>
      <li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
      <?php endforeach; ?>
    </ul>
    <?php }?>
   </div>
   <a href="javascript:void(0);" id="open_category"><img src="<?php echo TEMPLATE_URL; ?>images/open_category.gif" alt="查看分类" title="查看分类" width="58" height="20" class="roll" /></a>
   <a href="javascript:void(0);" class="close"><img src="<?php echo TEMPLATE_URL; ?>images/footer_close.gif" alt="关闭" title="关闭" width="43" height="9" class="roll tooltip" /></a>
   <a href="#wrapper" id="return_top"><img src="<?php echo TEMPLATE_URL; ?>images/return_top.gif" alt="回到顶部" title="回到顶部" width="67" height="20" class="roll" /></a>
   <img src="<?php echo TEMPLATE_URL; ?>images/copyright.gif" alt="&copy; 2011 &nbsp;<?php echo $blogtitle; ?>&nbsp;&nbsp;All rights reserved" title="&copy; 2011 &nbsp;<?php echo $blogtitle; ?>&nbsp;&nbsp;All rights reserved" width="203" height="7" id="copyright" />

  </div>
  <div style="width:0;height:0; visibility:hidden;"><?php doAction('index_footer'); ?></div>
 </div><!-- END #footer -->
</body>
</html>