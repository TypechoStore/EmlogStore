<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
          <p class="date">作者：<?php blog_author($author); ?> | 发布于：<?php echo gmdate('Y-n-j G:i ', $date); ?> |
	<?php blog_sort($logid); ?> | <?php blog_tag($logid); ?> <?php editflg($logid,$author); ?>
	</p>
          <?php echo $log_content; ?>
		  <div ID="nextlog"><?php neighbor_log($neighborLog); ?></div>
	      <?php doAction('log_related', $logData); ?>
          <div class="wumii-hook">
    <input type="hidden" name="wurl" value="<?php echo Url::log($logid); ?>" />
    <input type="hidden" name="wtitle" value="<?php echo $log_title; ?>" />
</div>
<script>
    var wumiiSitePrefix = "<?php echo BLOG_URL; ?>";
</script>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<p><?php blog_att($logid); ?></p>
          <div class="clr"></div>
        </div>
        </div>
                    <div class="sidebar">
      <?php
 include View::getView('side');
?>
</div>
  </div>
    </div>
      <div class="clr"></div>
<?php
 include View::getView('footer');
?>