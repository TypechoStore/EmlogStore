<?php 

/*

* 首页日志列表部分

*/

if(!defined('EMLOG_ROOT')) {exit('error!');} 

?>

<div class="content">

    <div class="content_resize">

      <div class="mainbar">

        <div class="article">

         <?php doAction('index_loglist_top'); ?>

  <?php foreach($logs as $value): ?>

          <h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>

          <p>发布:<?php echo gmdate('Y-n-j G:i ', $value['date']); ?> | 人气: <?php echo $value['views']; ?></a> | <?php blog_sort($value['logid']); ?> | 编辑： <?php blog_author($value['author']); ?>  | <?php blog_tag($value['logid']); ?> <?php editflg($value['logid'],$value['author']); ?> </p>

          <p><?php echo $value['log_description']; ?></p>

          <p><?php blog_att($value['logid']); ?></p>

          <div class="clr"></div>

          <?php endforeach; ?>

        </div>
<div id="pagenavi">
	<?php echo $page_url;?>
</div>

        <div class="clr"></div>

      </div>

      <div class="sidebar">

      <?php

 include View::getView('side');

?>

</div>

  </div>

  </div><!-- end #contentleft-->

  <div class="clr"></div>

  <?php

 include View::getView('footer');

?>

