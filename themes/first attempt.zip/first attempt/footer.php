﻿<?php 
/*
* 底部信息
*/

if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="header2">
    <div class="content_resize">
      <div class="logo">
          <div ><!-- JiaThis Button BEGIN -->
<div class="jiathis_style_32x32">
	<a class="jiathis_button_fav"></a>
	<a class="jiathis_button_print"></a>
	<a class="jiathis_button_tsina"></a>
	<a class="jiathis_button_qzone"></a>
	<a class="jiathis_button_renren"></a>
	<a class="jiathis_button_kaixin001"></a>
	<a class="jiathis_button_taobao"></a>
	<a class="jiathis_button_douban"></a>
	<a class="jiathis_button_xiaoyou"></a>
	<a class="jiathis_button_msn"></a>
	<a class="jiathis_button_tieba"></a>
	<a class="jiathis_button_meilishuo"></a>
	<a class="jiathis_button_mop"></a>
	<a class="jiathis_button_tianya"></a>
	<a class="jiathis_button_googleplus"></a>
	<a class="jiathis_button_twitter"></a>
	<a class="jiathis_button_fb"></a>
	<a class="jiathis_button_ujian"></a>
	<a href="http://www.jiathis.com/share" class="jiathis jiathis_txt jtico jtico_jiathis" target="_blank">更多</a>
	<a class="jiathis_counter_style"></a>
</div>
<script type="text/javascript" src="http://v2.jiathis.com/code/jia.js?uid=1346204938700568" charset="utf-8"></script>
<!-- JiaThis Button END --></div><br /><br />
        <h2>那些走访的朋友！</h2>
		  <div class="link">
            <?php widget_link(''); ?>
        </div>
		  <div class="clr"></div>
      </div>
  </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
      <div class="col c1">
	          <div class="clr"></div>
        <h2>发现你想要的！</h2>
  <ul class="search">
    <form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
      <input type="text" value=" Search and press Enter..." name="keyword"  onFocus="this.value = this.value == this.defaultValue ? '' : this.value" onBlur="this.value = this.value == '' ? this.defaultValue : this.value" class="s" /> 
    </form>
  </ul>
        <h2>社交联系</h2>
        <a href="http://weibo.com/ooian" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>/images/logo/WEIBO.jpg" width="56" height="56" alt="微博" class="ad" /></a>
		 <a href="#" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>/images/logo/weigt.jpg" alt="微信" width="56" height="56" border="0" class="ad" /></a>
        <a href="http://shop73163747.taobao.com/" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>/images/logo/QQ.jpg" width="56" height="56" alt="淘宝网" class="ad" /></a>
				 <a href="http://www.taobao.com/webww/?spm=a1z10.1.0.30.de5d86&ver=1&&touid=cntaobaoqq77152450&siteid=cntaobao&status=2&portalId=&gid=&itemsId=" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>/images/logo/wangwang.jpg" alt="旺旺" width="56" height="56" border="0" class="ad" /></a><br />
				 <a href="http://user.qzone.qq.com/77152450/infocenter" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>/images/logo/Q-z.jpg" alt="QQ-z" width="56" height="56" border="0" class="ad" /></a>
<a href="http://weibo.com/ooian" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>/images/logo/photo.jpg" alt="相册" width="56" height="56" border="0" class="ad" /></a>
        <a href="mailto:design.ooian@gmail.com" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>/images/logo/mail.jpg" width="56" height="56" alt="邮件" class="ad" /></a>
        <a href="/rss.php" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>/images/logo/RSS.jpg" alt="RSS" width="56" height="56" border="0" class="ad" /></a></div>
      <div class="col c2">
        <h2>我在说些什么！</h2>
<?php widget_twitter(''); ?>
      </div>
      <div class="col c3">
        <h2>我身在何处？</h2>
        <p>每一个成长的过程都需要漂流自己的心灵，我现在在惠州仲恺一家设计公司工作。我希望我的工作可以帮助到那些有需求的朋友，我深感荣幸！</p>
        <p><b>Phone: +86 180 2661 4840</b><br>
           <b>QQ: 77 152450</b><br>
           <b>E-mail:<b> <a href=mailto:design.ooian@gmail.com>design.ooian</a></b>
        <h2>服务</h2>
        <ul class="sb_menu">
          <li><a href="#"> 室内定制设计</a></li>
          <li><a href="#">施工图图纸制作</a></li>
          <li><a href="#">三维效果图制作</a></li>
        </ul>
     </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
        <p class=class="lf">&copy; Copyright 2011. Powered by <a href="http://www.emlog.net" target="_blank" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog.</a> Theme by <a href="http://www.ooian.com/">PAOPAO.</a>
          <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
          <?php doAction('index_footer'); ?> | <a href="http://www.ooian.com/">室内设计网站</a> <a href="/index.php?keyword=客厅设计">客厅设计</a> <a href="/index.php?keyword=卧室设计">卧室设计</a> <a href="/index.php?keyword=效果图制作">室内效果图</a> <a href="/index.php?keyword=3D模型">室内设计3D模型</a></p>
    </div>
    </div>
    <div class="clr"></div>
  </div>
<!-- UJian Button BEGIN -->
<script type="text/javascript" src="http://v1.ujian.cc/code/ujian.js?type=slide&uid=1701105"></script>
<!-- UJian Button END -->
<?php
if ($type == 'blog') { echo <<<LOADSCRIPT

<script type="text/javascript">
    var wumiiParams = "&num=5&mode=3&pf=emlog";
</script>
<script type="text/javascript" id="wumiiRelatedItems" src="http://widget.wumii.com/ext/relatedItemsWidget"></script>
<a href="http://www.wumii.com/widget/relatedItems" style="border:0;">
    <img src="http://static.wumii.cn/images/pixel.png" alt="无觅相关文章插件，快速提升流量" style="border:0;padding:0;margin:0;" />
</a>
LOADSCRIPT;
}
?>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/zh_CN/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
</body>
</html>

