<?php
/*
Template Name:Small fresh
Description:简洁、现代、小清新
Version:1.2
Author:屠夫
Author Url:http://blog.941mx.com/
original Author Url:http://sev7n.net/
Sidebar Amount:1  侧边栏只有一个
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<!--[if lt IE 9]>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>ie.css" />
<![endif]-->
<!--[if IE 9]>
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet"/>
<![endif]-->
<!--[if !IE 8]><!-->
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet"/>
<!--<![endif]-->
<!--[if IE 8]>
<link href="<?php echo TEMPLATE_URL; ?>ie8.css" rel="stylesheet" />
<![endif]-->
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>/js/jquery.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
<script>
		$(function() {
			$(".meter > span").each(function() {
				$(this)
					.data("origWidth", $(this).width())
					.width(0)
					.animate({
						width: $(this).data("origWidth")
					}, 1200);
			});
		});
	</script>
<?php doAction('index_head'); ?>
</head>
<!--[if !IE 9]>
<div id="tips-ie">你还在用古时候的IE内核浏览器啊-_-! 赶紧升级到IE9或者Firefox/Chrome等现代浏览器吧，相信您会有更好的体验！~(@^_^@)~</div>
<![endif]-->
<body>
<div id="wrap">
<div id="header">
  <div>
    <h1 id="logo"> <a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>" rel="home"><?php echo $blogname; ?></a> </h1>
    <h2 id="describe"><?php echo $bloginfo; ?></h2>
  </div>
  <div id="nav">
    <ul class="clearfix">
    <?php blog_navi();?>
    </ul>
  </div>
  <div id="menu"> 
    <a href="http://www.941mx.com/" title="玖年记" id="trigger-theme"></a>
    <a href="<?php echo BLOG_URL; ?>rss.php" title="你不订阅吗？" id="rss"></a> 
    <a href="http://weibo.com/iamtalent" rel="nofollow" target="_blank" title="微博" id="wb"></a> 
    </div>
</div>
