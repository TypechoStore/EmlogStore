$(document).ready(function(){
	$("#tab-title span").mouseover(function(){
			$('#tab-title span').removeClass("selected");
			$(this).addClass("selected");
			var likey = $("#tab-title span").index(this); 
			
			$('#tab-content ul').addClass("hide").removeClass("block");
			$("#tab-content ul:eq("+likey+")").addClass("block").removeClass("hide");
		});
	})
