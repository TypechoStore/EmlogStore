<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="page">
<div id="content" role="main">
  <section id="main" class="single">
    <article id="post-<?php echo $logid; ?>" class="post-<?php echo $logid; ?> post">
      <header>
        <h1 class="post-title"> <?php echo $log_title; ?> </h1>
      </header>
      <div class="post-content"> <?php echo $log_content; ?>
        <?php blog_att($value['logid']); ?>
      </div>
    </article>

    <div class="commentwrap">
      <?php blog_comments($comments,$logid,$params); ?>
      <div id="respond">
        <?php if ($allow_remark == 'y'){blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);}?>
      </div>
    </div>
 </section>
  
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>
