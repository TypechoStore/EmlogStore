<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="page">
<div id="content" role="main">
  <section id="main" class="single">
    <div id="post-<?php echo $logid; ?>" class="post-<?php echo $logid; ?> post">
      <header>
        <h1 class="post-title">
          <?php topflg($top); ?>
          <?php echo $log_title; ?><sup><a class="comments-link" href="<?php echo Url::log($logid); ?>#comments"><?php echo $views; ?></a></sup> </h1>
        <p class="post-meta">
          <time class="post-date" datetime="<?php echo gmdate('Y-n-j', $date); ?>"><?php echo gmdate('n月 j, Y G点', $date); ?></time>
          • <span class="post-category">
          <?php blog_sort($logid); ?>
          </span> → <span class="post-tag">
          <?php blog_tag($logid); ?>
          </span> </p>
      </header>
      <div class="post-content"> <?php echo $log_content; ?>
        <?php blog_att($value['logid']); ?>
      </div>
      <div class="new_info left">
          <h2>相关文章</h2>
  <ul class="top_articles">
      <?php doAction('log_related', $logData); ?>
        </ul>
</div>
      
    </div>
    <nav>
      <ul class="post-nav clearfix">
        <?php neighbor_log($neighborLog); ?>
      </ul>
    </nav>
    <!-- 评论模块-->
    <div class="commentwrap">
      <?php blog_comments($comments,$logid,$params); ?>
      <div id="respond">
        <?php if ($allow_remark == 'y'){blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);}?>
      </div>
    </div>
    <?php blog_trackback($tb, $tb_url, $allow_tb); ?>
  </section>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>
