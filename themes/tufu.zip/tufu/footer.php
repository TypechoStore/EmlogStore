<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="footer">
		<p class="copyright">Copyright © 2013 <a href="<?php echo BLOG_URL; ?>" rel="home"></a>. All Rights Reserved.</p>
		<p class="power">
        Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>, 
        <a href="http://sev7n.net/" rel="home">Sev7n</a> Themed Cover By Butcher,
                  <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> 
				  <?php echo $footer_info; ?>
                  </p>
        <?php doAction('index_footer'); ?>
		<p style="display: block;" id="back-top"><a href="#top"><span></span>Top</a></p>
	</div>
</div>
<div class="meter red"> <span style="width: 100%"></span></div>
</div>
</body>
</html>

