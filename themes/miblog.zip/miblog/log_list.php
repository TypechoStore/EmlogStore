<?php
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="content">
	
	

<ul>
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?><div class="wzk">
	
	<div class="liy"><h2 class="content_h2">
	<?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
	</h2>
    <div class="clear"></div>
   	
  <div class="postact">
     <span class="info-time-icon"><?php echo date('Y-n-j ', $value['date']); ?></span>
      <span class="info-user-icon"><?php blog_author($value['author']); ?></span>
	<span class="info-comment-icon"><a  href="<?php echo $value['log_url']; ?>#comment"><?php echo $value['comnum']; ?>条评论</a></span>
	<span class="info-view-icon"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['views']; ?>人围观</a></span>
    <span class="info-tag-icon"><?php blog_tag($value['logid']); ?></span>
	</div></div>
		</div>
<?php endforeach; ?>
</ul>
<div id="pagenavi">
<?php echo $page_url;?>
<span>共<?php echo ceil($sta_cache['lognum']/$index_lognum);?>页</span>
	
</div>
</div>
<!--end content-->
<?php
 include View::getView('side');
 include View::getView('footer'); 
?>