<?php 
/*
* 日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
   <div id="position">
   	
          
            </div>
<div id="content">
<div id="position_l"> 当前位置：<a href="<?php echo BLOG_URL; ?>" title="返回首页">首页</a>&nbsp;&nbsp;》 <?php blog_sort($logid); ?> &nbsp;&nbsp;》正文 </div> 
<ul>
<li>
	<h2 class="content_h3"><?php topflg($top); ?><?php echo $log_title; ?></h2>
	<div class="editor"><?php editflg($logid,$author); ?></div>
    <div class="ge1"></div>
    <div class="postact1">&nbsp;作者：<?php blog_author($author); ?>&nbsp;|&nbsp;
    日期：<?php echo gmdate('Y-n-j H:i', $date); ?>&nbsp;|&nbsp;
    阅读：<?php echo $views; ?>次&nbsp;|&nbsp;
    评论：<a href="#respond"><?php echo $comnum; ?>人</a>&nbsp;|&nbsp;
    分类：<?php blog_sort($logid); ?>
    </div>
	<div class="post2">
	<?php echo $log_content; ?></div>
	
	<?php doAction('log_related', $logData); ?>
 <div class="content-footer">
 <!-- Baidu Button BEGIN -->
<div id="bdshare" class="bdshare_t bds_tools_24 get-codes-bdshare">
<a class="bds_tsina"></a>
<a class="bds_qzone"></a>
<a class="bds_tqq"></a>
<a class="bds_renren"></a>
<a class="bds_t163"></a>
<a class="bds_fx"></a>
<a class="bds_kaixin001"></a>
<a class="bds_tsohu"></a>
<a class="bds_ty"></a>
<a class="bds_tfh"></a>
<a class="bds_xg"></a>
<a class="bds_mail"></a>
<a class="bds_print"></a>
<a class="bds_copy"></a>
<span class="bds_more"></span>
<a class="shareCount"></a>
</div>
<script type="text/javascript" id="bdshare_js" data="type=tools&uid=0" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
</script>
<!-- Baidu Button END -->
</br></br>
       <?php blog_tag($logid); ?>
      </br>
       相邻文章：<?php neighbor_log($neighborLog); ?>
      </div>
	 <div id="sm"> <div class="bq"  style="border: 1px solid #CEE1F6;align:center;font-size: 13px;">
<strong>声明:</strong> 本文采用 <a href="http://creativecommons.org/licenses/by-nc-sa/3.0/" rel="nofollow external"><abbr title="署名-非商业性使用-相同方式共享">BY-NC-SA</abbr></a> 协议进行授权. 转载请注明转自:<a href="<?php echo $log_url; ?>"><?php echo $log_title; ?></a></div></div>
    <?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);?>
    
</li>
</ul>
</div>
<!--end content-->
<?php 
include View::getView('side');
include View::getView('footer'); 
?>