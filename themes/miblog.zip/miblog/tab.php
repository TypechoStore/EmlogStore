<div id="tab-title">
		<h3><span class="selected">热门围观</span> | <span>最新文章</span> | <span>随机文章</span></h3>
	</div>
	<div id="tab-content">
		<ul><?php index_tablist('', 'view', $num="8"); ?></ul>
		<ul class="hide">
		   <?php index_tablist('', 'new', $num="8"); ?></ul>
		<ul class="hide"><?php index_tablist('', 'rand', $num="8"); ?></ul>
	</div>
    <div class="clear"></div>
    
    
    
<script type="text/javascript">
$('#tab-title span').mouseover(function(){
	$(this).addClass("selected").siblings().removeClass();
	$("#tab-content > ul").eq($('#tab-title span').index(this)).show(250).siblings().hide(250);
});</script>