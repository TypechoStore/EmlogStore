<?php
/*
Template Name:miblog
Version:1.0
Description:类似小米论坛，微博客式样
Author:asim
Author Url:http://asim.cn
Sidebar Amount:1
ForEmlog:5.0+
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once (View::getView('module'));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /><meta property="qc:admins" content="16614001415636" />
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<title><?php echo $site_title; ?> </title>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>css/saySlide.css" type="text/css" rel="stylesheet"  />
<link rel="shortcut icon" href="<?php echo TEMPLATE_URL; ?>images/favicon.ico" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script language="javascript" type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery-1.8.3.min.js"></script>
<script language="javascript" type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.corner.js"></script>
<script language="javascript" type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.saySlide.js"></script>
<script language="javascript" type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/kurly.js"></script>
<script language="javascript" type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery-1.3.2.min.js"></script>
<script language="javascript" type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/ddsmoothmenu.js"></script>



<!--[if lt IE 7]>
<div style='border: 1px solid #F7941D; background: #FEEFDA; text-align: center; clear: both; height: 20px; position: relative;'>
<div style='width:auto; hight:auto; color:red; text-align: center; font-size: 14px; font-weight: bold; line-height: 2em;'>温馨提示：您的IE版本过低，建议您升级浏览器。 <strong style='color:#0099FF;'>建议浏览器：</strong>  <strong style='padding-right: 10px;padding-left: 10px;'>[<a style='color: #0099FF;text-decoration: underline; href='http://www.firefox.com.cn/download/' target='_blank'>火狐</a>]</strong>  <strong style='padding-right: 10px;padding-left: 10px;'>[<a style='color: #0099FF;text-decoration: underline; href='http://ie.sogou.com/' target='_blank'>搜狗</a>]</strong><a style='color:#000' href='#' onclick='javascript:this.parentNode.parentNode.style.display="none"; return false;'>关闭提示</a></div>
</div>
</div>
<![endif]-->
</head><?php doAction('index_head'); ?><meta property="wb:webmaster" content="b84632c263febf5d" />
<body>
<a name="gotop" id="gotop"></a> 
<div id="na">
    <div id="naBar">
     <div class="topna"><ul>
 <li> <a href="<?php echo BLOG_URL; ?>about" title="About" class="home" target="_blank">关于</a></li>
 <li> <a href="<?php echo BLOG_URL; ?>?plugin=archiver" title="Archives" class="home" target="_blank">存档</a></li>
 <li> <a href="<?php echo BLOG_URL; ?>guestbook" title="Guestbook" class="home" target="_blank">留言</a></li>
<li> <a href="<?php echo BLOG_URL; ?>?plugin=yls_reg" title="About" class="home" target="_blank">注册</a></li>		 
<li> <a href="<?php echo BLOG_URL; ?>admin" title="About" class="home" target="_blank">登陆</a></li>
<li> <a href="<?php echo BLOG_URL; ?>submission.html" title="submission" class="home" target="_blank">投稿</a></li>
		 </ul>
</div>
			<!-- end: left_top --> 
			<div id="naLink">
        <ul>
        
		<li><a href="http://feed.feedsky.com/asim" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/icon-rss.gif" alt="欢迎订阅本博客!" title="欢迎订阅本博客!" width="21" height="21" /></a></li>
          <li><a href="http://asim.cn/t/" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/ioc-weibo.png" alt="新浪微博 求围观!" title="新浪微博 求围观!" width="21" height="21" /></a></li>
           <li><a href="http://asim.cn/t/" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/icon-tqq.gif" alt="腾讯微博 求围观!" title="腾讯微博 求围观!" width="21" height="21" /></a></li>
            <li><a href="http://sighttp.qq.com/authd?IDKEY=f09e" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/ioc-qq.png" alt="点此和我QQ交谈!" title="点此和我QQ交谈!" width="21" height="21" /></a></li>
          <li><a href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=IRATExAXFhYZFmFQUA9CTkw" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/icon-email.gif" alt="发邮件给我吧!" title="发邮件给我吧!" width="21" height="21" /></a></li>
        </ul>
      </div>
      </div>
		</div>	
<div id="logo">
	<div class="logo_l">
      <a rel="home" title="<?php echo $blogname; ?>" href="<?php echo BLOG_URL; ?>">
		<img src="<?php echo TEMPLATE_URL; ?>images/logo.png"></a>
    </div>
<div id="gg"><red>微广播:</red><div id="position_r">		
		<li>
		<?php include('js/time.php'); ?>
		</li>
        </div><div class="suiyu"><?php echo index_t(2); ?>
            </div>
<script>
		var c, _ = Function;
		with( o = document.getElementById("suiyu")) {
			innerHTML += innerHTML;
			onmouseover = _("c=1");
			onmouseout = _("c=0");
		}( F = _("if(#%27||!c)#++,#%=o.scrollHeight>>1;setTimeout(F,#%27?10:2000);".replace(/#/g, "o.scrollTop")))();
	</script></div>	
	
  <div class="logo">
   
	<div class="logo_r">
	<table width="280" height="70" border="0" cellpadding="0" cellspacing="0" bgco5lor="#eee">
  <tr align="center">
    <td style="line-height:20px;font-size:18px;color:#3300CC;padding-left:70px;">asim新品发布会<br>2014-5-15</td>
  </tr>
</table>
	
	</div>
 </div>
  
</div>
<div id="nav">
<DIV class=ddsmoothmenu id=smoothmenu1>
<?php blog_navi();?>
</DIV><form method="get" class="search-form" action="<?php echo BLOG_URL; ?>index.php">
			<input class="search-input" name="keyword" placeholder="善于使用搜索引擎" autofocus="" x-webkit-speech="" type="text"><input class="search-submit" value="搜索" type="submit">
		</form>
</div>
<div class="clear"></div>
<div class="main">