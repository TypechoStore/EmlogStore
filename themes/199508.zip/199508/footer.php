<?php 
/*
底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="footer">
<a id="go-top" href="#">Back to top</a>    <div class="credits"> 
	&copy; <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>
	由<a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank" rel="external nofollow">EMLOG</a>驱动<br/>
	<a href="http://199508.com/theme" target="_blank" title="Theme">Theme Link</a> <!--这里是统计代码 开始--><?php echo $footer_info; ?><!--这里是统计代码 结束--><br/>
	<?php doAction('index_footer'); ?>
<!--这里是站点统计代码 开始--><?php $sta_cache = Cache::getInstance()->readCache('sta');?>
<?php echo $sta_cache['lognum']; ?>篇文章
<?php echo $sta_cache['comnum']; ?>个评论<!--这里是站点统计代码 结束-->
	<br/ ><a href="http://www.miibeian.gov.cn" target="_blank"  rel="nofollow"><?php echo $icp; ?></a><a href="http://199508.com/3loc" target="_blank">主机</a>
    </div>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/common_tpl.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/x.js"></script>
  </div><!--end #footerbar-->
<?php if(isset($ckmail) && empty($ckmail)): ?>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/realgravatar.js"></script>
<?php endif; ?>
</body>
</html>