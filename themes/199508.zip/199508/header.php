<?php
/*
Template Name:199508
Description:魔法基佬的Win Metro主题1.1版与星星水的Metro1.2修正与剪接，所以就叫做1.0版
Version:1.2
Author:黎健雄
Author Url:http://199508.com
Sidebar Amount:0
ForEmlog:5.0.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
if(function_exists('emLoadJQuery')) {
    emLoadJQuery();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link type="text/css" href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" />
	<?php doAction('index_head'); ?>
	<!--[if lt IE 9]>
	<script src="<?php echo TEMPLATE_URL; ?>js/ie.js"></script>
	<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/lazyload.js"></script>
<script type="text/javascript">
jQuery(document).ready(function($){
  if (navigator.platform == "iPad") return;
  jQuery("img").lazyload({
    effect:"fadeIn",
    placeholder: "<?php echo TEMPLATE_URL; ?>images/grey.gif"
  });
});
</script>
	</head>
	<body>
	<div id="wrap">
	<div id="header">
 <div class="logo">
<h1><a target=_blank href="http://199508.ml/" title="黎健雄present">
<?php global $CACHE;
        $user_cache = $CACHE->readCache('user');
$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
<?php if (!empty($user_cache[1]['photo']['src'])): ?>
        <img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="200" height="200" alt="blogger" />
<?php endif;?>
</a></h1>
<span class="vpbg"></span>
<span class="vinf"><a href="<?php echo BLOG_URL; ?>t" title="微短语"><h3><?php widget_twitter_random($title);?></h3></a></span>
</div>
    <!--MenuNav Stard-->
    <div id="nav">
	<div id="navhead">
	  <ul id="menu" class="menu">
	  <form name="keyform" method="get" id="searchform" action="<?php echo BLOG_URL; ?>index.php">
      <input type="text" name="keyword" class="s" placeholder="Search" x-webkit-speech>
    </form>
        <li class="home"><a title="首页" href="<?php echo BLOG_URL; ?>">Home</a></li>
        <?php if($istwitter == 'y'):?><li class="twi"><a title="碎语" href="<?php echo BLOG_URL; ?>t/">说说<?php echo Option::get('twnavi');?></a></li><?php endif;?>
        <li class="host"><a title="友链" href="<?php echo BLOG_URL; ?>links">Friend</a></li>
        <li class="archive"><a title="归档" href="<?php echo BLOG_URL; ?>?plugin=archiver">Archiver</a></li>
		<li class="guestbook"><a title="留言" href="<?php echo BLOG_URL; ?>guestbook">Guestbook</a></li>
		      <!-- 
			  <li class="friend "></li>
              -->		
  <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
  <li class="write"><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
  <li class="admin"><a href="<?php echo BLOG_URL; ?>admin/" target="_blank">管理中心</a></li>
  <li class="logout"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
  <?php else: ?>
  <li class="login"><a href="<?php echo BLOG_URL; ?>admin/" rel="nofollow">Login</a></li>
  <?php endif; ?>
      </ul>
    </div>
	</div>
<div id="bomb">
  <?php {
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
  <ul class="recentcomments">
    <h3>Comments</h3>
    <?php
	foreach($com_cache as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	?>
    <li><img src="http://www.gravatar.com/avatar/<?php  echo md5($value['mail']); ?>" width="34" height="34" class="avatar" title="<?php echo $value['name']; ?>" /><?php echo $value['name']; ?> <br />
      <a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a></li>
    <?php endforeach; ?>
  </ul>
  <?php }?>
  <div class="arrow"></div>
	    	<?php doAction('diff_side'); ?>
</div>    <!--conment Stard-->
    <!--MenuNav End-->
  </div></div>
</div>
    <!--conment End-->
  <!-- end #header-->