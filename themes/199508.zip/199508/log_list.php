<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
  <?php doAction('index_loglist_top'); ?>
  <?php foreach($logs as $value): ?>
  <div class="post div">
   <script language="JavaScript"> 
   var m=14;
    var n=Math.floor(Math.random()*m+1) 
    switch(n)
    { 
    case 1:    
document.write('<div class="magenta">');
    break;   
    case 2: 
document.write('<div class="purple">');
    break;    
    case 3: 
document.write('<div class="teal">');
    break;     
    case 4:    
document.write('<div class="lime">');
    break;   
    case 5:    
document.write('<div class="brown">');
    break;   
    case 6:    
document.write('<div class="pink">');
    break;   
    case 7:    
document.write('<div class="orange">');
    break;   
    case 8:    
document.write('<div class="b1ue">');
    break;   
    case 9:    
document.write('<div class="red">');
    break;   
    case 10:    
document.write('<div class="green">');
    break;   
    case 11:    
document.write('<div class="marine">');
    break;   
    case 12:    
document.write('<div class="purple2">');
    break;   
    case 13:    
document.write('<div class="teal2">');
    break;   
    case 14:    
document.write('<div class="dark">');
    break;   
    } 
</script>
    <h2>
      <?php topflg($value['top']); ?>
      <a class="title" href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a><a class="more" href="<?php echo $value['log_url']; ?>" title="阅读全文"></a></h2></div>
    <div class="data"> <span class="post-time">作者：<?php blog_author($value['author']); ?> / 发布于：<?php echo gmdate('Y年n月j日', $value['date']); ?></span> <span class="post-sort">Posted in
      <?php blog_sort($value['logid']); ?>
      </span> <span class="post-count"><a href="<?php echo $value['log_url']; ?>#comments" title="查看<?php echo $value['log_title']; ?>上的评论"><?php echo $value['comnum']; ?></a></span> <span class="post-views"><?php echo $value['views']; ?></span>
      <?php editflg($value['logid'],$value['author']); ?>
    </div>
    <div class="post-content"> 
	<ul><?php echo subString(strip_tags($value['content']),0,150); ?></ul>
      <div class="post-footer"> <span class="post-tag">Tags:
        <?php blog_tag($value['logid']); ?>
        </span> </div>
    </div>
  </div>
  <?php endforeach; ?>
  <?php if($logs == NULL) { ?>
<img src="<?php echo TEMPLATE_URL; ?>images/01.png"/><br />
<p> 亲,没有找到您要的东西哟,您可以换个关键词或者联系 [<a href="<?php echo BLOG_URL; ?>post/59" target="_blank">管理员</a>] 添加更多资源。</p>
<?php } ?>
  <div id="pagenavi"> <?php echo $page_url;?> </div>
  
   
</div>
<!-- end #content-->
<?php
 include View::getView('footer');
?>