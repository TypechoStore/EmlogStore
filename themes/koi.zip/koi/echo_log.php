<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div class="post">
	<h2 class="post-title"><?php topflg($top); ?><?php echo $log_title; ?></h2>
	<p class="post-date">
		<span class="day"><?php echo gmdate('j', $date); ?></span>
		<span class="month"><?php echo gmdate('n月', $date); ?></span>
		<span class="year"><?php echo gmdate('Y', $date); ?></span>
		<span class="postcomment"><?php echo $comnum; ?> Comments</span>
	</p>
	<p class="post-data">
		<span class="postauthor">by <?php blog_author($author); ?></span>
		<span class="postcategory">sort <?php blog_sort($logid); ?></span>
		<?php blog_tag($logid); ?> <?php editflg($logid,$author); ?>
	</p>
	<?php echo $log_content; ?>
	<?php doAction('log_related', $logData); ?>
	<p class="post-nav"><?php neighbor_log($neighborLog); ?></p>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<h4 id="comments"><?php echo $comnum; ?> Comments <em>(<a href="#respond">+add yours?</a>)</em></h4>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
</div><!--end #contentleft-->
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>