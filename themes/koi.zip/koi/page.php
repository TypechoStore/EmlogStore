<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
	<h2 class="post-title"><?php echo $log_title; ?></h2>
	<?php echo $log_content; ?>
	<h4 id="comments"><?php echo $comnum; ?> Comments <em>(<a href="#respond">+add yours?</a>)</em></h4>
<div class="post">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
</div><!--end #contentleft-->
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>