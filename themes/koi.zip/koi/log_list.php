<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<div class="post">
	<h2 class="post-title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
	<p class="post-date">
		<span class="day"><?php echo gmdate('j', $value['date']); ?> </span>
		<span class="month"><?php echo gmdate('n月', $value['date']); ?> </span>
		<span class="year"><?php echo gmdate('Y', $value['date']); ?> </span>
		<span class="postcomment"><?php echo $value['comnum']; ?> Comments</span>
	</p>
	<p class="post-data">
		<span class="postauthor">by <?php blog_author($value['author']); ?></span>
		<span class="postcategory">sort <?php blog_sort($value['logid']); ?> </span>
		<span class="posttag">Tags: <?php blog_tag($value['logid']); ?></span><?php editflg($value['logid'],$value['author']); ?>
	</p>
	<?php echo ''.subString(strip_tags($value['log_description'],$img),0,200).''; ?>...
</div><!-- end #contentleft-->
<div style="clear:both;"></div>
<?php endforeach; ?>
<p class="post-nav">
	<?php $page_next = next_page($lognum, $index_lognum, $page, $pageurl);echo $page_next;?>
</p>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>