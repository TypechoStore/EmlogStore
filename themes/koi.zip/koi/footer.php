<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div style="clear:both;"></div>
<div id="footer">
	<div class="footer1">
		<h4>Recent Posts</h4>
		<ul id="newlog">
			<?php
			global $CACHE; 
			$newLogs_cache = $CACHE->readCache('newlog');
			?>
			<?php foreach($newLogs_cache as $value): ?>
			<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
			<?php endforeach; ?>
		</ul>
	</div>
	<div class="footer2">
		<h4>Recent Comments</h4>
		<ul class="recent-comments">
			<?php
			global $CACHE; 
			$com_cache = $CACHE->readCache('comment');
			?>
			<?php
			foreach($com_cache as $value):
			$url = Url::comment($value['gid'], $value['page'], $value['cid']);
			?>
			<li><a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a><br>
			<cite class="comment-author"><?php echo $value['name']; ?></cite></li>
			<?php endforeach; ?>
		</ul>
	</div>
	<div class="footer3">
		<h4>About</h4>
		<p><em>Come on!As soon as possible,speed to rid of this fucking personal description in  line 39 in footer.php!</em></p>
	</div>
<p class="credits">
© copyright <?php echo $blogname; ?></a> 2013 <span>•</span> Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">Emlog</a>  <span>•</span> 
<a href="http://www.ndesign-studio.com/wp-themes">Theme</a> by <a href="http://www.ndesign-studio.com">N.Design</a> <br><br>Don't forget transplant by <a href="http://blog.11ri.net">LaoLuo</a><br>
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
</p>
<?php doAction('index_footer'); ?>
</div><!--end #footerbar-->
</div><!--end #wrap-->
</body>
</html>