<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div class="clear"></div>
	<div id="footer">
	     <div class="search">
		 <form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php" class="clearfix">
			  <input type="text" name="keyword" class="yahei" value="输入搜索关键词回车…" onfocus="this.value=''" />
			  </form>
			  <p>© 2012 <?php echo $blogname; ?> 由<a href="http://emlog.net">emlog</a>驱动.
			  </p>
		 </div>
		 <div class="bottom">
		   <ul>
		      <li><a href="http://list.qq.com/cgi-bin/qf_invite?id=631bd6e0451632fd39822a42fb9dc2876a517b8fc8ce2259">订阅本站</a></li>
			  <li><a href="<? echo BLOG_URL;?>rss.php">本站RSS</a></li>
			  <li><a href="<? echo BLOG_URL;?>sitemap.xml">sitemap</a></li>
			  <li><?php echo $footer_info; ?></li>
		   </ul>
		   <ul>
		      <li>Follow Me</li>
			  <li><a href="http://weibo.com/waterg">新浪微博</a></li>
			  <li><a href="http://www.lz-z.com">林栽植</a></li>
		   </ul>
		   <ul>
		      <li>Contact Me</li>
			  <li><a> i(at)aieii.com</a></li>
			  <li> </li>
			  <li><a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a></li>
		   </ul>
		   <ul class="office">
		      <img src="<?php echo TEMPLATE_URL; ?>images/office.jpg">
		   </ul>
		 </div>
		 <div class="clear"></div>
	</div><!-- end #footer -->

</div>
</div><!-- end #outmain -->
<div class="clear"></div>
</div><!-- end #wrapper -->
<?php
if ($type == 'blog') { echo <<<LOADSCRIPT

<script type="text/javascript">
    var wumiiParams = "&num=5&mode=2&pf=emlog";
</script>
<script type="text/javascript" id="wumiiRelatedItems" src="http://widget.wumii.com/ext/relatedItemsWidget"></script>
<a href="http://www.wumii.com/widget/relatedItems" style="border:0;">
    <img src="http://static.wumii.com/images/pixel.png" alt="无觅相关文章插件，快速提升流量" style="border:0;padding:0;margin:0;" />
</a>
LOADSCRIPT;
}
?>
<?php doAction('index_footer'); ?>
</body>
</html>