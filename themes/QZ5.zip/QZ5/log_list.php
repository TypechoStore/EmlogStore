<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php include View::getView('side');?>
	<div id="content">
<?php doAction('index_loglist_top'); ?>

	<div id="top">
	   <div class="name"><span class="yahei"><?php echo $bloginfo; ?></span><h2 class="yahei"><?php echo $blogname; ?></h2></div>
	   <div class="title"><span><a href="<?php echo BLOG_URL; ?>">首页</a></span>博客</div>
	</div>

<?php foreach($logs as $value): ?>
        <div class="post">
			<div class="meta">
			    <span class="cate"></span>
				<span class="time"><strong><?php echo gmdate('d', $value['date']); ?></strong><br/><?php echo gmdate('M', $value['date']); ?></span>
				<span class="comm"><a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?></a></span>
			</div>
			<div class="txt">
			    <h2 class="yahei"><?php topflg2($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
				<?php echo $value['log_description']; ?>
		    </div>
        </div>
<?php endforeach; ?>

	<ol class="page-navigator"><?php echo $page_url;?></ol>
    </div><!-- end #content-->
<?php include View::getView('footer');?>