<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php include View::getView('side');?>
<script type="text/javascript">
	function setTab03Syn ( i )
	{
		selectTab03Syn(i);
	}
	function selectTab03Syn ( i )
	{
		switch(i){
			case 1:
			document.getElementById("TabCon1").style.display="block";
			document.getElementById("TabCon2").style.display="none";
			document.getElementById("font1").style.color="#fff";
			document.getElementById("font2").style.color="#000000";
			break;
			case 2:
			document.getElementById("TabCon1").style.display="none";
			document.getElementById("TabCon2").style.display="block";
			document.getElementById("font1").style.color="#000000";
			document.getElementById("font2").style.color="#fff";
			break;
		}
	}
</script>

	<div id="content">

	<div id="top">
	   <div class="name"><h2 class="yahei"><?php topflg($top); ?><?php echo $log_title; ?></h2></div>
	   <div class="title"><span><a href="<? echo BLOG_URL;?>">首页</a></span><span><?php blog_sort($logid); ?></span><?php echo $log_title; ?>（<?php echo gmdate('Y年m月d日', $date); ?> ）</div>
	</div>

			<div class="page">
				<?php echo $log_content; ?>
				
				<p><?php blog_att($logid); ?></p>
<div class="wumii-hook">
    <input type="hidden" name="wurl" value="<?php echo Url::log($logid); ?>" />
    <input type="hidden" name="wtitle" value="<?php echo $log_title; ?>" />
</div>
<script>
    var wumiiSitePrefix = "<?php echo BLOG_URL; ?>";
</script>
				<p class="tags"><?php blog_tag($logid); ?></p>
		    </div>
<div class="commentwrap">
	<div id="bg" class="xixi1">
		<!--
		<div id="font1" class="tab1" onMouseOver="setTab03Syn(1);document.getElementById('bg').className='xixi1'">社交评论</div>
		-->
		<div id="font2" class="tab2" onMouseOver="setTab03Syn(2);document.getElementById('bg').className='xixi2'">本站评论</div>
	</div>
<div id="TabCon1">
<!-- PingLun.La Begin -->

<!-- PingLun.La End -->

</div>
<div id="TabCon2" style="display:none">
	<div id="comments">
	<h4 id="response" class="yahei"><? if($comnum>0){ echo  "已经有". $comnum."条评论  &raquo;"; }?><a name="respond"></a></h4>

	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
</div>
</div><!-- commentwrap end -->

    </div><!-- end #content-->

<?php include View::getView('footer');?>