<?php 
/*
Custom:page
Description:默认页面
南笙资源网授权模板联系QQ1973652308
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="index-container layui-clear">
	<div class="article_content layui-clear">
		<div class="left">
			<h3 class="article-title"><?php echo $log_title; ?></h3>
			<div class="article-bq layui-clear">
				<span class="bq-zz"><i class="iconfont icon-zz"></i><?php blog_author($author);?></span>
				<time><i class="iconfont icon-time"></i><?php echo date('Y-n-j H:i',$date);?></time>
				<b class="bq-wg"><i class="iconfont icon-fl"></i><?php blog_sort1($logid);?></b>
			</div>
			<div class="article-content"><?php echo $log_content;?></div>	
			<div class="mzsm">
				<p><strong>免责声明：</strong></p>
				<p>本站提供的资源，都来自网络，版权争议与本站无关，所有内容及软件的文章仅限用于学习和研究目的。不得将上述内容用于商业或者非法用途，否则，一切后果请用户自负，我们不保证内容的长久可用性，通过使用本站内容随之而来的风险与本站无关，您必须在下载后的24个小时之内，从您的电脑/手机中彻底删除上述内容。如果您喜欢该程序，请支持正版软件，购买注册，得到更好的正版服务。侵删请致信E-mail：<?php echo _g('email');?> </p>
			</div>
			<div class="article-pl">
				<div id="cyEmoji" role="cylabs" data-use="emoji"></div>
				<div class="title">
					评论列表
				</div>
				<div class="panel ribbon-comment">
				<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
				<ol class="comment-list">
				<?php blog_comments($comments,$params); ?>
				</ol>
				</div>
			</div>
		</div>
<div class="right">
	<div class="article-right">
		<div class="title">
			热门文章
		</div>
		<ul class="list">
<?php blog_listlog7();?>
		</ul>
	</div>
	<div class="article-right">
		<div class="title">
			随机推荐
		</div>
		<ul class="list">
<?php blog_randomlog();?>
		</ul>
	</div>
</div>
	</div>
</div>
<?php include View::getView('footer');?>