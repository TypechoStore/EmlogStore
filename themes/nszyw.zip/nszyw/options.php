<?php
/*
 * 模板设置
 * 南笙资源网授权模板联系QQ1973652308
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
	'slideid' => array(
		'type' => 'text',
		'name' => '首页轮播文章id',
		'default' => '1,2',
		'description' => '文章id必须用,间隔',
	),
	
	'slide' => array(
		'type' => 'text',
		'name' => '轮播自定义广告',
		'multi' => true,
		'default' => '<div class="layui-this"><a href="http://dmjacu399.kuaizhan.com/?code=KMDgLldA3QCd49"><img class="flash" src="https://qqylw.co/ad/1582973866076.jpg"></a></div>',
		
	),
			'gg2' => array(
		'type' => 'text',
		'name' => '首页左侧广告下方优惠券',
		'multi' => true,
		'default' => '<a href="/" class="noad" target="_blank">查找优惠券</a>
			<a href="/" class="mytg">加入QQ群</a>'
			),
	'gg0' => array(
		'type' => 'text',
		'name' => '首页导航下广告',
		'multi' => true,
		'default' => '<div><a href="https://www.xiaobiaoyl.cn" target="_blank"><img alt="南笙资源网" src="content/templates/nszyw/lib/img/ad1.gif" style="height: 80px; width: 100%;" /></a></div>',
	),
	
	'toplink' => array(
		'type' => 'text',
		'name' => '首页顶部菜单',
		'multi' => true,
		'default' => '<span><a href="https://wpa.qq.com/msgrd?v=3&uin=1573652308&site=qq&menu=yes" target="_blank">联系站长</a></span><span><a href="https://www.nsdaohang.com" target="_blank">南笙技术导航</a></span>',
	),
	'index-down' => array(
		'type' => 'text',
		'name' => '下载专区分类ID',
		'default' => '1',
		'description' => '用英文逗号隔开可同时指定多个分类',
	),
	'index-article' => array(
		'type' => 'text',
		'name' => '文章专区分类ID',
		'default' => '1',
		'description' => '用英文逗号隔开可同时指定多个分类',
	),
	'index-articler' => array(
		'type' => 'text',
		'name' => '首页热门排行右侧块分类ID',
		'default' => '1',
		'description' => '只填写一个ID，填多了报错',
	),
		'tags' => array(
		'type' => 'text',
		'name' => '关键词优化',
		'default' => '南笙资源网，南笙网，南笙',
		'description' => '用英文逗号隔开可',
	),
		'logo' => array(
		'type' => 'image',
		'name' => '上传LOGO图片',
		'values' => array(
			TEMPLATE_URL . 'lib/img/logo.png',
		),
		'description' => '默认尺寸为120X50像素透明PNG图片',
	),
	'logo1' => array(
		'type' => 'image',
		'name' => '上传LOGO图片',
		'values' => array(
			TEMPLATE_URL . 'lib/img/logo1.png',
		),
		'description' => '默认尺寸为120X50像素透明PNG图片',
	),
	
	'foot-url' => array(
		'type' => 'text',
		'name' => '页脚相关链接',
		'multi' => true,
		'default' => '<li><a href="/copyright.html" target="_blank" rel="nofollow">版权声明</a></li>
			<li><a href="https://wpa.qq.com/msgrd?v=3&uin=1573652308&site=qq&menu=yes" target="_blank" rel="nofollow">广告合作</a></li>
			<li><a href="/tg.html" target="_blank" rel="nofollow">我要投稿</a></li>
          	<li><a href="map.html" target="_blank" rel="nofollow">网站地图</a></li>',
	),
		'foot-tg' => array(
		'type' => 'text',
		'name' => '站长统计',
		'multi' => true,
		'default' => '',
	),
	'foot-copy' => array(
		'type' => 'text',
		'name' => '页脚文字说明',
		'multi' => true,
		'default' => '本站内容来源于互联网，如果有侵权内容、不妥之处，请第一时间联系我们删除。敬请谅解! E-mail：1573652308@qq.com',
	),
	'email' => array(
		'type' => 'text',
		'name' => '投稿反馈邮箱',
		'default' => '1573652308@qq.com',
		'description' => '填写邮箱即可',
	),
);