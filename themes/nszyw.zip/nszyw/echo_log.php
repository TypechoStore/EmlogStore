<?php 
/**
 * 阅读文章页面
 * 南笙资源网授权模板联系QQ1973652308
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="index-container layui-clear">
	<div class="article_content layui-clear">
		<div class="left">
			<h3 class="article-title"><?php echo $log_title; ?></h3>
			<div class="article-bq layui-clear">
				<span class="bq-zz"><i class="iconfont icon-zz"></i><?php blog_author($author);?></span>
				<time><i class="iconfont icon-time"></i><?php echo gmdate('Y-n-j H:i',$date);?></time>
				<b class="bq-wg"><i class="iconfont icon-fl"></i><?php blog_sort1($logid);?></b>
			</div>
			<div class="article-content"><?php echo $log_content;?></div>
			<?php if(!empty($down_link1)):?>
			<div class="title" id="dwon">
					资源下载
				</div>
			<ul class="list_down">
				<a href="<?php echo $down_link1;?>" class="sbtn" title="点击下载" target="_blank" rel="nofollow"><i class="iconfont icon-xiazai"></i>点击下载</a>
				
					<?php if(!empty($down_link2)):?><a href="<?php echo $down_link2;?>" class="sbtn" title="备用下载" target="_blank" rel="nofollow"><i class="iconfont icon-xiazai"></i>备用下载</a>
				<?php endif;?><?php if(!empty($down_link3)):?><a href="<?php echo $down_link3
				;?>" class="sbtn" title="备用下载" target="_blank" rel="nofollow"><i class="iconfont icon-xiazai"></i>备用下载</a>
				<?php endif;?>	</ul>	<?php endif;?>
				<div class="article-end">
				<div class="tag">
					<span>标签：</span> <?php if(!empty(blog_tags($logid))){echo blog_tags($logid);}else{}?>
				</div>
			</div>
			<?php doAction('down_log',$logid); ?>
							
			<div class="fenxiang">
                <div class="bdsharebuttonbox bdshare-button-style1-24">
                    <div class="title">
					资源分享
				</div>
                <a href="http://connect.qq.com/widget/shareqq/index.html?url=<?php echo Url::log($logid);?>&title=<?php echo $log_title;?>&pics=<?php echo _g('logo');?>" class="bds_sqq" data-cmd="qq" target="_blank" title="分享到QQ空间"></a>
                <a href="http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=<?php echo Url::log($logid);?>&title=<?php echo $log_title;?>&pics=<?php echo _g('logo');?>" class="bds_qzone" data-cmd="qzone" target="_blank" title="分享到QQ空间"></a>
                <a href="https://cli.im/api/qrcode/code?text=<?php echo Url::log($logid);?>&mhid=sELPDFnok80gPHovKdI" class="bds_weixin" data-cmd="weixin" target="_blank" title="分享到微信"></a>
                <a href="https://service.weibo.com/share/share.php?url=<?php echo Url::log($logid);?>&title=<?php echo $log_title;?>&pics=<?php echo _g('logo');?>" class="bds_tsina" data-cmd="tsina" target="_blank" title="分享到新浪微博"></a>
						</div>
					</div><?php doAction('log_related', $logData); ?>
			<div class="article-pl">
				<div class="title">
					评论列表
				</div>
				<div class="panel ribbon-comment">
				<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
				<ol class="comment-list">
				<?php blog_comments($comments,$params); ?>
				</ol>
				</div>
			</div>
		</div>
<div class="right detail-right">


	<div class="article-right">
		<div class="title">
			热门文章
		</div>
		<ul class="list">
<?php blog_listlog7();?>
		</ul>
	</div>
	<div class="article-right">
		<div class="title">
			随机推荐
		</div>
		<ul class="list">
<?php blog_randomlog();?>
		</ul>
	</div>
</div>
	</div>
</div>
<?php include View::getView('footer');?>
<?php doAction('ad_jump_echo',$logid); ?>