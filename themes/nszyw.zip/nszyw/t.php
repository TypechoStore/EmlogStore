<?php 
/**
 * 微语
 *南笙资源网授权模板联系QQ1973652308
 */
header('HTTP/1.1 404 Not Found');
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>