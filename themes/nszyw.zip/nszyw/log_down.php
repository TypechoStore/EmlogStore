<?php
/**
 * 南笙资源网授权模板联系QQ1973652308
 */
if (!defined('EMLOG_ROOT')) {exit('error!');}
if($pageurl == Url::logPage()){include View::getView('index');exit;}
?>
<div class="index-container layui-clear">
	<div class="list-container fl">
		<div class="current_nav">当前位置：<a href='<?php echo BLOG_URL;?>'>首页</a> > <?php if($params[1]=='sort'){?><?php echo '<a href="'.Url::sort($sortid).'">'.$sortName.'</a>';?><?php }elseif ($params[1]=='tag'){?>包含标签 <?php echo htmlspecialchars(urldecode($params[2]));?> 的所有文章<?php }elseif($params[1]=='author'){?>作者 <?php echo blog_author($author);?> 的所有文章<?php }elseif($params[1]=='keyword'){?>搜索 <?php echo htmlspecialchars(urldecode($params[2]));?> 的结果<?php }elseif($params[1]=='record'){?>正在查看 “<?php echo $params[2];?>” 年月的文章<?php }?></div>
		<div>
		<ul class="list-soft">
<?php
if (!empty($logs)):
		if ($sort['pid'] != 0 || empty($sort['children'])) {
			$sqlSegment = "and sortid=$sortid";
		} else {
			$sortids = array_merge(array($sortid), $sort['children']);
			$sqlSegment = "and sortid in (" . implode(',', $sortids) . ")";
		}
		$sqlSegment .=  " order by sortop desc, date desc";
foreach($Log_Model->getLogsForHome($sqlSegment,$page,20) as $value):
      if(!empty($value['thumbs'])){
      $value['img']=$value['thumbs'];
  }else{
	$search_pattern = '%<img[^>]*?src=[\'\"]((?:(?!\/admin\/|>).)+?)[\'\"][^>]*?>%s';
	preg_match($search_pattern, $value['content'], $img);
	$value['img'] = isset($img[1])?$img[1]:TEMPLATE_URL.'lib/img/default.jpg';
  }

?>
			<li class="layui-clear">
				<a href="<?php echo $value['log_url'];?>" target="_blank" class="list-img">
					<img src="<?php echo $value['img'];?>" alt="<?php echo $value['log_title'];?>"/>
				</a>
				<div class="list-info">
					<a class="soft-title" href="<?php echo $value['log_url'];?>" target="_blank"><?php echo $value['log_title'];?></a>
					<div class="list-ca">时间：<?php echo date('Y-m-d',$value['date']);?></div>
					<div class="list-btn layui-clear">
						<a href="<?php echo $value['log_url'];?>" target="_blank">立即查看</a>
					</div>
				</div>
			</li>
<?php endforeach;?>
<?php else:?>
			<i class="wnr_ico"></i><span class="wnr_t">暂时没有找到您想要的内容！</span> <a href="/" class="wnr_home">回到首页</a>
<?php endif;?>
		</ul>
		<div id="page">
			<div class="layui-box layui-laypage layui-laypage-default">
			<?php echo blog_fy($lognum,20,$page,$pageurl);?>
			</div>
		</div>
	</div>
</div>
<div class="right">
	<div class="list-right">
		<div class="title">本周热门</div>
		<ul class="list">
<?php blog_listlog7();?>
		</ul>
	</div>
	<div class="list-right">
		<div class="title">随机推荐</div>
		<ul class="list">
<?php blog_randomlog();?>
		</ul>
	</div>
</div>
</div>
<?php include View::getView('footer');?>