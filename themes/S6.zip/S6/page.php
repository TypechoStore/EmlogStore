<?php 
/**
 * 	定制页面
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');} 
?>
<div class="main">
	<div class="echotitle"><?php echo $log_title; ?></div>
    <div class="echocontent" id="page"><?php echo $log_content; ?></div>
</div>
	<?php leave_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<?php leave_comments($comments); ?>
<?php
 include View::getView('footer');
?>