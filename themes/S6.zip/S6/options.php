<?php
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('Load failed.');
$options = array(
	'front_debug' => array(
		'name' => '引导页调试',
		'type' => 'radio',
		'values' => array(
			'open' => '开',
			'close' => '关'
		),
		'default' => 'close',
		'description' => '打开此项会使引导页一直出现，更改此项设置需重启浏览器才能生效'
	),
	'front' => array(
		'type' => 'radio',
		'name' => '引导页开关',
		'values' => array(
			'open' => '开',
			'close' => '关'
		),
		'default' => 'open',
	),
	'memory_color' => array(
		'name' => '引导页文字颜色',
		'type' => 'text',
		'default' => '#fff',
		'description' => '默认值为#ffffff',
	),
	'memory_scolor' => array(
	'name' => '引导页按钮颜色',
	'type' => 'text',
	'default' => '#13B5B1',
	'description' => '默认值为#13B5B1',
	),
	'memory_text' => array(
		'name' => '引导页纪念日描述文字',
		'type' => 'text',
		'default' => '倒计时',
	),
	'memory_date' => array(
		'name' => '引导页纪念日日期',
		'type' => 'text',
		'default' => '2013-11-05',
	),
	'words' => array(
		'name' => '引导页随机文字',
		'type' => 'text',
		'multi' => 'true',
		'description' => '可以输入任意行，每句以两个半角空格为结束',
	),
	'avatar' => array(
		'name' => '文字头像开关',
		'type' => 'radio',
		'values' => array(
			'open' => '开',
			'close' => '关',
		),
		'default' => 'open',
		'description' => '此设置项指的是当评论者未填写邮箱时的头像是否为其昵称的首个字符',
	),
	'global_fcolor' => array(
		'name' => '全局主题色',
		'type' => 'text',
		'default' => '#13B5B1',
		'description' => '默认值为#13B5B1',
	),
	'global_scolor' => array(
		'name' => '全局副主题色',
		'type' => 'text',
		'default' => '#00C193',
		'description' => '默认值为#00C193',
	),
	'background_color' => array(
		'name' => '背景颜色',
		'type' => 'text',
		'default' => '#ffffff',
		'description' => '默认值为#ffffff',
	),
	'panel_color' => array(
		'name' => '主面板文字颜色',
		'type' => 'text',
		'default' => '#ffffff',
		'description' => '默认值为#ffffff',
	),
	'text_fcolor' => array(
		'name' => '正文主题色',
		'type' => 'text',
		'default' => '#363636',
		'description' => '默认值为#363636',
	),
	'text_scolor' => array(
		'name' => '正文副主题色',
		'type' => 'text',
		'default' => '#666666',
		'description' => '默认值为#666666'
	),
);
?>