<?php
/**
 * 	主题色
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');} 
?>
<style>
/* 主题色 */
.panel, .echomonth, .ttime, .reply-ok input:hover, .ground, .echodate{
	background:<?php echo _g('global_fcolor'); ?>;
}
::-webkit-scrollbar-thumb{
	background:<?php echo _g('global_fcolor'); ?>;
}
.logtitle a, .echotitle, .echocontent a, .comment-header, #reply input, .reply-ok input, .comment-content a{
	color:<?php echo _g('global_fcolor'); ?>;
}
.block, .desc img, .echocontent img, #reply input, textarea, textarea:focus, #reply input:focus, .reply-ok input, .comment-content, .tcontent{
	border-color:<?php echo _g('global_fcolor'); ?>;
}
/* 副主题色*/
::-webkit-scrollbar-thumb:hover{
	background:<?php echo _g('global_scolor'); ?>;
}
.copy a, .logtitle a:hover{
	color:<?php echo _g('global_scolor'); ?>;
}
/* 背景色 */
.reply-ok input, body{
	background:<?php echo _g('background_color'); ?>;
}
::-webkit-scrollbar-track{
	background:<?php echo _g('background_color'); ?>
	
}
/* 主面版文字颜色 */
.panelname, .panelname a, .panelinfo, .panelnavi div, .prepage, .nextpage, .top, .pre, .next, a .prepage, a .nextpage, a .pre, a .next, .top, .echoday, .echoyear, .ttime, .reply-ok input:hover, .comment-avatar, .link{
	color:<?php echo _g('panel_color'); ?>;
}
.panelavatar, .panelnavi, .panelnavi div{
	border-color:<?php echo _g('background_color'); ?>;
}
/* 正文颜色 */
.desc, .echocontent, #reply, .reply-label, #reply input, textarea, .logdate, .tcontent{
	color:<?php echo _g('text_fcolor'); ?>;
}
/* 正文副颜色 */
.comment-cont-c, .comment-poster, .copy{
	color:<?php echo _g('text_scolor'); ?>;
}
</style>