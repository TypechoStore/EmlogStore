<?php 
/**
 * 	日志输出
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');} 
?>
<div class="main">
	<div class="echoinfo">
		<div class="echodate">
    		<div class="echoday"><?php echo gmdate('j', $date); ?></div>
        <div class="echoyear"><?php echo gmdate('y年n月', $date); ?></div>
    	</div>
    	<div class="echotitle"><?php echo $log_title; ?></div>
    </div>
    <div class="echocontent"><?php echo $log_content; ?></div>
    <?php neighbor_log($neighborLog); ?>
</div>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<?php blog_comments($comments); ?>
<?php
 include View::getView('footer');
?>