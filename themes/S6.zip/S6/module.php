<?php 
/**
 * 侧边栏组件、页面模块
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');} 
?>
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach($navi_cache as $value):
        if ($value['pid'] != 0) {
            continue;
        }
		if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):
			?>
			<a href="<?php echo BLOG_URL; ?>admin/"><div class="common">管理</div></a>
			<a href="<?php echo BLOG_URL; ?>admin/?action=logout"><div class="common">退出</div></a>
			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
        $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'current' : 'common';
		?>
        <a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><div class="<?php echo $current_tab;?>"><?php echo $value['naviname']; ?></div></a>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog && $nextLog):?>
    <a href="<?php echo Url::log($prevLog['gid']) ?>" title="<?php echo $prevLog['title'];?>"><div class="pre">上一篇</div></a><a href="<?php echo Url::log($nextLog['gid']) ?>" title="<?php echo $nextLog['title'];?>"><div class="next">下一篇</div></a>
    <?php elseif($prevLog): ?>
    <a href="<?php echo Url::log($prevLog['gid']) ?>" title="<?php echo $prevLog['title'];?>"><div class="pre">上一篇</div></a><div class="next">下一篇</div>
    <?php else: ?>
    <a href="<?php echo Url::log($nextLog['gid']) ?>" title="<?php echo $nextLog['title'];?>"><div class="next">下一篇</div></a><div class="pre">上一篇</div>
    <?php endif; ?>
<?php }?>
<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>
<?php
//纪念日
function loveDay($loveDate){
	$loveTime = strtotime($loveDate);
	$loveDays = (time()-$loveTime)/60/60/24;
	$lDay = abs(floor($loveDays)+1);
	return $lDay;
}
?>
<?php
//blog：评论列表
function blog_comments($comments){
    extract($comments);
    if($commentStacks):?>
    <div class="comment">
		<div class="comment-header">评论</div>
    <div class="frame">
	<?php
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
    <div class="comment-content">
    	<?php if($comment['mail'] == "" && _g('avatar') == 'open'): ?>
      <div class="comment-avatar" style="background:<?php echo randavatar(); ?>"><?php echo subStrings(strip_tags($comment['poster']),0,1); ?></div>
      <?php else: ?>
    	<div class="comment-avatar" style="background:url(<?php echo getDsavatar($comment['mail']); ?>) no-repeat;"></div>
      <?php endif; ?>
      <div class="comment-cont">
				<div class="comment-poster"><?php echo $comment['poster']; ?></div>
				<div class="comment-cont-c"><?php echo $comment['content']; ?></div>
      </div>
    </div>
    <?php blog_comments_children($comments, $comment['children']); ?>
	<?php endforeach; ?>
    </div>
    </div>
    <?php endif; ?>
<?php }?>
<?php
//blog：留言列表
function leave_comments($comments){
    extract($comments);
    if($commentStacks):?>
    <div class="comment">
		<div class="comment-header">留言簿</div>
    <div class="frame">
	<?php
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
    <div class="comment-content">
    	<?php if($comment['mail'] == "" && _g('avatar') == 'open'): ?>
      <div class="comment-avatar" style="background:<?php echo randavatar(); ?>"><?php echo subStrings(strip_tags($comment['poster']),0,1); ?></div>
      <?php else: ?>
    	<div class="comment-avatar" style="background:url(<?php echo getDsavatar($comment['mail']); ?>) no-repeat;"></div>
      <?php endif; ?>
      <div class="comment-cont">
				<div class="comment-poster"><?php echo $comment['poster']; ?></div>
				<div class="comment-cont-c"><?php echo $comment['content']; ?></div>
      </div>
    </div>
    <?php blog_comments_children($comments, $comment['children']); ?>
	<?php endforeach; ?>
    </div>
    </div>
    <?php endif; ?>
<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<div class="comment-content">
    <?php if($comment['mail'] == "" && _g('avatar') == 'open'): ?>
    <div class="comment-avatar" style="background:<?php echo randavatar(); ?>"><?php echo subStrings(strip_tags($comment['poster']),0,1); ?></div>
    <?php else: ?>
    <div class="comment-avatar" style="background:url(<?php echo getDsavatar($comment['mail']); ?>) no-repeat;"></div>
    <?php endif; ?>
    <div class="comment-cont">
			<div class="comment-poster"><?php echo $comment['poster']; ?></div>
			<div class="comment-cont-c"><?php echo $comment['content']; ?></div>
    </div>
  </div>
		<?php blog_comments_children($comments, $comment['children']);?>
	<?php endforeach; ?>
<?php }?>
<?php
//发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
    <div class="reply">
	<div class="comment-post" id="comment-post">
		<div class="comment-header">写评论</div>
		<form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
			<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
      <div class="reply-cont"><textarea name="comment" id="comment"></textarea></div>
      <?php if(ROLE == ROLE_VISITOR): ?>
			<div class="reply-nick" id="reply">昵称：<input type="text" name="comname" value="<?php echo $ckname; ?>" /> 主页：<input type="text" name="comurl" value="<?php echo $ckurl; ?>" /> 邮箱：<input type="text" name="commail" value="<?php echo $ckmail; ?>" /></div>
      <?php endif; ?>
			<div class="reply-ok"><input type="submit" id="comment_submit" value="发布" /></div>
		</form>
	</div></div>
	<?php endif; ?>
<?php } ?>
<?php
//发表留言表单
function leave_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
    <div class="reply">
	<div class="comment-post" id="comment-post">
		<div class="comment-header">给我留言</div>
		<form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
			<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
      <div class="reply-cont"><textarea name="comment" id="comment"></textarea></div>
      <?php if(ROLE == ROLE_VISITOR): ?>
			<div class="reply-nick" id="reply">昵称：<input type="text" name="comname" value="<?php echo $ckname; ?>" /> 主页：<input type="text" name="comurl" value="<?php echo $ckurl; ?>" /> 邮箱：<input type="text" name="commail" value="<?php echo $ckmail; ?>" /></div>
      <?php endif; ?>
			<div class="reply-ok"><input type="submit" id="comment_submit" value="发布" /></div>
		</form>
	</div></div>
	<?php endif; ?>
<?php } ?>
<?php
//widget：链接
function widget_link(){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
	?>
	<?php foreach($link_cache as $value): ?>
<a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><div class="link" style="background:<?php echo randavatar(); ?>"><?php echo $value['link']; ?></div></a>
	<?php endforeach; ?>
<?php }?>
<?php
//随机颜色
function randavatar(){
	$bgcolorArray = array('#53A9E6','#ACB8C2','#91C66A','#FF9626','#00C193','#967DB3','#F87663');
	$bgcolorIndex = rand(0, count($bgcolorArray) - 1);
	return $bgcolorArray[$bgcolorIndex];
}
?>
<?php
/**
 * 分页函数
 *
 * @param int $count 条目总数
 * @param int $perlogs 每页显示条数目
 * @param int $page 当前页码
 * @param string $url 页码的地址
 */
function pagination2($count, $perlogs, $page, $url) {
	$pnums = @ceil($count / $perlogs);
	$i = $page+1;
	$j = $page-1;
	if($pnums != 1){
		if($page == 1){
			return "<a href='".$url.$i."' ><div class='nextpage'>下一页</div></a><div class='prepage'>上一页</div>";
		}elseif($page == $pnums){
			return "<a href='".$url.$j."' ><div class='prepage'>上一页</div></a><div class='nextpage'>下一页</div>";
		}else{
			return "<a href='".$url.$i."' ><div class='nextpage'>下一页</div></a><a href='".$url.$j."' ><div class='prepage'>上一页</div></a>";
		}
	}
}
$tpage = pagination2($twnum, Option::get('index_twnum'), $page, BLOG_URL.'talk/?page=');
$logpage = pagination2($lognum, $index_lognum, $page, $pageurl);
?>
<?php
/**
* 多说头像
*/
function getDsavatar($email, $s = 55, $d='mm', $g = 'g') {
	$hash = md5($email);
	$avatar = "http://gravatar.duoshuo.com/avatar/$hash?s=$s&d=$d&r=$g";
	return $avatar;
}
?>
<?php
/**
* 截取UTF-8字符串（仅适用于头像的一个字符）
*/
function subStrings($strings, $start, $length) {
	if (function_exists('mb_substr') && function_exists('mb_strlen')) {
		$sub_str = mb_substr($strings, $start, $length, 'utf8');
		return $sub_str;
	}
}
?>

