<?php 
/**
 * 日志列表
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');} 
?>
<div class="main" id="loglist">
	<?php
	foreach($logs as $value):
		?>
        <div class="block">
        	<div class="logtitle"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a><span class="logdate"><?php echo gmdate('y年n月j日', $value['date']); ?></span></div>
          <div class="desc"><?php echo $value['log_description']; ?></div>
        </div>
        <?php endforeach; ?>
        <?php echo $logpage;?>
</div>
<?php
 include View::getView('footer');
?>