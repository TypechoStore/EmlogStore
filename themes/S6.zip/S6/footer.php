<?php 
/**
 * 	底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');} 
?>
<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js" type="text/javascript"></script>
<script>
$(document).ready(function(){
$('.top').click(function(){
$('body,html').animate({scrollTop:0},1000);});
});
</script>
	<div class="top">回到顶部</div>
	<div class="copy">
    	Powered by <a href="http://www.emlog.net">Emlog</a>. Written by <a href="http://sinkery.com">Sinkery</a>.<?php if($icp != ''): ?> <a href="http://www.miibeian.gov.cn/publish/query/indexFirst.action" target="_blank"><?php echo $icp; ?></a><?php endif; ?><br /><?php echo $footer_info; ?>
      <?php doAction('index_footer'); ?>
	</div>
</div>
</body>
</html>