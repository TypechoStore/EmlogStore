﻿<?php
/*
Template Name:S6
Description:绿色小清新
Author:Sinkery
Version:2.8
Author Url:http://sinkery.com
Sidebar Amount:0
*/
if(!defined('EMLOG_ROOT')) {exit('Load failed.');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<meta content="width=device-width, initial-scale=0.4, maximum-scale=0.4, user-scalable=0;" name="viewport" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<link media="screen and (max-width:1080px)" rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>min.css" />
<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php 
	doAction('index_head');
	include View::getView('color');
	$user_cache = $CACHE->readCache('user');
?>
</head>
<body>
<?php
if(_g('front') == 'open'){
	if(!isset($_COOKIE[DB_PREFIX.'s6'])){
		include View::getView('f');
		if(_g('front_debug') == 'close'):
		setcookie(DB_PREFIX.'s6',1);
		else:
		setcookie(DB_PREFIX.'s6',1,1);
		endif;
	};
};
?>
<div class="ground"></div>
<div class="wrap">
	<div class="panel">
  	<div class="panelavatar" style="background:url(<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>) no-repeat; background-size:100px 100px;"></div>
    <div class="panelname"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname;?></a></div>
    <div class="panelinfo"><?php echo $bloginfo; ?></div>
    <div class="panelnavi"><?php echo blog_navi(); ?></div>
  </div>
  