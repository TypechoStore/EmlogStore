<?php 
/**
 * 	说说
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');} 
?>
<div class="main">
	<div class="frame" id="time">
	<?php foreach($tws as $val): $tid = (int)$val['id']; ?>
  	<div class="ttime"><?php echo $val['date']; ?></div>
    <div class="tcontent"><?php echo $val['t']; ?></div>
  <?php endforeach;?>
  </div>
	<?php echo $tpage;?>
</div>
<?php
 include View::getView('footer');
?>