<?php
/**
 * 	引导页
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');} 
//随机格言
$maxArray = explode('  ',_g('words'));
$maxIndex = rand(0, count($maxArray) - 1);
?>
<style>
.fback{
	position:fixed;
	width:100%;
	height:100%;
	background:url(<?php echo TEMPLATE_URL; ?>img/bg.jpg) no-repeat center center;
	left:0;
	top:0;
	z-index:888;
	overflow:hidden;
}
.fback2{
	position:fixed;
	width:100%;
	height:100%;
	background:<?php echo _g('memory_scolor'); ?>;
	left:0;
	top:0;
	z-index:888;
	overflow:hidden;
}
.fwrap{
	position:fixed;
	width:100%;
	height:400px;
	top:50%;
	margin:-200px 0 0 0;
	z-index:999;
	text-align:center;
}
.ff{
	font-family:"Microsoft Jhenghei Light","微软雅黑 Light","微软雅黑";
	font-size:100px;
	color:<?php echo _g('memory_color'); ?>;
	height:125px;
}
.fs{
	margin-top:30px;
	font-size:20px;
	color:<?php echo _g('memory_color'); ?>;
}
.ft{
	margin-top:150px;
	color:<?php echo _g('memory_color'); ?>;
	display:inline-block;
	padding:20px 100px;
	border:1px solid <?php echo _g('memory_color'); ?>;
	cursor:pointer;
	transition:background 0.4s,color 0.4s, border 0.4s;
	-webkit-transition:background 0.4s,color 0.4s, border 0.4s;
	-moz-transition:background 0.4s,color 0.4s, border 0.4s;
}
.ft:hover{
	background:<?php echo _g('memory_scolor'); ?>;
	border:1px solid <?php echo _g('memory_scolor'); ?>;
	color:<?php echo _g('memory_color'); ?>;
	transition:background 0.4s,color 0.4s, border 0.4s;
	-webkit-transition:background 0.4s,color 0.4s, border 0.4s;
	-moz-transition:background 0.4s,color 0.4s, border 0.4s;
}
</style>
<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js" type="text/javascript"></script>
<script>
$(document).ready(function(){
$('.ft').click(function(){
	if($(window).width() < 1000){
		$('.fback2, .fwrap').fadeOut(400);
	}else{
		$('.fback, .fwrap').animate({top:"-100%"},800);
	};
});
});
if($(window).width() < 1000){
	document.write("<div class='fback2'></div>");
}else{
	document.write("<div class='fback'></div>");
}
</script>
<div class="fwrap">
	<div class="ff"><?php echo _g('memory_text'); ?><?php if(_g('memory_date') != '') echo loveDay(_g('memory_date')).'天'; ?></div>
  <div class="fs"><?php echo $maxArray[$maxIndex]; ?></div>
  <div class="ft">进入博客</div>
</div>
