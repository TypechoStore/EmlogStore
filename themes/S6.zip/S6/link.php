<?php 
/**
 * 	链接
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');} 
?>
<div class="main">
	<div class="echotitle"><?php echo $log_title; ?></div>
  <?php echo widget_link(); ?>
  <div style="clear:both;"></div>
</div>
<?php
 include View::getView('footer');
?>