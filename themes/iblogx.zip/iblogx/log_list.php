<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
	<?php doAction('index_loglist_top'); ?>
	<?php foreach($logs as $value): ?>
		<div class="cbx post">
			<h3>
					<?php blog_sort_4_new($value['logid']); ?> 
				</h3>
			<h2 class="post_title">
				<?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>" rel="bookmark"><?php echo $value['log_title']; ?></a>
			</h2>
			
		<div class="postmeta">
			<ul>
				<i class="meta-tags">
					<?php blog_tag($value['logid']); ?>
				</i>
				<td class="1">
					作者:<?php blog_author($value['author']); ?>
				</td>
				<i class="meta-date">
					发布于:<?php echo gmdate('Y-n-j', $value['date']); ?>
				</i>
				<i class="meta-views">
					<?php echo $value['views']; ?><B> views</B>
				</i>
				<td class="meta-comments">
					<a href="<?php echo $value['log_url']; ?>#comments"
						title="<?php echo $value['log_title']; ?> 上的评论"><?php echo $value['comnum']; ?></a>
				</td>
				
			</ul>
			<div class="clear"></div>
		</div>
		<div class="post-content">
			<?php echo $value['log_description']; ?><a href="<?php echo $value['log_url']; ?>" class="rea0dmore rea0dmorea">Continue Read.. </a>
		</div>
		
	</div>
	<?php endforeach; ?>
	<div class="pagenavi pnb">
		<?php echo $page_url;?>
	</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>