<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>哎~~~</title>
<style>
body{position:absolute;top:0;left:0;bottom:0;right:0;display:table;width:100%;height:100%;background:#212121 url(http://d3kpc4gyzr96f9.cloudfront.net/assets/bogartHD-6249e9d024335446ba8ed8327bf83012.gif) center;background-size:cover}
h1{margin:100px auto;width:900px;color:#fff;}
</style>
</head>
<body>
<h1>哎~~~<br><span>好惆怅有木有？</span></h1>
</body>
</html>