<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div style="clear:both;"></div>
<div id="footer_area">
<div id="footer_area_content">
<div class="box"><h3>最近发布</h3><div class="box_content"><ul><ol>
				<?php
				sideBlogList("new" , 8)
				?>
			</ul></ol></div></div>
<div class="box"><h3>最热文章</h3><div class="box_content"><ul><ol>
				<?php
				sideBlogList("view" , 8)
				?>
			</ul></ol></div></div>
<div class="box"><h3>随机文章</h3><div class="box_content"><ul><ol>
				<?php
				sideBlogList("rand" , 8)
				?>
			</ul></ol></div></div>
<div class="box"><h3>关于ASIM</h3><div class="box_content"><p>A concept,attitude,Aspect network Abstract blog.asim'log，My world！</p>
			<p>This is a network Abstract blog will excerpt some of the technology,ideas, concept, I hope you can gain something here!</p></div></div>
</div>
<div id="footer">
	<div class="mbox">
		<p>
			Copyright &copy;2014 <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>
		
			Based on
			<a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>
			& <a href="http://www.asooe.com/" target="_blank">iBlog X</a>.
			<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
			hosted on
	  <a href="https://portal.qiniu.com/signup?code=3lf1v930sy3iq" rel="nofollow external" target="_blank">QINIU</a>. <a href="<?php echo BLOG_URL; ?>sitemap.xml" title="网站地图" target="_blank">Sitemap</a>
			
		</p>
		
	</div>
<?php doAction('index_footer'); ?>
</div>

<script src="<?php echo TEMPLATE_URL; ?>script/jquery.lavalamp-1.3.4.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>script/theme_script.js" type="text/javascript"></script>

<!--[if IE 6]>
<script src="http://letskillie6.googlecode.com/svn/trunk/letskillie6.zh_CN.pack.js">
</script>
<![endif]-->
</body>
</html>