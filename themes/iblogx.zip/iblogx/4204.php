<?php 
/*
* 自定义404页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>404 - 对不起，您查找的页面不存在！</title>
<link rel="stylesheet" type="text/css" href="./404 - 对不起，您查找的页面不存在！_files/main.css">
<!--[if lt IE 9]>
  <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<link type="text/css" rel="stylesheet" href="chrome-extension://cpngackimfmofbokmjmljamhdncknpmg/style.css"><script type="text/javascript" charset="utf-8" src="chrome-extension://cpngackimfmofbokmjmljamhdncknpmg/js/page_context.js"></script></head>
<body screen_capture_injected="true">
<div id="wrapper"><a class="logo" href="http://www.wangshizhao.cn/"></a>
  <div id="main">
    <header id="header">
      <h1><span class="icon">!</span>404<span class="sub">page not found</span></h1>
    </header>
    <div id="content">
      <h2>您打开的这个的页面不存在！</h2>
      <p>当您看到这个页面,表示您的访问出错,这个错误是您打开的页面不存在,请确认您输入的地址是正确的,如果是在本站点击后出现这个页面,请联系管理员进行处理!</p>
	   <p>联系我:
			<a href="http://wpa.qq.com/msgrd?v=3&uin=938671819&site=qq&menu=yes" title="QQ交谈" target="_blank">
			<img src="./404 - 对不起，您查找的页面不存在！_files/qq.png">
		</a>
		<a href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=DnlvYGl9Zmd0Zm9hTnlvYGl9Zmd0Zm9hIG1g" title="给我写信" target="_blank">
			<img src="./404 - 对不起，您查找的页面不存在！_files/mail.png">
		</a>
		<a href="http://weibo.com/alevn" title="进入新浪微博" target="_blank">
			<img src="./404 - 对不起，您查找的页面不存在！_files/txweb.png">
		</a>
	   </p>
      <div class="utilities">
       
        <a class="button right" href="javascript:history.back(-1);" onclick="javascript:history.go(-1);">返回...</a><a class="button right" href="http://www.wangshizhao.cn/">返回首页</a>
        <div class="clear"></div>
      </div>
    </div>
   
  </div>
</div>
</body></html>