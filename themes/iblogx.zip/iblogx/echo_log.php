<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content" class="single">
	
	<div class="cbx post">
	<div class="fullbox_header"></div>	
	<div class="breadcrumb">
		<a href="<?php echo BLOG_URL; ?>" title="返回博客主页">首页</a>
		&nbsp;&raquo;&nbsp;
		<?php blog_sort_4_new($logid); ?>
		正文
	</div>	
		
		<h2>
			<?php echo $log_title; ?>
		</h2>
		<div class="postmeta">
			<ul>
				<li class="meta-date">
					<?php echo gmdate('Y-n-j G:i', $date); ?>
				</li>
				<li class="meta-cat">
					<?php blog_sort($logid); ?>
				</li>
				<li class="meta-views">
					<?php echo $views; ?> views
				</li>
				<li class="meta-comments">
					<a href="#comments"
						title="<?php echo $log_title; ?>上的评论"><?php echo $comnum; ?> 条评论</a>
				</li>
				<li class="meta-tags">
					<?php blog_tag($logid); ?>
				</li>
			</ul>
			<div class="clear"></div>
		</div>
		<div class="post-content">
			<div class="post-content-text">
				<?php echo $log_content; ?>	
			</div>
			
<div class="share">
      <div id="ckepop">
        <span class="jiathis_txt"></span>
        <a class="jiathis_button_tsina">新浪微博</a>
        <a class="jiathis_button_qzone">QQ空间</a>
        
        <a class="jiathis_button_renren">人人网</a>
        <a class="jiathis_button_tqq">腾讯微博</a>
        <a class="jiathis_button_hi">百度空间</a>
        <a class="jiathis_button_t163">网易微博</a>
        <a class="jiathis_button_gmail">Gmail邮箱</a>
		
      </div>
      <script type="text/javascript" src="http://v2.jiathis.com/code/jia.js?uid=1528361" charset="utf-8"></script>
    </div>
   <div class="bq"><strong>声明:</strong> 本文采用 <a style="color:#2521b1" href="http://creativecommons.org/licenses/by-nc-sa/3.0/" rel="nofollow external"><abbr title="署名-非商业性使用-相同方式共享">BY-NC-SA</abbr></a> 协议授权,转载请注明转自:<a style="color:#2521b1" href="<?php echo $log_url; ?>"><?php echo $log_title; ?></a></div>
   
   
    <div class="related-log">
      <h4>你可能会喜欢的内容：</h4>
      <ul><?php related_logs($sortid,$logid);?></ul>
    </div>			
			
			<?php doAction('log_related', $logData); ?>
			<div class="clear"></div>
		<div id="prext" class="breadcrumb">
		<?php neighbor_log($neighborLog); ?>
	</div>
		</div>
	</div>
	
	<div id="comments">
		<?php blog_comments($comments); ?>
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>
