<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="sidebar">
	<div id="t_box" class="cbx">
	<div id="welcome">
		<?php
			global $CACHE; 
			$newtws_cache = $CACHE->readCache('newtw');
			$istwitter = Option::get('istwitter');
		?>
		<?php foreach($newtws_cache as $value): ?>
		<li>
			<a href="<?php echo BLOG_URL . 't/'; ?>"><?php echo substr($value['t'],0,100); ?></a>
		</li>
		<?php endforeach; ?>
	</div>
	<script>
		var c, _ = Function;
		with( o = document.getElementById("welcome")) {
			innerHTML += innerHTML;
			onmouseover = _("c=1");
			onmouseout = _("c=0");
		}( F = _("if(#%27||!c)#++,#%=o.scrollHeight>>1;setTimeout(F,#%27?10:1000);".replace(/#/g, "o.scrollTop")))();
	</script>
	<div id="t_share">
		<a href="<?php echo BLOG_URL; ?>rss.php" target="_blank">订阅 RSS
			Feed</a>
	</div>
	<div class="clear"></div>
</div>
<div class="cbx">
	<h3><span>消逝的时光</span></h3>
<EMBED src="<?php echo BLOG_URL; ?>content/templates/iblogx/img/shiz.swf" width=300 height=90 type=application/x-shockwave-flash wmode="transparent" >
</div>
<div class="cbx">
	<h3><span>My Project</span></h3>
	<a href="http://www.asooe.com/project/" target=_blank><img style="padding:5px;" src="<?php echo BLOG_URL; ?>content/templates/iblogx/img/1111.png" alt="emlog模板" /></a>
	</div>
	<?php 
	$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
	doAction('diff_side');
	foreach ($widgets as $val)
	{
		$widget_title = @unserialize($options_cache['widget_title']);
		$custom_widget = @unserialize($options_cache['custom_widget']);
		if(strpos($val, 'custom_wg_') === 0)
		{
			$callback = 'widget_custom_text';
			if(function_exists($callback))
			{
				call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
			}
		}else{
			$callback = 'widget_'.$val;
			if(function_exists($callback))
			{
				preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
				$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
				call_user_func($callback, htmlspecialchars($wgTitle));
			}
		}
	}
	?>
<div id="float3">
          <div class="cbx">
	<h3 class="tit"><strong>为你推荐</strong></h3>		  
           <div class="ctx"><ul id="newlog"><?php getdatelogs(9);?>
			  </ul></div>	</div></div>
<script type="text/javascript">
  // 固定层
function buffer(a,b,c){var d;return function(){if(d)return;d=setTimeout(function(){a.call(this),d=undefined},b)}}(function(){function e(){var d=document.body.scrollTop||document.documentElement.scrollTop;d>b?(a.className="div1 div3",c&&(a.style.top=d-b+"px")):a.className="div1"}var a=document.getElementById("float3");if(a==undefined)return!1;var b=0,c,d=a;while(d)b+=d.offsetTop,d=d.offsetParent;c=window.ActiveXObject&&!window.XMLHttpRequest;if(!c||!0)window.onscroll=buffer(e,150,this)})();
</script>
</div><!-- 侧边栏结束 -->
<div class="clear"></div>
</div><!--container 结束-->
