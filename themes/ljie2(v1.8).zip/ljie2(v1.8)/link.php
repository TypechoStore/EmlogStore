<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div id="page">
<div id="content">
<div id="link">
<ul class='blogroll'>
<?php
 global $CACHE; 
 $link_cache = $CACHE->readCache('link');
 foreach($link_cache as $value): ?>
 <table id="tb"><tbody>
<tr>
 <td class="label"><a href="<?php echo $value['url']; ?>" title="" target="_blank"><?php echo $value['link']; ?></a></td>
 <td><?php echo $value['des']; ?></td>
</tr>
</tbody></table>
<?php endforeach; ?>
</ul>
</div>

</div>
</div>

