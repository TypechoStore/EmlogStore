<?php
/*
Template Name:L.Jie-II
Description:单栏大气的EM主题，适用于4.1.0版本……
Author:sprityaoyao
Author Url:http://www.sprityaoyao.org
Sidebar Amount:0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta property="qc:admins" content="52075177776302141171176727" />
<title><?php echo $blogtitle; ?> | <?php echo $bloginfo; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<?php
$cssTime = filemtime(TEMPLATE_PATH.'main.css');
?>
<link href="<?php echo TEMPLATE_URL; ?>main.css?t=<?php echo date('YmdGis',$cssTime) ?>" type="text/css" rel="stylesheet" />
<link rel="shortcut icon" href="<?php echo BLOG_URL; ?>favicon.ico" type="image/x-icon"/> 
<script src="<?php echo TEMPLATE_URL; ?>js/jquery.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>

<?php doAction('index_head'); ?>
</head>
<body>
<div id="navmenu">
<div class="links">
<ul>
	<li class="index"><a href="<?php echo BLOG_URL; ?>" title="首页"></a></li>
	<?php 
		foreach ($navibar as $key => $val):
		if ($val['hide'] == 'y'){continue;}
		if (empty($val['url'])){$val['url'] = Url::log($key);}
	?>
	<li class="menu"><a href="<?php echo $val['url']; ?>" target="<?php echo $val['is_blank']; ?>" title="<?php echo $val['title']; ?>"></a></li>
	<?php endforeach;?>
	<li class="friends"><a href="<?php echo BLOG_URL; ?>link/" title="邻居"></a></li>
	<?php if($istwitter == 'y'):?>
	<li class="twitter"><a href="<?php echo BLOG_URL; ?>t/" title="微语"></a></li>
	<?php endif;?>
	<?php doAction('navbar', '<li class="topNavItem">', '</li>'); ?>
	<li class="rss"><a href="http://feed.feedsky.com/sprityaoyao" title="Rss Feed"></a></li>
	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
	
	<li class="administrater"><a href="<?php echo BLOG_URL; ?>admin/" ><u>管理</u></a></li>
	<li class="logout"><a href="<?php echo BLOG_URL; ?>admin/?action=logout" ><u>退出</u></a></li>
	<?php else: ?>
	<li class="login"><a href="<?php echo BLOG_URL; ?>admin/" title="登录"></a></li>
	
	<?php endif; ?>
</ul>
</div>
</div>


  <div id="wrap">
  <!--[if lte IE 8]>
<span class="tips">推荐使用以下浏览器浏览本站 <a href="http://www.getfirefox.com" target="_blank">Firefox</a>, <a href="http://opera.com" target="_blank">Opera</a>, <a href="http://apple.com/safari" target="_blank">Safari</a>, <a href="http://chrome.google.com">Google Chrome</a>, <a href="http://windows.microsoft.com/zh-CN/internet-explorer/products/ie/home" target="_blank">IE9+</a></span>
<![endif]--> 
 <div id="header"><h1 class="blogname"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
<div class="tSearchNew right">
<form action="<?php echo BLOG_URL; ?>search/" method="get" id="searchform">
<div>
   <input type="text" value="搜搜更健康……" name="q" id="s" />
   </div>
  </form>
  </div></div>