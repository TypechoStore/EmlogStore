<?php 
/*
* 侧边栏组件、页面模块
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//头像缓存函数for emlog4.1.0 by sprityaoyao URL http://www.sprityaoyao.org
function get_avatar($mail,$alt,$size = '32',$default='monsterid')
{
    $alt = strip_tags($alt);
	$email_md5=md5(strtolower($mail));//通过MD5加密邮箱
	$cache_path=EMLOG_ROOT."/content/templates/ljie/cache"; //缓存文件夹路径,ljie需要换上你的主题目录名称
	if(!file_exists($cache_path))
	{
		mkdir($cache_path,0700);
	}
	$avatar_url=TEMPLATE_URL."cache/".$email_md5.'.jpg'; //头像相对路径
	$avatar_abs_url=$cache_path."/".$email_md5.'.jpg'; //头像绝对路径
	$cache_time=24*3600*7; //缓存时间为7天
	 if (empty($default)) $default = $cache_path. '/default.jpg';
	if(!file_exists($avatar_abs_url) || (time()-filemtime($avatar_abs_url)) > $cache_time)//过期或图片不存在
	{
		$new_avatar = getGravatar($mail,$size,$default);
		copy($new_avatar,$avatar_abs_url);
	}
	return "<img title='{$alt}' alt='{$alt}' src='{$avatar_url}' class='gravatar' height='{$size}' width='{$size}' />";
}
//调用方法
//get_avatar($comment['mail'],"{$comment['poster']}{$comment['comment_nums']}")
?>


<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
	<ul id="tags">
	<?php shuffle($tag_cache);foreach($tag_cache as $value): $color = dechex(rand(0,16777215));?>
		<span style="font-size:<?php echo $value['fontsize']; ?>pt; line-height:30px;">
		<a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇日志" style="color:#<?php echo $color;?>"><?php echo $value['tagname']; ?></a></span>
	<?php endforeach; ?>
	</ul>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="blogsort">
	<?php foreach($sort_cache as $value): ?>
	<li>
	<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
	<a href="<?php echo BLOG_URL; ?>rss.php?sort=<?php echo $value['sid']; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/rss.png" alt="订阅该分类"/></a>
	</li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：最新碎语
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="twitter">
	<?php foreach($newtws_cache as $value): ?>
	<li><?php echo $value['t']; ?><p><?php echo smartDate($value['date']); ?> </p></li>
	<?php endforeach; ?>
    <?php if ($istwitter == 'y') :?>
	<p><a href="<?php echo BLOG_URL . 't/'; ?>">更多&raquo;</a></p>
	<?php endif;?>
	</ul>
	</li>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
	
	<h3><span><?php echo $title; ?></span></h3>
		<?php
	foreach($com_cache as $value):
	$url = Url::log($value['gid']).'#'.$value['cid'];
	?>
	<div id="recentcomment">
	<div class="gravatar"><img src="<?php echo getGravatar($value['mail']); ?>" title="<?php echo $value['name']; ?>" width="30px" height="30px" /></div>
	<div class="recentcomment-info">
	<cite><a href="<?php echo $url; ?>"><?php echo $value['name']; ?></a></cite>
	<?php $value['content'] = preg_replace("/\{smile:(([1-4]?[0-9])|50)\}/",'<img src="http://www.sprityaoyao.org/face/$1.gif" alt="" height="14px" />',$value['content']);?>
	<div class="recentcomment-content"><?php echo $value['content']; ?></div>
	
	</div>
	</div>
	<?php endforeach; ?>
<?php }?>
<?php
//widget：最新日志
function widget_newlog($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="newlog">
	<?php foreach($newLogs_cache as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：随机日志
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="randlog">
	<?php foreach($randLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="record">
	<?php foreach($record_cache as $value): ?>
	<li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
	?>
	
	<h3><span><?php echo $title; ?></span></h3>
	<div id="link">
	<ul>
	<?php foreach($link_cache as $value): ?>
	<li>
	<a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank" rel="nofllow"><?php echo $value['link']; ?></a></li>
	<?php endforeach; ?></ul></div>
	
<?php }?>
<?php
//blog：置顶
function topflg($istop){
	$topflg = $istop == 'y' ? "[置顶日志] " : '';
	echo $topflg;
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == 'admin' || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
	<a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>" title="查看<?php echo $log_cache_sort[$blogid]['name']; ?>下的文章"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
	<?php endif;?>
<?php }?>
<?php
//blog：文件附件
function blog_att($blogid){
	global $CACHE;
	$log_cache_atts = $CACHE->readCache('logatts');
	$att = '';
	if(!empty($log_cache_atts[$blogid])){
		$att .= '附件下载:';
		foreach($log_cache_atts[$blogid] as $val){
			$att .= '<a href="'.BLOG_URL.$val['url'].'" target="_blank" rel="nofollow">'.$val['filename'].'</a> '.$val['size'];
		}
	}
	echo $att;
}
?>
<?php
//blog：日志标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "	<a href=\"".Url::tag($value['tagurl'])."\" rel=\"tag\">".$value['tagname'].'</a>';
		}
		echo $tag;
	}
}
?>
<?php
//blog：日志作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻日志
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog):?>
	<div class="left">&laquo; <a href="<?php echo Url::log($prevLog['gid']) ?>" title="上一篇"><?php echo $prevLog['title'];?></a></div>
	<?php else:?>
	<div class="left">没有了</div>
	<?php endif;?>
	<?php if($nextLog && $prevLog):?>
	<?php endif;?>
	<?php if($nextLog):?>
		<div class="right"> <a href="<?php echo Url::log($nextLog['gid']) ?>" title="下一篇"><?php echo $nextLog['title'];?></a>&raquo;</div>
		<?php else:?>
	<div class="right">没有了</div>
	<?php endif;?>
	
<?php }?>
<?php
//blog：引用通告
function blog_trackback($tb, $tb_url, $allow_tb){
    if($allow_tb == 'y' && Option::get('istrackback') == 'y'):?>
	<div id="trackback_address">
	<p class="traceback">Traceback&nbsp;<input type="text" style="width:300px" class="input" value="<?php echo $tb_url; ?>">
	<a name="tb"></a></p>
	</div>
	<?php endif; ?>
	<?php foreach($tb as $key=>$value):?>
		<ul id="trackback">
		<li><a href="<?php echo $value['url'];?>" target="_blank"><?php echo $value['title'];?></a></li>
		<li>BLOG: <?php echo $value['blog_name'];?></li><li><?php echo $value['date'];?></li>
		</ul>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：博客评论列表
function blog_comments($comments,$params){
    extract($comments);
    if($commentStacks): ?>
	<a name="comments"></a>
	<?php endif; ?>
	<?php
	$isGravatar = Option::get('isgravatar');
	$comnum = count($comments);
    foreach($comments as $value){
    if($value['pid'] != 0){
	$comnum--;
	}
}
    $page = isset($params[4])?intval($params[4]):1;
	$i= $comnum - ($page - 1)*Option::get('comment_pnum');
	?>
	<?php if(!empty($comnum)): ?>
	<div id="comment_list">
	<?php foreach($commentStacks as $cid):
	$comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank" rel="external nofollow">'.$comment['poster'].'</a>' : $comment['poster'];
	$comment['content'] = preg_replace("/\{smile:(([1-4]?[0-9])|50)\}/",'<img src="http://www.sprityaoyao.org/face/$1.gif" alt="" height="16" />',$comment['content']);
	$comment['content'] = preg_replace("/\[img=?\]*(.*?)(\[\/img)?\]/e", '"<img src=\"$1\" alt=\"" . basename("$1") . "\" />"', $comment['content']);
	?>
	<div class="comment" id="comment-<?php echo $comment['cid']; ?>">
		<a name="<?php echo $comment['cid']; ?>"></a>
		<?php if($isGravatar == 'y'): ?><div class="avatar left"><?php echo  get_avatar($comment['mail'],"{$comment['poster']}","36");?></div><?php endif; ?>
		<div class="comment-info">
			<cite><?php echo $comment['poster']; ?> </cite>
			<span class="time"><?php echo $comment['date']; ?></span>
			<span id="lay">(<?php echo $i; ?>L)</span>
	<span class="comment-reply"><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)" title="回复">@</a></span>
			<div class="comment-content"><p><?php echo $comment['content']; ?></p></div>
		</div>
		
	</div>
	<?php blog_comments_children($comments, $comment['children']); ?>
	<?php $i--;endforeach; ?>
	
	</div>
		<?php endif; ?>
	<?php if(!empty($commentPageUrl)): ?>
	<div id="pagenavi">
	    <?php echo $commentPageUrl;?>
    </div>
	<?php endif; ?>
<?php }?>
<?php
//blog：博客子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank" rel="external nofollow">'.$comment['poster'].'</a>' : $comment['poster'];
	$comment['content'] = preg_replace("/\{smile:(([1-4]?[0-9])|50)\}/",'<img src="http://www.sprityaoyao.org/face/$1.gif" alt="" height="16" />',$comment['content']);
	$comment['content'] = preg_replace("/\[img=?\]*(.*?)(\[\/img)?\]/e", '"<img src=\"$1\" alt=\"" . basename("$1") . "\" />"', $comment['content']);
	?>
	<div class="comment comment-children" id="comment-<?php echo $comment['cid']; ?>">
		<a name="<?php echo $comment['cid']; ?>"></a>
		<?php if($isGravatar == 'y'): ?><div class="avatar left"><?php echo  get_avatar($comment['mail'],"{$comment['poster']}","36");?></div><?php endif; ?>
		<div class="comment-info">
		<cite><?php echo $comment['poster']; ?> </cite> 
			<span class="time"><?php echo $comment['date']; ?></span>
	<span class="comment-reply"><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)" title="回复">@</a></span>
			<div class="comment-content"><p><?php echo $comment['content']; ?></p></div>	
		</div>
		<?php blog_comments_children($comments, $comment['children']);?>
	</div>
	
	<?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
	<div id="comment-place">
	<div class="comment-post" id="comment-post">
		<div class="cancel-reply" id="cancel-reply" style="display:none"><a href="javascript:void(0);" onclick="cancelReply()">取消回复</a></div>
		<form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
			<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
			<?php if(ROLE == 'visitor'): ?>
			<p>
				<input type="text" name="comname" maxlength="49" value="<?php echo $ckname; ?>" size="22" tabindex="1">
				<label for="author"><small>Name</small></label>
			</p>
			<p>
				<input type="text" name="commail"  maxlength="128"  value="<?php echo $ckmail; ?>" size="22" tabindex="2">
				<label for="email"><small>E-mail </small></label>
			</p>
			<p>
				<input type="text" name="comurl" maxlength="128"  value="<?php echo $ckurl; ?>" size="22" tabindex="3">
				<label for="url"><small>Website</small></label><?php echo $verifyCode; ?>
			</p>
			<?php endif; ?>
			<div class="smile"><?php include View::getView('smiley');?></div>
			<div style="clear:both;">
 <a href='javascript:embedImage();' style="margin-left:5px;" >贴图</a>
 <a style="margin-left:6px;" href='javascript:embedSmiley();' >表情</a>
 <span style="font-size:12px;margin-left:30px;">( ps. 健康评论，谢绝张贴非法图片！ )</span>
</div>
			<p><textarea name="comment" id="comment" cols="90%" rows="4" tabindex="4"></textarea><i id="num">0</i></p>
			<p> <input type="submit" id="comment_submit" value="发表评论(Ctrl+Enter || Shift+Enter)" />
			<span id="error"></span><span id="loading" style="display:none">正在努力提交中……</span></p>
			<input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/>
		</form>
	</div>
	</div>
	<?php endif; ?>
<?php }?>