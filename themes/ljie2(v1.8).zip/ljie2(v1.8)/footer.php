<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="footerbar">
Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>,<a href="http://www.sprityaoyao.org/theme/#" target="_blank" title="Designed by sprityaoyao">L.Jie-II(V1.8)</a>,<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>
,<?php doAction('index_footer'); ?>,<a href="http://creativecommons.org/licenses/by-nc-sa/2.5/" target="_blank">Creative Commons License</a>
</div>
</div>
    <?php 
    $data = ob_get_contents();
	$dataArr = array();
	$search_pattern = "%<a([^>]*?)href=\"[^\"]*?(jpg|gif|png|jpeg|bmp)\"([^>]*?)>.*?</a>%s";
	preg_match_all($search_pattern, $data, $dataArr, PREG_PATTERN_ORDER);
	if(!empty($dataArr[0])) echo '<script src="'.TEMPLATE_URL.'js/slimbox2.js" type="text/javascript"></script>';
	?>
<script src="<?php echo TEMPLATE_URL; ?>js/ljie.js" type="text/javascript"></script>
<?php if($curpage==CURPAGE_LOG) { ?>
<script src="<?php echo TEMPLATE_URL; ?>js/code.js" type="text/javascript"></script>
<?php } ?>
</body>

</html>