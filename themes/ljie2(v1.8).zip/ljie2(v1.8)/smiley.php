﻿<script type="text/javascript" language="javascript">
/* <![CDATA[ */
    function grin(tag) {
    	var myField;
    	tag = ' ' + tag + ' ';
        if (document.getElementById('comment') && document.getElementById('comment').type == 'textarea') {
    		myField = document.getElementById('comment');
    	} else {
    		return false;
    	}
    	if (document.selection) {
    		myField.focus();
    		sel = document.selection.createRange();
    		sel.text = tag;
    		myField.focus();
    	}
    	else if (myField.selectionStart || myField.selectionStart == '0') {
    		var startPos = myField.selectionStart;
    		var endPos = myField.selectionEnd;
    		var cursorPos = endPos;
    		myField.value = myField.value.substring(0, startPos)
    					  + tag
    					  + myField.value.substring(endPos, myField.value.length);
    		cursorPos += tag.length;
    		myField.focus();
    		myField.selectionStart = cursorPos;
    		myField.selectionEnd = cursorPos;
    	}
    	else {
    		myField.value += tag;
    		myField.focus();
    	}
    }
/* ]]> */
</script>
<a href="javascript:grin('{smile:1}')"><img src="http://www.sprityaoyao.org/face/1.gif" alt="色迷迷" title="色迷迷" /></a>
<a href="javascript:grin('{smile:2}')"><img src="http://www.sprityaoyao.org/face/2.gif" alt="哭" title="哭" /></a>
<a href="javascript:grin('{smile:3}')"><img src="http://www.sprityaoyao.org/face/3.gif" alt="呕吐" title="呕吐" /></a>
<a href="javascript:grin('{smile:4}')"><img src="http://www.sprityaoyao.org/face/4.gif" alt="大笑" title="大笑" /></a>
<a href="javascript:grin('{smile:5}')"><img src="http://www.sprityaoyao.org/face/5.gif" alt="口水" title="口水" /></a>
<a href="javascript:grin('{smile:6}')"><img src="http://www.sprityaoyao.org/face/6.gif" alt="微笑" title="微笑" /></a>
<a href="javascript:grin('{smile:7}')"><img src="http://www.sprityaoyao.org/face/7.gif" alt="啵一个" title="啵一个" /></a>
<a href="javascript:grin('{smile:8}')"><img src="http://www.sprityaoyao.org/face/8.gif" alt="发怒" title="发怒" /></a>
<a href="javascript:grin('{smile:9}')"><img src="http://www.sprityaoyao.org/face/9.gif" alt="给力" title="给力" /></a>
<a href="javascript:grin('{smile:10}')"><img src="http://www.sprityaoyao.org/face/10.gif" alt="囧" title="囧" /></a>
<a href="javascript:grin('{smile:11}')"><img src="http://www.sprityaoyao.org/face/11.gif" alt="难过" title="难过" /></a>
<a href="javascript:grin('{smile:12}')"><img src="http://www.sprityaoyao.org/face/12.gif" alt="糯米" title="糯米" /></a>
<a href="javascript:grin('{smile:13}')"><img src="http://www.sprityaoyao.org/face/13.gif" alt="玫瑰" title="玫瑰" /></a>
<a href="javascript:grin('{smile:14}')"><img src="http://www.sprityaoyao.org/face/14.gif" alt="伤不起" title="伤不起" /></a>
<a href="javascript:grin('{smile:15}')"><img src="http://www.sprityaoyao.org/face/15.gif" alt="有木有" title="有木有" /></a>
<a href="javascript:grin('{smile:16}')"><img src="http://www.sprityaoyao.org/face/16.gif" alt="惊叹号" title="惊叹号" /></a>
<a href="javascript:grin('{smile:17}')"><img src="http://www.sprityaoyao.org/face/17.gif" alt="看海" title="看海" /></a>
<a href="javascript:grin('{smile:18}')"><img src="http://www.sprityaoyao.org/face/18.gif" alt="向日葵" title="向日葵" /></a>
<a href="javascript:grin('{smile:19}')"><img src="http://www.sprityaoyao.org/face/19.gif" alt="豌豆射手" title="豌豆射手" /></a>
<a href="javascript:grin('{smile:20}')"><img src="http://www.sprityaoyao.org/face/20.gif" alt="豌豆" title="豌豆" /></a>
<a href="javascript:grin('{smile:21}')"><img src="http://www.sprityaoyao.org/face/21.gif" alt="坚果" title="坚果" /></a>
<a href="javascript:grin('{smile:22}')"><img src="http://www.sprityaoyao.org/face/22.gif" alt="僵尸" title="僵尸" /></a>
<br />