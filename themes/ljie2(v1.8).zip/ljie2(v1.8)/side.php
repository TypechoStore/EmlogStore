<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="sidebar">
<?php if($curpage==CURPAGE_HOME) { ?>
<div id="link">
<?php widget_tag('');?>
</div>
<?php } ?>
</div>
