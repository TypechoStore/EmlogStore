<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="page">
<div id="content">
    <div class="log_content">
	<h2><?php topflg($top); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $log_title; ?></a></h2>
	<div class="share">
	<a id="shareBox" target="_blank" href="#">+Share</a>
					<ul>
						<li><a rel="nofollow" class="twitter-share" title="Twitter"><span></span>Twitter</a></li>
						<li><a rel="nofollow" class="kaixin-share" title="开心网"><span></span>开心网</a></li>
						<li><a rel="nofollow" class="douban-share" title="豆瓣网"><span></span>豆瓣网</a></li>
						<li><a rel="nofollow" class="fanfou-share" title="饭否网"><span></span>饭否网</a></li>
						<li><a rel="nofollow" class="sina-share" title="新浪微博"><span></span>新浪微博</a></li>
						<li><a rel="nofollow" class="tencent-share" title="腾讯微博"><span></span>腾讯微博</a></li>
					</ul>
				</div>
	<?php echo $log_content; ?>
	<p class="att"><?php blog_att($logid); ?></p>
	<?php doAction('log_related', $logData); ?>
	</div>
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
		<div style="clear:both;"></div>
	
	<div class="top">
<script type="text/javascript"><!--
google_ad_client = "pub-5896237646489512";
/* 728x90, 创建于 11-7-30 */
google_ad_slot = "6689613600";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script></div>

	<?php blog_comments($comments,$params); ?>

	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>

	<div style="clear:both;"></div>
</div>
<!--end content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>