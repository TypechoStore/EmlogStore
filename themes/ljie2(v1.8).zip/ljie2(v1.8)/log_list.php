<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="page">

<div id="content">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
   <div class="log_comment">
	<h2>
	<?php topflg($value['top']); ?>&nbsp;&nbsp;<a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
	<?php 
	global $timezone;
	if(time() - $value['date'] < 172800 - $timezone*3600){echo '&nbsp;&nbsp;<img src="'.TEMPLATE_URL.'images/new.gif" alt="newlog" title="最新日志" style="width:24px;border:none;" />';}
	?>
	</h2>
	 <?php echo $value['log_description']; ?>

	</div>
	<div class="postinfo">
	<div class="posttags"><?php echo gmdate('Y-m-d H:i:G', $value['date']); ?><br /><?php blog_sort($value['logid']); ?></div>
	<div class="postcomments"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['views']; ?>^</a> / <a href="<?php echo $value['log_url']; ?>#comments" title="<?php echo $value['comnum']; ?>个评论"><?php echo $value['comnum']; ?>+</a><br /><a href="<?php echo $value['log_url']; ?>" title="阅读全文">>></a></div>
	<div style="clear:both;">
	</div>
	 </div>
	
<?php endforeach; ?>

<?php if(!empty($page_url)): ?>
<div id="pagenavi">
<?php echo $page_url;?>
</div>
<?php endif; ?>


<!--end content-->
<?php
include View::getView('side');
 include View::getView('footer');
?>