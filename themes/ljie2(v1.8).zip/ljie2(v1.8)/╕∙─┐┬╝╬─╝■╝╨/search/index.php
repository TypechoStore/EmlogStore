<?php
/**
 * 搜索
 */
require_once '../init.php'; 
define('TEMPLATE_PATH', TPLS_PATH.Option::get('nonce_templet').'/');//前台模板路径 
$blogtitle = '搜索 '.$_GET['q'];//页面标题，可自行修改，参数'q'文本框input的name一致
if ($action == '') {
$options_cache = $CACHE->readCache('options');
extract($options_cache); 
$navibar = unserialize($navibar); 
include View::getView('header');//加载头部文件
include View::getView('search');//加载搜索结果页，这个在后面一步讲到
 include View::getView('footer');
}
?>