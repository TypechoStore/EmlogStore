<?php
/**
 * 链接
 */
require_once '../init.php'; 
define('TEMPLATE_PATH', TPLS_PATH.Option::get('nonce_templet').'/');//前台模板路径 
$blogtitle = '链接 - 动点创想';
if ($action == '') {
$options_cache = $CACHE->readCache('options');
extract($options_cache); 
$navibar = unserialize($navibar); 
include View::getView('header');
include View::getView('link');

 include View::getView('footer');
 }
?>