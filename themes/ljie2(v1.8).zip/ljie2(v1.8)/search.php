<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div id="page">
<div id="content">
<?php if(empty($_GET['q'])):?>
<?php elseif(!empty($_GET['q'])):?>
		<?php endif;?>
<div id="cse" style="width:726px; margin-top:10px;" >	<h2>包含关键词{<?php echo $_GET['q'];?>}的结果如下:</h2></div> 
<script src="http://www.google.com/jsapi" type="text/javascript"></script>
<script type="text/javascript">
  google.load('search', '1', {language : 'zh-CN', style : google.loader.themes.BUBBLEGUM});
google.setOnLoadCallback(function() {
     var customSearchControl = new google.search.CustomSearchControl('005177029676389900943:erl9nwcbbk0');
    customSearchControl.setResultSetSize(google.search.Search.FILTERED_CSE_RESULTSET);
    var options = new google.search.DrawOptions();
    var search = '<?php echo $_GET['q']; ?>';
    options.setInput(document.getElementById('s')); // 传递输入元素
    document.getElementById('searchform').setAttribute('onSubmit',"document.getElementById('s').select(); return false;"); // 按下搜索按钮选中搜索框，并阻止表单提交
    document.getElementById('s').value = search; // 设置搜索框的内容
    options.setAutoComplete(true);//自动完成，不需要此功能可去除此句，建议留下
    customSearchControl.draw('cse', options);//cse为上面div的id
    customSearchControl.execute(search);
}, true);
</script>
</div><!--end content-->
    
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>search.css" type="text/css" />
