$(function() {
	var s = $('.share'),link,title,
	wh = 'toolbar=0,status=0,resizable=1,width=600,height=480,left=200,top=50';
	var funGetSelectTxt = function() {var txt = '';
	if (document.selection) {txt = document.selection.createRange().text} else {txt = document.getSelection()}return txt.toString()};
	s.hover(function() {var i = $(this).parent().parent().parent().prev('a'),u = $(this).children('ul');title = $('title').html();
	link =  window.location.href;u.show();
	$(this).find('.twitter-share').one('click',function() {var url = 'http://twitter.com/share?url=' + link + '&text=' + title;window.open(url, 'share', wh)});
$(this).find('.kaixin-share').one('click',
function() {var url = 'http://www.kaixin001.com/repaste/share.php?rurl=' + link + '&rcontent=' + link + '&rtitle=' + encodeURIComponent(title);window.open(url, 'share', wh)});
$(this).find('.douban-share').one('click',function() {var url = 'http://www.douban.com/recommend/?url=' + link + '&title=' + encodeURIComponent(title);window.open(url, 'share', wh)});
$(this).find('.fanfou-share').one('click',function() {var url = 'http://fanfou.com/sharer?u=' + link + '?t=' + encodeURIComponent(title);window.open(url, 'share', wh)});
$(this).find('.sina-share').one('click',function() {var url = 'http://v.t.sina.com.cn/share/share.php?url=' + link + '&title=' + title;window.open(url, 'share', wh)});
$(this).find('.tencent-share').one('click',
function() {var url = 'http://v.t.qq.com/share/share.php?title=' + encodeURIComponent(title) + '&url=' + link ;window.open(url, 'share', wh)})},
function() {$(this).children('ul').hide()})
$('#comment').bind('focus keyup input paste',function() {$('#num').text($(this).attr("value").length)});
$("#tb tr:even").addClass("even");function addListener(element, e, fn) {if (element.addEventListener) {element.addEventListener(e, fn, false);} else {element.attachEvent("on" + e, fn);}}
$(document).keypress(function(e) {if (e.ctrlKey && e.which == 13 || e.which == 10) {$("#commentform").submit();
		} else if (e.shiftKey && e.which == 13 || e.which == 10) {
			$("#commentform").submit();
		}
	})
	 var myinput = document.getElementById("s");
	addListener(myinput, "click",
	function() {
		myinput.value = "";
	})
	 addListener(myinput, "blur",
	function() {
		myinput.value = "搜搜更健康……";
	})
	 $('a,input[type="submit"],button[type="button"],object').bind('focus',
	function() {
		if (this.blur) {
			this.blur();
		}
	});
});

function embedImage() {
	var URL = prompt('请输入图片的 URL 地址:');
	if (URL) {
		document.getElementById('comment').value = document.getElementById('comment').value + '[img]' + URL + '[/img]';
	}
}
function embedSmiley() {
	jQuery('.smile').slideToggle();
}