<?php 
/*
* 日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="scroll">
		<a class="scroll_t" title="返回顶部"></a>
		<a class="scroll_b" title="转到底部"></a>
	</div>
<div id="content">
<?php if($pageurl == Url::logPage()){?>
<!--不要首页幻灯片从此行开始删除-->
<div id="slideshow">
<div class="slideshow">
<div id="featured_tag"></div>
	<div id="slider_nav"></div>
	<div id="slider" class="clear">
<?php
home_slide();
?>
	</div>
 </div>
 </div>	
 	    <div class="clear space"></div>	
<!--不要首页幻灯片删除到此行-->
 <?php
}else{
?>
<div id="loc">
<div class="here">现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; 
<?php if ($params[1]=='sort'){ ?>
		<?php get_cat($sortid);?>
<?php }elseif ($params[1]=='tag'){ ?>
			包含标签 <b><?php echo urldecode($params[2]);?></b> 的所有文章
<?php }elseif($params[1]=='author'){ ?>
			作者 <b><?php echo blog_author($author);?></b> 的所有文章
<?php }elseif($params[1]=='keyword'){ ?>
            关键词 <b><?php echo urldecode($params[2]);?></b> 的搜索结果
<?php }elseif($params[1]=='record'){ ?>
           发表在 <b><?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?> </b>的所有文章
<?php }else{?><?php }?>
			 </div>		
	</div> 
	    <div class="clear space"></div>	

<?php
	}
?>
<?php doAction('index_loglist_top'); ?>
<?php if($logs){?>
<?php foreach($logs as $value):?>
		<div class="list_box">
			<div class="list_box_title_box">
					<h3><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></h3>
				<div class="list_info">日期：<?php echo gmdate('Y年m月d日', $value['date']); ?> &#8260; 分类：<?php blog_sort($value['logid']); ?> &#8260; 围观：<?php echo $value['views']; ?> &#8260; 评论：<?php echo $value['comnum']; ?> &#8260; 引用：<?php echo $value['tbcount']; ?>
				</div>
			</div>
			<?php echo $value['log_description']; ?>
			<div class="clear"></div>
			<?php blog_tag($value['logid']); ?>
			<div class="clear"></div>
	</div>
<?php endforeach; ?>
<?php }else{?>
		<div class="list_box">
			<div class="list_box_title_box">
					<h3>对不起，未找到相关文章</h3>				
			</div>
		对不起，未找到相关文章，请<ul><li><a href="<?php echo BLOG_URL; ?>">返回首页</a>或者搜索</li>
			<li>
	<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php" class="wform">
	<input name="keyword"  type="text" value="" class="winput" />
	<input type="submit" id="logserch_logserch" value="搜"  class="wsubmit" />
	</form>
	</li>
	</ul>
	<div class="clear"></div>
	</div>
<?php } ?>
    <div class="navigation"><div class="pages"><?php echo $page_url;?></div></div>
	<div class="clear"></div>
</div>
<?php
 include View::getView('side');
?>
<div class="clear"></div>
<?php
 include View::getView('footer');
?>
</div>
</body>
</html>