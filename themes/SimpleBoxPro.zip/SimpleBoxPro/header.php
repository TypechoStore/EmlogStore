<?php
/*
Template Name:SimpleBoxPro
Description:简单大气的博客模板~~
Version:1.3
Author:大曾
Author Url:http://www.dazeng.org
Sidebar Amount:1
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.cycle.all.min.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/custom.js"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="wrap">
<div id="header">
<div id="logo"><h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1><span class="blog_des"><?php echo $bloginfo; ?></span></div>
<div id="header_right">
<div style="text-align:center;color:#DFDFDF;line-height:50px;">
<a href="http://php.dazeng.org" title="大曾PHP空间站提供免费php空间"><img src="<?php echo TEMPLATE_URL; ?>images/banner.gif" alt="大曾PHP空间站提供免费php空间啦" /></a>
  
</div>
</div>
				<div id="weibo">
					<ul>
					<li id="text">关注本博</li>
					<li id="sina"><a href="http://weibo.com/zxj5" target="_blank" title="关注我的新浪微博">新浪微博</a></li>
					<li id="qq"><a href="http://t.qq.com/iamjun" target="_blank" title="关注我的腾讯微博">腾讯微博</a></li>
					<li id="rss"><a href="<?php echo BLOG_URL; ?>rss.php" target="_blank" title="RSS订阅我的博客">RSS订阅</a></li>
					<!--li id="email"><a href="" target="_blank" title="邮件订阅我的博客">邮件订阅</a></li-->
					</ul>
				</div>
<div id="searchbar">
	<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php" class="wform">
	<input name="keyword"  type="text" value="" class="winput" />
	<input type="submit" id="logserch_logserch" value="搜"  class="wsubmit" />
	</form>
</div>
</div>

<div id="top_nav">
<?php blog_navi();?>
</div>
<div class="clear space"></div>	
