<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="scroll">
		<a class="scroll_t" title="返回顶部"></a>
		<a class="scroll_c" title="查看留言"></a>
		<a class="scroll_b" title="转到底部"></a>
	</div>	
<div id="content">
	<div id="loc">
		<div class="here">现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; <?php echo $log_title; ?></div>		
	</div>    
    <div class="clear">&nbsp;</div>	
		<div class="article_box">
				<h2 class="article_title"><?php echo $log_title; ?></h2>
				<div class="list_info">作者：<?php blog_author($author); ?> &#8260; 时间：<?php echo gmdate('Y年m月d日', $date); ?> &#8260; <a href="#respond" title="坐电梯直达评论">评论：<?php echo $comnum;?></a><?php editflg($logid,$author); ?>
				</div>
			<div class="article">
					<?php echo $log_content; ?>
										<div class="clear"></div>
			</div>
			<div class="clear"></div>
		</div>
<div class="comment_header">目前有 <?php echo $comnum;?> 条评论</div>
	<?php blog_comments($comments); ?>	
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>		
</div>
<?php
 include View::getView('side');
?>
<div class="clear"></div>
<?php
 include View::getView('footer');
?>
</div>
</body>
</html>