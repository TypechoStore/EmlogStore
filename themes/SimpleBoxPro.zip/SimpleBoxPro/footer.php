<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
//敬请保留emlog及模板作者链接，谢谢~~
?>
<div id="footer">
Copyright &copy;&nbsp;<a href="<?php echo BLOG_URL;?>" title="<?php echo $blogname;?>"><?php echo $blogname;?>&trade;</a>&nbsp;Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>&nbsp;& &nbsp;Designed by <a href="http://www.dazeng.org" title="大曾折腾博客">大曾</a> 
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
<?php doAction('index_footer'); ?>

</div>