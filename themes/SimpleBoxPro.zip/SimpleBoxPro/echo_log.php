<?php 
/*
* 日志
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="scroll">
		<a class="scroll_t" title="返回顶部"></a>
		<a class="scroll_c" title="查看评论"></a>
		<a class="scroll_b" title="转到底部"></a>
	</div>	
<div id="content">
	<div id="loc">
		<div class="here">现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; <?php blog_sort($logid); ?> &raquo;</div>		
	</div>    
    <div class="clear space"></div>	
		<div class="article_box">
				<h2 class="article_title"><?php topflg($top); ?><?php echo $log_title; ?></h2>
				<div class="list_info">作者：<?php blog_author($author); ?> &#8260; 时间：<?php echo gmdate('Y年m月d日', $date); ?> &#8260; 分类：<b><?php blog_sort($logid); ?></b> &#8260; <a href="#respond" title="坐电梯直达评论">评论：<?php echo $comnum;?></a><?php editflg($logid,$author); ?>
				</div>
			<div class="article">
					<?php echo $log_content; ?>	
			</div>
			<div class="clear"></div>
		</div>
		<div class="article_meta">
			<span class="spostinfo">
			版权所有，转载请注明出处：<a href="<?php echo Url::log($logid); ?>" >【<?php echo $log_title; ?>】<?php echo Url::log($logid); ?></a>
				</span><br/>
				<?php blog_tag($logid); ?>
				<span class="article_tb"><?php if($allow_tb == 'y' && Option::get('istrackback') == 'y'){echo '引用:'.$tb_url; }?></span>
			<div class="clear"></div>
		</div>
	<div class="art_pre_next">
	<?php neighbor_log($neighborLog); ?>
	</div>
<div class="article_about"><?php doAction('log_related', $logData); ?><div class="clear"></div></div>
<div class="comment_header">目前有 <?php echo $comnum;?> 条评论</div>
	<?php blog_comments($comments); ?>	
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark,$ad_com); ?>	
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
</div>
<?php
 include View::getView('side');
?>
<div class="clear"></div>
<?php
 include View::getView('footer');
?>
</div>
</body>
</html>