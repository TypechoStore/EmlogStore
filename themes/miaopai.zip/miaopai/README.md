miaopai for emlog 秒拍主题模板
---
# 模板截图

- 用户登陆截图
<img src="https://ws3.sinaimg.cn/large/005V7SQ5gy1g0xnghlavwj30sq0fwq4m.jpg" width="100%">
- 首页截图
<img src="https://ws3.sinaimg.cn/large/005V7SQ5gy1g0xngg17d4j30u01e5thm.jpg" width="100%">
- 文章页截图
<img src="https://ws3.sinaimg.cn/large/005V7SQ5gy1g0xngjbus7j30u01697c8.jpg" width="100%">

# 模板介绍

一个仿秒拍的模板

这是一个来自同乐儿的Emlog版本的秒拍主题模板。

为防止不改版本号更新主题，可关注微信公众号，和作者取得联系。

<img src="http://me.tongleer.com/content/uploadfile/201706/008b1497454448.png">

# 增加功能

如果有增加功能的需求，在这里

https://weidian.com/?userid=2055073

或

http://m.renrendian.com/buyer/home?vid=14420124

购买零食或主机后在以上微信公众号留言，和作者取得联系。

# 模板特点
 - 支持pjax、前台登陆、邮箱登陆、QQ登陆、微博登陆、图片验证码、邮件验证码，并后台可控制开启状态。
 
 - 支持检查更新
 
 - 支持修改自定义logo、favicon、自定义二维码、打赏二维码、底部自定义信息等
 
# 视频模块

在编辑文章时，除了以html的方式添加视频外，还可以用一下方式添加：

1、[video]秒拍网页端(http://www.miaopai.com/miaopai/plaza)中的视频ID[/video]

第一步：视频ID查找方法在秒拍网页端点击每个秒拍号头像；

第二步：打开单独秒拍号网页后，右键查看网页源代码，搜索https://www.miaopai.com/show/字符串，它和.htm之间的内容就是视频ID了；

第三步：最后将视频ID添加在[video]视频ID[/video]之中即可。

2、[video]mp4视频地址[/video]

3、[iframe]优酷视频地址[/iframe]

# 关于使用
 - 将本主题里的所有文件放在您网站目录的content/templates内，注意文件夹名字必须为miaopai。

 - 后台->模板->启用本主题->进入模板设置配置信息
 
 - 因为主题使用前台登陆，所以可以自由将后台登陆注册页面编写禁止登陆或者禁止注册的判断。

 - 本主题限个人使用，公开发布请注明原作者：二呆，及链接：http://www.tongleer.com

 - 如果你喜欢这个主题，别忘记给我打赏哦：https://www.tongleer.com/api/web/pay.png
 
 - 如果遇到bug或者使用问题，欢迎给我来email：diamond@tongleer.com
 
 - 1元入群：http://joke.tongleer.com/374.html

# 官方演示

https://me.tongleer.com/?theme=miaopai

# 版本记录
2019-10-02 V1.0.4

	修复因加载cloudflare的layer.js失效导致的bug。
	
2019-08-26 V1.0.3

	优化通用的发送邮件方式支持emlog_6.1.1，修复了发送验证码后修改邮箱可以注册的bug。
	
2019-03-22

	V1.0.2	修复了因cdn.bootcss.com中JS静态资源不可访问导致的js失效的问题。
	
2019-03-10 V1.0.1：

	第一个版本降世