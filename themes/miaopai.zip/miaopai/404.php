<?php 
/**
 * 自定义404页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<?php include View::getView('header');?>
<center>
	<p><h2>404. Not Found. 没有找到你要的页面</h2></p>
</center>