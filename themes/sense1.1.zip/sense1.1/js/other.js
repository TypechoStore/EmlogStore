
function colortags(){
  var colorarr=['#e050c3','#66b82b','#4646be','#406ecd','#098','#e97238','#4cb','#c55'];
  if(document.getElementById('blogtags')){
    var bt=document.getElementById('blogtags');
    if(bt.getElementsByTagName('a')){
    var bta=bt.getElementsByTagName('a');
      for(i=0;i<bta.length;i++){
        n=Math.floor(Math.random()*colorarr.length);
        bta[i].style.color=colorarr[n];
      }
    }
  }
}

function addfav(vtitle,vsite){
  vtitle=vtitle?vititle:document.title;
  vsite=vsite?vsite:window.location.href;
  if(document.all){
    window.external.addFavorite(vsite,vtitle);
  }else if(window.sidebar){
    window.sidebar.addPanel(vtitle,vsite,'');
  }else{
    alert('当前浏览器无法自动添加收藏，请手动添加');
  }
}

function togglecebian(n){
	if( n==0 ){
		$('#cebian').hide(300);
		$('#cebian2').show(300);
	}else{
		$('#cebian').show(300);
		$('#cebian2').hide(300);
	}
}


function movetop(){$('html,body').animate({scrollTop:'0px'},400);}
function movefooter(){$('html,body').animate({scrollTop:$('#footer').offset().top},400);}

$(document).ready(function(){

$('.post_tit h2 a').mouseover(function(){
	$(this).stop(true).animate({paddingLeft:'20px'},300);
}).mouseout(function(){
	$(this).stop(true).animate({paddingLeft:'0px'},200);
});
$('.post').hover(
function(){
	$(this).find('.readmore').stop(true).slideDown(200);
},
function(){
	$(this).find('.readmore').slideUp(200);
});

$('#bloggerinfo .photobox').mouseover(function(){
	$('#ber_info').stop(true).fadeTo(400, 0.7);
}).mouseout(function(){
	$('#ber_info').stop(true).fadeTo(300, 0);
});

$('#cebian h3').bind('mouseover',function(){
			$('#cebian h3').next().hide();
			$(this).next().css('display','block');
		}
);
$('#cebian .mod_nr').hover(
		function(){
			//mouseover
		},
		function(){
			$(this).hide(300);
		}
);



colortags();
});

//movebg
var scrollSpeed = 80;
var current = 0;
var ht = 0;
var direction = 'h';
function bgscroll(){
	current += 1;
	ht += 1;
	$('#movebg').css('backgroundPosition', (direction === 'h') ? current + "px " + ht + "px": ht + "px " + current + "px");
}
setInterval('bgscroll()',scrollSpeed);

//window.onload=function(){colortags();}