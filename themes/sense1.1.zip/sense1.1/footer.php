<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!-- end #contentleft-->
<div style="clear:both;"></div>
<div id="cebian" style="display: block;">
<div class="mod" id="blogsort">
	<h3><span>Look me</span></h3>
	<ul class="mod_nr" style="display: none;">
<?php blog_navi();?>
</div>
</div>
<h5>Links</h5>
  <div><?php widget_link(''); ?></div>
<div id="footerbar">
Powered by <a href="http://www.emlog.net" target="_blank" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog.</a> Theme to <a href="http://www.ooian.com/" target="_blank">Paopao.</a> 繁华过后，有的只是安静的记述生活点滴...<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?> </a><?php echo $footer_info; ?> <?php doAction('index_footer'); ?> </div>
<!--end #footerbar-->
<div style="clear:both;"></div>
</div>
</body></html>