<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="bread">
	<a href="<?php echo BLOG_URL; ?>" title="返回首页"><i class="fa fa-home"></i></a>
	<?php  
		global $CACHE; 
		$cache_sort = $CACHE->readCache('sort');
		$log_cache_sort = $CACHE->readCache('logsort');
		$mylogid = $log_cache_sort[$logid]['id'];
		$pid = $cache_sort [$mylogid]['pid'];
	?>
	<?php if($pid != 0):?>
		<a href="<?php echo Url::sort($pid); ?>">
			<?php echo $cache_sort[$pid]['sortname'];?> >
		</a><!-- 父分类 -->
		<a href="<?php echo Url::sort($mylogid);?>">
			<?php echo $cache_sort[$mylogid]['sortname']; ?> >
		</a><!-- 子分类 -->
	<?php else:?>
		<a href="<?php echo Url::sort($mylogid);?>">
			<?php echo $cache_sort[$mylogid]['sortname']; ?> >
		</a><!-- 分类 -->
	<?php endif;?>
	<?php echo $log_title; ?><!-- 日志标题 -->
</div>
<article class="content">
	<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
	<p class="info">
		<?php echo gmdate('Y-n-j', $date); ?>  
		<?php blog_author($author); ?> 
		分类:<?php blog_sort($logid); ?> 
		<?php editflg($logid,$author); ?>
	</p>
	<div class="article"><?php echo $log_content; ?></div>	
	<p class="tags"><?php blog_tag($logid); ?></p>
	<?php doAction('log_related', $logData); ?>
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div class="clear"></div>
</article>
<?php
 include View::getView('side');
 include View::getView('footer');
?>