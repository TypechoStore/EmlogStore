<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="clear"></div>
</div><!--wrap-->
</div><!--content-->

<footer class="footer">
	<p>Powered by <a href="http://www.emlog.net" title="采用emlog系统">emlog</a>. Design By <a href="http://zhangziheng.com">jaeheng</a>. <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
	<?php doAction('index_footer'); ?></p>
</footer>

<script>prettyPrint();</script>
</body>
</html>