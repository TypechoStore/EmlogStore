<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<article class="content">
	<h2 style="border-bottom:1px dotted #ccc;color:#363636;margin-bottom:20px;"><?php echo $log_title; ?></h2>
	<?php echo $log_content; ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
</article>
<?php
 include View::getView('side');
 include View::getView('footer');
?>