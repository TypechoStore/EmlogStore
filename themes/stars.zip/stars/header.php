<?php
/*
Template Name:宇宙星空
Description:bug反馈：请到作者博客点击广告后留言，嘻嘻。<a href="http://zhangziheng.com/?post=434" target="_blank">bug反馈</a><div class="custom_top_button"><a href="./template.php?action=custom-top">自定义顶部图片</a></div>
Version:1.0
Author:jaeheng
Author Url:http://zhangziheng.com
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<html lang="zh">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>css/style.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>css/csshake.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>font/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<!--[if IE 6]>
<script src="<?php echo TEMPLATE_URL; ?>iefix.js" type="text/javascript"></script>
<![endif]-->
<?php doAction('index_head'); ?>
<script src="<?php echo TEMPLATE_URL;?>js/jquery.js"></script>
<script src="<?php echo TEMPLATE_URL;?>js/jquery.lazyload.min.js"></script>
<script>
$(function() {
    $("img.lazy").fadeIn('slow').lazyload();
    $('p.h2').fadeIn(3000,'linear');
	$('a').hover(function(){
		$(this).fadeTo("slow", 0.5);
	},function(){
		$(this).fadeTo("slow", 1);
	})
});
</script>
</head>
<body>
<header class="header">
	<div class="wrap">
		<div class="left">
			<h1 class="logo shake shake-slow"><a href="">“<?php echo $blogname; ?>”</a></h1>
			<p class="h2"><?php echo $bloginfo; ?></p>
		</div>
		<div class="right">
			<div class="avatars">
				<a href="<?php echo BLOG_URL;?>?author=1"><img src="<?php echo TEMPLATE_URL;?>images/earth.jpg" alt=""></a>
			</div>
		</div>
		<div class="clear"></div>
		<nav class="nav">
		<?php blog_navi();?>
		</nav>			
	</div>		
</header>
<div id="content">
	<div class="wrap">
<?php if(Option::get('topimg') && blog_tool_ishome()): ?>
<div id="banner"><a href="<?php echo BLOG_URL; ?>"><img src="<?php echo BLOG_URL.Option::get('topimg'); ?>" height="134" width="1000" /></a></div>
<?php endif;?>