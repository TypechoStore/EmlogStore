<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php if (!blog_tool_ishome()): ?>
<div class="bread">
	<a href="<?php echo BLOG_URL; ?>" title="返回首页"><i class="fa fa-home"></i></a><!-- 首页 -->
	<?php if (isset($tag)):?>
	> 包含标签“<?php echo $tag; ?>”的文章<!-- 标签 -->
	<?php elseif (isset($sortid)): ?>
	<?php global $CACHE; $sort_cache = $CACHE->readCache('sort'); ?>
	<?php  $pid = $sort_cache[$sortid]['pid'];?>
	<?php if($pid != 0):?>
	<a href="<?php echo Url::sort($pid); ?>"><?php echo $sort_cache[$pid]['sortname'];?> ></a>
	<a><?php echo $sort_cache[$sortid]['sortname']; ?></a><!-- 父分类/子分类 -->
	<?php else:?>
	<a><?php echo $sort_cache[$sortid]['sortname']; ?></a><!-- 分类 -->
	<?php endif;?>
	<?php elseif (isset($author)): ?>
	> 作者：<?php echo $author; ?>的文章<!-- 作者 -->
	<?php elseif (isset($keyword)):?>
	> 包含关键词“<?php echo $keyword; ?>”的文章<!-- 搜索词 -->
	<?php elseif (isset($record)):?>
	> 在“<?php echo $record; ?>”时间内的文章<!-- 归档 -->
	<?php endif; ?>
</div>
<?php endif ?>

<div class="content">
<?php doAction('index_loglist_top'); ?>
<?php if(blog_tool_ishome()): ?>
<div class="list_img">
<ul>
<?php 
if (!empty($logs)):
foreach($logs as $value):
	if ($value['top'] == 'n') {
		continue;
	}
	preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['log_description'], $img);
	$imgext = !empty($img[1]) ? $img[1][0] : TEMPLATE_URL.'images/list/1.png';
	preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
	$imgsrc = !empty($img[1]) ? $img[1][0] : TEMPLATE_URL.'images/list/1.png';
?>
	<li class="shake shake-little">
		<img class="img lazy" data-original="<?php if($imgext):{ echo $imgext;} else:{ echo $imgsrc;} endif;?>" alt="<?php echo $value['log_title']; ?>" class="img">						
		<a href="<?php echo $value['log_url']; ?>" target="_blank"><span><?php echo $value['log_title']; ?></span></a>
	</li>
<?php endforeach; endif; ?>
</ul>
<div class="clear"></div>
</div>
<?php endif;?>
<?php 
if (!empty($logs)):
foreach($logs as $value):
	if ($value['top'] == 'y') {
		continue;
	}
	preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['log_description'], $img);
	$imgext = !empty($img[1]) ? $img[1][0] : TEMPLATE_URL.'images/list/1.png';
	preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
	$imgsrc = !empty($img[1]) ? $img[1][0] : TEMPLATE_URL.'images/list/1.png';
?>
<div class="list_item">
	<a href="<?php echo $value['log_url']; ?>" target="_blank" class="shake">
	<img class="img lazy" data-original="<?php if($imgext):{ echo $imgext;} else:{ echo $imgsrc;} endif;?>" alt="<?php echo $value['log_title']; ?>"></a>
	<div class="list_info">
		<h2><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
		<div class="info">
			<i class="fa fa-user"></i> <?php blog_author($value['author']); ?>
			<i class="fa fa-clock-o"></i> <?php echo gmdate('Y-m-d', $value['date']); ?>
			<?php editflg($value['logid'],$value['author']); ?>
		</div>
		<p class="descript">
			<?php echo subString(strip_tags($value['log_description']),0,150);?>
		</p>
	</div>
	<div class="clear"></div>
</div>
<?php 
endforeach;
else:
?>
<div class="list_item">
<h2>未找到</h2>
<p>抱歉，没有符合您查询条件的结果。</p>
</div>
<?php endif;?>

<div id="pagenavi">
	<?php echo $page_url;?>
</div>

</div><!-- end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>