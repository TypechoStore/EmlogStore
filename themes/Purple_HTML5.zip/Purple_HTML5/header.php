<?php
/*
Template Name:<font color="#c07">Purple_Html5</font>
Description:<font color="red">紫色简洁HTML5模板</font><br>使用主题请自行修改header文件内的35行文字 ……<br><font color="blue">本主题适用于IE7+, Chrome6+, FF3.5+, Safari4+</font>
Version:Ver 1.0
Author:Qzz
Author Url:http://www.qzee.net
Sidebar Amount:1
ForEmlog:4.1.0 - 4.2.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE HTML>
<html>
<head>
  <title><?php echo $blogtitle; ?></title>
  <meta name="description" content="<?php echo $description; ?>" />
  <meta name="keywords" content="<?php echo $site_key; ?>" />
  <meta name="generator" content="Qzz" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>style/style.css" />
  <link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
  <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
  <link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
  <script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?><span class="logo_colour"> 
		  by Qzz for Purple_Html5
		  <!--上面这里改成你的内容-->
		  </span></a></h1>
          <h2><?php echo $bloginfo; ?></h2>
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">
		  <li <?php echo $curpage == CURPAGE_HOME ? 'class="selected"' : ' ';?>><a href="<?php echo BLOG_URL; ?>">首页</a></li>
	<?php if($istwitter == 'y'):?>
		  <li <?php echo $curpage == CURPAGE_TW ? 'class="selected"' : ' ';?>><a href="<?php echo BLOG_URL; ?>t/">微语</a></li>
	<?php endif;?>
	<?php 
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach ($navi_cache as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	$val['is_blank'] = $val['newtab'] == 'y' ? 'target="_blank"' : '';
    $val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
	?>
		  <li <?php echo isset($logid) && $key == $logid ? 'class="selected"' : ' ';?>><a href="<?php echo $val['url']; ?>" target="<?php echo $val['is_blank']; ?>"><?php echo $val['naviname']; ?></a></li>
	<?php endforeach;?>
	<?php doAction('navbar', '<li>', '</li>'); ?>
	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
		  <li><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
		  <li><a href="<?php echo BLOG_URL; ?>admin/">管理中心</a></li>
		  <li><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
	<?php else: ?>
		  <li><a href="<?php echo BLOG_URL; ?>admin/">登录</a></li>
	<?php endif; ?>
        </ul>
      </div>
    </div>
<!-- end header -->
    <div id="site_content">