<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
include View::getView('side');
?>
<div id="content">
	<h1><?php echo $log_title; ?></h1>
	<?php echo $log_content; ?>
	<p class="att"><?php blog_att($logid); ?></p>
	<div class="log_line"></div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
</div>
<? include View::getView('footer');?>