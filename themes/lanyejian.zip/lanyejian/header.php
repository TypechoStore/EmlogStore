<?php
/*
Template Name:蓝绿简单
Description:蓝绿色调简单模板
Version:1.0
Author:蓝叶
Author Url:http://lanyes.org
Sidebar Amount:1
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once (View::getView('module'));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta property="qc:admins" content="00551375161536727" />
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<title><?php echo $site_title; ?> </title>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" language="javascript" src="<?php echo TEMPLATE_URL; ?>lytebox.js"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<!--[if lt IE 7]>
<div style='border: 1px solid #F7941D; background: #FEEFDA; text-align: center; clear: both; height: 20px; position: relative;'>
<div style='width:auto; hight:auto; color:red; text-align: center; font-size: 14px; font-weight: bold; line-height: 2em;'>温馨提示：您的IE版本过低，蓝叶建议您升级至更快速安全 <strong style='color:#0099FF;'>Internet Explorer 8</strong>  <strong style='padding-right: 10px;padding-left: 10px;'>[<a style='color: #0099FF;text-decoration: underline; ' href='http://ie8.down.sandai.net/IE8-Setup-Full.exe' target='_blank'>立即下载升级IE8</a>]</strong>  <a style='color:#000' href='#' onclick='javascript:this.parentNode.parentNode.style.display="none"; return false;'>关闭提示</a></div>
</div>
</div>
<![endif]-->
</head>
<body>
<a name="gotop" id="gotop"></a>
<div class="header-wrap">
	<div id="header">
		<div id="logo"><a href="<?php echo BLOG_URL; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/logo.png" /></a></div><div id="right"><a href="http://lanyes.org/yinyue" target="_blank"title="蓝叶音乐盒"><img width="32px" height="32px" src="<?php echo TEMPLATE_URL; ?>images/music.png" /></a> <a href="http://wpa.qq.com/msgrd?v=3&uin=84953409&site=qq&menu=yes" title="联系蓝叶" target="_blank"><img style="padding-left:3px;" width="32px" height="32px" src="<?php echo TEMPLATE_URL; ?>images/32-qq.png" /></a> <a href="http://t.qq.com/laobings" title="蓝叶的腾讯微博" target="_blank"><img style="padding-left:3px;" src="<?php echo TEMPLATE_URL; ?>images/32-qqweibo.png" /></a> <a href="http://t.sina.com.cn/hcwl" title="蓝叶的新浪微博" target="_blank"><img style="padding-left:3px;" src="<?php echo TEMPLATE_URL; ?>images/32-weibo.png" /></a> <a href="http://list.qq.com/cgi-bin/qf_invite?id=76346bb18630c869c0456c47a542522cdc896ca92bce235f" title="邮件订阅蓝叶博客" target="_blank"><img style="padding-left:3px;" src="<?php echo TEMPLATE_URL; ?>images/32-mail.png" /></a> <a href="http://lanyes.org/rss.php" title="蓝叶博客RSS源地址" target="_blank"><img style="padding-left:3px;" src="<?php echo TEMPLATE_URL; ?>images/32-rss.png" /></a></div>
		<div class="clear"></div>
	</div>
</div>	
<div class="menu-one"><div id="menu"><?php blog_navi();?></div></div>
<div class="main">