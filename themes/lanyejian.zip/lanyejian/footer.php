﻿<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div class="clear"></div>
</div>
<div class="footer-wrap">
<div id="footer"><p>
@ 2010-2012 Powered By <a href="http://www.emlog.net" title="emlog5.0" rel="nofollow">Emlog</a> Skin By <a href="http://lanyes.org" title="蓝叶" target="_blank">蓝叶</a> <a href="http://lanyes.org/sitemap.xml" target="_blank" title="谷歌网站地图">谷歌地图</a> <?php echo $icp; ?> <?php echo $footer_info; ?></P><script id="bdlike_shell"></script>
<script>
var bdShare_config = {
	"type":"large",
	"color":"blue",
	"uid":"636112",
	"likeText":"支持我请点击分享！",
	"likedText":"支持我请点击分享！",
	"share":"yes"
};
document.getElementById("bdlike_shell").src="http://bdimg.share.baidu.com/static/js/like_shell.js?t=" + new Date().getHours();
</script>
<script type="text/javascript"><!--
    	jQuery(document).ready(function($){
    	//友情链接自动添加fav图标
    	$("#link li a").each(function(e){
    	$(this).prepend("<img src=http://www.google.com/s2/favicons?domain="+this.href.replace(/^(http:\/\/[^\/]+).*$/, '$1').replace( 'http://', '' )+" style=float:left;margin-right:5px;>");
    	});
    	});
    	//--></script>
<div class="clear"></div>
</div>
<?php doAction('index_footer'); ?>
</div>
<a name="gobottom" id="gobottom"></a>
<div class="go">
<a title="返回顶部" class="top" href="#gotop">至顶</a>
<a title="留言评论" class="tocomment" href="#comment-place">发表评论</a>
<a title="返回底部" class="bottom" href="#gobottom">至底</a>
</div>
</body>
</html>