<?php 
/**
 * 日志列表
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');}
$randIndex = array_rand($logs);
$randLog = $logs[$randIndex];
?>
  	<div class="banner"><?php echo $randLog['title']; ?></div>
		<div class="log"><?php echo $randLog['content']; ?></div>
  </div>
</div>
<?php include View::getView('footer'); ?>