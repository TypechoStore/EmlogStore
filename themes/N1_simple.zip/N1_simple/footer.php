<?php 
/**
 * 尾部
 */
if(!defined('EMLOG_ROOT')) {exit('Load failed.');}
?>
<div class="footer">Powered by <a href="http://emlog.net" target="_blank">Emlog</a>. Written by <a href="http://sinkery.com" target="_blank">Sinkery</a>.</div>
<div class="top" title="回到顶部"><i class="fa fa-chevron-circle-up"></i></div>
<div class="rand" onclick="location.reload();" title="随机文章"><i class="fa fa-play-circle"></i></div>
</body>
<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js" type="text/javascript"></script>
<script>
$(document).ready(function(){
$(window).scroll(function(){
if($(this).scrollTop()!=0){
$('.top').fadeIn(500);}
else{
$('.top').fadeOut(500);} });
$('.top').click(function(){
$('body,html').animate({scrollTop:0},700);});
});
</script>
</html>