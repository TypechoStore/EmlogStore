<?php 
/*
* 日志页
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="main">
  <div id="title"><?php topflg($top); ?><?php echo $log_title; ?></div>	
  <div class="postinfo" id="postinfo">
    发表日期：<span><?php echo gmdate('Y-n-j G:i', $date); ?></span><?php blog_tag($logid); ?>
  </div>
	<div class="log"><?php echo $log_content; ?></div>
    <?php doAction('log_related', $logData); ?>
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>

<?php
 include View::getView('side');
 include View::getView('footer');
?>