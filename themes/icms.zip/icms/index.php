<?php 
/*
* 首页
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="main">
  <?php doAction('index_loglist_top'); ?>
  <?php newlog();?>
  <?php randlog();?>
  <?php get_list('1');?>
  <?php get_list('2');?>
  <?php get_list('3');?>
  <?php get_list('4');?>
  <div class="clear"></div>
</div>
