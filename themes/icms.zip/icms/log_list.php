<?php 
/*
* 列表页
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<?php if($pageurl == Url::logPage()){ ?>
<?php include View::getView('index'); ?>
<?php }else{ ?>
<?php doAction('index_loglist_top'); ?>
<div class="main">
  <?php foreach($logs as $value): ?>
  <div class="title">
    <?php topflg($value['top']); ?>
    <a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
  </div>
  <div class="postinfo">
    发表日期：<span><?php echo gmdate('Y-n-j G:i', $value['date']); ?></span><?php blog_tag($value['logid']); ?>&nbsp;&nbsp;评论：<a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?></a>&nbsp;条&nbsp;&nbsp;浏览：<a href="<?php echo $value['log_url']; ?>"><?php echo $value['views']; ?></a>&nbsp;人
  </div>
  <div class="logdes">
    <?php echo $value['log_description']; ?>
  </div>
  <?php endforeach; ?>
  <div class="pagenavi">
    <?php echo $page_url;?>
  </div>
</div>
<?php } ?>

<?php
 include View::getView('side');
 include View::getView('footer');
?>
