  <?php 
/*
* 底部信息
*/

if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="clear"></div>
<?php if($pageurl == Url::logPage()){ ?>
<?php links();?>
<?php }else{ ?>
<?php } ?>
</div>
<div class="foot">
Copyright © 2012-2013 <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a> 版权所有<br /> 
Powered by <a href="http://www.emlog.net" rel="nofollow">emlog</a><br />
<?php doAction('index_footer'); ?>
</div>
</div>
</body>
</html>
