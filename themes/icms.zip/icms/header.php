<?php
/*
Template Name:icms
Description:这是一个精仿DeDeCms的模版，无版权，大家可以任意修改。
Version:1.0
Author:弦非玄
Author Url:http://www.emlog.net
Sidebar Amount:1
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div class="w960">
  <div class="head">
    <div class="logo">
	  <a href="<?php echo BLOG_URL; ?>">
	  <img src="<?php echo TEMPLATE_URL; ?>images/logo.jpg" width="234" height="60" border="0" />
	  </a>
	</div>
    <div class="banner1">
	  <a href="#" rel="nofollow">
	  <img src="<?php echo TEMPLATE_URL; ?>images/banner1.gif" width="468" height="60" border="0" />
	  </a>
	</div>
    <div class="banner2">
	  <a href="#" rel="nofollow">
	  <img src="<?php echo TEMPLATE_URL; ?>images/banner2.gif" width="218" height="60" border="0" />
	  </a>
	</div>
  </div>
  <div class="nav">
    <?php blog_navi();?>
    <div class="clear"></div>
	<div class="here">
		现在位置：
		<?php if($pageurl == Url::logPage()){ ?>
        <a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a>
		<?php }elseif ($params[1]=='sort'){ ?>
		<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> > <?php echo '<a href="'.Url::sort($sortid).'">'.$sortName.'</a>';?>
        <?php }elseif ($params[1]=='tag'){ ?>
		<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> > 标签 <?php echo urldecode($params[2]);?> 的所有文章
        <?php }elseif($params[1]=='author'){ ?>
		<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> > 作者 <?php echo blog_author($author);?> 的所有文章
        <?php }elseif($params[1]=='keyword'){ ?>
		<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> > 关键词 <?php echo urldecode($params[2]);?> 的搜索结果
        <?php }elseif($params[1]=='record'){ ?>
		<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> > 发表在 <?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?> 的所有文章
        <?php }else{?>
		<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> > 
		<?php if($log_title == ""){ ?>
		碎语
		<?php }else{?>
		<?php echo $log_title; ?>
        <?php } ?>
		<?php } ?>
	</div>		
  </div>
  <div class="clear"></div>