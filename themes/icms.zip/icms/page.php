<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="main">
  <div id="title"><?php echo $log_title; ?></div>	
  <div class="postinfo" id="postinfo">
    发表日期：<span><?php echo gmdate('Y-n-j G:i', $date); ?></span>
  </div>
	<div class="log"><?php echo $log_content; ?></div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>