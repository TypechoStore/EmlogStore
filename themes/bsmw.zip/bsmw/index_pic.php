<?php 
/**
 * 首页幻灯片
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="blank"></div>
<div class="blogs">
<ul class="bloglist">
<div class="info">
<link href="<?php echo TEMPLATE_URL; ?>css/saySlide.css" type="text/css" rel="stylesheet" />
<script src="<?php echo TEMPLATE_URL; ?>jquery.saySlide.js" type="text/javascript" ></script>
<script src="jquery-1.7.1.min.js" type="text/javascript" ></script>
<style>
#saySlide{width:693px;height:150px;margin:0 auto;overflow:hidden;}
</style>
</head>
<body>
<div id="saySlide">
	<?php index_pic(_g('index_img_sort'), _g('index_img_num')); ?>
</div>
<script>
$(function(){
	$("#saySlide").saySlide({isTitle:true,isBottombg:true,autodir:'left'});
})
</script>
<style>
b{width:100px;text-align:right;display:inline-block;padding-right:10px;color:#2A730B;}
</style>
</div>