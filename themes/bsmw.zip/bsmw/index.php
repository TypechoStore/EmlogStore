<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="mainbody">
<?php doAction('index_loglist_top'); ?>
<?php if(_g('index_img') == "yes"): ?>
<?php include View::getView('index_pic');?>
<?php else: ?>
<?php include View::getView('banner');?>
<?php endif; ?>
<?php echo get_flash_data(_g('index_num')); ?></ul>
<?php include View::getView('side');?></div>
<?php include View::getView('side_nav');?></div>