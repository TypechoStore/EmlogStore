<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="mainbody">
<div class="blank"></div>
<div class="blogs">	
<div id="index_view">
<h2 class="t_nav"><a href="<?php echo BLOG_URL;?>">网站首页</a><?php blog_sort($logid); ?></h2>
<h1 class="c_titile"><?php topflg($top); ?><?php echo $log_title; ?></h1>
<ul><p><?php echo $log_content; ?></p></ul>
<div class="share"> 
</div>
<div class="otherlink">
<?php doAction('log_related', $logData); ?> 
<?php blog_comments($comments,$params); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>   
</div>
<?php include View::getView('side');?>
</div>
 </div>
<?php include View::getView('footer');?>