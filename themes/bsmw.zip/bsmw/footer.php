<?php 
//�ײ�ҳ��
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
function foot_date(){
	$db = MySql::getInstance();
	?>
	<?php
	$sql2 = "SELECT gid,title,date FROM ".DB_PREFIX."blog WHERE gid='2' ORDER BY `date` DESC LIMIT 1";
	$list = $db->query($sql2);
	while($row = $db->fetch_array($list)){
	?>
	<?php 
		echo gmdate('Y', $row['date']); ?>
	<?php }?>
<?php } ?>
<?php 
Copyright(); 
?><?php  echo $blogname; ?> <?php $str = '4oCUIOWni+S6jg==';echo base64_decode($str);?>
<?php foot_date(); ?> 
<?php $str = '54mI5p2D5omA5pyJ';echo base64_decode($str);?>
 <?php echo $footer_info; ?><br/>
<?php doAction('index_footer'); ?> <?php echo $icp; ?></p>
</div>
</footer>
<div id="tbox"><a id="gotop" href="javascript:void(0)"></a> </div>
</body>
</html>
