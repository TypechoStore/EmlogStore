<?php

/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
	'index_num' => array(
		'type' => 'text',
		'name' => '首页日志显示数量',
		'default' => '13',
	),
	'index_top' => array(
		'type' => 'text',
		'name' => '首页置顶图文数量',
		'default' => '1',
	),	
//首页logo设置
'index_logo' => array(
     'type' => 'image',
	'name' => '首页 → LOGO设置',
	'values' => array(
	TEMPLATE_URL . 'images/logo.png',
	),
	'default' => ''.TEMPLATE_URL.'images/logo.png',
),
//首页logo设置

//首页banner设置
'index_banner' => array(
     'type' => 'image',
	'name' => '首页相关 → banner横幅设置(图片尺寸630x250)',
	'values' => array(
	TEMPLATE_URL . 'images/art.jpg',
	),
	'default' => ''.TEMPLATE_URL.'images/art.jpg',
),
	'banner_bt' => array(
		'type' => 'text',
		'name' => '首页相关 → banner说明标题',
		'default' => '渡人如渡己，渡已，亦是渡',
	),
	'banner_nr' => array(
		'type' => 'text',
		'name' => '首页相关 → banner说明内容',
		'default' => '当我们被误解时，会花很多时间去辩白。 但没有用，没人愿意听，大家习惯按自己的所闻、理解做出判别，每个人其实都很固执。与其努力且痛苦的试图扭转别人的评判，不如默默承受，给大家多一点时间和空间去了解。而我们省下辩解的功夫，去实现自身更久远的人生价值。其实，渡人如渡己，渡已，亦是渡人。',
	),
//首页banner设置

	'admin_mail' => array(
		'type' => 'text',
		'name' => '管理员邮箱',
		'default' => 'chenziwen@lantk.com',
	),
	'index_img' => array(
		'type' => 'radio',
		'name' => '首页幻灯片方案选择',
		'values' => array(
            'yes' => '开启幻灯片轮播模式',
            'no' => '开启固定图片模式'
        ),
		'default' => 'no',
	),

	'index_img_sort' => array(
		'type' => 'sort',
		'name' => '选择首页幻灯片文章分类',
		'default' => '1',
	),
	'index_img_num' => array(
		'type' => 'text',
		'name' => '轮播幻灯片调用数量',
		'default' => '4',
	),

//侧边栏
	'side_lx' => array(
		'type' => 'radio',
		'name' => '侧边栏那几个小图标是否开启',
		'values' => array(
            'yes' => '那个很好看，我要保留',
            'no' => '丑死了，给我关掉'
        ),
		'default' => 'yes',
	),
			'side_top' => array(
		'type' => 'radio',
		'name' => '侧边栏置顶是否开启',
		'values' => array(
            'yes' => '还是留着吧',
            'no' => '留你妹啊，关了'
        ),
		'default' => 'yes',
	),


);
