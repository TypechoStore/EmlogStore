<?php
/*
Template Name:Magix Tech
Description:舍力移植Magix Tech
Version:1.2
Author:舍力
Author Url:http://www.shuyong.net
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');ob_clean();?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title><?php echo $site_title; ?></title>
<script>
var _options_ = {
  'current_user_id' : 0,
  'site_url' : '<?php echo BLOG_URL;?>',
  'template_url' : '<?php echo TEMPLATE_URL;?>', // 模板文件夹的访问路径
  'real_current_page' : 1, // 当前的页码，用在翻页中
  'pagenavi_num' : 3, // 翻页的加载数量
  'response_narrow_width' : 1200, // 有些屏幕比较窄，适当调整
  'response_pad_width' : 800, // 响应式平板屏幕宽度
  'response_phone_width' : 480, // 响应式手机屏幕宽度
  'img_lazyload' : 1, // 图片延时加载
  'style_color' : 'green' // 基调颜色
};
</script>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL;?>main.css">
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<script src="<?php echo TEMPLATE_URL;?>fanti.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"http:\/\/s.w.org\/images\/core\/emoji\/72x72\/","ext":".png","source":{"concatemoji":"content\/templates\/magix_tech\/release.js"}};
			!function(a,b,c){function d(a){var c=b.createElement("canvas"),d=c.getContext&&c.getContext("2d");return d&&d.fillText?(d.textBaseline="top",d.font="600 32px Arial","flag"===a?(d.fillText(String.fromCharCode(55356,56812,55356,56807),0,0),c.toDataURL().length>3e3):(d.fillText(String.fromCharCode(55357,56835),0,0),0!==d.getImageData(16,16,1,1).data[0])):!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g;c.supports={simple:d("simple"),flag:d("flag")},c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.simple&&c.supports.flag||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
</head>
<body class="home blog">
<div id="top-area"><div class="container">
  <h1 id="logo"><img src="<?php echo _g('logo');?>" alt="<?php echo $blogname;?>"></h1>
  <div id="menu"><?php blog_navi();?></div>
        <div id="user-area">
        <span class="register"><a href="javascript:zh_tran('s');" class="zh_click" id="zh_click_s">简体</a></span>
    <span>|</span>
    <span class="login"><a href="javascript:zh_tran('t');" class="zh_click" id="zh_click_t">繁體</a></span>
      </div>
    <div id="search-area">
    <form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
      <input name="keyword" class="search" type="text" value="输入关键字..." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
      <button type="submit">&nbsp;</button>
      <div class="clear"></div>
    </form>
  </div>
  <div class="clear"></div>
</div></div>
