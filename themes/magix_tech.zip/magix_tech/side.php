<?php hotlog($title);?>
<?php random_log($title);?>   
<?php newcomm($title);?>
<?php newlog($title);?>
<?php tag($title);?>