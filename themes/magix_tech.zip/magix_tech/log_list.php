<div role="main" id="main">
  <div id="content-box">
  <div id="content">
<div id="slider" class="swiper-container"><div class="swiper-wrapper"><div class="swiper-slide swiper-first-slide"><img src="<?php echo _g('flash1');?>" class="swiper-slide-img"></div><div class="swiper-slide"><img src="<?php echo _g('flash2');?>" class="swiper-slide-img"></div><div class="swiper-slide"><img src="<?php echo _g('flash3');?>" class="swiper-slide-img"></div></div><div class="swiper-pagination"></div><div class="clear"></div></div>
    
    <div id="post-list">
     
     <?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
<div class="post type-post status-publish format-standard has-post-thumbnail hentry category-news">
<div class="post-thumb"><?php $imgsrc =preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);$imgsrc = !empty($img[1]) ? $img[1][0] : ''; ?><?php if($imgsrc){?><img src="<?php echo $imgsrc;?>"><?php }else{?><?php }?></div>
<h2 class="post-title"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
<div class="post-info">
<span class="post-meta"><span class="icon author"></span><?php blog_author($value['author']); ?></span>    <span class="post-meta"><span class="icon cate"></span><?php blog_sort($value['logid']); ?> </span>
<span class="post-meta"><span class="icon date"></span><?php echo gmdate('Y-m-d H:i:s', $value['date']); ?></span>
<span class="post-comment post-meta"><span class="icon comment"></span><?php echo $value['comnum']; ?></span>    <span class="post-meta"><span class="icon view"></span><?php echo $value['views']; ?></span>
      </div>
  <div class="post-excerpt">
    <p><?php echo subString(strip_tags(str_replace(array("\n","&nbsp;"),"",$value['content'])),0,90);?></p>
  </div>
  <div class="post-opt">
    <span class="icon tag"></span><?php blog_tag($value['logid']); ?>  </div>
<div class="clear"></div>
</div>
<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
 </div>
<div class="pagenav" id="pagenavi"><?php echo $page_url;?></div></div></div>
<aside role="sidebar"><div id="sidebar"><?php include View::getView('side');?></div></div></aside></div>
<?php include View::getView('footer');?>