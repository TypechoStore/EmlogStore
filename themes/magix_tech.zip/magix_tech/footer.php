<div id="footer"><div class="container">
<?php links();?>
<div id="copyright"><p style="text-align: center;">Copyright © <?php echo(($Y = intval(date('Y'))) > 2013) ? "$Y" : '';?> <?php echo $blogname;?> 版权所有 &nbsp; <?php echo $icp;?></p>
<p style="text-align: center;"><?php echo $footer_info; ?></p>
<p style="text-align: center;">Powered by emlog / &Theme <a href="http://www.shuyong.net" title="舍力博客" target="_blank" id="xj">舍力博客</a>.</p>
</div>
  <div class="clear"></div>
</div></div>
<?php doAction('index_footer'); ?>
<!--[if IE]><script src="<?php echo TEMPLATE_URL;?>jquery-1.11.3.min.js"></script><![endif]-->
<!--[if !IE]><!--><script src="<?php echo TEMPLATE_URL;?>jquery-2.1.1.min.js"></script><!--<![endif]-->
<script src="<?php echo TEMPLATE_URL;?>minify.js"></script>
</body>
</html>