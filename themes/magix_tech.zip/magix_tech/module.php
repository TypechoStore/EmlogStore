<?php if(!defined('EMLOG_ROOT')) {exit('error!');} if (!function_exists('_g')) {emMsg('<div style="color:#ff0000;line-height:40px;text-align:center;font-size:16px;">欢迎你使用由舍力制作的主题；</div><div style="line-height:25px;font-size:14px;color:#999;">你现在无法正常使用本模板的原因：<br />1、你可能还未安装，请先安装<a href="http://www.emlog.net/plugin/144" target="_blank">模板设置插件</a><br />2、你还未启用模板设置插件，请到后面插件管理中启用模板插件；<br />主题由舍力负责维护，如有疑问请阅读【<a href="http://www.shuyong.net/787.html" target="_blank">模板使用说明</a>】</div>', BLOG_URL . 'admin/plugins.php');}?>
<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="bloggerinfo">
	<div id="bloggerinfoimg">
	<?php if (!empty($user_cache[1]['photo']['src'])): ?>
	<img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="<?php echo $user_cache[1]['photo']['width']; ?>" height="<?php echo $user_cache[1]['photo']['height']; ?>" alt="blogger" />
	<?php endif;?>
	</div>
	<p><b><?php echo $name; ?></b>
	<?php echo $user_cache[1]['des']; ?></p>
	</ul>
	</li>
<?php }?>
<?php
//widget：日历
function widget_calendar($title){ ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<div id="calendar">
	</div>
	<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
	</li>
<?php }?>
<?php
//widget：标签
function tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
<div id="fixed-sidebar"><div class="widget widget_tag_cloud" id="tag_cloud-2"><div class="widget-title"><h3>标签</h3><div class="clear"></div></div>
<div class="tagcloud">
	<?php foreach($tag_cache as $value): ?>

		<a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇文章" style="font-size:<?php echo $value['fontsize'];?>pt;"><?php echo $value['tagname']; ?></a>
	<?php endforeach; ?>
</div><div class="clear"></div></div>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="blogsort">
	<?php
	foreach($sort_cache as $value):
		if ($value['pid'] != 0) continue;
	?>
	<li>
	<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
	<?php if (!empty($value['children'])): ?>
		<ul>
		<?php
		$children = $value['children'];
		foreach ($children as $key):
			$value = $sort_cache[$key];
		?>
		<li>
			<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
		</li>
		<?php endforeach; ?>
		</ul>
	<?php endif; ?>
	</li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>

<?php
//widget：最新评论
function newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
<div class="widget posts-recommend" id="postsrecommend-5"><div class="widget-title"><h3>最新评论文章</h3><div class="clear"></div></div><ul class="posts-recommend">
	<?php
	foreach($com_cache as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	?>
<?php com_tt($value['gid']);?>

	<?php endforeach; ?>
<div class="clear"></div></div>
<?php }?>

<?php //评论文章标题
function com_tt($gid){$db = MySql::getInstance();$sql = "SELECT * FROM ".DB_PREFIX."blog WHERE hide='n' and gid in ($gid) ORDER BY `date` DESC LIMIT 0,1";$list = $db->query($sql);while($row = $db->fetch_array($list)){?>
<li><a href="<?php echo Url::log($row['gid']);?>" title="<?php echo $row['title'];?>"><?php echo $row['title'];?></a></li><?php }}?>
<?php
//widget：最新文章
function newlog($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
<div class="widget posts-recommend" id="postsrecommend-5"><div class="widget-title"><h3>更新文章</h3><div class="clear"></div></div><ul class="posts-recommend">
	<?php foreach($newLogs_cache as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']);?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
<div class="clear"></div></div>
<?php }?>
<?php //widget：热门文章
function hotlog($title){
$index_hotlognum = Option::get('index_hotlognum');?>
<div class="widget posts-recommend" id="postsrecommend-3"><div class="widget-title"><h3>本月热门文章排行榜</h3><div class="clear"></div></div><ul class="posts-recommend posts-with-image-list">
<?php $db = MySql::getInstance();$db = MySql::getInstance();
$time = time();
$sql = $db->query ("SELECT * FROM ".DB_PREFIX."blog inner join ".DB_PREFIX."sort WHERE hide='n' AND type='blog' AND date > $time - 300*24*60*60 AND top='n' AND sortid=sid order by `views` DESC limit 0,$index_hotlognum");
while($row = $db->fetch_array($sql)){ $logpost = !empty($row['excerpt']) ? $row['excerpt'] :''.$row['content'].''; if (!empty($row['excerpt'])){preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i",$row['excerpt'],$match);if(empty($match[1][0])){
preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i",$row['content'],$match);}}else{preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'],$match);}
$img = isset($match[0][0]) ? $match[0][0]:'<img src="'.TEMPLATE_URL.'images/news.jpg" />';//无图片时显示
$date = gmdate('Y年m月d日', $row['date']);
$content = strip_tags($logpost,'');
$content = mb_substr($content,0,100,'utf-8');//摘要字数修改本代码中的100这个即可
$comment = ($row['comnum'] != 0) ? ''.$row['comnum'].'' : '0';
$gid = $row['gid'];?>
<li>
<div class="thumb"><?php echo $img;?></div>
<div class="title"><a href="<?php echo Url::log($row['gid']);?>" title="<?php echo $row['title'];?>" /><?php echo $row['title'];?></a></div>
<div class="excerpt"><?php echo $content;?></div>
<div class="clearfix clear"></div>
</li><?php };?></ul><div class="clear"></div></div><?php }?>
<?php
//widget：随机文章
function random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
<div class="widget posts-recommend" id="postsrecommend-5"><div class="widget-title"><h3>随机文章</h3><div class="clear"></div></div><ul class="posts-recommend">
	<?php foreach($randLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
</ul><div class="clear"></div></div>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="logsearch">
	<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
	<input name="keyword" class="search" type="text" />
	</form>
	</ul>
	</li>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="record">
	<?php foreach($record_cache as $value): ?>
	<li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul>
	<?php echo $content; ?>
	</ul>
	</li>
<?php } ?>
<?php //widget：cms首页链接
function links(){global $CACHE;$link_cache = $CACHE->readCache('link');if (!blog_tool_ishome()) return;?>友情链接：
<?php foreach($link_cache as $value){?> <a href="<?php echo $value['url'];?>" title="<?php echo $value['link'];?>" target="_blank"><?php echo $value['link'];?></a> <?php }syurl();?><?php }?> 
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');$i=0;
	?>

	<?php
	foreach($navi_cache as $value):$i++;if($i>7)break;

        if ($value['pid'] != 0) {
            continue;
        }

		if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):
			?>

			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
        $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'current' : 'common';
		?>

        <?php if(!empty($value['children'])||!empty($value['childnavi'])){?><span class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children"><a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a> <?php }else{?>
<span class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a> <?php }?>
			<?php if(!empty($value['children'])) :?>
<div class="sub-menu">
                <?php foreach ($value['children'] as $row){
                        echo '<span class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></span>';
                }?>
			</div>
            <?php endif;?>

            <?php if (!empty($value['childnavi'])) :?>
            <div class="sub-menu">
                <?php foreach ($value['childnavi'] as $row){
                        $newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';
                        echo '<span class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="' . $row['url'] . "\" $newtab >" . $row['naviname'].'</a></span>';
                }?>
			</div>
            <?php endif;?>

		</span>
	<?php endforeach; ?>

<?php }?>
<?php
//blog：置顶
function topflg($top, $sortop='n', $sortid=null){
    if(blog_tool_ishome()) {
       echo $top == 'y' ? "<img src=\"".TEMPLATE_URL."/images/top.png\" title=\"首页置顶文章\" /> " : '';
    } elseif($sortid){
       echo $sortop == 'y' ? "<img src=\"".TEMPLATE_URL."/images/sortop.png\" title=\"分类置顶文章\" /> " : '';
    }
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
    <a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
	<?php endif;?>
<?php }?>
<?php
//blog：文章标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '标签:';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "	<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
		}
		echo $tag;
	}
}
?>
<?php
//blog：文章作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog):?>
<p>上一篇：<a href="<?php echo Url::log($prevLog['gid']) ?>"><?php echo $prevLog['title'];?></a></p>
	<?php endif;?>
	<?php if($nextLog && $prevLog):?>

	<?php endif;?>
	<?php if($nextLog):?>
<p>下一篇：<a href="<?php echo Url::log($nextLog['gid']) ?>"><?php echo $nextLog['title'];?></a></p>
	<?php endif;?>
<?php }?>
<?php //blog：评论列表 
function blog_comments($comments,$params){extract($comments);if($commentStacks):endif;?>
<?php $isGravatar = Option::get('isgravatar');
$comnum = count($comments);foreach($comments as $value){if($value['pid'] != 0){$comnum--;}}
$page = isset($params[5])?intval($params[5]):1;
$i= $comnum - ($page - 1)*Option::get('comment_pnum');
foreach($commentStacks as $cid):$comment = $comments[$cid];$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' :$comment['poster'];?>
<div class="comment" id="comment-<?php echo $comment['cid']; ?>"><a name="<?php echo $comment['cid']; ?>"></a><div class="avatar"><img src="<?php echo myGravatar($comment['mail']); ?>" /></div><div class="comment-info"><b><?php echo $i;?>楼、<?php echo $comment['poster']; ?> </b> [<a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)" >回复该留言</a>] <br /><span class="comment-time"><?php echo $comment['date']; ?></span></div><div class="comment-content"<?php if($comment['url']=='http://www.shuyong.net/'){?> style="color:#F00;"<?php }?>><?php echo $comment['content']; ?></div><?php blog_comments_children($comments, $comment['children']); ?></div><?php $i--;endforeach; ?><div class="pagenav"><?php echo $commentPageUrl;echo '共'.$comnum.'条评论';?></div><?php }?>
<?php //blog：子评论列表
function blog_comments_children($comments, $children){$isGravatar = Option::get('isgravatar');foreach($children as $child):$comment = $comments[$child];$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank" >'.$comment['poster'].'</a>' : $comment['poster'];?><div class="comment comment-children" id="comment-<?php echo $comment['cid'];?>"><a name="<?php echo $comment['cid']; ?>"></a><div class="zipl"><?php if($isGravatar == 'y'): ?><div class="avatar"><img src="<?php echo myGravatar($comment['mail']); ?>" /></div><?php endif; ?><b><?php echo $comment['poster']; ?></b> [<a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复该留言</a>]<br /><?php echo $comment['date']; ?><div class="comment-content"<?php if($comment['url']=='http://www.shuyong.net/'){?> style="color:#F00;"<?php }?>><?php echo $comment['content']; ?></div></div><?php blog_comments_children($comments, $comment['children']);?></div><?php endforeach; ?><?php }?>
<?php function syurl(){$url='<a href="http://www.shuyong.net">舍力博客</a>'; echo $url;}?>
<?php //blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){if($allow_remark == 'y'): ?>
<div id="comment-place"><div class="comment-post" id="comment-post"><div class="cancel-reply" id="cancel-reply" style="display:none"><a href="javascript:void(0);" onclick="cancelReply()">取消回复</a></div>
<p class="comment-header"><b>留言/评论：◎欢迎参与讨论，请在这里发表您的看法、交流您的观点。</b><a name="respond"></a></p>
<form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
<div class="comxx"><div id="comname"><p>昵称</p><input type="text" name="comname" maxlength="49" value="<?php echo $ckname; ?>" size="22" tabindex="1" placeholder="必填项"></div>
<div id="commail"><p>邮箱</p><input type="text" name="commail"  maxlength="128"  value="<?php echo $ckmail; ?>" size="22" tabindex="2" placeholder="必填项,正确的邮箱地址"></div>
<div id="comurl"><p>网址</p><input type="text" name="comurl" maxlength="128"  value="<?php echo $ckurl; ?>" size="22" tabindex="3" placeholder="选填项"></div></div>
<p id="comnr"><textarea name="comment" id="comment" rows="10" tabindex="4" class="comnr"></textarea></p>
<p><?php echo $verifyCode; ?> <input type="submit" id="comment_submit" value="发表评论" tabindex="6" />
<label for="sheli"><input type="checkbox" value=9 id="sheli" name="sheli" required="required" autocomplete="on" required title="发表评论确认框：请勾选我再发表评论！"> <font color="red">请勾选我再发表评论！</font></label></p>
<input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/></form></div></div><?php endif; ?><?php }?>

<?php
//blog-tool:获取Gravatar头像
function myGravatar($email, $s = 40, $d = 'mm', $g = 'g') {
$hash = md5($email);
$avatar = "http://cn.gravatar.com/avatar/$hash?s=$s&d=$d&r=$g";
return $avatar;
}?>
<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>
<?php
//全局匹配正文中的图片并存入imgsrc中
function img_zw($content){preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $content, $img);$imgsrc = !empty($img[1]) ? $img[1][0] : '';if($imgsrc):return $imgsrc;endif;}
//Custom: 获取附件第一张图片
function img_fj($logid){$db = MySql::getInstance();$sql = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$logid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";$imgs = $db->query($sql);$img_path = "";while($row = $db->fetch_array($imgs)){$img_path .= BLOG_URL.substr($row['filepath'],3,strlen($row['filepath']));}
return $img_path;}?>