<?php
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(


'logo' => array(
'type' =>'image',
'name' =>'logo图片',
'values' => array(TEMPLATE_URL .'images/logo.png',
),
'description' =>'设置站点头部图片,固定尺寸：205*60px。',
),

'flash1' => array(
'type' =>'image',
'name' =>'flash1',
'values' => array(TEMPLATE_URL .'images/flash1.jpg',
),
'description' =>'设置导航下图片,尺寸：800*370px。',
),

'flash2' => array(
'type' =>'image',
'name' =>'flash1',
'values' => array(TEMPLATE_URL .'images/flash2.jpg',
),
'description' =>'设置导航下图片,尺寸：800*370px。',
),

'flash3' => array(
'type' =>'image',
'name' =>'flash1',
'values' => array(TEMPLATE_URL .'images/flash3.jpg',
),
'description' =>'设置导航下图片,尺寸：800*370px。',
),









);