<div id="main">
  <div id="content-box">
  <div id="content">
    <div class="place">	当前位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &rsaquo; <?php echo $log_title; ?></div>
<article role="article">
    <div id="article" class="post-3165 post type-post status-publish format-standard has-post-thumbnail hentry category-product">
<h1 class="article-title post-title"><?php echo $log_title; ?></h1>
<div class="article-content"><?php echo $log_content; ?></div>
<div class="sy"><?php blog_comments($comments,$params);blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?></div></div>
    </article>
  </div>
  </div>
<aside role="sidebar"><div id="sidebar"><?php include View::getView('side');?></div></div></aside></div>
<?php include View::getView('footer');?>