<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
// 感谢您使用我制作的模板主题,请您保留作者链接,如有需要欢迎到我博客交换友链.
?>
        <div id="footer">
            <div class="footer-holder">
                <div class="programms">
                    <span>QZGROW IS <br />
                        QZZ WITH
                    </span>
                    <ul>
                        <li><a href="http://www.html5.com/" target="_blank"><img title="基于HTML5" src="<?php echo TEMPLATE_URL; ?>growfiles/images/ico-html.png"  /></a></li>
                        <li><a href="http://www.emlog.net" target="_blank"><img title="Powered by emlog" src="<?php echo TEMPLATE_URL; ?>growfiles/images/ico-emlog.png" /></a></li>
                        <li><a href="<?php echo BLOG_URL; ?>"><img title="[<?php echo $blogtitle; ?>]" src="<?php echo TEMPLATE_URL; ?>growfiles/images/ico-logo.png"  /></a></li>
                    </ul>
                </div>
                <div class="info-footer">
                    <p><a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>
					<?php echo $footer_info; ?></p>
                    <ul class="footer-menu">
                        <li>Theme by <a href="http://blog.qzee.net">qzz</a></li>
                    </ul>
                </div>
<?php include View::getView('lib/footermenu');?>
            </div>
        </div><!--底部 end-->
		<div style="display:none;">
		<script src="http://s24.cnzz.com/stat.php?id=3618614&web_id=3618614" language="JavaScript"></script>
		</div>
	<?php doAction('index_footer'); ?>
    </body>
</html>