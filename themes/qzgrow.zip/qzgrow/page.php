<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="post-block">
<?php include View::getView('lib/gallery'); ?>
<!--gallery end-->
<?php editflg($value['logid'],$value['author']); ?>
    <div class="info-area">
		<p><?php echo $log_content; ?></p>
		<p><?php blog_att($logid); ?></p><!--附件-->
    </div>
<!--内容结束-->

<a name="comments"></a>
<div class="comments-box">
    <div class="heading">
        <div class="box"><strong class="title">感谢您阅读:</strong>
            <p>《<?php echo $log_title; ?>》</p>
        </div>
        <a href="#comment" class="link">发表评论</a>	
    </div>
    <div class="section">
        <ol class="comments">
			<?php blog_comments($comments); ?>
        </ol>
	</div>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div><!--评论框架end-->
</div><!--文章内容end-->
</div><!--content文章全体构架-->
                <div id="sidebar">
                    <div class="logos">
					<img src="<?php echo TEMPLATE_URL; ?>growfiles/images/logo02.png" alt="image description" width="205" height="42" />
					</div>
                    <div class="side-block"><strong class="logo"><a href="<?php echo BLOG_URL; ?>">博客前传</a></strong>
                        <div class="comments-block">
                            <h2><a href="/"><?php echo $log_title; ?></a></h2>
                            <ul class="comments-list">
                                <li><strong class="title-date">DATE</strong>
            <span title="Post on <?php echo gmdate('Y-n-j G:i l', $date); ?>"><?php echo gmdate('M d,Y'); ?></span>
                                </li>
                                <li><strong class="title-comments">COMMENTS</strong>
                                <div class="comments"><a href="#comment" title="在《<?php echo $log_title; ?>》上的评论"><?php echo ($comnum); ?></a></div>
                                </li>
                                <li><strong class="title-posted">POSTED BY</strong>
                                <span><?php blog_author($author); ?> </span>
                                </li>
                            </ul>
                            <p>
<?php include View::getView('lib/sidepage'); ?>
                            </p>
                            <div class="read-holder">				<a href="/?post=4" class="read">READ IT</a>				<a href="/?post=4" class="read link-hover">READ IT</a>			</div>
                        </div>
                    </div><!--side-block 侧栏顶部模块结束-->
					<?php widget_sort($title);?>
					<?php widget_search($title);?>
					<?php widget_newcomm($title);?>
					<?php widget_archive($title);?>
					<?php widget_link($title);?>
<div id="clicki_widget_2431" title=""></div>
                    </div><!--end sidebar-->
            </div><!--w1 结束-->
        </div><!--wrapper 结束-->
<?php include View::getView('footer'); ?>