<?php
/*
Template Name:QzGrow 前传的形成
Description:HTML5模板 - 博客前传的成长之路，qzz 出品 ……
Author:qzz
Author Url:http://blog.qzee.net
Sidebar Amount:1
ForEmlog:4.1.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once (View::getView('module'));
?>
<!DOCTYPE HTML>
<html>
    <head profile="http://gmpg.org/xfn/11">
        <title><?php echo $blogtitle; ?></title>
        <meta charset="utf-8">
		<meta name="keywords" content="<?php echo $site_key; ?>" />
		<meta name="description" content="<?php echo $description; ?>" />
		<meta name="revised" content="qzz, 2012/1/1/" />
        <link rel="stylesheet" type="text/css" media="all" href="<?php echo TEMPLATE_URL; ?>growfiles/style.css"  />
        <link href="<?php echo TEMPLATE_URL; ?>growfiles/all.css" rel="stylesheet" type="text/css" media="all"/>
        <link href="<?php echo TEMPLATE_URL; ?>growfiles/images/favicon.ico" rel="shortcut icon" type="image/x-icon" />
        <link href='<?php echo TEMPLATE_URL; ?>growfiles/images/favicon.ico' rel='icon'/>
		<script src="https://libs.baidu.com/jquery/1.3.2/jquery.min.js"></script>
        <style type="text/css">
		li#menu-item-24 {display:none;}
		li#menu-item-17 {background: none !important;padding-left: 3px !important;}
		</style>
        <link href="<?php echo TEMPLATE_URL; ?>growfiles/contact-form-7.css" type="text/css" media="all" />
        <script type="text/javascript' src='<?php echo TEMPLATE_URL; ?>growfiles/js/l10n.js"></script>
		<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
        <script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>growfiles/js/comment-reply.js?ver=3.2.1'></script>
		<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
		<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
		<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<?php doAction('index_head'); ?>
        <link rel='index' title='Qzlog' href='http://blog.qzee.net/' />
        <script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>growfiles/js/jquery-1.6.1.min.js"></script>
        <script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>growfiles/js/jquery.main.js"></script>
<script type="text/javascript">
(function() {
	var c = document.createElement('script'); c.type = 'text/javascript'; c.async = true;
	c.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'www.clicki.cn/boot/44599';
	var h = document.getElementsByTagName('head')[0]; h.appendChild(c);
})();
jQuery(document).ready(function(){
jQuery('#tab-title span').click(function(){
	jQuery(this).addClass("selected").siblings().removeClass();
	jQuery("#tab-content > ul").slideUp('1500').eq(jQuery('#tab-title span').index(this)).slideDown('1500');
});
});
$(document).ready(function() {
$('h1 a').click(function(){
myloadoriginal = this.text;
$(this).text('加载中，请稍候...');
var myload = this;
setTimeout(function() { $(myload).text(myloadoriginal); }, 2012);
});
});
</script>
<?php //diyface();  ?>
    </head>
    <body>
        <div id="wrapper" ><!--end in side-->
            <div class="w1">
                <div id="content"><!--end in list-->
                    <ul id="nav" class="">
<?php include View::getView('lib/nav');?>
                    </ul>
<!--nav end-->