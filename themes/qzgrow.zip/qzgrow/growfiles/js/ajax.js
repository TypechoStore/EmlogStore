// JavaScript Document Ajax����
$(function(){
	$("#comment-post").submit(function(){
	var q = $("#comment-post").serialize();
		$("#comment").attr("disabled","disabled");
		$("#loading").show();
		$.post($("#comment-post").attr("action"),q,function(d){
			var reg = /<div class=\"main\">[\r\n]*<p>(.*?)<\/p>/i;
			if(reg.test(d)){
				$("#error").html(d.match(reg)[1]);
				$("#loading").hide();
			}else{
				var p = $("input[name=pid]").val();
				cancelReply();
				$("[name=comment]").val("");
				$("#com_ajax").html($(d).find("#com_ajax").html());
				$(".newcomment").html($(d).find(".newcomment").html());
			if(p != 0) {
				var body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body');
				body.animate({scrollTop: $("#comment-" + p).offset().top - 20},	"normal",function() {$("#loading").hide();});
				} else {
				var body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body');
				body.animate({scrollTop: $(".comment").offset().top - 20},	"normal",function() {$("#loading").hide();});
				}
			}
			$("#comment").attr("disabled",false);
		});
		return false;	})
		   });