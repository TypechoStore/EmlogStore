;(function($){
	//init page
	$(function(){
		initCarousel();
		initHaccordion();
		initHoverState();
		initHoverSocial();
	});
	//init carousel
	function initCarousel(){
		$('.gallery').scrollGallery({
			sliderHolder: '.mask',
			generatePagination:'.switcher-holder',
			pauseOnHover:true,
			autoRotation:true,
			switchTime:9000,
			duration:650
		});
	}
	//init hover state
	function initHoverState(){
		var nav = $('#nav'),
			links = nav.find('a'),
			slides = nav.find('span'),
			t,
			speed = 650;
		slides.css({top:'-171px'});
		links.hover(function(){
			var curSlide = $(this).find('span');
			if(t)clearTimeout(t);
			t = setTimeout(function(){
				curSlide.stop().animate({top: '-27px'}, {duration: 200, easing:"easeOutCubic", complete:function(){
					curSlide.animate({top: '-42px'}, {easing:"easeOutBack", duration:500}); 
				}});
			}, 450);
		}, function(){
			if(t)clearTimeout(t);
			var curSlide = $(this).find('span');
			curSlide.stop().animate({top: '-171px'}, {duration: 500, easing:"easeOutCubic", complete: function(){t = false;}});
		});
	}
	//init hover social
	function initHoverSocial(){
		var nav = $('.social'),
			links = nav.find('a'),
			nav2 = $('#nav'),
			links2 = nav2.find('a'),
			hold = $('.read-holder'),
			link = hold.find('.read'),
			hold2 = $('.info'),
			link2 = hold2.find('.link-form'),
			hold3 = $('.btn-holder'),
			link3 = hold3.find('.btn-view'),
			hold4 = $('.paging'),
			link4 = hold4.find('.prev'),
			link5 = hold4.find('.next'),
			speed = 1000;
		if($.browser.msie && $.browser.version < 9) {
			links.filter('.link-hover').hide();
			links2.find('.link-hover').hide().css('opacity', '');
			link.filter('.link-hover').hide().css('opacity', '');
			link2.filter('.link-hover').hide().css('opacity', '');
			link3.filter('.link-hover').hide().css('opacity', '');
			link4.filter('.link-hover').hide().css('opacity', '');
			link5.filter('.link-hover').hide();
			links.hover(function(){
				var curLink = $(this).parent().find('.link-hover');
				curLink.show();
			}, function(){
				var curLink = $(this).parent().find('.link-hover');
				curLink.hide();
			});
			links2.hover(function(){
				var curLink = $(this).find('.link-hover');
				curLink.show();
			}, function(){
				var curLink = $(this).find('.link-hover');
				curLink.hide();
			});
			link.hover(function(){
				var curLink = $(this).parent().find('.link-hover');
				curLink.show();
			}, function(){
				var curLink = $(this).parent().find('.link-hover');
				curLink.hide();
			});
			link2.hover(function(){
				var curLink = $(this).parent().find('.link-hover');
				curLink.show();
			}, function(){
				var curLink = $(this).parent().find('.link-hover');
				curLink.hide();
			});
			link3.hover(function(){
				var curLink = $(this).parent().find('.link-hover');
				curLink.show();
			}, function(){
				var curLink = $(this).parent().find('.link-hover');
				curLink.hide();
			});
			link4.hover(function(){
				var curLink = $(this).parent().find('.prev.link-hover');
				curLink.show();
			}, function(){
				var curLink = $(this).parent().find('.prev.link-hover');
				curLink.hide();
			});
			link5.hover(function(){
				var curLink = $(this).parent().find('.next.link-hover');
				curLink.show();
			}, function(){
				var curLink = $(this).parent().find('.next.link-hover');
				curLink.hide();
			});
		}else {
			links.hover(function(){
				var curLink = $(this).parent().find('.link-hover');
				curLink.stop().animate({opacity: 1}, {duration: 400});
			}, function(){
				var curLink = $(this).parent().find('.link-hover');
				curLink.stop().animate({opacity: 0}, {duration: speed});
			});
		
			links2.hover(function(){
				var curLink = $(this).find('.link-hover');
				curLink.stop().animate({opacity: 1}, {duration: 400});
			}, function(){
				var curLink = $(this).find('.link-hover');
				curLink.stop().animate({opacity: 0}, {duration: speed});
			});
			link.hover(function(){
				var curLink = $(this).parent().find('.link-hover');
				curLink.stop().animate({opacity: 1}, {duration: 400});
			}, function(){
				var curLink = $(this).parent().find('.link-hover');
				curLink.stop().animate({opacity: 0}, {duration: speed});
			});
			link2.hover(function(){
				var curLink = $(this).parent().find('.link-hover');
				curLink.stop().animate({opacity: 1}, {duration: 400});
			}, function(){
				var curLink = $(this).parent().find('.link-hover');
				curLink.stop().animate({opacity: 0}, {duration: speed});
			});
			link3.hover(function(){
				var curLink = $(this).parent().find('.link-hover');
				curLink.stop().animate({opacity: 1}, {duration: 400});
			}, function(){
				var curLink = $(this).parent().find('.link-hover');
				curLink.stop().animate({opacity: 0}, {duration: speed});
			});
			link4.hover(function(){
				var curLink = $(this).parent().find('.prev.link-hover');
				curLink.stop().animate({opacity: 1}, {duration: 400});
			}, function(){
				var curLink = $(this).parent().find('.prev.link-hover');
				curLink.stop().animate({opacity: 0}, {duration: speed});
			});
			link5.hover(function(){
				var curLink = $(this).parent().find('.next.link-hover');
				curLink.stop().animate({opacity: 1}, {duration: 400});
			}, function(){
				var curLink = $(this).parent().find('.next.link-hover');
				curLink.stop().animate({opacity: 0}, {duration: speed});
			});
		}
	}
	//init horizontal accordion
	function initHaccordion(){
		var speed = 200,
			t;
		$('.accordion').each(function(){
			var hold = $(this),
				links = hold.find('a'),
				items = hold.find('li');
				
			items.css({width:links.width()});
			items.mouseenter(function(){
				if (!t){
					t = true;
					$(this).stop().animate({width: '214px'}, {duration: speed});
					$(this).find('.block').stop().animate({width: '194px'}, {duration: speed,complete:function(){
						t = false;
						$(this).parents('li').eq(0).addClass('active');
					}});
					items.filter('.active').stop().animate({width:links.width()},{duration: speed});
					items.not($(this)).filter('.active').find('.block').stop().animate({width:0},{duration: speed,complete:function(){
						$(this).parents('li').eq(0).removeClass('active');
					}});
				}
			});
			hold.mouseleave(function(){
				setTimeout(function(){
					items.filter('.active').stop().animate({width:links.width()},{duration: speed});
					items.filter('.active').find('.block').stop().animate({width:0},{duration: speed,complete:function(){
							$(this).parents('li').eq(0).removeClass('active');
							t = false;
					}});
				},400);
			});
		});
	}
	// scrolling gallery plugin
	jQuery.fn.scrollGallery = function(_options){
		var _options = jQuery.extend({
			sliderHolder: '>div',
			slider:'>ul',
			slides: '>li',
			pagerLinks:'div.pager a',
			btnPrev:'a.link-prev',
			btnNext:'a.link-next',
			activeClass:'active',
			disabledClass:'disabled',
			generatePagination:'div.pg-holder',
			curNum:'em.scur-num',
			allNum:'em.sall-num',
			circleSlide:true,
			pauseClass:'gallery-paused',
			pauseButton:'none',
			pauseOnHover:true,
			autoRotation:false,
			stopAfterClick:false,
			switchTime:5000,
			duration:650,
			easing:'swing',
			event:'click',
			splitCount:false,
			afterInit:false,
			vertical:false,
			step:false
		},_options);

		return this.each(function(){
			// gallery options
			var _this = jQuery(this);
			var _sliderHolder = jQuery(_options.sliderHolder, _this);
			var _slider = jQuery(_options.slider, _sliderHolder);
			var _slides = jQuery(_options.slides, _slider);
			var _btnPrev = jQuery(_options.btnPrev, _this);
			var _btnNext = jQuery(_options.btnNext, _this);
			var _pagerLinks = jQuery(_options.pagerLinks, _this);
			var _generatePagination = jQuery(_options.generatePagination, _this);
			var _curNum = jQuery(_options.curNum, _this);
			var _allNum = jQuery(_options.allNum, _this);
			var _pauseButton = jQuery(_options.pauseButton, _this);
			var _pauseOnHover = _options.pauseOnHover;
			var _pauseClass = _options.pauseClass;
			var _autoRotation = _options.autoRotation;
			var _activeClass = _options.activeClass;
			var _disabledClass = _options.disabledClass;
			var _easing = _options.easing;
			var _duration = _options.duration;
			var _switchTime = _options.switchTime;
			var _controlEvent = _options.event;
			var _step = _options.step;
			var _vertical = _options.vertical;
			var _circleSlide = _options.circleSlide;
			var _stopAfterClick = _options.stopAfterClick;
			var _afterInit = _options.afterInit;
			var _splitCount = _options.splitCount;

			// gallery init
			if(!_slides.length) return;

			if(_splitCount) {
				var curStep = 0;
				var newSlide = $('<slide>').addClass('split-slide');
				_slides.each(function(){
					newSlide.append(this);
					curStep++;
					if(curStep > _splitCount-1) {
						curStep = 0;
						_slider.append(newSlide);
						newSlide = $('<slide>').addClass('split-slide');
					}
				});
				if(curStep) _slider.append(newSlide);
				_slides = _slider.children();
			}

			var _currentStep = 0;
			var _sumWidth = 0;
			var _sumHeight = 0;
			var _hover = false;
			var _stepWidth;
			var _stepHeight;
			var _stepCount;
			var _offset;
			var _timer;

			_slides.each(function(){
				_sumWidth+=$(this).outerWidth(true);
				_sumHeight+=$(this).outerHeight(true);
			});

			// calculate gallery offset
			function recalcOffsets() {
				if(_vertical) {
					if(_step) {
						_stepHeight = _slides.eq(_currentStep).outerHeight(true);
						_stepCount = Math.ceil((_sumHeight-_sliderHolder.height())/_stepHeight)+1;
						_offset = -_stepHeight*_currentStep;
					} else {
						_stepHeight = _sliderHolder.height();
						_stepCount = Math.ceil(_sumHeight/_stepHeight);
						_offset = -_stepHeight*_currentStep;
						if(_offset < _stepHeight-_sumHeight) _offset = _stepHeight-_sumHeight;
					}
				} else {
					if(_step) {
						_stepWidth = _slides.eq(_currentStep).outerWidth(true)*_step;
						_stepCount = Math.ceil((_sumWidth-_sliderHolder.width())/_stepWidth)+1;
						_offset = -_stepWidth*_currentStep;
						if(_offset < _sliderHolder.width()-_sumWidth) _offset = _sliderHolder.width()-_sumWidth;
					} else {
						_stepWidth = _sliderHolder.width();
						_stepCount = Math.ceil(_sumWidth/_stepWidth);
						_offset = -_stepWidth*_currentStep;
						if(_offset < _stepWidth-_sumWidth) _offset = _stepWidth-_sumWidth;
						if(_sumWidth < _stepWidth) _offset = 0;
					}
				}
			}

			// gallery control
			if(_btnPrev.length) {
				_btnPrev.bind(_controlEvent,function(){
					if(_stopAfterClick) stopAutoSlide();
					prevSlide();
					return false;
				});
			}
			if(_btnNext.length) {
				_btnNext.bind(_controlEvent,function(){
					if(_stopAfterClick) stopAutoSlide();
					nextSlide();
					return false;
				});
			}
			if(_generatePagination.length) {
				_generatePagination.empty();
				recalcOffsets();
				var _list = $('<ul class="switcher" />');
				for(var i=0; i<_stepCount; i++) $('<li><a href="#">'+(i+1)+'</a></li>').appendTo(_list);
				_list.appendTo(_generatePagination);
				_pagerLinks = _list.children();
			}
			if(_pagerLinks.length) {
				_pagerLinks.each(function(_ind){
					jQuery(this).bind(_controlEvent,function(){
						if(_currentStep != _ind) {
							if(_stopAfterClick) stopAutoSlide();
							_currentStep = _ind;
							switchSlide();
						}
						return false;
					});
				});
			}

			// gallery animation
			function prevSlide() {
				recalcOffsets();
				if(_currentStep > 0) _currentStep--;
				else if(_circleSlide) _currentStep = _stepCount-1;
				switchSlide();
			}
			function nextSlide() {
				recalcOffsets();
				if(_currentStep < _stepCount-1) _currentStep++;
				else if(_circleSlide) _currentStep = 0;
				switchSlide();
			}
			function refreshStatus() {
				if(_pagerLinks.length) _pagerLinks.removeClass(_activeClass).eq(_currentStep).addClass(_activeClass);
				if(!_circleSlide) {
					_btnPrev.removeClass(_disabledClass);
					_btnNext.removeClass(_disabledClass);
					if(_currentStep == 0) _btnPrev.addClass(_disabledClass);
					if(_currentStep == _stepCount-1) _btnNext.addClass(_disabledClass);
				}
				if(_curNum.length) _curNum.text(_currentStep+1);
				if(_allNum.length) _allNum.text(_stepCount);
			}
			function switchSlide() {
				recalcOffsets();
				if(_vertical) _slider.animate({marginTop:_offset},{duration:_duration,queue:false,easing:_easing});
				else _slider.animate({marginLeft:_offset},{duration:_duration,queue:false,easing:_easing});
				refreshStatus();
				autoSlide();
			}

			// autoslide function
			function stopAutoSlide() {
				if(_timer) clearTimeout(_timer);
				_autoRotation = false;
			}
			function autoSlide() {
				if(!_autoRotation || _hover) return;
				if(_timer) clearTimeout(_timer);
				_timer = setTimeout(nextSlide,_switchTime+_duration);
			}
			if(_pauseOnHover) {
				_this.hover(function(){
					_hover = true;
					if(_timer) clearTimeout(_timer);
				},function(){
					_hover = false;
					autoSlide();
				});
			}
			recalcOffsets();
			refreshStatus();
			autoSlide();

			// pause buttton
			if(_pauseButton.length) {
				_pauseButton.click(function(){
					if(_this.hasClass(_pauseClass)) {
						_this.removeClass(_pauseClass);
						_autoRotation = true;
						autoSlide();
					} else {
						_this.addClass(_pauseClass);
						stopAutoSlide();
					}
					return false;
				});
			}

			if(_afterInit && typeof _afterInit === 'function') _afterInit(_this, _slides);
		});
	}
	// mobile browsers detect
	browserPlatform = {
		platforms: [
			{
				// Blackberry <5
				uaString:['BlackBerry','midp'],
				cssFile:'blackberry.css'
			},
			{
				// Symbian phones
				uaString:['symbian','midp'],
				cssFile:'symbian.css'
			},
			{
				// Opera Mobile
				uaString:['opera','mobi'],
				cssFile:'opera.css'
			},
			{
				// IE Mobile <6
				uaString:['msie','ppc'],
				cssFile:'ieppc.css'
			},
			{
				// IE Mobile 6+
				uaString:'iemobile',
				cssFile:'iemobile.css'
			},
			{
				// Palm WebOS
				uaString:'webos',
				cssFile:'webos.css'
			},
			{
				// Android
				uaString:'Android',
				cssFile:'android.css'
			},
			{
				// Blackberry 6+
				uaString:['BlackBerry','6.0','mobi'],
				cssFile:'blackberry6.0.css'
			},
			{
				// iPad
				uaString:'ipad',
				cssFile:'ipad.css',
				miscHead:''
			},
			{
				// iPhone and other webkit browsers
				uaString:['safari','mobi'],
				cssFile:'safari.css',
				miscHead:''
			}
		],
		options: {
			cssPath:'css/',
			mobileCSS:'allmobile.css'
		},
		init:function(){
			this.checkMobile();
			this.parsePlatforms();
			return this;
		},
		checkMobile: function() {
			if(this.uaMatch('mobi') || this.uaMatch('midp') || this.uaMatch('ppc') || this.uaMatch('webos')) {
				this.attachStyles({cssFile:this.options.mobileCSS});
			}
		},
		parsePlatforms: function() {
			for(var i = 0; i < this.platforms.length; i++) {
				if(typeof this.platforms[i].uaString === 'string') {
					if(this.uaMatch(this.platforms[i].uaString)) {
						this.attachStyles(this.platforms[i]);
						break;
					}
				} else {
					for(var j = 0, allMatch = true; j < this.platforms[i].uaString.length; j++) {
						if(!this.uaMatch(this.platforms[i].uaString[j])) {
							allMatch = false;
						}
					}
					if(allMatch) {
						this.attachStyles(this.platforms[i]);
						break;
					}
				}
			}
		},
		attachStyles: function(platform) {
			if(platform.cssFile) {
				document.write('<link rel="stylesheet" href="' + this.options.cssPath + platform.cssFile + '" type="text/css"/>');
			}
			if(platform.miscHead) {
				document.write(platform.miscHead);
			}
		},
		uaMatch:function(str) {
			if(!this.ua) {
				this.ua = navigator.userAgent.toLowerCase();
			}
			return this.ua.indexOf(str.toLowerCase()) != -1;
		}
	}.init();
	/*
	 * jQuery Easing v1.3 - http://gsgd.co.uk/sandbox/jquery/easing/
	 *
	 * Uses the built in easing capabilities added In jQuery 1.1
	 * to offer multiple easing options
	 *
	 * TERMS OF USE - jQuery Easing
	 * 
	 * Open source under the BSD License. 
	 * 
	 * Copyright © 2008 George McGinley Smith
	 * All rights reserved.
	 * 
	 * Redistribution and use in source and binary forms, with or without modification, 
	 * are permitted provided that the following conditions are met:
	 * 
	 * Redistributions of source code must retain the above copyright notice, this list of 
	 * conditions and the following disclaimer.
	 * Redistributions in binary form must reproduce the above copyright notice, this list 
	 * of conditions and the following disclaimer in the documentation and/or other materials 
	 * provided with the distribution.
	 * 
	 * Neither the name of the author nor the names of contributors may be used to endorse 
	 * or promote products derived from this software without specific prior written permission.
	 * 
	 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
	 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
	 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
	 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
	 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
	 *  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
	 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
	 *  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
	 * OF THE POSSIBILITY OF SUCH DAMAGE. 
	 *
	*/

	// t: current time, b: begInnIng value, c: change In value, d: duration
	jQuery.easing['jswing'] = jQuery.easing['swing'];

	jQuery.extend( jQuery.easing,
	{
		def: 'easeOutQuad',
		swing: function (x, t, b, c, d) {
			//alert(jQuery.easing.default);
			return jQuery.easing[jQuery.easing.def](x, t, b, c, d);
		},
		easeInQuad: function (x, t, b, c, d) {
			return c*(t/=d)*t + b;
		},
		easeOutQuad: function (x, t, b, c, d) {
			return -c *(t/=d)*(t-2) + b;
		},
		easeInOutQuad: function (x, t, b, c, d) {
			if ((t/=d/2) < 1) return c/2*t*t + b;
			return -c/2 * ((--t)*(t-2) - 1) + b;
		},
		easeInCubic: function (x, t, b, c, d) {
			return c*(t/=d)*t*t + b;
		},
		easeOutCubic: function (x, t, b, c, d) {
			return c*((t=t/d-1)*t*t + 1) + b;
		},
		easeInOutCubic: function (x, t, b, c, d) {
			if ((t/=d/2) < 1) return c/2*t*t*t + b;
			return c/2*((t-=2)*t*t + 2) + b;
		},
		easeInQuart: function (x, t, b, c, d) {
			return c*(t/=d)*t*t*t + b;
		},
		easeOutQuart: function (x, t, b, c, d) {
			return -c * ((t=t/d-1)*t*t*t - 1) + b;
		},
		easeInOutQuart: function (x, t, b, c, d) {
			if ((t/=d/2) < 1) return c/2*t*t*t*t + b;
			return -c/2 * ((t-=2)*t*t*t - 2) + b;
		},
		easeInQuint: function (x, t, b, c, d) {
			return c*(t/=d)*t*t*t*t + b;
		},
		easeOutQuint: function (x, t, b, c, d) {
			return c*((t=t/d-1)*t*t*t*t + 1) + b;
		},
		easeInOutQuint: function (x, t, b, c, d) {
			if ((t/=d/2) < 1) return c/2*t*t*t*t*t + b;
			return c/2*((t-=2)*t*t*t*t + 2) + b;
		},
		easeInSine: function (x, t, b, c, d) {
			return -c * Math.cos(t/d * (Math.PI/2)) + c + b;
		},
		easeOutSine: function (x, t, b, c, d) {
			return c * Math.sin(t/d * (Math.PI/2)) + b;
		},
		easeInOutSine: function (x, t, b, c, d) {
			return -c/2 * (Math.cos(Math.PI*t/d) - 1) + b;
		},
		easeInExpo: function (x, t, b, c, d) {
			return (t==0) ? b : c * Math.pow(2, 10 * (t/d - 1)) + b;
		},
		easeOutExpo: function (x, t, b, c, d) {
			return (t==d) ? b+c : c * (-Math.pow(2, -10 * t/d) + 1) + b;
		},
		easeInOutExpo: function (x, t, b, c, d) {
			if (t==0) return b;
			if (t==d) return b+c;
			if ((t/=d/2) < 1) return c/2 * Math.pow(2, 10 * (t - 1)) + b;
			return c/2 * (-Math.pow(2, -10 * --t) + 2) + b;
		},
		easeInCirc: function (x, t, b, c, d) {
			return -c * (Math.sqrt(1 - (t/=d)*t) - 1) + b;
		},
		easeOutCirc: function (x, t, b, c, d) {
			return c * Math.sqrt(1 - (t=t/d-1)*t) + b;
		},
		easeInOutCirc: function (x, t, b, c, d) {
			if ((t/=d/2) < 1) return -c/2 * (Math.sqrt(1 - t*t) - 1) + b;
			return c/2 * (Math.sqrt(1 - (t-=2)*t) + 1) + b;
		},
		easeInElastic: function (x, t, b, c, d) {
			var s=1.70158;var p=0;var a=c;
			if (t==0) return b;  if ((t/=d)==1) return b+c;  if (!p) p=d*.3;
			if (a < Math.abs(c)) { a=c; var s=p/4; }
			else var s = p/(2*Math.PI) * Math.asin (c/a);
			return -(a*Math.pow(2,10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )) + b;
		},
		easeOutElastic: function (x, t, b, c, d) {
			var s=1.70158;var p=0;var a=c;
			if (t==0) return b;  if ((t/=d)==1) return b+c;  if (!p) p=d*.3;
			if (a < Math.abs(c)) { a=c; var s=p/4; }
			else var s = p/(2*Math.PI) * Math.asin (c/a);
			return a*Math.pow(2,-10*t) * Math.sin( (t*d-s)*(2*Math.PI)/p ) + c + b;
		},
		easeInOutElastic: function (x, t, b, c, d) {
			var s=1.70158;var p=0;var a=c;
			if (t==0) return b;  if ((t/=d/2)==2) return b+c;  if (!p) p=d*(.3*1.5);
			if (a < Math.abs(c)) { a=c; var s=p/4; }
			else var s = p/(2*Math.PI) * Math.asin (c/a);
			if (t < 1) return -.5*(a*Math.pow(2,10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )) + b;
			return a*Math.pow(2,-10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )*.5 + c + b;
		},
		easeInBack: function (x, t, b, c, d, s) {
			if (s == undefined) s = 1.70158;
			return c*(t/=d)*t*((s+1)*t - s) + b;
		},
		easeOutBack: function (x, t, b, c, d, s) {
			if (s == undefined) s = 1.70158;
			return c*((t=t/d-1)*t*((s+1)*t + s) + 1) + b;
		},
		easeInOutBack: function (x, t, b, c, d, s) {
			if (s == undefined) s = 1.70158; 
			if ((t/=d/2) < 1) return c/2*(t*t*(((s*=(1.525))+1)*t - s)) + b;
			return c/2*((t-=2)*t*(((s*=(1.525))+1)*t + s) + 2) + b;
		},
		easeInBounce: function (x, t, b, c, d) {
			return c - jQuery.easing.easeOutBounce (x, d-t, 0, c, d) + b;
		},
		easeOutBounce: function (x, t, b, c, d) {
			if ((t/=d) < (1/2.75)) {
				return c*(7.5625*t*t) + b;
			} else if (t < (2/2.75)) {
				return c*(7.5625*(t-=(1.5/2.75))*t + .75) + b;
			} else if (t < (2.5/2.75)) {
				return c*(7.5625*(t-=(2.25/2.75))*t + .9375) + b;
			} else {
				return c*(7.5625*(t-=(2.625/2.75))*t + .984375) + b;
			}
		},
		easeInOutBounce: function (x, t, b, c, d) {
			if (t < d/2) return jQuery.easing.easeInBounce (x, t*2, 0, c, d) * .5 + b;
			return jQuery.easing.easeOutBounce (x, t*2-d, 0, c, d) * .5 + c*.5 + b;
		}
	});

	/*
	 *
	 * TERMS OF USE - EASING EQUATIONS
	 * 
	 * Open source under the BSD License. 
	 * 
	 * Copyright © 2001 Robert Penner
	 * All rights reserved.
	 * 
	 * Redistribution and use in source and binary forms, with or without modification, 
	 * are permitted provided that the following conditions are met:
	 * 
	 * Redistributions of source code must retain the above copyright notice, this list of 
	 * conditions and the following disclaimer.
	 * Redistributions in binary form must reproduce the above copyright notice, this list 
	 * of conditions and the following disclaimer in the documentation and/or other materials 
	 * provided with the distribution.
	 * 
	 * Neither the name of the author nor the names of contributors may be used to endorse 
	 * or promote products derived from this software without specific prior written permission.
	 * 
	 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
	 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
	 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
	 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
	 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
	 *  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
	 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
	 *  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
	 * OF THE POSSIBILITY OF SUCH DAMAGE. 
	 *
	 */
})(jQuery);