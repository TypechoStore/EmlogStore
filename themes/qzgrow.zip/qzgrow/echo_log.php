<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="post-block">
    <div class="info-posts">
    <h1><?php topflg($top); ?><?php echo $log_title; ?></h1>
        <ul>
            <li class="col1"><strong class="title">DATE</strong>
            <span title="Post on <?php echo gmdate('Y-n-j G:i l', $date); ?>"><?php echo gmdate('M d,Y', $date); ?></span>
            </li>
            <li class="col2"><strong class="title">COMMENTS</strong>
			<a href="#comment" title="在《<?php echo $log_title; ?>》上的评论"><?php echo ($comnum); ?></a></li>
            <li class="col3"><strong class="title">CATEGROY</strong>
            <span><?php blog_sort($logid); ?></span>
            </li>
            <li class="col4"><strong class="title">
            <span class="rss">RSS</span>
            </strong><a href="<?php echo $value['log_url']; ?>rss.php">Subscribe</a></li>
        </ul>
    </div><!--info-posts end-->
    <div class="category">
            	<!--标签-->
                <div class="tag-list">
<?php blog_tag($logid); ?>
                </div> 
				<div class="bshare-custom"><a title="分享到新浪微博" class="bshare-sinaminiblog" href="javascript:void(0);"></a><a title="分享到腾讯微博" class="bshare-qqmb" href="javascript:void(0);"></a><a title="分享到Twitter" class="bshare-twitter" href="javascript:void(0);"></a><a title="分享到Facebook" class="bshare-facebook" href="javascript:void(0);"></a><a title="分享到Tumblr" class="bshare-tumblr" href="javascript:void(0);"></a><a title="分享到收藏夹" class="bshare-favorite" href="javascript:void(0);"></a><a title="分享到QQ空间" class="bshare-qzone" href="javascript:void(0);"></a><a title="更多平台" class="bshare-more bshare-more-icon more-style-addthis"></a><span class="BSHARE_COUNT bshare-share-count">0</span></div><script type="text/javascript" charset="utf-8" src="http://static.bshare.cn/b/button.js#style=-1&amp;uuid=eb6ed31a-0f21-49da-b113-ab0ce04e1a8b&amp;pophcol=2&amp;lang=zh"></script><script type="text/javascript" charset="utf-8" src="http://static.bshare.cn/b/bshareC0.js"></script>
        <?php editflg($logid,$author); ?>
    </div>
    <div class="info-area">
		<p><?php echo $log_content; ?></p>
		<div class="post-block"></div>
		<p><?php blog_att($logid); ?></p><!--附件-->
    </div>
	<!--内容结束-->
	<?php doAction('log_related', $logData); ?>
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>

<a name="comments"></a>
<div class="comments-box">
    <div class="heading">
        <div class="box"><strong class="title">感谢您阅读:</strong>
            <p>《<?php echo $log_title; ?>》</p>
        </div>
        <a href="#comment" class="link">发表评论</a>	
    </div>
    <div class="section">
        <ol class="comments">
			<?php blog_comments($comments); ?>
        </ol>
	</div>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div><!--评论框架end-->
</div>	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
</div><!--文章结束-->

<!--end content-->
<?php 
include View::getView('side');
include View::getView('footer'); 
?>