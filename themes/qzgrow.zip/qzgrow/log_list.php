<?php 
/*
* 首页日志列表部分 
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<div class="post-block">
    <div class="info-posts">
    <h1><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h1>
        <ul>
            <li class="col1"><strong class="title">DATE</strong>
            <span title="Post on <?php echo gmdate('Y-n-j G:i l', $value['date']); ?>"><?php echo gmdate('M d,Y', $value['date']); ?></span>
            </li>
            <li class="col2"><strong class="title">COMMENTS</strong>
			<a href="<?php echo $value['log_url']; ?>#comment" title="在《<?php echo $value['log_title']; ?>》上的评论"><?php echo $value['comnum']; ?></a></li>
            <li class="col3"><strong class="title">CATEGROY</strong>
            <span><?php blog_sort($value['logid']); ?> </span>
            </li>
            <li class="col4"><strong class="title">
            <span class="rss">RSS</span>
            </strong><a href="<?php echo $value['log_url']; ?>rss.php">Subscribe</a></li>
        </ul>
    </div><!--info-posts end-->
    <div class="category">
        <p>Views: <a href="<?php echo $value['log_url']; ?>" rel="tag"><?php echo $value['views']; ?></a> 
		| Trackback: <a href="<?php echo $value['log_url']; ?>#tb"><?php echo $value['tbcount']; ?></a>
		<?php editflg($value['logid'],$value['author']); ?></p>
    </div>
    <div class="info-area">
        <p><?php echo $value['log_description']; ?></p>
    </div>
    <div class="read-holder">
		<a href="<?php echo $value['log_url']; ?>" class="read">READ IT</a>
		<a href="<?php echo $value['log_url']; ?>" class="read link-hover">READ IT</a>
	</div>
</div><?php endforeach; ?><!--文章内容+循环结束-->
	<div class="navigation">
		<?php echo $page_url;?>
	</div>
</div><!--content文章全体构架-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>