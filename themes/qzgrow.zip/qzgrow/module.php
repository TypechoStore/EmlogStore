<?php 
/*
* 侧边栏组件、页面模块
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//分类调用
function menu_sort($class){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	
	<?php foreach($sort_cache as $value): ?>
	 <li class="cat-<?php echo $class; ?>-<?php echo $value['sid']; ?>">
	<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?></a>
	</li>
	<?php endforeach; ?>

<?php }?>

<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
	<li>
	<h3><span onclick="showhidediv('bloggerinfo')"><?php echo $title; ?></span></h3>
	<ul style="text-align:center" id="bloggerinfo">
	<div id="bloggerinfoimg">
	<?php if (!empty($user_cache[1]['photo']['src'])): ?>
	<img src="<?php echo $user_cache[1]['photo']['src']; ?>" width="<?php echo $user_cache[1]['photo']['width']; ?>" height="<?php echo $user_cache[1]['photo']['height']; ?>" alt="blogger" />
	<?php endif;?>
	</div>
	<li><b><?php echo $name; ?></b></li>
	<li><?php echo $user_cache[1]['des']; ?></li>
	</ul>
	</li>
<?php }?>
<?php
//widget：日历
function widget_calendar($title){ ?>
                    <div id="categories-4" class="side-block">
                        <div class="holder">
                            <h3><?php echo $title; ?></h3>
	<div id="calendar">
	<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
	</div>
                        </div>
                    </div>

<?php }?>
<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
                    <div id="categories-4" class="side-block">
                        <div class="holder">
                            <h3>Tag 标签</h3>
                            <ul id="tag">
	<?php foreach($tag_cache as $value): ?>
		<span style="font-size:<?php echo $value['fontsize']; ?>pt; height:30px;">
		<a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇日志"><?php echo $value['tagname']; ?></a></span>
	<?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
                    <div id="categories-4" class="side-block">
                        <div class="holder">
                            <h3>分类</h3>
                            <ul>
	<?php foreach($sort_cache as $value): ?>
                                <li class="cat-item cat-item-20"><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a><a href="<?php echo BLOG_URL; ?>rss.php?sort=<?php echo $value['sid']; ?>" title="订阅该分类RSS"> <img align="absmiddle" src="<?php echo TEMPLATE_URL; ?>growfiles/images/icon_rss.gif" alt="订阅该分类RSS"/></a></li>
	<?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
<?php }?>
<?php
//widget：最新碎语
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter'); ?>
                    <div id="custom_twitter_widget-4" class="side-block">
                        <div class="holder">
                            <h3><?php echo $title; ?></h3>
                            <div class="twitter-message">
<?php foreach($newtws_cache as $value): ?>
                                <p><a href="<?php echo BLOG_URL . 't/'; ?>" class="twitter-link">“<?php echo $value['t']; ?>...”
                                <span class="mark">on <?php echo smartDate($value['date']); ?></span>
                                </a></p>
<?php endforeach; ?>
                            </div>
                        </div>
                    </div>

<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
                    <div id="custom_twitter_widget-4" class="side-block">
                        <div class="holder">
                            <h3>最新评论</h3>
                            <div class="twitter-message">
	<?php
	foreach($com_cache as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	?>
                                <p><a href="<?php echo $url; ?>" class="twitter-link">“<?php echo $value['content']; ?>...”
                                <span class="mark">by <?php echo $value['name']; ?> @<?php echo smartDate($value['date']); ?></span>
                                </a></p>
	<?php endforeach; ?>
                            </div>
                        </div>
                    </div>
<?php }?>
<?php
//widget：最新日志
function widget_newlog($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
                    <div id="archives-4" class="side-block">
                        <div class="holder recent-posts" style="margin-top:-60px;">
                            <h3><?php echo $title; ?></h3>
                            <div class="table">
                                <table>
	<?php foreach($newLogs_cache as $value): ?>
                                    <tr>
                                        <td class="col1"><a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>"><?php echo $value['title']; ?></a></td>
                                        <?//
										//由于获取不到时间所以取消了
										//如果你有更好的方法麻烦您告诉我一声：
										//a@aapp.cc 
										//qzee.net?>
										<!--
										<td class="col2"><?php echo gmdate('d.m.Y', $date); ?></td>
										-->
                                    </tr>
	<?php endforeach; ?>
                                </table>
                            </div>
                        </div>
                    </div>
<?php }?>
<?php
//widget：随机日志
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	                    <div class="side-block"><strong class="logo">
						<a href="<?php echo BLOG_URL; ?>" title="[博客前传].">博客前传</a></strong>
                        <div class="holder recent-posts">
                            <h3><?php echo $title; ?></h3>
                            <div class="table">
                                <table>
								<?php foreach($randLogs as $value): ?>
                                    <tr>
                                        <td class="col1"><a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>"><?php echo $value['title']; ?></a></td>
                                        <?//
										//由于获取不到时间所以取消了
										//如果你有更好的方法麻烦您告诉我一声：
										//a@aapp.cc 
										//qzee.net?>
										<!--
										<td class="col2"><?php echo gmdate('d.m.Y', $date); ?></td>
										-->
                                    </tr>
	<?php endforeach; ?>
                                </table>
                            </div>
                        </div>
                    </div>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
                    <div id="custom_twitter_widget-4" class="side-block">
                        <div class="holder">
                            <h3>搜索本站博文</h3>
                            <div class="twitter-message">
	<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php" class="comments-form" />
	<input name="keyword"  type="text" value=""  class="text" />
	<input type="submit" id="logserch_logserch" value="搜索" class="submit" />
	</form>
                            </div>
                        </div>
                    </div>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
                    <div id="archives-4" class="side-block">
                        <div class="holder">
                            <h3>Archive档案馆</h3>
                            <ul>
	<?php foreach($record_cache as $value): ?>

                                <li><a href='<?php echo Url::record($value['date']); ?>' title='<?php echo $value['record']; ?>'><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
	<?php endforeach; ?>

                            </ul>
                        </div>
                    </div>

<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
                    <div id="archives-4" class="side-block">
                        <div class="holder">
                            <h3><?php echo $title; ?></h3>
                            <ul id="<?php echo $id; ?>">
                               <?php echo $content; ?>
                            </ul>
                        </div>
                    </div>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
	?>
                    <div id="categories-4" class="side-block">
                        <div class="holder">
                            <h3>友情链接</h3>
                            <ul>
	<?php foreach($link_cache as $value): ?>
	<li class="cat-item cat-item-20"><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
	<?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
<?php }?>
<?php
//blog：置顶
function topflg($istop){
	$topflg = $istop == 'y' ? "<img src=\"".TEMPLATE_URL."/growfiles/images/topTitle.gif\" align=\"absmiddle\"  title=\"置顶日志\" /> " : '';
	echo $topflg;
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == 'admin' || $author == UID ? '　|　<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
	<a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
	<?php endif;?>
<?php }?>
<?php
//blog：文件附件
function blog_att($blogid){
	global $CACHE;
	$log_cache_atts = $CACHE->readCache('logatts');
	$att = '';
	if(!empty($log_cache_atts[$blogid])){
		$att .= '附件下载：';
		foreach($log_cache_atts[$blogid] as $val){
			$att .= '<br /><a href="'.$val['url'].'" target="_blank">'.$val['filename'].'</a> '.$val['size'];
		}
	}
	echo $att;
}
?>
<?php
//blog：日志标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = ' ';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
		}
		echo $tag;
	}
}
?>
<?php
//blog：日志作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻日志
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<div class="paging">
	<?php if($prevLog):?>
<a class="next" href="<?php echo Url::log($prevLog['gid']) ?>"  title="下一篇《<?php echo $prevLog['title'];?>》">PREV PAGE</a>
<a class="next link-hover" href="<?php echo Url::log($prevLog['gid']) ?>" title="下一篇《<?php echo $prevLog['title'];?>》">PREV PAGE</a>
	<?php endif;?>
	<?php if($nextLog && $prevLog):?>
		
	<?php endif;?>
	<?php if($nextLog):?>
<a class="prev" href="<?php echo Url::log($nextLog['gid']) ?>"  title="《<?php echo $nextLog['title'];?>》上一篇">NEXT PAGE</a>
<a class="prev link-hover" href="<?php echo Url::log($nextLog['gid']) ?>"  title="《<?php echo $nextLog['title'];?>》上一篇">NEXT PAGE</a>
	<?php endif;?>
	</div>
	<div class="post-block"> </div>

<?php }?>
<?php
//blog：引用通告
function blog_trackback($tb, $tb_url, $allow_tb){
    if($allow_tb == 'y' && Option::get('istrackback') == 'y'):?>
	<div id="trackback_address">
	<p>Trackback: <input type="text" style="width:360px" value="<?php echo $tb_url; ?>">
	<a name="tb"></a></p>
	</div>
	<?php endif; ?>
	<?php foreach($tb as $key=>$value):?>
		<ul id="trackback">
		<li><a href="<?php echo $value['url'];?>" target="_blank"><?php echo $value['title'];?></a></li>
		<li>BLOG: <?php echo $value['blog_name'];?></li><li><?php echo $value['date'];?></li>
		</ul>
	<?php endforeach; ?>
<?php }?>

<?php
//blog：博客评论列表
function blog_comments($comments){
    extract($comments);
    if($commentStacks): ?>

	<p class="comment-header"><b>评论：</b><a name="comments"></a></p>
	
	<?php
	$isGravatar = Option::get('isgravatar');
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
            <li>
            <div class="comment" id="comment-<?php echo $comment['cid']; ?>">
			<a name="<?php echo $comment['cid']; ?>"></a>
                <div class="block">
					<?php if($isGravatar == 'y'): ?><div class="image"><img src="<?php echo getGravatar($comment['mail']); ?>" /></div><?php endif; ?>
                    <span class="name"><?php echo $comment['poster']; ?> <?php if(function_exists('display_useragent')){display_useragent($comment['cid']);} ?></span>
                    <strong class="date"><?php echo $comment['date']; ?> </strong>			
                </div>
                <p><?php echo $comment['content']; ?></p>
				<a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a>
            </div>
			<?php blog_comments_children($comments, $comment['children']); ?>
            </li>
<?php endforeach;?>
	<div id="navigation">
	<?php echo $commentPageUrl;?>
	</div>
	<?php else: ?>
	<ol id="thecomments" class="commentlist">
	<li class="messagebox">本文目前尚无任何评论.</li>
	</ol>
	<?php endif; ?>
<?php }?>
	
<?php
//blog：博客子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
			<div class="comment repost" id="comment-<?php echo $comment['cid']; ?>">
			<a name="<?php echo $comment['cid']; ?>"></a>
                <div class="block">
                    <?php if($isGravatar == 'y'): ?><div class="image"><img src="<?php echo getGravatar($comment['mail']); ?>" /></div><?php endif; ?>
                    <span class="name"><?php echo $comment['poster']; ?> <?php if(function_exists('display_useragent')){display_useragent($comment['cid']);} ?></span>
                    <strong class="date"><?php echo $comment['date']; ?> </strong>			
                </div>
                <p><?php echo $comment['content']; ?></p>
				<?php if($comment['level'] < 3): ?><div class="comment-reply"><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a> </div><?php endif; ?>
            </div>
		<?php blog_comments_children($comments, $comment['children']);?>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
	<div id="com_ajax">
	<div id="comment-place">
	<div class="comment-post" id="comment-post">
<form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform" class="comments-form">
<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
    <fieldset>
    <div class="heading"><a name="leavecomment"></a>
        <h2 class="text-thoughts">你的想法？</h2>
			<div class="cancel-comment-reply" id="cancel-reply" style="display:none"><a href="#comment-post" onclick="cancelReply()">不想回了？点击这里取消回复.</a></div>
    </div>
<?php if(ROLE == 'visitor'): ?>
    <div class="text-holder">
        <div class="area"><label for="author"><strong>昵称</strong>*</label><input type="text" class="text" id="comname" name="comname" /></div>
        <div class="area"><label for="email"><strong>邮箱</strong>*</label><input type="text" class="text" id="email" name="commail" /></div>
        <div class="area"><label for="url"><strong>网站</strong></label><input type="text" class="text" id="comurl" name="comurl" /></div>
    </div>
<?php
	else:
	$CACHE = Cache::getInstance();
	$user_cache = $CACHE->readCache('user');
?>
	<p>您当前已登录为 <b><?php echo $user_cache[UID]['name']; ?></b></p>
<div class="text-holder"><span class="logo-projects">CURRENTLY ACCEPITING PROJECTS</span>
        <div class="area"><label for="author"><strong>昵称</strong>*</label><input type="text" class="text" id="comname" name="comname" value="<?php echo $user_cache[UID]['name']; ?>" /></div>
        <div class="area"><label for="email"><strong>邮箱</strong>*</label><input type="text" class="text" id="email" name="commail" value="<?php echo $user_cache[UID]['mail']; ?>" /></div>
        <div class="area"><label for="url"><strong>网站</strong></label><input type="text" class="text" id="comurl" name="comurl" value="<?php echo BLOG_URL; ?>" /></div>
    </div>
<?php endif; ?>
    <div class="area"><label for="message"><strong>想说的话：</strong></label>
	<p><? echo imgrep($comment);  ?></p>
	<textarea name="comment" id="comment"  class="textarea" cols="30" rows="10"></textarea>
	</div>
	<?php echo $verifyCode; ?> <input type="submit" value="POST" class="submit" name="提交内容[Ctrl+Enter]" />
	<input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/>
	</fieldset>
<p id="gasp_p" style="clear:both;"></p>
<script type="text/javascript">
            document.getElementById("comment").onkeydown = function(moz_ev) {
                var ev = null;
                if (window.event) {
                    ev = window.event;
                } else {
                    ev = moz_ev;
                }
                if (ev != null && ev.ctrlKey && ev.keyCode == 13) {
                    document.getElementById("submit").click();
                }
            }
            //v1.01
            var gasp_p = document.getElementById("gasp_p");
            var gasp_cb = document.createElement("input");
            var gasp_text = document.createTextNode("请把我勾选了才可以评论哦!");
            gasp_cb.type = "checkbox";
            gasp_cb.id = "gasp_checkbox";
            gasp_cb.name = "gasp_checkbox";
            gasp_cb.style.width = "25px";
            gasp_p.appendChild(gasp_cb);
            gasp_p.appendChild(gasp_text);
            var frm = gasp_cb.form;
            frm.onsubmit = gasp_it;
            function gasp_it(){
            if(gasp_cb.checked != true){
            alert("请把下面的框打勾方能评论!");
            return false;
            }
            return true;}
            </script>
</form><!--表单end-->
</div></div></div><!--comment-place end //该表指引回复跳转调用-->
<!--
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>growfiles/js/ajax.js"></script>-->
	<?php endif; ?>
<?php }?>