    <div class="gallery">
		<div class="mask">
            <ul class="slider">
                <li><a href="http://qzee.net/?post=3"><img src="<?php echo TEMPLATE_URL; ?>growfiles/uploads/aappz.png" alt="image description" width="371" height="172" /></a></li>
                <li><a href="http://qzee.net/?post=6"><img src="<?php echo TEMPLATE_URL; ?>growfiles/uploads/qzbench.png" alt="image description" width="371" height="172" /></a></li>
                <li><a href="http://qzee.net/?post=41"><img src="<?php echo TEMPLATE_URL; ?>growfiles/uploads/qzsoil.png" alt="image description" width="371" height="172" /></a></li>
                <li><a href="http://qzee.net/?post=44"><img src="<?php echo TEMPLATE_URL; ?>growfiles/uploads/qzlog.png" alt="image description" width="371" height="172" /></a></li>
            </ul>
        </div>
    <div class="switcher-holder"></div>
</div>
<h2><strong><a href="http://qzee.net/?sort=3" target="_blank">[前传]制作的模板</a></strong></h2>
<p>by <strong>qzz</strong>.</p>