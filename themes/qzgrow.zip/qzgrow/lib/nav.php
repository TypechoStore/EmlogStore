<?php if($curpage == CURPAGE_HOME):?>  <? else: ?>
					<li class="">
						<a title="home" href="<?php echo BLOG_URL; ?>">
							<strong class="home">Home<span class="home-decor">&nbsp;</span></strong>
							<strong class="home link-hover">Home</strong>
						</a>
					</li>
<?endif;?>
<?php 
global $CACHE; 
$navi_cache = $CACHE->readCache('navi');
foreach ($navi_cache as $key => $val):
if ($val['hide'] == 'y'){continue;}
if (empty($val['url'])){$val['url'] = Url::log($key);}
$newtab = $val['newtab'] == 'y' ? 'target="_blank"' : '';
$val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
?>
					<li class="<?php echo isset($logid) && $key == $logid ? 'active' : '';?>">
						<a title="<?php echo $val['naviname']; ?>" href="<?php echo $val['url']; ?>">
							<strong class="<?php echo $val['naviname']; ?>"><?php echo $val['naviname']; ?><span class="<?php echo $val['naviname']; ?>-decor">&nbsp;</span></strong>
							<strong class="<?php echo $val['naviname']; ?> link-hover"><?php echo $val['naviname']; ?></strong>
						</a>
					</li>
<?php endforeach;?>
<?php doAction('navbar', '<li class="common">', '</li>'); ?>