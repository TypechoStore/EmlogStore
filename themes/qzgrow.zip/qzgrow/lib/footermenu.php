<ul class="social">
    <li><a href="t.qq.com/waterg" target="_new" class="forrst"></a><a href="http://t.qq.com/waterg" target="_new" class="forrst link-hover">
    <span class="follow">FOLLOW ME</span> <span class="item"> ON <span class="mark">QQWeibo</span>
	</span>
    </a></li>
    <li><a href="http://zhan.renren.com/qzzzzz/" target="_new" class="dribbble"></a><a href="http://zhan.renren.com/qzzzzz/" target="_new" class="dribbble link-hover">
    <span class="follow">FOLLOW ME</span> <span class="item">  ON <span class="mark">Renren</span>
    </span>
    </a></li>
    <li><a href="http://www.twitter.com/aieii" target="_new" class="twitter"></a><a href="http://www.twitter.com/aieii" target="_new" class="twitter link-hover">
    <span class="follow">FOLLOW ME</span><span class="item"> ON <span class="mark">TWITTER</span>
    </span>
    </a></li>
    <li><a href="http://www.facebook.com/aappc" target="_new" class="facebook"></a><a href="http://www.facebook.com/aappc" target="_new" class="facebook link-hover">
    <span class="follow">FOLLOW ME</span><span class="item"> ON <span class="mark">FACEBOOK</span>
    </span>
    </a></li>
    <li><a href="http://blog.qzee.net/rss.php" target="_new" class="rss"></a>
	<a href="http://blog.qzee.net/rss.php" target="_new" class="rss link-hover">
    <span class="follow">FOLLOW ME</span><span class="item"> VIA <span class="mark">RSS FEED</span></span>
    </a></li>
    <li><a href="http://weibo.com/waterg" target="_new" class="Weibo"></a>
	<a href="http://weibo.com/waterg" target="_new" class="Weibo link-hover">
    <span class="follow">FOLLOW ME</span><span class="item"> ON <span class="mark">SinaWeibo</span>
    </span>
    </a></li>
    <li><a href="http://list.qq.com/cgi-bin/qf_invite?id=631bd6e0451632fd39822a42fb9dc2876a517b8fc8ce2259" target="_new" class="email"></a>
	<a href="http://list.qq.com/cgi-bin/qf_invite?id=631bd6e0451632fd39822a42fb9dc2876a517b8fc8ce2259" target="_new" class="email link-hover">
    <span class="follow">SEND ME</span> <span class="item">AN E-MAIL</span>
    </a></li>
                </ul>