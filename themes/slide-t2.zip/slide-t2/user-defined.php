<?php 
/*
 * 自定义函数
 */
if (!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//Custom: 彩色标签
//调用本函数时须指定标签显示数量，如：getColorTags(25);
function getColorTags($tag_num) {
    //$tag_num 为标签显示数量，数值为"0"时全部显示
    global $CACHE;
    $tag_cache = $CACHE->readCache('tags');
    shuffle($tag_cache); //随机顺序
    if ($tag_num != 0){
        $tag_cache = array_slice($tag_cache,0,$tag_num); //显示数量
        }
    foreach($tag_cache as $value):
        $color = dechex(rand(3355443,13421772)); //随机颜色 ?>
        <span style="font-size:<?php echo $value['fontsize']; ?>pt; line-height:23px;"><a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇日志" style="color:#<?php echo $color; ?>"><?php echo $value['tagname']; ?></a></span>
    <?php endforeach; ?>
    <?php if ($tag_num != 0): ?>
        &nbsp; <a href="<?php echo BLOG_URL.'Tags'; ?>" target="_self" style="font-size:14px;">更多»</a>
    <?php endif; ?>
<?php } ?>
<?php
//Custom: 推荐日志
//调用本函数时须指定日志数量，如：getTopLogs(10);
function getTopLogs($log_num) {
    $db = MySql::getInstance();
    $sql = 	"SELECT gid,title,content FROM ".DB_PREFIX."blog WHERE type='blog' and top='y' ORDER BY `top` DESC LIMIT 0,$log_num";
    $list = $db->query($sql);
    while($row = $db->fetch_array($list)){ ?>
        <div class="loglist-logs">
        <div class="logs-title"><a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>" rel="bookmark"><?php echo $row['title']; ?></a></div>
        </div>
    <?php } ?>
<?php } ?>
<?php
//Custom: 热评日志
//调用本函数时须指定日志数量，如：getHotLogs(10);
function getHotLogs($log_num) {
    $db = MySql::getInstance();
    $sql = 	"SELECT gid,title,content FROM ".DB_PREFIX."blog WHERE type='blog' ORDER BY `comnum` DESC LIMIT 0,$log_num";
    $list = $db->query($sql);
    while($row = $db->fetch_array($list)){ ?>
        <div class="loglist-logs">
        <div class="logs-title"><a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>" rel="bookmark"><?php echo $row['title']; ?></a></div>
        </div>
    <?php } ?>
<?php } ?>
<?php
//Custom: 热门日志
//调用本函数时须指定日志数量，如：getHotViewLogs(10);
function getHotViewLogs($log_num) {
    $db = MySql::getInstance();
    $sql = 	"SELECT gid,title,content FROM ".DB_PREFIX."blog WHERE type='blog' ORDER BY `views` DESC LIMIT 0,$log_num";
    $list = $db->query($sql);
    while($row = $db->fetch_array($list)){ ?>
        <div class="loglist-logs">
        <div class="logs-title"><a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>" rel="bookmark"><?php echo $row['title']; ?></a></div>
        </div>
    <?php } ?>
<?php } ?>
<?php
//Custom: 随机日志
//调用本函数时须指定日志数量，如：getRandLogs(10);
function getRandLogs($log_num) {
    $db = MySql::getInstance();
    $sql = 	"SELECT gid,title,content FROM ".DB_PREFIX."blog WHERE type='blog' ORDER BY rand() LIMIT 0,$log_num";
    $list = $db->query($sql);
    while($row = $db->fetch_array($list)){ ?>
        <div class="loglist-logs">
        <div class="logs-title"><a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>" rel="bookmark"><?php echo $row['title']; ?></a></div>
        </div>
    <?php } ?>
<?php } ?>
<?php
//获取首页幻灯片
//调用本函数时须指定图片数量及获取模式，如：top_imgplay(6，0);
function top_imgplay($img_num,$play_range){
    //$play_range = 0 [按日期]；$play_range = 1 [随机] 
    if ($play_range == 0) {$condition_mode = "`addtime` DESC";}
    else {$condition_mode = "rand()";}
			 $db = MySql::getInstance();
	 		$sql = "SELECT blogid as g,filepath,(SELECT title FROM ".DB_PREFIX."blog where `gid`=g) as t FROM ".DB_PREFIX."attachment WHERE `filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png' GROUP BY `blogid` ORDER BY $condition_mode LIMIT 0, $img_num";
    echo '<div id="gal-wrap"><ul id="gal-pic">';
    $img_num1 = 0;
    $imgs = $db->query($sql);
    while($row = $db->fetch_array($imgs)){
        $img .= '<li><a href="'.Url::log($row['g']).'" target="_self"><img src="'.BLOG_URL.substr($row['filepath'],3,strlen($row['filepath'])).'" alt="'.$row['t'].'" /></a><span>'.$row['t'].'</span></li>';
        $img_num1++;
    }
    echo $img.'<div class="clear"></div></ul>';
    if ($img_num1>0){
        echo '<div id="gal-panel">';
        for ($img_num0=1; $img_num0<=$img_num1; $img_num0++){echo '<span>'.$img_num0.'</span>';}
        echo '&nbsp;&nbsp;</div>';
    }
    echo '</div>';
} ?>
<?php
//Custom: 获取附件第一张图片
function get_Attachment_img($blogid,$src_type){
    //$src_type 为图片地址类型，如下：
    //0 - url地址  (http://...)
    //1 - path地址 (d:/...)
    $db = MySql::getInstance();
    $sql = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$blogid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";
    //die($sql);
    $imgs = $db->query($sql);
    $img_src = "";
    while($row = $db->fetch_array($imgs)){
        if ($src_type == 0){
            $img_src .= BLOG_URL.substr($row['filepath'],3,strlen($row['filepath']));
        }else{
            $img_src .= EMLOG_ROOT.'/'.substr($row['filepath'],3,strlen($row['filepath']));
        }
    }
    return $img_src;
}
?>
