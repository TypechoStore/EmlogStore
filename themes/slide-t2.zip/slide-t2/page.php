<?php
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="frame-content">
<div id="content">
<div class="content-box">
    <div class="title">
        <h2 class="page"><span><?php echo $log_title; ?></span></h2>
    </div>
    <div class="blank"></div>
    <div class="log-cont">
        <?php if($log_title == "标签"): ?>
            <?php getColorTags(0); ?>
        <?php else: ?>
            <?php echo $log_content; ?>
            <div class="clear"></div>
        <?php endif; ?>
    </div>
    <!--非图形附件列表，5.0己非必须-->
    <!--<div class="att"><?php //blog_att($logid); ?></div>-->
</div>
<?php if ($comnum > 0): ?>
<div class="content-box">
    <?php blog_comments($comments,$params); ?>
</div>
<?php endif; ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div><!--#content.End-->
</div><!--#frame_content.End-->

<?php
    include View::getView('side');
    include View::getView('footer');
?>
