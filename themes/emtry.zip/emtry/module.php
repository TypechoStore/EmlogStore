<?php if (!defined('EMLOG_ROOT')) {
    exit('error!');
}?><?php function tool_ishome()
{
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL) {
        return true;
    } else {
        return false;
    }
}?><?php function blog_navi()
{
    global $CACHE;
    $navi_cache = $CACHE->readCache('navi'); ?><ul class="nav clearfix"><?php foreach ($navi_cache as $value): if ($value['pid'] != 0) {
        continue;
    }
    if ($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):?><li class="item"><a href="<?php echo BLOG_URL; ?>admin/">管理站点</a></li><li class="item"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li><?php continue;
    endif;
    $newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
    $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/'); ?><li class="item"><a href="<?php echo $value['url']; ?>" <?php echo $newtab; ?>><?php echo $value['naviname']; ?></a><?php if (!empty($value['children'])) :?><ul class="sub-nav"><?php foreach ($value['children'] as $row) {
        echo '<li class="sub-item"><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></li>';
    } ?></ul><?php endif; ?><?php if (!empty($value['childnavi'])) :?><ul class="sub-nav"><?php foreach ($value['childnavi'] as $row) {
        $newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';
        echo '<li class="sub-item"><a href="' . $row['url'] . "\" $newtab >" . $row['naviname'].'</a></li>';
    } ?></ul><?php endif; ?></li><?php endforeach; ?></ul><?php 
}?><?php function blog_author($uid)
{
    global $CACHE;
    $user_cache = $CACHE->readCache('user');
    $author = $user_cache[$uid]['name'];
    echo '<a href="'.Url::author($uid).'" title="'.$author.'">'.$author.'</a>';
}?><?php function editflg($logid, $author)
{
    $editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
    echo $editflg;
}?><?php function blog_sort($blogid)
{
    global $CACHE;
    $log_cache_sort = $CACHE->readCache('logsort'); ?><?php if (!empty($log_cache_sort[$blogid])): ?><a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a><?php endif; ?><?php 
}?><?php function blog_tag($blogid)
{
    global $CACHE;$log_cache_tags = $CACHE->readCache('logtags'); if (!empty($log_cache_tags[$blogid])) {
        foreach ($log_cache_tags[$blogid] as $value) {
            $tag .= "<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
        }
        echo $tag;
    }
}?><?php function neighbor_log($neighborLog)
{
    extract($neighborLog); ?><div class="echo-neighbor"><ul class="clearfix"><?php if ($prevLog):?><li class="neighbor-left"><a href="<?php echo Url::log($prevLog['gid']) ?>"><?php echo $prevLog['title']; ?></a></li><?php endif; ?><?php if ($nextLog):?><li class="neighbor-right"><a href="<?php echo Url::log($nextLog['gid']) ?>"><?php echo $nextLog['title']; ?></a></li><?php endif; ?></ul></div><?php 
}?><?php function blog_comments($comments)
{
    extract($comments);
    if ($commentStacks):?><a name="comments"></a><?php endif; ?><h4 class="echo-comments-header">评论</h4><div class="echo-comments-list"><ul><?php $isGravatar = Option::get('isgravatar');
    foreach ($commentStacks as $cid):$comment = $comments[$cid];
    $comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster']; ?><li class="li-list clearfix" id="comment-<?php echo $comment['cid']; ?>"><div class="t-left"><?php if ($isGravatar == 'y'): ?><img class="img-circle" src="<?php echo getGravatar($comment['mail']); ?>" /><?php endif; ?></div><div class="t-right"><div class="t-cont"><a name="<?php echo $comment['cid']; ?>"></a><div class="t-content"><?php echo $comment['content']; ?></div><div class="t-info"><?php echo $comment['poster']; ?>&nbsp;&nbsp;<?php echo $comment['date']; ?><a class="echo-icon-comments" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)"></a></div><?php blog_comments_children($comments, $comment['children']); ?></div></div></li><?php endforeach; ?></ul><div class="am-pages"><div class="am-pages-item"><?php echo $commentPageUrl; ?></div></div></div><?php 
}?><?php function blog_comments_children($comments, $children)
{
    $isGravatar = Option::get('isgravatar');
    foreach ($children as $child):$comment = $comments[$child];
    $comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster']; ?><div class="echo-comments-list echo-comments-children clearfix" id="comment-<?php echo $comment['cid']; ?>"><div class="t-left"><?php if ($isGravatar == 'y'): ?><img class="img-circle" src="<?php echo getGravatar($comment['mail']); ?>" /><?php endif; ?></div><div class="t-right"><div class="t-cont"><a name="<?php echo $comment['cid']; ?>"></a><div class="t-content"><?php echo $comment['content']; ?></div><div class="t-info"><?php echo $comment['poster']; ?>&nbsp;&nbsp;<?php echo $comment['date']; ?><?php if ($comment['level'] < 4): ?><a class="echo-icon-comments" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)"></a><?php endif; ?></div></div></div></div><?php blog_comments_children($comments, $comment['children']); ?><?php endforeach; ?><?php 
}?><?php function blog_comments_post($logid, $ckname, $ckmail, $ckurl, $verifyCode, $allow_remark)
{
    ?><div id="comment-place"><div class="echo-comments-post" id="comment-post"><div class="cancel-reply clearfix" id="cancel-reply" style="display:none"><a href="javascript:void(0);" onclick="cancelReply()">取消回复</a></div><a name="respond"></a><form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform"><input type="hidden" name="gid" value="<?php echo $logid; ?>"><?php if (ROLE == ROLE_VISITOR): ?><ul class="clearfix"><li class="li-input li-left"><input type="text" class="input" name="comname" value="<?php echo $ckname; ?>" tabindex="1" placeholder="昵称（必填）"></li><li class="li-input li-left"><input type="text" class="input" name="commail" value="<?php echo $ckmail; ?>" tabindex="2" placeholder="邮箱（选填）"></li><li class="li-input li-right"><input type="text" class="input" name="comurl" value="<?php echo $ckurl; ?>" tabindex="3" placeholder="个人主页（选填）"></li></ul><?php endif; ?><textarea class="textarea" name="comment" id="comment" tabindex="4" placeholder="欢迎在这里发表评论，但是垃圾评论不受欢迎！"></textarea><div class="li-btn clearfix"><?php if (!empty($verifyCode)) {
        echo '<div class="li-code"><img src="'.BLOG_URL.'include/lib/checkcode.php" title="看不清楚？点图切换"><input type="text" name="imgcode" class="input" placeholder="验证码" tabindex="5"></div>';
    } ?><button type="submit" class="pull-right btn btn-primary" id="comment_submit">立即发布</button></div><input type="hidden" name="pid" id="comment-pid" value="0" tabindex="1"></form></div></div><?php 
}?>
