<?php if (!defined('EMLOG_ROOT')) {
    exit('error!');
}?>
<div class="container">
    <div class="echo-wrap">
        <h3 class="echo-title"><?php echo $log_title; ?></h3>
        <div class="echo-info">作者：<?php blog_author($author); ?><?php editflg($logid, $author); ?><?php blog_sort($logid); ?><span><?php echo gmdate('Y-n-j H:i:s', $date); ?></span></div>
        <div class="echo-article"><?php echo $log_content; ?></div>
        <div class="echo-tags clearfix"><?php blog_tag($logid); ?></div>
        <?php neighbor_log($neighborLog); ?>
        <?php blog_comments($comments); ?>
        <?php blog_comments_post($logid, $ckname, $ckmail, $ckurl, $verifyCode, $allow_remark); ?>
    </div>
</div>
<?php include View::getView('footer'); ?>
