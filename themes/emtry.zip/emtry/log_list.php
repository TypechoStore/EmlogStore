<?php if (!defined('EMLOG_ROOT')) {
    exit('error!');
}?>
<div class="container">
    <div class="index-box">
        <ul>
        <?php if (!empty($logs)): foreach ($logs as $value): ?>
            <li<?php if ($value['top'] == 'y' || $value['sortop'] == 'y') {echo ' class="index-istop"';} ?>>
                <h3 class="index-title"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h3>
                <div class="index-info"><?php echo gmdate('Y-m-d H:i', $value['date']); ?></div>
            </li>
        <?php endforeach;endif; ?>
        </ul>
        <div class="am-pages"><div class="am-pages-item"><?php echo $page_url; ?></div></div>
    </div>
</div>
<?php include View::getView('footer'); ?>
