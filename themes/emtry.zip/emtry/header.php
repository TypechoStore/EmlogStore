<?php
/*
Template Name:Emtry
Description:<a href="../?setting">模板设置</a>
Version:1.0
Author:xiaogu
Author Url:http://xiaogupai.com
Sidebar Amount:0
*/
if (!defined('EMLOG_ROOT')) {
    exit('error!');
} require_once View::getView('module'); ?>
<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="<?php echo $site_description; ?>">
    <meta name="keywords" content="<?php echo $site_key; ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $site_title; ?></title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp">
    <link rel="icon" type="image/png" href="<?php echo TEMPLATE_URL; ?>images/favicon.png">
    <!-- Add to homescreen for Chrome on Android -->
    <meta name="mobile-web-app-capable" content="yes">
    <link rel="icon" sizes="192x192" href="<?php echo TEMPLATE_URL; ?>images/appicon.png">
    <!-- Add to homescreen for Safari on iOS -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="<?php echo $blogname; ?>">
    <link rel="apple-touch-icon-precomposed" href="<?php echo TEMPLATE_URL; ?>images/appicon.png">
    <!-- Tile icon for Win8 (144x144 + tile color) -->
    <meta name="msapplication-TileImage" content="<?php echo TEMPLATE_URL; ?>images/appicon.png">
    <meta name="msapplication-TileColor" content="#167ffc">
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
    <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
    <link rel="alternate" type="application/rss+xml" title="RSS" href="<?php echo BLOG_URL; ?>rss.php" />
    <link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/prettify.css">
    <script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js"></script>
    <script src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js"></script>
    <script src="<?php echo TEMPLATE_URL; ?>js/prettify.js"></script>
</head>

<body>
    <div class="header-wrap js-header-wrap d-none">
        <div class="container clearfix">
            <div class="header-nav-list"><?php blog_navi(); ?></div>
            <div class="header-search-list">
                <form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
                    <input name="keyword" type="text" placeholder="请输入关键字">
                </form>
            </div>
        </div>
    </div>
    <div class="header-brand">
        <div class="container">
            <div class="header-bar js-header-bar"><span></span><span></span><span></span></div>
            <div class="header-logo">
                <a href="<?php echo BLOG_URL; ?>" title="首页"><img src="<?php echo TEMPLATE_URL; ?>images/logo.png" alt="logo"></a>
                <p><?php echo $bloginfo; ?></p>
            </div>
        </div>
    </div>
    <script>
    $(function() {
        $('.js-header-bar').on('click', function() {
            $('.js-header-wrap').toggleClass('d-none');
        });
    });
    </script>
