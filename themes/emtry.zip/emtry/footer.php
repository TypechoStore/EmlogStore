<?php if (!defined('EMLOG_ROOT')) {
    exit('error!');
}?>
    <div class="footer-wrap">
        <div class="container">
            <div class="page-footer">
                <div class="footer-copy"><a href="http://www.emlog.net" target="_blank">Powered by emlog</a><a href="http://xiaogupai.com" target="_blank">Theme by lcuncle</a></div>
                <div class="footer-info"><a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a></div>
                <div class="footer-other"><?php echo $footer_info; ?></div>
            </div>
        </div>
    </div>
</body>
</html>
