<?php if (!defined('EMLOG_ROOT')) {
    exit('error!');
}?>
<div class="container">
    <div class="page-wrap">
        <h3 class="page-title"><?php echo $log_title; ?></h3>
        <div class="echo-article"><?php echo $log_content; ?></div>
    </div>
</div>
<?php include View::getView('footer'); ?>
