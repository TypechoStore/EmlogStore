<?php if (!defined('EMLOG_ROOT')) {
    exit('error!');
}?>
<div class="container">
    <div class="page-twitter">
        <ul>
        <?php foreach ($tws as $val) : $tid = (int)$val['id'];$img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img src="'.BLOG_URL.$val['img'].'"></a>'; ?>
            <li>
                <div class="p-ct"><?php echo $val['t'].'<br/>'.$img; ?></div>
                <div class="p-ft"><?php echo $val['date']; ?></div>
            </li>
        <?php endforeach; ?>
        </ul>
        <div class="am-pages"><div class="am-pages-item"><?php echo $pageurl; ?></div></div>
    </div>
</div>
<?php include View::getView('footer'); ?>
