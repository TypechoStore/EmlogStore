<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<section class="central container">
    <div class="content-wrap">
	    <div class="content">
		<article class="article">
			<header class="article-header">
				<h1 class="article-title"><?php topflg($top); ?><?php echo $log_title; ?></h1>
				<div class="share"><div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare"><span class="share-tit">分享到：</span><a class="bds_qzone" title="分享到QQ空间" href="#"></a><a class="bds_tqq" title="分享到腾讯微博" href="#"></a><a class="bds_tsina" title="分享到新浪微博" href="#"></a><a class="bds_renren" title="分享到人人网" href="#"></a><a class="bds_kaixin001" title="分享到开心网" href="#"></a><a class="bds_tqf" title="分享到腾讯朋友" href="#"></a><span class="bds_more">更多</span><a class="shareCount" href="#" title="累计分享1次">1</a></div></div>	
				<p class="article-meta">
					<?php echo gmdate('Y-n-j', $date); ?> &nbsp;&nbsp; <?php blog_sort($logid); ?>
					<a class="comm" href="#comments" title="查看 <?php echo $log_title; ?> 的评论"><?php echo $comnum; ?>人评论</a>
					<span class="view"><?php echo $views; ?> ℃</span>
					<?php editflg($logid,$author); ?>	
				</p>
			</header>

						
			<div class="article-entry">
				<p><?php echo $log_content; ?></p>	
                <p>转载请注明：<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a> » <a href="<?php echo $log_url; ?>"><?php echo $log_title; ?></a></p>				
			</div>
            <?php doAction('log_related', $logData); ?>
			<footer class="article-footer">
			<div class="article-tags">
                        标签: <?php blog_tag($logid); ?> 
                    </div>
				<div class="share"><div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare"><span class="share-tit">分享到：</span><a class="bds_qzone" title="分享到QQ空间" href="#"></a><a class="bds_tqq" title="分享到腾讯微博" href="#"></a><a class="bds_tsina" title="分享到新浪微博" href="#"></a><a class="bds_renren" title="分享到人人网" href="#"></a><a class="bds_kaixin001" title="分享到开心网" href="#"></a><a class="bds_tqf" title="分享到腾讯朋友" href="#"></a><span class="bds_more">更多</span><a class="shareCount" href="#" title="累计分享1次">1</a></div></div>				
			
			</footer>

		</article>
       
	    <?php blog_comments($comments); ?>
	    <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
		</div>
    </div>
	
<?php
 include View::getView('side');
 include View::getView('footer');
?>