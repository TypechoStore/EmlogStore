<?php

/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
	'foot_li1' => array(
		'type' => 'text',
		'name' => '底部菜单1',
		'default' => '关于本站',
	),
	'foot_li1url' => array(
		'type' => 'text',
		'name' => '底部菜单1链接地址(请务必加上http://)',
	),
	'foot_li2' => array(
		'type' => 'text',
		'name' => '底部菜单2',
		'default' => '友情链接',
	),
	'foot_li2url' => array(
		'type' => 'text',
		'name' => '底部菜单2链接地址(请务必加上http://)',
	),
	 'foot_li3' => array(
		'type' => 'text',
		'name' => '底部菜单3',
		'default' => '灌水排行',
	),
	'foot_li3url' => array(
		'type' => 'text',
		'name' => '底部菜单3链接地址(请务必加上http://)',
	),
	'foot_li4' => array(
		'type' => 'text',
		'name' => '底部菜单4',
		'default' => '日志标签',
	),
	'foot_li4url' => array(
		'type' => 'text',
		'name' => '底部菜单4链接地址(请务必加上http://)',
	),
	'foot_li5' => array(
		'type' => 'text',
		'name' => '底部菜单5',
		'default' => '技术团队',
	),
	'foot_li5url' => array(
		'type' => 'text',
		'name' => '底部菜单5链接地址(请务必加上http://)',
	),
	'admin_qq_weibo' => array(
		'type' => 'text',
		'name' => '侧边栏 腾讯微博',
	),
	'admin_sina_weibo' => array(
		'type' => 'text',
		'name' => '侧边栏 新浪微博',
	),
	'mail_list' => array(
		'type' => 'radio',
		'name' => '是否显示邮件订阅',
		'values' => array(
			'yes' => '是',
			'no' => '否',
		),
		'default' => 'yes',
	),
	'emailid' => array(
		'type' => 'text',
		'name' => '侧边栏 腾讯邮件订阅ID',
	),
	'sidebar_theme' => array(
		'type' => 'radio',
		'name' => '是否显示侧边栏主题简介',
		'values' => array(
			'yes' => '是',
			'no' => '否',
		),
		'default' => 'yes',
	),
	'foot_theme' => array(
		'type' => 'radio',
		'name' => '是否显示底部主题版权',
		'values' => array(
			'yes' => '是',
			'no' => '否',
		),
		'default' => 'yes',
	),
	'foot_emlog' => array(
		'type' => 'radio',
		'name' => '是否显示底部emlog版权',
		'values' => array(
			'yes' => '是',
			'no' => '否',
		),
		'default' => 'yes',
	),
);
