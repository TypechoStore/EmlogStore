<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<section class="central container">
    <div class="content-wrap">
	    <div class="content">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>		
        	<article class="excerpt">
			 <?php
            //获取缩略图
            $template_name = str_replace(BLOG_URL,"",TEMPLATE_URL);
            $template_name = str_replace("content/templates/","",$template_name);
            $template_name = str_replace("/","",$template_name);
            //以上三句代码获取模板目录名称
            $thum_file = EMLOG_ROOT.'/content/templates/'.$template_name.'/thumbnail/gid/'.$value['gid'].'.jpg';
            if (is_file($thum_file)) {
                $thum_src = TEMPLATE_URL.'/thumbnail/gid/'.$value['gid'].'.jpg';
                //ID编号配图
            }else{
                $thum_src = getThumbnail($value['logid']); //附件第一张图片
                if (empty($thum_src)) {
                    $rand_num = 12; //随机图片数量，按实际数量设置
                    if ($rand_num == 0) {
                        $thum_src = TEMPLATE_URL."thumbnail/0.jpg";
                        //默认图片，须命名为"0.jpg"
                    }else{
                        $thum_src = TEMPLATE_URL."thumbnail/random/".rand(1,$rand_num).".jpg";
                        //随机图片，须按"1.jpg","2.jpg","3.jpg"...的顺序命名
                    }
                }
            }
            //ID编号配图(gid目录)、默认图片(0.jpg)、随机图片(random目录)，都保存在模板目录中的"thumbnail"目录下，以便于集中管理
            ?>
				<a href="<?php echo $value['log_url']; ?>" class="pic"><img width="140" height="98" src="<?php echo $thum_src;?>" alt="<?php echo $value['log_title']; ?>"></a>
				<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></h2>
				<div class="info">
					<time class="time"><?php echo gmdate('Y-n-j', $value['date']); ?></time>
					<a class="comm" href="<?php echo $value['log_url']; ?>#comments" title="查看 <?php echo $value['log_title']; ?> 的评论"><?php echo $value['comnum']; ?>条评论</a>
					
					

					<span class="view"><?php echo $value['views']; ?> ℃</span>
				</div>
				<div class="note"><?php echo msubstr ($value['log_description'],0,170); ?>	</div>
			</article>
			<?php endforeach; ?>
        	<div class="paging"><?php echo $page_url;?>	</div>
	     </div>  
</div>         
<?php
 include View::getView('side');
 include View::getView('footer');
?>