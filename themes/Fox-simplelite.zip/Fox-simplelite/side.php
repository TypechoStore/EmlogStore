<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<aside class="sidebar">
<!--sidebar主题简介 start-->
<?php if ($sidebar_theme == "yes"): ?>
<div class="widget widget_d_theme">
    <h3 class="widget_tit">F-simple超简洁主题</h3>
    <ul>
    	<li>
			<span class="pic">EM</span>
			<p><strong>Fox-simple主题：</strong>2013年强势推荐EM超简洁主题!</p>
			<a class="btn btn-mini" href="http://foxzld.com">F-simple主题 »</a><a class="btn btn-mini btn-success" href="http://foxzld.com">问题交流反馈</a>
		</li>
	</ul>
</div>
<?php else: ?>	
<?php endif; ?>
<!--sidebar主题简介 end-->
<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>

</aside><!--end #siderbar-->
