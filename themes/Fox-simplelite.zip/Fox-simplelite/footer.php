<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</section>

<section class="showlinks">
	<div class="central">
		<ul class="showlink">
        	<li id="menu-item" class="menu-item "><a href="<?php echo _g('foot_li1url'); ?>"><?php echo _g('foot_li1'); ?></a></li>
            <li id="menu-item" class="menu-item "><a href="<?php echo _g('foot_li1url'); ?>"><?php echo _g('foot_li2'); ?></a></li>
            <li id="menu-item" class="menu-item "><a href="<?php echo _g('foot_li1url'); ?>"><?php echo _g('foot_li3'); ?></a></li>
            <li id="menu-item" class="menu-item "><a href="<?php echo _g('foot_li1url'); ?>"><?php echo _g('foot_li4'); ?></a></li>
            <li id="menu-item" class="menu-item "><a href="<?php echo _g('foot_li1url'); ?>"><?php echo _g('foot_li5'); ?></a></li>
		</ul>
	</div>
</section>
<footer class="footer">
	<div class="central">
	<!--看版权不爽？尽管删 strat-->
		<div class="copyright">
			© 2013 <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>
			<?php if ($foot_theme == "yes"): ?>Theme <a href="http://foxzld.com" target="_blank">Fox-simple</a><?php else: ?><?php endif; ?>
			<?php if ($foot_emlog == "yes"): ?>Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> <?php else: ?><?php endif; ?>
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
<?php doAction('index_footer'); ?>
		</div>
	<!--看版权不爽？尽管删 end-->
	</div>
</footer>

<div class="rollto" style="display: block;">
	<a class="ico ico-totop" title="回顶部"></a>
    
</div>
 
	
<script id="bdshare_js" data="type=tools&amp;uid=13688" ></script><script id="bdshell_js"></script><script>document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?t=" + new Date().getHours();</script>
</body>
</html>