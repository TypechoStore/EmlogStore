<?php
/*
Template Name:Fox-simpleLite
Description:Fox-simpleLite本地评论版，必须启用模板设置插件。
Version:2.0
Author:孤独的北极狐
Author Url:http://foxzld.com
Sidebar Amount:1
ForEmlog:5.2.X
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
extract(_g());
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js"></script>

<!--[if lt IE 9]><script src="<?php echo TEMPLATE_URL; ?>js/html5.js"></script><![endif]-->
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>

<?php doAction('index_head'); ?>
</head>
<body class="home blog logged-in" id="hasfixed">
<header class="header">
	<div class="central">
		<h1 class="logo"><a href="<?php echo BLOG_URL; ?>" title="<?php echo $bloginfo; ?>"><?php echo $blogname; ?></a></h1>
		<?php blog_navi();?>
		<ul class="header-menu">
			<li class="menu-follow">
			<?php
	        global $CACHE;
	        $isset_qq_weibo = ($admin_qq_weibo != '') ? '收听我的腾讯微博' : '暂无腾讯微博';
	        $isset_sina_weibo= ($admin_sina_weibo != '') ? '收听我的新浪微博' : '暂无新浪微博';?>
			
				<a class="btn btn-arrow btn-headermenu" href="javascript:;">订阅关注<i class="arrow"></i></a>
				<span class="popup-arrow"><i></i></span>
				<div class="popup-layer">
					<div class="popup">
						<ul class="popup-follow-weibo">
							<li><a class="btn btn-mini" target="_blank" href="<?php echo $admin_qq_weibo; ?>" title="<?php echo $isset_qq_weibo; ?>">腾讯微博</a></li>
							<li><a class="btn btn-mini" target="_blank" href="<?php echo $admin_sina_weibo; ?>" title="<?php echo $isset_sina_weibo; ?>">新浪微博</a></li>
						</ul>
						<div class="popup-follow-feed">
							<h4>订阅到：</h4>
							<a target="_blank" href="http://fusion.google.com/add?feedurl=<?php echo BLOG_URL; ?>rss.php">Google Reader</a>
							<a target="_blank" href="http://mail.qq.com/cgi-bin/feed?u=<?php echo BLOG_URL; ?>rss.php">QQ邮箱</a>
							<a target="_blank" href="http://www.xianguo.com/subscribe.php?url=<?php echo BLOG_URL; ?>rss.php">鲜果</a>
							<a target="_blank" href="http://www.zhuaxia.com/add_channel.php?url=<?php echo BLOG_URL; ?>rss.php">抓虾</a>
							<h4>订阅地址：</h4>
							<input class="ipt" type="text" readonly value="<?php echo BLOG_URL; ?>rss.php">
						</div>
						<?php if ($mail_list == "yes"): ?>
						<div class="popup-follow-mail">
							<h4>邮件订阅：</h4>
							<form action="http://list.qq.com/cgi-bin/qf_compose_send" target="_blank" method="post">
								<input type="hidden" name="t" value="qf_booked_feedback">
								<input type="hidden" name="id" value="<?php echo stripslashes($emailid); ?>">
								<input id="to" placeholder="输入邮箱 订阅本站" name="to" type="text" class="ipt"><input class="btn btn-primary" type="submit" value="邮件订阅">
							</form>
						</div>
						<?php else: ?>
						<?php endif; ?>
					</div>
				</div>
			</li>
			<li class="menu-profile">
			 <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
			 <?php
				global $CACHE;
				$user_cache = $CACHE->readCache('user');
				$name = $user_cache[1]['name'];?>
			 <a class="btn btn-arrow btn-image btn-headermenu" href="javascript:;"><img class="avatar"  src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="23" height="23"><?php echo $name; ?><i class="arrow"></i></a>
				<span class="popup-arrow"><i></i></span>
				<div class="popup-layer">
					<div class="popup">
					
						<div class="popup-profile">
							<img class="avatar" src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="53" height="53">
							<span class="name"><?php echo $name; ?></span>
							<span class="mail"></span>
							<a href="<?php echo BLOG_URL; ?>admin/" class="btn btn-primary">进入管理中心</a>
						</div>
						<div class="popup-profile-ctrl">
							<a href="<?php echo BLOG_URL; ?>admin/write_log.php" class="btn btn-mini">写日志</a>
							<a href="<?php echo BLOG_URL; ?>admin/?action=logout" class="btn btn-mini">注销</a>
						</div>
						
					</div>
				</div>
				<?php ?>
			 <?php else: ?>
				<a class="btn btn-arrow btn-headermenu" href="javascript:;">用户登陆<i class="arrow"></i></a>
				<span class="popup-arrow"><i></i></span>
				<div class="popup-layer">
					<div class="popup">
						<form class="popup-signin" name="loginform" action="<?php echo BLOG_URL; ?>admin/index.php?action=login" method="post">
							<h4>用户名：</h4>
							<input class="ipt" size="20" type="text" name="user" id="user" value="" onfocus="this.value=''" />
							<h4>密码：</h4>
							<input class="ipt" size="20" type="password" name="pw" id="pw" value="" onfocus="this.value=''" />
							<input class="btn btn-primary" type="submit" name="submit" value="立即登录">
							<input type="hidden" name="redirect_to" value="<?php echo $_SERVER['REQUEST_URI']; ?>" />
		                </form>
	           		</div>
           		</div>
			  
			   <?php endif; ?>
			</li>
		</ul>
		<form method="get" class="search-form" action="<?php echo BLOG_URL; ?>index.php" >
			<input class="search-input" name="keyword" type="text" placeholder="输入关键字搜索"autofocus="" x-webkit-speech="">
			<input class="btn btn-primary search-submit" type="submit" value="搜索">
		</form>
	</div>
</header>
<section class="focus">
	<div class="central">
	<?php global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	?>
	<?php foreach($newtws_cache as $value): ?>
		<div class="toptip"><strong>最新消息：</strong><?php echo $value['t']; ?></div>
	<?php endforeach; ?>
	</div>
</section>