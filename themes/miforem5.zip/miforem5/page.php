<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="content">
<div class="listtop">
<div id="pt" class="bm cl">
<div class="z">
<a href="<?php echo BLOG_URL; ?>" class="nvhm" title="<?php echo $blogname; ?>首页"><?php echo $blogname; ?></a>
><?php echo $log_title; ?>
</div>
</div>
</div>
	<div class="main">
		<?php echo $log_content; ?>
	</div>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<?php blog_comments($comments); ?>
	<div style="clear:both;"></div>
</div><!--end #content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>