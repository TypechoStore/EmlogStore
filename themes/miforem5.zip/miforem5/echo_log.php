<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

	
<div class="content">
	<div class="listtop">
		<div id="pt" class="bm cl">
			<div class="z">
			<a href="<?php echo BLOG_URL; ?>" class="nvhm" title="<?php echo $blogname; ?>首页"><?php echo $blogname; ?></a>
			----> <?php echo $log_title; ?>
			</div>
		</div>
	</div>
	<div class="glists">
		<table width="100%" height="66px" border="0">
  			<tr>
    			<td rowspan="2" width="65px"><img src="<?php echo TEMPLATE_URL; ?>images/random/tb (<?php echo rand(1,20);?>).jpg" alt="<?php echo $value['log_title']; ?>" title="<?php echo $value['log_title']; ?>" height="65px"  width="65px"/></td>
    			<td><h2><?php topflg($top); ?><?php echo $log_title; ?></font></h2></td>
  			</tr>
  			<tr>
    			<td><p class="date">作者：<?php blog_author($author); ?> 发布于：<?php echo gmdate('Y-n-j G:i l', $date); ?> 
																	<?php blog_sort($logid); ?> <?php editflg($logid,$author); ?></p>
				</td>
  			</tr>
		</table>
	</div>
	<div class="post_content">
		<?php echo $log_content; ?>
	</div>
	<div class="post_nav_tag">
		<span style="float:right"><?php blog_att($logid); ?><?php blog_tag($logid); ?></span>
		<span style="float:left"><?php neighbor_log($neighborLog); ?></span>
	</div>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<?php doAction('log_related', $logData); ?>
	<?php doAction('em_ad_replated');?>
	<div class="space"></div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
</div><!--end content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>