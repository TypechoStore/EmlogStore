<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>	
<!--首页日志列表-->	
<div class="content">

<div class="listtop">
	<div id="pt" class="bm cl">
		<div class="z">
		<a href="<?php echo BLOG_URL; ?>" class="nvhm" title="<?php echo $blogname; ?>首页"><?php echo $blogname; ?></a><em></em>
&nbsp;&nbsp;&nbsp;运行: <?php echo floor((time()-strtotime("2012-01-01"))/86400);?>天 | 文章：<?php echo $sta_cache['lognum'];?> 篇 | 评论：<?php echo $sta_cache['comnum_all'];?> 条 | 碎语：<?php echo $sta_cache['twnum'];?>条 | <font color="#FF0000">
<!--首次访问提示-->
<?php
if($_COOKIE['visit_flag']){
$first_visit = true;
}else{
$first_visit = false;
setcookie("visit_flag",1);
}
if($first_visit){
echo "";
}else{
echo "鼠标移动到头像可查看文章描述！";
}
?>
</font>
		</div>
	</div><!--end #pt-->
</div><!--listtop-->

<?php doAction('index_loglist_top'); ?>
<?php doAction('em_ad_post_top');?>

<!--日志列表-->
<?php foreach($logs as $value): ?>
<div class="lists">
	<div class="lists_l"><!--随机头像，images/random文件夹里的tb (*).jpg，*为1-20，tb与()中间有空格，不能省-->
		<a href="<?php echo $value['log_url']; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/random/tb (<?php echo rand(1,20);?>).jpg" alt="<?php echo $value['log_title']; ?>" title="<?php echo subString(strip_tags($value['log_description']),0,300); ?>" height="49px"  width="49px"/></a>
	</div>
		
    <div class="lists_m">
        <div class="box">
          <div class="title">
			<img src="<?php echo TEMPLATE_URL; ?>images/folder_new.gif" alt="新文章" />
            <a href="<?php echo $value['log_url']; ?>" rel="bookmark" title="查看 <?php echo $value['log_title']; ?> 的详细内容"><?php topflg($value['top']); ?><?php echo $value['log_title']; ?></font></a>
          </div>
          <div class="read_total">
			<?php editflg($value['logid'],$value['author']); ?>
			<?php blog_sort($value['logid']); ?> 
			<a href="<?php echo $value['log_url']; ?>#tb">引用(<?php echo $value['tbcount']; ?>)</a>
			
			<?php blog_tag($value['logid']); ?>
		  </div>
         </div><!--end box-->
	 
    	 <div class="lists_r">   
        	<div class="info"><?php blog_author($value['author']); ?><br><?php echo gmdate('Y-n-j', $value['date']); ?></div>
        	<span id="comm"><a href="<?php echo $value['log_url']; ?>#comments" target="_blank">评论：<?php echo $value['comnum']; ?></a></span>
			<span id="views"><a href="<?php echo $value['log_url']; ?>">浏览：<?php echo $value['views']; ?></a></span>
    	 </div><!--end lists_r-->
     </div><!--end lists_m-->
	 <div style="clear:both"></div>
</div><!--end lists-->
<?php endforeach; ?>
       
<div class="pagelist">  
		<?php echo $page_url;?> 
		<?php if($page_url): ?>
			<span class="pageinfo">第 <b><?php echo $page; ?></b> 页 / 共 <b><?php echo ceil($lognum/$index_lognum); ?></b> 页</span>
		<?php endif; ?>
</div>
</div><!-- end #content-->


<div class="sidebar">
	<span class="side_right">
		<form name="keyform" id="searchform" method="get" action="<?php echo BLOG_URL; ?>index.php">
        	<input name="keyword" id="s" class="text" type="text">
        	<input name="keyword" class="submit" type="submit" value="搜索">
      	</form>
	</span>
	<!--选项卡-->
		<div class="tabnav" id="J_setTabBNav">
				<li>人气推荐</li>
				<li>热点日志</li>
				<li>最新评论</li>
		</div>
		<ul>
			<div class="tabbox" id="J_setTabBBox">
				<div style="display:block">
<?php $date = time() - 3600 * 24 * 180;
      $Log_Model = new Log_Model();
	  $viewslogs = $Log_Model->getLogsForHome("AND date > {$date} ORDER BY views DESC,date DESC", 1, 10);
	  foreach($viewslogs as $value):?>
				<li>
				<a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a>
				</li><div class="line"></div>
<?php endforeach; ?>
				</div>
			<div>
<?php $date = time() - 3600 * 24 * 180;
        $Log_Model = new Log_Model();
		$hotlogs = $Log_Model->getLogsForHome("AND date > {$date} ORDER BY comnum DESC,date DESC", 1, 10);
		foreach($hotlogs as $value):?>
				<li><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></li>
				<div class="line"></div>
<?php endforeach; ?> 
			</div>
	<div class="new_comment">
 	<?php global $CACHE; 
		$com_cache = $CACHE->readCache('comment');
		foreach($com_cache as $value):
		$url = Url::log($value['gid']).'#'.$value['cid'];
		?>
		<li><?php echo $value['name']; ?>:<a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a></li>
		<?php endforeach; ?>
	</div>
			</div><!--end tabbox-->
		</ul>
		<!--选项卡-->
<!--随机日志-->
	<?php 
	$Log_Model = new Log_Model();
	$randlogs = $Log_Model->getLogsForHome("ORDER BY rand() DESC,date DESC", 1, 14);
	?>
	<div class="title">
		<h2>随机日志</h2>
	<ul>
	<?php foreach($randlogs as $value): ?> 
		<li><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></li>
		<div class="line"></div>
	<?php endforeach; ?> 
	</ul>
	</div>
<?php doAction('diff_side');?>
</div><!--sidebar-->
<?php
 include View::getView('footer');
?>