<?php
/*
Template Name:仿小米V2.0
Description:可自定义banner,template文件夹需存在默认模版。建议修改admin/template.php里的裁剪高度跟宽度，以裁出适合您网站的banner。<a href="template.php?action=custom-top" style="color:red;">点此设置banner</a>
Version:V2.0
Author:jaeheng
Author Url:http://zhangziheng.com
Sidebar Amount:1
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/jquery.min.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/think.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<!--cl头部的横条-->
<div class="cl" id="toptb">
	<div class="wp">
		<div class="z">
			<a href="<?php echo BLOG_URL; ?>">网站首页</a>
			<script language="javascript">
			function bookmarkit(){window.external.addFavorite('<?php echo BLOG_URL; ?>','<?php echo $blogname; ?>')}
			if (document.all)document.write('<a href="#" onClick="bookmarkit()">收藏本站</a>')
			</script> 	
		</div>
		<div class="y">
		<a href="<?php echo BLOG_URL; ?>" onClick="this.style.behavior='url(#default#homepage)';this.setHomePage('<?php echo BLOG_URL; ?>')">设为首页</a>
		<a title="RSS订阅" href="<?php echo BLOG_URL; ?>rss.php">订阅本站</a>
		</div>
	</div>
</div>

<!--整个布局开始-->
<div class="wrap">
<div class="space"></div>
<!--header包括左侧logo跟右侧登陆相关-->
<div class="header">
    	<div class="logo"><a href="<?php echo BLOG_URL; ?>"></a>
		</div>
		<!--
			头部挂载点，顶部广告钩子，
			适合官网那个广告插件。
		-->
		<?php doAction('index_head_ad');?>
    	<span class="right"><!--右侧登陆相关-->
			<?php if($istwitter == 'y'):?>
				<a href="<?php echo BLOG_URL; ?>t/">微语</a>
			<?php endif;?>
			<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
				<a href="<?php echo BLOG_URL; ?>admin/write_log.php">写作</a>
				<a href="<?php echo BLOG_URL; ?>admin/">管理中心</a>
				<a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a>
			<?php else: ?>
				<a href="<?php echo BLOG_URL; ?>admin/">登录</a>
			<?php endif; ?> 
		</span>  
</div>
<div class="space"></div>
<div id="nav"><?php blog_navi();?></div>
<!--以下是自定义banner,自己改链接,默认为自己的博客主页。默认的图片宽度是960px,高度没限制。自己控制-->
<div id="banner"><a href="<?php echo BLOG_URL;?>" target="_blank"><img src="<?php echo BLOG_URL.Option::get('topimg'); ?>"width="960px" border="0"/></a></div>
  <!--碎语滚动-->

  <div id="notice">
		<?php
			global $CACHE; 
			$newtws_cache = $CACHE->readCache('newtw');
			$istwitter = Option::get('istwitter');
		?>
		<?php foreach($newtws_cache as $value): ?>
		<ul>
			<li>
				<a href="<?php echo BLOG_URL . 't/'; ?>"><?php echo substr($value['t'],0,100); ?></a>
			</li>
		</ul>
		<?php endforeach; ?>
</div>
<div style="clear:both;"></div>
	<script>
		var c, _ = Function;
		with( o = document.getElementById("notice")) {
			innerHTML += innerHTML;
			onmouseover = _("c=1");
			onmouseout = _("c=0");
		}( F = _("if(#%27||!c)#++,#%=o.scrollHeight>>1;setTimeout(F,#%27?10:4000);".replace(/#/g, "o.scrollTop")))();
	</script>

