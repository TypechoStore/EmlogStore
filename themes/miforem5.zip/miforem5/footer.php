<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div style="clear:both;"></div>
<div class="space"></div>
<!--友情链接-->
<div id="links">
<span class="links">友情链接</span>
	<?php {global $CACHE;$link_cache = $CACHE->readCache('link');?>
	<ul>
	<?php foreach($link_cache as $value): ?>
	<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
	<?php endforeach; ?>
	</ul>
<?php }?>
</div>
<!--footer-->
<div class="footer">
	<div class="copyright">Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">Emlog</a>
   							 Theme by <a href="http://zhangziheng.com/" title="子恒网络博客" target="_blank">jaeheng</a><br> 
  								 © 2011-<?php echo date(Y);?> 
     
   </div>
    <div class="right">
		<span class="navr">
			<a href="<?php echo BLOG_URL; ?>?post=192" target="_blank">联系我们</a> | <a href="<?php echo BLOG_URL; ?>m" target="_blank">手机版</a> | <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>(<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>)
		</span><br />
		<span><?php echo date("Y年m月d日");?>| <?php echo $footer_info; ?> |
		</span>
	</div><!--right-->
	<div class="clear"></div>
</div><!--end #footer-->
</div><!--end #warp-->

<?php doAction('index_footer'); ?>
<?php doAction('em_ad_couplet');?>
<?php doAction('em_ad_button_window');?>
</body>
</html>