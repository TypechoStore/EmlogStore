<?php 
/*
* 侧边栏组件、页面模块
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
	<li>
	<h3 class="wtitle"><span><span class="icon-user">  </span><?php echo $title; ?></span></h3>
	<ul id="bloggerinfo">
	<div id="bloggerinfoimg">
	<?php if (!empty($user_cache[1]['photo']['src'])): ?>
	<img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="<?php echo $user_cache[1]['photo']['width']; ?>" height="<?php echo $user_cache[1]['photo']['height']; ?>" alt="blogger" />
	<?php endif;?>
	</div>
	<p><b><?php echo $name; ?></b>
	<?php echo $user_cache[1]['des']; ?></p>
	</ul>
	</li>
<?php }?>
<?php
//widget：日历
function widget_calendar($title){ ?>
	<li>
	<h3 class="wtitle"><span><span class="icon-cal2">  </span><?php echo $title; ?></span></h3>
	<div id="calendar">
	</div>
	<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
	</li>
<?php }?>
<?php
//widget：标签 修改为彩色的，实际上只是随机显示几种已经设定好的颜色
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
	<li>
	<h3 class="wtitle"><span><span class="icon-tags">  </span><?php echo $title; ?></span></h3>
	<ul id="blogtags">
	<?php foreach($tag_cache as $value): ?>
		<span style="font-size:<?php echo $value['fontsize']; ?>pt; line-height:30px;" class="color<?php echo rand(1,13); ?>">
		<a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇日志"><?php echo $value['tagname']; ?></a></span>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	<li>
	<h3 class="wtitle"><span><span class="icon-menu">  </span><?php echo $title; ?></span></h3>
	<ul id="blogsort">
	<?php
	foreach($sort_cache as $value):
		if ($value['pid'] != 0) continue;
	?>
	<li><span class="icon-wm">  </span>
	<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
	<a href="<?php echo BLOG_URL; ?>rss.php?sort=<?php echo $value['sid']; ?>"><span class="icon-rss"></span></a>
	<?php if (!empty($value['children'])): ?>
		<ol class="submenuu">
		<?php
		$children = $value['children'];
		foreach ($children as $key):
			$value = $sort_cache[$key];
		?>
		<li>
		  <span class="icon-wsm">  </span><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
		  <a href="<?php echo BLOG_URL; ?>rss.php?sort=<?php echo $value['sid']; ?>"><span class="icon-rss"></span></a>
		</li>
		<?php endforeach; ?>
		</ol>
	<?php endif; ?>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：最新碎语
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	?>
	<li>
	<h3 class="wtitle"><span><span class="icon-list">  </span><?php echo $title; ?></span></h3>
	<ul id="twitter">
	<?php foreach($newtws_cache as $value): ?>
	<?php $img = empty($value['img']) ? "" : '<a title="点击查看图片" class="t_img" href="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" target="_blank">&nbsp;</a>';?>
	<li><span class="icon-art"></span> <?php echo $value['t']; ?><?php echo $img;?><p><?php echo smartDate($value['date']); ?></p></li>
	<?php endforeach; ?>
    <?php if ($istwitter == 'y') :?>
	<p><a href="<?php echo BLOG_URL . 't/'; ?>">更多&raquo;</a></p>
	<?php endif;?>
	</ul>
	</li>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
	<li>
	<h3 class="wtitle"><span><span class="icon-wcom">  </span><?php echo $title; ?></span></h3>
	<ul id="newcomment">
	<?php
	foreach($com_cache as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	?>
	<li class="wcomment"><div class="w_avatar"><img src="<?php echo getGravatar($value['mail']); ?>" /></div><?php echo $value['name']; ?>
	<br /><a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a></li>
	<?php endforeach; ?>
	<div class="clear"></div>
	</ul>
	</li>
<?php }?>
<?php
//widget：最新日志
function widget_newlog($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
	<li>
	<h3 class="wtitle"><span><span class="icon-list">  </span><?php echo $title; ?></span></h3>
	<ul id="newlog">
	<?php foreach($newLogs_cache as $value): ?>
	<li><span class="icon-art"></span> <a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：热门日志
function widget_hotlog($title){
	$index_hotlognum = Option::get('index_hotlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getHotLog($index_hotlognum);?>
	<li>
	<h3 class="wtitle"><span><span class="icon-list">  </span><?php echo $title; ?></span></h3>
	<ul id="hotlog">
	<?php foreach($randLogs as $value): ?>
	<li><span class="icon-art"></span> <a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：随机文章
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	<li>
	<h3 class="wtitle"><span><span class="icon-list">  </span><?php echo $title; ?></span></h3>
	<ul id="randlog">
	<?php foreach($randLogs as $value): ?>
	<li><span class="icon-art"></span> <a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
	<li>
	<h3 class="wtitle"><span><span class="icon-list">  </span><?php echo $title; ?></span></h3>
	<ul id="logserch">
	<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php" class="wform" >
	<input name="keyword" class="winput" type="text" />
	<input type="submit" class="wsubmit" value="搜">
	</form>
	<div class="clear" ></div>
	</ul>
	</li>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
	<li>
	<h3 class="wtitle"><span><span class="icon-list">  </span><?php echo $title; ?></span></h3>
	<ul id="record">
	<?php foreach($record_cache as $value): ?>
	<li><span class="icon-play"></span> <a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
	<?php endforeach; ?>
	</ul>
	<div class="clear"></div>
	</li>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
	<li>
	<h3 class="wtitle"><span><span class="icon-list">  </span><?php echo $title; ?></span></h3>
	<ul>
	<?php echo $content; ?>
	</ul>
	</li>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
	?>
	<li>
	<h3 class="wtitle"><span><span class="icon-yqlink">  </span><?php echo $title; ?></span></h3>
	<ul id="link">
	<?php foreach($link_cache as $value): ?>
	<li><span class="icon-link"></span> <a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	<div class="clear" ></div>
	</li>
<?php }?>
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	?>

	<?php
	foreach($navi_cache as $value):
		if($value['url'] == 'admin'):
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
                $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
                $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'current' : 'common';
		?>
		<li class="<?php echo $current_tab;?>">
                <a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a>
                <?php if (!empty($value['children'])) :?>
                <ul >
                <?php foreach ($value['children'] as $row){
                        echo '<li class="sub-menu"><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></li>';
                }?>
		</ul>
                <?php endif;?>
                </li>
	<?php endforeach; ?>

<?php }?>
<?php
//blog：置顶
function topflg($istop){
	$topflg = $istop == 'y' ? "<img src=\"".TEMPLATE_URL."/images/top.gif\" alt=\"置顶日志\" /> " : '';
	echo $topflg;
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == 'admin' || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'"> <span class="icon-edit"></span> 编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
	<a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
	<?php endif;?>
<?php }?>
<?php
//blog：日志标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '<br /><span class="icon-tags"></span>本文标签：';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "	<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
		}
		echo $tag;
	}
}
?>
<?php
//blog：日志作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻日志
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog):?>
	<span class="icon-left"></span>上一篇： <a href="<?php echo Url::log($prevLog['gid']) ?>"><?php echo $prevLog['title'];?></a>
	<?php endif;?>
	<?php if($nextLog && $prevLog):?>
	<br />
	<?php endif;?>
	<?php if($nextLog):?>
	<span class="icon-right"></span>下一篇：<a href="<?php echo Url::log($nextLog['gid']) ?>"><?php echo $nextLog['title'];?></a>
	<?php endif;?>
<?php }?>
<?php
//blog：博客评论列表
function blog_comments($comments){
    extract($comments); ?>
	<?php
	$isGravatar = Option::get('isgravatar');
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<div class="comment comment_f" id="comment-<?php echo $comment['cid']; ?>">
		<a name="<?php echo $comment['cid']; ?>"></a>
		<?php if($isGravatar == 'y'): ?><div class="avatar"><img src="<?php echo getGravatar($comment['mail']); ?>"  alt="avatar" /></div><?php endif; ?>
		<div class="comment-info">
			<b><?php echo $comment['poster']; ?> </b><span class="comment-time"><?php echo $comment['date']; ?></span> &#8260; <span class="comment-reply"><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a></span>
			<div class="comment-content"><?php echo $comment['content']; ?></div>
			
		</div>
		<?php blog_comments_children($comments, $comment['children']); ?>
	</div>
	<?php endforeach; ?>

    <div id="comnavi">
	    <?php echo $commentPageUrl;?>
    </div>
	<div class="clear"></div>
<?php }?>
<?php
//blog：博客子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<div class="comment comment-children com_l<?php echo $comment['level'];?>" id="comment-<?php echo $comment['cid']; ?>">
		<a name="<?php echo $comment['cid']; ?>"></a>
		<?php if($isGravatar == 'y'): ?><div class="avatar"><img src="<?php echo getGravatar($comment['mail']); ?>" alt="avatar" /></div><?php endif; ?>
		<div class="comment-info">
			<b><?php echo $comment['poster']; ?> </b><span class="comment-time"><?php echo $comment['date']; ?></span><?php if($comment['level'] < 4): ?><span class="comment-reply"> / <a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a></span><?php endif; ?>
			<div class="comment-content"><?php echo $comment['content']; ?></div>
			
		</div>
		<?php blog_comments_children($comments, $comment['children']);?>
	</div>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark,$ad_com="0"){
	if($allow_remark == 'y'): ?>
	<div id="comment-place">
	<div id="respond">
	<div class="comment-post" id="comment-post">
		<div class="cancel-reply" id="cancel-reply" style="display:none"><a href="javascript:void(0);" onclick="cancelReply()">取消回复</a></div>
		<a name="respond"></a>
		<div class="commentform">
		<form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
			<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
			<?php if(ROLE == 'visitor'): ?>
<div class="ad_com">
<?php
 include View::getView('ad_com');
?>
</div>
			<div class="vinfo"><p>
				<input type="text" name="comname" maxlength="49" value="<?php echo $ckname; ?>"  tabindex="1" size="22" class="commenttext" id="author" />
				<label for="author">昵称*</label>
			</p>
			<p>
				<input type="text" name="commail"  maxlength="128"  value="<?php echo $ckmail; ?>" size="22" tabindex="2" class="commenttext" id="email" />
				<label for="email">邮箱</label>
			</p>
			<p>
				<input type="text" name="comurl" maxlength="128"  value="<?php echo $ckurl; ?>" size="22" tabindex="3" class="commenttext" id="url" />
				<label for="url">网址</label>
			</p>
			</div>
			<?php endif; ?>
			<p class="imgcode"><?php echo $verifyCode; ?></p><div class="clear"></div>
			<p><textarea name="comment" id="comment" rows="10" cols="20" tabindex="6"></textarea></p>
			<p> <input type="submit" class="submit" id="comment_submit" value="发表评论（Ctrl+Enter）" tabindex="7" /></p>
			<input type="hidden" name="pid" id="comment-pid" value="0" />
		</form>
		</div>
	</div>
	</div>
	</div>
	<?php endif; ?>
<?php }?>
<?php
//首页友情链接
function index_flinks(){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
	?>
	<?php foreach($link_cache as $value): ?>
	<a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><span class="icon-link"></span> <?php echo $value['link']; ?></a>
	<?php endforeach; ?>
<?php }?>
<?php
//首页栏目列表，偶用了很复杂的方式来实现，不知道是否有更简单的方法？
function get_list($sort){
			$db = MySql::getInstance();
			?>
			<div class="index_list_box">
			<?php
			$sql = "SELECT sortname FROM ".DB_PREFIX."sort WHERE sid=".$sort;
			$s = $db->query($sql);
			$sortname = $db->fetch_array($s);
			?>
			<div class="index_cat_title">
				<h3><a href="<?php echo Url::sort($sort);?>"><span class="icon-menu"></span> <?php echo $sortname['sortname'];?></a></h3>
			<span class="cat_more"><a href="<?php echo Url::sort($sort);?>">+more</a></span><div class="clear"></div>
			</div>
			<ul class="index_list_first">
			<?php
			$sqlf = "SELECT gid,title,date,content FROM ".DB_PREFIX."blog WHERE sortid=".$sort." AND hide='n' ORDER BY `date` DESC LIMIT 0,1";
			$first = $db->query($sqlf);
			while($row = $db->fetch_array($first)){
			?>
			<li>
			<?php			
$thum_pic = EMLOG_ROOT.'/thumpic/'.$row['gid'].'.jpg';
if (is_file($thum_pic)) {

    $thum_url = BLOG_URL.'thumpic/'.$row['gid'].'.jpg'; 
	
}else{
$sql = "SELECT `A`.`blogid` as `g`, `A`.`filepath`, `B`.`title` as `t`, `B`.`date` as `d`, `B`.`content` as `c` FROM ".DB_PREFIX."attachment `A` LEFT JOIN ".DB_PREFIX."blog `B` ON `A`.`blogid`=`B`.`gid` WHERE `B`.`hide`='n' AND (`A`.`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') AND (`A`.`blogid`=".$row['gid'].") GROUP BY `A`.`blogid` ORDER BY `A`.`addtime` DESC LIMIT 0,1";
	$imgs = $db->query($sql);
    while($roww = $db->fetch_array($imgs)){
	 $thum_url=BLOG_URL.substr($roww['filepath'],3,strlen($roww['filepath']));	 
    }
    if (empty($thum_url)) {
srand((double)microtime()*1000000); 
$randval   =   rand(0,9); 

            $thum_url = BLOG_URL.'content/templates/DaZengCMS/images/rand/'.$randval.'.jpg';

        }
    }
			
	?>
	<span class="index_img"><a href="<?php echo Url::log($row['gid']);?>" title="<?php echo $row['title'];?>"><img  src="<?php echo $thum_url;?>" width="100px" height="76px" alt="<?php echo $row['title'];?>" /></a></span>
	<h4 class="index_title"><a href="<?php echo Url::log($row['gid']);?>" title="<?php echo $row['title'];?>" ><?php echo $row['title'];?></a></h4>
<span class="index_des"><?php echo subString(strip_tags($row['content']),0,40);?>...</span>	
</li>
<?php
}?>
</ul>
<ul class="index_list">
<?php				
				
			$sql2 = "SELECT gid,title,date FROM ".DB_PREFIX."blog WHERE sortid=".$sort." AND hide='n' ORDER BY `date` DESC LIMIT 1,11";
			$list = $db->query($sql2);
			while($row = $db->fetch_array($list)){
				?>
				
		  			<li>
					<a href="<?php echo Url::log($row['gid']);?>" rel="bookmark" title="<?php echo $row['title'];?>"><span class="icon-play"> </span><?php echo $row['title'];?></a>

					<span class="idate"><?php echo gmdate('m-d', $row['date']);?></span>
				</li>
				<?php
				}
				?>
				</ul>
			<div class="clear"></div>
		</div>
	<?php	}
		
?>
<?php
//获取文章缩略图，先是自定义指定，然后是查找附件图片，最后是随机图片
//思路来自独头茧
function get_thum($logid){
 $db = MySql::getInstance();
$thum_pic = EMLOG_ROOT.'/thumpic/'.$logid.'.jpg';
if (is_file($thum_pic)) {
    $thum_url = BLOG_URL.'thumpic/'.$logid.'.jpg'; 
}else{
	$sqlimg = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$logid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";
//    die($sql);
	$img = $db->query($sqlimg);
    while($roww = $db->fetch_array($img)){
	 $thum_url=BLOG_URL.substr($roww['filepath'],3,strlen($roww['filepath']));
    }
    if (empty($thum_url)) {
	
srand((double)microtime()*1000000); 
$randval   =   rand(0,9); 

            $thum_url = BLOG_URL.'content/templates/DaZengCMS/images/rand/'.$randval.'.jpg';
        }
    }
echo $thum_url;
}
?>
<?php
//此函数为奇遇大大的相关日志函数，因排版需要，在此集成到本主题中，希望奇遇大大不要介意。
//保留读取相关日志配置（即你在后台设置的，请将日志数量设为10），如果没有安装相关日志插件，请按下面说明进行修改或保持默认。
function related_logs($logData = array())
{
$configfile = EMLOG_ROOT.'/content/plugins/related_log/related_log_config.php';
if (is_file($configfile)) {
require $configfile;
}else{
	$related_log_type = 'sort';//相关日志类型，sort为分类，tag为日志；
	$related_log_sort = 'rand';//排列方式，views_desc 为点击数（降序）comnum_desc 为评论数（降序） rand 为随机 views_asc 为点击数（升序）comnum_asc 为评论数（升序）
	$related_log_num = '10'; //显示文章数，排版需要，只能为10
	$related_inrss = 'y'; //是否显示在rss订阅中，y为是，其它值为否
	}
	global $value;
	$DB = MySql::getInstance();
	$CACHE = Cache::getInstance();
	extract($logData);
	if($value)
	{
		$logid = $value['id'];
		$sortid = $value['sortid'];
		global $abstract;
	}
	$sql = "SELECT gid,title FROM ".DB_PREFIX."blog WHERE hide='n' AND type='blog'";
	if($related_log_type == 'tag')
	{
		$log_cache_tags = $CACHE->readCache('logtags');
		$Tag_Model = new Tag_Model();
		$related_log_id_str = '0';
		foreach($log_cache_tags[$logid] as $key => $val)
		{
			$related_log_id_str .= ','.$Tag_Model->getTagByName($val['tagname']);
		}
		$sql .= " AND gid!=$logid AND gid IN ($related_log_id_str)";
	}else{
		$sql .= " AND gid!=$logid AND sortid=$sortid";
	}
	switch ($related_log_sort)
	{
		case 'views_desc':
		{
			$sql .= " ORDER BY views DESC";
			break;
		}
		case 'views_asc':
		{
			$sql .= " ORDER BY views ASC";
			break;
		}
		case 'comnum_desc':
		{
			$sql .= " ORDER BY comnum DESC";
			break;
		}
		case 'comnum_asc':
		{
			$sql .= " ORDER BY comnum ASC";
			break;
		}
		case 'rand':
		{
			$sql .= " ORDER BY rand()";
			break;
		}
	}
	$sql .= " LIMIT 0,$related_log_num";
	$related_logs = array();
	$query = $DB->query($sql);
	while($row = $DB->fetch_array($query))
	{
		$row['gid'] = intval($row['gid']);
		$row['title'] = htmlspecialchars($row['title']);
		$related_logs[] = $row;
	}
	$out = '';
	if(!empty($related_logs))
	{
		foreach($related_logs as $val)
		{
			$out .= "<li><span class='icon-play'></span> <a href=\"".Url::log($val['gid'])."\">{$val['title']}</a></li>";
		}
	}
	if(!empty($value['content']))
	{
		if($related_inrss == 'y')
		{
			$abstract .= $out;
		}
	}else{
		echo $out;
	}
}

?>
<?php
//文章底部随机图片文章
function get_rand_log(){
	$index_randlognum = 6;
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	<?php foreach($randLogs as $value): ?>
	<a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>" ><img src="<?php get_thum($value['gid']); ?>" ></a>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：图片幻灯,直接拷贝于CMSONE
function blog_image_slide($count){
    ?>
    <div class="box_skitter box_skitter_normal">
    <ul>
    <?php
    $db = MySql::getInstance();
    $sql = "SELECT a.filepath,b.title,b.gid  FROM ".DB_PREFIX."attachment as a, ".DB_PREFIX."blog as b where a.blogid=b.gid and a.thumfor=0 ORDER BY a.addtime DESC limit $count";
	$ret = $db->query($sql);
    $items = array();
	while ($row = $db->fetch_array($ret)) {
		$row['filepath'] = $atturl = BLOG_URL.substr($row['filepath'], 3);
		$row['title'] = htmlspecialchars($row['title']);
		$row['logurl'] = Url::log(intval($row['gid']));
		$items[] = $row;
	}
	foreach($items as $val):
	?>
        <li>
	<a href="<?php echo $val['logurl'];?>" target="_blank">
        <img  width="320px" height="240px" src="<?php echo $val['filepath'];?>" alt="<?php echo $val['title'];?>" />
        </a>
	<div class="label_text"><p><?php echo $val['title'];?></p></div>
	</li>
	<?php endforeach; ?>
	</ul>
    </div>
<?php }?>
	<?php
//widget：首页随机推荐，其实就是随机文章
function index_rand_log(){
	$index_randlognum = 8;
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	<?php foreach($randLogs as $value): ?>
	<li><span class="icon-play"></span>  <a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>" ><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：N天内热门
function blog_ndayhot($count, $n){
    ?>
    <div class="focus_top">
    <?php
    $curdate = time();
    $db = MySql::getInstance();
    $sql = "SELECT * FROM " . DB_PREFIX . "blog WHERE type='blog' and hide='n' and date>UNIX_TIMESTAMP()-86400*$n order by views desc limit $count";
	$ret = $db->query($sql);
    $items = array();
    global $CACHE;
	$user_cache = $CACHE->readCache('user');
	while ($row = $db->fetch_array($ret)) {
		$row['title'] = htmlspecialchars($row['title']);
        $row['excerpt'] = htmlspecialchars(strip_tags($row['excerpt']));
		$row['logurl'] = Url::log(intval($row['gid']));
        $row['author'] = '<a href="'.Url::author($row['author']).'">' . $user_cache[$row['author']]['name'].'</a>';
        $row['date'] = gmdate('Y.n.j', $row['date']);
		$items[] = $row;
	}
	foreach($items as $val):
	?>
	<li><span class="icon-play"></span>  <a href="<?php echo $val['logurl']; ?>" title="<?php echo $val['title']; ?>" ><?php echo $val['title']; ?></a></li>
	<?php endforeach; ?>
    </div>
<?php }?>






<?php
//侧边栏TAB用:最新发表、热评文章、随机文章
function widget_tablist($by,$num="5") {
    if($by=="new"){//最新发表
        $order = 'ORDER BY date DESC';
    }elseif($by=="hot"){//热评文章
        $order = 'ORDER BY comnum DESC';
    }else{//随机文章
        $order = 'ORDER BY rand()';
    }
    $db=MySql::getInstance();
    $logs = $db->query("SELECT gid ,title FROM " . DB_PREFIX . "blog WHERE hide='n' and type='blog' $order LIMIT 0, $num");
    while ($row = $db->fetch_array($logs)){
        $row['title'] = htmlspecialchars($row['title']);
     ?>
    <li><a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>" ><?php echo $row['title']; ?></a></li>
	<?php } ?>
<?php }?>