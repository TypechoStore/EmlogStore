<?php 
/*
* 日志
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="main">
	<div id="mainleft">
		<div id="loc">
			<div class="here">现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; <?php blog_sort($logid); ?> &raquo;
			</div>		
		</div> 
		<div id="art_box">
					<h2 class="art_title"><?php echo $log_title; ?></h2>
					<span class="art_beta">作者：<?php blog_author($author); ?> &#8260; 时间：<?php echo gmdate('Y年m月d日', $date); ?> &#8260; 分类：<b><?php blog_sort($logid); ?></b> &#8260; <a href="#respond" title="坐电梯直达评论">评论：<?php echo $comnum;?></a><?php editflg($logid,$author); ?></span>
					<span class="art_content"><?php include View::getView('ad_artf');?><?php echo $log_content; ?><?php include View::getView('ad_artb');?></span>
					<span class="art_info">
					本文由<?php blog_author($author); ?>原创或编辑，转载请保留链接<a href="<?php echo Url::log($logid); ?>" >【<?php echo $log_title; ?>】<?php echo Url::log($logid); ?></a>
					<?php if($allow_tb == 'y' && Option::get('istrackback') == 'y'){echo '<br />引用地址:	'.$tb_url; }?>
					<?php blog_tag($logid); ?>
					</span>
					<span class="art_pre_next">
					<?php neighbor_log($neighborLog); ?>
					</span>
					<span class="art_related">
					<?php doAction('log_related', $logData); ?>
					</span>
		</div>
		<div id="art_about">
			<span class="about_left">
			<h3><span class="icon-list"></span> 随机推荐</h3>
				<ul>
<li class="thum_news"><?php get_rand_log();?>
</li>
				</ul>
			</span>
			<span class="about_right">
			<h3><span class="icon-list"></span> 相关文章</h3>
				<ul>
<?php related_logs($logData);?>
				</ul>
			</span>
			<div class="clear"></div>
			<?php
		include View::getView('ad_about');
		?>
		</div>
<div class="comment_header">目前有 <?php echo $comnum;?> 条评论</div>
	<?php blog_comments($comments); ?>	
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark,$ad_com); ?>	

	</div>
	<div id="mainright">
		<?php
		include View::getView('side');
		?>
	</div>
</div>
<div class="clear space">
<?php
 include View::getView('footer');
?>
</body>
</html>