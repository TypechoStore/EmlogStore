<?php
/*
Template Name:DaZengCMS
Description:简单大气的博客/CMS模板~~
Version:0.2
Author:大曾
Author Url:http://www.dzlog.com
Sidebar Amount:1
ForEmlog:5.2.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title><?php echo $site_title; ?></title>
        <meta name="keywords" content="<?php echo $site_key; ?>" />
        <meta name="description" content="<?php echo $site_description; ?>" />
        <meta name="generator" content="emlog" />
        <link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
        <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
        <link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
        <link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
		<?php if($pageurl == Url::logPage()){?>
		<link href="<?php echo TEMPLATE_URL; ?>slider.css" rel="stylesheet" type="text/css" />
 <?php
}
?>
        <script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
        <?php
        emLoadJQuery();
        doAction('index_head');
        ?>
        <script src="<?php echo TEMPLATE_URL; ?>js/jquery.scrolltotop.js"></script>
        <script src="<?php echo TEMPLATE_URL; ?>js/jquery.skitter.js"></script>
        <script src="<?php echo TEMPLATE_URL; ?>js/jquery.easing.1.3.js"></script>

    </head>
<body>
<div id="header">
	<div id="logo">
	<h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
	<span class="blog_des"><?php echo $bloginfo; ?></span>
	</div>
	<div id="header_right">
		<?php include View::getView('ad_headercenter');	?>

	</div>
	<div id="contact">
		<ul>
			<li id="text">关注本博</li><!--这个下面的得修改成自己的，呵呵-->
			<li id="sina"><a href="http://weibo.com/zxj5" target="_blank" title="关注我的新浪微博">新浪微博</a></li>
			<li id="tqq"><a href="http://t.qq.com/iamjun" target="_blank" title="关注我的腾讯微博">腾讯微博</a></li>
			<li id="rss"><a href="<?php echo BLOG_URL; ?>rss.php" target="_blank" title="RSS订阅我的博客">RSS订阅</a></li>
			<li id="qq"><a href="#" target="_blank" title="联系QQ：80039551">QQ联系</a></li>
			<li id="tt"><a href="#" target="_blank" title="Twitter Me">Twitter</a></li>
		</ul>
	</div>
	<div id="searchbar">
		<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php" class="wform">
			<input name="keyword"  type="text" value="" class="winput" />
			<input type="submit" id="logserch_logserch" value="搜"  class="wsubmit" />
		</form>
	</div>
</div>
<div id="main_nav">
	<div class="nav">
	<ul class="menu" id="jsddm">
	<li class="<?php if($pageurl == Url::logPage()){ ?>current <?php }else{}?>"><a href="<?php echo BLOG_URL; ?>"><span class="icon-home"></span> 首页</a></li>
<?php blog_navi();?>
</ul>
	</div>
</div>
<div class="clear space"></div>