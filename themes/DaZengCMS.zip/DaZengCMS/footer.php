<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
//敬请保留emlog及模板作者链接，谢谢~~
?>
<div id="footer">
<div id="infooter">
Copyright &copy; <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a> Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> & Theme by <a href="http://www.dzlog.com" title="大曾博客">ZENG</a>
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
<?php doAction('index_footer'); ?>
</div>

</div>
<script>
    jQuery(function($) {
        $.scrolltotop({
            className: 'totop',
            controlHTML: '<div class="totop" id="topcontrol" style="position: fixed; bottom: 40px; right: 25px; opacity: 1; cursor: pointer;width:50px;text-align:center;"><a href="javascript:;"><span class="icon-up"></span><br /><b>回<br />顶<br />部</b></a></div>',
            offsety: 0
        });
    });

    var timeout = 500;
    var closetimer = 0;
    var ddmenuitem = 0;
    function jsddm_open() {
        jsddm_canceltimer();
        jsddm_close();
        ddmenuitem = $(this).find('ul').eq(0).css('visibility', 'visible');
    }
    function jsddm_close() {
        if (ddmenuitem)
            ddmenuitem.css('visibility', 'hidden');
    }
    function jsddm_timer() {
        closetimer = window.setTimeout(jsddm_close, timeout);
    }
    function jsddm_canceltimer() {
        if (closetimer) {
            window.clearTimeout(closetimer);
            closetimer = null;
        }
    }
    $(document).ready(function() {
        $('#jsddm > li').bind('mouseover', jsddm_open);
        $('#jsddm > li').bind('mouseout', jsddm_timer);
    });
    document.onclick = jsddm_close;
</script>