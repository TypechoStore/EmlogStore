<div id="main">
	<div id="mainleft">
		<div class="index_list_box">
			<div id="sidepic">
			<h3><span class="icon-list"></span> 本月最热推荐</h3>
			<ul>
			<?php blog_ndayhot(8, 30);?>
			</ul>
			</div>
			<div id="picnews">
            <?php
            blog_image_slide(5);
            ?>
            <script>
                $(document).ready(function() {
                    $('.box_skitter_normal').css({width: 320, height: 240}).skitter({animation: 'blind', interval: 2000, hideTools: true, theme: 'minimalist'});
                });
            </script>

			</div>
			<div class="clear"></div>
		 </div> 
		<?php
			include View::getView('ad_indexpicbottom');
		?>
<?php //请将要在首页显示的分类添加到下面，默认是id为1~4的4个分类。?>
	<?php get_list('1');?>
	<?php get_list('2');?>
	<?php get_list('3');?>
	<?php get_list('4');?>
<?php //如果不想在首页显示带摘要的最新文章列表，请从下一行（第32行）开始删除，?>
		<ul class="list_box">
			<?php doAction('index_loglist_top'); ?>
			<?php foreach($logs as $value): $i++;?>
			<li class="list_log">
					<span class="list_imgt"><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><img  src="<?php get_thum($value['logid']);?>" width="160px" height="120px" alt="<?php echo $value['log_title']; ?>"/></a></span>
					<h4 class="index_title">【<?php blog_sort($value['logid']); ?>】<?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></h4>
					<span class="list_des"><?php echo subString(strip_tags($value['content']),0,120);?>...</span>
					<span class="list_beta">日期：<?php echo gmdate('Y-m-d', $value['date']); ?>  <span class="icon-view"></span> 浏览：<?php echo $value['views']; ?> <span class="icon-bubbles"></span> 评论：<?php echo $value['comnum']; ?></span>
			</li>
			<?php if($i==1){include View::getView('ad_list');}?>
			<?php endforeach; ?>			
		</ul>
<?php //直到上一行（第43行）。?>	
	</div>
	<div id="mainright">
		<?php
		include View::getView('side');
		?>
	</div>
</div>
<div class="clear space">
<?php //首页的友情链接不想要？从下一行（第54行）开始删除。?>
<div id="index_flinks">
	<h4><span class="icon-yqlink"></span> 友情链接</h4>
	<div class="inerf">
	<?php index_flinks();?>
	<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
<div class="clear space">
<?php //直到上一行（第62行）。?>
<?php
 include View::getView('footer');
?>
</body>
</html>