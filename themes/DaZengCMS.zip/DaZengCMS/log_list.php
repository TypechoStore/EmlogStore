<?php 
/*
* 日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<?php if($pageurl == Url::logPage()){?>
<?php
 include View::getView('index');
?>
 <?php
}else{
?>

<div id="main">
	<div id="mainleft">
		<div id="loc">
<div class="here">现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; 
<?php if ($params[1]=='sort'){ ?>
		<?php echo '<a href="'.Url::sort($sortid).'">'.$sortName.'</a>';?>
<?php }elseif ($params[1]=='tag'){ ?>
			包含标签 <b><?php echo urldecode($params[2]);?></b> 的所有文章
<?php }elseif($params[1]=='author'){ ?>
			作者 <b><?php echo blog_author($author);?></b> 的所有文章
<?php }elseif($params[1]=='keyword'){ ?>
            关键词 <b><?php echo urldecode($params[2]);?></b> 的搜索结果
<?php }elseif($params[1]=='record'){ ?>
           发表在 <b><?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?> </b>的所有文章
<?php }else{?><?php }?>
			 </div>		
</div> 
		
		<ul class="list_box">
			<?php doAction('index_loglist_top'); ?>
			<?php foreach($logs as $value): $i++;?>
			<li class="list_log">
					<span class="list_imgt"><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" ><img  src="<?php get_thum($value['logid']);?>" width="160px" height="120px" alt="<?php echo $value['log_title']; ?>"/></a></span>
					<h4 class="index_title"><?php topflg($value['top']); ?>                <?php if (!empty($value['children'])) :?>
               【<?php blog_sort($value['logid']); ?>】
                <?php endif;?><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" ><?php echo $value['log_title']; ?></a></h4>
					<span class="list_des"><?php echo subString(strip_tags($value['content']),0,120);?>...</span>
					<span class="list_beta"><span class="icon-time"></span> 日期：<?php echo gmdate('Y-m-d', $value['date']); ?> <span class="icon-menu"></span> 分类：<?php blog_sort($value['logid']); ?> <span class="icon-view"></span> 浏览：<?php echo $value['views']; ?> <span class="icon-bubbles"></span> 评论：<?php echo $value['comnum']; ?></span>
			</li>
<?php if($i==1){include View::getView('ad_list');}?>			
			<?php endforeach; ?>			
		</ul>
		<div class="navigation"><div class="pages"><?php echo $page_url;?></div></div>

	</div>
	<div id="mainright">
		<?php
		include View::getView('side');
		?>
	</div>
</div>
<div class="clear space">
<?php
 include View::getView('footer');
?>
</body>
</html>
</body>
</html>
<?php
	}
?>
