<?php
/*
Template Name:simue-wood-2
Description:仿木纹皮肤模板2
Version:4.1
Author:L卡片
Author Url:http://simue.com/blog/
Sidebar Amount:1
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php">
<link href="<?php echo TEMPLATE_URL; ?>css.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>other.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="header">
  <div class="header_body">
    <h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a><span class="description"><?php echo $bloginfo; ?></span></h1>
    <div id="nav">
    <ul>
    <?php blog_navi();?>
    </ul>
    </div>
  </div>
  <div class="plus">
    <ul>
    <li><a class="plus1" href="<?php echo BLOG_URL; ?>" title="返回首页">首页</a></li>
    <li><a class="plus2" href="<?php echo BLOG_URL; ?>rss.php" title="订阅博客最新文章" target="_blank">订阅</a></li>
    <li><a class="plus3" href="javascript:addfav()" title="将当前网址放入收藏夹">收藏</a></li>
    <li><a class="plus4" href="<?php echo BLOG_URL; ?>admin/" title="管理博客">管理</a></li>
    </ul>
  </div>
</div>
