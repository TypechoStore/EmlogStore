<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div id="main" class="echo_log">
	<div id="main_left">
	<div id="ml_content" class="narrowcolumn">
		<div class="post" id="post-<?php echo $logid; ?>">
			<div class="post_title">
				<h2><?php echo $log_title;?></h2>
			</div>
			<div class="post_content clear">
				<p><?php echo $log_content; ?></p>
			</div>
		</div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
	</div>
<?php include View::getView('side'); ?><div class="clear"></div>
</div>
<?php include View::getView('footer'); ?>