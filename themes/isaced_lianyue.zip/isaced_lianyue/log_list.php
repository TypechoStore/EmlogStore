﻿<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

	<div class="home_1">
          <div class="slide left"><img src="<?php echo TEMPLATE_URL; ?>images/head.jpg" width="700" height="270"> </div>
          <div class="newest" id="newest"><?php widget_newlog("最新日志");?>

	</div><!--#home_1 End-->

	<div class="page">
		<div class="home_cat left" >
			<div class="cat_blog cat_title content">
            <h2 class="title breadcrumb">当前位置 : <a href="#">首页</a></h2>
         <?php doAction('index_loglist_top'); ?>
		<?php foreach($logs as $value): ?>
            <ul>
                <li>
                    <h3><a href="<?php  echo $value['log_url']; //文章地址?>"><?php echo $value['log_title']; //文章标题?></a></h3>
                    <div class="excerpt"><img width="200" height="140"><?php echo $value['log_description'];  //文章摘要?></p></div>
                    <div class="meta">
                        <span class="comment"><?php echo $value['comnum']; ?></span>
                        <span class="date"><?php echo gmdate('Y-n-j', $value['date']); //发布时间 ?></span>
                        <span class="view"><?php echo $value['views']; ?></span>
                        <span class="category"><?php blog_sort($value['logid']); ?></span>
                    </div>
                </li>
            </ul>
            <?php endforeach; ?>
            <div class="vt_nav">

                
                <span class="page-numbers current">1</span>
                <a class="page-numbers" href="#">2</a>
            </div>
            
          </div>
          	 
		</div>
        
	<div class="right sidebar" id="sidebar">
        <div class="widget_archive"><h3 class="title">文章归档</h3>
        <ul>
            <li><a href="#" >2012 年八月</a></li>
            <li><a href="#">2012 年七月</a></li>
        </ul>
        </div>
        
    <div class="widget_tag_cloud">
        <h3 class="title">标签</h3>
        <div class="tagcloud">
            <a href="#"  title="2 个话题" style="font-size: 8pt;">无限</a>
        </div>
    </div>
    
	</div>		
    <div class="clear"></div>
    
<div class="links">
	<h3 class="title">
        <strong class="right">
            <a href="#" title="申请链接">申请链接</a>
        </strong>
        友情链接
    </h3>
	<ul>
		<li><a href="http://www.isaced.com" target="_blank">isaced</a></li>
	</ul>
</div>
</div>
</div>
<?php
 //include View::getView('side');
 include View::getView('footer');
?>