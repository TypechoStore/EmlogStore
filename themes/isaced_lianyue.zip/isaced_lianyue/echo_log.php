﻿<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div class="page">
		<div class="home_cat left" >
			<div class="cat_blog cat_title content">
            <h2 class="title breadcrumb">当前位置 : <a href="#">首页</a></h2>

            <ul>
                <li>
                    <h3><a href="<?php  echo $value['log_url']; //文章地址?>"><?php echo $log_title; //日志标题 ?></a></h3>
                    <?php echo $log_content;  //文章内容?>
                    <div class="meta">
                        <span class="comment"><?php echo $comnum; //评论数 ?></span>
                        <span class="date"><?php echo gmdate('l Y-n-j ', $date); //发布时间 ?></span>
                        <span class="view"><?php echo $views; //浏览量?></span>
                        <span class="category"><?php blog_sort($logid); //日志分类?> </span>
                    </div>
                </li>
            </ul>
            	<?php doAction('log_related', $logData); ?>

            
          </div>
          	 
		</div>
        
	<div class="right sidebar" id="sidebar">
        <div class="widget_archive"><h3 class="title">文章归档</h3>
        <ul>
            <li><a href="#" >2012 年八月</a></li>
            <li><a href="#">2012 年七月</a></li>
        </ul>
        </div>
        
    <div class="widget_tag_cloud">
        <h3 class="title">标签</h3>
        <div class="tagcloud">
            <a href="#"  title="2 个话题" style="font-size: 8pt;">无限</a>
        </div>
    </div>
    
	</div>		
    <div class="clear"></div>
    
<div class="links">
	<h3 class="title">
        <strong class="right">
            <a href="#" title="申请链接">申请链接</a>
        </strong>
        友情链接
    </h3>
	<ul>
		<li><a href="http://www.isaced.com" target="_blank">isaced</a></li>
	</ul>
</div>
</div>
</div>
<?php
 //include View::getView('side');
 include View::getView('footer');
?>