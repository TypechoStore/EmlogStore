﻿<?php
/*
Template Name:isaced_lianyue
Description:lianyue的一个主题，移植过来的。只是个空架子。
Version:0.1
Author:isaced
Author Url:http://www.isaced.com
Sidebar Amount:1
ForEmlog:4.2.1
*/

if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; //CSS文件地址 ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>

<div id="header_bg"></div>
<div class="wrapper">
	<div class="header">
    		<div id="logo">
				<h1><a href="<?php echo BLOG_URL; //链接 ?>"><?php echo $blogname; //博客标题 ?></a></h1>
             </div>
            <div class="header_right">
             <div id="search">
                   <form  name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
                        <input name="keyword" type="text" id="search-text" speech="speech" x-webkit-speech="x-webkit-speech" x-webkit-grammar="builtin:translate" />
                        <input type="submit" id="search-submit"  value="GO" />
                    </form>
			</div>
			<div class="clear"></div>
			<div class="menu_head" >
                <ul>
                    <li><a href="<?php echo BLOG_URL; ?>">首页</a></li>
                    <?php 
                        //输出自定义页面的链接
                        global $CACHE; 
						$navi_cache = $CACHE->readCache('navi');
						foreach ($navi_cache as $key => $val):
						if ($val['hide'] == 'y'){continue;}
						if (empty($val['url'])){$val['url'] = Url::log($key);}
						$val['is_blank'] = $val['newtab'] == 'y' ? 'target="_blank"' : '';
						$val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
                    ?>
                    <li><a href="<?php echo $val['url']; ?>" target="<?php echo $val['is_blank']; ?>"><?php echo $val['naviname']; ?></a></li>
                    <?php endforeach;?>
                    <?php doAction('navbar', '<li>', '</li>'); ?>
                </ul>
			</div>		
	</div><!--#right header_right End-->
	</div><!--#header End-->
    
    
    
    