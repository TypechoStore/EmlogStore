<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="contentleft">
<?php doAction('index_loglist_top'); ?>

	<?php 
		//获取图片URL
		$thum_src = get_Attachment_img($logid,0); //附件第一张图片
		if (empty($thum_src))
		{
			$thum_src = TEMPLATE_URL."images/none.jpg";
		}
	?>

	<div id="post-top">
		<div id="post-img"><img width="980" height="542" src="<?php echo $thum_src; ?>"></div>
		<div id="post-title"><h2><a href="<?php echo $value['log_url']; ?>"><?php echo $log_title; ?></a></h2></div>
		<div id="post-meta"><?php echo gmdate('l n,Y ', $value['date']); ?> | By:<?php blog_author($author); ?> | <?php echo $views; ?> views</div>
		<div id="post-content"><?php echo $log_content; ?></div>
		<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
		<?php blog_comments($comments); ?>
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
	<div style="clear:both;"></div>

<div id="pagenavi">
	<?php echo $page_url;?>
</div>
<?php
 //include View::getView('side');
 include View::getView('footer');
?>