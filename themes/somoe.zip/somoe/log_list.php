<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="contentleft">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>

	<?php 
		//获取图片URL
		$thum_src = get_Attachment_img($value['logid'],0); //附件第一张图片
		if (empty($thum_src))
		{
			$thum_src = TEMPLATE_URL."images/none.jpg";
		}
	?>

	<div id="post-top">
		<div id="post-img"><a href="<?php echo $value['log_url']; ?>"><img width="980" height="542" src="<?php echo $thum_src; ?>"></a></div>
		<div id="post-title"><h2><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2></div>
		<div id="post-meta"><?php echo gmdate('l n,Y ', $value['date']); ?> | By:<?php blog_author($value['author']); ?> | <?php echo $value['views']; ?> views</div>
		<div id="post-content"><?php echo $value['log_description']; ?></div>
	</div>
	<div style="clear:both;"></div>
<?php endforeach; ?>

<div id="pagenavi">
	<?php echo $page_url;?>
</div>

</div><!-- end #contentleft-->
<?php
 //include View::getView('side');
 include View::getView('footer');
?>