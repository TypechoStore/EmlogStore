<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div class="foot">
<div class="bottom_info">
<ul>
<li>&copy;<?php echo gmdate('Y');?> <?php echo $blogname;?></li>
<li>主题（<em>Show7</em>）</li>
<li><?php blogt();?></li>
</ul>
</div>
<div class="bottom_other">
<ul>
<li>博客系统（<a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank"><em>Emlog</em></a>）</li>
<li><?php echo $footer_info; ?></li>
<li><a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a></li>
</ul>
</div>
<div class="bottom_login">
<ul>
<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
<li class="common"><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
<li class="common"><a href="<?php echo BLOG_URL; ?>admin/">管理中心</a></li>
<li class="common"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
<?php else: ?>
<li class="common"><a href="<?php echo BLOG_URL; ?>admin/">登录</a></li>
<?php endif; ?>
</ul>
</div>
<div class="c"></div>
</div>
<?php doAction('index_footer'); ?>
<div class="ttop"><a href="javascript:void(0);" class="scroll_t"></a><a href="javascript:void(0);" class="scroll_b"></a></div>
</div>
</div>