jQuery(document).ready(function($){
$('.scroll_t').click(function(){$('html,body').animate({scrollTop: '0px'}, 800);}); 
$('.scroll_c').click(function(){$('html,body').animate({scrollTop:$('.comment-header').offset().top}, 800);});
$('.scroll_b').click(function(){$('html,body').animate({scrollTop:$('.foot').offset().top}, 800);});
});