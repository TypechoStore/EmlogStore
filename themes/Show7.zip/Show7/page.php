<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div class="center">
<div class="main_content">
<div class="content_body">
<div class="content_title"><?php echo $log_title; ?></div>
<div class="log_text"><?php echo $log_content; ?></div>
<?php blog_att($logid); ?>
</div>
<?php blog_comments($comments);?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);?>
</div>
<div class="main_side"><?php include View::getView('side');?></div>
<div class="c"></div>
</div>
<?php include View::getView('footer');?>