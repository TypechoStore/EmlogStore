<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div class="center">
<?php doAction('index_loglist_top'); ?>
<div class="main_content">
<?php foreach($logs as $value): ?>
<div class="content_body">
<div class="content_title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a><div class="view"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['views']; ?></a></div></div>
<div class="c"></div>
<div class="content_info">
<div class="content_date">
<div class="time"><?php $weekarray=array("日","一","二","三","四","五","六");echo gmdate('Y年n月j日 G:i', $value['date']); echo " 星期".$weekarray[gmdate('w', $value['date'])];?></div>
<?php blog_sort($value['logid']); ?>
<?php blog_tag($value['logid']); ?>
<div class="c"></div>
</div>
<div class="content_edit"><?php editflg($value['logid'],$value['author']); ?></div>
<div class="c"></div>
</div>
<div class="content_text"><?php echo $value['log_description']; ?></div>
<?php blog_att($value['logid']); ?>
<div class="content_data">
<a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a>
<a href="<?php echo $value['log_url']; ?>#tb">引用(<?php echo $value['tbcount']; ?>)</a>
</div>
</div>
<?php endforeach; ?>
<div class="page"><?php echo $page_url;?></div>
</div>
<div class="main_side"><?php include View::getView('side');?></div>
<div class="c"></div>
</div>
<?php include View::getView('footer');?>