<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div class="center">
<div class="main_content">
<div class="content_body">
<div class="content_title"><?php topflg($top); ?><?php echo $log_title; ?></div>
<div class="log_info">
<div class="content_date">
<div class="time">
<?php $weekarray=array("日","一","二","三","四","五","六");echo gmdate('Y年n月j日 G:i', $date);echo " 星期".$weekarray[gmdate('w', $date)];?></div><?php blog_sort($logid); ?>
</div>
<div class="content_edit"><?php editflg($logid,$author); ?></div>
<div class="c"></div>
</div>
<div class="log_text"><?php echo $log_content; ?></div>
<?php blog_att($logid); ?>
<?php blog_tag($logid); ?>
<div class="c"></div>
<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
<?php doAction('log_related', $logData); ?>
<?php neighbor_log($neighborLog); ?>
<div class="c"></div>
<?php blog_comments($comments);?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);?>
</div>
</div>
<div class="main_side"><?php include View::getView('side');?></div>
<div class="c"></div>
</div>
<?php include View::getView('footer');?>