<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
  <div class="blogs">
    <div id="index_view" style="width:96%">
        <h1 class="c_titile"><?php topflg($top); ?><?php echo $log_title; ?></h1>
        <ul>
          <p><?php echo $log_content; ?></p>
        </ul>
        <div id="tucao" style="border-top:solid 1px #ccc;">
            <?php doAction('log_related', $logData); ?>
            <?php blog_comments($comments); ?>
            <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
        </div>
    </div>
  
  
  </div>
</div>
<?php
 include View::getView('footer');
?>
