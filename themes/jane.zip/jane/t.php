<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="blogs">
    <div class="yunyu">
        <div class="ttop">
            <div class="ttop-left">逆境中，力挽狂澜使强者更强，随波逐流使弱者更弱。</div>
            <div class="ttop-right">
                <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
                    <a href="<?php echo BLOG_URL . 'admin/twitter.php' ?>">啐云语</a>
                <?php endif; ?>
            </div>
        </div>
        <ul>
        <?php 
        foreach($tws as $val):
        $author = $user_cache[$val['author']]['name'];
        $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                    BLOG_URL . 'admin/views/images/avatar.jpg' : 
                    BLOG_URL . $user_cache[$val['author']]['avatar'];
        $tid = (int)$val['id'];
        $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
        ?> 
        <li class="li">
        <div class="main_img"><img src="<?php echo $avatar; ?>" width="32px" height="32px" /></div>
        <div class="post1">
            <span><?php echo $author; ?></span><b>&nbsp;发布于<?php echo $val['date'];?></b>
            <br />
            <?php echo $val['t'].'<br/>'.$img;?>
        </div>
        </li>
        <?php endforeach;?>
        <div id="pagenaviw"><?php echo $pageurl;?></div>
        </ul>
        
    </div>
</div><!--end #blogs-->
<?php
 include View::getView('side');
?>
</div><!--end #mainbody-->
<?php
 include View::getView('footer');
?>
