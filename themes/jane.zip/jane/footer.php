<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="footer">
	<div class="footer-me">
        <a href="<?php echo BLOG_URL; ?>rss.php">RSS订阅</a>
        &nbsp;&nbsp;|&nbsp;&nbsp;
        <a href="#">友情链接</a>
        &nbsp;&nbsp;|&nbsp;&nbsp;
        <a href="<?php echo BLOG_URL; ?>baidusitemap.php">百度地图</a>
        &nbsp;&nbsp;|&nbsp;&nbsp;
        <a href="<?php echo BLOG_URL; ?>sitemap.xml">XML-Sitemap</a>
       
    </div>
	<div class="footer-bottom">
    	<p>一席之云 | 搭建于Emlog & 易梦主机 | 图片基于SAE | Theme By <a href="http://www.janecc.com"  id="janecc">JaneCC</a>| 免备案（FBI特批） |  
        <a href="http://www.miibeian.gov.cn" rel="nofollow" target="_blank"><?php echo $icp; ?></a>
        <?php echo $footer_info; ?>
        <?php doAction('index_footer'); ?>
        <?php echo $footer_info; ?> 
		<?php echo $icp; ?>
        </p>
  </div>
  
</div><!--footer结束-->

<!-- jQuery仿腾讯回顶部和建议 代码开始 -->
<div id="tbox"><a id="gotop" href="javascript:void(0)"></a></div>
<!-- 代码结束 -->
</body>
</html>
