<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?> 
<div class="blogs">
	
<!--加载日志列表循环页面与侧边栏-->
<?php
 include View::getView('list');
?>
</div>
<?php
 include View::getView('side');
?>
<!--加载日志列表循环页面与侧边栏结束-->

</div>
<?php
 include View::getView('footer');
?>