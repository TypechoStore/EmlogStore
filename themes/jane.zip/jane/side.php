<?php 
/**
 * 侧边栏页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<aside>
<ul id="sidebar">
    <li class="toppic">
      <h3><dt class="icon-toppic"></dt><span>首页置顶</span></h3>
      <ul>
		<?php index_show();?>
      </ul>
    </li>
<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>
    <!--MYBLOG-->
    <li>
    <?php if("http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] == BLOG_URL):?>
        <h3>
            <dt class="icon-myblog"></dt>
            <span>MYBLOG</span>
        </h3>
        <ul class="myblog">
            <li>日志总数量：<b><?php echo $sta_cache['lognum'];?></b> 篇</li>
            <li>评论数量：<b><span class="ds-thread-count" data-thread-key="21"></span></b> 条</li>
            <li>云 语：<b><?php echo $sta_cache['twnum'];?></b> 条</li>
            <li>小站生日：2013-11-06</li>
            <li>博客已运行：<b><?php echo floor((time()-strtotime("2013-11-06"))/86400); ?></b> 天</li>
            <?php endif;?>
        </ul>
    </li>
    <!--MYBLOG结束-->
</ul>
</aside>	  
	 







   

