<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="blogs">
    <div id="index_view">
        <h1 class="c_titile"><?php topflg($top); ?><?php echo $log_title; ?></h1>
        <p class="box">
              发布时间：<?php echo gmdate('Y-n-j G:i l', $date); ?>
              <span>作者：<?php blog_author($author); ?></span>
              阅读（<?php echo $views; ?>）
             <?php editflg($logid,$author); ?>
        </p>
        <ul>
            <p><?php echo $log_content; ?></p>
        </ul>
    
        <div class="otherlink"></div>
        <div class="tagshare">
             <p class="tag"><?php blog_tag($logid); ?></p>
            <!-- Baidu Button BEGIN -->
            <div class="bdsharebuttonbox" style=" padding-right:60px; float:right;">
            <a href="#" class="bds_more" data-cmd="more"></a>
            <a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a>
            <a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a>
            <a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a>
            <a href="#" class="bds_renren" data-cmd="renren" title="分享到人人网"></a>
            <a href="#" class="bds_tieba" data-cmd="tieba" title="分享到百度贴吧"></a>
            <a href="#" class="bds_mshare" data-cmd="mshare" title="分享到一键分享"></a>
            </div>
			<script>
			window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"1","bdSize":"16"},"share":{}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];
			</script>
            <!-- Baidu Button END -->
            
       </div>
          
        <div class="author_text">
            <strong>特别申明：</strong>若无说明,文章均为原创，转载时请注明本文地址，谢谢合作！<br />
            <strong>本文链接：</strong><a itemprop="url" title="<?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];?>" 
                href="<?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];?>"><?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];?></a>
                <?php neighbor_log($neighborLog); ?>
        </div>
    			<?php doAction('log_related', $logData); ?>
        <div  class="otherlink">   
        <h2>相关文章</h2>
        <?php $Log_Model = new Log_Model();
              $randlogs = $Log_Model->getLogsForHome("AND sortid = {$sortid} ORDER BY rand() DESC,date DESC", 1, 10);?>
            <ul>
            <?php foreach($randlogs as $value): ?>
                <li>
                <a href="<?php echo $value['log_url']; ?>" title="查看文章:<?php echo $value[		'log_title']; ?>"><?php echo $value['log_title']; ?></a>
                </li>
            <?php endforeach; ?>
            </ul>
        </div>
        <div id="tucao"   style="border-top: 1px solid #ccc; padding-top:-50px">
            <?php blog_comments($comments); ?>
            <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
        </div>
    </div>


</div>
<?php
 include View::getView('side');
?>
</div>
<?php
 include View::getView('footer');
?>
	
	
	
