﻿<?php
/*
Template Name:Janeccblog
Description:扁平响应式模版，扁平化按钮，响应式布局，先进的理念，其中用到了css3属性以及postion定位，增加页面返回到顶部的代...
Version:1.1
Author:Janecc
Author Url:http://www.janecc.com
Sidebar Amount:1
ForEmlog:5.2.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml"  xmlns:wb="http://open.weibo.com/wb">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=10;IE=EDGE">	
<meta charset="utf-8">
<!--emlog模板固定格式开始-->
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="icon" type="image/x-icon" href="<?php echo TEMPLATE_URL; ?>images/favicon.ico" id="favicon"/>
<link rel="icon" type="image/gif" href="<?php echo TEMPLATE_URL; ?>images/animated_favicon.gif" id="favicon">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<!--emlog模板固定格式结束-->
<!--微博关注js-->
<script src="<?php echo TEMPLATE_URL; ?>js/wb.js" type="text/javascript" charset="utf-8"></script>
<!--调用模板的CSS与JS开始-->
<link href="<?php echo TEMPLATE_URL; ?>styles.css" rel="stylesheet">
<link href="<?php echo TEMPLATE_URL; ?>all.css" rel="stylesheet">
<!-- 返回顶部调用 begin -->
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery-1.4.2.js"></script>
<!-- 返回顶部调用 end-->
<!--弹出登录框-->
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery-1.8.2.min.js"></script>
<!-- 返回顶部调用 弹出登录框 搜索框滑动弹出-->
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/js.js"></script>
<!--调用模板的CSS结束-->
<!--[if lt IE 9]>
<script src="<?php echo TEMPLATE_URL; ?>js/modernizr.js"></script>
<![endif]-->
<!--七牛镜像存储-->
<?php doAction('index_head'); ?>
<?php doAction('index_head',$logid); ?>
</head>
<body>
<div id="top">
	<div class="top-logo"></div>
	<div class="top-nav" >
    	<div class="sign">
        	<a id="toploginopen"><dt class="icon-sign"></dt>登&nbsp;录&nbsp;▼</a>
          <ul class="top-login" id="toplogin" style="display:none;">
             <form method="post" action="<?php echo BLOG_URL; ?>admin/index.php?action=login" name="f">
               <ul class="login">
                    <li><dt class="icon-userd"></dt><input type="text" value="" id="user" name="user"></li>
                    <li><dt class="icon-pwd"></dt><input type="password" id="pw" name="pw"></li>
                    <li><input type="submit" class="submit" value="确 定" name="submit">&nbsp; &nbsp;<input type="reset" class="submit2" id="toploginclose" name="Submit" value="取 消"><input type="hidden" value="/" name="redirect_to"></li>
               </ul>
         		</form>
          </ul>
      </div>
        <div class="qq-sign"><a href=""><dt class="icon-qq"></dt>QQ登录</a></div>
        <div class="bd-sign"><a href=""><dt class="icon-bd"></dt>百度登录</a></div>
        <div class="qq-group" >
            <a target="_blank" href="http://shang.qq.com/wpa/qunwpa?idkey=030ccc55561af58821d6335709e272cb00eaf5d61f1a873ff87e8b89bd6fac4f"><dt class="icon-group"></dt>加入Q群</a>
        </div>
        <li class="sina-attention">
        	<wb:follow-button uid="你的微博ID" type="red_2" width="136" height="24" ></wb:follow-button>
        </li>
        
    </div>
    <div class="me">
        <form name="keyform" method="get" id="searchform" class="focusblurmenu" action="<?php echo BLOG_URL; ?>index.php">
        	<input name="" type="submit" value="搜索" id="searchbtn" class="searchbtn"/>
       		<input type="text" name="keyword"  placeholder="Search" id="searchkey" class="searchkey" x-webkit-speech>
        </form>
    </div>
</div>
<div id="header">
	<div class="logo">
    	
    </div>
	<div id="nav">
		<?php blog_navi();?>
    </div>
    
    <!-- 加载动画开始：有需要的可以自行开启 -->
	<!--
    <div class="content">
        <div class="circle"></div>
        <div class="circle1"></div>
    </div>
    -->
	<!-- 加载动画结束-->
</div>
<div id="mainbody">
    <div class="notice">
		<?php if("http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] == BLOG_URL):?>
            <div class="notice-home">
                <dt class="icon-notice-home"></dt>
                <a href="<?php echo BLOG_URL; ?>t"><?php widget_twitter_random($title);?></a>
            </div>
        <?php else: ?>
            <div class="notice-nav">
                <?php if (isset($logid) || !empty($tws)) : ?>
                	<a href="<?php echo BLOG_URL; ?>"  title="返回首页" rel="tooltip" class="gohome"><dt class="icon-gohome"></dt>首页</a>
					<?php blog_sort($logid); ?><?php /*?><?php echo $log_title; ?><?php */?>
                <?php else: ?>
                	<a href="<?php echo BLOG_URL; ?>"><dt class="icon-gohome"></dt>网站首页</a>
                    <?php blog_sort($logid); ?>
				<?php endif; ?>
				
            </div>
        <?php endif;?>

    </div>
