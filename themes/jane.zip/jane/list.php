<?php 
/**
 * 日志列表循环页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<ul class="bloglist">
         <?php if (!empty($logs)):foreach($logs as $value): ?>
	  <li>
        <div class="arrow_box">
        <div class="boxhead"></div>
          <ul class="textinfo">
         
			<li class="listimg">
            <!--拉取附件第一张图片，如果没有，则随机拉取random文件夹图片，图片名称任意-->
			<?php
            preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
            $imgsrc = !empty($img[1]) ? $img[1][0] : TEMPLATE_URL.'images/random/s'.rand(1,25).'.jpg';?>
            <a class="thumbnail" href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>">
            <img src="<?php echo $imgsrc; ?>" width="100%" height="100%" alt="<?php echo $value['log_title']; ?>"  title="<?php echo $value['log_title']; ?>" rel="tooltip"/></a>
        <!--随机图片部分-->
            </li>
            <li class="listtxt">
             <h2 class="title"><a href="<?php echo $value['log_url']; ?>"  title="<?php echo $value['log_title']; ?>" rel="tooltip"><?php echo $value['log_title']; ?></a></h2>
              <ul class="details">
              	<li class="author" title="简CC" rel="tooltip"><dt class="icon-author"></dt><?php blog_author($value['author']); ?></li>
                <li class="time" title="发布于<?php echo gmdate('Y-n-j G:i l', $value['date']); ?>" rel="tooltip"><dt class="icon-time"></dt><a href="<?php echo Url::log($value['gid']); ?>"><?php echo gmdate('Y-n-j G:i l', $value['date']); ?></a></li>
                <li class="comments" title="吐槽<?php echo $value['comnum']; ?>次" rel="tooltip"><dt class="icon-comments"></dt><a href="<?php echo Url::log($value['gid']); ?>">
                <span class="ds-thread-count" data-thread-key="<?php echo $value['logid']; ?>" data-count-type="comments"></span>条吐槽</a></li>
                <li class="likes" title="点击阅读全文" rel="tooltip"><dt class="icon-likes"></dt><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['views']; ?></a></li>
                
              </ul>
              <p>
              <?php echo subString(strip_tags($value['log_description']),0,120); ?>
              </p>
            <div></div>
          </li>
        </ul>
      </div>


        <!--arrow_box 结束--> 
      </li>
	      <?php endforeach;else:?>
	<h2 style="color:#fff;; text-align:center;">未找到</h2>
	<p style="color:#999; text-align:center;">抱歉，没有符合您查询条件的结果。</p>
   <?php endif;?>
	<!--翻页-->
    <div id="pagenavi">
	<?php echo $page_url;?>
	</div>

    </ul>
    <!--bloglist 结束-->
    