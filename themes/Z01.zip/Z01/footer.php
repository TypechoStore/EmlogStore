<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!-- container END -->


<footer id="footer">

	<div id="ancillary" class="clearfix">

		<section class="1st block">
			<div class="title"></div>
			<div class="content">
				
			</div>
		</section>

		<section class="2nd block">
			<div class="title"></div>
			<div class="content">
			<ul>
				
			</ul>
			</div>
		</section>

		<section class="3rd block">
			<div class="title"></div>
			<div class="content">
			<ul>
				
			</ul>
			</div>
		</section>

	</div>

	<div id="footer-wrapper">
	<span id="typecho"><?php doAction('index_footer'); ?> &nbsp;<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?> &nbsp;</a> <?php echo $footer_info; ?></span>
		<p>Powered by <a href="http://www.emlog.net"><span style="color:#EEE;">Em</span><span style="color:#E47E00;">log</span></a> | Theme by <a href="http://braxiu.net" rel="home me">Braxiu</a> | Licensed under <a title="知识共享署名-非商业性使用-禁止修改 3.0" href="http://creativecommons.org/licenses/by-nc-nd/3.0/deed.zh" rel="license">(CC)BY-NC-ND</a></p>
	
	</div>
	
</footer><!-- footer END -->

</div> <!-- wrapper END -->
</body>
</html>
