<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<section id="content" class="reading">
		<article class="post">
			<div class="title"><span class="postdate clearfix"><?php echo gmdate('Y-n-j G:i l', $date); ?></span><?php topflg($top); ?><a href="<?php echo $log_url ?>"><?php echo $log_title; ?></a></div>
			<p class="info">
				<a href="<?php echo $log_url ?>#respond" class="CommentsNumber"><?php if($comnum==0){echo 'Leave a comment (0)';}elseif($comnum==1){echo 'Leave a comment (1)';}else{echo "Leave a comment ($comnum)";} ?></a>
				<span>作者：<?php blog_author($author); ?></span>
			</p>
			<?php echo $log_content; ?>
			<div class="tags"><span><?php blog_att($logid); ?></span></div>
			<div class="tags"><span><?php blog_sort($logid); ?></span> <?php blog_tag($logid); ?></div>
		</article>
		<div class="border"></div>

		<div class="nav-below clearfix">
			<?php neighbor_log($neighborLog); ?>
		</div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</section><!-- content END -->

<?php
 include View::getView('side');
 include View::getView('footer');
?>
