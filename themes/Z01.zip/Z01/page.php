<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<section id="content" class="page reading">
		<article class="post">
			<div class="title"><span class="postdate clearfix"><?php echo gmdate('Y-n-j G:i l', $date); ?></span><a href="<?php echo $log_url; ?>"><?php echo $log_title; ?></a></div>
			<p class="info">
				<a href="<?php echo $log_url; ?>#respond" class="CommentsNumber"><?php if($comnum==0){echo 'Leave a comment (0)';}elseif($comnum==1){echo 'Leave a comment (1)';}else{echo "Leave a comment ($comnum)";} ?></a>
				<span>作者：<?php blog_author($author); ?></span>
			</p>
			<?php echo $log_content; ?>
		</article>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
		<?php blog_comments($comments); ?>
	</section><!-- content END -->
<?php
 include View::getView('side');
 include View::getView('footer');
?>

