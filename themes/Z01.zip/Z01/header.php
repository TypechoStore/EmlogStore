<?php
/*
Template Name:Z01
Description:简洁优雅 ……
Version:1.0
Author:Syan移植braxiu
Author Url:http://syanblog.sinaapp.com
Sidebar Amount:1
ForEmlog:4.1.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="Bluefish 2.0.3" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<!--[if IE 6]><link rel="stylesheet" type="text/css" media="all" href="<?php echo TEMPLATE_URL; ?>ie6.css" /><![endif]-->

<!--[if IE]>
<script type="text/javascript">
//<![CDATA[
(function(){
if(!/*@cc_on!@*/0) return;
var e = "abbr,article,aside,audio,bb,canvas,datagrid,datalist,details,dialog,eventsource,figure,footer,hgroup,header,mark,menu,meter,nav,output,progress,section,time,video".split(','),i=0,length=e.length;
while(i<length){document.createElement(e[i++])}
})();
//]]>
</script>
<![endif]-->
</head>

<body>
<div id="wrapper">
<header id="header" class="clearfix">
	<div id="header-wrapper">
	<div id="caption">
		<div id="logo">
				<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>
		</div>
		<div id="description"><?php echo $bloginfo; ?></div>
	</div><!-- caption END -->
		<nav id="nav" class="clearfix">
		<div id="nav-wrapper">
			<ul class="clearfix">
				<li <?php echo $curpage == CURPAGE_HOME ? 'class="current"':'';?>"><a href="<?php echo BLOG_URL; ?>">首页</a></li>
				<?php if($istwitter == 'y'):?>
				<li <?php echo $curpage == CURPAGE_TW ? 'class="current"':'';?>"><a href="<?php echo BLOG_URL; ?>t/"><?php echo Option::get('twnavi');?></a></li>
				<?php endif;?>
				<?php 
				global $CACHE; 
				$navi_cache = $CACHE->readCache('navi');
				foreach ($navi_cache as $key => $val):
				if ($val['hide'] == 'y'){continue;}
				if (empty($val['url'])){$val['url'] = Url::log($key);}
				$newtab = $val['newtab'] == 'y' ? 'target="_blank"' : '';
				$val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
				?>
				<li <?php echo isset($logid) && $key == $logid ? 'class="current"':'';?>"><a href="<?php echo $val['url']; ?>" <?php echo $newtab; ?>><?php echo $val['naviname']; ?></a></li>
				<?php endforeach;?>
				<?php doAction('navbar', '<li>', '</li>'); ?>
				<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
				<li><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
				<li><a href="<?php echo BLOG_URL; ?>admin/">管理中心</a></li>
				<li><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
				<?php else: ?>
				<li><a href="<?php echo BLOG_URL; ?>admin/">登录</a></li>
				<?php endif; ?>
			</ul>
		</div><!-- menu-wrapper END -->
		</nav><!-- menu END -->


	</div><!-- header-wrapper END -->
</header><!-- header END -->



<div id="container" class="clearfix">
