<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<section id="content" class="index">
<?php doAction('index_loglist_top'); ?>
	<?php foreach($logs as $value): ?>
		<article class="post">
			<div class="title"><span class="postdate clearfix"><?php echo gmdate('Y-n-j G:i l', $value['date']); ?></span><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></div>
			<p class="info">
				<a href="<?php echo $value['log_url']; ?>#comments" class="CommentsNumber"><?php if($value['comnum']==0){echo 'No Comments';}elseif($value['comnum']==1){echo '1 Comment';}else{echo $value['comnum'].' Comments';} ?></a>
				<span>作者：<?php blog_author($value['author']); ?></span>
				<span><?php blog_sort($value['logid']); ?></span>
				<span><?php echo $value['views']; ?>人围观</span>
				<span><?php editflg($value['logid'],$value['author']); ?></span>
			</p>
			<?php echo $value['log_description']; ?>
		</article>
	<?php endforeach; ?>
	<div class="page-nav-border"><div class="page-nav clearfix">
		<?php echo $page_url;?>
	</div></div>

	</section><!-- content END -->
<?php
 include View::getView('side');
 include View::getView('footer');
?>
