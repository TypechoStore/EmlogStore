<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="m-postlst">
		<div class="m-post m-post-txt">
			<div class="ct">
				<div class="ctc box">
				<h2 class="ttl"><a href="#"><?php echo $log_title; ?></a></h2>
					<div class="txtcont"><?php echo $log_content; ?></div>
				</div>
			</div>
<div class="m-info box">
							<div class="tags">
<a href="#" class="date">起始于2010-04-28</a>
<a href="#respond" class="cmt">留言(<?php echo $comnum; ?>)</a>
<a href="http://creativecommons.org/licenses/by-nc/2.5/deed.zh" class="cc_3" target="_blank" title="署名-非商业性使用">&nbsp;</a>
							</div>
							</div>
		</div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
			</div>
        </div>
<?php
 include View::getView('footer');
?>