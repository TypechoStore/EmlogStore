<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="m-postlst">
<?php doAction('index_loglist_top'); ?>
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
		<div class="m-post m-post-txt">
			<div class="ct">
				<div class="ctc box">
				<h2 class="ttl"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
					<div class="txtcont"><?php echo $value['log_description']; ?></div>
				</div>
			</div>
					<div class="m-info box">
							<div class="tags">
<a href="<?php echo $value['log_url']; ?>" class="date"><?php echo gmdate('Y/n/j l', $value['date']); ?></a>
<a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a>
							</div>

					</div>
		</div>
<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>

</div>
<div id="pagenavi">
	<?php echo $page_url;?>
</div>
<?php if("http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] == BLOG_URL): ?><!-- 判断仅在首页显示link -->
			<div class="flink">
        <div class="data">  
	<div class="linktitle">友情链接 | BLOGROLL</div>
	<ul>
<?php {global $CACHE; $link_cache = $CACHE->readCache('link');foreach($link_cache as $value):?><li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li><?php endforeach; ?><?php }?>
    </ul>
        </div>
            </div>
<?php endif; ?>
			</div>
        </div>
<?php
 include View::getView('footer');
?>