<?php
/*
Template Name:lofter0829
Description:lofter0829
Version:0.1
Author:loekman
Author Url:http://loek.us
Sidebar Amount:0
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>css.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div class="g-doc">
<!--logo-->
		<div class="g-hd">
			<h1 class="m-title">
				<!-- 如要使用logo图片，请注释掉下面这段代码[by loekman] -->
<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>
				<!-- 使用logo图片时，去掉下面代码的注释[by loekman] -->
				<!-- <a href="<?php echo BLOG_URL; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/logo.gif" /></a> -->
			</h1>
        </div>
<!--/logo-->
        <div class="g-bd">
			<div class="g-bdc">
<!--nav-->
					<div class="m-nav-static">
						<div class="m-nav">
							<ul class="box">
								<li class="m-intro">
									<a class="level0" href="#"><span></span></a>
									<div class="m-about f-dn">
										<span class="icn"></span>
										<div class="cont box">
<?php
//widget：blogger
	global $CACHE;
	$user_cache = $CACHE->readCache('user');?>
	<?php if (!empty($user_cache[1]['photo']['src'])): ?>
	<img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="82" height="82" alt="blogger" />
	<?php endif;?>
											<p><?php echo $user_cache[1]['des']; ?></p>
										</div>
									</div>
								</li>
								<li class="m-sch">
									<a class="level0" href="#" class="lnk" id="j-schlnk"><span></span></a>
									<form method="get" action="<?php echo BLOG_URL; ?>index.php" class="form f-dn" id="j-schform"><input type="text" value="输入搜索的内容+回车" onclick="if(this.value=='输入搜索的内容+回车') this.value='';return false;"  onblur="if(this.value=='') this.value='输入搜索的内容+回车';return false;" name="keyword" class="txt" id="j-schtxt" /></form>
								</li>
								
								<li class="m-nav0">
<div><?php blog_navi();?></div>
								</li>
							</ul>
						</div>
					</div>
					<div class="m-nav-fixed">
						<div class="m-nav">
							<ul class="box">
								<li class="m-intro">
									<a class="level0" href="#"><span></span></a>
									<div class="m-about f-dn">
										<span class="icn"></span>
										<div class="cont box">
<?php
//widget：blogger
	global $CACHE;
	$user_cache = $CACHE->readCache('user');?>
	<?php if (!empty($user_cache[1]['photo']['src'])): ?>
	<img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="82" height="82" alt="blogger" />
	<?php endif;?>
											<p><?php echo $user_cache[1]['des']; ?></p>
										</div>
									</div>
								</li>
								<li class="m-sch">
									<a class="level0" href="#" class="lnk" id="j-schlnk"><span></span></a>
									<form method="get" action="<?php echo BLOG_URL; ?>index.php" class="form f-dn" id="j-schform"><input type="text" value="输入搜索的内容+回车" onclick="if(this.value=='输入搜索的内容+回车') this.value='';return false;"  onblur="if(this.value=='') this.value='输入搜索的内容+回车';return false;" name="keyword" class="txt" id="j-schtxt" /></form>
								</li>
								
								<li class="m-nav0">
<div><?php blog_navi();?></div>
								</li>
							</ul>
						</div>
					</div>
<!--/nav-->