<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
		<div class="g-ft">
			<p class="m-cprt">&copy;&nbsp;<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>&nbsp;|&nbsp;Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> <?php echo $footer_info; ?></p>
		</div>
</div>
<?php doAction('index_footer'); ?>
<!-- 加载jquery文件，如遇插件冲突请将其注释[by loekman]-->
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>jquery-1.6.2.min.js" ></script>
<!-- jquery js end -->
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js.js" ></script>
</body>
</html>