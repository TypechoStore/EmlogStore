<?php
/*
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
	'slideid' => array(
		'type' => 'text',
		'name' => '首页轮播文章id',
		'default' => '1,2',
		'description' => '文章id必须用,间隔',
	),
'qqtz' => array(
		'type' => 'radio',
		'name' => '防红跳转开关',
		'values' => array(
			'1' => '开',
			'2' => '关'
		),
		'default' => '1',
	),
	'gonggao' => array(
		'type' => 'text',
		'name' => '首页流动公告',
		'multi' => true,
		'default' => '汉松资源吧络工作室运营的一家个人博客,专门技术资源分享.秒单中.网站问题请咨询站长QQ321976193',
	),
'gg0' => array(
		'type' => 'text',
		'name' => '首页导航分类下图片广告',
		'multi' => true,
		'default' => '<div><a href="http://www.qqjcane.cn" target="_blank"><img alt="大盗资源网" src="content/templates/yuleba/lib/img/ad1.gif" style="height: 80px; width: 100%;" /></a></div>',
	),
	'slide' => array(
		'type' => 'text',
		'name' => '轮播自定义广告',
		'multi' => true,
		'default' => '<div class="layui-this"><a href="http://www.qqjcane.cn"><img class="flash" src="content/templates/ziyuanba/lib/img/zyb.jpg"></a></div>',
	),
	'ruanjian' => array(
		'type' => 'text',
		'name' => '首页软件推荐栏目',
		'multi' => true,
		'default' => '
<a class="mk-embed-card" href="http://www.qqjcane.cn" title="Emlog资源模板介绍"> <span class="mk-embed-content"> <span class="mk-embed-title">Emlog资源模板介绍</span> <span class="mk-embed-meta"> 2020年10月25日</span> <img class="mk-embed-image no-shadow" src="content/templates/hui/lib/img/logo.png" alt="Emlog资源模板介绍" /> </span> </a>
',
	),
		'text' => array(
		'type' => 'text',
		'name' => '首页文字广告',
		'multi' => true,
		'default' => '<li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#C71585;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#C71585;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#C71585;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#C71585;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#C71585;"> 文字广告位置 </span> </a> </li> ',
		'description' => '第一列',
	),
		'text1' => array(
		'type' => 'text',
		'name' => '首页文字广告',
		'multi' => true,
		'default' => '<li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#FF0033;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#FF0033;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#FF0033;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#FF0033;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#FF0033;"> 文字广告位置 </span> </a> </li> ',
		'description' => '第二列',
	),
		'text2' => array(
		'type' => 'text',
		'name' => '首页文字广告',
		'multi' => true,
		'default' => '<li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#9F79EE;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#9F79EE;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#9F79EE;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#9F79EE;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#9F79EE;"> 文字广告位置 </span> </a> </li> ',
		'description' => '第三列',
	),
		'text3' => array(
		'type' => 'text',
		'name' => '首页文字广告',
		'multi' => true,
		'default' => '<li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#228B22;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#228B22;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#228B22;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#228B22;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#228B22;"> 文字广告位置 </span> </a> </li> ',
		'description' => '第四列',
	),
		'text4' => array(
		'type' => 'text',
		'name' => '首页文字广告',
		'multi' => true,
		'default' => '<li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#0a11d6;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#0a11d6;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#0a11d6;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#0a11d6;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#0a11d6;"> 文字广告位置 </span> </a> </li> ',
		'description' => '第五列',
	),
	'toplink' => array(
		'type' => 'text',
		'name' => '首页顶部菜单',
		'multi' => true,
		'default' => '<span><a href="http://www.qqjcane.cn" target="_blank">大盗资源网</a></span><span><a href="http://www.678zyw.cn" target="_blank">汉松资源吧</a></span>',
	),
	'index-down' => array(
		'type' => 'text',
		'name' => '下载专区分类ID',
		'default' => '1,2',
		'description' => '用英文逗号隔开可同时指定多个分类',
	),
	'index-article' => array(
		'type' => 'text',
		'name' => '文章专区分类ID',
		'default' => '3',
		'description' => '用英文逗号隔开可同时指定多个分类',
	),
	'index-articler' => array(
		'type' => 'text',
		'name' => '首页热门排行右侧块分类ID',
		'default' => '4',
		'description' => '只填写一个ID，填多了报错',
	),
	'gg3' => array(
		'type' => 'text',
		'name' => '首页最近更新下方淘宝优惠券链接',
		'multi' => true,
		'default' => '',
		'description' => '留空则不显示',
	),
	'gg4' => array(
		'type' => 'text',
		'name' => '首页最近更新下方天猫优惠券链接',
		'multi' => true,
		'default' => '',
	),
	'gg5' => array(
		'type' => 'text',
		'name' => '首页最近更新下方拼多多优惠券链接',
		'multi' => true,
		'default' => '',
	),
		'tags' => array(
		'type' => 'text',
		'name' => '关键词优化',
		'default' => '资源网,小刀资源网,汉松技术,大盗资源网,汉松资源吧,技术网',
		'description' => '用英文逗号隔开可',
	),
		'logo' => array(
		'type' => 'image',
		'name' => '上传LOGO图片',
		'values' => array(
			TEMPLATE_URL . 'lib/img/logo.png',
		),
		'description' => '默认尺寸为120X50像素透明PNG图片',
	),
	'logo1' => array(
		'type' => 'image',
		'name' => '上传LOGO图片',
		'values' => array(
			TEMPLATE_URL . 'lib/img/logo1.png',
		),
		'description' => '默认尺寸为120X50像素透明PNG图片',
	),
		'qmimg' => array(
		'type' => 'image',
		'name' => '上传二维码图片',
		'values' => array(
			TEMPLATE_URL . 'lib/img/ewm.png',
		),
		'description' => '默认尺寸为120X50像素PNG图片',
	),
	'foot-url' => array(
		'type' => 'text',
		'name' => '页脚相关链接',
		'multi' => true,
		'default' => '<li><a href="http://www.qqjcane.cn" target="_blank" rel="nofollow">关于我们</a></li>
			<li><a href="http://www.qqjcane.cn" target="_blank" rel="nofollow">广告合作</a></li>
			<li><a href="http://www.qqjcane.cn" target="_blank" rel="nofollow">我要投稿</a></li>
          	<li><li style="float: right;line-height: 32px;margin-right: 0px;display: flex;width: 100px;">基于<a target="_blank" rel="nofollow" href="http://www.emlog.net/" id="emlog">Emlog</a>系统<script></li>',
	),
		'foot-tg' => array(
		'type' => 'text',
		'name' => '站长统计',
		'multi' => true,
		'default' => '',
	),
	'foot-copy' => array(
		'type' => 'text',
		'name' => '页脚文字说明',
		'multi' => true,
		'default' => '本站内容来源于互联网，如果有侵权内容、不妥之处，请第一时间联系我们删除。敬请谅解! E-mail：',
	),
	'email' => array(
		'type' => 'text',
		'name' => '投稿反馈邮箱',
		'default' => '321976193@qq.com',
		'description' => '填写邮箱即可',
	),
'xiaotugg' => array(
		'type' => 'text',
		'name' => '最新文章下小图广告',
		'multi' => true,
		'default' => '<ul>
<li>
<a href="https://www.ixxz.cn/go.php?url=http://www.qqjcane.cn/" title="2-7" target="_blank"><img src="https://ae01.alicdn.com/kf/U9cc5cc37b8284dee8cda93a27b80a2283.jpg" /></a> </li>
</ul> 

<ul>
<li>
<a href="https://www.ixxz.cn/go.php?url=http://www.qqjcane.cn
" title="广告招租" target="_blank"><img src="https://ae01.alicdn.com/kf/U16f11c5dbde642539f2c39e762b31bc4c.jpg" /></a> </li>
</ul> 

<ul>
<li>
<a href="https://weidian.com/?userid=321976193&spider_token=a312&wfr=c" title="广告招租" target="_blank"><img src="https://ae01.alicdn.com/kf/U3ee5929f63f04c09829ea38f0afaf3adE.jpg" /></a> </li>
</ul> 



<ul>
<li>
<a href="https://www.ixxz.cn/go.php?url=http://www.qqjcane.cn" title="广告招租" target="_blank"><img src="https://ae01.alicdn.com/kf/U50fbf49c990c4d0ab0ca4df442f1e8437.jpg" /></a> </li>
</ul> 

<ul>
<li>
<a href="http://www.qqjcane.cn" title="广告招租" target="_blank"><img src="https://ae01.alicdn.com/kf/Ua758eb0dbc5048f395e9c959f0eeb841x.jpg" /></a> </li>
</ul> 

<ul>
<li>
<a href="https://wpa.qq.com/msgrd?v=3&uin=321976193&site=qq&menu=yes" title="广告招租" target="_blank"><img src="https://ae01.alicdn.com/kf/U0fd41c72a21b44219493c8183deb0f91C.jpg" /></a> </li>
</ul> ',
	),
);