<?php
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
/*
template Name: 娱乐吧
Version: V2.1
Plugin URL: http://www.qqjcane.cn
Description: 更美观、更有利于SEO收录，有问题联系小傅哥QQ321976193，收录至Emlog6.1.1时已将MySql改为Database和split改为preg_split支持了php7.4。
Author: 汉松技术网
Author URL: http://www.qqjcane.cn/
*/
//手机QQ打开跳转到浏览器
if(_g('qqtz')== 1 ){
$scriptpath = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
$sitepath = substr($scriptpath, 0, strrpos($scriptpath, '/'));
$siteurl = ($_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $sitepath . '/';
if (strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== !1 ) {
	echo '<!DOCTYPE html>
	<html>
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>请使用浏览器打开</title>
	<script src="https://open.mobile.qq.com/sdk/qqapi.js?_bid=152"></script>
	<script type="text/javascript"> mqq.ui.openUrl({ target: 2,url: "' . $siteurl . '"}); </script>
	</head>
	<body><img src="/content/templates/yuleba/lib/images/web.png" style="height: 600px; width: 100%;" alt="请使用浏览器打开">
</body>
	</html>';
 exit;
}}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title><?php echo $site_title;?></title>
<meta name="keywords" content="<?php echo $site_key; ?>">
<meta name="description" content="<?php echo $site_description; ?>"/>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/>
<meta name="renderer" content="webkit"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<script src="//apps.bdimg.com/libs/jquery/1.10.2/jquery.min.js"></script>
<?php if($pageurl == Url::logPage()){?>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>lib/css/index.css" type="text/css" media="all"/>
<?php }elseif($logid){?>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>lib/css/article.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL;?>lib/fancybox/jquery.fancybox.min.css" />
<script src="<?php echo TEMPLATE_URL;?>lib/fancybox/jquery.fancybox.min.js"></script>
<?php }else{?>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>lib/css/list.css" type="text/css" media="all"/>	
<?php }?>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>lib/css/layui.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>lib/css/commons.css" type="text/css" media="all"/>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>lib/css/layer.css" type="text/css" media="all"/>
<?php doAction('index_head'); ?>
<?php doAction('baidu_xz_echo',$logid, $log_title, $log_content, $date); ?>
</head>
<body class="indexx">
<header>
	<div class="header-top">
		<div class="header-important container">
			<div class="tj <?php if($pageurl == Url::logPage()){?>left<?php }else{?>rl<?php }?>">
				<span><?php echo $bloginfo;?></span>
			</div>
			<div class="tg <?php if($pageurl == Url::logPage()){?>left<?php }else{?>fr<?php }?>">
				<?php echo _g('toplink');?>

			</div>
		</div>
	</div>
<div class="header-important">
	<div class="container layui-clear">
		<a href="/" class="logo">
		<img src="<?php echo _g('logo');?>" alt="<?php echo _g('tags');?>">
		</a>
		<img src="<?php echo TEMPLATE_URL;?>lib/img/yxcz.png" class="logo-right-decation">
		<form method="get" class="search" action="<?php echo BLOG_URL;?>index.php">
				<input type="text" class="focus" size="24" name="keyword" placeholder="快来搜一搜吧！">
				<input type="submit" class="iconfont" value="">
			</form>
	</div>
</div>
<div class="header-nav">
		<div class="header-nav-main container">
<?php blog_navi();?>
		</div>
</div>

<?php
 if(blog_tool_ishome()){}elseif($sortName){}elseif($logid){
$page=isset($params[5])?intval($params[5]):1;//文章页代码
$ymurl=$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];//浏览器获取URL
//$emurl=preg_replace('/(http://|https://|)*/','',Url::log($logid));//去除http://或https://的默认url
$emurl=str_replace(array("http://","https://"),'',Url::log($logid));//去除http://或https://的默认url
if($emurl!=$ymurl && $page==1){//判断2者是否相同，是否第一页
header('HTTP/1.1 301 Moved Permanently');
header('Location:'.Url::log($logid));//不同时调整到默认URL 
}}elseif($keyword){
}elseif($record){}elseif($tag){}elseif($author){}else{}
?>
</header>
