<?php
/**
 * 站点首页模板
* 二次开发联系作者QQ：321976193
 */
if (!defined('EMLOG_ROOT')) {exit('error!');}
if (isset($_GET["Down"])) {
    include View::getView('list_down');
    exit;
}
if (isset($_GET["Article"])) {
    include View::getView('list_article');
    exit;
}
if($pageurl == Url::logPage()){include View::getView('index');exit;}
// 判断下载分类ID是否存在，存在则跳转下载页
$down = explode(',',_g("index-down"));if(in_array($sortid,$down) !== false){include View::getView('log_down');exit();}
?>
<div class="index-container layui-clear">
	<div class="list-container fl">
		<div class="current_nav">当前位置：<a href='<?php echo BLOG_URL;?>'>首页</a> > <?php if($params[1]=='sort'){?><?php echo '<a href="'.Url::sort($sortid).'">'.$sortName.'</a>';?><?php }elseif ($params[1]=='tag'){?>包含标签 <?php echo htmlspecialchars(urldecode($params[2]));?> 的所有文章<?php }elseif($params[1]=='author'){?>作者 <?php echo blog_author($author);?> 的所有文章<?php }elseif($params[1]=='keyword'){?>搜索 <?php echo htmlspecialchars(urldecode($params[2]));?> 的结果<?php }elseif($params[1]=='record'){?>正在查看 “<?php echo $params[2];?>” 年月的文章<?php }?></div>
		<div>
		<ul class="list-ul">
<?php
if (!empty($logs)):
foreach($logs as $key=>$value): 
	$search_pattern = '%<img[^>]*?src=[\'\"]((?:(?!\/admin\/|>).)+?)[\'\"][^>]*?>%s';
	preg_match($search_pattern, $value['content'], $img);
	$value['img'] = isset($img[1])?$img[1]:TEMPLATE_URL.'lib/img/default.jpg';
?>
			<li class="layui-clear">
				<div class="list-info">
					<div class="info-img fl">
						<a href="<?php echo $value['log_url'];?>" target="_blank">
							<img src="<?php echo $value['img'];?>" alt="<?php echo $value['log_title'];?>"/>
						</a>
					</div>
					<div class="info-tit fr">
						<a class="soft-title" href="<?php echo $value['log_url'];?>" target="_blank"><i class="rj"><?php echo blog_sort($value['logid']);?></i><?php echo $value['log_title'];?></a>
						<div class="list-intro"><?php if(!empty($value['log_description'])){echo subString(strip_tags($value['log_description']),0,50,"...");}else{echo "此作者很懒，没有为文章撰写内容呦！";}?></div>
						<div class="list-ca">发布时间：<?php echo date('Y-m-d',$value['date']);?></div>
						<div class="list-btn layui-clear">
							<a href="<?php echo $value['log_url'];?>" target="_blank">立即查看</a>
						</div>
					</div>
				</div>
			</li>
<?php endforeach;?>
<?php else:?>
			<i class="wnr_ico"></i><span class="wnr_t">暂时没有找到您想要的内容！</span> <a href="/" class="wnr_home">回到首页</a>
<?php endif;?>
		</ul>
		<div id="page">
			<div class="layui-box layui-laypage layui-laypage-default">
				<?php echo blog_fy($lognum,$index_lognum,$page,$pageurl);?>
			</div>
		</div>
	</div>
</div>
<div class="right">
<?php if($sort):?>
	<div class="list-right nav">
		<div class="title">栏目分类</div>
		<ul>
<?php blog_listsort($sortid);?>
		</ul>
	</div>
	<?php endif;?>
	<div class="list-right">
		<div class="title">本周热门</div>
		<ul class="list">
<?php blog_listlog7();?>
		</ul>
	</div>
	<div class="list-right">
		<div class="title">随机推荐</div>
		<ul class="list">
<?php blog_randomlog();?>
		</ul>
	</div>
</div>
</div>
<?php include View::getView('footer');?>