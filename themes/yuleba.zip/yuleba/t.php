<?php 
/**
 * 微语
 *模板二次开发321976193
 */
header('HTTP/1.1 404 Not Found');
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>