<?php if(!defined('EMLOG_ROOT')) {exit('error!');}//首先你要有读写文件的权限
 
//本程序可以直接运行,第一次报错,无视
 
$error_url = 'https://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
 
$error_log = "silian.txt";
 
$entries = file($error_log);
 
$check=true;
 
foreach($entries as $f){
 
    if($f == $error_url."\n")
 
        $check = false;
 
}
 
if($check){
 
    $fp = fopen($error_log,"a");
 
    flock   ($fp, LOCK_EX) ;
 
    fwrite  ($fp, $error_url."\n");
 
    flock   ($fp, LOCK_UN);
 
    fclose  ($fp);
 
}?>
<!doctype html><html><head><meta charset="utf-8"><meta name="renderer" content="webkit"><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><meta http-equiv="Cache-Control" content="no-transform " /><meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,minimum-scale=1.0,user-scalable=no"><title>404提醒！这里暂时什么都没有噢！</title><style>*{padding:0;margin:0;box-sizing:border-box;font-family:"微软雅黑";}body,html{width:100%;height:100%;}.container{max-width:90%;margin:0 auto;padding:80px 0px;}img{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;}.bg{display:block;max-width:100%;margin:0px auto;margin:40px auto;}.btn{width:500px;margin:0 auto;max-width:100%;margin-top:40px;}.btn a{float:left;text-decoration:none;width:40%;border:1px solid #5298ff;background:#5298ff;color:#FFF;display:block;height:46px; line-height:44px;text-align:center;font-size:16px;border-radius:3px;overflow:hidden;margin-left:65px;margin-right:20px}#home{margin-left:0;margin-right:0;}@media screen and (max-width: 500px){.btn{width:85%;}.btn a{width:100%;font-size:15px; height:42px;line-height:42px;margin:0 0 10px 0;}</style><script>var domain = window.location.host;function go_baidu(){window.open("https://www.baidu.com/s?ie=utf-8&wd=site:"+domain);}function go_home(){location.href = "//"+domain;}</script></head><body><div class="container"><img class="bg" src="<?php echo TEMPLATE_URL;?>404.png" /><audio src="http://tts.baidu.com/text2audio?idx=1&tex=%E6%8A%B1%E6%AD%89%E9%81%87%E5%88%B0%E9%94%99%E8%AF%AF%E5%95%A6%E6%82%A8%E6%89%BE%E7%9A%84%E9%A1%B5%E9%9D%A2%E4%B8%8D%E5%AD%98%E5%9C%A8%E6%88%96%E8%80%85%E5%B7%B2%E7%BB%8F%E5%88%A0%E9%99%A4&cuid=baidu_speech_demo&cod=2&lan=zh&ctp=1&pdt=1&spd=4&vol=5&pit=5&per=4" autoplay></audio><div class="btn"><a href="javascript:void(0);" onClick="go_baidu();" id="links">百度一下</a><a href="javascript:void(0);" onClick="go_home();" id="home">返回首页</a><div style="clear:both;"></div></div>	</div></body></html>