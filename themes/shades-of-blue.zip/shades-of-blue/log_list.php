<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div id="content">
	<div id="contentleft">
		<div class="postarea">
			<?php doAction('index_loglist_top'); ?>
			<?php foreach($logs as $value): ?>
			<div class="post">
            <h1><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h1>
                <div class="postauthor">
            		<p>Posted by <?php blog_author($value['author']); ?> on <?php echo gmdate('F j, Y', $value['date']); ?> &middot; 
    				<a href="<?php echo $value['log_url']; ?>#comment">评论(<?php echo $value['comnum']; ?>)</a>
					<a href="<?php echo $value['log_url']; ?>#tb">引用(<?php echo $value['tbcount']; ?>)</a> 
					<a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a>&nbsp;
					<?php editflg($value['logid'],$value['author']); ?></p>
                </div>
            <?php echo $value['log_description']; ?>
            <?php blog_att($value['logid']); ?>
            <div style="clear:both;"></div>
			<?php blog_sort_and_tag($value['logid']); ?>
            </div>
			<?php endforeach; ?>
            <div id="pagenavi"><?php echo $page_url;?></div>
        </div>
	</div>
	<?php include View::getView('sidebar');?>
</div>
<!-- The main column ends  -->
<?php include View::getView('footer');?>