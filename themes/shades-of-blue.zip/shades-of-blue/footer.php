<!-- begin footer -->
<div style="clear:both;"></div>
</div>
<div id="copyright">
    <div class="copyright">
		<p>Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?></p>
    </div>
</div>                                
<?php doAction('index_footer'); ?>
</body>
</html>