<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div id="content">
	<div id="contentleft">
		<div class="postarea">
			<h1><?php topflg($top); ?><?php echo $log_title; ?></h1>
                <div class="postauthor">
            		<p>Posted by <?php blog_author($author); ?> on <?php echo gmdate('l, F j, Y', $date); ?>&nbsp;<?php editflg($logid,$author); ?></p>
                </div>
			<?php echo $log_content; ?>
			<?php blog_att($logid); ?>
			<?php doAction('log_related', $logData); ?>
			<div style="clear:both;"></div>
			<?php blog_sort_and_tag($logid); ?>
		</div>
		<p align="center"><?php neighbor_log($neighborLog); ?></p>
        <div class="postcomments">
			<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
			<?php blog_comments($comments); ?>
			<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);?>
        </div>
	</div>
	<?php include View::getView('sidebar');?>
</div>
<!-- The main column ends  -->
<?php include View::getView('footer');?>