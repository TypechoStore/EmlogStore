<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
    <div id="main">
        <div id="content">
            <div class="story" id="post">
                <h2><?php echo $log_title; ?></h2>
                <div class="entry">
                    <?php echo $log_content; ?>
					<p class="att"><?php blog_att($logid); ?></p>
                    <br class="clear" />
                    <p class="postmetadata">
                        <?php editflg($logid,$author); ?>
                    </p>
                </div>
            </div>
            <div class="comments-template"> 
			<ol class="commentlist">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
            </ol>
			</div> 
        </div>
    <div id="sidebar">
<?php
 include View::getView('side');
 include View::getView('side2');
 include View::getView('side3');
?>
    </div>
    </div>
<?php
 include View::getView('footer');
?>