<?php
/*
Template Name:Waterfall
Description:移植自wp同名模板
Version:1.0
Author:capricornusoel
Author Url:http://jingzipanda.com
Sidebar Amount:1
ForEmlog:4.1.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/lib/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/lib/jquery.plugins.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/javascript.js"></script>
<!--[if lt IE 7]>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/ie6.js"></script>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>/ie6.css" type="text/css" media="screen" />
<![endif]-->
</head>
<body style="height:100%; width:100%; position:relative;">
<div id="loading" style="position:fixed !important;position:absolute;top:0;left:0;height:100%; width:100%; z-index:199999; background:#000 url(<?php echo TEMPLATE_URL; ?>/img/load.gif) no-repeat center center; opacity:0.6; filter:alpha(opacity=60);font-size:14px;line-height:20px;" onclick="javascript:turnoff('loading')"><p id="loading-one" style="color:#fff;position:absolute; top:50%; left:50%; margin:20px 0 0 -50px; padding:3px 10px; text-shadow:none;" onclick="javascript:turnoff('loading')">页面载入中..</p></div>
<script type="text/javascript">
//<![CDATA[
  function turnoff(obj){
    document.getElementById(obj).style.display="none";
  }
//]]>
</script>
<div id="scroll"><a href="#" title="回到页首" class="back-to-top">回到页首</a><a href="#sidebar" title="回到页尾" class="back-to-bottom">回到页尾</a></div>
<div id="nav">
  <div class="inner">
    <ul>
    <li class="<?php echo $curpage == CURPAGE_HOME ? 'current_page_item' : 'page_item';?>"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></li>
	<?php if($istwitter == 'y'):?>
	<li class="<?php echo $curpage == CURPAGE_TW ? 'current_page_item' : 'page_item';?>"><a href="<?php echo BLOG_URL; ?>t/">微语</a></li>
	<?php endif;?>
	<?php 
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach ($navi_cache as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	$newtab = $val['newtab'] == 'y' ? 'target="_blank"' : '';
    $val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
	?>
	<li class="<?php echo isset($logid) && $key == $logid ? 'current_page_item' : 'page_item';?>"><a href="<?php echo $val['url']; ?>" <?php echo $newtab; ?>><?php echo $val['naviname']; ?></a></li>
	<?php endforeach;?>
	<?php doAction('navbar', '<li class="page_item">', '</li>'); ?>   
	<li class="page_item li_ul"><a href="http://jingzipanda.com">别院</a>
	<ul class="children" style="display: none; ">
	<li class="page_item"><a href="http://kisu.me">Typecho</a></li>
	<li class="page_item"><a href="http://sijiabiji.net">私家筆記</a></li>
	</ul>
	</li>	
    </ul>
    <div id="nav_buttons">
        <a id="nav_rss" href="<?php echo BLOG_URL; ?>rss.php" title="订阅本站">RSS</a>
        <a id="nav_email" href="mailto:jingzipanda@gmail.com" title="Email">Email</a>
        <a id="nav_weibo" href="http://weibo.com/yaohiz" title="新浪微博">新浪微博</a>
        <a id="nav_t" href="http://t.qq.com/" title="腾讯微博">腾讯微博</a>
        <a id="nav_twitter" href="http://twitter.com/over_shy" title="Twitter">Twitter</a>
        <a id="nav_facebook" href="http://facebook.com/" title="Facebook">Facebook</a>
        <a id="nav_comment" href="<?php echo BLOG_URL; ?>/guestbook.html" name="go-gbook" title="我有话想说，直接带我去吧～">评论</a>
    </div>
  </div>
</div>
<div id="wrap">
<!--[if IE 6]>
<div id="anti_ie6" <?php if($_COOKIE['closeAnti']==true){echo 'class="hidden"';}?>><p>尊敬的用户，您正在使用<a href="http://interjc.net/a/anti-ie6">老掉牙的IE 6.0</a>，我们强烈推荐您升级为<a target="_blank"  href="http://docs.google.com/View?id=dg5phkpq_78cd6t5gf8">符合Web标准的浏览器</a>，更快，更好，更安全！<a href="http://www.microsoft.com/china/windows/internet-explorer/">IE8下载</a><strong>    <a href="#" style="color:red;">X</a></strong></p></div>
<![endif]-->