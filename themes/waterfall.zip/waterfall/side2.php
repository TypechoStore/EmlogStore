<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="sidebar-2" class="sidebar">
    <ul>
        <li id="brians-latest-comments" class="widget">
            <h2>评论</h2>
			<ul class="blclastcommentedposts">
            <?php widget_newcomm(''); ?>
			</ul>
        </li>
        <li id="recent-posts-2" class="widget">
            <h2>手气</h2>
			<ul>
            <?php widget_random_log(''); ?>
			</ul>
        </li>
    </ul>
</div>
