<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="main">
    <div id="content">
        <?php doAction('index_loglist_top'); ?>
        <?php foreach($logs as $value): ?>
        <div class="story" id="post">
            <h2><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
            <div class="meta">
                <p>
                    <?php blog_author($value['author']); ?>
                    [
                    <?php blog_sort($value['logid']); ?>
                    ]</p>
                <p>
                    <?php echo gmdate('Y.m.d', $value['date']); ?>
                </p>
            </div>
            <div class="entry">
                <div class="inner"><?php echo $value['log_description']; ?><div style="clear:both;"></div></div>
                <br class="clear" />
                <p class="postmetadata">
                    Tags: <?php blog_tag($value['logid']); ?>
                    | 
                    <a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?>评论 &#187;</a>
                </p>
            </div>
        </div>
        <?php endforeach; ?>
        <div class="navigation">
            <div class="pagebar"><?php echo $page_url;?></div>
        </div>
    </div>
    <div id="sidebar">
<?php
 include View::getView('side');
 include View::getView('side2');
 include View::getView('side3');
?>
    </div>
</div>
<?php
 include View::getView('footer');
?>
