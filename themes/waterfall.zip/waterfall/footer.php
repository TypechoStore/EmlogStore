<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
    <br class="clear" />
    <div id="footer">
        <p>&copy;<a target="_blank" href="http://creativecommons.org/licenses/by-nc-nd/3.0/deed.zh">Copyright</a><a href="<?php echo BLOG_URL; ?>" title="Home"><?php echo $blogname; ?></a>/<a href="http://interjc.net/dev/waterfall">WaterFall</a> . <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> . <?php echo $bloginfo; ?> . <script src="http://s19.cnzz.com/stat.php?id=3522029&web_id=3522029" language="JavaScript"></script> . <a class="back-to-top" href="#">Top ↑</a>
        </p>
        <?php doAction('index_footer'); ?>
<?php if($curpage == CURPAGE_LOG): ?>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/comments-ajax.js"></script>
<?php endif; ?>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-218305-2");
pageTracker._trackPageview();
} catch(err) {}</script>
    </div>
  </div>
</body></html>