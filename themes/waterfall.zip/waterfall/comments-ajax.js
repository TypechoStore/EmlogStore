  // Ajax评论
$(function(){
		   $("#commentform").submit(function(){
			var q = $("#commentform").serialize();
		$("#comment").attr("disabled","disabled");
		$("#loading").show();
		$.post($("#commentform").attr("action"),q,function(d){
			var reg = /<div class=\"main\">[\r\n]*<p>(.*?)<\/p>/i;
			if(reg.test(d)){
				$("#error").html(d.match(reg)[1]);
				$("#loading").hide();
			}else{
				var p = $("input[name=pid]").val();
				cancelReply();
				$("[name=comment]").val("");
				$("#comment_list").html($(d).find("#comment_list").html());
				$("#recentcomment").html($(d).find("#recentcomment").html());
				if(p != 0) {
					var body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body');
					body.animate({scrollTop: $("#comment-" + p).offset().top - 20},	"normal",function() {$("#loading").hide();});
				} else {
					var body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body');
					body.animate({scrollTop: $("#comment_list").offset().top - 20},	"normal",function() {$("#loading").hide();});
				}
			}
			$("#comment").attr("disabled",false);
		});
		return false;	})   
		    $(document).keypress(function(e){
      if(e.ctrlKey && e.which == 13 || e.which == 10) {
      $("#commentform").submit();
      } else if (e.shiftKey && e.which==13 || e.which == 10) {
      $("#commentform").submit();//#commentform是发表评论表单form的ID
       }
      })
	
		   });