<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="sidebar-3" class="sidebar">
    <ul>
        <li id="better-blogroll" class="widget">
            <h2>友链</h2>
            <ul>
                <?php widget_link(''); ?>
            </ul>
        </li>
    </ul>
</div>
