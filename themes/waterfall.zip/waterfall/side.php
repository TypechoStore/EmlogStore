<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="sidebar-1" class="sidebar">
    <ul>
        <li id="search" class="widget">
<form method="get" id="searchform" action="<?php echo BLOG_URL; ?>/">
<div>
	<input type="text" value="" name="q" id="s" size="15" />
	<input type="submit" id="searchsubmit" value="搜索" />
	<input type="reset" id="searchreset" value="重置" />
</div>
</form>
        </li>
        <li class="widget">
            <h2>标签</h2>
							    <?php
	                            global $CACHE;
	                            $tag_cache = $CACHE->readCache('tags');
                                ?>
				<ul>
	                            <?php shuffle($tag_cache);$tag_cache = array_slice($tag_cache,0,30);foreach($tag_cache as $value): ?>
		                        <span style="font-size:<?php echo $value['fontsize']; ?>pt; line-height:30px;">
		                        <a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇日志" style="text-decoration:none;"><?php echo $value['tagname']; ?></a></span>
	                            <?php endforeach; ?>
				</ul>
        </li>
    </ul>
</div>
