<?php
/*
Template Name:simue-fresh
Description:forEM4仿google小清新简单模板，适合以此为基础进行二次开发
Version:4.1
Author:L卡片
Author Url:http://simue.com/blog/
Sidebar Amount:1
ForEmlog:4.1.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="nav2">
  <div class="nav2body">
		<ul class="pleft">
			<li><?php echo $blogname; ?>：</li>
			<?php $sort_cache = $CACHE->readCache('sort'); ?>
<?php foreach($sort_cache as $value): ?>
			<li><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?></a></li>
			<?php endforeach; ?>
		</ul>
    <ul class="pright">
    <li><a href="<?php echo BLOG_URL; ?>rss.php" title="订阅博客最新文章" target="_blank">订阅</a></li>
    <li><a href="javascript:addfav()" title="将当前网址放入收藏夹">收藏</a></li>
    <li><a href="<?php echo BLOG_URL; ?>admin/">管理</a></li>
    </ul>
  </div>
</div>
<div id="header">
  <div class="header_body">
    <h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a><span class="description"><?php echo $bloginfo; ?></span></h1>
    <div id="nav">
    <ul>
<?php if(isset($curpage)){ ?>
    <li<?php echo $curpage == CURPAGE_HOME ? ' class="on"' : ''; ?>><span><a href="<?php echo BLOG_URL; ?>">首页</a></span></li>
    <li<?php echo $curpage == CURPAGE_TW ? ' class="on"' : ''; ?>><span><a href="<?php echo BLOG_URL; ?>t/">微语</a></span></li>
<?php }else{ ?>
    <li<?php echo empty($_GET) ?  ' class="on"' : ''; ?>><span><a href="<?php echo BLOG_URL; ?>">首页</a></span></li>
<?php } ?>
<?php
global $CACHE; 
$navi_cache = $CACHE->readCache('navi');
foreach ($navi_cache as $key => $val):
if ($val['hide'] == 'y'){continue;}
if (empty($val['url'])){$val['url'] = Url::log($key);}
$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
$value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
?>
      <li<?php echo isset($logid) && $logid == $key ? ' class="on"' : ''; ?>><span><a href="<?php echo $val['url']; ?>" <?php echo $newtab; ?>><?php echo $val['naviname']; ?></a></span></li>
<?php endforeach;?>
<?php doAction('navbar', '<li><span>', '</span></li>'); ?>
<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
  <li><span><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></span></li>
  <li><span><a href="<?php echo BLOG_URL; ?>admin/">管理</a></span></li>
  <li><span><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></span></li>
<?php else: ?>
  <li><span><a href="<?php echo BLOG_URL; ?>admin/">登录</a></span></li>
<?php endif; ?>
    </ul>
    </div>
  </div>
</div>