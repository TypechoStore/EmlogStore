<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div id="footer">
  <div class="footer_top"></div>
  <div class="footer_body">
      <div class="copyright">
        Powered by <a href="http://www.emlog.net" target="_blank">emlog</a> | Design by <a href="http://simue.com" target="_blank">simue</a><?php if($icp) echo " | <a href=\"http://www.miibeian.gov.cn\" target=\"_blank\">" .$icp. "</a>"; ?> <?php echo $footer_info; ?>
        <div class="play1">(ㄒ<a href="http://simue.com">o</a>ㄒ)//</div>
      </div>
      <?php doAction('index_footer'); ?>
	</div>
</div>
<a id="movetop" href="javascript:movetop()">Top↑</a>
</body>
</html>
