<?php
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="main">
  <div id="main_left">
<?php doAction('index_loglist_top'); ?>
    <?php
if(isset($sortName)){
  echo '<h2 class="pagetitle">类别《<span>'.$sortName.'</span>》下的文章:</h2>';
}
if(isset($record)) {
  if(strlen($record)>6){
    echo '<h2 class="pagetitle">写于<span>'.substr($record,0,4).'年'.substr($record,4,2).'月'.substr($record,6,2).'日</span>的文章:</h2>';
  }else{
    echo '<h2 class="pagetitle">写于<span>'.substr($record,0,4).'年'.substr($record,4,2).'月</span>的文章:</h2>';
  }
}
if(isset($tag)) echo '<h2 class="pagetitle">标签《<span>'.$tag.'</span>》下的文章:</h2>';
if(isset($keyword)) echo '<h2 class="pagetitle">搜索关键词为『<span>'.$keyword.'</span>』的文章:</h2>';
if(isset($author)) echo '<h2 class="pagetitle">作者“<span>'.$user_cache[$author]['name'].'</span>”的文章:</h2>';
?>


	<div id="ml_content">
<?php foreach($logs as $value):?>


<div class="post" id="post-<?php echo $value['logid'] ?>">
    <div class="post_title">
        <h2<?php if($value['top']=='y'){echo " class=\"topflg\"";} ?>><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
        <div class="postinfo"><?php blog_sort($value['logid']); ?>&nbsp;&nbsp;作者：<?php blog_author($value['author']); ?> / <?php echo gmdate('Y-n-j H:i l', $value['date']); ?> <?php editflg($value['logid'],$value['author']); ?></div>
		</div>
		<div class="post_content clear">
				<?php echo $value['log_description']; ?>
				<div class="fujian"><?php blog_att($value['logid']); ?></div>
		</div>

    <div class="post_meta">
        <div class="post_tag"><?php blog_tag($value['logid']); ?></div>
        <div class="pmetainfo">
						<a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a> <a href="<?php echo $value['log_url']; ?>#tb">引用(<?php echo $value['tbcount']; ?>)</a> <a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a>
				</div>
				<div class="clear"></div>
    </div>
</div>


<?php endforeach; ?>
</div>			
  <div class="pagenav">
  <?php if($page_url) echo '<div class="pagenum">Pages:'.$page_url.'</div>' ?>
  </div>
</div>
<?php include View::getView('side'); ?><div class="clear"></div>
</div>
<?php include View::getView('footer'); ?>