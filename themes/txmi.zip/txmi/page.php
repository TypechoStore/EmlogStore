<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="cennr">
<div id="left" class="xian">
<dl id="info">
<dt><h1><?php topflg($top); ?><?php echo $log_title; ?></h1><span><em class="kan"><?php echo $views; ?></em><em class="ping"><?php echo $comnum; ?></em></span>   <?php echo gmdate('Y-n-j G:i l', $date); ?>  </dt>


<dd id="zi"><?php echo $log_content; ?>
<?php echo _g('fx'); ?></dd>

</dl>

<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?> 
</div>


<div id="rigth">
<?php include View::getView('side');?></div>
<div class="clear"></div></div>

<?php include View::getView('footer');?>
