<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="cennr">
<div id="left" class="xian">


<?php doAction('index_loglist_top'); ?>

<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
<dl id="lieb"><dt><h2><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
<span><em class="kan"><?php echo $value['views']; ?></em><em class="ping"><?php echo $value['comnum']; ?></em></span>   <?php blog_sort($value['logid']); ?> | <?php echo gmdate('Y-n-j G:i', $value['date']); ?> </dt>
<dd><?php $imgsrc = preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);$imgsrc = !empty($img[1]) ? $img[1][0] : ''; ?>
<?php if($imgsrc): ?>
	<i><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" class="tu"><img src="<?php echo $imgsrc; ?>"></a></i>
<?php else: ?><?php endif; ?><?php echo subString(strip_tags($value['log_description']),0,200); ?>...<a href="<?php echo $value['log_url']; ?>" class="more secai"  target="_blank">查看详细</a>
<div class="clear"></div></dd></dl>
<?php 
endforeach;
else:
?>
<dl id="lieb">	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p></dl>
<?php endif;?>


<div id="pagenavi">
	<?php echo $page_url;?>
<div class="clear"></div>
</div>

</div>


<div id="rigth"> 
<?php include View::getView('side');?></div>
</div>

<?php include View::getView('footer');?>