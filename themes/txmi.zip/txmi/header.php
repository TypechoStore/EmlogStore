<?php
/*
Template Name:天兴工作室多彩主题
Description:天兴工作室多彩三色主题
Version:1.0
Author:天兴工作室
Author Url:http://www.txcstx.cn/
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1.33,minimum-scale=1.0,maximum-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<?php if (_g('fengge') == "huang"): ?><link href="<?php echo TEMPLATE_URL; ?>css/huang.css" rel="stylesheet" type="text/css" /><?php else:endif; ?>
<?php if (_g('fengge') == "lan"): ?><link href="<?php echo TEMPLATE_URL; ?>css/lan.css" rel="stylesheet" type="text/css" /><?php else:endif; ?>
<?php if (_g('fengge') == "hong"): ?><link href="<?php echo TEMPLATE_URL; ?>css/hong.css" rel="stylesheet" type="text/css" /><?php else:endif; ?>	
<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<!--[if IE 6]>
<script src="<?php echo TEMPLATE_URL; ?>iefix.js" type="text/javascript"></script>
<![endif]-->
<?php doAction('index_head'); ?>
</head>
<body style="background-image: url(<?php echo _g('bg'); ?>);">
<div id="top"><dl><span><a href="<?php echo BLOG_URL; ?>feed.php">RSS订阅</a></span><?php echo $bloginfo; ?></dl></div>

<div id="w980">
<div id="head"><span id="ss"><form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php"> 
	<input name="keyword" class="search" type="text"  id="edtSearch"/>
	<input type="submit" value="搜索"  class="search-submit" id="btnPost"/>
	</form>
</span>
<a href="<?php echo BLOG_URL; ?>" class="logo" title="<?php echo $blogname; ?>"><img src="<?php echo _g('logo'); ?>"   alt="<?php echo $blogname; ?>"></a></div>

<div id="nav"><ul><?php blog_navi();?></ul>
</div>

<div id="place">当前位置：				<?php 
					if(blog_tool_ishome()):
						echo '首页';
					elseif(isset($logs)):
?>
<a href="<?php echo BLOG_URL;?>">首页</a> >> 
<?php if ($params[1]=='sort'){ ?>
			<?php echo $sortName; ?>
<?php }elseif ($params[1]=='tag'){ ?>
		 	标签 <?php echo urldecode($params[2]);?>
<?php }elseif($params[1]=='author'){ ?>
			作者 <?php echo blog_author($author);?>
<?php }elseif($params[1]=='keyword'){ ?>
			关键词 <?php echo urldecode($params[2]);?>
<?php }elseif($params[1]=='record'){ ?>
			时间 <?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?>
		<?php }?>
				<?php
					elseif(isset($logid) && !isset($neighborLog)):
				?>
					<a href="<?php echo BLOG_URL;?>">首页</a> >> <?php blog_sort($logid); ?> >> <?php echo $log_title;?>
				<?php
					elseif(isset($logid) && isset($neighborLog)):
				?>
					<a href="<?php echo BLOG_URL;?>">首页</a> >> <?php blog_sort($logid); ?> >> <?php echo $log_title;?>
				<?php
					elseif(isset($tws)):
				?>
					<a href="<?php echo BLOG_URL;?>">首页</a> >> 微语
				<?php
					endif;
				?></div>