<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="clear"></div>

<div  id="footer">
<p>Powered by <a href="http://www.emlog.net" title="采用emlog系统">emlog</a>,Theme By <a href="http://www.txcstx.cn">天兴工作室</a></p>
<?php echo $footer_info; ?></div>

<?php doAction('index_footer'); ?>
</div>

<script>prettyPrint();</script>
</body>
</html>