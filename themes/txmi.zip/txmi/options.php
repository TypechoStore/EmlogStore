<?php

/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
	'logo' => array(
		'type' => 'image',
		'name' => '网站logo',
		 'values' => array(
            TEMPLATE_URL . 'images/logo.png',
        ),
        'description' => 'logo大小为320*60',
	),
	
		'bg' => array(
		'type' => 'image',
		'name' => '网页背景图片',
		 'values' => array(
            TEMPLATE_URL . 'images/bg.gif',
        ),
        'description' => '网页背景图片，平铺展开',
	),
	
		'fx' => array(
		'type' => 'text',
		'name' => '文章页内容下在线分享',
		'default' => '请输入你的在线分享代码',
	),
	
	'fengge' => array(
        'type' =>'radio',
        'name' =>'主题配色风格',
        'values' => array(
        'huang' =>'黄色',
        'lan' =>'蓝色',
		'hong' =>'红色',
      ),
        'default' =>'huang',
    ),
	
);