<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="cennr">
<div id="left" class="xian">
<dl id="info">
<dt><h1><?php topflg($top); ?><?php echo $log_title; ?></h1><span><em class="kan"><?php echo $views; ?></em><em class="ping"><?php echo $comnum; ?></em></span>   <?php blog_sort($logid); ?> | <?php echo gmdate('Y-n-j', $date); ?>  </dt>

<dd id="zi"><?php echo $log_content; ?>
<P>推荐您阅读更多有关于“ <?php blog_tag($logid); ?> ”的文章</P>
<?php echo _g('fx'); ?></dd>

<dd id="post_nav">
<?php neighbor_log($neighborLog); ?>
<div class="clear"></div>
</dd>

<dd id="guan"><h2>猜你喜欢</h2>
<ul>
<?php if ($ganxq == "yes"): ?>
<?php related_logs($logData);?> 
<?php else: ?>	
<?php $index_hotlognum = Option::get('index_hotlognum');	$Log_Model = new Log_Model();	$randLogs = $Log_Model->getHotLog(8);?> <?php foreach($randLogs as $value): ?><li><span><?php echo gmdate('n-j', $date); ?></span><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
<?php endforeach; ?>
<?php endif; ?>
</ul></dd>

</dl>

<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?> 
</div>


<div id="rigth">
<?php include View::getView('side');?></div>
<div class="clear"></div></div>

<?php include View::getView('footer');?>
