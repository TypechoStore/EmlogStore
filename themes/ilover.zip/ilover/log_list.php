<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php doAction('index_loglist_top'); ?>
<div class="clear"></div>
<div id="container">
<div id="content">
<?php foreach($logs as $value): ?>
    <div class="content_text">
	<div class="content_header">
	<div class="title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></div>
	<div class="date"><?php echo gmdate('Y-n-j G:i l', $value['date']); ?>&nbsp;&nbsp;<?php editflg($value['logid'],$value['author']); ?></div>
    </div><!--end of content_header-->
	<div class="clear"></div>
	<div class="text">
	<?php echo $value['log_description']; ?>
    </div>
	</div><!--content_text End-->
<?php endforeach; ?>

<div id="pagenavi">
	<?php echo $page_url;?>
</div>

</div><!--end content-->

<?php
 include View::getView('side');
?>
 </div><!--end of container-->
<?php
 include View::getView('footer');
?>