<?php
/*
Template Name:ilover
Description:模板修改自http://www.ilover.in，简洁典雅，由野马移植到Emlog
Version:1.1
Author:野马
Author Url:http://yemaz.com
Sidebar Amount:1
ForEmlog:4.1.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<!--Header-->
<div id="ilover">
<div id="header">
<div id="nav">
<div id="blogtitle"><a href="<?php echo BLOG_URL; ?>" title= "<?php echo $blogname; ?>" rel="bookmark"><?php echo $blogname; ?></a></div><!--end of blogtitle-->
<div id="blogdescription"><?php echo $bloginfo; ?></div><!--end of blogdescription-->
</div><!--end of nav-->
<div id="menu">
    <ul>
        <li class="navi"><a href="<?php echo BLOG_URL; ?>">首页</a></li>
		<?php if($istwitter == 'y'):?>
		<li class="<?php echo $curpage == CURPAGE_TW ? 'current' : 'common';?>"><a href="<?php echo BLOG_URL; ?>t/">微语</a></li>
		<?php endif;?>
        <?php
		global $CACHE; 
		$navi_cache = $CACHE->readCache('navi');
        foreach ($navi_cache as $key => $val):
        if ($val['hide'] == 'y'){continue;}
        if (empty($val['url'])){$val['url'] = Url::log($key);}
		$newtab = $val['newtab'] == 'y' ? 'target="_blank"' : '';
		$val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
        ?>
        <li class="navi"><a href="<?php echo $val['url']; ?>" <?php echo $newtab; ?>><?php echo $val['naviname']; ?></a></li>
        <?php endforeach;?>
        <?php doAction('navbar', '<li class="navi">', '</li>'); ?>
        <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
        <li class="navi"><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></li>
        <li class="navi"><a href="<?php echo BLOG_URL; ?>admin/">管理中心</a></li>
        <li class="navi"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
        <?php else: ?>
        <li class="navi"><a href="<?php echo BLOG_URL; ?>admin/">登录</a></li>
        <?php endif; ?>
    </ul>
</div><!--end of menu-->
</div><!--end of header-->
<!--Header End-->
