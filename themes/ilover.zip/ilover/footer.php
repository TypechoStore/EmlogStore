<?php
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
</div>
<div style="clear:both;"></div>
<div id="footer">
Powered by <a href="http://www.emlog.net" target="_blank" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>│ CopyRight &copy; <?php echo date(Y); ?> <a href=<?php echo BLOG_URL;?>><?php echo $blogname; ?></a>, All Rights Reserved.│Themed by <a href="http://www.ilover.me/" target="_blank">ilover</a>, modified by <a href="http://yemaz.com/" target="_blank">野马</a><?php echo $footer_info; ?><!--请保留emlog以及模板作者的链接，这也是对你自己的尊重！-->
<?php doAction('index_footer'); ?>
</div>
</body>
</html>