<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<section id="content">
	<article class="post">
		<header>
			<h2><?php echo $log_title; ?></h2>
		</header>
		<div class="con">
			<?php echo $log_content; ?>
		</div>
	</article>
	<div class="postunder">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
</section>
<aside class="sidebar">
	<?php include View::getView('side'); ?>
</aside>
<div class="clear"></div>
<?php
 include View::getView('footer');
?>