<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<section id="content">
	<?php doAction('index_loglist_top'); ?>
	<?php foreach($logs as $value): ?>
		<article class="post">
			<div class="info">
				<a href="<?php echo $value['log_url']; ?>#comment"> <?php echo $value['comnum']; ?> COMMENTS</a>
			</div>
			<div class="date">
				<span class="day"><?php echo gmdate('j', $value['date']); ?></span>
				<span class="time"><?php echo gmdate('M', $value['date']); ?></span>
				<span class="year"><?php echo gmdate('Y', $value['date']); ?></span>
			</div>
			<header>
				<h2><?php topflg($value['top']); ?> <a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
			</header>
			<div class="con">
				<?php echo $value['log_description']; ?>
			</div>
		</article>
		<?php endforeach; ?>	
		<div class="post">
			<div id="pageurl"><?php echo $page_url;?></div>
		</div>
</section>
<aside class="sidebar">
	<?php include View::getView('side'); ?>
</aside>
<div class="clear"></div>
<?php
  include View::getView('footer');
?>