<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<footer id="footer"> 
    <div class="foot">
    	<a id="gotop" href="javascript:void(0);" onclick="MGJS.goTop();return false;">TOP</a>
		<div class="copy">Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> | Theme by <a href="http://pagecho.com">cho</a> | 移植 by <a href="http://lwllo.com">老王</a> | <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?></div>
	</div>
</footer>
</div>
<?php doAction('index_footer'); ?>
	</body>
</html>