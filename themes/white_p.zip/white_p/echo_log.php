<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<section id="content">
	<article class="post">
		<div class="info">
				<a href="<?php echo $log_url; ?>#comment"> <?php echo $comnum; ?> COMMENTS</a>
		</div>
		<div class="date">
			<span class="day"><?php echo gmdate('j', $date); ?></span>
			<span class="time"><?php echo gmdate('M', $date); ?></span>
			<span class="year"><?php echo gmdate('Y', $date); ?></span>
		</div>
		<header>
			<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
		</header>
		<div class="con">
			<?php echo $log_content; ?>
			<?php blog_att($logid); ?>
			<?php doAction('log_related', $logData); ?>
		</div>
	</article>
	<div class="postunder">
	<div id="comments"><?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?></div>
	</div>
</section>
<aside class="sidebar">
	<?php include View::getView('side'); ?>
</aside>
<div class="clear"></div>
<?php
  include View::getView('footer');
?>