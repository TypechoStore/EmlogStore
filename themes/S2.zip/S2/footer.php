<?php 
/**
 * 	底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js" type="text/javascript"></script>
<script>
$(document).ready(function(){
$(window).scroll(function(){
if($(this).scrollTop()!=0){
$('.top').fadeIn(500);}
else{
$('.top').fadeOut(500);} });
$('.top').click(function(){
$('body,html').animate({scrollTop:0},700);});
});
</script>
	<div class="footer"><?php echo $maxArray[$maxIndex]; ?><span class="top">返回顶部</span></div>
</div>
</div>
</body>
</html>