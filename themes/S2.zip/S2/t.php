<?php 
/**
 * 简志
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div class="t">
    	<div class="ttt">说说</div>
    	<?php foreach($tws as $val): $tid = (int)$val['id']; ?>
        <div class="tcontent"><?php echo $val['t']; ?><span class="ttime"> <?php echo $val['date']; ?></span></div>
        <?php endforeach;?>
    </div><?php echo $s2_tpage;?>
<?php
 include View::getView('footer');
?>