<?php 
/**
 * 输出日志
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div class="content">
    	<div class="contenttitle"><?php echo $log_title; ?><span class="date"><?php echo gmdate('Y.n.j', $date); ?></span></div>
        <div class="logcontent"><?php echo $log_content; ?></div>
        <div class="nei"><?php neighbor_log($neighborLog); ?></div>
        <?php blog_comments($comments); ?>
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    </div>
    <?php
 	include View::getView('footer');
	?>