<style>

.fwrap{
	position:fixed;
	width:500px;
	height:150px;
	top:50%;
	left:50%;
	margin:-75px 0 0 -250px;
	box-shadow:0 1px 5px #888;
	-webkit-box-shadow:0 1px 5px #888;
	-moz-box-shadow:0 1px 5px #888;
	z-index:3;
	text-align:center;
	background:#fff;
}
.fwrap:before{
	content:'';
	position:fixed;
	width:475px;
	height:110px;
	top:50%;
	left:50%;
	margin:-48px 0 0 -239px;
	background:#000;
	box-shadow:10px 10px 20px #888;
	-webkit-box-shadow:10px 10px 20px #888;
	-moz-box-shadow:10px 10px 20px #888;
	z-index:-1;
	-webkit-transform:skew(-12deg) rotate(-3deg);
	-moz-transform:skew(-12deg) rotate(-3deg);
	-o-transform:skew(-12deg rotate(-3deg));
	-ms-transform:skew(-12deg) rotate(-3deg);
}
.fwrap:after{
	content:'';
	position:fixed;
	width:475px;
	height:110px;
	top:50%;
	left:50%;
	margin:-48px 0 0 -239px;
	background:#000;
	box-shadow:-10px 10px 20px #888;
	-webkit-box-shadow:-10px 10px 20px #888;
	-moz-box-shadow:-10px 10px 20px #888;
	z-index:-1;
	-webkit-transform:skew(12deg) rotate(3deg);
	-moz-transform:skew(-12deg) rotate(3deg);
	-o-transform:skew(-12deg) rotate(3deg);
	-ms-transform:skew(-12deg) rotate(3deg);
}
.fava{
	float:left;
	width:178px;
	height:120px;
	background:#0093CD;
	padding:30px 0 0 20px;
}
.fboy, .fgirl{
	width:80px;
	height:80px;
	float:left;
	border-radius:50px;
	border:5px solid #fff;
}
.fboy{
	background:url(<?php echo TEMPLATE_URL; ?>img/boy.jpg) no-repeat center center;
}
.fgirl{
	background:url(<?php echo TEMPLATE_URL; ?>img/girl.jpg) no-repeat center center;
	margin-left:-25px;
}
.fenter{
	float:left;
	width:302px;
	height:150px;
	cursor:pointer;
	overflow:hidden;
}
.fto{
	overflow:hidden;
	width:604px;
	transition:0.5s margin-left;
	-webkit-transition:0.5s margin-left;
	-moz-transition:0.5s margin-left;
}
.fto:hover{
	margin-left:-302px;
	transition:0.5s margin-left;
	-webkit-transition:0.5s margin-left;
	-moz-transition:0.5s margin-left;
}
.fl, .fr{
	float:left;
	width:302px;
	height:150px;
	font-size:48px;
	text-align:center;
	line-height:150px;
	font-family:"Microsoft Jhenghei Light","微软雅黑 Light";
}
.fl{
	color:#0093CD;
	background:#fff;
}
.fr{
	color:#fff;
	background:#0093CD;
}
</style>
<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js" type="text/javascript"></script>
<script>
$(document).ready(function(){
$('.fenter').click(function(){
$('.fback, .fwrap').fadeOut(1000);});
});
</script>
<div class="fwrap">
		<div class="fava">
        	<div class="fboy"></div>
            <div class="fgirl"></div>
        </div>
		<div class="fenter">
        	<div class="fto">
        		<div class="fl">点击进入</div>
            	<div class="fr">一生挚爱</div>
            </div>
        </div>
</div>
