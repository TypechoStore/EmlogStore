<?php 
/**
 * 独立页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div class="content">
    	<div class="contenttitle">关于</div>
        <div class="logcontent"><?php echo $log_content; ?></div>
        <?php leave_comments($comments); ?>
		<?php leave_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    </div>
    <?php
 	include View::getView('footer');
	?>