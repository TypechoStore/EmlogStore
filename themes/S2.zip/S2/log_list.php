<?php 
/**
 * 日志列表
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
    <div class="list">
    	<?php if (!empty($logs)):
		foreach($logs as $value): 
		?>
        <div class="block">
        	<div class="logtitle"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a><span><?php echo gmdate('Y.n.j', $value['date']); ?></span></div>
            <div class="desc"><?php echo $value['log_description']; ?></div>
        </div>
        <?php endforeach; endif; ?>
		<?php echo $s2_logpage;?>
<?php
 include View::getView('footer');
?>
