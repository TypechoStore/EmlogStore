<?php 
/**
 * 侧边栏组件、页面模块
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach($navi_cache as $value):
        if ($value['pid'] != 0) {
            continue;
        }
		if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):
			?>
			<a href="<?php echo BLOG_URL; ?>admin/"><div class="common">管理</div></a>
			<a href="<?php echo BLOG_URL; ?>admin/?action=logout"><div class="common">退出</div></a>
			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
        $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'current' : 'common';
		?>
        <a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><div class="<?php echo $current_tab;?>"><?php echo $value['naviname']; ?></div></a>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog):?>
	<a href="<?php echo Url::log($prevLog['gid']) ?>" title="<?php echo $prevLog['title'];?>"><div class="pre"></div></a>
	<?php endif;?>
	<?php if($nextLog):?>
	<a href="<?php echo Url::log($nextLog['gid']) ?>" title="<?php echo $nextLog['title'];?>"><div class="next"></div></a>
	<?php endif;?>
<?php }?>
<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>
<?php
//相恋日
function loveDay($loveDate){
	$loveTime = strtotime($loveDate);
	$loveDays = (time()-$loveTime)/60/60/24;
	$lDay = floor($loveDays)+1;
	return $lDay;
}
?>
<?php
//blog：评论列表
function blog_comments($comments){
    extract($comments);
    if($commentStacks): ?>
	<div class="comment-header">评论</div>
	<?php endif; ?>
    <table border="1" cellspacing="0" style="border:1px solid #0093CD; border-collapse:collapse; font-size:14px;">
	<?php
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
    	<tr>
        	<td style="width:130px; text-align:center; color:#0093CD;"><?php echo $comment['poster']; ?></td>
            <td style="padding:10px; color:#333;"><?php echo $comment['content']; ?></td>
        </tr>
	<?php endforeach; ?>
    </table>
<?php }?>
<?php
//blog：留言列表
function leave_comments($comments){
    extract($comments);
    if($commentStacks): ?>
	<div class="comment-header">留言簿</div>
	<?php endif; ?>
    <table border="1" cellspacing="0" style="border:1px solid #0093CD; border-collapse:collapse; font-size:14px;">
	<?php
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
    	<tr>
        	<td style="width:130px; text-align:center; color:#0093CD;"><?php echo $comment['poster']; ?></td>
            <td style="padding:10px; color:#333;"><?php echo $comment['content']; ?></td>
        </tr>
	<?php endforeach; ?>
    </table>
<?php }?>
<?php
//发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
	<div id="comment-place">
	<div class="comment-post" id="comment-post">
		<div class="comment-header">写评论</div>
		<form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
			<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
			<?php if(ROLE == ROLE_VISITOR): ?>
			<div class="reply-nick" id="reply">昵称：<input type="text" name="comname" /></div>
            <div class="reply-nick" id="reply">网址：<input type="text" name="comurl" /></div>
			<?php endif; ?>
			<div class="reply-cont" id="reply">评论：<input type="text" name="comment" id="comment" /></div>
			<div class="reply-ok"><input type="submit" id="comment_submit" value="发布" /></div>
		</form>
	</div>
	</div>
	<?php endif; ?>
<?php } ?>
<?php
//发表留言表单
function leave_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
	<div id="comment-place">
	<div class="comment-post" id="comment-post">
		<div class="comment-header">给我留言</div>
		<form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
			<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
			<?php if(ROLE == ROLE_VISITOR): ?>
			<div class="reply-nick" id="reply">昵称：<input type="text" name="comname" /></div>
            <div class="reply-nick" id="reply">网址：<input type="text" name="comurl" /></div>
			<?php endif; ?>
			<div class="reply-cont" id="reply">留言：<input type="text" name="comment" id="comment" /></div>
			<div class="reply-ok"><input type="submit" id="comment_submit" value="发布" /></div>
		</form>
	</div>
	</div>
	<?php endif; ?>
<?php } ?>
<?php
//申请链接
function link_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
	<div id="comment-place">
	<div class="comment-post" id="comment-post">
		<div class="comment-header">申请链接</div>
		<form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
			<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
			<?php if(ROLE == ROLE_VISITOR): ?>
			<div class="reply-nick" id="reply">链接名称：<input type="text" name="comname" /></div>
            <div class="reply-nick" id="reply">链接地址：<input type="text" name="comurl" /></div>
			<?php endif; ?>
			<div class="reply-cont" id="reply">链接描述：<input type="text" name="comment" id="comment" /></div>
			<div class="reply-ok"><input type="submit" id="comment_submit" value="确认申请" /></div>
		</form>
	</div>
	</div>
	<?php endif; ?>
<?php } ?>
<?php
//widget：链接
function widget_link(){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
    //if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
	?>
	<?php foreach($link_cache as $value): ?>
	<p class="link"><a href="<?php echo $value['url']; ?>" target="_blank"><?php echo $value['link']; ?></a><span><?php echo $value['des']; ?></span></p>
	<?php endforeach; ?>
<?php }?> 
<?php
/**
 * 分页函数
 *
 * @param int $count 条目总数
 * @param int $perlogs 每页显示条数目
 * @param int $page 当前页码
 * @param string $url 页码的地址
 */
function pagination2($count, $perlogs, $page, $url) {
	$pnums = @ceil($count / $perlogs);
	$i = $page+1;
	$j = $page-1;
	if($pnums != 1){
		if($page == 1){
			return "<a href='".$url.$i."' title='下一页'><div class='nextpage'></div></a>";
		}elseif($page == $pnums){
			return "<a href='".$url.$j."' title='上一页'><div class='prepage'></div></a>";
		}else{
			return "<a href='".$url.$i."' title='下一页'><div class='nextpage'></div><a href='".$url.$j."' title='上一页'><div class='prepage'></div></a>";
		}
	}
}
$s2_logpage = pagination2($lognum, $index_lognum, $page, $pageurl);
$s2_tpage = pagination2($twnum, Option::get('index_twnum'), $page, BLOG_URL.'talk/?page=');
?>
<?php
//随机格言
$maxArray = array(
'任何值得去的地方，都没有捷径。',
'别人指的路，走不出成就感。',
'人生不易，青春不难。',
'宁愿做过了后悔，也不要错过了后悔。',
'人生就像钟表，可以回到起点，却已不是昨天。',
'活在当下，快乐已然。',
'运气就是机会碰巧撞到了你的努力。',
'人生最大的遗憾莫过于错误坚持和轻易放弃。',
'命运并不会因为你欲哭无泪，而停止给你伤悲。',
'情未终，梦正浓，寸寸相思与君同。',
'一个人越懒，明天要做的事越多。',
'相遇而遇，及期则遇。',
'我们听过无数的道理，却仍旧过不好这一生。',
'结局很美妙的事情，开头并非如此。',
'或许有一天我们都老了，但我依然记得当初你让我心动的样子。无论我变得如何强大，你仍然是我的弱点。',
'生活坏到一定程度就会好起来，因为它无法更坏。所以我们心中应该总是充满阳光。',
'照顾每个人的感受，注定自己不会好受。',
'有的人对你好，是因为你对他好；有的人对你好，是因为懂得你的好。',
'维系一段感情的，不是坦白，而是考虑到对方的感受，有所保留。',
'人生的旅途中，你总有那么一段时间，需要自己走，需要自己扛。',
'梦想和自由一样，都有代价，但都值得。',
'变老是人生的必修课，而变成熟则是选修课。',
'生活只有经得起平静，方才显淡泊宁静的真实。',
'一个人，如果没有经受过投入和用力的痛楚，又怎么会明白决绝之后的海阔天空。',
'学会适应，就会让你的环境变的明亮；学会宽容，就会让你的生活没有烦恼。',
'幸福不是终点，而是旅程的途中。',
'没有什么是一定要的。如果说有什么一定要的，那就是对自己好。',
'对身边的人好点，因为重要的人越来越少，剩下的越来越重要。',
'关于生活中的每一件事都可以用三个字总结：会过去。',
'时间是单行道，过去了，回不来。',
'时间走了，一切是云烟；记忆散了，一切是少年。',
'永远相信美好的事情即将发生。',
'只要还有明天，今天就永远是起跑线。',
'所有人的成功都不是偶然的。',
'万事如意就离死不远了。',
'放宽心，坚持住，一切都是最好的安排。',
'知易行难。',
'学会与自己的伤痛和平共处，这就是成长的意义。',
'大喜大悲看清自己，大起大落看清朋友。',
'人不会死在绝境，却往往栽在十字路口。',
'人之患在好为人师。',
'自知者不怨人，知命者不怨天。',
'大喜大悲看清自己，大起大落看清朋友。',
'最痛苦的事，不是失败，是我本可以。',
'不如意事常八九，可与言者无二三。'
);
$maxIndex = rand(0, count($maxArray) - 1);
?>