<?php 
/**
 * 友情链接
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="content">
    	<div class="contenttitle">朋友</div>
        <div class="logcontent"><?php echo widget_link(); ?></div>
		<?php link_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
<?php
	include View::getView('footer');
?>