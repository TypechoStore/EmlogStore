<?php 
/**
 * 自定义404页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>404 Not Found</title>
<style>
body{
	background:#ddd;
}
.error{
	position:absolute;
	width:600px;
	height:120px;
	left:50%;
	top:50%;
	margin-left:-300px;
	margin-top:-60px;
	background:#fff;
	font-size:14px;
	color:#666;
	font-family:"微软雅黑";
	box-shadow:0 1px 4px #888;
	-webkit-box-shadow:0 1px 4px #888;
	-moz-box-shadow:0 1px 4px #888;
}
.error:after{
	position:absolute;
	content:'';
	width:600px;
	height:100px;
	left:50%;
	top:50%;
	margin:-40px 0 0 -300px;
	background:#000;
	box-shadow:0 2px 20px #888;
	-webkit-box-shadow:0 2px 20px #888;
	-moz-box-shadow:0 2px 20px #888;
	border-radius:100px/30px;
	z-index:-1;
}
.error-title{
	width:585px;
	height:47px;
	line-height:47px;
	color:#0093CD;
	font-size:20px;
	padding-left:15px;
	background:#f8f8f8;
	border-top:3px solid #0093CD;
	border-bottom:1px solid #eee;
}
.error-cont{
	width:570px;
	height:70px;
	line-height:70px;
	padding:0px 15px;
}
.error-cont span{
	float:right;
}
a{
	text-decoration:none;
	color:#0093CD;
}
</style>
</head>
<body>
<div class="error">
	<div class="error-title">错误</div>
	<div class="error-cont">您所请求的页面未找到。<span><a href="<?php echo BLOG_URL; ?>">点击返回</a></span></div>
</div>
</body>
</html>