<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div id="sheli-main">
<div id="mbx"><p>现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; <?php echo $log_title; ?></p></div>
<div id="sheli-right">
<div id="sheli-page">
<div id="sheli-page-tt"><?php echo $log_title; ?></div>
<div id="sheli-page-nr"><?php echo $log_content; ?></div>
<?php blog_comments($comments); ?><?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div></div><?php //!--end sheli-right--?>
<div id="sheli-left"><?php include View::getView('side');?></div></div>
<?php include View::getView('footer');?>