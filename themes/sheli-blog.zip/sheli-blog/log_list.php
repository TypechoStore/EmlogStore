<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<?php if($pageurl == Url::logPage()){ ?><?php include View::getView('index'); ?><?php }else{ ?>
<div id="sheli-main">
<div id="mbx"><p>现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; 
<?php if ($params[1]=='sort'){ ?><?php echo '<a href="'.Url::sort($sortid).'">'.$sortName.'</a>';?>
<?php }elseif ($params[1]=='tag'){ ?>包含标签 <b><?php echo urldecode($params[2]);?></b> 的所有文章
<?php }elseif($params[1]=='author'){ ?>作者 <b><?php echo blog_author($author);?></b> 的所有文章
<?php }elseif($params[1]=='keyword'){ ?>搜索 <b><?php echo htmlspecialchars(urldecode($params[2]));?></b> 的所有结果
<?php }elseif($params[1]=='record'){ ?>发表在 <b><?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?> </b>的所有文章<?php }else{?><?php }?></p></div>
<div id="sheli-right">
<?php doAction('index_loglist_top'); ?>
<?php if (!empty($logs)):foreach($logs as $value): ?>
<div id="sheli-list" class="bk">
<div id="sheli-list-left"><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" ><img src="<?php get_thum($value['logid']);?>" alt="<?php echo $value['log_title']; ?>"/></a></div>
<div id="sheli-list-right">
<p id="list-tt"><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></p>
<p id="list-date">日期：<?php echo gmdate('Y-n-j', $value['date']); ?> | 作者：<?php blog_author($value['author']); ?> | 浏览：<?php echo $value['views']; ?> 次 | 分类：<?php blog_sort($value['logid']); ?> </p>
<p id="list-nr"><?php echo subString(strip_tags($value['content']),0,150);?></p>
</div>
<div id="list-tag">评论：<?php echo $value['comnum']; ?> 条 <?php blog_tag($value['logid']); ?><a href="<?php echo $value['log_url']; ?>" id="list-tag-right" title="阅读全文">阅读全文</a></div></div>
<?php endforeach;else:?>
<div id="sheli-list-wzd" class="bk">
<div id="list-tt">未找到你要找的文章</div>
<p>抱歉，没有符合您查询条件的结果。</p>
</div>
<?php endif;?>
<div id="pages" class="bk" ><?php echo $page_url;?></div>
</div><?php //!-- end #sheli-right--?>
<div id="sheli-left"><?php include View::getView('side');?></div>
</div><?php } ?>
<?php include View::getView('footer');?>