<?php
/*
Template Name:舍力主题模板系列001
Description:<br /><font color=red>＊</font>本主题由舍力设计和维护（更新日期：2014-08-27）<br><font color=red>＊</font>模板修改后出现的任何问题请自行解决<br><font color=red>＊</font>在未修改的情况下，如有任何问题，请点击下面的使用说明进行反馈<br><br><a href="http://www.shuyong.net/" target="_blank">作者站点</a>    <a href="http://www.shuyong.net/393.html" target="_blank">使用说明</a>
Version:v1.0
Author:舍力
Author Url:http://www.shuyong.net
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link href="<?php echo TEMPLATE_URL; ?>css-js/sheli-main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<!--[if IE 6]><script src="<?php echo TEMPLATE_URL; ?>iefix.js" type="text/javascript"></script><![endif]--><?php doAction('index_head'); ?>
</head>
<body>
<div id="header"><div id="sheli-head"><div id="head-wz"><?php echo $blogname; ?></div><div id="head-right"><p><?php echo $bloginfo; ?></p></div></div></div>
<div id="sheli-nav"><div id="nav"><?php blog_navi();?></div></div>