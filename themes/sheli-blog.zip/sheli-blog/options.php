<?php
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
'index-wz' => array(
'type' =>'text',
'name' =>'首页导航下文字描述',
'default' =>'舍力博客记录生活中点滴，发现与分享生活中的乐趣，永远保持乐观开朗的心态，让每一天都过得精彩。',
'multi' => true,
),

'index-num' => array(
'type' =>'text',
'name' =>'首页分类文章显示数量',
'default' =>'10',
),

'index-sort1' => array(
'type' =>'sort',
'name' =>'分类日志ID(第一个位置)',
'default' => '1',
),

'index-sort2' => array(
'type' =>'sort',
'name' =>'分类日志ID(第二个位置)',
'default' => '1',
),

'index-sort3' => array(
'type' =>'sort',
'name' =>'分类日志ID(第三个位置)',
'default' => '1',
),

'index-sort4' => array(
'type' =>'sort',
'name' =>'分类日志ID(第四个位置)',
'default' => '1',
),

'index-sort-kg' => array(
'type' =>'radio',
'name' =>'首页文章显示开关',
'values' => array(
'no' =>'全部不显示',
'yi' =>'显示一排(2个分类)',
'er' =>'显示二排(4个分类)',
),
'default' =>'no',
),

'pic_sort' => array(
'type' => 'sort',
'name' => '首页图文列表分类id',
'default' => '1',
),

'pic-num' => array(
'type' =>'text',
'name' =>'首页图文列表显示数量',
'default' =>'10',
),

	);