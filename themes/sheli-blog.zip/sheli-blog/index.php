<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div id="sheli-main">
<div id="mbx"><p><?php echo _g('index-wz'); ?></p></div>
<div id="sheli-right">
<div class="index-ttnews"><div class="index-ttnews-tt">头条新闻</div><?php home_slideshow();?></div>
<div class="pic-sort bk"><div class="index-pic-sort-tt">图文展示</div><?php indextop_sort(_g('pic_sort'),_g('pic-num')); ?></div>
<div class="index-flwz">
<?php if (_g('index-sort-kg') == "yi"): ?>
<ul><?php echo get_list(_g('index-sort1'),_g('index-num'));?></ul>
<ul><?php echo get_list(_g('index-sort2'),_g('index-num'));?></ul>
<?php else: ?><?php endif; ?>
<?php if (_g('index-sort-kg') == "er"): ?>
<ul><?php echo get_list(_g('index-sort1'),_g('index-num'));?></ul>
<ul1><?php echo get_list(_g('index-sort2'),_g('index-num'));?></ul1>
<ul><?php echo get_list(_g('index-sort3'),_g('index-num'));?></ul>
<ul1><?php echo get_list(_g('index-sort4'),_g('index-num'));?></ul1>
<?php else: ?><?php endif; ?>
</div></div>
<div id="sheli-left"><?php include View::getView('side');?></div></div><?php //!-- main end -- ?>