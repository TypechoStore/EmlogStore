<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div class="footer"><div class="foot">Copyright © 2014 <?php echo $blogname; ?> 版权所有 <?php echo $icp; ?><br />
<?php echo $footer_info; sl();?></div></div><?php doAction('index_footer'); ?>
</body></html>