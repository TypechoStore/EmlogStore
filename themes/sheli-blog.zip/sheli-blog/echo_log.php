<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div id="sheli-main">
<div id="mbx"><p>现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; <?php blog_sort($logid); ?> &raquo; <?php echo $log_title; ?></p></div>
<div id="sheli-right">
<div id="sheli-log">
<div id="sheli-log-tt"><?php topflg($top); ?><?php echo $log_title; ?></div>
<div id="log-date">日期：<?php echo gmdate('Y-n-j', $date); ?> | 作者：<?php blog_author($author); ?> | 分类：<?php blog_sort($logid); ?> | 评论:<?php echo $comnum;?> 条 | 浏览：<?php echo $views;?> 次 <?php blog_tag($logid); ?></div>
<div id="sheli-log-nr"><?php echo $log_content; ?></div>
<div class="log-bq"><script type="text/javascript">bdfx()</script>本文固定链接：<?php echo Url::log($logid); ?><br />本文由<?php blog_author($author); ?>原创或编辑，互联分享请尊重作者劳动成果，转载请以链接形式标明本文地址</div>
<?php doAction('log_related', $logData); ?>
<div class="log-xgwz"><p class="log-xgwz-tt">你可能感兴趣的话题</p><?php related_logs($logData);?></div>
<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
<?php blog_comments($comments); ?><?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div></div><?php //!--end sheli-right--?>
<div id="sheli-left"><?php include View::getView('side');?></div></div>
<?php include View::getView('footer');?>