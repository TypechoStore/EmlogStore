<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<footer class="footer">
<div class="footer_container"><div class="clearfix">
<div class="footer-col footer-col-logo"><img src="<?php echo TEMPLATE_URL; ?>tpimg/logo.jpg" alt="<?php echo $blogname; ?>"></div>
<div class="footer-col footer-col-copy">
<ul class="footer-nav hidden-xs">
<li class="menu-item">
<a  href="<?php echo BLOG_URL; ?>tousjiany.html" target="_blank">投诉建议</a><a  href="<?php echo BLOG_URL; ?>sitemap.xml" target="_blank">sitemap</a><a  href="<?php echo BLOG_URL; ?>anli.html" target="_blank">案例展示</a>
<a href="http://www.miibeian.gov.cn/" rel="nofollow" target="_blank" title="ICP备案号：<?php echo $icp; ?>"><?php echo $icp; ?></a>
<?php echo $footer_info; ?></li></ul>
<div class="copyright">Copyright<i class="fa fa-copyright"></i>2017-2018<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?>.</a>基于<a href="http://www.emlog.net/" title="至强 Emlog" rel="nofollow" target="_blank">EMLOG</a>搭建.
</div></div>
<div class="footer-col footer-col-sns"><div class="footer-sns">
<a class="sns-wx" href="javascript:;"><i class="fa fa-lock"></i><span class="https" title="已开启HTTPS安全加密服务" style="background-image:url(<?php echo TEMPLATE_URL; ?>tpimg/ssl.png);"></span></a>
<a rel="nofollow" class="sns-wx" href="javascript:;"><i class="fa fa-weixin"></i><span style="background-image:url(<?php echo $wxurl; ?>);"></span></a>
<a class="sns-wx" rel="nofollow"  target="_blank" title="QQ空间" href="//user.qzone.qq.com/<?php echo $txurl; ?>"><i class="fa fa-chrome"></i></a>
<a rel="nofollow"  target="_blank" title="新浪微博地址" href="<?php echo $xlurl; ?>" rel="nofollow"><i class="fa fa-weibo"></i></a>
</div></div></div></div></footer>
<?php include View::getView('top/tpfooter');?>
</body></html>
<?php
if($compress_html== 1 ){
        $html=ob_get_contents();
        ob_get_clean();
        echo em_compress_html_main($html);
}
?>