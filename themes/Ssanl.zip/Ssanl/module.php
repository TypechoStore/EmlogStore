<?php 
/**
 * Ssanl.Theme by 东轩
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
date_default_timezone_set('Asia/Shanghai');
if (PHP_VERSION < '5.0'){emMsg('您的php版本过低，请选用支持PHP5的环境配置。');}
require_once View::getView('top/config');
global $arr_navico1;
$arr_navico1 = unserialize($arr_navico);
global $arr_sortico1;
$arr_sortico1 = unserialize($arr_sortico);
?>
<?php
//分页标题后面加 - 第几页
function page_tit($page){
        if ($page>=2){ echo ' - 第'.$page.'页'; }
}
?>
<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
<div class="widget-box widget wow fadeInDown" id="readers"><h3 class="widget-title"><i class="fa fa-th"></i><?php echo $title; ?></h3>
<ul class="widget-content readers"><?php echo huoyue(12); ?></ul></div> 
<?php }?>
<?php
//widget：TAG随机与推荐
function widget_calendar($title){ ?>
<div class="widget-box widget" id="tabcelan">
<ul class="widget-content tabcelan"><li id="con_title"><ul id="tab"><li id="one1" class="tabhover">随机</li><li id="one2" class="">推荐</li></ul></li>
<li id="con_one">
<ul id="con_one_1" style="display: block;"><?php random_sj();?></ul>
<ul id="con_one_2" style="display: none;"><?php random_tj();?></ul>
</li></ul></div>
<?php }?>

<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');
	$tag_cache = array_slice($tag_cache,0,24);?>
<div class="widget-box widget wow fadeInDown" id="hottags">
<h3 class="widget-title"><i class="fa fa-tags"></i><?php echo $title; ?></h3>
<ul class="widget-content hottags"><?php foreach($tag_cache as $value): ?>
<li class="divTags3"><a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['tagname']; ?>(<?php echo $value['usenum']; ?>)"><?php echo $value['tagname']; ?></a></li>
<?php endforeach; ?></ul></div>	
<?php }?>
<?php
//search：标签
function search_tag($title){
    global $CACHE;
    $tag_cache = $CACHE->readCache('tags');?>
        <?php shuffle ($tag_cache);
		$tag_cache = array_slice($tag_cache,0,30);foreach($tag_cache as $value): ?>
			<li><a href="<?php echo BLOG_URL; ?>tag/<?php echo $value['tagname']; ?>"><?php echo $value['tagname']; ?></a></li>
        <?php endforeach; ?>
<?php }?>	
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
<div class="widget-box widget wow fadeInDown" id="divArchives">
<h3 class="widget-title"><i class="fa fa-th"></i><?php echo $title; ?></h3>
<ul class="widget-content divArchives">
	<?php
	foreach($sort_cache as $value):
		$sid=$value["sid"];
		if ($value['pid'] != 0) continue;
	?>
		<li> <a title="<?php echo $value['lognum'] ?> 篇文章" href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?></a> </li> 
	<?php endforeach; ?>
	</ul> </div> 

<?php }?>
<?php
//widget：最新微语
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	?>
    <div class="widget-box widget" id="shangxi">
<ul class="widget-content shangxi">
<h3 class="sx-title"><i class="fa fa-asterisk"></i><?php echo $title; ?></h3>
<?php foreach($newtws_cache as $value): ?>
<?php $img = empty($value['img']) ? "" : '<a title="查看图片" class="t_img" href="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" >&nbsp;</a>';?>
<li class="shangxi">
<p class="plus"><?php echo $value['t']; ?><?php echo $img;?></p>
</li>
<?php endforeach; ?>
    <?php if ($istwitter == 'y') :?>
	<?php endif;?>
</ul>
</div>	

<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
<div class="widget-box widget wow fadeInDown" id="divComments">
<h3 class="widget-title"><i class="fa fa-th"></i><?php echo $title; ?></h3>
<ul class="widget-content divComments">
<?php foreach($com_cache as $value): $url = Url::comment($value['gid'], $value['page'], $value['cid']); ?>
<li><span class="zb_avatar"><a href="<?php echo $url; ?>"><img src="<?php echo getqqtx($value['mail']);?>" alt="<?php echo $value['name']; ?>"></a></span><p><a href="<?php echo $url; ?>"><?php echo sidecomcontent($value['content']); ?></a></p><small><?php echo $value['name']; ?> 评论于：<?php echo smartDate($value['date']); ?></small></li>
<?php endforeach; ?>
</ul>
</div>	
<?php }?>
<?php
//widget：最新文章
function widget_newlog($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
<div class="widget-box widget wow fadeInDown" id="side_randimg">
<h3 class="widget-title"><i class="fa fa-th"></i><?php echo $title; ?></h3>
<ul class="widget-content side_randimg">
<?php foreach($newLogs_cache as $value):
$thum_src = getThumbnail($value['gid']);
            $imgsrc = getimgforgid($value['gid']);
            if($thum_src) {
                $img = $thum_src;
            }elseif($imgsrc){
                $img = $imgsrc;
            }else{
               $img = TEMPLATE_URL.'tpimg/cats.jpg';
            } ?>
<li><a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>"><div class="hotpost-img"><img src="<?php echo $img;?>" alt="<?php echo $value['title']; ?>" class="randsimg"></div><div class="hotpost-left"><span class="hot-post-title"><?php echo $value['title']; ?></span><span class="hot-post-clock"><i class="fa fa-clock-o"></i><?php echo gettime($value['gid']);?></span><span class="hot-post-info"><i class="fa fa-comment"></i><?php echo blog_content($value['gid'],'comnum');?></span></div></a></li>
<?php endforeach; ?>
</ul>
</div>
<?php }?>
<?php
//widget：热门文章
function widget_hotlog($title){
	$index_hotlognum = Option::get('index_hotlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getHotLog($index_hotlognum);?>
<div class="widget-box widget wow fadeInDown" id="divPrevious">
<h3 class="widget-title"><i class="fa fa-th"></i><?php echo $title; ?></h3>
<ul class="widget-content divPrevious">
<?php foreach($randLogs as $value): ?>
<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
<?php endforeach; ?>
</ul>
</div>
<?php }?>
<?php
//widget：随机文章
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
<div class="widget-box widget wow fadeInDown" id="divPrevious">
<h3 class="widget-title"><i class="fa fa-th"></i><?php echo $title; ?></h3>
<ul class="widget-content divPrevious">
<?php foreach($randLogs as $value): ?>
<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
<?php endforeach; ?>
</ul>
</div>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>

<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
<div class="widget-box widget wow fadeInDown" id="divArchives">
<h3 class="widget-title"><i class="fa fa-th"></i><?php echo $title; ?></h3>
<ul class="widget-content divArchives">
	<?php foreach($record_cache as $value): ?>
<li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
	<?php endforeach; ?>
</ul>
</div> 	
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
    <div class="widget-box widget" id="divmeiri">
	<h3 class="widget-title"><i class="fa fa-th"></i><?php echo $title; ?></h3>
<ul class="widget-content divmeiri"><?php echo $content; ?></ul>
</div>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
    //if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
	?>
<div class="widget-box widget wow fadeInDown" id="divLinkage">
<h3 class="widget-title"><i class="fa fa-th"></i><?php echo $title; ?></h3>
<ul class="widget-content divLinkage">
	<?php foreach($link_cache as $value): ?>
	<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
	<?php endforeach; ?>
</ul>
</div> 	
<?php }?> 
<?php
//blog：导航
function blog_navi(){
    global $CACHE; 
    global $arr_navico1;
    global $arr_sortico1;
    define('TEMROOT', EMLOG_ROOT.'/content/templates/tadpole/inc');
    $config_file = TEMROOT.'/config.php';
    if (is_file($config_file)) {include $config_file;}
	$navi_cache = $CACHE->readCache('navi');
	?>
	<?php
	foreach($navi_cache as $value): $id=$value["id"]; if ($value['pid'] != 0) {continue;}
		if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):?>
			<li class="nvabar-category"><a href="<?php echo BLOG_URL; ?>admin/">管理站点</a></li>
			<li class="nvabar-category"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
        $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'item-index' : 'category';
		$no_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'class="on"' : '';
		$menu_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? '' : 'menu-item-has-children';
		?>
		<li id="nvabar-<?php echo $current_tab;?>" class="<?php if (!empty($value['children']) || !empty($value['childnavi'])) :?><?php echo $menu_tab;?><?php endif;?>">
			<a href="<?php echo $value['url']; ?>" <?php echo $newtab;?> <?php echo $no_tab;?>>
			<?php if(empty($arr_navico1[$id])) {echo $value['naviname'];}else {echo "<i class='".$arr_navico1[$id]."'></i> ".$value['naviname']."";} ?>
			</a>
			<?php if (!empty($value['children'])) :?>
           <ul class="dropdown-menu sub-menu">
                <?php foreach ($value['children'] as $row){
                        echo '<li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="'.Url::sort($row['sid']).'"><i class="'.$arr_sortico1[$row['sid']].'"></i>'.$row['sortname'].'</a></li>';
                }?>
			</ul >
            <?php endif;?>
            <?php if (!empty($value['childnavi'])) :?>

<ul class="dropdown-menu sub-menu">
<?php foreach ($value['childnavi'] as $row){
$newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';
echo '<li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="' . $row['url'] . "\" $newtab >" . $row['naviname'].'</a></li>';}?>
</ul >
<?php endif;?>
		</li>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：置顶
function topflg($top, $sortop='n', $sortid=null){
    if(blog_tool_ishome()) {
       echo $top == 'y' ? "<div class=\"post-top\"></div>" : '';
    } elseif($sortid){
       echo $sortop == 'y' ? "<div class=\"news\"></div> " : '';
    }
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：返回分类
function fanhui_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
    <a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>" class="backtolist">返回列表</a>
	<?php endif;?>
<?php }?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
    <a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
	<?php endif;?>
<?php }?>
<?php
//blog：文章标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "<a href=\"".Url::tag($value['tagurl'])."\" rel=\"tag\"  title=\"".$value['tagname']."\">".$value['tagname'].'</a>';
		}
		echo $tag;
	}
}
?>
<?php
//blog：文章作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){ extract($neighborLog);?>
<div class="post-previous">
<?php if($prevLog):?><span>上一篇：</span><a href="<?php echo Url::log($prevLog['gid']) ?>" rel="prev" title="<?php echo $prevLog['title'];?>"><?php echo $prevLog['title'];?></a><?php else: ?>
<a title="没错这就是本分类第一篇文章">没有咯</a><?php endif;?></div>
<div class="post-next">
<?php if($nextLog):?><span>下一篇：</span><a href="<?php echo Url::log($nextLog['gid']) ?>" rel="next" title="<?php echo $nextLog['title'];?>"><?php echo $nextLog['title'];?></a><?php else: ?>
 <a title="没错这就是本分类最后一篇文章">结束咯</a><?php endif;?></div>   
<?php }?> 
<?php
//blog：评论列表
function blog_comments($comments){
    extract($comments);$comnum = count($comments);
    if($commentStacks): ?>
<div class="comment-tab"><div class="come-comt">
<i class="fa fa-comments"></i>评论列表 <span id="comment_count">（已有<span style="color:#E1171B"><?php echo $comnum; ?></span>条评论）</span></div>
</div>
<label id="AjaxCommentBegin"></label>	
 	<?php endif; ?>
<?php
	$isGravatar = Option::get('isgravatar');
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>	
<div class="shadow-box msg noimg wow fadeInDown" id="cmt<?php echo $comment['cid']; ?>">
  <div class="msgimg">
  <?php if($isGravatar == 'y'): ?>
  <img class="avatar" src="<?php echo getqqtx($comment['mail']);?>">
  </div>
<?php endif; ?>  
<div class="msgtxt">
  <div class="msgname">
<?php echo $comment['poster']; ?>
<span class="LevelName auleve"><?php echo echo_levels("\"".strip_tags($comment['mail'])."\"","\"".$comment['url']."\"");?></span>
<span><?php echo $comment['date']; ?><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)" class="comment-reply-link">回复</a></span>
   <div class="msgarticle">
<?php echo comcontent($comment['content']); ?> <label id="AjaxComment<?php echo $comment['cid']; ?>"></label> 
  </div>
 </div>
 	 <?php blog_comments_children($comments, $comment['children']); ?>
</div>
</div>
<?php endforeach; ?>
  <div id="comments-nav" class="pagination wow fadeInDown">
       <div class="page-list">
	   <?php echo $commentPageUrl;?>
 </div>
  </div>
<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>   
  <div class="shadow-box msg noimg wow fadeInDown" id="cmt<?php echo $comment['cid']; ?>">
  <div class="msgimg">
 <?php if($isGravatar == 'y'): ?><img class="avatar" src="<?php echo getqqtx($comment['mail']);?>">
  </div>
<div class="msgtxt">
<div class="msgname">
<?php echo $comment['poster']; ?>
<span class="LevelName auleve"><?php echo echo_levels("\"".strip_tags($comment['mail'])."\"","\"".$comment['url']."\"");?></span>
<?php if($comment['level'] < 4): ?><span><?php echo $comment['date']; ?><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)" class="comment-reply-link">回复</a></span>
 <?php endif; ?> 
   <div class="msgarticle">       
  <?php echo comcontent($comment['content']); ?>
	<label id="AjaxComment<?php echo $comment['cid']; ?>"></label>    
	</div>
 </div>
</div>
<?php endif; ?>  
 <?php blog_comments_children($comments, $comment['children']);?>
</div>
<?php endforeach; ?>
<?php }?>

<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>	
	<div id="comment-place">
	<div class="comment-post" id="comment-post">	
<div class="commentpost wow fadeInDown" id="comment">
  <h4><i class="fa fa-pencil"></i>发表评论<a name="respond"></a><span><a rel="nofollow" id="cancel-reply" href="javascript:void(0);" onclick="cancelReply()" style="display: none;"><small>取消回复</small></a></span></h4>
  <form id="frmSumbit" name="commentform" target="_self" method="post" action="<?php echo BLOG_URL; ?>index.php?action=addcom">
  <input type="hidden" name="gid" id="inpId" value="<?php echo $logid; ?>">
   <input type="hidden" name="pid" id="inpRevID" value="0" id="commail" >
  <?php if(ROLE == ROLE_VISITOR): ?>
  <div class="comt-box">
  <div class="form-group liuyan form-name"><input type="text" id="inpName" class="text" name="comname" tabindex="1"  placeholder="名称（必填）"></div>
  <div class="form-group liuyan form-email"><input type="text" id="inpEmail" class="text" name="commail" tabindex="2" placeholder="邮箱（必填）"> </div>
  <div class="form-group liuyan form-www"><input type="text" id="inpHomePage" name="comurl"  class="text" tabindex="3" placeholder="网址"></div>
  </div>
  <?php endif; ?>
  <!--verify-->
  <div id="comment-tools">
<!--    <span class="com-title">快捷回复：</span>-->
   <span class="com-title">快捷回复：</span>
    <a title="粗体字" onmousedown="InsertText(objActive,ReplaceText(objActive,&#39;[B]&#39;,&#39;[/B]&#39;),true);"><i class="fa fa-bold"></i></a>
    <a title="斜体字" onmousedown="InsertText(objActive,ReplaceText(objActive,&#39;[I]&#39;,&#39;[/I]&#39;),true);"><i class="fa fa-italic"></i></a>
    <a title="下划线" onmousedown="InsertText(objActive,ReplaceText(objActive,&#39;[U]&#39;,&#39;[/U]&#39;),true);"><i class="fa fa-underline"></i></a>
    <a title="删除线" onmousedown="InsertText(objActive,ReplaceText(objActive,&#39;[S]&#39;,&#39;[/S]&#39;),true);"><i class="fa fa-strikethrough"></i></a>
    <a href="javascript:addNumber(&#39;文章不错,写的很好！&#39;)"><i class="fa fa-thumbs-o-up"></i></a>
    <a href="javascript:addNumber(&#39;这。。看不懂怎么破？&#39;)"><i class="fa fa-thumbs-o-down"></i></a>
    <a href="javascript:addNumber(&#39;赞、狂赞、超赞、不得不赞、史上最赞！&#39;)"><i class="fa fa-heart"></i></a>
	<span id="faces"><i class="fa fa-smile-o"></i></span>
	 <div id="UbbFrame" style="display:none">
     <?php include View::getView('top/smile');?>
	 </div>
	
  </div>

  <textarea placeholder=" 请遵守相关法律与法规，文明评论。O(∩_∩)O~~" name="comment" id="txaArticle" class="text input-block-level comt-area" cols="50" rows="4" tabindex="5"></textarea>
  <p><?php echo $verifyCode; ?> <input name="pid" type="submit" id="comment_submit" tabindex="6" value="提交"  class="button"></p>
  	<input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/>
  </form>
</div>	</div>	</div>	

	<?php endif; ?>
<?php }?>
<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>
<?php //文章缩略图获取
function get_imgsrc($str){
preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $str, $match);
if(!empty($match[1])){
 echo $match[1][0]; }else{
 echo TEMPLATE_URL . 'tpimg/cats.jpg'; } } ?>
 <?php
//分类标题
function sotrnamefromsid($sid){
global $CACHE; $sort_cache = $CACHE->readCache('sort');
foreach ($sort_cache as $key => $value) {
# code...
if($value["sid"]==$sid){ return $value["sortname"]; break;} } return "未分类"; } ?>
<?php //分类文章图文显示的方法1
function lanyou_tw($sort, $num){$db = Database::getInstance();
$sql = "SELECT gid,title,date,content,sortid,views,comnum FROM ".DB_PREFIX."blog WHERE sortid=".$sort." AND hide='n' ORDER BY `date` DESC LIMIT 0,$num";
$go = $db->query($sql);while($row = $db->fetch_array($go)){
$date = gmdate('Y-m-d', $row['date']);	
$img_url = TEMPLATE_URL.'tpimg/cats.jpg';//设置没有图片时的显示
if(pic_thumb($row['content'])){$img_url = pic_thumb($row['content']);//调用文章内容的第一张图片
}elseif(picthumb($row['gid'])){$img_url = picthumb($row['gid']);//调用附件的第一张图片
}else{$img_url;}?>
<li class="shop_main">
<a href="<?php echo Url::log($row['gid']);?>" title="<?php echo $row['title'];?>" rel="bookmark" class="shopthumb"><img src="<?php echo $img_url;?>" alt="<?php echo $row['title'];?>" original="<?php echo $img_url;?>" style="display: block;"></a>
<h3><a href="<?php echo Url::log($row['gid']);?>" title="<?php echo $row['title'];?>"><?php echo $row['title'];?></a></h3>
<p></p>
<div class="shop_btn">
<span class="price"><?php echo $date;?></span><a class="zzxq" href="<?php echo Url::log($row['gid']);?>"><i class="fa fa-chain"></i>查看详情</a>
</div></li>
<?php }}function picthumb($blogid) {$db = Database::getInstance();$sql = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$blogid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";$imgs = $db->query($sql);while($row = $db->fetch_array($imgs)){$pict.= ''.BLOG_URL.substr($row['filepath'],3,strlen($row['filepath'])).'';}return $pict;}function pic_thumb($content){preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $content, $img);$imgsrc = !empty($img[1]) ? $img[1][0] : '';if($imgsrc):return $imgsrc;endif;}?>
<?php //分类文章图文显示的方法2
function lanyou_tww($sort, $num){$db = Database::getInstance();
$sql = "SELECT gid,title,date,content,sortid,views,comnum FROM ".DB_PREFIX."blog WHERE sortid=".$sort." AND hide='n' ORDER BY `date` DESC LIMIT 0,$num";
$go = $db->query($sql);while($row = $db->fetch_array($go)){
$date = gmdate('Y-m-d', $row['date']);	
$img_url = TEMPLATE_URL.'tpimg/cats.jpg';//设置没有图片时的显示
if(pic_thumb($row['content'])){$img_url = pic_thumb($row['content']);//调用文章内容的第一张图片
}elseif(picthumb($row['gid'])){$img_url = picthumb($row['gid']);//调用附件的第一张图片
}else{$img_url;}?>
<li class="nbs-flexisel-item" style="width: 239.6px;">
<a href="<?php echo Url::log($row['gid']);?>"><img src="<?php echo $img_url;?>" alt="<?php echo $row['title'];?>" title="查看：<?php echo $row['title'];?>"></a></li> 	
<?php }}?>
<?php
//首先你要有读写文件的权限
//本程序可以直接运行,第一次报错,以缶涂梢?
$online_log = "count.dat"; //保存人数的文件,
$timeout = 30;//30秒内没动作者,认为掉线
$entries = file($online_log);
$temp = array();
for ($i=0;$i<count($entries);$i++) {
 $entry = explode(",",trim($entries[$i]));
 if (($entry[0] != getenv('REMOTE_ADDR')) && ($entry[1] > time())) {
  array_push($temp,$entry[0].",".$entry[1]."\n"); //取出其他浏览者的信息,并去掉超时者,保存进$temp
 }
}
array_push($temp,getenv('REMOTE_ADDR').",".(time() + ($timeout))."\n"); //更新浏览者的时间
$users_online = count($temp); //计算在线人数
$entries = implode("",$temp);
//写入文件
$fp = fopen($online_log,"w");
flock($fp,LOCK_EX); //flock() 不能在NFS以及其他的一些网络文件系统中正常工作
fputs($fp,$entries);
flock($fp,LOCK_UN);
fclose($fp);
?>	
<?php
//widget：TAG随机
function random_sj(){ 
$Log_Model = new Log_Model(); 
$randLogs = $Log_Model->getRandLog(9);$i=1;?>
<?php foreach($randLogs as $value): ?>
<li><span class="li-icon li-icon-<?php echo $i;?>"><?php echo $i;?></span><a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>" ><?php echo $value['title']; ?></a></li>
<?php $i++; endforeach; ?>
<?php }?>
<?php
//widget：TAG推荐
function random_tj(){ 
$Log_Model = new Log_Model(); 
$randLogs = $Log_Model->getHotLog(9);$i=1;?>
<?php foreach($randLogs as $value): ?>
<li><span class="li-icon li-icon-<?php echo $i;?>"><?php echo $i;?></span><a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>" ><?php echo $value['title']; ?></a></li>
<?php $i++; endforeach; ?>
<?php }?>
<?php
//时间代码 
function gettime($id){
	$db = Database::getInstance();
	$sql = 'SELECT * FROM ' . DB_PREFIX . "blog WHERE gid='".$id."'";
	$date = $db->query($sql);
	while ($row = $db->fetch_array($date)) {
		$time = date('Y-m-d',$row['date']);
	}
	return $time;
}?>
<?php
//获取附件第一张图片
function getThumbnail($blogid){
    $db = Database::getInstance();
    $sql = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$blogid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";
    //die($sql);
    $imgs = $db->query($sql);
    $img_path = "";
	if(mysqli_num_rows($imgs)){
		while($row = $db->fetch_array($imgs)){
			 $img_path .= BLOG_URL.substr($row['filepath'],3,strlen($row['filepath']));
		}
	}else{
		$img_path = false;
	}
    return $img_path;
}
//数据库报错用
function getimgforgid($gid){
    $db = Database::getInstance();
    $sql = 'SELECT content FROM ' . DB_PREFIX . "blog WHERE gid='".$gid."'";
	$d = $db->once_fetch_array($sql);

	return isset($d['content']) && preg_match("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $d['content'], $img) ? $img[1] : false;
}
//获取blog表的一条内容,$content填写表名
function blog_content($gid,$content){
    $db = Database::getInstance();
    $sql = 'SELECT * FROM ' . DB_PREFIX . "blog WHERE gid='".$gid."'";
    $sql = $db->query($sql);
    while ($row = $db->fetch_array($sql)) {
        $content = $row[$content];
	}
    return $content;
}
?>
<?php //获取QQ信息
function getqqtx($qq){
	$url="https://q.qlogo.cn/headimg_dl?bs=qq&amp;dst_uin=$qq&amp;src_uin=admin@92mo.cn&amp;fid=blog&amp;spec=100";
	return $url;}
if(isset($_POST['qq'])){
	if(empty($_POST['qq'])){
		echo "@@({comname:'QQ账号错误',commail:'QQ账号错误',comurl:'QQ账号错误',toux:'http://q.qlogo.cn/headimg_dl?bs=qq&dst_uin=admin@92mo.cn&src_uin=admin@92mo.cn&fid=blog&spec=100'})@@";
		return ;
	}
	$spurl = "https://r.pengyou.com/fcg-bin/cgi_get_portrait.fcg?uins={$_POST['qq']}";
	$data = file_get_contents($spurl);
	$nc=explode('"',$data);
	$s=$nc[5];
	$bm=mb_convert_encoding($s,'UTF-8','UTF-8,GBK,GB2312,BIG5');
	if(empty($bm)){echo "@@({comname:'QQ账号错误',commail:'QQ账号错误',comurl:'QQ账号错误',toux:'https://q.qlogo.cn/headimg_dl?bs=qq&dst_uin=admin@92mo.cn&src_uin=admin@92mo.cn&fid=blog&spec=100'})@@";}
else{echo "@@({comname:'{$bm}',commail:'{$_POST['qq']}@qq.com',comurl:'https://user.qzone.qq.com/{$_POST['qq']}',toux:'https://q.qlogo.cn/headimg_dl?bs=qq&dst_uin={$_POST['qq']}&src_uin=admin@92mo.cn&fid=blog&spec=100'})@@";}}
function getqqxx($qq,$role=''){
	if(!empty($role)){
		return $role;
	}
	$ssud=explode("@",$qq,2);
	if($ssud[1]=='qq.com'){
	return getqqtx($ssud[0]);
	}else{	
	return MyGravatar($qq,$role);	
}}
?>
<?php
//活跃读者挂载
function huoyue($num){global $CACHE; $user_cache = $CACHE->readCache('user'); $name = $user_cache[1]['name']; $DB = Database :: getInstance();
$sql = "SELECT count(*) AS comment_nums,poster,mail,url FROM ".DB_PREFIX."comment where date >0 and poster !='". $name ."' and  poster !='' and hide ='n' group by poster order by comment_nums DESC limit 0,$num";
$log_content = $content[1]; if(strpos($log_content, '[READERWALL-WEEK]') > -1) { $cur_time_span = strtotime('last Year',strtotime('Sunday')); }
$result = $DB -> query( $sql ); while($row = $DB -> fetch_array($result)){
$img = "<li><a href=\"" . $row[ 'url' ] . "\" title=\"" . $row[ 'poster' ] ."(" . $row[ 'comment_nums' ] . "次)\" target=\"_blank\" rel=\"external nofollow\"><img src=\"" . getqqtx($row['mail']) . "\" alt=\"" . $row[ 'poster' ] ."\"></a></li>";
if( $row[ 'url' ] ){
$tmp = "<li><a href=\"" . $row[ 'url' ] . "\" title=\"" . $row[ 'poster' ] ."(" . $row[ 'comment_nums' ] . "次)\" target=\"_blank\" rel=\"external nofollow\"><img src=\"" . getqqtx($row['mail']) . "\" alt=\"" . $row[ 'poster' ] ."\"></a></li>";
}else{ $tmp = $img; } $output .= $tmp; } $output = ''. $output .''; return $output ;} 
?>
<?php
//读者墙页面
function duzheq($num){global $CACHE; $user_cache = $CACHE->readCache('user'); $name = $user_cache[1]['name']; $DB = Database :: getInstance();
$sql = "SELECT count(*) AS comment_nums,poster,mail,url FROM ".DB_PREFIX."comment where date >0 and poster !='". $name ."' and  poster !='' and hide ='n' group by poster order by comment_nums DESC limit 0,$num";
$log_content = $content[1]; if(strpos($log_content, '[READERWALL-WEEK]') > -1) { $cur_time_span = strtotime('last Year',strtotime('Sunday')); }
$result = $DB -> query( $sql ); while($row = $DB -> fetch_array($result)){
$img = "<div class=\"like-post col-xs-6 col-sm-4 col-md-3\"><div class=\"like-post-box\">
<a href=\"" . $row[ 'url' ] . "\" rel=\"external nofollow\" target=\"_blank\"><div class=\"views\"><span class=\"sealik\">评论数 | </span><span class=\"count num\">" . $row[ 'comment_nums' ] . "条</span></div>
<div class=\"title\"><img class=\"lazy thumbnail\" style=\"float:left;\" src=\"" . getqqtx($row['mail']) . "\" ><h2>" . $row[ 'poster' ] ."</h2>
</div></a></div></div>";
if( $row[ 'url' ] ){
$tmp = "<div class=\"like-post col-xs-6 col-sm-4 col-md-3\"><div class=\"like-post-box\">
<a href=\"" . $row[ 'url' ] . "\" rel=\"external nofollow\" target=\"_blank\"><div class=\"views\"><span class=\"sealik\">评论数 | </span><span class=\"count num\">" . $row[ 'comment_nums' ] . "条</span></div>
<div class=\"title\"><img class=\"lazy thumbnail\" style=\"float:left;\" src=\"" . getqqtx($row['mail']) . "\" ><h2>" . $row[ 'poster' ] ."</h2>
</div></a></div></div>";
}else{ $tmp = $img; } $output .= $tmp; } $output = ''. $output .''; return $output ; } 
?>
<?php 
//分页函数
function tp_page($count,$perlogs,$page,$url,$anchor=''){
$pnums = @ceil($count / $perlogs);
$page = @min($pnums,$page);
$prepg=$page-1;
$nextpg=($page==$pnums ? 0 : $page+1);
$urlHome = preg_replace("|[\?&/][^\./\?&=]*page[=/\-]|","",$url);
$re = "<div class=\"page-list\">";
if($pnums<=1) return false;		
if($page!=1) $re .=" <a href=\"$urlHome$anchor\" title=\"首页\">‹‹</a>"; 
if($prepg) $re .="<a href=\"$url$prepg$anchor\" class=\"c-nav next ease\" title=\"上一页\" >←</a>";
for ($i = $page-2;$i <= $page+2 && $i <= $pnums; $i++){
if ($i > 0){if ($i == $page){$re .= "<a class=\"on\">$i</a>";
}elseif($i == 1){$re .= "<a href=\"$urlHome$anchor\">$i</a>";
}else{$re .= "<a href=\"$url$i$anchor\">$i</a>";}
}}
if($nextpg) $re .="<a href=\"$url$nextpg$anchor\" class=\"c-nav next ease\" title=\"下一页\" >→</a>"; 
if($page!=$pnums) $re.=" <a href=\"$url$pnums$anchor\" title=\"尾页\">››</a>";
$re .="<a>$pnums 页</a>";
$re .="</div>";
return $re;}
?>
<?php
// 判断内容页是否百度收录,并且以博主和或者理员身份访问博客文章时自动向百度提交未收录的文章
function baidu($url){
$url='http://www.baidu.com/s?wd='.$url;
$curl=curl_init();
curl_setopt($curl,CURLOPT_URL,$url);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
$rs=curl_exec($curl);
curl_close($curl);
if(!strpos($rs,'没有找到')){
return 1; }
else{ return 0; }   }
function checkbaidu($id){
$url=Url::log($id);
if(baidu($url)==1){  echo "<a style=\"color:#1EA83A;\" rel=\"external nofollow\" title=\"点击查看！\" target=\"_blank\" href=\"http://www.baidu.com/s?wd=$url\">[百度已收录]</a>";
} else { if (ROLE == 'admin' || ROLE == 'writer') { $urls = array($url,);
$api = 'http://data.zz.baidu.com/urls?site=www.92mo.cn&token=VMAFM80yQhH46KQ7';
$ch = curl_init();
$options =  array(
CURLOPT_URL => $api,
CURLOPT_POST => true,
CURLOPT_RETURNTRANSFER => true,
CURLOPT_POSTFIELDS => implode("\n", $urls),
CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),);
curl_setopt_array($ch, $options);
$result = curl_exec($ch);
echo '';}
echo "<a style=\"color:red;\" rel=\"external nofollow\" title=\"点击提交收录！\" target=\"_blank\" href=\"http://zhanzhang.baidu.com/sitesubmit/index?sitename=$url\">[百度未收录]</a>";} }?>

<?php
//comment：输出评论人等级
function echo_levels($comment_author_email,$comment_author_url){
	$DB = Database::getInstance();
	global $CACHE;
	$user_cache = $CACHE->readCache('user'); 
	$adminEmail = '"'.$user_cache[1]['mail'].'"';
	if($comment_author_email==$adminEmail){
		echo '神秘管理员';
	}
	$sql = "SELECT cid as author_count,mail FROM ".DB_PREFIX."comment WHERE mail != '' and mail = $comment_author_email and hide ='n'";
	$res = $DB->query($sql);
	$author_count = mysqli_num_rows($res);
	if($author_count>=0 && $author_count<5 && $comment_author_email!=$adminEmail)
		echo '路人';
	else if($author_count>=5 && $author_count<10 && $comment_author_email!=$adminEmail)
		echo '屌丝';
	else if($author_count>=10 && $author_count<20 && $comment_author_email!=$adminEmail)
		echo '男爵';
	else if($author_count>=20 && $author_count<30 && $comment_author_email!=$adminEmail)
		echo '子爵';
	else if($author_count>=30 &&$author_count<40 && $comment_author_email!=$adminEmail)
		echo '伯爵';
	else if($author_count>=40 && $author_coun<50 && $comment_author_email!=$adminEmail)
		echo '侯爵';
	else if($author_count>=50 && $author_coun<60 && $comment_author_email!=$adminEmail)
		echo '公爵';
	else if($author_count>=60 && $author_coun<70 && $comment_author_email!=$adminEmail)
		echo '亲王';
}
?>
<?php  
//自动标签内链
   function nltag($content ,$domain) {
            global $CACHE;  
            $tag_cache = $CACHE->readCache('tags');              
            foreach($tag_cache as $value){  
                $tag_url = Url::tag($value['tagurl']);  
                $keyword = $value['tagname'];  
                $cleankeyword = stripslashes($keyword);  
                $url = "<a href=\"{$tag_url}\" title=\"浏览关于“{$cleankeyword}”的文章\"  >{$cleankeyword}</a>";  
                $regEx = '\'(?!((<.*?)|(<a.*?)))('. $cleankeyword . ')(?!(([^<>]*?)>)|([^>]*?</a>))\'s';  
                $content = preg_replace($regEx,$url,$content);          
}  
return $content;  
}  
//代码压缩
function em_compress_html_main($buffer){
    $initial=strlen($buffer);
    $buffer=explode("<!--em-compress-html-->", $buffer);
    $count=count ($buffer);
    for ($i = 0; $i <= $count; $i++){
        if (stristr($buffer[$i], '<!--em-compress-html no compression-->')){
            $buffer[$i]=(str_replace("<!--em-compress-html no compression-->", " ", $buffer[$i]));
        }else{
            $buffer[$i]=(str_replace("\t", " ", $buffer[$i]));
            $buffer[$i]=(str_replace("\n\n", "\n", $buffer[$i]));
            $buffer[$i]=(str_replace("\n", "", $buffer[$i]));
            $buffer[$i]=(str_replace("\r", "", $buffer[$i]));
            while (stristr($buffer[$i], '  '))
            {
            $buffer[$i]=(str_replace("  ", " ", $buffer[$i]));
            }
        }
        $buffer_out.=$buffer[$i];
    }
    $final=strlen($buffer_out);
    $savings=($initial-$final)/$initial*100;
    $savings=round($savings, 2);
    $buffer_out.="\n<!--压缩前的大小: $initial bytes; 压缩后的大小: $final bytes; 节约：$savings% -->";
    return $buffer_out;
}

//pre不被压缩
function unCompress($content){
    if(preg_match_all('/(crayon-|<\/pre>)/i', $content, $matches)) {
        $content = '<!--em-compress-html--><!--em-compress-html no compression-->'.$content;
        $content.= '<!--em-compress-html no compression--><!--em-compress-html-->';
    }
    return $content;
}
//评论内容
function comcontent($pl) {
	$patterns = array ("/@/","/\[blockquote\](.*?)\[\/blockquote\]/","/\[F(([1-4]?[0-9])|50)\]/"); 
	$replace = array ('回复了','<blockquote>$1</blockquote>','<img alt="表情" src="'.TEMPLATE_URL.'top/face/$1.gif" />'); 
	$pl=preg_replace($patterns, $replace, $pl);
	return $pl;
}
//侧边栏评论
function sidecomcontent($pl) {
	$patterns = array ("/@/","/\[blockquote\](.*?)\[\/blockquote\]/","/\[F(([1-4]?[0-9])|50)\]/"); 
	$replace = array ('回复了','<small>$1</small>','<img alt="表情" src="'.TEMPLATE_URL.'top/face/$1.gif" />'); 
	$pl=preg_replace($patterns, $replace, $pl);
	return $pl;
}

//正则去除HTML
function ClearHtml($content) {  
   $preg = "/<\/?[^>]+>/i";
   return preg_replace($preg,'',$content);
}
?> 
<?php //内容页
function dyyinfo($logid){
	$db=Database::getInstance();
	$row=mysqli_fetch_array(mysqli_query("SELECT * FROM ".DB_PREFIX."blog WHERE gid =$logid"));
	if(img_zw($row['content'])){$imgurl = img_zw($row['content']);}elseif(img_fj($row['gid'])){$imgurl = img_fj($row['gid']);}else{$imgurl = TEMPLATE_URL.'img/random/'.rand(1,4).'.jpeg';}?>
<div class="dycondiv">
<div class="divboss dvd02 dvd01">
<div class="divwoot">
<div class="divomg divopg"><span class="dvd-img divboss dvd-x"><img src="<?php echo $imgurl;?>" original="<?php echo $imgurl;?>" alt="<?php echo $row['title'];?>"></span></div>
<div class="divomg divdoog"><div class="oppo-txt">
<ul class="dvd03">
<li><strong>标题：</strong><?php echo $row['title'];?></li>
<li><strong>分类：</strong><?php echo dy_sort($logid);?></li>
<li><strong>评论：</strong><?php echo $row['comnum'];?></li>
<li><strong>更新：</strong><?php echo gmdate('Y-n-j',$row['date']);?></li>
<li><strong>观看：</strong><?php echo $row['views'];?></li>
</ul>
</div>
</div>
</div>
</div>
<h6 class="post-title">简介</h6>
<p><?php echo ClearHtml($row['content']);?></p>
<h6 class="post-title">播放地址</h6>
<p>
<?php 
$strarr = explode("\n",$row['spdz']);
$i=1;
foreach ($strarr as $u){
$jishu=explode("*",$u);?>
<a class="dybutton" href="<?php echo '?ply='.$i++;?>"><?php echo $jishu[0];?></a>
<?php }?></p></div>
<?php } ?>
<?php //分类
function dy_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
<?php if(!empty($log_cache_sort[$blogid])): ?>
<a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>" title="<?php echo $log_cache_sort[$blogid]['name']; ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
<?php endif;?>
<?php }?>
<?php
function img_zw($content){preg_match_all("/<img.*src\s*=\s*[\"|\']?\s*([^>\"\'\s]*)/i",str_ireplace("\\","",$content),$imgsrc);return $imgsrc[1][0];}
function img_fj($logid){$db = Database::getInstance();$sql = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$logid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";$imgs = $db->query($sql);$img_path = "";while($row = $db->fetch_array($imgs)){$img_path .= BLOG_URL.substr($row['filepath'],3,strlen($row['filepath']));}
return $img_path;}?>