<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>	
<style type="text/css">
#shuoshuo_content{padding:10px;min-height:500px;}
body.theme-dark .cbp_tmtimeline::before{background:RGBA(255,255,255,.06)}
ul.cbp_tmtimeline{padding:0}
div class.cdp_tmlabel>li .cbp_tmlabel{margin-bottom:0}
.cbp_tmtimeline{position:relative;margin:30px 0 0 0;padding:0;list-style:none}
.cbp_tmtimeline:before{position:absolute;top:0;bottom:0;left:80px;margin-left:10px;width:4px;background:RGBA(0,0,0,.02);content:''}
.cbp_tmtimeline>li .cbp_tmtime{position:absolute;display:block;max-width:70px}
.cbp_tmtimeline>li .cbp_tmtime span{display:block;text-align:right}
.cbp_tmtimeline>li .cbp_tmtime span:first-child{color:#bdd0db;font-size:.9em}
.cbp_tmtimeline>li .cbp_tmtime span:last-child{color:#9BCD9B;font-size:1.2em}
.cbp_tmtimeline>li:nth-child(odd) .cbp_tmtime span:last-child{color:RGBA(255,125,73,.75)}
div.cbp_tmlabel>p{margin-bottom:0}
.cbp_tmtimeline>li .cbp_tmlabel{position:relative;display:block;margin:0 0 45px 65px;padding:.8em 1.2em .4em 1.2em;border-radius:5px;background:#9BCD9B;box-shadow:0 1px 2px rgba(0,0,0,.15);color:#fff;font-weight:300;line-height:1.4;cursor:pointer;transition:all .3s ease 0s}
.cbp_tmlabel:hover{z-index:1;-webkit-box-shadow:0 15px 32px rgba(0,0,0,.15)!important;transform:translateY(-3px)}
.cbp_tmtimeline>li:nth-child(odd) .cbp_tmlabel{background:RGBA(255,125,73,.75)}
.cbp_tmtimeline>li .cbp_tmlabel:after{position:absolute;top:4px;right:100%;width:0;height:0;border:solid transparent;border-width:10px;content:" ";pointer-events:none;border-right-color:#9BCD9B}
.cbp_tmtimeline>li:nth-child(odd) .cbp_tmlabel:after{border-right-color:RGBA(255,125,73,.75)}
p.shuoshuo_time{margin-top:10px;padding-top:5px;border-top:1px dashed #fff}
@media screen and (max-width:65.375em){.cbp_tmtimeline>li .cbp_tmtime span:last-child{font-size:1.2em}
}
.shuoshuo_author_img img{float:left;padding:2px;border:1px solid #ddd;border-radius:64px;transition:all 1s}
.avatar{-webkit-border-radius:100%!important;-moz-border-radius:100%!important;-webkit-box-shadow:inset 0 -1px 0 #3333sf;box-shadow:inset 0 -1px 0 #3333sf;-webkit-transition:.4s;-webkit-transition:-webkit-transform .4s ease-out;-moz-transition:-moz-transform .4s ease-out;transition:transform .4s ease-out}
.zhuan{-webkit-transform:rotateZ(720deg);-moz-transform:rotateZ(720deg);transform:rotateZ(720deg)}
</style>
<div class="container-fluid home-fluid">
<div class="site-content">
  <div class="site-main content-left">
<div class="widget-box">
 <div id="primary" class="content-area" style="">
    <main id="main" class="site-main" role="main">
        <div id="shuoshuo_content">
            <ul class="cbp_tmtimeline">
   <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
?> 
                <li> <span class="shuoshuo_author_img"><img src="<?php echo $avatar; ?>" class="avatar avatar-48" width="48" height="48"></span>
                    <a class="cbp_tmlabel" href="javascript:void(0)">
                        <p></p>
                        <p><?php echo $val['t'].'<br/>'.$img;?></p>
                        <p></p>
                        <p class="shuoshuo_time"><i class="fa fa-clock-o"></i>
						  <?php echo $val['date'];?>
						  <span onClick="javascript:loadr('<?php echo BLOG_URL; ?>t/?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">
							  <span>回复(<?php echo $val['replynum']; ?>)</span>
						  </span>
						</p>
						<?php if(Option::get('istreply') == 'y'){?>
						<div id="rp_<?php echo $tid;?>" style="display:none;">
						<textarea maxLength="140" style="width:100%;" id="rtext_<?php echo $tid; ?>" placeholder="回复内容"></textarea>
						<div>
								<div style="display:<?php if(ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER){echo 'none';}?>">
								<input placeholder="昵称" type="text" id="rname_<?php echo $tid; ?>" value="" />
								<span style="display:<?php if($reply_code == 'n'){echo 'none';}?>"><input placeholder="验证码" type="text" id="rcode_<?php echo $tid; ?>" value="" /><?php echo $rcode; ?></span>
								</div>
								<input type="button" onclick="reply('<?php echo BLOG_URL."t/"; ?>index.php?action=reply',<?php echo $tid;?>);" value="回复" style="border:none;background:#fff;" /> 
								<span id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></span>
						</div>
						</div>
						<?php }?>
						<div class="media-list" id="r_<?php echo $tid;?>" style="display:none;"></div>
                    </a>
                     <?php endforeach;?>
                </li>
            </ul>
        </div>
  <div id="comments-nav" class="pagination wow fadeInDown"><div class="page-list"><?php echo $pageurl;?></div></div>				
    </main>
    <!-- .site-main -->	
</div>
</div>      </div>
<?php include View::getView('side2');?>
</div><div class="clear"></div>
</div>

<?php include View::getView('footer'); ?>
