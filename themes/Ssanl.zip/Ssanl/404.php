<?php 
/**
 * 自定义404页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
include View::getView('header');
?>
<script>
document.title = "404 抱歉页面不存在或被删除"
</script>

<div class="container-fluid home-fluid">
  <div class="site-content primary error">
    <div class="content4 widget-box">
      <header id="post-header">
        <h1 class="post-title">
          <a href="<?php echo BLOG_URL; ?>" title="Error:404-您访问的页面不存在或已删除！" rel="bookmark">Error:404-您访问的页面不存在或已删除！</a></h1>
      </header>
      <div class="error_content">
        <div class="error_left">
          <span class="sp_con">赶紧修，大家等着呢。</span></div>
        <div class="error_right">
          <div class="error_detail">
            <p class="error_p_title">哎呦~ 服务器居然累倒了!</p>
            <p class="error_p_con">● 别急，工程师正在紧急处理，马上就好。</p>
            <p class="error_p_con">● 您可联系站长QQ/微信：<a target="blank" rel="nofollow" href="tencent://message/?uin=<?php echo $txurl; ?>&amp;Site=&amp;Menu=yes" title="QQ临时对话"><?php echo $txurl; ?></a>,通知网站开发人员!</p>
            <p class="error_p_con">● Ssanl主题的进步需要您的反馈,感谢您对我们的支持,请您耐心等待!</p></div>
          <div class="btn_error">
            <a class="btn_back1" href="<?php echo BLOG_URL; ?>">返回首页</a>
      
            <a class="btn_back2" href="javascript:history.back(-1);">返回上一页</a></div>
        </div>
        <div class="clear"></div>

      </div>
    </div>
  </div><div class="clear"></div>
</div>
<?php include View::getView('footer');?>
