<?php 
/**
 * 站点首页模板
 */
 if(!defined('EMLOG_ROOT')) {exit('error!');} 
if($pageurl == Url::logPage()){include View::getView('index');exit;}
$sort_img = explode(",",$img_id);
if(in_array($sortid,$sort_img)){include View::getView('log_img');exit;}
?>
<div class="container-fluid home-fluid">
<div class="site-content">
<nav class="navcates">当前位置：<i class="fa fa-home"></i><a href="<?php echo BLOG_URL; ?>">首页</a><i class="fa fa-angle-right"></i><?php if ($params[1]=='sort'){ ?><?php echo $sortName;?><?php }?> </nav>
<?php doAction('index_loglist_top'); ?>
<div class="site-main">
<!--文章列表-->
<div class="widget-box blog-layout">
<div class="post_box_title"><h3><i class="fa fa-twitch"></i><?php if ($params[1]=='sort'){ ?><?php echo '<a href="'.Url::sort($sortid).'">'.$sortName.'</a>';?><?php }?></h3></div>
<?php 
if (!empty($logs)): foreach($logs as $value):
//去除文章摘要的“阅读全文” 
$value['log_description'] = strip_tags($value['log_description']); $value['log_description'] = str_replace('阅读全文&gt;&gt;','',$value['log_description']);
//去除默认分页的首页和尾页
$page_url = str_replace('&laquo;','首页',$page_url); $page_url = str_replace('&raquo;','尾页',$page_url);?>	
<article class="post_box" id="post_box1">
<div class="readMore-date"><div class="corner-date"></div><?php echo gmdate('Y-n-j', $value['date']); ?></div>
<div class="post-img col-xs-4">
<a href="<?php echo $value['log_url']; ?>"><img class="img-responsive img-rounded imgs" src="<?php get_imgsrc($value['content']);?>" alt="<?php echo $value['log_title']; ?>" title="详细阅读：<?php echo $value['log_title']; ?>" original="<?php get_imgsrc($value['content']);?>"></a></div>
<header class="entry-header">
<h2 class="entry-title"><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?>
<?php if(((date('Ymd',time())-date('Ymd',$value['date']))< 1)&&($value['top']=='n')){?><img src="/content/templates/Ssanl/tpimg/new.gif"><?php }elseif($value['views']>=150){?><img src="/content/templates/Ssanl/tpimg/hot.gif"><?php }?>
</a></h2>		
</header>
<div class="post-left">
<div class="post-con"><?php echo $value['log_description']; ?>...</div>
<div class="item-meta">
<span class="mu-ml"><i class="fa fa-list-alt"></i><?php blog_sort($value['logid']); ?></span>
<span class="mu-ml-eye"><i class="fa fa-paw"></i><?php echo $value['views']; ?>次浏览</span>
<span class="mu-ml-comment"><i class="fa fa-comment"></i><a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?>条评论</a></span>
</div>
<div class="readMore"><a href="<?php echo $value['log_url']; ?>" rel="nofollow" title="详细阅读：<?php echo $value['log_title']; ?>">阅读全文</a></div>
</div><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?></article>
<?php endforeach;else:?>   
<h2>未找到</h2> <p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?></div>
<!--页码-->
<div class="pagination"><?php echo tp_page($lognum,$index_lognum,$page,$pageurl);?></div></div>
<!--侧栏-->
<?php include View::getView('side');?>
</div><div class="clear"></div>
</div>
<?php include View::getView('footer');?>