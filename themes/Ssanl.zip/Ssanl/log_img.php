<?php 
/**
 * 图片列表模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>

<div class="waterfall-show">
<div class="imgcon imgrid centimg">
<ul>
<?php if (!empty($logs)):foreach($logs as $value):?>
<li>
<div class="itemm">
<div class="thumcb">
<a target="_blank" href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>">
<img src="<?php get_imgsrc($value['content']);?>"  alt="<?php echo $value['log_title']; ?>">
</a>
</div>
 <div class="metata">
 <div class="title">
 <h2><a target="_blank" href="<?php echo $value['log_url']; ?>" rel="bookmark" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></h2>
 </div>
<div class="extrabc">
<i class="fa fa-bookmark"></i><?php blog_sort($value['logid']); ?><span><?php echo $value['views']; ?><i class="fa fa-fire"></i></span>
</div>             
</div>
<div class="data">
<time class="time"><?php echo gmdate('Y-n-j', $value['date']); ?></time>
 <span><a href="<?php echo $value['log_url']; ?>#comments"><i class="fa fa-comment"></i><?php echo $value['comnum']; ?></a></span>
<span><i class="fa fa-heart"></i><?php echo $value['views']; ?></span>
      </div>
  </div>
</li>	
<?php endforeach;else:?>  
</ul>	
<h2>未找到</h2> <p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
   <div class="pagebar">
<?php echo tp_page($lognum,$index_lognum,$page,$pageurl);?></div>
</div></div>
<div class="clear"></div>
<?php include View::getView('footer');?>