<?php
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
  'sort_keywords' => array(
		'type' => 'text',
		'name' => '分类页面关键词设置',
		'values' => array(
			'请填写关键词',
		),
		'depend' => 'sort',
		'description' => '左侧选择分类，在输入框中输入分类关键词。',
	)
);

