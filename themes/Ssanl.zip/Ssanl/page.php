<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="container-fluid home-fluid">
<div class="site-content">
  <div class="site-main content-left">
          <div class="widget-box">
<article id="post" class="widget-content single-post">
  <header id="post-header">
    <div class="post-meta">
      <span class="time"><?php echo gmdate('Y-n-j', $date); ?></span>
      <span class="eye"><i class="fa fa-eye"></i><?php echo $views; ?></span>
      <span class="comm"><a href="<?php echo $value['log_url']; ?>"><i class="fa fa-comment-o"></i><?php echo $comnum; ?></a></span>
      <span class="r-hide"><a title="侧边栏"><i class="fa fa-caret-left"></i><i class="fa fa-caret-right"></i></a></span>
    </div>
    <div id="font-change" class="left">
      <span id="font-dec"><a href="<?php echo $value['log_url']; ?>##" title="减小字体">-</a></span>
      <span id="font-n"><a href="<?php echo $value['log_url']; ?>##" title="默认大小">N</a></span>
      <span id="font-inc"><a href="<?php echo $value['log_url']; ?>##" title="增大字体">+</a></span>
          </div>
    <h2 class="post-title"><a href="<?php echo $value['log_url']; ?>#" title="正在阅读：<?php echo $log_title; ?>" rel="bookmark"><?php echo $log_title; ?></a></h2>
    <div class="clear"></div>
  </header>
 <div class="entry">
<?php echo $log_content; ?>
</div>
    <section id="comments">  
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>

<?php blog_comments($comments); ?>
<label id="AjaxCommentEnd"></label>
<!--评论翻页条输出结束-->
    <span class="icon icon_comment" title="comment"></span>
  </section>
</article>
</div>      </div>
<?php include View::getView('side2');?>
</div><div class="clear"></div>
</div>
<?php include View::getView('footer');?>