<div id="backtop" class="backtop"><div class="bt-box tnrt"><a href="javascript:translatePage();" id="zh_big">繁</a></div>
<div class="bt-box weixin"><i class="fa fa-weixin fa-2x"></i><img class="pic" src="<?php echo $wxurl; ?>" alt="微信二维码"></div>
<div class="bt-box top" style="display: none;"><i class="fa fa-angle-up fa-2x"></i></div></div>
<?php doAction('index_footer'); ?>
<div class="search-form">
<form method="get" action="<?php echo BLOG_URL; ?>index.php" name="search" role="search">       
<div class="search-form-inner"><div class="search-form-box">
<input class="form-search" type="text" name="keyword" placeholder="键入搜索关键词">
<button type="submit" id="btn-search"><i class="fa fa-search"></i> </button></div>
<div class="search-commend"><h4>大家都在搜</h4>
<ul><?php search_tag($title); ?></ul></div></div></form> 
<div class="close-search">
<span class="close-top"></span><span class="close-bottom"></span></div></div>
<script src="<?php echo TEMPLATE_URL; ?>js/lanyou.js" type='text/javascript'></script>
<div class="none">
<script type="text/javascript">var defaultEncoding="2";var translateDelay="50";var cookieDomain="<?php echo BLOG_URL; ?>";var msgToTraditionalChinese="<b>繁</b>";var msgToSimplifiedChinese="<b>简</b>";var translateButtonId="zh_big";</script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/zh_big.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/custom.js"></script>
<script>POWERMODE.colorful = true;POWERMODE.shake = false;document.body.addEventListener("input", POWERMODE);</script>
<script type="text/javascript">var swiper = new Swiper('.swiper-home', {pagination:'.swiper-home-pagination',nextButton:'.swiper-home-button-next',prevButton:'.swiper-home-button-prev',paginationClickable:true,centeredSlides:true,autoplay:5000,autoplayDisableOnInteraction:false,lazyLoading:true,mousewheelControl:false,keyboardControl:true,loop:true});</script>
<script>var wow = new WOW({boxClass:'wow',animateClass:'animated',offset:0,mobile:true,live:true});wow.init();translateInitilization();</script>
</div><canvas width="1440" height="745" style="position: fixed; top: 0px; left: 0px; pointer-events: none; z-index: 999999;"></canvas>
<div class="usercm"><ul>
<li><a href="javascript:void(0);" onclick="getSelect();"><i class="fa fa-clipboard fa-fw"></i><span>复制文字</span></a></li>
<li><a href="javascript:window.location.reload();"><i class="fa fa-refresh fa-fw"></i><span>刷新页面</span></a></li>
<li><a href="javascript:history.go(1);"><i class="fa fa-arrow-right fa-fw"></i><span>前进一页</span></a></li>
<li><a href="javascript:history.go(-1);"><i class="fa fa-arrow-left fa-fw"></i><span>后退一页</span></a></li>
<li><a href="javascript:void(0);"  onclick="baiduSearch();"><i class="fa fa-paw fa-fw"></i><span>百度搜索</span></a></li>
<li><a href="https://www.baidu.com/s?wd=东轩博客" rel="nofollow" target="_blank" ><i class="fa fa-search"></i><span>东轩博客</span></a></li>
</ul></div>
<script>(function(){
var src = (document.location.protocol == "http:") ? "http://js.passport.qihucdn.com/11.0.1.js?0f37d648fa20b7b5e130a9f2f1719465":"https://jspassport.ssl.qhimg.com/11.0.1.js?0f37d648fa20b7b5e130a9f2f1719465";
document.write('<script src="' + src + '" id="sozz"><\/script>');
})();
</script>