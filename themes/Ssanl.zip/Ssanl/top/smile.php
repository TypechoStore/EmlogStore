<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<img src="<?php echo TEMPLATE_URL; ?>top/face/1.gif" title="囧" alt="囧" onclick="InsertText(objActive,&#39;[F1]&#39;,false);" >
<img src="<?php echo TEMPLATE_URL; ?>top/face/2.gif" title="亲" alt="亲" onclick="InsertText(objActive,&#39;[F2]&#39;,false);" >
<img src="<?php echo TEMPLATE_URL; ?>top/face/3.gif" title="晕" alt="晕" onclick="InsertText(objActive,&#39;[F3]&#39;,false);" >
<img src="<?php echo TEMPLATE_URL; ?>top/face/4.gif" title="酷" alt="酷" onclick="InsertText(objActive,&#39;[F4]&#39;,false);" >
<img src="<?php echo TEMPLATE_URL; ?>top/face/5.gif" title="哭" alt="哭" onclick="InsertText(objActive,&#39;[F5]&#39;,false);" >
<img src="<?php echo TEMPLATE_URL; ?>top/face/6.gif" title="馋" alt="馋" onclick="InsertText(objActive,&#39;[F6]&#39;,false);" >
<img src="<?php echo TEMPLATE_URL; ?>top/face/7.gif" title="闭嘴" alt="闭嘴" onclick="InsertText(objActive,&#39;[F7]&#39;,false);" >
<img src="<?php echo TEMPLATE_URL; ?>top/face/8.gif" title="调皮" alt="调皮" onclick="InsertText(objActive,&#39;[F8]&#39;,false);" >
<img src="<?php echo TEMPLATE_URL; ?>top/face/9.gif" title="馋" alt="馋" onclick="InsertText(objActive,&#39;[F9]&#39;,false);" >
<img src="<?php echo TEMPLATE_URL; ?>top/face/10.gif" title="奸" alt="奸" onclick="InsertText(objActive,&#39;[F10]&#39;,false);" >
<img src="<?php echo TEMPLATE_URL; ?>top/face/11.gif" title="怒" alt="怒" onclick="InsertText(objActive,&#39;[F11]&#39;,false);" >
<img src="<?php echo TEMPLATE_URL; ?>top/face/12.gif" title="笑" alt="笑" onclick="InsertText(objActive,&#39;[F12]&#39;,false);" >
<img src="<?php echo TEMPLATE_URL; ?>top/face/13.gif" title="羞" alt="羞" onclick="InsertText(objActive,&#39;[F13]&#39;,false);" >
<img src="<?php echo TEMPLATE_URL; ?>top/face/14.gif" title="汗" alt="汗" onclick="InsertText(objActive,&#39;[F14]&#39;,false);" >
<img src="<?php echo TEMPLATE_URL; ?>top/face/15.gif" title="色" alt="色" onclick="InsertText(objActive,&#39;[F15]&#39;,false);" >
<img src="<?php echo TEMPLATE_URL; ?>top/face/16.gif" title="萌" alt="萌" onclick="InsertText(objActive,&#39;[F16]&#39;,false);" >
<img src="<?php echo TEMPLATE_URL; ?>top/face/17.gif" title="可怜" alt="可怜" onclick="InsertText(objActive,&#39;[F17]&#39;,false);" >
<img src="<?php echo TEMPLATE_URL; ?>top/face/18.gif" title="快哭了" alt="快哭了" onclick="InsertText(objActive,&#39;[F18]&#39;,false);" >
<img src="<?php echo TEMPLATE_URL; ?>top/face/19.gif" title="呆" alt="呆" onclick="InsertText(objActive,&#39;[F19]&#39;,false);" >
<img src="<?php echo TEMPLATE_URL; ?>top/face/20.gif" title="吓" alt="吓" onclick="InsertText(objActive,&#39;[F20]&#39;,false);" >
<img src="<?php echo TEMPLATE_URL; ?>top/face/21.gif" title="大笑" alt="大笑" onclick="InsertText(objActive,&#39;[F21]&#39;,false);" >

