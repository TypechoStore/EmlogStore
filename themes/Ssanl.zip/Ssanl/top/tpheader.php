<link href="<?php echo TEMPLATE_URL; ?>css/animate.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>css/sh_style.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>css/style.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>css/92mo.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<style type="text/css">#hottags ul li{margin-bottom:12px;}#readers ul{padding:2px 8px 5px;}span.ttcolor{border-bottom:2px solid #2F889A;padding-bottom:6px;}.ad{padding: 5px 0;}.single-ad{padding: 10px 0;}#hottags ul.hottags {margin: 10px 0px 0px 13px;}</style>
<script src="<?php echo TEMPLATE_URL; ?>js/fb.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/flexisel.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/swiper.min.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/common_tpl.js" type="text/javascript"></script>
<?php if($log_listpax=='1'){?><script src="<?php echo TEMPLATE_URL; ?>js/script.js" type='text/javascript'></script><?php }?>
<script src="//msite.baidu.com/sdk/c.js?appid=1586759269185909" type="text/javascript"></script>
<!--[if lte IE 7]><link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>/js/font-awesome-ie7.min.css"><![endif]-->
<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
<?php doAction('index_head'); ?>