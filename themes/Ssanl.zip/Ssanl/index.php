<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
if(isset($_GET["setting"])){include View::getView('setting');exit();}
?>
<div class="container-fluid home-fluid">
<div class="site-content">
<nav class="gonggao navcates"><div class="bull"><i class="fa fa-volume-up"></i></div>
<div id="callboard"><ul class="menu" style="margin-top: 0px;">
<?php global $CACHE;$newtws_cache = $CACHE->readCache('newtw');
foreach($newtws_cache as $value):
$img = empty($value['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" target="_blank"><i class="icon-image"></i></a>';?>
<li><a href="<?php echo BLOG_URL.'t';?>"><?php echo preg_replace("/\[F(([1-4]?[0-9])|50)\]/",'<img alt="face" src="'.TEMPLATE_URL.'img/face/$1.gif"  />',$value['t']);echo $img;echo date('（Y年n月j日）',$value['date']);?></a></li>
<?php endforeach; ?>           
</ul></div></nav>
<div class="site-main">
<!--幻灯片-->
<div class="content-wrap left">
<div class="slide-main">
<?php if($Slide== 1 ){ ?>
<div class="swiper-container swiper-home swiper-container-horizontal">
<div class="swiper-wrapper">
<article class="swiper-slide slide-single swiper-slide-duplicate" data-swiper-slide-index="2" style="width: 873px;">
<div class="swiper-image"><a href="<?php echo $Surl1?>" title="幻图1" ><img src="<?php echo $Slide1 ?  $Slide1 : ''.TEMPLATE_URL."tpimg/hdp/h1.jpg";?>" alt="幻图1"></a></div>
</article>
<article class="swiper-slide slide-single" data-swiper-slide-index="0" style="width: 873px;">
<div class="swiper-image"><a href="<?php echo $Surl2?>" title="幻图2" ><img src="<?php echo $Slide2 ?  $Slide2 : ''.TEMPLATE_URL."tpimg/hdp/h1.jpg";?>" alt="幻图2"></a></div>
</article>
<article class="swiper-slide slide-single" data-swiper-slide-index="1" style="width: 873px;">
<div class="swiper-image"><a href="<?php echo $Surl3?>" title="幻图3" ><img src="<?php echo $Slide3 ?  $Slide3 : ''.TEMPLATE_URL."tpimg/hdp/h1.jpg";?>" alt="幻图3"></a></div>
</article>
<article class="swiper-slide slide-single swiper-slide-prev" data-swiper-slide-index="2" style="width: 873px;">
<div class="swiper-image"><a href="<?php echo $Surl1?>" title="幻图1" ><img src="<?php echo $Slide1 ?  $Slide1 : ''.TEMPLATE_URL."tpimg/hdp/h1.jpg";?>" alt="幻图1"></a></div>
</article>  
<article class="swiper-slide slide-single swiper-slide-duplicate swiper-slide-active" data-swiper-slide-index="0" style="width: 873px;">
<div class="swiper-image"><a href="<?php echo $Surl2?>" title="幻图2" ><img src="<?php echo $Slide2 ?  $Slide2 : ''.TEMPLATE_URL."tpimg/hdp/h1.jpg";?>" alt="幻图2"></a></div>
</article></div>
<div class="swiper-pagination swiper-home-pagination swiper-pagination-clickable"><span class="swiper-pagination-bullet swiper-pagination-bullet-active"></span><span class="swiper-pagination-bullet"></span><span class="swiper-pagination-bullet"></span></div>
<div class="swiper-button swiper-home-button-next swiper-button-next"><i class="fa fa-chevron-right"></i></div>
<div class="swiper-button swiper-home-button-prev swiper-button-prev"><i class="fa fa-chevron-left"></i></div>
</div><?php }?></div></div>
<?php doAction('index_loglist_top'); ?>
<section class="widget-box home-layout">
<?php if (!empty($logs)):
$logs=array_slice($logs,0,$index_mnum);
foreach($logs as $key=>$value): 
//去除文章摘要的“阅读全文”
$value['log_description'] = strip_tags($value['log_description']); $value['log_description'] = str_replace('阅读全文&gt;&gt;','',$value['log_description']);
//去除默认分页的首页和尾页
$page_url = str_replace('&laquo;','首页',$page_url); $page_url = str_replace('&raquo;','尾页',$page_url);?>	 
<article class="post_box" id="post_box1">
<div class="readMore-date"><div class="corner-date"></div><?php echo gmdate('Y-n-j', $value['date']); ?></div>
<div class="post-img col-xs-4">
<a href="<?php echo $value['log_url']; ?>"><img class="img-responsive img-rounded imgs" src="<?php get_imgsrc($value['content']);?>" alt="<?php echo $value['log_title']; ?>" title="详细阅读：<?php echo $value['log_title']; ?>" original="<?php get_imgsrc($value['content']);?>"></a></div>
<header class="entry-header">
<h2 class="entry-title"><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?>
<?php if(((date('Ymd',time())-date('Ymd',$value['date']))< 1)&&($value['top']=='n')){?><img src="<?=BLOG_URL;?>content/templates/Ssanl/tpimg/new.gif"><?php }elseif($value['views']>=200){?><img src="<?=BLOG_URL;?>content/templates/Ssanl/tpimg/hot.gif"><?php }?>
</a></h2>		
</header>
<div class="post-left">
<div class="post-con"><?php echo $value['log_description']; ?>...</div>
<div class="item-meta">
<span class="mu-ml"><i class="fa fa-list-alt"></i><?php blog_sort($value['logid']); ?></span>
<span class="mu-ml-eye"><i class="fa fa-paw"></i><?php echo $value['views']; ?>次浏览</span>
<span class="mu-ml-comment"><i class="fa fa-comment"></i><a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?>条评论</a></span>
</div>
<div class="readMore"><a href="<?php echo $value['log_url']; ?>" rel="nofollow" title="详细阅读：<?php echo $value['log_title']; ?>">阅读全文</a></div>
</div><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?></article>
<?php endforeach;else:?> 
</section>
<h2>未找到</h2><p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
<!--页码-->
<div class="pagination"><?php echo tp_page($lognum,$index_lognum,$page,$pageurl);?></div>
<section class="home_shop shadow-box wow fadeInDown">
<h2><i class="fa fa-list-ul"></i><a href="<?php echo Url::sort($index_cid); ?>" class="shop_button" title="查看更多"><?php echo sotrnamefromsid($index_cid);?></a></h2>    
<ul><?php lanyou_tw($index_cid,3);?></ul>
</section>
<!-- cms开始 -->
<?php
if ($pageurl == Url::logPage()) {
$db = Database::getInstance();
global $CACHE;
global $arr_sortico1;
$sort_cache = $CACHE->readCache('sort');
$sort_id = array_unique(explode(',', trim($cms_cid)));
$out = "<div class='cms'>";
foreach ($sort_id as $key => $i) {
$out .= "<article class='cms-cate shadow-box wow fadeInDown'data-wow-delay='0.3s'>
<div class='cms-main'><h3 class='cms-title'><i class='".$arr_sortico1[$i]."'></i><a href='".Url::sort($i)."' rel='category'>".$sort_cache[$i]['sortname']."</a>
<a class='cat-angle' href='".Url::sort($i)."' rel='category'></a></h3><div class='clear'></div><div class='cms-post'>  <ul class='cms-grid'>";
$logss = $db->query('SELECT * FROM ' . DB_PREFIX . "blog WHERE sortid='{$i}' AND type='blog' AND hide='n' order by date DESC limit 0,8");
while($trow = $db->fetch_array($logss)) {;
$date = gmdate('m月d日', $trow['date']);
$trow['title'] = mb_substr($trow['title'], 0, 23, 'utf-8');
$url = Url::log($trow['gid']);
$out .= "<li class=\"list-date\">{$date}</li><li class=\"list-title\"><i class=\"fa fa-angle-right\"></i><a href=\"{$url}\" rel='bookmark' title=\"{$trow['title']}\">{$trow['title']}</a></li> ";
}
$out .= "</ul></div></div></article>";
}
$out .= "</div>";
echo $out;
};
?>
<!-- cms结束 -->
</div>
<!--侧栏-->
<?php include View::getView('side');?>
</div><div class="clear"></div>
<div class="fluid-box shadow-box wow fadeInDown" data-wow-delay="0.3s">
<h3 class="showcase-title"><i class="fa fa-bars"></i>&nbsp;&nbsp;<a href="<?php echo Url::sort($lunfan_cid); ?>" rel="category"><?php echo sotrnamefromsid($lunfan_cid);?></a></h3>
<div class="nbs-flexisel-container"><div class="nbs-flexisel-inner">
<ul id="flexisel" class="nbs-flexisel-ul">
<?php lanyou_tww($lunfan_cid,10);?>
</ul></div>
<div class="clear"></div></div>
<div class="clear"></div></div></div>
<?php if($sylinks=='1'){?>
<div class="container-fluid links  wow fadeInDown">
<div class="sec-panel topic-recommend shadow-box">
<div class="sec-panel-head"><h2><a href="<?php echo BLOG_URL; ?>links.html"   title="友联申请">友联申请</a></h2></div>
<div class="sec-panel-body list-links"><ul>
<?php global $CACHE;$link_cache = $CACHE->readCache('link');$link_cache = array_slice($link_cache,0,35);foreach($link_cache as $value): ?>			
<li><a href="<?php echo $value['url']; ?>" target="_blank" title="<?php echo $value['des']; ?>"><?php echo $value['link']; ?></a></li>
<?php endforeach; ?></ul></div></div></div><?php }?>
<?php include View::getView('footer');?>