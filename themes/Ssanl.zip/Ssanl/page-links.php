<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="container-fluid home-fluid">
  <div class="site-content primary error">
    <div class="content4 widget-box">
<header id="link-header">
<h2 class="link-title"><a href="<?php echo $value['log_url']; ?>" title="<?php echo $log_title; ?>" rel="bookmark"><?php echo $log_title; ?></a></h2>
</header>
<div class="linkcontent">
<?php echo $log_content; ?>
</div>
<ul class="link-list">
<?php 
global $CACHE;
$link_cache = $CACHE->readCache('link');
foreach($link_cache as $value): ?>	
<li><a target="_blank" href="<?php echo $value['url']; ?>"  title="<?php echo $value['des']; ?>" target="_blank" ><img alt="" src="<?php echo TEMPLATE_URL; ?>favicon/fav.php?url=<?php echo $value['url']; ?>" class="avatar avatar-36 photo" height="36" width="36"><em><?php echo $value['link']; ?></em> <address>描述：<?php echo $value['des']; ?></address></a></li>
<?php endforeach; ?>
</ul>  
<div class="clear"></div>
    <section id="comments">  
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<?php blog_comments($comments); ?>
<label id="AjaxCommentEnd"></label>
<!--评论翻页条输出结束-->
    <span class="icon icon_comment" title="comment"></span>
  </section>
    </div>
 </div><div class="clear"></div>
</div>
<?php include View::getView('footer');?>
