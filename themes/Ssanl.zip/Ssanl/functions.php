<?php
/*
 * @des 主题控制中心
 * Tadpole.theme by 东轩
 */
if(!defined('EMLOG_ROOT')) {exit('Ssanl Functions Requrire Emlog!');}
function d($str){
	$str = str_replace("'","\'",$str );
	return $str;
}


function plugin_setting(){
	$do = isset($_GET['do']) ? $_GET['do'] : '';
    if($do == 'save') {
		if(empty($_POST)){
                emMsg("修改失败，请重试！");
			return ;
		}
		//处理上传的图片
		if ($_FILES['logo']['error'] != 4) {
			$logo = $_FILES['logo']['tmp_name'];
			$logopath = '/content/templates/Ssanl/tpimg/logo.png';
			$a = move_uploaded_file($logo, EMLOG_ROOT .'/'.$logopath);
			$logo = BLOG_URL.$logopath;
		}else{
			$logo = isset($_POST['logo']) ? d(trim($_POST['logo'])) : '';
		}
		 $yxsjdate = $_POST['yxsjdate'];
		 $arr_navico = $_POST['arr_navico'];
		 $arr_sortico = $_POST['arr_sortico'];
		 $Slide = isset($_POST['Slide']) ? d(trim($_POST['Slide'])) : '';
		 $Slide1 = isset($_POST['Slide1']) ? d(trim($_POST['Slide1'])) : '';
		 $Surl1 = isset($_POST['Surl1']) ? d(trim($_POST['Surl1'])) : '';
		 $Slide2 = isset($_POST['Slide2']) ? d(trim($_POST['Slide2'])) : '';
		 $Surl2 = isset($_POST['Surl2']) ? d(trim($_POST['Surl2'])) : '';
		 $Slide3 = isset($_POST['Slide3']) ? d(trim($_POST['Slide3'])) : '';
		 $Surl3 = isset($_POST['Surl3']) ? d(trim($_POST['Surl3'])) : '';
		 $index_mnum = isset($_POST['index_mnum']) ? d(trim($_POST['index_mnum'])) : '';
		 $index_cid = isset($_POST['index_cid']) ? d(trim($_POST['index_cid'])) : '';
		 $cms_cid = isset($_POST['cms_cid']) ? d(trim($_POST['cms_cid'])) : '';
		 $img_id = isset($_POST['img_id']) ? d(trim($_POST['img_id'])) : '';
		 $lunfan_cid = isset($_POST['lunfan_cid']) ? d(trim($_POST['lunfan_cid'])) : '';
		 $wxurl = isset($_POST['wxurl']) ? d(trim($_POST['wxurl'])) : '';
		 $txurl = isset($_POST['txurl']) ? d(trim($_POST['txurl'])) : '';
		 $xlurl = isset($_POST['xlurl']) ? d(trim($_POST['xlurl'])) : '';
		 $tbaiduapi = isset($_POST['tbaiduapi']) ? d(trim($_POST['tbaiduapi'])) : '';
		 $log_listpax = isset($_POST['log_listpax']) ? d(trim($_POST['log_listpax'])) : '';
		 $sylinks = isset($_POST['sylinks']) ? d(trim($_POST['sylinks'])) : '';
		 $compress_html = isset($_POST['compress_html']) ? d(trim($_POST['compress_html'])) : '';
		 $dy_id = isset($_POST['dy_id']) ? d(trim($_POST['dy_id'])) : '';
		 $dy_jk = isset($_POST['dy_jk']) ? d(trim($_POST['dy_jk'])) : '';
		 $more = isset($_POST['more']) ? d(trim($_POST['more'])) : '';
		 $more_html = isset($_POST['more_html']) ? d(trim($_POST['more_html'])) : '';
		 $cachedata = "<?php
	\$logo = '".$logo."';	 
	\$bgimg = '".$bgimg."';
	\$yxsjdate = '".$yxsjdate."';
	\$arr_navico = '".serialize($arr_navico)."';
	\$arr_sortico = '".serialize($arr_sortico)."';
	\$Slide = '".$Slide."';
	\$Slide1 = '".$Slide1."';
	\$Surl1 = '".$Surl1."';
	\$Slide2 = '".$Slide2."';
	\$Surl2 = '".$Surl2."';
	\$Slide3 = '".$Slide3."';
	\$Surl3 = '".$Surl3."';
	\$index_mnum = '".$index_mnum."';
	\$index_cid = '".$index_cid."';
	\$cms_cid = '".$cms_cid."';
	\$img_id = '".$img_id."';
	\$lunfan_cid = '".$lunfan_cid."';
	\$wxurl = '".$wxurl."';
	\$txurl = '".$txurl."';
	\$xlurl = '".$xlurl."';
	\$tbaiduapi = '".$tbaiduapi."';
	\$log_listpax = '".$log_listpax."';
	\$sylinks = '".$sylinks."';
	\$compress_html = '".$compress_html."';
	\$dy_id = '".$dy_id."';
	\$dy_jk = '".$dy_jk."';
	\$more = '".$more."';
	\$more_html = '".$more_html."';
?>";
		$cachefile = EMLOG_ROOT.'/content/templates/Ssanl/top/config.php';
		@ $fp = fopen($cachefile, 'wb') OR emMsg('读取缓存失败。如果您使用的是Unix/Linux主机，请修改缓存目录 (content/cache) 下所有文件的权限为777。如果您使用的是Windows主机，请联系管理员，将该目录下所有文件设为可写');
		@ $fw =	fwrite($fp,$cachedata) OR emMsg('写入缓存失败，缓存目录 (content/cache) 不可写');
		fclose($fp);
		emMsg("修改配置成功！",BLOG_URL.'?setting');
		}
}