<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div class="container-fluid home-fluid">
<div class="site-content">
<nav class="navcates">当前位置：<i class="fa fa-home"></i><a href="<?php echo BLOG_URL; ?>">首页</a><i class="fa fa-angle-right"></i><?php blog_sort($logid);?><i class="fa fa-angle-right"></i><?php echo $log_title; ?></nav>
<div class="site-main content-left"><div class="widget-box">
<article id="post-20574" class="widget-content single-post">
<header id="post-header">
<div class="post-meta">
<span class="time"><?php echo gmdate('Y-n-j', $date); ?></span>
<span class="eye"><i class="fa fa-eye"></i><?php echo $views; ?></span>
<span class="comm"><a href="<?php echo $value['log_url']; ?>"><i class="fa fa-comment-o"></i><?php echo $comnum; ?></a></span>
<span class="r-hide"><a title="侧边栏"><i class="fa fa-caret-left"></i><i class="fa fa-caret-right"></i></a></span></div>
<div id="font-change" class="left"><span id="font-dec"><a href="<?php echo $value['log_url']; ?>#" title="减小字体">-</a></span><span id="font-n"><a href="<?php echo $value['log_url']; ?>#" title="默认大小">N</a></span><span id="font-inc"><a href="<?php echo $value['log_url']; ?>#" title="增大字体">+</a></span></div>
<h2 class="post-title"><?php topflg($top); ?><a href="<?php echo $value['log_url']; ?>" title="正在阅读：<?php echo $log_title; ?>" rel="bookmark"><?php echo $log_title; ?></a></h2>
<div class="clear"></div>
</header>
<div class="entry">
<?php if($sortid==$dy_id){
if($_GET['ply'] != null){
$db=Database::getInstance();
$row=mysqli_fetch_array(mysqli_query("SELECT * FROM ".DB_PREFIX."blog WHERE gid =$logid"));
$strarr = explode("\n",$row['spdz']);
$u=$_GET['ply']-1;
$urls= explode("*",$strarr[$u]);?>
<h6>正在播放:<?php echo $log_title.'-'.$urls[0]; ?></h6>
<p style="max-width:100%;height:500px;">
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width="100%" height="100%" src="<?php echo $dy_jk; ?><?php echo $urls[1];?>&amp;moshi=sd&amp;hd=3">
</iframe>
</p>
<?php doAction('log_related', $logData); ?>
<div class="fanhui"><a href="<?php echo $logid;?>.html">返回</a></div>
<?php }else{ dyyinfo($logid); } }else{?>
<?php echo nltag(unCompress($log_content),$domain);?>
<?php doAction('down_log',$logid); ?>
<?php }?>
<?php doAction('log_related', $logData); ?>
</p>
<br/>
<h2 style="box-sizing:border-box;margin:0px -15px 10px;padding:0px 15px;border-width:1px 1px 1px 3px;border-style:solid;border-color:#528B8B #528B8B #528B8B #528B8B;line-height:25px;font-weight:normal;color:#333333;text-rendering:optimizelegibility;font-size:15px;white-space:normal;font-family:'Hiragino Sans GB', 'Microsoft Yahei', SimSun, Helvetica, Arial, sans-serif;background:#FFFFFF;">
<i class="fa fa-clock-o" aria-hidden="true"></i>发布时间：<?php echo gmdate('Y-n-j G:i l', $date); ?><li>
<i class="fa fa-bullhorn"></i>版权声明：除非注明，文章均为【<?php echo $blogname; ?>】原创，欢迎转载！转载请注明本文地址，谢谢！
<script>cambrian.render('body')</script>
</h2>
<p style="box-sizing:border-box;margin-top:0px;margin-bottom:10px;padding:0px;border:0px;line-height:25px;color:#333333;font-size:13px;white-space:normal;font-family:'Hiragino Sans GB', 'Microsoft Yahei', SimSun, Helvetica, Arial, sans-serif;background:#FFFFFF;">
<br/>
<div id="authorarea"><div class="authorinfo">
<?php global $CACHE; $user_cache = $CACHE->readCache('user'); $name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
<div class="author-avater">
<?php if (!empty($user_cache[1]['photo']['src'])): ?>
<img class="avaterimg" alt="作者：<?php echo $blogname; ?>" title="作者：<?php echo $blogname; ?>" src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" height="50" width="50">
<?php endif;?></div>
<div class="author-des">
<div class="author-meta">
<span class="post-author-name"><a href="<?php echo BLOG_URL; ?>?author=1"  rel="author"><?php echo $name; ?></a></span>
<?php $sta_cache = Cache::getInstance()->readCache('sta'); ?>
<span class="post-author-tatus"><a href="javascript:void(0);" target="_blank"><?php echo $sta_cache['lognum']; ?>篇文章</a></span>
<span class="post-author-url"><a href="<?php echo BLOG_URL; ?>" rel="nofollow" target="_blank">站点</a></span>
<span class="post-author-weibo"><a href="<?php echo $xlurl; ?>" rel="nofollow" target="_blank">微博</a></span>     
<span class="post-author-weibo"><a href="/" rel="nofollow" target="_blank">熊掌号</a></span>  </div>
<p class="author-description"><?php echo $user_cache[1]['des']; ?></p>
</div></div>
<?php if($tbaiduapi=='1'){?><div class="bdshare"><?php echo checkbaidu($logid);?></div><?php }?>
</div>
<div class="post-navigation"><?php fanhui_sort($logid); ?> <?php neighbor_log($neighborLog); ?> </div>
<div id="related-posts" class="related-posts">
<h3><span class="h3line">相关文章</span><div class="post-tags-key"><span class="post-keyword">关键词：<?php blog_tag($logid); ?></span></div> </h3>
  <ul class="widget-content">
<?php
$Log_Model = new Log_Model();
$randlogs = $Log_Model->getLogsForHome("AND sortid = {$sortid} ORDER BY rand() DESC,date DESC", 1,4);
foreach($randlogs as $value):
if(pic_thumb($value['content'])){
$imgsrc = pic_thumb($value['content']);
}elseif(getThumbnail($value['logid'])){
$imgsrc = getThumbnail($value['logid']);
}else{
$imgsrc = TEMPLATE_URL.'tpimg/cats.jpg';
}?>  

<li class="related-item post-thumbnail">
<a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" rel="bookmark">
<img src="<?php echo $imgsrc; ?>" alt="<?php echo $value['log_title']; ?>" width="330" height="200" original="<?php echo $imgsrc; ?>"><span><?php echo $value['log_title']; ?></span></a></li>            
<?php endforeach; ?></ul></div>
<section id="comments"> 
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>		
<?php blog_comments($comments); ?>
<label id="AjaxCommentEnd"></label>
<span class="icon icon_comment" title="comment"></span>
  </section>
  
</article>
</div>      </div>
<?php include View::getView('side');?>
</div><div class="clear"></div>
</div>
<?php include View::getView('footer');?>
