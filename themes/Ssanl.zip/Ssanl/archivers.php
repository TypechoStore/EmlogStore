<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<style type="text/css">
.archives ul{overflow:hidden;padding:0px !important;}
.archives-title{border-bottom:1px #eee solid;position:relative;padding-bottom:4px;margin-bottom:10px}
.archives li a{color:#222222;padding:8px 0;display:block;}
.archives li{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;list-style:none !important}
.archives li a:hover .atitle:after{background:#cc0000}
.archives li a span{display:inline-block;width:130px;font-size:12px;text-indent:20px}
.archives li a .atitle{display:inline-block;padding:0 15px;position:relative;white-space:nowrap;width:calc(100% - 180px);}
.archives li a .atitle:after{position:absolute;left:-6px;background:#ccc;height:8px;width:8px;border-radius:6px;top:8px;content:""}
.archives li a .atitle:before{position:absolute;left:-8px;background:#fff;height:12px;width:12px;border-radius:6px;top:6px;content:"";box-shadow:inset 0px 0px 2px #00cc00;}
.archives{position:relative;padding:10px 0}
.archives:before{height:100%;width:4px;background:#eee;position:absolute;left:126px;content:"";top:0;}
.archives h4{position:relative;margin:20px 0;cursor:pointer;font-size:14px !important;font-weight:bold !important;width:120px}
.archives h4:hover:after{background:#cc0000}
.archives h4:before{position:absolute;left:119px;background:#fff;height:18px;width:18px;border-radius:9px;top:3px;content:"";box-shadow:inset 0px 0px 4px #00cc00;}
.archives h4:after{position:absolute;left:122px;background:#ccc;height:12px;width:12px;border-radius:6px;top:6px;content:""}
</style>
<script type="text/javascript">
$(function(){
	$('.archives').find('ul').hide();
	$('.archives').find('ul:first').show();
	$('.archives h4').click(function(){
		$(this).next('ul').slideToggle("fast");
	})
})
</script>
<div class="container-fluid home-fluid">
<div class="site-content">
  <div class="site-main content-left">
<div class="widget-box">
<article id="post-20574" class="widget-content single-post">
<header id="post-header">
<div class="post-meta">
<span class="time"><?php echo gmdate('Y-n-j', $date); ?></span>
<span class="eye"><i class="fa fa-eye"></i><?php echo $views; ?></span>
<span class="comm"><a href="<?php echo $value['log_url']; ?>"><i class="fa fa-comment-o"></i><?php echo $comnum; ?></a></span>
<span class="r-hide"><a title="侧边栏"><i class="fa fa-caret-left"></i><i class="fa fa-caret-right"></i></a></span></div>
<h2 class="post-title"><?php topflg($top); ?><a href="<?php echo $value['log_url']; ?>" title="正在阅读：<?php echo $log_title; ?>" rel="bookmark"><?php echo $log_title; ?></a></h2>
<div class="clear"></div>
</header>
  <div class="entry"> 
<?php
			function displayRecord(){
				global $CACHE; 
				$record_cache = $CACHE->readCache('record');
				$output = '';
				foreach($record_cache as $value){
					$output .= '<h4>'.$value['record'].'</h4>'.displayRecordItem($value['date']);
				}
				$output = '<div class="archives">'.$output.'</div>';
				return $output;
			}
			function displayRecordItem($record){
				if (preg_match("/^([\d]{4})([\d]{2})$/", $record, $match)) {
					$days = getMonthDayNum($match[2], $match[1]);
					$record_stime = emStrtotime($record . '01');
					$record_etime = $record_stime + 3600 * 24 * $days;
				} else {
					$record_stime = emStrtotime($record);
					$record_etime = $record_stime + 3600 * 24;
				}
				$sql = "and date>=$record_stime and date<$record_etime order by top desc ,date desc";
				$result = archiver_db($sql);
				return $result;
			}
			function archiver_db($condition = ''){
				$DB = Database::getInstance();
				$sql = "SELECT gid, title, date, views FROM " . DB_PREFIX . "blog WHERE type='blog' and hide='n' $condition";
				$result = $DB->query($sql);
				$output = '';
				while ($row = $DB->fetch_array($result)) {
					$log_url = Url::log($row['gid']);
					if($row['views']>1000){$output .= '<li class="goodwork"><a title="热门文章" href="'.$log_url.'"><span>'.date('m月d日',$row['date']).'</span><div class="atitle">'.$row['title'].'</div></a></li>';}
					else{$output .= '<li><a href="'.$log_url.'"><span>'.date('m月d日',$row['date']).'</span><div class="atitle">'.$row['title'].'</div></a></li>';}
				}
				$output = empty($output) ? '<li>暂无文章</li>' : $output;
				$output = '<ul>'.$output.'</ul>';
				return $output;
			}
			echo displayRecord();
			?>
</div></article>
</div>      </div>
<?php include View::getView('side');?>
</div><div class="clear"></div>
</div>
<?php include View::getView('footer');?>