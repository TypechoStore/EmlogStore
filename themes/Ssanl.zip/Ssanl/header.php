<?php
/*
Template Name:Ssanl[2020]
Description:Ssanl<br><a href="../?setting" target="_blank"" title="模板设置" target="_blank">模板设置</a><br>
Version:2.0
Author:演员
Author Url:https://hujinyuan.cn
ForEmlog:5.3.1、6.0.0、6.0.1、6.1.1、6.1.9
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('functions');
require_once View::getView('module');
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?><?php echo page_tit($page); ?></title>
<?php if(isset($sortName)):?>
<meta name="keywords" content="<?php echo _g('sort_keywords.'.$sortid);?>" />
<?php else:?>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<?php endif; ?>
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="Tadpole" />
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<meta name="renderer" content="webkit">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link rel="apple-touch-icon-precomposed" href="<?php echo TEMPLATE_URL; ?>favicon.ico">
 <?php include View::getView('top/tpheader');?>
<?php if($logid){?>
<link href="<?php echo Url::log($logid);?>" rel="canonical" />
<?php }?>
<?php if($sortid){?>
<link href="<?php echo Url::sort($sortid);?>" rel="canonical" />
<?php }?>
<?php if($tag){?>
<link href="<?php echo Url::tag($params[2]);?>" rel="canonical" />
<?php }?>
<?php if($record){?>
<link href="<?php echo Url::record($params[2]);?>" rel="canonical" />
<?php }?>
</head>
<body class="home-index">
<header class="site-header">
<div id="header" class="navbar">
<div class="header"><h1 id="logo">
<a href="<?php echo BLOG_URL; ?>"><img src="<?php echo $logo ?  $logo : ''.TEMPLATE_URL."tpimg/logo.png";?>" title="<?php echo $blogname; ?>" alt="<?php echo $blogname; ?>"></a></h1>
<div class="search">
<button class="js-toggle-search" ><i class="fa fa-search icon-search"></i></button></div>
<!-- mobile nav -->
<div class="nav-sjlogo"><i class="fa fa-navicon"></i></div>
<div class="nav-sousuo">
<a id="mo-so" class="js-toggle-search" href="javascript:void(0);"><i class="fa fa-search icon-search"></i></a>
</div>
<div class="header-nav" data-type="index" data-infoid="index">
<aside class="mobile_aside mobile_nav"><div class="mobile-menu"><ul id="nav" class="nav-pills"><?php blog_navi();?>	
<?php if($more=='1'){?>	
<li id="nvabar-category" class="menu-item-has-children"><a href="javascript:;"><i class="fa fa-retweet"></i> 更多功能</a><ul class="dropdown-menu sub-menu"><?php echo $more_html;?></ul ></li>
<?php }?>	
</ul></div></aside></div>
</div></div></header>