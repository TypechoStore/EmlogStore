<?php 
/**
 * 侧边栏
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="yccss">
<aside class="sidebar-right">
<div class="widget-box widget" id="zzxx-box">
<?php
global $CACHE;
$user_cache = $CACHE->readCache('user');
$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
<div class="topauthor">
<?php if (!empty($user_cache[1]['photo']['src'])): ?>
<img alt="博客主人：<?php echo $blogname; ?>" src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" class="avatar-photo" title="<?php echo $blogname; ?>" height="100" width="100">
<?php endif;?>
<span class="intag">博 主：</span><span class="names"><?php echo $name; ?></span><span class="talk"><?php echo $user_cache[1]['des']; ?></span>
</div>
<ul>
<li class="tsina"><a title="新浪微博" rel="nofollow" href="<?php echo $xlurl; ?>" target="_blank"><i class="fa fa-weibo"></i></a></li>
<li class="weixin"><a title="微信"><i class="fa fa-weixin"></i><span style="background-image:url(<?php echo $wxurl; ?>);"></span></a></li>
<li class="tqq"><a title="QQ临时对话" rel="nofollow" href="tencent://message/?uin=<?php echo $txurl; ?>&amp;Site=&amp;Menu=yes" target="blank"><i class="fa fa-qq"></i></a></li>
<li class="feed"><a title="QQ空间" href="//user.qzone.qq.com/<?php echo $txurl; ?>" rel="nofollow" target="_blank"><i class="fa fa-chrome"></i></a></li>
</ul>
<div class="butauthor ">
<span class="bignum pn">在线 <?php echo "".$users_online."";?> 人</span>
<span class="bignum">运行 <a id="days"><?php echo floor((time()-strtotime($yxsjdate))/86400); ?></a> 天数</span>
</div>
</div>
<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>
</aside>
</div><!--end #siderbar-->
