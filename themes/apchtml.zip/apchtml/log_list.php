<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<section id="articles" class="wrapper clearfix" role="main">
<div class="sidebar-spacer">
<? include View::getView('side');?>
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<article id="post-<?echo $value['logid']?>" class="post-<?echo $value['logid']?> post type-post status-publish format-standard hentry category-random-musings">
<div class="header-spacer">
<div class="date">
<time datetime="<?php echo gmdate('Y-n-j', $value['date']); ?>" pubdate><span class="month"><?php echo gmdate('M', $value['date']); ?></span> <span class="day"><?php echo gmdate('j', $value['date']); ?></span></time> </div>
<header>
<h1><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>" rel="bookmark" title="点击：<?php echo $value['views']; ?>，评论：<?php echo $value['comnum']; ?>，引用：<?php echo $value['tbcount']; ?>">
<?php echo $value['log_title']; ?></a></h1>
</header>
</div>
<div class="content equal">
<p><?php echo $value['log_description']; ?></p>
<span><?php blog_sort($value['logid']); ?> <?php blog_tag($value['logid']); ?></span>
</div>
<a href="<?php echo $value['log_url']; ?>" rel="bookmark">
<div class="button">Read Article</div>
</a> </article>
<?php endforeach; ?>
<!--end content-->
</div>
</section>
<div id="pagenavi"><?php echo $page_url;?></div>
<? include View::getView('footer');?>