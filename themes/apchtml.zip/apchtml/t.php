<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 

?>
<section>
<a name="comments"></a>
<div id="comments" class="wrapper clearfix">
<p class="nocomments">
<a href="#respond">来了就随便说点什么吧~</a>
    <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
    <div class="top"><a href="<?php echo BLOG_URL . 'admin/twitter.php' ?>">发布碎语</a></div>
    <?php endif; ?>
</p>
</div>
</section>
<section style="color:#aaa;">
<div id="comments" class="wrapper clearfix">
<ol class="comments-list">
    <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    ?> 
<li class="comment even thread-even depth-1" id="li-comment-<?php echo $tid;?>">
<article id="comment-<?php echo $tid;?>">
<div class="author-avatar">
<img alt='' src='<?php echo $avatar; ?>' class='avatar avatar-112 photo' height='112' width='112'/><div class="ring-top"></div>
<div class="ring-bottom"></div>
</div>
<div class="content">
<h2>By
<span class="fn"><?php echo $author; ?> </span> on <a href="#comment-<?php echo $tid;?>"><time pubdate datetime="<?php echo $val['date']; ?>"><?php echo $val['date']; ?></time></a><span class="says"></span> </h2>
<p><?php echo $val['t'];?></p>
<div class="reply">
<a href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">Reply (<span id="rn_<?php echo $tid;?>"><?php echo $val['replynum'];?></span>) <span>&darr;</span></a>
</div>
</div>
</article>
	<div class="clear"></div>
   	<ul id="r_<?php echo $tid;?>" class="r"></ul>
    <div class="huifu" id="rp_<?php echo $tid;?>">
	<textarea id="rtext_<?php echo $tid; ?>"></textarea>
    <div class="tbutton">
        <div class="tinfo" style="display:<?php if(ROLE == 'admin' || ROLE == 'writer'){echo 'none';}?>">
        Name: <input type="text" id="rname_<?php echo $tid; ?>" value="" />
        <span style="display:<?php if($reply_code == 'n'){echo 'none';}?>">验证码：<input type="text" id="rcode_<?php echo $tid; ?>" value="" /><?php echo $rcode; ?></span>        
        </div>
        <input class="button_p" type="button" onclick="reply('<?php echo DYNAMIC_BLOGURL; ?>?action=reply',<?php echo $tid;?>);" value="回复" /> 
        <div class="msg"><span id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></span></div>
    </div>	
    </div>
</li>
    <?php endforeach;?>
</ol>
    <div id="pagenavi"><?php echo $pageurl;?><span>(有<?php echo $twnum; ?>条碎语)</span></div>
</div>	
</section>
<?php
 include View::getView('footer');
?>