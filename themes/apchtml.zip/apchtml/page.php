<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
 <link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>/public/styles/biography.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>/public/styles/biography-devices.css" type="text/css" media="screen and (min-device-width: 641px)"/>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>/public/styles/biography-mobile.css" type="text/css" media="screen and (max-width: 640px)"/>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>/public/styles/biography-iphone.css" type="text/css" media="screen and (max-device-width: 480px)"/>
<!--[if IE]>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>/public/styles/biography-ie9.css" type="text/css" media="screen" />
<![endif]-->
<!--[if lte IE 8 ]>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>/public/styles/biography-ie8.css" type="text/css" media="screen" />
<![endif]-->
<section id="biography" class="wrapper clearfix">
<section>
<article id="about">
<div class="content-title">
<header id="headline-container">
<h1 id="main-headline"><?php echo $log_title; ?></h1>
<h2 id="sub-headline">这里修改成你需要填写的文字,或者删除掉也行</h2>
</header>
<div class="ring-left"></div>
<div class="ring-right"></div>
</div>
<div class="content">
<?php echo $log_content; ?>
<?php blog_att($logid); ?>
</div>
</article>
</section>
<!--end content-->
<?php 
include View::getView('page_side');
include View::getView('footer');
?>