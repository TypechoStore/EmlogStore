<?php
/*
Template Name:apcHtml
Description: 由【博客前传】创建的第二款HTML5模板
Author:qzz
Version:1.1
Author Url:http://www.qzee.net
Sidebar Amount:1
ForEmlog:4.2.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once (View::getView('module'));
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="author" content="qzz"/>
<meta name="geo.placename" content="apcHTML">
<link rel="shortcut icon" href="<?php echo TEMPLATE_URL; ?>/favicon.ico">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo TEMPLATE_URL; ?>/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo TEMPLATE_URL; ?>/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon-precomposed" href="<?php echo TEMPLATE_URL; ?>/apple-touch-icon.png">
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;"/>
<meta property="og:title" content="<?php echo $blogtitle; ?>"/>
<meta property="og:type" content="blog"/>
<meta property="og:url" content="<?php echo BLOG_URL; ?>"/>
<meta property="og:site_name" content="<?php echo $blogtitle; ?>"/>
<title><?php echo $blogtitle; ?></title>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>public/styles/styles.css" type="text/css" media="screen"/>
<!--[if lte IE 8 ]>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>public/styles/styles-ie8.css" type="text/css" media="screen" />
<![endif]-->
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>public/styles/articles.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>public/styles/articles-mobile.css" type="text/css" media="screen and (max-width: 1200px)"/>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>public/styles/articles-devices.css" type="text/css" media="screen and (min-width: 641px)"/>
<!--[if IE 9 ]>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>public/styles/articles-ie9.css"  type="text/css" media="screen" />
<![endif]-->
<!--[if lte IE 8 ]>
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>public/styles/articles-ie8.css" type="text/css" media="screen" />
<![endif]-->
<script src="<?php echo TEMPLATE_URL; ?>public/scripts/jquery-1.5.2.min.js"></script>
<!--[if IE]>
<script src="html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script src="<?php echo TEMPLATE_URL; ?>public/scripts/main.min.js"></script>
<script type="text/javascript">
$(window).bind("load resize", function(){
 $(".equal").removeAttr("style");
 $(".equal").equalHeight();
});
</script>

<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head><body>

<header>
<nav>
<div id="navigation" class="clearfix"><a href="<?php echo BLOG_URL; ?>" id="logo"><?php echo $blogname; ?></a>
<div id="menu" class="clearfix">
<div id="arrow"><img src="<?php echo TEMPLATE_URL; ?>public/images/backgrounds/menu-hover.gif" alt="Current Page" class="menu-hover"/></div>
<ul id="pages">
<li <?php echo $curpage == CURPAGE_HOME ? 'id=current' : ' ';?>><a href="<?php echo BLOG_URL; ?>">Home</a></li>
<?php if($istwitter == 'y'):?>
<li <?php echo $curpage == CURPAGE_TW ? 'id=current' : ' ';?>><a href="<?php echo BLOG_URL; ?>t/">微语</a></li>
<?php endif;?>
			<?php 
			global $CACHE; 
			$navi_cache = $CACHE->readCache('navi');
			foreach ($navi_cache as $key => $val):
			if ($val['hide'] == 'y'){continue;}
			if (empty($val['url'])){$val['url'] = Url::log($key);}
			$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
			$value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
			?>
			<li <?php echo isset($logid) && $key == $logid ? 'id=current' : ' ';?>><a href="<?php echo $val['url']; ?>" <?php echo $newtab; ?>><?php echo $val['naviname']; ?></a></li>
			<?php endforeach;?>
			<?php doAction('navbar', '<li>', '</li>'); ?>
			<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
			<li><a href="<?php echo BLOG_URL; ?>admin/write_log.php">New Post</a></li>
			<li><a href="<?php echo BLOG_URL; ?>admin/">Manage</a></li>
			<li><a href="<?php echo BLOG_URL; ?>admin/?action=logout">Exit</a></li>
			<?php else: ?>
			<li><a href="<?php echo BLOG_URL; ?>admin/">Login</a></li>
			<?php endif; ?>
</ul>
</div>
</div>
</nav>
</header>
<!--header end-->
