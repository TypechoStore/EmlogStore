<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<section id="article" class="wrapper clearfix" role="main">
<div class="sidebar-spacer">
<? include View::getView('side');?>
<article id="post-<?echo $value['logid']?>" class="post-<?echo $value['logid']?> post type-post status-publish format-standard hentry category-random-musings">
<div class="article-details">
<div class="date">
<time datetime="<?php echo gmdate('Y-n-j', $value['date']); ?>" pubdate><span class="month"><?php echo gmdate('M', $value['date']); ?></span> <span class="day"><?php echo gmdate('j', $value['date']); ?></span></time> <div class="ring-left"></div>
<div class="ring-right"></div>
</div>
<div class="comments">
<p> <a href="#comments"> <?php echo ($comnum); ?>  Comment </a> </p>
<div class="ring-left"></div>
<div class="ring-right"></div>
</div>
<div class="share clearfix">
<div class="social"><span class="st_sharethis_custom" displayText="Share this!">Share this! </span><div class="bshare-custom"><a title="分享到QQ空间" class="bshare-qzone" href="javascript:void(0);"></a><a title="分享到新浪微博" class="bshare-sinaminiblog" href="javascript:void(0);"></a><a title="分享到人人网" class="bshare-renren" href="javascript:void(0);"></a><a title="分享到腾讯微博" class="bshare-qqmb" href="javascript:void(0);"></a><a title="分享到豆瓣" class="bshare-douban" href="javascript:void(0);"></a><a title="更多平台" class="bshare-more bshare-more-icon"></a></div><script type="text/javascript" charset="utf-8" src="http://static.bshare.cn/b/button.js#style=-1&amp;uuid=eb6ed31a-0f21-49da-b113-ab0ce04e1a8b&amp;pophcol=2&amp;lang=zh"></script><script type="text/javascript" charset="utf-8" src="http://static.bshare.cn/b/bshareC0.js"></script></div>
</div>
</div>
<div id="content">
<div class="content-title">
<header>
<h1 id="main-headline"><?php topflg($top); ?><?php echo $log_title; ?></h1>
<h6 id="sub-headline" style="font-size:14px;"><?php blog_sort($logid); ?>post by <?php blog_author($author); ?> on <?php echo gmdate('Y-n-j G:i l', $date); ?> <?php editflg($logid,$author); ?></h6>
</header>
<div class="ring-left"></div>
<div class="ring-right"></div>
</div>
<div class="content clearfix">
<p><?php echo $log_content; ?></p>
	<p class="tags"><?php blog_att($logid); ?></p>
	<p class="tags"><?php blog_tag($logid); ?></p>
	<?php doAction('log_related', $logData); ?>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
</div>
</div>
</article>
</div>
</section>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);?>
<!--end content-->
<? include View::getView('footer'); ?>