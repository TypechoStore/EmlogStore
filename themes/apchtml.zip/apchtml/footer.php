<?php 
/*
* 底部信息
* Qzz一直在为大家制作免费的模板,希望您能保留我的链接,或者您可以添加我的网站 qzee.net为友情链接
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<footer id="footer">
<p class="copyright">&copy;</p>
<p>Created by Emlog using valid CSS3 &amp; <a href="http://validator.w3.org/check?uri=http://qzee.net" target="_blank" class="footer-link">HTML5</a>. Theme by <a href="http://qzee.net/" target="_blank" class="footer-link">Qzz</a>. 
 <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
<?php doAction('index_footer'); ?>
</p>
</footer>
<div style="display:none;"><!--这里可放统计代码--></div>
<script>try{Typekit.load();}catch(e){}</script>
<script src="<?php echo TEMPLATE_URL; ?>/public/scripts/jquery.fittext.js"></script>
<script type="text/javascript">
	$("#main-headline").fitText(2.5,28);
	$("#sub-headline").fitText(2.8,21);
</script></body>
</html>