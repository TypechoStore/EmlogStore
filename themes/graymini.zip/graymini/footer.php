<?php
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<!--<div class="clear"></div>-->
<div id="footerbar">
    Powered by <a href="http://www.emlog.net/" title="Emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">Emlog</a> &nbsp; Designed by <a href="http://www.zhush.net/" target="_blank">Hesan</a> &nbsp; <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> &nbsp; <?php doAction('index_footer'); ?> &nbsp; <?php echo $footer_info; ?><a name="bottom"></a><!--设置底部锚点-->
</div>
</div><!--#wrap.End-->
</body>
</html>
