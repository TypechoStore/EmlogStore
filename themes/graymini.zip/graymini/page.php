<?php
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="content">
<div class="content-box">
    <div class="log_tit">
        <h2 class="page"><span><?php echo $log_title; ?></span></h2>
    </div>
    <div class="log_cont">
        <?php echo $log_content; ?>
        <div class="clear"></div>
    </div>
    <!--非图形附件列表，5.0己非必须-->
    <!--<div class="att"><?php //blog_att($logid); ?></div>-->
</div>
<?php if ($comnum > 0): ?>
    <div class="content-box">
        <?php blog_comments($comments,$params); ?>
    </div>
<?php endif; ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div><!--#content.End-->
<?php
    //include View::getView('side');
    include View::getView('footer');
?>
