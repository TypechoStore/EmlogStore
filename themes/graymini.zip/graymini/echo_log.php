<?php
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="content">
<div class="content-box">
    <div class="log_tit">
        <h2 class="logs"><?php topflg($top); ?><?php echo $log_title; ?></h2>
        <p class="date"><?php blog_sort($logid); ?> &nbsp; <?php blog_author($author); ?> &nbsp; 发布于: &nbsp;<?php echo gmdate('Y-n-j G:i l', $date); ?> &nbsp; <?php editflg($logid,$author); ?></p>
    </div>
    <div class="log_cont">
        <?php echo $log_content; ?>
        <div class="clear"></div>
    </div>
    <!--非图形附件列表，5.0己非必须-->
    <!--<div class="att"><?php //blog_att($logid); ?></div>-->
    <div class="under">
        <p class="tag"><?php blog_tag($logid); ?></p>
        <p class="count">
        <a href="<?php echo $log_url; ?>#comments">评论(<?php echo $comnum; ?>)</a> &nbsp;
        <a href="<?php echo $log_url; ?>#tb">引用(<?php echo $tbcount; ?>)</a> &nbsp;
        <a href="<?php echo $log_url; ?>">浏览(<?php echo $views; ?>)</a>
        </p>
    </div>
</div>
<div class="content-box">
    <div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
</div>
<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
<?php if ($comnum > 0): ?>
    <div class="content-box">
        <?php blog_comments($comments,$params); ?>
    </div>
<?php endif; ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div><!--#content.End-->
<?php
    //include View::getView('side');
    include View::getView('footer');
?>
