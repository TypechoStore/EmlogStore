<?php
/*
 *首页日志列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="content">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<div class="content-box">
    <div class="log_tit">
        <h2 class="logs"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
        <p class="date"><?php blog_sort($value['logid']); ?> &nbsp; <?php blog_author($value['author']); ?> &nbsp; 发布于: &nbsp;<?php echo gmdate('Y-n-j G:i l', $value['date']); ?> &nbsp; <?php editflg($value['logid'],$value['author']); ?></p>
    </div>
    <div class="log_desc">
        <?php echo $value['log_description']; ?>
        <div class="clear"></div>
    </div>
    <!--非图形附件列表，5.0己非必须-->
    <!--<div class="att"><?php //blog_att($value['logid']); ?></div>-->
</div>
<?php endforeach; ?>
<div id="pagenavi"><?php echo $page_url; ?></div>
<div class="blank"></div>
<!-- 友情链接 -->
<?php if ($friends_display != 0): ?>
<div class="content-box">
    <div id="friends">
        <span class="title" style="margin-bottom:8px">友情链接</span> &nbsp;
        <?php
        global $CACHE; 
        $link_cache = $CACHE->readCache('link'); ?>
        <?php foreach($link_cache as $value): ?>
        <a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a> &nbsp;
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>
<!-- 友情链接.End -->
</div><!--#content.End-->
<?php
    //include View::getView('side');
    include View::getView('footer');
?>
