<?php
/*
Template Name: 绿色小清新
Description:本模版采用绿色为主色调单配蓝色，一眼看上去清爽亮丽。
Author:蓝叶
Author Url:http://lanyes.org
Sidebar Amount:1
ForEmlog:5.0.0 - 5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="<?php echo BLOG_URL; ?>" />
<title><?php echo $site_title; ?></title>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>master.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" language="javascript" src="<?php echo TEMPLATE_URL; ?>lytebox.js"></script>
<SCRIPT type=text/javascript src="<?php echo TEMPLATE_URL; ?>jquery.min.js"></SCRIPT>
<SCRIPT type=text/javascript src="<?php echo TEMPLATE_URL; ?>lavalamp.min.js"></SCRIPT>
<SCRIPT type=text/javascript src="<?php echo TEMPLATE_URL; ?>xixi.js"></SCRIPT>
<SCRIPT type=text/javascript>
$(function(){$(".lavaLamp").lavaLamp({ fx: "backout", speed: 700 })});
</SCRIPT>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<!--[if lt IE 7]>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>iepngfix_tilebg.js"></script>
 <style type="text/css">
 img, div, input, a { behavior: url("<?php echo TEMPLATE_URL; ?>iepngfix.htc") }
 </style>
<![endif]-->
</head>
<body>
<div id="web_bg" style="position:absolute;width:100%;height:100%;z-index:-1;left:0;top:0">
<img style="position:fixed;" src="http://t1.qpic.cn/mblogpic/b46d3d5b0d7f4a62513c/2000" height="100%" width="100%" />
</div>
<div id="header" class="w">
<h1 class="logo"><a href="<?php echo BLOG_URL; ?>" title="<?php echo $bloginfo; ?>"><IMG alt="<?php echo $blogname; ?>" src="<?php echo TEMPLATE_URL; ?>images/logo.png" /></a></h1>
<div class="clear"></div>
</div>
<div id="wrapper"><?php blog_navi();?>
<div style="float:right"><a href="http://lanyes.org/yinyue" target="_blank"title="蓝叶音乐盒"><img width="32px" height="32px" src="http://lanyes.org/content/templates/vqq/images/music.png" /></a> <a href="http://wpa.qq.com/msgrd?v=3&uin=84953409&site=qq&menu=yes" title="联系蓝叶" target="_blank"><img style="padding-left:3px;" width="32px" height="32px" src="http://lanyes.org/content/templates/vqq/images/32-qq.png" /></a> <a href="http://t.qq.com/laobings" title="蓝叶的腾讯微博" target="_blank"><img style="padding-left:3px;" src="http://lanyes.org/content/templates/vqq/images/32-qqweibo.png" /></a> <a href="http://t.sina.com.cn/hcwl" title="蓝叶的新浪微博" target="_blank"><img style="padding-left:3px;" src="http://lanyes.org/content/templates/vqq/images/32-weibo.png" /></a> <a href="http://list.qq.com/cgi-bin/qf_invite?id=76346bb18630c869c0456c47a542522cdc896ca92bce235f" title="邮件订阅蓝叶博客" target="_blank"><img style="padding-left:3px;" src="http://lanyes.org/content/templates/vqq/images/32-mail.png" /></a> <a href="http://lanyes.org/rss.php" title="蓝叶博客RSS源地址" target="_blank"><img style="padding-left:3px;" src="http://lanyes.org/content/templates/vqq/images/32-rss.png" /></a></div></div>
<div id="main" class="w">