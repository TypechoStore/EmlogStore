<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php if ($logid == '431'): ?>
<div style="width:960px;padding:20px 50px 50px 50px">
<div style="width:900px;text-align:center;font-size:18px;padding:20px"><a style="padding:10px 20px;background:#fff;border:1px solid #0CF" href="http://lanyes.org/tuwen.html" title="亲点击有惊喜出现">亲点击一下有惊喜</a></div>
<ul>
<?php get_rand_log();?>

</ul>

</div>
<?php else:?>
<div id="content">
<ul>
<li>
<div class="clear"></div>
<div class="post"><?php echo $log_content; ?></div>
<div><?php blog_att($logid); ?></div>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</li>
</ul>
</div>
<?php include View::getView('side');?><?php endif; ?>
<?php include View::getView('footer');?>