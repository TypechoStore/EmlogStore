﻿<div class="clear"></div>
</div>
<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<DIV id="footer" class="w">
<DIV id="footlink"><SPAN style="cursor:pointer;" onclick="window.scrollTo(0,0);">TOP</SPAN></DIV>
<DIV id="copyright">
<P>
CopyRight &copy; <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a> Powered By <a href="http://www.emlog.net" title="emlog 5.1.2">Emlog</a> Skin by <a href="http://lanyes.org" title="蓝叶">蓝叶</a> <?php echo $icp; ?> <?php echo $footer_info; ?></P>
</DIV>
<?php doAction('index_footer'); ?>
<div class="clear"></div>
</DIV>

</body>
</html>