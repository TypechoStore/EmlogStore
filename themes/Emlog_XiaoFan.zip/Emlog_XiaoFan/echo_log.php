<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="contentleft">
	<div class="logtitle">
    <?php topflg($top); ?><?php echo $log_title; ?>
	</div>
    <div class="logcont">
    	<p class="logdata">
        <?php echo gmdate('Y-n-j', $date); ?>  <?php blog_author($author); ?> <?php blog_sort($logid); ?> <?php editflg($logid,$author); ?>
        </p>
        <hr />
        <div class="cont">
         <?php echo $log_content; ?>
        </div>
       
        
        <p class="tag"><?php blog_tag($logid); ?></p>
		<?php doAction('log_related', $logData); ?>
        <?php /*?><div class="nextlog"><?php neighbor_log($neighborLog); ?></div><?php */?>
        <?php blog_comments($comments); ?>
        <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
        <div style="clear:both;"></div>
	</div>
</div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>