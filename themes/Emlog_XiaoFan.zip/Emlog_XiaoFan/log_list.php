<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 

?>
<div id="content">
<div id="contentleft">
    
<div class="topname">
最新文章
</div>
<div class="list">

<?php doAction('index_loglist_top'); ?>

<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
	
	<div class="cont">
        <p class="himg">
            <a href="<?php echo $value['log_url']; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/logoico.png" width="50" height="50" class="xwcms" /></a>
        </p>
        <div class="tt">
            <p class="logname">
            <?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
            </p>
            <p class="logmge">
            	作者：
				<?php blog_author($value['author']); 
					$user=$value['author'];
					if($user==1)
					{
						echo '<img src="'.TEMPLATE_URL.'images/hg.png" title="站长" />';
						}
				
				
				?>
                
                
                
                  分类：<?php blog_sort($value['logid']); ?>  评论数：<?php echo $value['comnum']; ?>  浏览量：<?php echo $value['views']; ?>
            </p>
            
        </div>
        <p class="logtime">
         <?php


			$a = gmdate('Y-m-d', $value['date']);
			$time = time();
			$c = date('Y-m-d',$time);
			
			if($a==$c){
				echo '<font color="Red"><b>今日更新</b></font> ';
			}else{
				echo $a;
			}
			?>
       
        </p>
       
    </div>
    
	<?php /*?><p class="date"><?php echo gmdate('Y-n-j', $value['date']); ?> <?php blog_author($value['author']); ?> 
	<?php blog_sort($value['logid']); ?> 
	<?php editflg($value['logid'],$value['author']); ?>
	</p>
	<?php echo $value['log_description']; ?>
	<p class="tag"><?php blog_tag($value['logid']); ?></p>
	<p class="count">
	<a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a>
	<a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a>
	</p>
	<div st<?php yle="clear:both;"></div>*/?>
<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>

<div id="pagenavi">
	<?php echo $page_url;?>
</div>

</div>
</div>

<div>
</div>
<!-- end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>