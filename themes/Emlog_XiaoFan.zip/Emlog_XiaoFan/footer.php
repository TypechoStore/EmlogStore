<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div style="clear:both;"> </div>
</div><!--end #content-->
 
<div id="footerbar">
	<div class="footleft">
    	<img width="150" height="150" src="http://i3.tietuku.com/cb6e56d157d147ce.png" title="扫一扫关注小凡网络传媒公众号" />
    </div>
    <div class="footri">
    	<p class="linkt">友情链接</p>
       	<div class="linklist">
        	<?php echo widget_link(); ?>
        </div>
    </div>
    <
    <div class="copy" style="color:#FFF; margin-left:400px;">
      	<p class="span-b"><a href="<?php echo BLOG_URL; ?>" style="margin-left:0"><?php echo $blogname; ?></a> | <a href="<?php echo BLOG_URL; ?>m/" target="_blank" >手机访问</a> | <a href="http://wpa.qq.com/msgrd?v=3&uin=8336184&site=qq&menu=yes" target="_blank">QQ联系</a><?php echo _g('footlink'); ?>&nbsp;&nbsp;&copy;2014-2015 小凡网络传媒 All right reserved. 版权所有 <span style="padding-left:10px;"><?php echo $footer_info; ?></span> </p>
     
        <p><?php echo $icp; ?></p>
        <?php doAction('index_footer'); ?>
      </div>
    
	<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
	<?php doAction('index_footer'); ?>
</div><!--end #footerbar-->
</div><!--end #wrap-->
<script>prettyPrint();</script>
</body>
</html>