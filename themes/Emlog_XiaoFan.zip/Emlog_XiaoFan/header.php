<?php



/*



Template Name:小凡极致优美



Description:简美，时尚，大方!



Version:1.0



Author:小凡



Author Url:http://www.aixiaofan.cn



Sidebar Amount:1



*/



if(!defined('EMLOG_ROOT')) {exit('error!');}



require_once View::getView('module');



?>



<!DOCTYPE html PUBliC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">



<html xmlns="http://www.w3.org/1999/xhtml">



<head>



<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />



<title><?php echo $site_title; ?></title>



<meta name="keywords" content="<?php echo $site_key; ?>" />



<meta name="description" content="<?php echo $site_description; ?>" />



<meta name="generator" content="emlog" />



<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />



<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />



<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />



<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />



<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />



<link href="<?php echo TEMPLATE_URL; ?>/css/shake.css" rel="stylesheet" type="text/css" />



<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>



<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>



<link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL ?>css/style.css" media="screen" />



<script type="text/javascript" src="<?php echo TEMPLATE_URL ?>js/jquery-1.8.3.min.js"></script>



<script type="text/javascript" src="<?php echo TEMPLATE_URL ?>js/jquery.banner.revolution.min.js"></script>



<script type="text/javascript" src="<?php echo TEMPLATE_URL ?>js/banner.js"></script>



<script src="http://tjs.sjs.sinajs.cn/open/api/js/wb.js" type="text/javascript" charset="utf-8"></script>







<!--[if IE 6]>



<script src="<?php echo TEMPLATE_URL; ?>iefix.js" type="text/javascript"></script>



<![endif]-->



<?php doAction('index_head'); ?>



</head>



<body>



<div id="wrap">



    <div id="topp">



          <div id="topnav">



          



            <div class="top">



            



            <?php /*?><?php echo $blogname; ?><?php */?>



            



            </div>



            <a href="<?php echo BLOG_URL; ?>"><img src="<?php echo TEMPLATE_URL ?>images/rjlogo.png" class="shake shake-slow" /></a>



            <?php /*?><h3><?php echo $bloginfo; ?></h3><?php */?>



          </div>

<?php /*?><div class="time">

		<span id="t_b">距离中秋节还剩：</span>

        <span id="t_d">00天</span>

        <span id="t_h">00时</span>

        <span id="t_m">00分</span>

        <span id="t_s">00秒</span>

    </div>

<script>

   function GetRTime(){

       var EndTime= new Date('2015/09/27 00:00:00');

       var NowTime = new Date();

       var t =EndTime.getTime() - NowTime.getTime();

       var d=Math.floor(t/1000/60/60/24);

       var h=Math.floor(t/1000/60/60%24);

       var m=Math.floor(t/1000/60%60);

       var s=Math.floor(t/1000%60);



       document.getElementById("t_d").innerHTML = d + "天";

       document.getElementById("t_h").innerHTML = h + "时";

       document.getElementById("t_m").innerHTML = m + "分";

       document.getElementById("t_s").innerHTML = s + "秒";

   }

   setInterval(GetRTime,0);

</script><?php */?>

          <div class="sing">



          	<wb:follow-button uid="3305247800" type="red_2" width="136" height="24" ></wb:follow-button>



            <br />



            



            <iframe src="http://follow.v.t.qq.com/index.php?c=follow&a=quick&appkey=801491545&sign=d4409f40&v=2&name=ooooocv&style=5&t=1395990534886&f=1" frameborder="0" scrolling="auto" width="178" height="24" marginwidth="0" marginheight="0" allowtransparency="true"></iframe>



          </div>



    </div>



    <div id="nav">



		<div class="navlist">



			<?php blog_navi();?>



    	</div>



    </div>



<div id="wrapper">



	<div class="fullwidthbanner-container">



		<div class="fullwidthbanner">



			<ul>



				<li data-transition="3dcurtain-horizontal" data-slotamount="15" data-masterspeed="300">



					<img src="https://qqpublic.qpic.cn/qq_public/0/0-2927777429-2F475FC0721D8F4934752EDC5A7AF59D/600?fmt=jpg&h=471&ppv=1&size=143&w=600" alt="" />									



				</li>



				<!--<li data-transition="3dcurtain-vertical" data-slotamount="15" data-masterspeed="300" data-link="#">



					<img src="http://i1.tietuku.com/91529015a0a9abac.png" alt="" />



				</li>-->

				



				<li data-transition="papercut" data-slotamount="15" data-masterspeed="300" data-link="http://www.aixiaofan.cn/post-21.html">



					<img src="https://qqpublic.qpic.cn/qq_public/0/0-2927777429-2F475FC0721D8F4934752EDC5A7AF59D/600?fmt=jpg&h=471&ppv=1&size=143&w=600" alt="点我查看借贷宝" />



				</li>

					



				<!--<li data-transition="turnoff" data-slotamount="15" data-masterspeed="300">



					<img src="http://i3.tietuku.com/58fd9e9e206f8561.jpg" alt="" />



				</li>	



				<li data-transition="flyin" data-slotamount="15" data-masterspeed="300">



					<img src="http://i3.tietuku.com/ab9628e271e5ebf0.jpg" alt="" />	 



				</li>					-->



			</ul>



		</div>



	</div>



    <div id="toplog">



    	<div class="topname">赞助商广告 - 小凡网络传媒</div>



        	



        <div class="toplist">



        	<a href="tencent://message/?uin=8336184">



        	<p style="width:960px; height:100px;">



            </p>



            </a>



        </div>



    </div>







</div>







  <?php /*?><?php if(Option::get('topimg')): ?>



  <div id="banner"><a href="<?php echo BLOG_URL; ?>"><img src="<?php echo BLOG_URL.Option::get('topimg'); ?>" height="450" width="960" /></a></div><?php 



  



  <?php endif;?>*/?>



  