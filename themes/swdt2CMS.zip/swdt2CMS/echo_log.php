<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="maincontent">
    <div id="mainleft">
        <div class="left-post">
            <div class="post-post">
				<h1 class="log-title"><?php topflg($top); ?><?php echo $log_title; ?> <span class="r"><?php echo $views;?>°</span></h1>
                <div class="log-meta">
					<?php blog_author($author); ?> &nbsp; / &nbsp; <?php echo gmdate('Y-n-j G:i', $date); ?> &nbsp; / &nbsp; 浏览：<?php echo $views;?> 人次 &nbsp; / &nbsp;  分类：<?php blog_sort($logid); ?> &nbsp; / &nbsp; <a href="#pinglun" class="blue">发表评论</a> &nbsp; <?php editflg($logid,$author); ?>              
				</div>
				<div class="log-share">
<!-- Baidu Button BEGIN -->
          
          <div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare"> <a href="#" title="分享到QQ空间" class="bds_qzone"></a> <a href="#" title="分享到新浪微博" class="bds_tsina"></a> <a href="#" title="分享到腾讯微博" class="bds_tqq"></a> <a href="#" title="分享到人人网" class="bds_renren"></a> <span class="bds_more">更多</span> <a title="累计分享0次" href="#" class="shareCount">0</a> </div>
          <script src="http://bdimg.share.baidu.com/static/js/bds_s_v2.js?cdnversion=386939" type="text/javascript" id="bdshare_js" data="type=tools&uid=38631"></script> 
           
          <script type="text/javascript">

document.getElementById("bdshell_js").src = "http://share.baidu.com/static/js/shell_v2.js?t=" + new Date().getHours();

</script> 
          
          <!-- Baidu Button END -->
					<div class="clear"></div>
				</div>
                <div class="log-content">
                	<?php echo $log_content; ?>
				</div>
				<!--百度广告开始-->
				<center>
				<script type="text/javascript">
/*文章末尾360*300*/
var cpro_id = "u1397024";
</script>
<script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script>
</center>
				<!--百度广告结束-->				
                <div class="log-footer">
                    <div class="qr">
						<img src="http://chart.apis.google.com/chart?chl=http://blog.sina.com.cn/eeemarketing&chs=100x100&cht=qr&chld=<?php echo Url::log($logid);?>|1&choe=UTF-8" />
                    </div>
                    <div class="copy">
                        <p><?php blog_tag($logid); ?></p>
                        <p>
                            <?php neighbor_log($neighborLog); ?>
                        </p>
						<p>本文网址：<input type="text" size="50" value="<?php echo Url::log($logid);?>" /></p>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
			<!--百度推荐-->
	<center>
	<div id="hm_t_10058"></div>
</center>
	<!--百度推荐-->
			<div id="pinglun">
				<?php blog_comments($comments); ?>
				<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
			</div>
        </div><!--//left-post end-->
    </div><!--//mainleft end-->
    <div id="mainright">
		<?php include View::getView('side');?>
    </div><!--//mainright end-->
    <div class="clear"></div>
<?php include View::getView('footer');?>