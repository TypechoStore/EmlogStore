<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="maincontent">
    <div id="mainleft">
        <div class="left-post">
            <div class="post-post">
				<h1 class="log-title"><?php echo $log_title; ?></h1>
                <div class="log-meta">
					作者：<?php blog_author($author); ?> 
					发布于：<?php echo gmdate('Y-n-j G:i', $date); ?>
					<?php editflg($logid,$author); ?>
				</div>
                <div class="log-content">
                	<?php echo $log_content; ?>
				</div>
            </div>
			<div id="pinglun">
				<?php blog_comments($comments); ?>
				<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
			</div>
        </div><!--//left-post end-->
    </div><!--//mainleft end-->
    <div id="mainright">
		<?php include View::getView('side');?>
    </div><!--//mainright end-->
    <div class="clear"></div>
<?php include View::getView('footer');?>