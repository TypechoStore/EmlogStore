<?php 
/**
 * 侧边栏
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<ul id="sidebar">
	<?php
if( ROLE == 'admin' || ROLE == 'writer' ):
?>
            <li>
				<h3><span>会员中心</span><span style="color:#333; font-weight:normal; font-size:12px;">（<?php $userInfo = userInfo(UID); echo $userInfo['name'];?>）</span></h3>
                <div id="side-member">
					<div class="gl">
						<span><a href="<?php echo BLOG_URL;?>admin/write_log.php">撰写日志</a></span>
						<span><a href="<?php echo BLOG_URL;?>admin/twitter.php">撰写微语</a></span>
						<div class="clear"></div>
					</div>
					<div class="gl">
						<span><a href="<?php echo BLOG_URL;?>admin/">管理中心</a></span>
						<span><a href="<?php echo BLOG_URL;?>admin/?action=logout">退出登录</a></span>
						<div class="clear"></div>
					</div>
                </div>
            </li>
	<?php
else:
	?>
            <li>
                <h3><span>用户登录</span></h3>
                <div id="side-login">
					<form action="<?php echo BLOG_URL;?>admin/index.php?action=login" method="post">
						<div class="ipt">
							账&nbsp;&nbsp;号：<input type="text" name="user" />
						</div>
						<div class="ipt">
							密&nbsp;&nbsp;码：<input type="password" name="pw" />
						</div>
						<div class="chk">
							验证码：<img src="<?php echo BLOG_URL;?>include/lib/checkcode.php" align="absmiddle" />
							<input name="imgcode" id="imgcode" type="text" />
						</div>
						<div class="btn">
							<table>
								<tr>
									<td><input type="submit" value="登录" /></td>
									<td><input type="reset" value="重置" /></td>
								</tr>
							</table>
							<div class="clear"></div>
						</div>
					</form>
                </div>
            </li>
<?php endif;?>
				
<?php 
$widgets = !empty($options_cache['widgets2']) ? unserialize($options_cache['widgets2']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>
</ul><!--end #siderbar-->
