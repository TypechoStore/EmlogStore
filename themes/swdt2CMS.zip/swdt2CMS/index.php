<?php 
/**
 * 文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="maincontent">
    <div id="mainleft">
        <div class="board">
            <div class="left">
				<?php getToutiao(15, 2);?>
            </div>
            <div class="right">
				<!-- 广告位：首页头条右边开始 -->
<script type="text/javascript" >BAIDU_CLB_SLOT_ID = "863279";</script>
<script type="text/javascript" src="http://cbjs.baidu.com/js/o.js"></script>
				<!-- 广告位：首页头条右边结束 -->
			</div>
            <div class="clear"></div>
        </div><!--//board end-->		
<!-- 广告位：头条下面banger开始 -->
<script type="text/javascript" >BAIDU_CLB_SLOT_ID = "863370";</script>
<script type="text/javascript" src="http://cbjs.baidu.com/js/o.js"></script>
<!-- 广告位：头条下面banger结束 -->		
        <div class="left-post">
                <?php
                $sort_cache = $CACHE->readCache('sort');
                if (!empty($sort_cache)):
                    foreach ($sort_cache as $value):
                        if ($value['pid'] != 0)
                            continue;
                        ?>
            <div class="cms-item">
               <h2>
                    <span><?php echo $value['sortname']; ?></span>
                    <div class="clear"></div>
               </h2>
               <ul class="list">
				   <?php
$sqlSegment = '';
if ($value['pid'] != 0 || empty($value['children'])) {
	$sqlSegment = "and sortid={$value['sid']}";
} else {
	$sortids = array_merge(array($value['sid']), $value['children']);
	$sqlSegment = "and sortid in (" . implode(',', $sortids) . ")";
}
$sqlSegment .= " order by date desc";
$logs = $Log_Model->getLogsForHome($sqlSegment, 1, 20);
foreach ($logs as $row) :
				   ?>
				   <li><a href="<?php echo $row['log_url']; ?>" title="<?php echo $row['log_title']; ?>"><?php echo subString($row['log_title'], 0, 22); ?></a></li>
				   <?php endforeach; ?>
                   <div class="clear"></div>
               </ul>
            </div>
                        <?php
                    endforeach;
                endif;
                ?>
        </div><!--//left-post end-->
    </div><!--//mainleft end-->
    <div id="mainright">
		<?php include View::getView('side2');?>
    </div><!--//mainright end-->
    <div class="clear"></div>
<?php include View::getView('footer');?>