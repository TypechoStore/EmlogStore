<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="main">
	<div id="content">
		<div class="post" id="post-<?php echo $logid; ?>">
			<h2 class="post-title"><?php echo $log_title; ?></h2>
			<div class="entry">
				<?php echo $log_content; ?>
				<?php blog_att($logid); ?>
			</div>
		</div>
		<div id="reaction">
			<?php blog_comments($comments); ?>
			<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
		</div>
	</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>