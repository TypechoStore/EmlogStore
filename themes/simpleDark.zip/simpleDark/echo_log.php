<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="main">
	<div id="content">
		<div class="post" id="post-<?php echo $logid; ?>">
			<h2 class="post-title"><?php topflg($top); ?><?php echo $log_title; ?></h2>
			<div class="post-meta">
				<?php echo gmdate('Y 年 n 月 j 日', $date); ?> / <?php blog_author($author); ?>
				<?php blog_sort($logid); ?> / 
				<a title="《<?php echo $log_title; ?>》上的评论" class="comment-link" href="<?php echo Url::log($logid); ?>#respond">评论</a> / 
				<?php editflg($logid,$author); ?>
			</div>
			<div class="entry">
				<?php echo $log_content; ?>
				<?php blog_att($logid); ?>
			</div>
			<div class="post-info"><?php blog_tag($logid); ?></div>
			<?php doAction('log_related', $logData); ?>
		</div>
		<div class="pagenavi">
			<?php neighbor_log($neighborLog); ?>
		</div>
		<div id="reaction">
			<?php blog_comments($comments); ?>
			<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
			<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
		</div>
	</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>