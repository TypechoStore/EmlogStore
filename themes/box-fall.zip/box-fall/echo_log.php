<?php
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="frame-content">
<div id="content">
<div class="content-box">
    <div class="title">
        <h2 class="logs"><?php topflg($top); ?><?php echo $log_title; ?></h2>
        <div class="line2" style="margin-top:9px;"></div>
        <p class="date"><i>本文由&nbsp; <?php blog_author($author); ?> 发布于 <?php echo gmdate('Y-n-j l', $date); //完整格式：gmdate('Y-n-j G:i l', $date) ?> &nbsp; <a href="<?php echo $log_url; ?>">浏览 (<?php echo $views; ?>)</a> &nbsp;<a href="<?php echo $log_url; ?>#comments">评论 (<?php echo $comnum; ?>)</a></i> &nbsp; <?php editflg($logid,$author); ?></p>
        <div class="log-sort"><img src="<?php echo TEMPLATE_URL; ?>images/sort.gif"><?php blog_sort($logid); ?></div>
    </div>
    <div class="blank"></div>
    <div class="log-cont">
        <?php echo $log_content; ?>
        <div class="clear"></div>
    </div>
    <div class="att"><?php blog_att($logid); ?></div>
    <div class="under">
        <p class="tag"><?php blog_tag($logid); ?></p>
    </div>
</div>
<div class="content-box">
    <div class="nextlog">
    <div class="hr1"></div>
    <?php neighbor_log($neighborLog); ?>
    <div class="hr2"></div>
    </div>
</div>
<div class="content-box">
    <?php doAction('log_related', $logData); ?>
</div>
<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
<?php if ($comnum > 0): ?>
    <div class="content-box">
        <?php blog_comments($comments,$params); ?>
    </div>
<?php endif; ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div><!--#content.End-->
</div><!--#frame_content.End-->
<?php
    include View::getView('side');
    include View::getView('footer');
?>
