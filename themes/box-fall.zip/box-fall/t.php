<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="frame-content">
<div id="tw">
<div class="content-box">
    <div class="title">
        <h2 class="twit"><span><?php echo Option::get('twnavi'); ?></span></h2>
    </div>
    <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
        <div id="tw-top"><a href="<?php echo BLOG_URL . 'admin/twitter.php' ?>">发布碎语</a></div>
        <div id="twitter">
    <?php else: ?>
        <div class="blank"></div>
        <div id="twitter">
        <div class="line3"></div>
    <?php endif; ?>
    <?php 
    foreach($tws as $val):
        $author = $user_cache[$val['author']]['name'];
        $avatar = empty($user_cache[$val['author']]['avatar']) ? 
        BLOG_URL . 'admin/views/images/avatar.jpg' : 
        BLOG_URL . $user_cache[$val['author']]['avatar'];
        $tid = (int)$val['id'];
        $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
        ?> 
        <div class="tw-cont-box">
        <div class="tw-avatar"><img src="<?php echo $avatar; ?>" /></div>
        <div class="tw-content">
            <p><b><?php echo $author; ?></b> &nbsp; <span class="tw-time"><?php echo $val['date'];?></span> &nbsp; <span class="tw-post"><a href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">回复(<span id="rn_<?php echo $tid;?>"><?php echo $val['replynum'];?></span>)</a></p>
            <p><?php echo $val['t'].'<br/>'.$img;?></p>
            <div id="r_<?php echo $tid;?>" class="r"></div>
            <!--<div class="bttome"></div>-->
            <?php if ($istreply == 'y'): ?>
            <div class="huifu" id="rp_<?php echo $tid;?>">   
            <textarea id="rtext_<?php echo $tid; ?>"></textarea>
            <div class="tbutton">
            <div class="tinfo" style="display:<?php if(ROLE == 'admin' || ROLE == 'writer'){echo 'none';}?>">
            昵　称：<input type="text" id="rname_<?php echo $tid; ?>" value="" />
            <br /><span style="display:<?php if($reply_code == 'n'){echo 'none';}?>">验证码：<input type="text" id="rcode_<?php echo $tid; ?>" value="" /><?php echo $rcode; ?></span>        
            </div>
            <input class="button_p" type="button" onclick="reply('<?php echo DYNAMIC_BLOGURL; ?>index.php?action=reply',<?php echo $tid;?>);" value="回复" /> 
            <div class="msg"><span id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></span></div>
            </div>
            </div><!--huifu.End-->
            <?php endif;?>
            <div class="clear"></div>
        </div><!--tw-content.End-->
        </div><!--tw-cont-box.End-->
    <?php endforeach;?>
    </div><!--twitter.End-->
</div><!--content-box.End-->
<div id="pagenavi"><?php echo $pageurl; ?></div>
</div><!--tw.End-->
<div class="blank"></div>
</div><!--#frame_content.End-->
<?php
    include View::getView('side');
    include View::getView('footer');
?>
