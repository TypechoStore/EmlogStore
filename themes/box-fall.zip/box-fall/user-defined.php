<?php 
/*
 * 自定义函数
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//Custom: 彩色标签
//调用本函数时须指定标签显示数量，如：getColorTags(25);
function get_ColorTags($tag_num) {
    //$tag_num 为标签显示数量，数值为"0"时全部显示
    global $CACHE;
    $tag_cache = $CACHE->readCache('tags');
    shuffle($tag_cache); //随机顺序
    if ($tag_num != 0){
        $tag_cache = array_slice($tag_cache,0,$tag_num); //显示数量
        }
    foreach($tag_cache as $value):
        $color = dechex(rand(3355443,13421772)); //随机颜色 ?>
        <span style="font-size:<?php echo $value['fontsize']; ?>pt; line-height:23px;"><a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇日志" style="color:#<?php echo $color; ?>"><?php echo $value['tagname']; ?></a></span>
    <?php endforeach; ?>
    <?php if ($tag_num != 0): ?>
        &nbsp; <a href="<?php echo BLOG_URL.'Tags'; ?>" target="_self" style="font-size:14px;">更多»</a>
    <?php endif; ?>
<?php } ?>
<?php
//Custom: 获取附件第一张图片
function get_AttachmentImg($blogid,$src_type){
    //$src_type 为图片地址类型，如下：
    //0 - url地址  (http://...)
    //1 - path地址 (d:/...)
    $db = MySql::getInstance();
    $sql = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$blogid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";
    //die($sql);
    $imgs = $db->query($sql);
    $img_src = "";
    while($row = $db->fetch_array($imgs)){
        if ($src_type == 0){
            $img_src .= BLOG_URL.substr($row['filepath'],3,strlen($row['filepath']));
        }else{
            $img_src .= EMLOG_ROOT.'/'.substr($row['filepath'],3,strlen($row['filepath']));
        }
    }
    return $img_src;
}
?>
<?php
//Custom: 日志归档
function get_Archive(){
$sql="select *,date_format(from_unixtime(date),'%Y年%m月') as ym,date_format(from_unixtime(date),'%m/%d') as md from ".DB_PREFIX."blog WHERE hide='n' and type='blog' ORDER BY date DESC";
$DB = MySql::getInstance();
$re=$DB->query($sql);
$log_content='<ul class="archive_list">';
$ym='';
while( $row = $DB->fetch_array($re) ){
	if($ym==$row['ym']){
		$log_content.='<li><a href="'.Url::log($row['gid']).'">'.$row['title'].'</a></li>';
	}else{
		$ym=$row['ym'];
		if($log_content!=='<ul class="archive_list">'){$log_content.='</ul></li>';}
		$log_content.='<li><p>'.$row['ym'].'</p><ul>';
		$log_content.='<li><a href="'.Url::log($row['gid']).'">'.$row['title'].'</a></li>';
	}
}
$log_content.='</ul>';
echo $log_content;
}
?>
