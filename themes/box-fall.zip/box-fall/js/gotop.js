//-goTOP[返回顶部]
function goTopEx(){
    var obj=document.getElementById("goTopBtn");
    function getScrollTop(){
        var scrollTop=0;
        if(document.documentElement&&document.documentElement.scrollTop){
            scrollTop=document.documentElement.scrollTop;
        }else if(document.body){
            scrollTop=document.body.scrollTop;
        }
        return scrollTop;
    }
    function setScrollTop(value){
        document.documentElement.scrollTop=value;
        document.body.scrollTop=value;
    }    
    window.onscroll=function(){getScrollTop()>666?obj.style.display="":obj.style.display="none";}
    obj.onclick=function(){
        var goTop=setInterval(scrollMove,10);
        function scrollMove(){
            setScrollTop(getScrollTop()/1.5);
            if(getScrollTop()<1)clearInterval(goTop);
        }
    }
}
//-goTOP.End
