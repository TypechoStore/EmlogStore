<?php
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div class="clear"></div>
</div><!--#frame.End-->
<?php
// 友情链接
if (!isset($logid) && empty($tws)) {
if ($display_list_side != 1) {
?>
<div class="content-box">
<div id="friends">
    <span class="title" style="margin-bottom:8px">友情链接</span> &nbsp;
    <?php
    global $CACHE; 
    $link_cache = $CACHE->readCache('link'); ?>
    <?php foreach($link_cache as $value): ?>
        <?php if(!strstr($value['link'],'#')): ?>
        <a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a> &nbsp;
        <?php endif; ?>
    <?php endforeach; ?>
</div>
</div>
<?php } ?>
<?php } ?>
<div class="hr2"></div>
<div id="footerbar">
    <a name="bottom"></a><!--设置底部锚点-->
    &nbsp; <a href=# target=_self><?php echo $blogname; ?></a> &copy; 2011-2012 &nbsp; <a href="http://www.miibeian.gov.cn" target="_blank" rel="nofollow"><?php echo $icp; ?></a> &nbsp; <?php doAction('index_footer'); ?> &nbsp; <?php echo $footer_info; ?><br />
    &nbsp; Designed by <a href="http://emlog8.sinaapp.com/" target="_blank">Emlog吧</a>
    <div id="powered"><img src="<?php echo TEMPLATE_URL; ?>/images/powered.png">&nbsp; Powered by <a href="http://www.emlog.net/" title="Emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">Emlog</a> &nbsp;</div>
</div>
</div><!--#wrap.END-->
</div>
<!-- goTOP[返回顶部] -->
<script src="<?php echo TEMPLATE_URL; ?>js/gotop.js" type="text/javascript"></script>
<div id="goTopBtn" style="display:none"><img src="<?php echo TEMPLATE_URL; ?>images/top.jpg"></div>
<script type=text/javascript>goTopEx();</script>
<!-- goTOP[返回顶部].END -->
<!-- 瀑布流 -->
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/jquery.masonry.min.js"></script>
<script>
  $(function(){
    var $container = $('#container');
    $container.imagesLoaded( function(){
      $container.masonry({
        itemSelector : '.box'
      });
    });
  });
</script>
<!-- 瀑布流.End -->
<!-- 图片延迟加载 -->
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/lazyload.js"></script>
<script type="text/javascript">
jQuery(document).ready(function($){
  if (navigator.platform == "iPad") return;
  jQuery("img").lazyload({
    effect:"fadeIn",
    placeholder: "<?php echo TEMPLATE_URL; ?>images/placeholder.gif"
  });
});
</script>
<!-- 延迟加载.End -->
<!-- 无觅相关日志插件 -->
<div id="wumi" style="z-index:999; display:none;">
<?php
if ($type == 'blog') { echo <<<LOADSCRIPT
<script type="text/javascript">
    var wumiiParams = "&num=5&mode=2&pf=emlog";
</script>
<script type="text/javascript" id="wumiiRelatedItems" src="http://widget.wumii.com/ext/relatedItemsWidget.htm"></script>
<a href="http://www.wumii.com/widget/relatedItems.htm" style="border:0;">
<img src="http://static.wumii.com/images/pixel.png" alt="无觅相关文章插件，快速提升流量" style="border:0;padding:0;margin:0;" />
</a>
LOADSCRIPT;
}
?>
</div>
<!-- 无觅相关日志插件.END -->
</body>
</html>
