<?php
/*
 *首页日志列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="frame-content"<?php if($display_list_side != 1){echo ' style="width:960px;"';} ?>>
<div id="content">
<?php doAction('index_loglist_top'); ?>
<div id="container" class="content-box">
<?php foreach($logs as $value): ?>
<div class="box">
		  <div style="height:27px; line-height:27px; background-color:#e4e4e4; border-bottom:1px #d8d8d8 solid; overflow:hidden;">
        &nbsp;<a href="<?php echo $value['log_url']; ?>"><font class="top"><?php topflg($value['top']); ?></font>
        <font style="font-weight:bold;"><?php echo $value['log_title']; ?></font></a>
		  </div>
    <?php
    $atta_img_src  = get_AttachmentImg($value['logid'],0);
    $atta_img_src1 = get_AttachmentImg($value['logid'],1);
    if (!empty($atta_img_src1)) {
        list($width, $height) = getimagesize($atta_img_src1);
        $height = 220*$height/$width;
        echo '<div class="box_abs" style="height:'.$height.'px;">';
        echo '<img src="'.$atta_img_src.'" />';
        echo '</div>';
    }else{
        echo '<div class="box_abs">';
        echo $value['log_description'];
        echo '<div class="clear"></div>';
        echo '</div>';
        //echo '<p class="att">'.blog_att($value['logid']).'</p>';
    } ?>
		  <div class="box_ps">
       <a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a> &nbsp;
       <a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a> &nbsp;
	  	</div>
</div>
<?php endforeach; ?>
<div class="clear"></div>
</div>
<div class="blank"></div>
<div id="pagenavi"><?php echo $page_url; ?></div>
<div class="blank"></div>
</div><!--#content.End-->
</div><!--#frame_content.End-->
<?php
    if($display_list_side == 1) {include View::getView('side');}
    include View::getView('footer');
?>
