<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div style="clear: both;"></div>
<div id="footer">
		<p>
        Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> 
		<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> 
		<?php echo $footer_info; ?>
       	Design by <a href="http://www.isaced.com/">isaced</a>.
        <?php doAction('index_footer'); ?>
		</p>
</div>

</body>
</html>