﻿<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="page">
<div id="content">
<div class="post">
	<h2 class="title"><?php topflg($top); //显示置顶标记?><a><?php echo $log_title; //日志标题 ?></a></h2>
    <p class="meta">
		<?php echo gmdate('l Y-n-j G:i ', $date); //发布时间 ?> Posted by <?php blog_author($author); //作者?>
		<?php blog_sort($logid); //日志分类?> 
        <?php blog_tag($logid);  //标签?>
	</p>
	<div class="entry">
		<?php echo $log_content;  //文章内容?>
	</div>
    
    <div id="postbottom">
        <div id="nextlog"><?php neighbor_log($neighborLog); ?></div>
        <div id="logdata">
             阅读(<?php echo $views; //浏览量?>)&nbsp;|&nbsp;
            评论(<?php echo $comnum; //评论数 ?>)&nbsp;|&nbsp;
            引用(<?php echo $tbcount; //引用数?>)
            <?php editflg($logid,$author); //编辑?>
        </div>
    </div>
	<?php doAction('log_related', $logData); ?>
	<?php  blog_comments($comments); ?>
	<?php  blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>

	</div><!--end #post-->
</div><!--end #content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>