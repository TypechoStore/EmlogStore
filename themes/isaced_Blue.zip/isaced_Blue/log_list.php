﻿<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<!--文章显示-->
<div id="page">
	<div id="content">
		<?php doAction('index_loglist_top'); ?>
		<?php foreach($logs as $value): ?>
			<div class="post">
            
				<h2 class="title">
					<a href="<?php  echo $value['log_url']; //文章地址?>">
						<?php echo $value['log_title']; //文章标题?>
					</a>
				</h2>
				
				<p class="meta">
					<?php echo gmdate('Y-n-j G:i l', $value['date']); //发布时间 ?> Posted by <?php blog_author($author); //作者?>
				</p>
				
				<div class="entry">
					<?php echo $value['log_description'];  //文章内容?>
				</div>
                
		  </div> 
		<?php endforeach; ?>
		
		<div id="navigation">
        	<?php echo $page_url;?>
		</div>
	</div><!--end #content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>