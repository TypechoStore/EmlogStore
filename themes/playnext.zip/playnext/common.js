eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('6(1O!=11){11.12=1O.12}7 2w="";$(A).2x(9(){$(\'#2y,.13-1z .2z,#1P-2A 1Q 1R,#1P-2B 1Q 1R a\').1S();$(\'.13-2C .13\').1g(9(){$(F).1o(\'.13-1z\').1T()},9(){$(F).1o(\'.13-1z\').1U()});$(\'.1A\').1g(9(){$(F).1o(\'.1A-1V-1B\').1T()},9(){$(F).1o(\'.1A-1V-1B\').1U()})});9 2D(a){7 b,17,18;7 c=Y(1C 1W().2E()/1X);7 d;d=c-a;1p=Y(d/2F);18=Y(d/2G);17=Y(d/2H);b=Y(d/2I);6(1p>0&&1p<4){y 1p+"周前"}w 6(18>0&&18<4){y 18+"天前"}w 6(18<=0&&17>0){y 17+"小时前"}w 6(17<=0&&b>0){y b+"分钟前"}w 6(17<=0&&b==0){y"刚刚"}w{7 s=1C 1W(a*1X);y(s.2J()+1)+"月"+s.2K()+"日"}}9 J(b){6(2L(1Y)==\'2M\'){7 c=""}w{7 c=1Y}6(c==""){7 f=1C 2N();$(\'#13-2O 2P\').1Z(9(a){f[a]=$(F).2Q("2R")});6(f){c=f[0]}}7 g=19(A.12.G);7 h=19(A.z);6(b=="2S"){21(A.z);y}w 6(b=="1D"){K.L([\'M\',\'N\',\'O\',\'2T\',1]);B.P(\'Q://2U.1D.1E.T/2V-2W/2X/2Y?15=\'+g);y}w 6(b=="1F"){K.L([\'M\',\'N\',\'O\',\'22\',1]);B.P(\'Q://1F.T/2Z?1h=\'+h+19(\' \')+g,\'14\');y}w 6(b=="23"){K.L([\'M\',\'N\',\'O\',\'30\',1]);B.P("Q://24.31.T/1i/1i.25?15="+g+"&26=&z="+h+"&27="+c+"&32=33","14","1a=34,1b=35");y}w 6(b=="28"){K.L([\'M\',\'N\',\'O\',\'36\',1]);B.P(\'Q://37.1E.T/13?38=3&39=2&3a=1&3b=\'+g+\'&z=\'+h,\'14\',\'1a=3c,1b=3d,1c=29,11=29,1G=X,2a=X,12=X,1q=1d,1h=1d,1r=1d\');y}w 6(b=="1H"){K.L([\'M\',\'N\',\'O\',\'3e\',1]);B.P(\'Q://3f.1H.T/3g/3h?3i=\'+h+\'&3j=\'+g+\'&3k=3l#3m=1\',\'14\',\'1q=X,1a=3n,1b=2b,1c=3o,11=20,1h=X,1r=1d\');y}w 6(b=="2c"){K.L([\'M\',\'N\',\'O\',\'3p\',1]);B.P(\'Q://1j.3q.T/3r/13?15=\'+g+\'&3s=\'+c);y}w 6(b=="1s"){K.L([\'M\',\'N\',\'O\',\'3t\',1]);7 d=A,e=19,1I=B.2d,1J=d.2d,1K=d.3u,s=1I?1I():1J?1J():1K?1K.3v().3w:\'\',r=\'Q://1j.1s.T/3x/?15=\'+e(d.12.G)+\'&z=\'+e(d.z)+\'&3y=\'+e(s)+\'&v=1\',x=9(){6(!B.P(r,\'1s\',\'1G=0,1r=1,1q=1d,1h=1,1a=2b,1b=3z\'))12.G=r+\'&r=1\'};6(/3A/.3B(3C.3D)){3E(x,0)}w{x()}y}w 6(b=="1L"){K.L([\'M\',\'N\',\'O\',\'3F\',1]);B.P(\'Q://1j.3G.1L.T/1i/3H?15=\'+g+\'&z=\'+h,\'14\');y}w 6(b=="2e"){K.L([\'M\',\'N\',\'O\',\'3I\',1]);B.P(\'Q://2e.T/24/3J/?1B=\'+g+\'&z=\'+h,\'14\');y}w 6(b=="2f"){K.L([\'M\',\'N\',\'O\',\'3K\',1]);B.P(\'Q://1j.3L.T/3M/3N.3O?z=\'+h+\'&15=\'+g,\'14\',\'1a=3P,1b=3Q\');y}w 6(b=="2g"){K.L([\'M\',\'N\',\'O\',\'3R\',1]);B.P(\'3S:?3T=\'+h+\'&3U=\'+19(\'这是我看到了一篇很不错的文章，分享给你看看！\\r\\n\\r\\n\')+h+19(\'\\r\\n\')+g);y}w 6(b=="2h"){K.L([\'M\',\'N\',\'O\',\'3V\',1]);7 i=3W("3X");B.P(\'Q://v.t.1E.T/1i/1i.25?z=\'+h+\'&3Y=Q://1j.3Z.40/&26=\'+i+\'&27=\'+c+\'&15=\'+g,\'14\',\'1a=41, 1b=42, 11=0, 1c=0, 1G=X, 2a=X, 1q=X, 12=1d, 1r=X, 1h=X\');y}}9 21(a){7 b=43.12.G;6(B.2i){B.2i.44(a,b,"")}w 6(A.45){B.46.47(b,a)}w 6(B.48){y 49}w{4a(\'请按 4b + D 为4c浏览器添加书签!\')}}9 4d(){A.I(\'<2j R="4e">\');A.I(\'<a R="U" V="4f" G="W:J(\\\'1D\\\');" z="分享到1M空间"></a>\');A.I(\'<a R="U" V="4g" G="W:J(\\\'2h\\\');" z="分享到 1M 腾讯微博"></a>\');A.I(\'<a R="U" V="4h" G="W:J(\\\'23\\\');" z="分享到新浪微博"></a>\');A.I(\'<a R="U" V="4i" G="W:J(\\\'28\\\');" z="收藏到1M书签"></a>\');A.I(\'<a R="U" V="4j" G="W:J(\\\'1L\\\');" z="分享到人人网"></a>\');A.I(\'<a R="U" V="4k" G="W:J(\\\'1F\\\');" z="分享到22"></a>\');A.I(\'<a R="U" V="4l" G="W:J(\\\'1H\\\');" z="收藏到 - 百度搜藏"></a>\');A.I(\'<a R="U" V="4m" G="W:J(\\\'2c\\\');" z="分享到 4n 4o"></a>\');A.I(\'<a R="U" V="4p" G="W:J(\\\'1s\\\');" z="分享到豆瓣"></a>\');A.I(\'<a R="U" V="4q" G="W:J(\\\'2f\\\');" z="分享到嘀咕"></a>\');A.I(\'<a R="U" V="4r" G="W:J(\\\'2g\\\');" z="发送邮件分享给朋友"></a>\');A.I(\'</2j>\')}(9($){$.4s.1S=9(s){7 t={2k:2,2l:2,2m:1,2n:10,1k:\'1g\',2o:\'1c\',2p:\'11\'};7 u=$.4t(t,s);y F.1Z(9(){$Z=$(F);7 f;7 g=u.2k;7 h=u.2l;7 i=u.2m;g=g*2;h=h*2;i=i*2;7 j=u.2n;7 k=$Z.8(\'1l\');7 l=u.2o;7 m=u.2p;7 n;7 o;7 p;6(l===\'1c\'){n=Y($Z.8(\'1c\'),10)}6(l===\'2q\'){n=Y($Z.8(\'2q\'),10)}6(m===\'11\'){o=Y($Z.8(\'11\'),10)}6(m===\'2r\'){o=Y($Z.8(\'2r\'),10)}9 1m(a){7 b=16.1t();7 c=16.1N(16.1t()*(g+1))-g/2;7 d=16.1N(16.1t()*(h+1))-h/2;7 e=16.1N(16.1t()*(i+1))-i/2;6(a.8(\'1e\')===\'1f\'){p=1n;a.8(\'1e\',\'1f-4u\')}6(c===0&&g!==0){6(b<.5){c=1}w{c=-1}}6(d===0&&h!==0){6(b<.5){d=1}w{d=-1}}6(k===\'2s\'){a.8({\'1l\':\'2s\',\'-1u-C\':\'E(\'+e+\'S)\',\'-1v-C\':\'E(\'+e+\'S)\',\'-o-C\':\'E(\'+e+\'S)\',\'C\':\'E(\'+e+\'S)\'});a.8(l,n+c+\'H\');a.8(m,o+d+\'H\')}6(k===\'2t\'){a.8({\'1l\':\'2t\',\'-1u-C\':\'E(\'+e+\'S)\',\'-1v-C\':\'E(\'+e+\'S)\',\'-o-C\':\'E(\'+e+\'S)\',\'C\':\'E(\'+e+\'S)\'});a.8(l,n+c+\'H\');a.8(m,o+d+\'H\')}6(k===\'4v\'||k===\'2u\'){a.8({\'1l\':\'2u\',\'-1u-C\':\'E(\'+e+\'S)\',\'-1v-C\':\'E(\'+e+\'S)\',\'-o-C\':\'E(\'+e+\'S)\',\'C\':\'E(\'+e+\'S)\'});a.8(l,c+\'H\');a.8(m,d+\'H\')}}7 q={\'1l\':k,\'-1u-C\':\'E(1w)\',\'-1v-C\':\'E(1w)\',\'-o-C\':\'E(1w)\',\'C\':\'E(1w)\'};6(u.1k===\'1g\'){$Z.1g(9(){7 a=$(F);f=1x(9(){1m(a)},j)},9(){7 a=$(F);1y(f);a.8(q);a.8(l,n+\'H\');a.8(m,o+\'H\');6(p===1n){a.8(\'1e\',\'1f\')}})}6(u.1k===\'4w\'){$Z.4x(9(){7 a=$(F);f=1x(9(){1m(a)},j)},9(){7 a=$(F);1y(f);a.8(q);a.8(l,n+\'H\');a.8(m,o+\'H\');6(p===1n){a.8(\'1e\',\'1f\')}})}6(u.1k===\'2v\'){$Z.4y({2v:9(){7 a=$(F);f=1x(9(){1m(a)},j)},4z:9(){7 a=$(F);1y(f);a.8(q);a.8(l,n+\'H\');a.8(m,o+\'H\');6(p===1n){a.8(\'1e\',\'1f\')}},4A:9(){7 a=$(F);1y(f);a.8(q);a.8(l,n+\'H\');a.8(m,o+\'H\');6(p===1n){a.8(\'1e\',\'1f\')}}})}6(u.1k===\'4B\'){7 r=$(F);f=1x(9(){1m(r)},j)}})}})(4C);',62,287,'||||||if|var|css|function|||||||||||||||||||||||else||return|title|document|window|transform||rotate|this|href|px|write|shareto|_gaq|push|_trackEvent|SocialShare|Share|open|http|class|deg|com|sharebutton|id|javascript|no|parseInt|obj||top|location|post|_blank|url|Math|d_hours|d_days|encodeURIComponent|width|height|left|yes|display|inline|hover|status|share|www|rumbleEvent|position|rumbler|true|find|d_weeks|scrollbars|resizable|douban|random|webkit|moz|0deg|setInterval|clearInterval|menu|comment|link|new|qzone|qq|twitter|toolbar|baidu|s1|s2|s3|renren|QQ|floor|self|header|ul|li|jrumble|show|hide|reply|Date|1000|shareto_img|each||addBookmark|Twitter|sina|service|php|appkey|pic|qqshuqian|50|menubar|450|googlebuzz|getSelection|xianguo|digu|mail|tqq|sidebar|div|rangeX|rangeY|rangeRot|rumbleSpeed|posX|posY|right|bottom|absolute|fixed|relative|mousedown|strBatchView|ready|logo|readmore|nav|icons|list|timeAgo|getTime|604800|86400|3600|60|getMonth|getDate|typeof|undefined|Array|content|img|attr|src|fav|QZone|sns|cgi|bin|qzshare|cgi_qzshare_onekey|home|SinaT|weibo|ralateUid|1642980755|615|505|QQShuqian|shuqian|from|jumpback|noui|uri|930|570|Baidu|cang|do|add|it|iu|fr|ien|nw|600|75|GoogleBuzz|google|buzz|imageurl|Douban|selection|createRange|text|recommend|sel|330|Firefox|test|navigator|userAgent|setTimeout|RenRen|connect|sharer|XianGuo|submitdigg|Digu|diguff|diguShare|bookMark_FF|jsp|580|310|Mail|mailto|subject|body|TQQ|encodeURI|468235b5feec4c5a9b02e4fbe679fa52|site|playnext|cn|700|680|parent|addPanel|all|external|AddFavorite|opera|false|alert|Ctrl|Chrome|ShareButtons|social_share|share_qzone|share_tqq|share_sina|share_qqshuqian|share_renren|share_twitter|share_baidu|share_googlebuzz|Google|Buzz|share_douban|share_digu|share_mail|fn|extend|block|static|click|toggle|bind|mouseup|mouseout|constant|jQuery'.split('|'),0,{}))


/* Toggle and Smiles */
$(function(){$(".title-list ul").children("li").each(function(a){$(this).mousemove(function(){$(".content-list").each(function(b){b==a?$(this).slideDown():$(this).slideUp()})})});$(".logo").click(function(){var a=$(this).css("left")=="20px"?($.browser.msie?document.compatMode=="CSS1Compat"?document.documentElement.clientWidth:document.body.clientWidth:self.innerWidth)-178:20;$(this).animate({left:a+"px"},1E3)});$("#smiles img").click(function(){var a=$(this).attr("id");$("#comment").insertAtCaret("|"+
a+"|")});$(document).keypress(function(a){(a.ctrlKey&&a.which==13||a.which==10)&&$("#comment_submit").click()})});function toggleInput(){$("#userinfo").toggle("normal");return!1};
(function(q){q.fn.extend({insertAtCaret:function(a){var c=
q(this)[0];if(document.selection)this.focus(),sel=document.selection.createRange(),sel.text=a,this.focus();else if(c.selectionStart||c.selectionStart=="0"){var h=c.selectionStart,g=c.selectionEnd,i=c.scrollTop;c.value=c.value.substring(0,h)+a+c.value.substring(g,c.value.length);this.focus();c.selectionStart=h+a.length;c.selectionEnd=h+a.length;c.scrollTop=i}else this.value+=a,this.focus()}})})(jQuery);

(function($){
  //goToTop
  var scrolltotop={
    setting: {startline:350, scrollto: 0, scrollduration:500, fadeduration:[500, 100]},
    controlHTML: ' ', 
    controlattrs: {offsetx:10, offsety:10}, 
    anchorkeyword: '#top', 
    state: {isvisible:false, shouldvisible:false},
    scrollup:function(){
      if (!this.cssfixedsupport) 
        this.$control.css({opacity:0}) 
      var dest=isNaN(this.setting.scrollto)? this.setting.scrollto : parseInt(this.setting.scrollto)
      if (typeof dest=="string" && jQuery('#'+dest).length==1) 
        dest=jQuery('#'+dest).offset().top
      else
        dest=0
    this.$body.animate({scrollTop: dest}, this.setting.scrollduration);
    },
    keepfixed:function(){
      var $window=jQuery(window);
      var controlx=$window.scrollLeft() + $window.width() - this.$control.width() - this.controlattrs.offsetx;
      var controly=$window.scrollTop() + $window.height() - this.$control.height() - this.controlattrs.offsety;
      this.$control.css({left:controlx+'px', top:controly+'px'});
    },
    togglecontrol:function(){
      var scrolltop=jQuery(window).scrollTop()
      if (!this.cssfixedsupport)
        this.keepfixed()
      this.state.shouldvisible=(scrolltop>=this.setting.startline)? true : false
      if (this.state.shouldvisible && !this.state.isvisible){
        this.$control.stop().animate({opacity:1}, this.setting.fadeduration[0])
        this.state.isvisible=true
      }
      else if (this.state.shouldvisible==false && this.state.isvisible){
        this.$control.stop().animate({opacity:0}, this.setting.fadeduration[1])
        this.state.isvisible=false
      }
    },
    init:function(){
      jQuery(document).ready(function($){
        var mainobj=scrolltotop
        var iebrws=document.all
        mainobj.cssfixedsupport=!iebrws || iebrws && document.compatMode=="CSS1Compat" && window.XMLHttpRequest 
        mainobj.$body=(window.opera)? (document.compatMode=="CSS1Compat"? $('html') : $('body')) : $('html,body')
        mainobj.$control=$('<div id="gotop"><a>'+mainobj.controlHTML+'</a></div>')
          .css({position:mainobj.cssfixedsupport? 'fixed' : 'absolute', bottom:mainobj.controlattrs.offsety, right:mainobj.controlattrs.offsetx, opacity:0, cursor:'pointer'})
          .attr({title:'回到顶部'})
          .click(function(){mainobj.scrollup(); return false})
          .appendTo('body')
        if (document.all && !window.XMLHttpRequest && mainobj.$control.text()!='') 
          mainobj.$control.css({width:mainobj.$control.width()}) 
        mainobj.togglecontrol()
        $('a[href="' + mainobj.anchorkeyword +'"]').click(function(){
          mainobj.scrollup()
          return false
        })
        $(window).bind('scroll resize', function(e){
          mainobj.togglecontrol()
        })
      })
    }
  };
  scrolltotop.init()
})(jQuery);