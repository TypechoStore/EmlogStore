<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?> 
<div class="content">

<div class="post">		
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>	<div id="crumb">
				<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
			<p><?php echo $value['log_description']; ?></p>
			<p style="color:#AEAFAF;">生产日期：<?php echo gmdate('Y-n-j'); ?> &nbsp;&nbsp;&nbsp;作者：<?php blog_author($value['author']); ?> &nbsp;&nbsp;&nbsp; 文章热度：<?php echo $value['views']; ?> ℃</p></div>
	<div style="clear:both;"></div>
<?php endforeach; ?>
<div id="pagenavi">
<?php echo $page_url;?>		
</div>	
</div>

</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>