﻿<?php
/*
Template Name:低调的异次元
Description:一份.蓝白.简洁的主题,主题中木有碎语页面。
Version:1.0
Author:易牛娃应用世界
Author Url:http://www.eniuwa.com
Sidebar Amount:1
ForEmlog:4.2.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="zh-CN">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta charset="UTF-8">
<link rel="icon" href="<?php echo BLOG_URL; ?>favicon.ico" type="image/x-icon">
<link type="text/css" href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" />
<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
<script type="text/javascript">var _gaq=_gaq||[];</script> 
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/common.js"></script> 
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="main">
<div id="header">
<div id="header-container">
<div id="header-left">
<h1 id="logo" style="left: 2px; top: 2px; position: static; -webkit-transform: rotate(0deg); "><a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>"><?php echo $blogname; ?></a></h1>
<!--LOGO-->
</div>
<div id="header-right">
<div id="header-icons">
<ul> <!--右上角四个链接-->
<li><a class="icon-ips" target="_blank" title="易牛娃应用世界" href="http://www.eniuwa.com/" style="left: 2px; top: 2px; position: static; -webkit-transform: rotate(0deg); ">易牛娃应用世界</a></li>
<li><a class="icon-ipc" target="_blank" title="" href="" style="left: -1px; top: -2px; position: static; -webkit-transform: rotate(0deg); ">iPc.me</a></li>
<li><a class="icon-zhaofile" target="_blank" title="" href="" style="position: static; -webkit-transform: rotate(0deg); ">找文件网盘搜索</a></li>
<li><a class="icon-rss" target="_blank" title="" href="" style="left: -1px; top: 1px; position: static; -webkit-transform: rotate(0deg); ">订阅</a></li>
</ul>
</div>
</div>
<div class="clear"></div>
<div id="header-nav">
<ul>
<li><a  class="current" href="<?php echo BLOG_URL; ?>"<?php echo $pageurl == BLOG_URL."page" ? '' : 'thisnav';?> >首页</a></li>
<?php 
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach ($navi_cache as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	$val['is_blank'] = $val['newtab'] == 'y' ? 'target="_blank"' : '';
    $val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
	?>
	<li class="<?php echo isset($logid) && $key == $logid ? 'current' : 'common';?>"><a href="<?php echo $val['url']; ?>" target="<?php echo $val['is_blank']; ?>"><?php echo $val['naviname']; ?></a></li>
	<?php endforeach;?>
</ul>
<form name="keyform" method="get" action="index.php">
<div class="header-search">
<input class="search-text-box" type="text" name="keyword" onblur="if(this.value==&#39;&#39;){this.value=&#39;搜索神马的最有爱了...&#39;;}" onfocus="this.value=&#39;&#39;;" value="搜索神马的最有爱了..." size="31"> 
<input type="submit" onmouseover="" onmouseout="" class="header-search-normal"  value="">
</div>
</form>
</div>
<div class="clear"></div>
</div>
</div><!-- id /header-->
<div id="crumb">
<a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>">首页</a>><?php blog_sort($logid); ?>><?php echo $log_title; ?>
</div>