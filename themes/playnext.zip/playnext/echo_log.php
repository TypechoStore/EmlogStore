<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="content">
<div id="post">
	<h1><?php topflg($top); ?><?php echo $log_title; ?></h1>
	<script type="text/javascript">ShareButtons();</script> 
	<div id="post-content"><?php echo $log_content; ?><center>
	<?php neighbor_log($neighborLog); ?></center>
	</div>
<div id="post-meta">
<div class="box-title"><span>文章属性</span></div>
<ul>
<li>文章热度：<?php echo $views; ?> ℃</li>
<li><p class="tag"><?php blog_tag($logid); ?></p></li>
<li>作者：<?php blog_author($author); ?> &nbsp;&nbsp;生产日期：<?php echo gmdate('Y-n-j G:i l', $date); ?> 
<li></li>
</ul>
</div>
	<?php doAction('log_related', $logData); ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>