<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="clear"></div>
<div class="row" >
<div class="content col_12 col">
	<?php doAction('index_loglist_top'); ?>
	<?php foreach($logs as $value): ?>
	            <article>
				<h2 id="post-<?php echo $value['logid'];?> "><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
               		<small>
					  <?php echo gmdate('Y 年-n 月-j 日 G:i l', $value['date']); ?>
					  <?php blog_sort($value['logid']); ?>  | <a title="《<?php echo $value['log_title']; ?>》上的评论"  
					  class="commentslink" href="<?php echo $value['log_url']; ?>#comments">(<?php echo $value['comnum']; ?>)条评论</a>			
					 </small>
				   
				    <div class="content">
				<?php echo $value['log_description']; ?>
				</div>
			<p>关键字：<?php blog_tag($value['logid']); ?></p> 						          
			 </article>
	<?php endforeach; ?>
	<div class="pagebar">
		<?php echo $page_url;?>
		 </div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>