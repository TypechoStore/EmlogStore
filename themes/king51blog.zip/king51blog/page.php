<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="row" >
<div class="content col_12 col">
<article class="single">
			<h1 id="post-<?php echo $value['logid'];?> "><?php echo $log_title; ?></h1>				
            		
            <div class="content">
			<?php echo $log_content; ?>
			<?php blog_att($logid); ?>
			</div>			                        
 	  </article>		
	<article>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</article>
	</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>