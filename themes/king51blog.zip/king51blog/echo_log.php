<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="row" >
<div class="content col_12 col">
<article class="single">
			<h1 id="post-<?php echo $logid;?> "><?php topflg($top); ?><?php echo $log_title; ?></h1>				
            		<small>
					  <?php echo date('Y-n-j G:i l', $date); ?> 
					  <?php blog_sort($logid); ?>  | <a title="《<?php echo $log_title; ?>》上的评论"  
					  class="commentslink" href="<?php echo Url::log($logid); ?>#comments">(<?php echo $comnum; ?>)条评论</a>			
					 </small>
            <div class="content">
			<?php echo $log_content; ?>
			<?php blog_att($logid); ?>
			</div>
			<p><?php blog_tag($logid); ?></p>                         
			<?php doAction('log_related', $logData); ?>
     </article>	
	<!--<div id="respond">这个应该是评论框的ID，放此处不合适，下面缺少一个article-->
	<article>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</article>
	</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>