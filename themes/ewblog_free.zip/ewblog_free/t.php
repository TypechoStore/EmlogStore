<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="section" class="box">
		<!-- CONTENT -->
		<div id="content">
			<div class="aticle-text padding">
抱歉，暂无此功能！<br /><br />如需获取支持，请前往 <a href="http://www.ewceo.com/" target="_blank">www.ewceo.com</a> 联系模板作者<br /><br />详情也可见模板文件包内说明文件
			</div> <!-- /padding -->
		</div> <!-- /content -->
<?php
 include View::getView('side');
?>
	</div> <!-- /section -->
<?php
 include View::getView('footer');
?>