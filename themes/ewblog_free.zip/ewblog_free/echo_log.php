<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="section" class="box">
		<!-- CONTENT -->
		<div id="content">
			<div class="main-title box">
				<h1><?php topflg($top); ?><?php echo $log_title; ?></h1>
			</div>
            <div class="aticle-info">
            <?php editflg($logid,$author); ?><?php blog_author($author); ?> / <?php echo gmdate('n-j G:i', $date); ?> / <?php blog_sort($logid); ?> / <?php blog_tag($logid); ?>
            </div>
			<div class="aticle-text padding">
				<?php echo $log_content; ?>
<?php doAction('log_related', $logData); ?>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>	
			</div> <!-- /padding -->
		</div> <!-- /content -->
<?php
 include View::getView('side');
?>
	</div> <!-- /section -->
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
<?php
 include View::getView('footer');
?>