<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="section" class="box">
		<!-- CONTENT -->
		<div id="content">
			<div class="main-title box">
				<h1><?php echo $log_title; ?></h1>
			</div>
			<div class="aticle-text padding">
				<?php echo $log_content; ?>
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>	
			</div> <!-- /padding -->
		</div> <!-- /content -->
<?php
 include View::getView('side');
?>
	</div> <!-- /section -->
<?php
 include View::getView('footer');
?>