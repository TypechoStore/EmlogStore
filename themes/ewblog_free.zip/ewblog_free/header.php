<?php
/*
Template Name:Ew渐变色彩[免费版]
Description:一款渐变色质感博客风格模板，详情见模板包内说明.TXT
Version:1.5
Author:尔今
Author Url:http://www.ewceo.com
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
if(function_exists('emLoadJQuery')) {
    emLoadJQuery();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>css/main.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>css/skin_blue.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<!--[if IE 6]><script src="<?php echo TEMPLATE_URL; ?>js/pngfix.js"></script><![endif]-->
<?php doAction('index_head'); ?>
<script type="text/javascript">
var datn = ".js";
document.writeln(unescape("%3Cscript src='<?php echo TEMPLATE_URL; ?>js/e" + datn + "' type='text/javascript'%3E%3C/script%3E"));
<?php
if(!empty($tws)){
	$xylgimg='../content/templates/ewblog_free/images/logo.png';
}
else{
	$xylgimg='content/templates/ewblog_free/images/logo.png';
}
if(file_exists($xylgimg)){
	echo <<<html
$(function(){
$("#logo .plg").show();
});
html;
}
else{
	echo <<<html
$(function(){
$("#logo .tlg").show();
});
html;
}
?>
</script>
</head>
<body>
<div id="main">
	<!-- HEADER -->
	<div id="header" class="box">
		<p id="logo"><a href="<?php echo BLOG_URL; ?>"><span class="tlg"><?php echo $blogname; ?></span><span class="plg"><img src="<?php echo TEMPLATE_URL; ?>images/logo.png" alt="<?php echo $blogname; ?>" /></span></a></p>
		<h3 id="slogan"><?php if(ROLE == 'admin' || ROLE == 'writer'): ?><a href="<?php echo BLOG_URL; ?>admin/">管理</a>&nbsp;/&nbsp;<a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a>&nbsp;&nbsp;&nbsp;<?php else: ?><a href="<?php echo BLOG_URL; ?>admin/">登录</a>&nbsp;&nbsp;&nbsp;<?php endif; ?><?php echo $bloginfo; ?></h3>
	</div> <!-- /header -->
	<!-- NAVIGATION -->
    <div id="xytop">
        <div id="nav" class="box">
            <ul>
                <?php blog_navi();?>
            </ul>
            <!-- SEARCH -->
            <form action="<?php echo BLOG_URL; ?>index.php" method="get" id="search">
                <div class="relative">
                    <div id="search-input"><input type="text" name="keyword" class="input-text" value="Search..." onFocus="if(value==defaultValue){value='';}" onBlur="if(!value){value=defaultValue;}" x-webkit-speech x-webkit-grammar="builtin:translate" /></div>
                    <div id="search-submit"><input type="image" src="<?php echo TEMPLATE_URL; ?>images/search-submit.png" value="Search" /></div>
                </div> <!-- /relative -->
            </form>
        </div> <!-- /nav -->
        <div id="tray" class="box">
            <p class="f-right">
                <a href="#" id="skinbtn"><img src="<?php echo TEMPLATE_URL; ?>images/skin.png" width="24" title="切换皮肤" /></a>
                <a href="<?php echo BLOG_URL; ?>rss.php"><img src="<?php echo TEMPLATE_URL; ?>images/ico-rss.png" title="RSS" /></a>
            </p>
            <p id="toparrow" class="f-left">
                <a href="<?php echo BLOG_URL; ?>">Home</a><?php if ($params[1]=='sort'){ ?>
    <?php echo '<a href="'.Url::sort($sortid).'">'.$sortName.'</a>';?>
    <?php }elseif ($params[1]=='tag'){ ?>
    <b><?php echo urldecode($params[2]);?></b> 标签下的内容
    <?php }elseif($params[1]=='author'){ ?>
    <b><?php echo blog_author($author);?></b> 的所有内容
    <?php }elseif($params[1]=='keyword'){ ?>
    <span> / </span>搜索 <b><?php echo urldecode($params[2]);?></b> 的结果
    <?php }else{?><?php }?>
    <?php blog_sort($logid); ?><?php if (!empty($logid)) : ?><a href="<?php echo $value['log_url']; ?>"><?php echo $log_title; ?></a><?php endif; ?>
            </p>
        </div>
    </div>