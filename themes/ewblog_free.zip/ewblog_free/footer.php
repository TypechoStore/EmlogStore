<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<!--注意：当前模板免费版需要您保留模板作者信息，强行修改可能导致出错。收费版详情请联系Q77940140或见模板包内说明.TXT文件-->
	<div id="footer" class="box">
		<p class="f-right"><?php systemer();?> &amp; <a href="http://www.emlog.net" target="_blank">emlog</a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?><?php doAction('index_footer'); ?></p>
		<p class="f-left">Copyright &copy;&nbsp;<script>document.write(new Date().getFullYear());</script> <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></p>
	</div> <!-- /footer -->
</div> <!-- /main -->
<a id="totop" href="javascript:void(0)" title="返回顶部">返回顶部</a>
</body>
</html>