<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="section" class="box">
		<!-- CONTENT -->
		<div id="content">
<?php doAction('index_loglist_top'); ?>
<?php 
if (!empty($logs)):
foreach($logs as $key=>$value): 
$search_pattern = '%<img[^>]*?src=[\'\"]((?:(?!\/admin\/|>).)+?)[\'\"][^>]*?>%s';
preg_match($search_pattern, $value['content'], $img);
$value['img'] = isset($img[1])?$img[1]:TEMPLATE_URL.'pic/ap'.rand(1,15).'.jpg';
?>
<?php if($key == 0):?>
			<div id="topstory" class="box">
				<h1><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h1>
				<div class="tag">
					<strong><a href="<?php echo $value['log_url']; ?>#respond" class="views"><?php echo $value['comnum']; ?>/<?php echo $value['views']; ?> Views</a></strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span><?php echo gmdate('n-j G:i', $value['date']); ?> <span>|</span><?php blog_author($value['author']); ?> <span>|</span>  <?php blog_sort($value['logid']); ?></span>
				</div> <!-- /tag -->
				<p>
					<a href="<?php echo $value['log_url']; ?>"><img src="<?php echo $value['img']; ?>" class="f-left" /></a>
					<?php echo subString(strip_tags($value['log_description']),0,260,"..."); ?><a href="<?php echo $value['log_url']; ?>">More &raquo;</a>
				</p>
			</div>
			<div class="padding">
				<ul class="articles box">
<?php else:?>
					<li class="box">
						<div class="articles-img">
							<a href="<?php echo $value['log_url']; ?>"><img src="<?php echo $value['img']; ?>"/></a>
						</div> <!-- /articles-img -->
						<div class="articles-desc">
							<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
							<p class="articles-info"><span class="articles-info-inner"><a href="<?php echo $value['log_url']; ?>#respond"><?php echo $value['comnum']; ?> comments</a> <span>|</span> <?php blog_author($value['author']); ?> <span>|</span> <?php blog_sort($value['logid']); ?></span></p>
							<p class="text"><?php echo subString(strip_tags($value['log_description']),0,120,"..."); ?><a href="<?php echo $value['log_url']; ?>">More &raquo;</a></p>
						</div> <!-- /articles-desc -->
					</li>
<?php endif;?>
<?php 
endforeach;
else:
?>
			<div class="padding">
				<ul class="articles box">
                    <li class="box">
                        <h2>未找到</h2>
                        <p><br />抱歉，没有符合您查询条件的结果。</p>
                    </li>
<?php endif;?>
				</ul>
				<!-- PAGINATION -->
				<div class="pagination box">
						<?php echo $page_url;?>
				</div> <!-- /pagination -->
			</div> <!-- /padding -->
		</div> <!-- /content -->
<?php
 include View::getView('side');
?>
	</div> <!-- /section -->
<?php
 include View::getView('footer');
?>