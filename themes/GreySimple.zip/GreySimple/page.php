<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="main">
	<h2><?php echo $log_title; ?></h2>
	<?php echo $log_content; ?>
	<p class="att"><?php blog_att($logid); ?></p><br />
	<?php blog_comments($comments); ?><br />
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
</div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>