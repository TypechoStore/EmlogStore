<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="main">
					<div class="post-<?php echo $value['logid']?>" id="post-<?php echo $value['logid']?>">
				<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
				<div class="meta">作者：<?php blog_author($author); ?>  | 分类：<?php blog_sort($logid); ?>  | 标签：<?php blog_tag($logid); ?>  | <?php editflg($logid,$author); ?>  <?php echo gmdate('Y-n-j', $date); ?></div>
					<div id="post_content"><?php echo $log_content; ?>
					</div>
				
			</div><hr>
			<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
				<div class="sponsor">
			<a href="http://zhangziheng.com" target="_blank">
			广告位</a>
		</div>
		<div id="comments">	
			<?php doAction('log_related', $logData); ?>
	
	
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>							
		</div>	</div>


<?php
 include View::getView('side');
 include View::getView('footer');
?>