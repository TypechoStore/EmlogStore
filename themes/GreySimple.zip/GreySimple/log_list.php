<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="main">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>


		<ul id="post_list">
		<li class="post-63 post type-post status-publish format-standard hentry category-industry-news">
<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
	<div class="meta"><?php echo gmdate('Y-n-j', $value['date']); ?></div>
	<div class="excerpt"><?php echo $value['log_description']; ?>
	<div class="meta">作者：<?php blog_author($value['author']); ?> | 分类目录:<?php blog_sort($value['logid']); ?> | 标签：<?php blog_tag($value['logid']); ?></div>
	<div class="comments_num"><a href="<?php echo $value['log_url']; ?>#comments" title="《<?php echo $value['log_title']; ?>》上的评论"><?php echo $value['comnum']; ?></a></div>
	</div>
		</li>
	</ul>

<?php endforeach; ?>


<div class="manu"><span class="disabled"> <  Prev</span><?php echo $page_url;?></div>


</div><!-- end #contentleft-->
<div id="sidebar">
</div>


<?php
 include View::getView('side');
 include View::getView('footer');
?>
