<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--end #content-->
<div style="clear:both;"></div>
<div id="footer">
POWERED BY <a href="http://emlog.net">EMLOG</a><?php doAction('index_footer'); ?>
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a><?php echo $footer_info; ?></div>
<!--end #footerbar-->


</div><!--end #wrap-->
</body>
</html>