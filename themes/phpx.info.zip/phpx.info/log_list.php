
	
	

<div id="wrapper">
	<!-- start page -->
	<div id="page">
	<div id="page-bgtop">
	<div id="page-bgbtm">
    <div id="sidebar1" class="sidebar">

			
</div>
		
	  <!-- start content -->
	  <div id="content">
			<div class="flower"></div>
                <?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
		<div class="post">
				<h1 class="title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h1>
				<p class="byline">作者：<?php blog_author($value['author']); ?> 发布于：<?php echo gmdate('Y-n-j G:i l', $value['date']); ?> 
	<?php blog_sort($value['logid']); ?> 
	<?php editflg($value['logid'],$value['author']); ?></p>
    
				<div class="entry">
					<p><?php echo $value['log_description']; ?></p>
				  <p class="links">
				  <p class="att"><?php blog_att($value['logid']); ?></p>
	<p class="tag"><?php blog_tag($value['logid']); ?></p>
	<p class="count">        
                    <a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a>
	<a href="<?php echo $value['log_url']; ?>#tb">引用(<?php echo $value['tbcount']; ?>)</a>
	<a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a>				</div>
			    
			</div><?php endforeach; ?>
<div id="pagenavi"><?php echo $page_url;?></div></div>
		<!-- end content -->
		<!-- start sidebars -->
	
<?php  include View::getView('side');?>
	
	
	
<div style="clear: both;">&nbsp </div>
	</div>
	</div>
	</div>
	<!-- end page -->
<?php  include View::getView('footer');?>