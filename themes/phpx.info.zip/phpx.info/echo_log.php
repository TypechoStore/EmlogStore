<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<link href="php.css" rel="stylesheet" type="text/css" />

<div id="wrapper">
	<!-- start page -->
	<div id="page" >
	<div id="page-bgtop">
	<div id="page-bgbtm" >
	<div id="sidebar1" class="sidebar"></div>
		
		<!-- start content -->
	  <div id="content2" align="center"  >
			<div class="flower"></div>
               

		<div class="post" >
				<h1 class="title" ><?php topflg($top); ?><?php echo $log_title; ?></h1>
				<p class="byline">作者：<?php blog_author($author); ?> 发布于：<?php echo gmdate('Y-n-j G:i l', $date); ?> 
	<?php blog_sort($logid); ?> <?php editflg($logid,$author); ?></p>
    
				<div class="entry">
                
					<p><?php echo $log_content; ?></p>
                    
				 <p class="att"><?php blog_att($logid); ?></p>
                 
	<p class="tag"><?php blog_tag($logid); ?></p>
    
	
    
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
			    
			</div></div>
		<!-- end content -->
		<!-- start sidebars -->
	
<?php  include View::getView('side');?>
	
	
	<?php doAction('log_related', $logData); ?>
<div style="clear: both;">&nbsp </div>
	</div>
	</div>
	</div>
	<!-- end page -->
<?php  include View::getView('footer');?>