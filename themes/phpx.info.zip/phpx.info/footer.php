<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>


</div>
<div id="footer">
<p class="copyright">&copy;&nbsp;&nbsp;2012-2025 All Rights Reserved<a href="http://www.phpx.info" target="_blank">php学习小站</a>  Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a><?php echo $footer_info; ?> 
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?><?php doAction('index_footer'); ?></p>

</div>
</body>
</html>