<?php
/*
Template Name:phpx模板
Description:简洁优雅 ……
Version:1.0
Author:phpx.info
Author Url:http://www.phpx.info
Sidebar Amount:1
ForEmlog:4.2.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN""http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<link href="<?php echo TEMPLATE_URL; ?>php.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>

<!-- start header -->
<div id="header">
	<div id="logo">
		<h1><a href="<?php echo BLOG_URL; ?>"><span><?php echo $blogname; ?></a></h1>
		<p><?php echo $bloginfo; ?></p>
	</div>
	<div id="menu">
		<ul id="main">
			<?php indexa(2);  ?>
            
		</ul>
		<ul id="feed">
		<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
	<li class="common"><a href="<?php echo BLOG_URL; ?>admin/">管理中心</a></li>
	<li class="common"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
	<?php else: ?>
	<li class="common"><a href="<?php echo BLOG_URL; ?>admin/">登录</a></li><?php endif; ?>
		</ul>
	</div>
	
</div>
  <?php
	   function indexa($get_part) {
	global $CACHE;
	$timezone = Option::get('timezone');
	$sort_cache = $CACHE->readCache('sort');
	if ($get_part > 7) //$get_part = 7; //调用超过4个的话，就得改css来适应高度
		$count=0;
		$sort_cache = array_slice($sort_cache,0,7);
		 $curpage == CURPAGE_HOME ? 'current' : 'common';
		 echo "<li class=".$curpage."><a href=".BLOG_URL.">首页$curpage</a></li>";
		/*if($curpage=='HOME'){
echo'<li class="current"><a href="'.BLOG_URL.'">首页$curpage</a></li>'.$curpage;
}else{echo '<li class="common"><a href="'.BLOG_URL.'">首页</a></li>';}*/
		foreach ($sort_cache as $value){
		$count++;
		$sort = $value['sid'];

if($value['sid']==$_GET['sort']){$a="current";}else{$a="ccommon";}
echo '<li class="'.$a.'"><a href="'.Url::sort($sort).'" target="_blank">'.$value['sortname'].'</a></li>';
}
}


?>