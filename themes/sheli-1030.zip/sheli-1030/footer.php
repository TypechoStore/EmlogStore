<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
</div><?php //---- #main end ---- ?>
<div id="footer">
<div id="foot">
Copyright © 2014 <?php echo $blogname; ?> 版权所有 &nbsp; <?php echo $icp; ?><br />
<?php echo $footer_info;sl();doAction('index_footer');?>
</div><?php //---- #foot end ---- ?>
</div><?php //---- #footer end ---- ?>
</body>
</html>