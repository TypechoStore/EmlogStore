<?php
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(

'logo' => array(
'type' =>'image',
'name' =>'头部LOGO',
'values' => array(TEMPLATE_URL .
'images/logo.png',
),
'description' =>'设置站点头部LOGO,250X60最佳。',
),

'gonggao' => array(
'type' =>'text',
'name' =>'可使用html代码',
'multi' => true,
'default' =>'<p>欢迎各位光临舍力博客，(*^__^*) <br />
想分享本主题请<b style="color: #000;font-weight:normal;"> @</b><strong style="color: #0088DD;"> SL</strong>：  <a href="http://www.shuyong.net/432.html" target="_blank">蓝色经典 主题说明（点击查看）</a><br />
———  <strong>最近更新日期：2014-10-30</strong> ———</p>',
),

'weibo' => array(
'type' =>'text',
'name' =>'请填写新浪微博地址',
'default' =>'http://www.shuyong.net',
),

'tqq' => array(
'type' =>'text',
'name' =>'请填写腾讯微博地址',
'default' =>'http://www.shuyong.net',
),

'qq' => array(
'type' =>'text',
'name' =>'请直接填写QQ号码',
'default' =>'345952779',
),

'email' => array(
'type' =>'text',
'name' =>'请直接填写E-mail',
'default' =>'sheli@shuyong.net',
),

'img' => array(
'type' =>'radio',
'name' =>'文章缩略图调用方式',
'values' => array(
'zwimg' =>'调用正文第一张图片',
'fjimg' =>'调用附件第一张图片',
),
'default' =>'zwimg',
),

'daohang-kg' => array(
'type' =>'radio',
'name' =>'评论上方导航(文章详情页广告)',
'values' => array(
'yes' =>'显示',
'no' =>'隐藏',
),
'default' =>'yes',
),

'newlog_mun' => array(
'type' =>'text',
'name' =>'首页最新日志',
'description' =>'"0"为不显示，在未找到搜索结果页也会显示',
'default' =>'5',
),

'sortlog_mun' => array(
'type' =>'text',
'name' =>'首页分类日志显示数量',
'default' =>'10',
),

'sortlog_id' => array(
'type' =>'sort',
'name' =>'分类日志ID(cms模式)',
'description' =>'"不选"为不显示,排序请在分类中进行',
'multi' =>'true',
),

'top-kg' => array(
'type' =>'radio',
'name' =>'返回顶部图标开关',
'values' => array(
'yes' =>'开启',
'no' =>'关闭',
),
'default' =>'yes',
),

);