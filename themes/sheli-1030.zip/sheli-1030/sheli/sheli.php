<?php
//blog：评论列表 链接已经加入nofollow标签
function blog_comments($comments){extract($comments);if($commentStacks): ?>
<?php endif; ?>
<?php if (_g('daohang-kg') == "yes"): ?><br /><center><script type="text/javascript">daohang()</script></center><?php else: ?><?php endif; ?>
<?php $isGravatar = Option::get('isgravatar');foreach($commentStacks as $cid):$comment = $comments[$cid];$comment['poster'] = $comment['url'] ? '<a href="./content/templates/sheli-1028/url.php?go='.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];?>
<div class="comment" id="comment-<?php echo $comment['cid']; ?>"><a name="<?php echo $comment['cid']; ?>"></a>
<?php if($isGravatar == 'y'): ?><div class="avatar bk"><img src="<?php echo getGravatar($comment['mail']); ?>" /></div><?php endif; ?>
<div class="comment-info"><b><?php echo $comment['poster']; ?> </b> [<a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)" >回复该留言</a>]<br /><span class="comment-time"><?php echo $comment['date']; ?></span>
<div class="comment-content"><?php echo $comment['content']; ?></div>
</div>
<?php blog_comments_children($comments, $comment['children']); ?>
</div>
<?php endforeach; ?>
<div id="pagenavi"><?php echo $commentPageUrl;?></div>
<?php }?>
<?php
//blog：子评论列表 链接已经加入nofollow标签
function blog_comments_children($comments, $children){$isGravatar = Option::get('isgravatar');foreach($children as $child):$comment = $comments[$child];$comment['poster'] = $comment['url'] ? '<a href="./content/templates/sheli-1028/url.php?go='.$comment['url'].'" target="_blank" rel="nofollow">'.$comment['poster'].'</a>' : $comment['poster'];?>
<div class="comment comment-children" id="comment-<?php echo $comment['cid']; ?>"><a name="<?php echo $comment['cid']; ?>"></a>
<div class="zipl"><b><?php echo $comment['poster']; ?></b> 回复于 <?php echo $comment['date']; ?>  [<a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复该留言</a>]
<div class="comment-content"><?php echo $comment['content']; ?></div>
</div>
<?php blog_comments_children($comments, $comment['children']);?>
</div>
<?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
if($allow_remark == 'y'): ?>
<div id="comment-place">
<div class="comment-post" id="comment-post">
<div class="cancel-reply" id="cancel-reply" style="display:none"><a href="javascript:void(0);" onclick="cancelReply()">取消回复</a></div>
<p class="comment-header"><b>发表评论：</b><a name="respond"></a></p>
<form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
<?php if(ROLE == ROLE_VISITOR): ?>
<p><input type="text" name="comname" maxlength="49" value="<?php echo $ckname; ?>" size="22" tabindex="1"><label for="author"><small>昵称</small></label></p>
<p><input type="text" name="commail"  maxlength="128"  value="<?php echo $ckmail; ?>" size="22" tabindex="2"><label for="email"><small>邮件地址 (必填)</small></label></p>
<p><input type="text" name="comurl" maxlength="128"  value="<?php echo $ckurl; ?>" size="22" tabindex="3"><label for="url"><small>个人主页 (选填)</small></label></p>
<?php endif; ?>
<p><textarea name="comment" id="comment" rows="10" tabindex="4"></textarea></p>
<p><?php echo $verifyCode; ?> <input type="submit" id="comment_submit" value="发表评论" tabindex="6" /></p>
<input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/>
</form></div></div><?php endif; ?>
<?php }?>
<?php //分页标题后面加 - 第几页
function page_tit($page){if ($page>=2){ echo ' - 第'.$page.'页'; }}?>
<?php
//获取文章缩略图，先是自定义指定，然后是查找附件图片，最后是随机图片
function sheli_fjimg($logid){
$db = MySql::getInstance();
$thum_pic = EMLOG_ROOT.'/thumpic/'.$logid.'.jpg';
if (is_file($thum_pic)) {
$thum_url = BLOG_URL.'thumpic/'.$logid.'.jpg'; 
}else{
$sqlimg = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$logid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";
//die($sql);
$img = $db->query($sqlimg);
while($roww = $db->fetch_array($img)){
$thum_url=BLOG_URL.substr($roww['filepath'],3,strlen($roww['filepath']));
}if (empty($thum_url)) {
srand((double)microtime()*1000000); 
$randval   =   rand(0,9); 
$thum_url = BLOG_URL.'content/templates/sheli-lanse/images/shuyong_net_wzimg/'.$randval.'.jpg';}
}echo $thum_url;}
?>
<?php
//获取文章中第一张图片，如果没有就调用随机图片
function sheli_zwimg($str){
preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $str, $match);
if(!empty($match[1])){echo $match[1][0];}else{
echo TEMPLATE_URL . 'images/shuyong_net_wzimg/'.rand(0,10).'.jpg';//随机图片路径
}}
?>
<?php //幻灯片
function home_slideshow(){ $db = MySql::getInstance(); $sql = $db->query ("SELECT * FROM ".DB_PREFIX."blog inner join ".DB_PREFIX."sort WHERE hide='n' AND type='blog' AND sortop='y' AND sortid=sid order by date DESC limit 0,5"); while($row = $db->fetch_array($sql)){ if (!empty($row['excerpt'])){ preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['excerpt'], $match); if(empty($match[0][0])) { preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'], $match); } }else{ preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'], $match); } $logpost = !empty($row['excerpt']) ? $row['excerpt'] : ''.$row['content'].''; $num = rand(1,3); $img = isset($match[0][0]) ? $match[0][0] : '<img src="'.TEMPLATE_URL.'images/shuyong_net_hdp/'.$num.'.jpg">'; $date = gmdate('Y年m月d日', $row['date']); $content = strip_tags($logpost,''); $content = mb_substr($content,0,300,'utf-8');$comment = ($row['comnum'] != 0) ? '被吐槽<span>'.$row['comnum'].'</span>次' : '暂无吐槽'; $gid = $row['gid']; $tag = $db -> query("SELECT * FROM ".DB_PREFIX."tag WHERE gid LIKE '%,$gid,%'"); $out .='
<li><a href="'.Url::log($row['gid']).'" title="'.$row['title'].'" >'.$img.'</a><div id="hdp-wz">'.$row['title'].'</div></li>
'; } echo $out; }?><?php function sl(){?><div id="bq">Powered by <a href="<?php echo TEMPLATE_URL; ?>url.php?go=www.emlog.net" title="采用emlog系统" target="_blank">emlog</a> &Designed By <a href="http://www.shuyong.net" title="舍力博客" target="_blank" id="xj">舍力博客</a>.</div><?php if (_g('top-kg') == "yes"): ?><a href="javascript:scroll(0,0)" class="top"><img alt="返回顶部" src="<?php echo TEMPLATE_URL; ?>images/top.gif" /></a><?php else:endif; ?><?php }?>
<?php //分类文章
function sort_log($sortid){
$db = MySql::getInstance();
$sql = $db->query ("SELECT * FROM ".DB_PREFIX."blog WHERE sortid='$sortid' AND type='blog' AND hide='n' order by date DESC limit 0,1");
$row = $db->fetch_array($sql);  
if (!empty($row['excerpt'])){
preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['excerpt'], $match);
if(empty($match[0][0]))
{preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'], $match);}
}else{preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'], $match);}
$logpost = !empty($row['excerpt']) ? $row['excerpt'] : ''.$row['content'].'';
$num = rand(1,$imgnum);
$img = isset($match[0][0]) ? $match[0][0] : '<img src="'.TEMPLATE_URL.'images/shuyong_net_wzimg/'.$num.'.jpg">';
$content = strip_tags($logpost,'');
$content = mb_substr($content,0,68,'utf-8');//
$out .='<div class="sort-tw"><div class="sort-img"><a href="'.Url::log($row['gid']).'" title="'.$row['title'].'"  >'.$img.'</a></div>
<div class="sort-tt"><a href="'.Url::log($row['gid']).'" title="'.$row['title'].'" >'.$row['title'].'</a></div><div class="sort-nr">'.$content.'...</div></div>
';
$sort_log_num = $sort_log_num -1;
$logs = $db->query ("SELECT * FROM ".DB_PREFIX."blog WHERE sortid='$sortid' AND type='blog' AND hide='n' order by date DESC limit 1,10");//1表示从第2篇文章开始，10为数量
while ($trow = $db->fetch_array($logs)){
$date = gmdate('m-d', $trow['date']);
$trow['title'] = mb_substr($trow['title'],0,180,'utf-8');
$out .='<li><p><a href="'.Url::log($trow['gid']).'" title="'.$trow['title'].'">'.$trow['title'].'</a></p><span>'.$date.'</span></li>
';
}echo $out;}?>
<?php
//首页置顶头条
function zdlog1($log_num) {
$db = MySql::getInstance();
$sql = 	"SELECT gid,title,content,date FROM ".DB_PREFIX."blog WHERE type='blog' and sortop='y' ORDER BY `sortop` DESC ,`date` DESC LIMIT 0,$log_num";
$list = $db->query($sql);
while($row = $db->fetch_array($list)){
//$row['content'] = htmlspecialchars($row['content']);
$row['content'] = strip_tags($row['content']);?>
<div id="zdlog1"><ul><li><p1>荐</p1><a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>" target="_blank"><?php echo $row['title']; ?></a></li>
<p><?php echo mb_substr($row['content'],0,60,'utf-8'); ?>...</p></ul></div>
<?php } ?><?php } ?>
<?php //置顶文章
function zdlog(){ require('mun.php'); $db = MySql::getInstance(); $sql = $db->query ("SELECT * FROM ".DB_PREFIX."blog inner join ".DB_PREFIX."sort WHERE hide='n' AND type='blog' AND top='y' AND sortid=sid order by date DESC limit 0,$newlog_mun"); while($row = $db->fetch_array($sql)){ $logpost = !empty($row['excerpt']) ? $row['excerpt'] : ''.$row['content'].''; if (!empty($row['excerpt'])){ preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['excerpt'], $match); if(empty($match[0][0])) { preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'], $match); } }else{ preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'], $match); } $num = rand(1,5); $img = isset($match[0][0]) ? $match[0][0] : '<img src="'.TEMPLATE_URL.'images/shuyong_net_wzimg/'.$num.'.jpg">'; $date = gmdate('Y年m月d日', $row['date']); $content = strip_tags($logpost,''); $content = mb_substr($content,0,200,'utf-8'); $comment = ($row['comnum'] != 0) ? '评论：<small>'.$row['comnum'].'</small>' : '暂无评论'; $gid = $row['gid']; $tag = $db -> query("SELECT * FROM ".DB_PREFIX."tag WHERE gid LIKE '%,$gid,%'"); $out .='
<div class="index_newlog">
<div class="index_newlog_img"><a href="'.Url::log($row['gid']).'" title="'.$row['title'].'"  >'.$img.'</a></div>
<div class="index_newlog_tt"><a href="'.Url::log($row['gid']).'" title="'.$row['title'].'"  >'.$row['title'].'</a></div>       		
<div class="index_newlog_riqi"><i class="icon-clock"></i>'.$date.' &nbsp; <i class="icon-folder-open"></i><a href="'.Url::sort($row['sortid']).'" title="查看 '.$row['sortname'].' 中的全部文章" rel="category tag">'.$row['sortname'].'</a> &nbsp; <i class="icon-file"></i>'.$row['views'].' 次 &nbsp; <i class="icon-bubbles"></i>'.$comment.' </div> 
<div class="index_newlog_nr">'.$content.'...</div>
</div>'; } echo $out; }?>
<?php //最新文章
function newlog(){ require('mun.php'); $db = MySql::getInstance(); $sql = $db->query ("SELECT * FROM ".DB_PREFIX."blog inner join ".DB_PREFIX."sort WHERE hide='n' AND type='blog' AND top='n' AND sortid=sid order by date DESC limit 0,$newlog_mun"); while($row = $db->fetch_array($sql)){ $logpost = !empty($row['excerpt']) ? $row['excerpt'] : ''.$row['content'].''; if (!empty($row['excerpt'])){ preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['excerpt'], $match); if(empty($match[0][0])) { preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'], $match); } }else{ preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'], $match); } $num = rand(1,5); $img = isset($match[0][0]) ? $match[0][0] : '<img src="'.TEMPLATE_URL.'images/shuyong_net_wzimg/'.$num.'.jpg">'; $date = gmdate('Y年m月d日', $row['date']); $content = strip_tags($logpost,''); $content = mb_substr($content,0,150,'utf-8'); $comment = ($row['comnum'] != 0) ? '评论：<small>'.$row['comnum'].'</small>' : '暂无评论'; $gid = $row['gid']; $tag = $db -> query("SELECT * FROM ".DB_PREFIX."tag WHERE gid LIKE '%,$gid,%'"); $out .='
<div class="newlog">
<div class="newlog_tt"><a href="'.Url::log($row['gid']).'" title="'.$row['title'].'"  >'.$row['title'].'</a></div>   
<div class="newlog_img"><a href="'.Url::log($row['gid']).'" title="'.$row['title'].'"  >'.$img.'</a></div>
<div class="newlog_nr">'.$content.'...</div>
<div class="newlog_riqi">发布日期 : '.$date.' &nbsp;|&nbsp; 所属分类 : <a href="'.Url::sort($row['sortid']).'" title="'.$row['sortname'].'" >'.$row['sortname'].'</a> &nbsp;|&nbsp;  被围观'.$row['views'].' 次 &nbsp;|&nbsp; '.$comment.'</div> 
</div>'; } echo $out; }?>
<?php //首页分类文章列表
function sortlogs(){ $db = MySql::getInstance(); global $CACHE; $sort_cache = $CACHE->readCache('sort'); foreach(_g('sortlog_id') as $key => $i){ $key = $key+1;
$out .= '<div id="log">';
$out .= '<ul>';
$out .= '<div id="log-tt"><p>'.$sort_cache[$i]['sortname'].'</p><span><a rel="nofollow" href="'.Url::sort($i).'" title="查看 '.$sort_cache[$i]['sortname'].' 中的全部文章">更多...</a></span></div>';
require('mun.php'); $sortlog_mun = $sortlog_mun -1; $logs = $db->query ("SELECT * FROM ".DB_PREFIX."blog WHERE sortid='$i' AND type='blog' AND hide='n' order by date DESC limit 0,{$sortlog_mun}"); while ($trow = $db->fetch_array($logs)){ $date = gmdate('m-d', $trow['date']); $trow['title'] = mb_substr($trow['title'],0,40,'utf-8'); 
$out .='<li><p><a href="'.Url::log($trow['gid']).'" title="'.$trow['title'].'">'.$trow['title'].'</a></p><span>'.$date.'</span></li>'
; } $out .='</div></ul>'; } echo $out; }?>
<?php
//7天按点击率排行文章
function sheli_hotlogz($log_num) {
$db = MySql::getInstance();
$time = time();
$sql = "SELECT gid,title FROM ".DB_PREFIX."blog WHERE type='blog' AND date > $time - 7*24*60*60 ORDER BY `views` DESC LIMIT 0,$log_num";
$list = $db->query($sql);
while($row = $db->fetch_array($list)){ ?>
<li><a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>"><?php echo $row['title']; ?></a></li>
<?php } ?><?php } ?>
<?php
//30天按点击率排行文章
function sheli_hotlog($log_num) {
$db = MySql::getInstance();
$time = time();
$sql = "SELECT gid,title FROM ".DB_PREFIX."blog WHERE type='blog' AND date > $time - 30*24*60*60 ORDER BY `views` DESC LIMIT 0,$log_num";
$list = $db->query($sql);
while($row = $db->fetch_array($list)){ ?>
<li><a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>"><?php echo $row['title']; ?></a></li>
<?php } ?><?php } ?>
<?php
//置顶文章数
function count_log_top(){
$db = MySql::getInstance();
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "blog WHERE  top = 'y' or sortop = 'y' AND type = 'blog'");
return $data['total'];
}

//统计页面总数
function count_page_all(){
$db = MySql::getInstance();
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "blog WHERE type = 'page'");
return $data['total'];
}

//统计友链总数
function count_link_all(){
$db = MySql::getInstance();
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "link");
return $data['total'];
}

//统计分类总数
function count_sort_all(){
$db = MySql::getInstance();
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "sort");
return $data['total'];
}

//统计标签总数
function count_tag_all(){
$db = MySql::getInstance();
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "tag");
return $data['total'];
}

//统计附件总数
function count_att_all(){
$db = MySql::getInstance();
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "attachment");
return $data['total'];
}

//最后发表文章时间
function last_post_log(){
$db = MySql::getInstance();
$sql = "SELECT * FROM " . DB_PREFIX . "blog WHERE type='blog' ORDER BY date DESC LIMIT 0,1";
$res = $db->query($sql);
$row = $db->fetch_array($res);
$date = date('Y年n月j日',$row['date']);
return $date;       
};?>