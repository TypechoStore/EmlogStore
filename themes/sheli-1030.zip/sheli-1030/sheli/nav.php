<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Cache-Control" content="no-transform" />
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>sheli/sheli.js" type="text/javascript"></script>
<script type="text/javascript">
function openNav(){
nav = document.getElementById("m-left-nav");
if(nav.style.display == "none"){
nav.style.display = "block";}
else{
nav.style.display = "none";
}}
</script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="top">
<div id="logo-img"><img src="<?php echo _g('logo'); ?>" alt="<?php echo $blogname; ?>"></div>
<div id="mp_gonggao">
<div class="mp_gg">
<span class="mp_gg_box mp_gg_boxs"><em>◆</em><i>◆</i></span>
<?php echo _g('gonggao'); ?>
</div>
</div>
<div class="solve">
<div class="sl_search">
<form name="keyform" id="searchform" method="get" action="<?php echo BLOG_URL; ?>index.php">
<input name="keyword" class="search" type="text" placeholder="输入搜索内容" id="s" />
<button type="submit">搜索</button>
</form>
<div id="rss">
<li class="sl_mail"><a href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=<?php echo _g('email'); ?>" target="_blank" rel="nofollow" title="给我写信"></a></li>
<li class="sl_rss"><a href="<?php echo BLOG_URL; ?>rss.php" target="_blank" rel="nofollow" title="RSS订阅"></a></li>
<li class="sl_qq"><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo _g('qq'); ?>&site=qq&menu=yes" target="_blank" title="在线交流"></a></li>
<li class="sl_tqq"><a href="<?php echo TEMPLATE_URL; ?>url.php?go=<?php echo _g('tqq'); ?>" target="_blank" title="腾讯微博"></a></li>
<li class="sl_weibo"><a href="<?php echo TEMPLATE_URL; ?>url.php?go=<?php echo _g('weibo'); ?>" target="_blank" title="新浪微博"></a></li>
</div></div></div></div><?php //----#top end -----?>
<div id="sheli-nav"><div id="nav"><?php blog_navi();?></div></div>
<div id="m"><div id="m-logo"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></div><a onClick="openNav();return false;" href="#" class="nav-open"></a></div>
<div id="m-left-nav" style="display:none;">
<div id="m-nav"><?php blog_navi();?></div></div><?php //----#m-left-nav enf----?>
<div id="main">