<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<?php if($pageurl == Url::logPage()){ ?><?php include View::getView('index'); ?><?php }else{ include View::getView('sheli/head');?>
<div id="right">
<div id="mbx">
<p>现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; 
<?php if ($params[1]=='sort'){ ?><?php echo '<a href="'.Url::sort($sortid).'">'.$sortName.'</a>';?>
<?php }elseif ($params[1]=='tag'){ ?>包含标签 <b><?php echo urldecode($params[2]);?></b> 的所有文章
<?php }elseif($params[1]=='author'){ ?>作者 <b><?php echo blog_author($author);?></b> 的所有文章
<?php }elseif($params[1]=='keyword'){ ?>搜索 <b><?php echo htmlspecialchars(urldecode($params[2]));?></b> 的所有结果
<?php }elseif($params[1]=='record'){ ?>发表在 <b><?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?> </b>的所有文章
<?php }else{?><?php }?></p></div>
<?php if (!empty($logs)):foreach($logs as $value): ?>
<?php doAction('index_loglist_top'); ?>
<div class="newlog">
<div class="newlog_tt"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a><?php if(((date('Ymd',time())-date('Ymd',$value['date']))<=2)&&($value['top']=='n')){echo "<i class='new-arrow'></i><span class='new-label'>News</span>";}else if($value['views']>=300){echo "<i class='hot-arrow'></i><span class='hot-label'>热门</span>";};?><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?></div>
<div class="newlog_img"><img src="<?php if (_g('img') == "fjimg"): ?><?php sheli_fjimg($value['logid']);?><?php else: ?><?php endif; ?><?php if (_g('img') == "zwimg"): ?><?php sheli_zwimg($value['content']); ?><?php else: ?><?php endif; ?>" alt="<?php echo $value['log_title']; ?>" /></div>
<div class="newlog_nr"><?php echo subString(strip_tags($value['content']),0,150);?></div>
<div class="newlog_riqi">
作者: <?php blog_author($value['author']); ?> &nbsp;|&nbsp;
时间: <?php echo gmdate('Y年n月j日', $value['date']); ?> &nbsp;|&nbsp;
分类: <?php blog_sort($value['logid']); ?> &nbsp;|&nbsp; 
<a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a> &nbsp;|&nbsp; 
浏览(<?php echo $value['views']; ?>) &nbsp;|&nbsp;<br />
<?php blog_tag($value['logid']); ?>
</div></div><?php //----#log-list enf----?><?php endforeach;?>
<div id="pagenavi"><?php echo $page_url;?></div>
<?php else:?>
<div class="newlog">
<div class="newlog_tt">未找到您搜索的结果</div>
<div class="newlog_nr">抱歉，没有符合您查询条件的结果；请返回首页继续浏览</div>
</div>
<?php endif;?>
</div><?php //----#right enf----?>
<div id="left"><div id="sheli-hotlog"><div id="sheli-hotlog-tt">本月热门文章排行榜</div><ul><?php sheli_hotlog(10);?></ul></div>
<?php include View::getView('side1');?></div>
<?php } ?>
<?php include View::getView('footer');?>