<?php
$go=$_REQUEST["go"];
function if_http($http_url)
{
$url=$http_url;
$preg='|^http://|';
if(!preg_match($preg,$url))
{$url='http://'.$url;}
$tz_url=$url;
return $tz_url;
}
$web=if_http($go);
header("Location:$web");
?>