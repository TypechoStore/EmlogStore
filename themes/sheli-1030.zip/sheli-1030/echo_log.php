<?php if(!defined('EMLOG_ROOT')) {exit('error!');} include View::getView('sheli/head');?>
<div id="right">
<div id="mbx"><p>现在位置：<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> &raquo; <?php blog_sort($logid); ?> &raquo; <?php echo $log_title; ?></p></div>
<div id="sheli-log">
<div id="sheli-log1">
<div id="sheli-log-tt"><span id="log-list-tt-tt"></span><?php topflg($top); ?><?php echo $log_title; ?></div>
<div id="sheli-log-bq"><i class="icon-users"></i><?php blog_author($author); ?> &nbsp; 
<i class="icon-clock"></i><?php echo gmdate('Y年n月j日', $date); ?> &nbsp; 
<i class="icon-folder-open"></i><?php blog_sort($logid); ?> &nbsp; 
<i class="icon-bubbles"></i>评论(<?php echo $comnum;?>) &nbsp; 
<i class="icon-file"></i>浏览(<?php echo $views; ?>) &nbsp; 
<?php blog_tag($logid); ?>
</div>
<div id="sheli-log-nr"><?php echo $log_content; ?></div>
<div id="nextlog"><?php neighbor_log($neighborLog); ?></div>
<div id="log-bq"><script type="text/javascript">bdfx()</script>本文固定链接：<?php echo Url::log($logid); ?><br />本文由<?php blog_author($author); ?>原创或编辑，互联分享,尊重版权,转载请以链接形式标明本文地址</div>
<?php doAction('log_related', $logData); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); blog_comments($comments); ?>
</div></div><?php //----#sheli-log enf----?>
</div><?php //----#right enf----?>
<div id="left"><?php include View::getView('side2');?></div>
<?php include View::getView('footer');?>