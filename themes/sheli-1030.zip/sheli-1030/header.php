<?php
/*
Template Name:sheli-1030
Description:＊本主题由舍力设计和维护（制作日期10-30）<br />＊模板修改后出现的任何问题均请自行解决<br />＊在未修改的情况下，如有疑问，请点击下面的使用说明进行反馈<br><a href="http://www.shuyong.net/" target="_blank">使用说明及更新日志</a><br>
Version:1.0
Author:舍力博客
Author Url:http://www.shuyong.net
Sidebar Amount:3
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}require_once View::getView('module');include View::getView('sheli/sheli');?>