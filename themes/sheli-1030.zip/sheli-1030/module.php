<?php if(!defined('EMLOG_ROOT')) {exit('error!');} if (!function_exists('_g')) {emMsg('<div style="color:#ff0000;line-height:40px;text-align:center;font-size:16px;">欢迎你使用由舍力制作的主题；</div><div style="line-height:25px;font-size:14px;color:#999;">你现在无法正常使用本模板的原因：<br />1、你可能还未安装，请先安装<a href="http://www.emlog.net/plugin/144" target="_blank">模板设置插件</a><br />2、你还未启用模板设置插件，请到后面插件管理中启用模板插件；<br />主题由舍力负责维护，如有疑问请阅读【<a href="http://www.shuyong.net/" target="_blank">模板使用说明</a>】，QQ345952779</div>', BLOG_URL . 'admin/plugins.php');}?>
<?php
//widget：日历
function widget_calendar($title){ ?>
<li><h3><span><?php echo $title; ?></span></h3>
<div id="calendar"></div><script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script></li>
<?php }?>
<?php
//widget：标签
function widget_tag($title){global $CACHE;$tag_cache = $CACHE->readCache('tags');?>
<li><h3><span><?php echo $title; ?></span></h3><ul id="blogtags"><?php foreach($tag_cache as $value): ?><li><a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇文章"><?php echo $value['tagname']; ?></a></li><?php endforeach; ?></ul></li><?php }?>
<?php
//widget：分类
function widget_sort($title){global $CACHE;$sort_cache = $CACHE->readCache('sort'); ?>
<li><h3><span><?php echo $title; ?></span></h3><ul id="blogsort"><?php foreach($sort_cache as $value):if ($value['pid'] != 0) continue;?><li><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a><?php if (!empty($value['children'])): ?><ul>
<?php $children = $value['children'];foreach ($children as $key):$value = $sort_cache[$key];?><li><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a></li><?php endforeach; ?></ul><?php endif; ?></li><?php endforeach; ?></ul></li><?php }?>
<?php
//widget：最新微语
function widget_twitter($title){global $CACHE; $newtws_cache = $CACHE->readCache('newtw');$istwitter = Option::get('istwitter');?>
<li><h3><span><?php echo $title; ?></span></h3><ul id="twitter"><?php foreach($newtws_cache as $value): ?><?php $img = empty($value['img']) ? "" : '<a title="查看图片" class="t_img" href="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" target="_blank">&nbsp;</a>';?><li><?php echo $value['t']; ?><?php echo $img;?><p><?php echo smartDate($value['date']); ?></p></li><?php endforeach; ?><?php if ($istwitter == 'y') :?><p><a href="<?php echo BLOG_URL . 't/'; ?>">更多&raquo;</a></p><?php endif;?></ul></li><?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){global $CACHE; $com_cache = $CACHE->readCache('comment');?>
<li><h3><span><?php echo $title; ?></span></h3><ul id="newcomment"><?php foreach($com_cache as $value):$url = Url::comment($value['gid'], $value['page'], $value['cid']);?><li id="comment"><font color="#990000"><?php echo $value['name']; ?>:</font><a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a></li>	<?php endforeach; ?></ul></li><?php }?>
<?php
//widget：最新文章
function widget_newlog($title){global $CACHE; $newLogs_cache = $CACHE->readCache('newlog');?>
<li><h3><span><?php echo $title; ?></span></h3><ul id="newlog"><?php foreach($newLogs_cache as $value): ?><li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li><?php endforeach; ?></ul></li><?php }?>
<?php
//widget：热门文章
function widget_hotlog($title){$index_hotlognum = Option::get('index_hotlognum');$Log_Model = new Log_Model();$randLogs = $Log_Model->getHotLog($index_hotlognum);?>
<li><h3><span><?php echo $title; ?></span></h3><ul id="hotlog"><?php foreach($randLogs as $value): ?><li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li><?php endforeach; ?></ul></li>
<?php }?>
<?php
//widget：随机文章
function widget_random_log($title){$index_randlognum = Option::get('index_randlognum');$Log_Model = new Log_Model();$randLogs = $Log_Model->getRandLog($index_randlognum);?>
<li><h3><span><?php echo $title; ?></span></h3><ul id="randlog"><?php foreach($randLogs as $value): ?><li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li><?php endforeach; ?></ul></li>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
<li><h3><span><?php echo $title; ?></span></h3><ul id="logsearch">
<center><form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
<input name="keyword" class="search" type="text" placeholder="输入搜索内容" />
<input type="submit" id="logserch_logserch" class="l-wsubmit" title="搜索" value="搜索"/>
</form></center></ul></li><?php } ?>
<?php
//widget：归档
function widget_archive($title){global $CACHE; $record_cache = $CACHE->readCache('record');?>
<li><h3><span><?php echo $title; ?></span></h3><ul id="record"><?php foreach($record_cache as $value): ?><li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li><?php endforeach; ?></ul></li><?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
<li><h3><span><?php echo $title; ?></span></h3><ul id="zdy"><?php echo $content; ?></ul></li><?php } ?>
<?php
//widget：链接
function widget_link($title){global $CACHE; $link_cache = $CACHE->readCache('link');if (!blog_tool_ishome()) return;?>
<li><h3><span><?php echo $title; ?></span></h3><ul id="link"><?php foreach($link_cache as $value): ?><li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li><?php endforeach; ?></ul></li><?php }?>
<?php
//blog：导航
function blog_navi(){global $CACHE; $navi_cache = $CACHE->readCache('navi');$i=0;?>
<ul class="bar"><?php foreach($navi_cache as $value):$i++;if($i>=11)break;if ($value['pid'] != 0) {continue;}if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):	?><?php continue;endif;$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';$value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');$current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'current' : 'common';?><li class="item <?php echo $current_tab;?>"><a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a><?php if (!empty($value['children'])) :?><ul class="sub-nav"><?php foreach ($value['children'] as $row){echo '<li><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></li>';}?></ul><?php endif;?><?php if (!empty($value['childnavi'])) :?><ul class="sub-nav"><?php foreach ($value['childnavi'] as $row){$newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';echo '<li><a href="' . $row['url'] . "\" $newtab >" . $row['naviname'].'</a></li>';}?></ul><?php endif;?></li><?php endforeach; ?></ul><?php }?><?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<?php
//blog：置顶
function topflg($top, $sortop='n', $sortid=null){if(blog_tool_ishome()) {echo $top == 'y' ? "<span class='zhiding'>置顶</span>" : '';} elseif($sortid){echo $sortop == 'y' ? "<span class='zhiding'>置顶</span><i class='zhiding1'></i>" : '';}}?>
<?php
//blog：分类
function blog_sort($blogid){global $CACHE; $log_cache_sort = $CACHE->readCache('logsort');?><?php if(!empty($log_cache_sort[$blogid])): ?><a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a><?php endif;?><?php }?>
<?php
//blog：文章标签
function blog_tag($blogid){global $CACHE;$log_cache_tags = $CACHE->readCache('logtags');if (!empty($log_cache_tags[$blogid])){$tag = '关键词:';foreach ($log_cache_tags[$blogid] as $value){$tag .= "    <a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';}echo $tag;}}?>
<?php
//blog：文章作者
function blog_author($uid){global $CACHE;$user_cache = $CACHE->readCache('user');$author = $user_cache[$uid]['name'];$mail = $user_cache[$uid]['mail'];$des = $user_cache[$uid]['des'];$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';echo $author;}?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){extract($neighborLog);?>
<?php if($prevLog):?><li>上一篇：<a href="<?php echo Url::log($prevLog['gid']) ?>"><?php echo $prevLog['title'];?></a></li><?php endif;?>
<?php if($nextLog && $prevLog):?><?php endif;?>
<?php if($nextLog):?><li1>下一篇：<a href="<?php echo Url::log($nextLog['gid']) ?>"><?php echo $nextLog['title'];?></a></li1><?php endif;?>
<?php }?>
<?php //blog-tool:判断是否是首页
function blog_tool_ishome(){if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){  return true; } else { return FALSE;}}?>