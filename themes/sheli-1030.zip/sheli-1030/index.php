<?php if(!defined('EMLOG_ROOT')) {exit('error!');}include View::getView('sheli/index');?>
<div id="right">
<div id="sheli-flash"><ul class="sy-flash" id="flash"><?php home_slideshow(); ?></ul></div>
<?php doAction('index_loglist_top'); ?>
<?php newlog();?>
<div id="log-sort"><?php sortlogs();?></div>

</div><?php //----#right enf----?>
<div id="left"><div id="sheli-hotlog"><div id="sheli-hotlog-tt">本月热门文章排行榜</div><ul><?php sheli_hotlog(10);?></ul></div>
<?php include View::getView('side1');?>
<?php if (_g('blogtj-kg') == "yes"): ?><div id="sheli-blogtj"><div id="sheli-blogtj-tt">博客统计</div><ul>
<li>文章数量：<?php echo $sta_cache['lognum'];?>篇</li>
<li>草稿文章：<?php echo $sta_cache['draftnum'];?>篇</li>
<li>已审评论：<?php echo $sta_cache['comnum'];?>条</li>
<li>微语数量：<?php echo $sta_cache['twnum'];?>条</li>
<li>待审评论：<?php echo $sta_cache['hidecomnum'];?>条</li>
<li>页面数量：<?php echo count_page_all();?>篇</li>
<li>分类数量：<?php echo count_sort_all();?>个</li>
<li>标签数量：<?php echo count_tag_all();?>个</li>
<li>友链数量：<?php echo count_link_all();?>条</li>
<li>附件数量：<?php echo count_att_all();?>个</li>
<li>网站运行：<?php echo floor((time()-strtotime(_g('opentime')))/86400); ?>天</li>
<p>最后更新：<small><?php echo last_post_log();?></small></p>
</ul></div><?php else: ?><?php endif; ?>
</div>