<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<section>
  <article class="contentleft">
    <?php doAction('index_loglist_top'); ?>
    <?php foreach($logs as $value): ?>
    <div class="post">
      <div class="post-time">
        <div class="post-time-d"><?php echo gmdate('j', $value['date']); ?></div>
        <div class="post-time-ym"><?php echo gmdate('M', $value['date']); ?> - <?php echo gmdate('Y', $value['date']); ?> </div>
      </div>
      <h2 class="log-title">
        <?php topflg($value['top']); ?>
        <a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
      <p class="date">By
        <?php blog_author($value['author']); ?>
        | <a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?></a> Comments | <a href="<?php echo $value['log_url']; ?>"><?php echo $value['views']; ?></a> Views
        <?php editflg($value['logid'],$value['author']); ?>
      </p>
      <?php echo $value['log_description']; ?>
      <div class="post-tag">
        <?php blog_sort($value['logid']); ?>
        <?php blog_tag($value['logid']); ?>
      </div>
    </div>
    <?php endforeach; ?>
    <div id="pagenavi"> <?php echo $page_url;?> </div>
  </article>
</section>
<?php
 include View::getView('footer');
?>
