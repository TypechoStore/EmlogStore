<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
		<div id="content" class="single">
			<div class="post" id="post-<?php echo $logid; ?>">
				<p class="details_small">
					on <?php echo gmdate('Y-n-j G:i l', $date); ?> 
					by <?php blog_author($author); ?>
					<?php blog_sort($logid); ?>
					 <?php editflg($logid,$author); ?>
				</p>
				<h1><?php echo $log_title; ?></h1>
				<div class="post_content">
				<?php echo $log_content; ?>
				<?php blog_att($logid); ?>
				<?php doAction('log_related', $logData); ?>
				</div>
				<p><?php blog_tag($logid); ?></p>
			</div>
			<div class="comments">
			<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
			<?php blog_comments($comments); ?>
			<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);?>
			</div>
			<div class="navigation">
				<?php neighbor_log($neighborLog); ?>
			</div>
		</div>
<?php include View::getView('footer');  ?>
