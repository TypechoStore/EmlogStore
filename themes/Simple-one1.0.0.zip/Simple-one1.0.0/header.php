<?php
/*

Template Name:Simple-one1.0.0
Description:Simple-one
Author:达荣设计
Author Url:http://www.maidarong.com
Sidebar Amount:1

*/

if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<link href="<?php echo TEMPLATE_URL;?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL;?>js/jquery.corner.js"></script>
<script type="text/javascript">
$(function(){
$('.dh ul').wrap('<div class="outer"></div>');
$('.dh ul').corner().parent().css('padding', '1px').corner();
});
</script>
</head>

<body>
<div id="top">
	<div id="topleft">
   		<div id="bt"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></div>
		<div id="des"><?php echo $bloginfo; ?></div>
    </div>
    <div id="topright">
<form action="<?php echo BLOG_URL; ?>index.php" method="get"><input id="search_content" class="sch" type="search" name="keyword" placeholder="Search" /></form>
    </div>
	<div class="dh"><?php blog_navi(); ?></div>
</div>
