<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="dibu"><a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?> <a href="<?php echo BLOG_URL; ?>?post=15">关于我们</a>  <a href="<?php echo BLOG_URL; ?>?post=16">联系我们</a></div>
</body>
</html>