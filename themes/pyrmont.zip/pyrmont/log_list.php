<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
	<div id="container">
		<div id="main">
		<?php doAction('index_loglist_top'); ?>
		<?php foreach($logs as $value): ?>
			<div class="post">
				<div class="date">
					<?php echo date('Y', $value['date']); ?><br />
					<?php echo date('n.j', $value['date']); ?>				
				</div>
				<div class="title">
					<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
					<div class="postmeta">
						Author: <?php blog_author($value['author']); ?><?php blog_sort($value['logid']); ?> &nbsp;/
						<?php blog_tag($value['logid']); ?> 
						<span class="comments"><a href="<?php echo $value['log_url']; ?>#comments" title="<?php echo $value['log_title']; ?>上的评论"><?php echo $value['comnum']; ?> comments</a></span>
					</div><!-- end postmeta -->
				</div><!-- end title -->
				<div class="clear"></div>
				<div class="entry">
					<p><?php echo $value['log_description']; ?> </p>
					| <a href="<?php echo $value['log_url']; ?>">浏览次数(<?php echo $value['views']; ?>)</a> 
					| <a href="<?php echo $value['log_url']; ?>#tb">引用次数(<?php echo $value['tbcount']; ?>)</a> 
					| <a href="<?php echo $value['log_url']; ?>#comments">评论次数(<?php echo $value['comnum']; ?>)</a> |
					<br/>
					<br/>
					<div class="clear"></div>
				</div><!-- end entry -->
			</div><!-- end post -->
		<?php endforeach; ?>
			<div class="navigation">
				<div class="wp-pagenavi">
					<?php echo $page_url;?>
				</div>
			</div><!-- end navigation -->
		</div><!-- end main -->
	</div>
<!--end content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>