<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
	<div id="container">
		<div id="main">
			<div class="post">
				<div class="clear"></div>
				<div class="entry">
					<?php echo $log_content; ?>
					<div class="clear"></div>
				</div>
			</div>
		<?php blog_comments($comments); ?>
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
		</div>
	</div>
<!--end content-->
<?php 
 include View::getView('side');
 include View::getView('footer');
?>