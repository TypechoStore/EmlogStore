﻿<?php
/*
Template Name:Pyrmont
Description:黑色深邃风格，强大的兼容能力，兼容IE3 - IE8、FF等浏览器
Version:3.0
Author:motta(Kuma使emlog支持)
Author Url:http://www.cooron.net
Sidebar Amount:1
ForEmlog:5.0.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title ; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="page_wrap">
	<div id="header">
		<div class="blog_title">
			<h1><a href="./"><?php echo $blogname; ?></a></h1>
			<p class="description"><?php echo $bloginfo; ?></p>
		</div>
		<div id="search">
			<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>" id="keyform"><p>
				<input name="keyword"  type="text"  id="searchinput"  class="searchinput" value="search" onfocus="if (this.value == 'search') {this.value = '';}" onblur="if (this.value == '') {this.value = 'search';}" />
				<input type="submit" id="logserch_logserch" class="button" value="" onclick="return keyw()" />
			</form>
		</div>		
		<div class="clear"></div>
	</div>
    <!-- end header -->
	<?php blog_navi();?>
	<div class="clear"></div>
    <!-- end menu -->