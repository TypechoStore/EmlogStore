<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>

<div id="container">
<div id="main">
		<div class="post">
				<div class="date"> <?php echo date('Y', $date); ?><br />
						<?php echo date('n.j', $date); ?> </div>
				<div class="title">
						<h2><?php topflg($top); ?><?php echo $log_title; ?> </h2>
						<div class="postmeta">Author:
							<?php blog_author($author); ?>
							<?php blog_sort($logid); ?>
						</div>
						<!-- end postmeta -->
				</div>
				<!-- end title -->
				<div class="clear"></div>
				<div class="entry"> <?php echo $log_content; ?>
						<div class="clear"></div>
				</div>
				<!-- end entry -->
				<div id="postother">
						<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
						<div class="post_tags">
								<?php blog_tag($logid); ?>
						</div>
						<div id="nextlog">
								<?php neighbor_log($neighborLog); ?>
						</div>
						<div id="aboutblog">
								<div id="left">
										<?php doAction('log_related', $logData); ?>
								</div>
								<div id="right">
									<div style="display:none;">这里加入广告</div>
								</div>
								<div class="clear"></div>
						</div><!-- end aboutblog-->
				</div><!-- end postother -->
		</div><!-- end post -->
		<div class="clear"></div>
		<?php blog_comments($comments); ?>
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
<!-- end main -->
<?php 
 include View::getView('side');
 include View::getView('footer');
?>