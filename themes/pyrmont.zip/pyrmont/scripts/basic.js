$(document).ready(function(){
	$(":text, textarea").focus(function(){//获得焦点, 背景颜色变化
		$(this).parent().addClass("currentFocus");
		$(".currentFocus .desc").css({"color" : "#ff5a00"});
		$(".currentFocus .message_input, .currentFocus #author, .currentFocus #email, .currentFocus #url").css({"border-color" : "#ff5a00", "color" : "#000"});
	});

	$(":text,textarea").blur(function(){//失去焦点, 恢复
		$(this).parent().removeClass("currentFocus");
		$(".message_input, .desc, #author, #email, #url").removeAttr("style");
	});
	
	$(".btt").hover(function(){//TOP鼠标形状
		$(".btt").css({"cursor": "pointer"});
	});
	
	$(".btt").click(function(){//scrollTo插件
		$.scrollTo("#header", 800);
	});
	
	$(".add_your_comment").click(function(){//scrollTo插件
		$.scrollTo("#respond", 800);return false;
	});
	
	$(".ad_toggle").click(function(){
		$(".related_inner > div").slideToggle("slow");
		$(this).toggleClass("ad_toggle_active");
	});	
	
});