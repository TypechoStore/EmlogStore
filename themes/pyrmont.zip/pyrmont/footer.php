﻿<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js" type="text/javascript"></script>
<div id="footer">
	<div class="footer_wrapper">
©&nbsp;<?php echo date(Y);?>&nbsp;&nbsp;<a href="<?php echo BLOG_URL; ?>"> <?php echo $blogname; ?></a>&nbsp;&nbsp;&nbsp;&nbsp;Powered by <a href="http://www.emlog.net" title="emlog <?php echo EMLOG_VERSION;?>">emlog</a> &nbsp;&nbsp;&nbsp;&nbsp;Theme By&nbsp;<a href="http://imotta.cn" target="_blank">motta</a>&nbsp;&nbsp;&nbsp;&nbsp;Foremlog by <a href="http://www.cooron.net" target="_blank">Kuma</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
<span class="btt" title="返回顶部">返回顶部&nbsp;↑</span>&nbsp;&nbsp;&nbsp;&nbsp;
<script src="<?php echo TEMPLATE_URL; ?>scripts/basic.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>scripts/jquery.scrollTo-min.js" type="text/javascript"></script>
	</div>
</div><!-- end footer -->
</body>
</html>