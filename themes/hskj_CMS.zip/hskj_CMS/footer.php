<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="clr"></div>
		<div id="footer">
		<div class="footbg">
		<div class="footbg">
		<span>Copyright &copy; 2013  Sanzi保留所有权利.
       </span><br>
	   Theme By 陈子文移植自Sanzi. Powered By <a rel="nofollow" target="_blank" href="http://www.emlog.net/">emlog</a>.
		<?php echo $footer_info; ?>	<?php doAction('index_footer'); ?>
		</div>
		</div>
	
	<?php
      $login = '
	     <div class="login">
	          <form method="post" action="'.BLOG_URL.'admin/index.php?action=login" name="f">
                    <ul class="login">
                        <li><label for="log">登陆账号：</label><input type="text" value="" id="user" name="user"></li>
                        <li><label for="pwd">登陆密码：</label><input type="password" id="pw" name="pw"></li>
                        <li><input type="submit" class="submit1" value="确 定" name="submit">&nbsp; &nbsp;<input type="reset" class="submit2" name="Submit2" value="取 消"><input type="hidden" value="/" name="redirect_to"></li>
                    </ul>
              </form>
	     </div>';
      $ok = '
          <div class="login">
		       <a href="'.BLOG_URL.'admin/">站点管理</a>
		  </div>
      ';
      if(ROLE == 'admin' || ROLE == 'writer')
        echo $ok ; 
      else
        echo $login ; 
   ?>
	

	</div>
</div>
<!-- 返回顶部 -->
<div style="display: none;" id="gotop"></div>
<!-- 返回顶部END -->


<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/js/jquery-1.9.0.min.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/js/sanzi.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/js/prettify.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>/js/prettify.min.js"></script>
<script type="text/javascript">
window.onload = function(){prettyPrint();};
</script>

 
<script type="text/javascript">
	$(document).ready(function() {
		$(".fancybox").fancybox();
	});
</script>
 <!--[if ie 6]>
	<script src="http://letskillie6.googlecode.com/svn/trunk/letskillie6.zh_TW.pack.js"></script>
<![endif]-->
</body>
</html>