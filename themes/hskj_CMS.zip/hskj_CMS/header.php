<?php
/*
Template Name:黑色空间_CMS
Description:黑色空间主题地址：http://vps.lantk.com/?post=71
Version:1.2
Author:陈子文
Author Url:http://vps.lantk.com/?post=71
Sidebar Amount:1
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
require_once View::getView('option');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!--忽略因找不到JS对象所产生的网页错误-->
<script language="JavaScript">
<!-- Hide
function killErrors() {
return true;
}
window.onerror = killErrors;
// -->
</script> 
<!--忽略因找不到JS对象所产生的网页错误结束-->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<!--高亮代码-->
<link href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
  <style>


  </style>
</head>

<body>
<div id="page">
	<div id="header">
		<div class="header-left">
		     <a rel="home" title="<?php echo $blogname; ?>" href="<?php echo BLOG_URL; ?>">
		        <img alt="<?php echo $blogname; ?>" src="<?php echo TEMPLATE_URL; ?>images/logo.png">
			 </a>
		</div>
			
		<div id="topad">
		   <div class="adc">
			 <div class="t"></div>
			 <div class="inner">
				       <li>采用优秀开源建站程序Emlog进行搭建</li>
			 </div>
             <div class="b"></div>
           </div>
		</div>
		           <?php global $CACHE;$user_cache = $CACHE->readCache('user');
	        $name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>

     <?php global $CACHE;$user_cache = $CACHE->readCache('user');$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
	 <?php if (!empty($user_cache[1]['photo']['src'])): ?>

	<?php
      $login = '
	     <div id="topbtn">	
             <div class="login">
	          <form method="post" action="admin/index.php?action=login" name="f">
                    <ul class="login">
                        <li><label for="log">登陆账号：</label><input type="text" value="" id="user" name="user"></li>
                        <li><label for="pwd">登陆密码：</label><input type="password" id="pw" name="pw"></li>
                        <li><input type="submit" class="submit1" value="确 定" name="submit">&nbsp; &nbsp;<input type="reset" class="submit2" name="Submit2" value="取 消"><input type="hidden" value="/" name="redirect_to"></li>
                    </ul>
              </form>
	     </div>
		 ';
      $ok = '
	     <div id="topbtn">	
             <div class="login">
			      <div class="userpic">
                       <img width=50 height=50 src="'.BLOG_URL.$user_cache[1]['photo']['src'].'" alt="blogger" />
                  </div>
				  <div class="userus">
				       尊敬的'.$name.'欢迎回来!
					   <p>发表一篇<a targes="_blank" href="'.BLOG_URL.'admin/write_log.php">新文章</a></p>
					   <p><a targes="_blank" href="'.BLOG_URL.'admin">后台管理</a>　　　　<a href="'.BLOG_URL.'admin/?action=logout">退出</a></p>
                  </div>
	         </div>     
	  ';

      if(ROLE == 'admin' || ROLE == 'writer')
        echo $ok ; 
      else
        echo $login ; 
   ?>
	     <?php endif;?>		
	</div>
			<div class="nav">		
		<?php blog_navi();?>
			<div id="search">		
				<form action="<?php echo BLOG_URL; ?>index.php" method="get" id="searchform">
				<input type="text" value="没事别点我,节约资源.." name="keyword" class="s" onfocus="if (this.value == '没事别点我,节约资源..') {this.value = '';}" onblur="if (this.value == '') {this.value = '没事别点我,节约资源..';}" x-webkit-speech="">
				<button type="submit">搜索</button>
				</form>
			</div>
		</div> <div class="clr"></div> 
	</div>