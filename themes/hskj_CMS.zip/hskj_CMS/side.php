<?php 
/**
 * 侧边栏
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="sidebar">
<div class="widget">
	<h3><?php echo $admin_twitter; ?></h3>
<div class="siderbar-ad">
				<a href="<?php echo $admin_sina_weibo; ?>">
				<img width="250px" height="213px" alt="EMLOG5.20" title="EMLOG5.20下载" src="<?php echo $admin_gg; ?>">
				</a>
				
					</div>
					<div class="clr"></div> 
<p>
免責：<br>
本站文章內容為原創,主題美化為網絡傳播
如有侵權請通知修改,將不負任何法律責任
</p>
</div>
<div class="clr"></div>

<div class="widget">
		<div id="tab-title">
		<h4><span class="current" id="tab-1">新评</span><span id="tab-2" class="">热文</span><span id="tab-3" class="">随机</span><span id="tab-4" class="">标签</span></h4>
	</div>
	<div id="tab-content">
				<ul class="tab-1 recentcomments" style="display: block;">
			
<?php tab_newcomm(); ?><!--最新评论-->

		</ul>
				<ul class="tab-2" style="display: none;">
			<?php widget_hotlog($title); ?><!--热门文章-->
</ul>
		<ul class="tab-3" style="display: none;">
						<?php widget_random_log($title); ?><!--随机文章-->
					</ul>
		<ul class="tab-4 tag_cloud" style="display: none;">
			<li>
			<ul class="post_tags">
			<?php widget_tag($title); ?><!--标签-->
			</ul>
			</li>
		</ul>
	</div><div class="clr"></div></div>

<div class="widget">
	<h3>友情链接</h3>
<ul class="r_link">
<?php links(); ?>
</ul><div class="clr"></div></div>

<div class="widget">
		<h3>博客统计</h3>
<div class="r_statistics">
   <ul class="linetwo">
<li>日志总数：<?php $sta_cache = Cache::getInstance()->readCache('sta');?><?php echo $sta_cache['lognum']; ?> 篇</li>
<li>评论总数：<?php $sta_cache = Cache::getInstance()->readCache('sta');?><?php echo $sta_cache['comnum']; ?> 篇</li>
<li>碎语总数：<?php echo $sta_cache['twnum'];?> 条</li>
<li>已经运行：<b><script language='JavaScript'>var urodz= new Date('5/6/2013');var now = new Date();var ile = now.getTime() - urodz.getTime();var dni = Math.floor(ile / (1000 * 60 * 60 * 24));if (dni > 1){document.write(dni)}else{document.write()};</script></b>天</li>
  </ul>
<ul class="lineone"><li>建站日期：2013年5月6日</li>
</ul> 
</div><div class="clr"></div>         
</div>
<!--侧边栏跟随开始-->
<div class="widget" id="float">
				<h3>主机推荐</h3>
				<ul class="contact">
					
					<li>PHP主机推荐：<a href="http://idc.lantk.com/index.php" target="_blank">恒讯主机</a></li>
					<li>小提示：<br/>本博客在<a href="http://www.google.com/chrome " target="_blank">谷歌浏览器</a>上能显示最佳效果！</li>
				</ul> 
         	</div>
<!--侧边栏跟随结束-->
</div>