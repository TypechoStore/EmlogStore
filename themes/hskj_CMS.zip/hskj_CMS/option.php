<?php 
/**
模板配置文件
* */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
	// 设置

// 首页分类调用ID//	
    $index_sort1 = "1";
    $index_sort2 = "2";
	$index_sort3 = "3";
	$index_sort4 = "4";

// 首页全局设置
    $emailid = '2';	//首页置顶图文调用数量

//侧边栏设置
	$admin_twitter ='欢迎光临 Welcome To My Blog!'; // 侧边栏欢迎语
	$admin_gg = 'http://vps.lantk.com/content/templates/hskj_CMS/images/screenshot.png'; // 侧边栏广告图片地址
	$admin_sina_weibo = 'http://vps.lantk.com/?post=71'; // 侧边栏广告图片链接地址

//评论等级输出设置说明
//请打开module.php找到第11~32行自行修改！！

?>

