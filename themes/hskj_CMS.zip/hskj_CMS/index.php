<?php 
/*
* 首页
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<?php doAction('index_loglist_top'); ?>	
<?php $sort_cache = Cache::getInstance()->readCache('sort'); ?>
<div class="post-content">
<!--置顶图文开始-->         		 	 
<?php index_show($emailid);?>  
     	     	<!--置顶图文结束-->         		 		  
<div id="indexcms">

     <div class="box1">
	      <div class="sort">
		       <ul>
			     <h2><?php echo $sort_cache[$index_sort1]['sortname']; ?></h2>
			     <?php echo get_list($index_sort1); ?>
			   </ul>
		  </div>
     </div>

	<div class="box1">
	      <div class="sort">
		       <ul>
			     <h2><?php echo $sort_cache[$index_sort2]['sortname']; ?></h2>
			     <?php echo get_list($index_sort2); ?>
			   </ul>
		  </div>
     </div>

	 <div class="box1">
	      <div class="sort">
		       <ul>
			     <h2><?php echo $sort_cache[$index_sort3]['sortname']; ?></h2>
			     <?php echo get_list($index_sort3); ?>
			   </ul>
		  </div>
     </div>

	 
	 <div class="box1">
	      <div class="sort">
		       <ul>
			     <h2><?php echo $sort_cache[$index_sort4]['sortname']; ?></h2>
			     <?php echo get_list($index_sort4); ?>
			   </ul>
		  </div>
     </div>
</div>

		</div>
			
<!--载入侧边栏-->
<?php
 include View::getView('side');
?>