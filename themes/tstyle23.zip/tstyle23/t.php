<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container" class="clearfix">
<div id="main" class="col-17">
<div id="content">
<div class="f-s"></div><div class="f-m">
<h2><em><a title="回到首页" href="<?php echo BLOG_URL; ?>">首页</a></em><span class="cut">&raquo;</span><em>碎语</em></h2>
<div id="tw" class="box">
    <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
    <div class="top"><a href="<?php echo BLOG_URL . 'admin/twitter.php' ?>">发布碎语</a></div>
    <?php endif; ?>
    <ul>
    <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    $img = empty($val['img']) ? "" : '<br><a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #E7E7E7;padding:3px;background:#fff;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?> 
    <li class="li">
    <div class="userPic"><span class="avatar"><img src="<?php echo $avatar; ?>" width="32px" /></span></div>
    <div class="msgBox">
    <p class="post1"><b class="name"><?php echo $author; ?> :</b><em>“</em><?php echo $val['t'];?><em>”</em><?php echo $img;?></p>
    <div class="bttome clear">
        <p class="left time"><?php echo $val['date'];?></p>
        <p class="right post"><a href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>t/?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">评论(<span id="rn_<?php echo $tid;?>"><?php echo $val['replynum'];?></span>)</a></p>
    </div>
    <div class="huifu replay" id="rp_<?php echo $tid;?>" style="display:none">   
	<div style="margin-right:10px;"><textarea id="rtext_<?php echo $tid; ?>"></textarea></div>
    <div class="tbutton">
        <div class="tinfo left" style="<?php if(ROLE == 'admin' || ROLE == 'writer'){echo 'display:none';}?>">
        昵称：<input type="text" id="rname_<?php echo $tid; ?>" value="" style="width:100px;" />
        <span style="display:<?php if($reply_code == 'n'){echo 'none';}?>">&nbsp;&nbsp;&nbsp;&nbsp;验证码：<input type="text" id="rcode_<?php echo $tid; ?>" value="" style="width:50px;font-size:14px;" /><?php echo $rcode; ?></span>        
        </div>
        <button class="btn right" type="button" onclick="reply('<?php echo DYNAMIC_BLOGURL; ?>t/?action=reply',<?php echo $tid;?>);" value="回复">提交</button>
    </div>
    <div class="msg"><span id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></span></div>
    </div>
    <ul class="reply_list replay clear" id="r_<?php echo $tid;?>" style="display:none"></ul>
    </li>
    <?php endforeach;?>
    <li id="pagenavi"><?php echo $pageurl;?><p>[ 有<?php echo $twnum; ?>条碎语 ]</p></li>
    </ul>
</div><div class="f-e"></div>
</div>
</div>
</div>
<?php include View::getView('side');?>
</div><!--end container-->
<?php include View::getView('footer');?>