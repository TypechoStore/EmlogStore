<?php 
/*
* 侧边栏组件、页面模块
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
//$GLOBALS['tcms']['params']=$params;
?>
<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
<div id="side-dfn" class="col-6 last">
<div class="f-s"></div><div class="f-m">
	<h2><em><?php echo $title; ?></em><span>Blogger</span></h2>
	<div id="blogger" class="blogger side">
	<?php if (!empty($user_cache[1]['photo']['src'])): ?>
	<img src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="<?php echo $user_cache[1]['photo']['width']; ?>" height="<?php echo $user_cache[1]['photo']['height']; ?>" alt="blogger" />
	<?php endif;?>
	<div><b><?php echo $name; ?></b></div>
	<div><?php echo $user_cache[1]['des']; ?></div>
    </div>
</div><div class="f-e"></div>
</div>
<?php }?>
<?php
//widget：日历
function widget_calendar($title){?>
<div id="side-dfn" class="col-6 last">
<div class="f-s"></div><div class="f-m">
	<h2><em><?php echo $title; ?></em><span>Calendar</span></h2>
	<div id="calendar" class="calendar side">
	<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
	</div>
</div><div class="f-e"></div>
</div>
<?php }?>
<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');
	$colors = array("#333333","#FF0000","#CC0099","#E50066","#990099","#990000","#660099","#330099","#1919B2","#0033CC","#0066B2","#009999","#00B266","#00CC00","#33FF00","#8EB100","#DBC400","#FFB200","#FF8000","#FF3300","#6600FF","#CC6666","#FF00FF","#663399","#00CCFF");
    ?>
<div id="side-tag" class="col-6 last">
<div class="f-s"></div>
<div class="f-m">
	<h2><em><?php echo $title; ?></em><span>Tag Cloud</span><!--a href="#" title="更多..." class="more">更多Tag...</a--></h2>
    <div id="blogtags" class="tags">
	<?php foreach($tag_cache as $value) {
        $color = $colors[rand(0,24)];
    ?>
		<a style="font-size:<?php echo $value['fontsize']>13? "13":$value['fontsize']; ?>pt;color:<?php echo $color; ?>" href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇日志"><?php echo $value['tagname']; ?></a>
	<?php } ?>
	</div>
</div>
<div class="f-e"></div>
</div>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort');?>
<div id="side-dfn" class="col-6 last">
<div class="f-s"></div>
<div class="f-m">
	<h2><em><?php echo $title; ?></em><span>Blog Sort</span></h2>
    <div id="blogsort" class="sort side">
	<ul>
	<?php foreach($sort_cache as $value): ?>
	<li>
	<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
	<a href="<?php echo BLOG_URL; ?>rss.php?sort=<?php echo $value['sid']; ?>"><img align="absmiddle" src="<?php echo TEMPLATE_URL; ?>images/icon_rss.gif" alt="订阅该分类"/></a>
	</li>
	<?php endforeach; ?>
	</ul>
	</div>
</div>
<div class="f-e"></div>
</div>
<?php }?>
<?php
//widget：最新碎语
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter'); ?>
<div id="side-dfn" class="col-6 last">
<div class="f-s"></div>
<div class="f-m">
	<h2><em><?php echo $title; ?></em><span>New Twitters</span><a href="<?php echo BLOG_URL.'t'; ?>" title="更多..." class="more">更多...</a></h2>
    <div id="twitter" class="newtws side">
	<ul id="twitter">
	<?php foreach($newtws_cache as $value): ?>
	<!--li><?php echo substr($value['t'],0,36).'...'; ?><p><?php echo gmdate('m-d H:i', $value['date']); ?> </p></li-->
    <?php $img = empty($value['img']) ? "" : '<a title="查看图片" class="t_img" href="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" target="_blank">&nbsp;</a>';?>
<li><?php echo $value['t']; ?><?php echo $img;?><p class="date"><?php echo smartDate($value['date']); ?></p></li>
	<?php endforeach; ?>
    <?php if ($istwitter == 'y') :?>
	<p style="text-align:right;padding:5px"><a href="<?php echo BLOG_URL . 't/'; ?>">更多&raquo;</a></p>
	<?php endif;?>
	</ul>
	</div>
</div>
<div class="f-e"></div>
</div>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');?>
<div id="side-dfn" class="col-6 last">
<div class="f-s"></div>
<div class="f-m">
	<h2><em><?php echo $title; ?></em><span>New Comments</span><a href="#" title="更多..." class="more">更多...</a></h2>
    <div id="newcomment" class="newcmt side">
	<ul>
	<?php
	foreach($com_cache as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	?>
	<li id="comment"><?php echo $value['name']; ?>
	<?php if($value['reply']): ?>
	<a href="<?php echo $url; ?>" title="博主回复：<?php echo $value['reply']; ?>">
	<img src="<?php echo TEMPLATE_URL; ?>images/reply.gif" align="absmiddle"/>
	</a>
	<?php endif;?>
	<br /><a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</div>
</div>
<div class="f-e"></div>
</div>
<?php }?>
<?php
//widget：最新日志
function widget_newlog($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');?>
<div id="side-dfn" class="col-6 last">
<div class="f-s"></div>
<div class="f-m">
	<h2><em><?php echo $title; ?></em><span>New Logs</span><a href="#" title="更多..." class="more">更多...</a></h2>
    <div id="newlog" class="newlog side">
	<ul class="list">
	<?php foreach($newLogs_cache as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</div>
</div>
<div class="f-e"></div>
</div>
<?php }?>
<?php
//widget：热门日志
function widget_hotlog($title){
        $index_hotlognum = Option::get('index_hotlognum');
        $Log_Model = new Log_Model();
        $randLogs = $Log_Model->getHotLog($index_hotlognum);?>
<div id="side-dfn" class="col-6 last">
<div class="f-s"></div>
<div class="f-m">
    <h2><em><?php echo $title; ?></em><span>Hot Logs</span></h2>
    <div id="hotlog" class="hotlog side">
	<ul class="list">
        <?php foreach($randLogs as $value): ?>
        <li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
        <?php endforeach; ?>
    </ul>
	</div>
</div>
<div class="f-e"></div>
</div>
<?php }?>
<?php
//widget：随机日志
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
<div id="side-dfn" class="col-6 last">
<div class="f-s"></div>
<div class="f-m">
	<h2><em><?php echo $title; ?></em><span>Rand Logs</span></h2>
    <div id="randlog" class="randlog side">
	<ul class="list">
	<?php foreach($randLogs as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</div>
</div>
<div class="f-e"></div>
</div>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
<div id="side-dfn" class="col-6 last">
<div class="f-s"></div>
<div class="f-m">
	<h2><em><?php echo $title; ?></em><span>Search</span></h2>
    <div id="logserch" class="search side">
	<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
	<input name="keyword"  type="text" value="" style="width:120px;"/>
	<input type="submit" id="logserch_logserch" value="搜索" onclick="return keyw()" />
	</form>
	</div>
</div>
<div class="f-e"></div>
</div>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');?>
<div id="side-dfn" class="col-6 last">
<div class="f-s"></div>
<div class="f-m">
	<h2><em><?php echo $title; ?></em><span>Record</span></h2>
    <div id="record" class="record side">
	<ul>
	<?php foreach($record_cache as $value): ?>
	<li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
	<?php endforeach; ?>
	</ul>
	</div>
</div>
<div class="f-e"></div>
</div>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
<div id="side-dfn" class="col-6 last">
<div class="f-s"></div>
<div class="f-m">
	<h2><em><?php echo $title; ?></em></h2>
    <div class="side">
	<?php echo $content; ?>
	</div>
</div>
<div class="f-e"></div>
</div>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE;
	$link_cache = $CACHE->readCache('link'); ?>
<div id="side-dfn" class="col-6 last">
<div class="f-s"></div>
<div class="f-m">
	<h2><em><?php echo $title; ?></em><span>Link</span><!--a href="#" title="更多..." class="more">更多...</a--></h2>
    <div id="link" class="link side">
	<ul>
	<?php foreach($link_cache as $value): ?>
	<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
	<?php endforeach; ?>
	</ul>
    </div>
</div>
<div class="f-e"></div>
</div>
<?php }?>
<?php
//blog：置顶
function topflg($istop){
	$topflg = $istop == 'y' ? "<img src=\"".TEMPLATE_URL."/images/import.gif\" align=\"absmiddle\"  title=\"置顶日志\" /> " : '';
	echo $topflg;
}?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == 'admin' || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'">编辑</a>' : '';
	echo $editflg;
}?>
<?php
//blog：分类
function blog_sort($sort, $blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort'); ?>
	<?php if($log_cache_sort[$blogid]): ?>
	[<a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>]
	<?php endif;?>
<?php }?>
<?php
//blog：文件附件
function blog_att($blogid){
	global $CACHE;
	$log_cache_atts = $CACHE->readCache('logatts');
	$att = '';
	if(!empty($log_cache_atts[$blogid])){
		$att .= '<div class="fujian"><h4>附件下载：</h4>';
		foreach($log_cache_atts[$blogid] as $val){
			$att .= '<p><a href="'.BLOG_URL.$val['url'].'" target="_blank">'.$val['filename'].'</a><span>'.$val['size'].'</span></p>';
		}
        $att .= '</div>';
	}
	echo $att;
}?>
<?php
//blog：日志标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '标签:';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "	<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
		}
		echo $tag;
	}
}?>
<?php
//blog：meta-keywords
function log_tags($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags'); 
     if (!empty($log_cache_tags[$blogid])){
         foreach ($log_cache_tags[$blogid] as $value){
            $tags .= $value['tagname'].',';
         }
         echo $tags;
     }
}?>
<?php
//blog：日志作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}?>
<?php
//blog：相邻日志
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog):?>
	<span class="ico prev"><a href="<?php echo Url::log($prevLog['gid']) ?>"><?php echo $prevLog['title'];?></a></span>
	<?php endif;?>
	<?php if($nextLog):?>
		 <span class="ico next last"><a href="<?php echo Url::log($nextLog['gid']) ?>"><?php echo $nextLog['title'];?></a></span>
	<?php endif;?>
<?php }?>
<?php
//blog：引用通告
function blog_trackback($tb, $tb_url, $allow_tb){
    if($allow_tb == 'y' && Option::get('istrackback') == 'y'):?>
	<div id="trackback_address">
	<p>引用地址: <input type="text" style="width:350px" class="input" value="<?php echo $tb_url; ?>">
	<a name="tb"></a></p>
	</div>
	<?php endif; ?>
	<?php foreach($tb as $key=>$value):?>
		<ul id="trackback">
		<li><a href="<?php echo $value['url'];?>" target="_blank"><?php echo $value['title'];?></a></li>
		<li>BLOG: <?php echo $value['blog_name'];?></li><li><?php echo $value['date'];?></li>
		</ul>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：博客评论列表
function blog_comments($comments,$logid,$params){
	extract($comments);
    $isgb = $logid==$GLOBALS['tcms']['guestbook_id'] ? '留言':'评论';
	$commnum = count($comments);
?>
<div id="comment-list">
	<div class="f-s"></div>
	<div class="f-m">
	<h2><em><?php echo $isgb;?></em><span class="thin"><?php echo $commnum; ?>条</span>
    <a class="to-respond respond">快速<?php echo $isgb;?></a></h2>
    <div class="box">
        <ol class="commentlist">
<?php 
	if($commentStacks):
    foreach ($comments as $key=>$row) if($row['pid']==0) $ret[$key] = $row;
	$floor_count = count($ret);
	$page= isset($params[4]) && $params[4] == 'comment-page' ? intval($params[5]) : 1;
	$comment_pnum=Option::get('comment_pnum');
	$floor= $floor_count- $comment_pnum * ($page-1);
	$floor_rise = -1;
    
	foreach($commentStacks as $cid):
		$comment = $comments[$cid];
		$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
?>
	<li class="comment parent" id="comment-<?php echo $comment['cid']; ?>">
		<div id="div-comment-<?php echo $value['cid']; ?>" class="comment-body"><a name="<?php echo $comment['cid']; ?>"></a>
		<div class="comment-author vcard">
			<div class="avatar"><img src="<?php echo getGravatar($comment['mail']); ?>" /></div>
			<cite class="fn"><?php echo $floor; ?>楼 <span><?php echo $comment['poster']; ?></span></cite><span class="says">说：</span>
		</div>
		<div class="comment-meta"><?php echo $comment['date']; ?></div>
		<p class="comment-content"><?php echo $comment['content']; ?></p>
		<div class="reply"><a class="comment-reply-link" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a></div>
		</div>
		<?php blog_comments_children($comments, $comment['children']); ?>
	</li>
<?php 
	$floor += $floor_rise;
	endforeach;
?>
	<div id="pagenavi"><?php echo $commentPageUrl;?></div>
<?php else: ?>
    <li class="no-comment"><?php echo "暂无评论，快抢沙发吧。"; ?></li>
<?php endif; ?>
		</ol>
		</div>
        </div>
		<div class="f-e"></div>
</div><!-- /comment-list -->
<?php }?>
<?php
//blog：博客子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<ul class="children comment-children" id="comment-<?php echo $comment['cid']; ?>">
		<li id="comment-<?php echo $comment['cid']; ?>" class="comment">
		<div id="div-comment-<?php echo $comment['cid']; ?>" class="comment-body">
		<div class="comment-author vcard">
<?php if($isGravatar == 'y'): ?>
		<div class="avatar"><img src="<?php echo getGravatar($comment['mail']); ?>" /></div>
<?php endif; ?>
		<div class="comment-info">
			<cite class="fn"><span><?php echo $comment['poster']; ?></span></cite><span class="says">说：</span><span class="comment-meta"><?php echo $comment['date']; ?></span>
			<p class="comment-content"><?php echo $comment['content']; ?></p>
<?php if($comment['level'] < 4): ?>
			<div class="reply"><a class="comment-reply-link" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a></div>
<?php endif; ?>
			</div>
		</div>
		</div>
		<?php blog_comments_children($comments, $comment['children']);?>
		</li>
	</ul>
<?php endforeach;} ?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): 
	$isgb = $logid==$GLOBALS['tcms']['guestbook_id'] ? '留言':'评论';
?>
<div id="respond">
<div class="f-s"></div><div class="f-m">
	<h2><em>发表<?php echo $isgb;?>：</em><span class="thin"> [支持<a href="http://en.gravatar.com/" target="_blank">gravatar</a>头像] - [文明评论 共同进步]</span>
    <span id="view-cmt">查看<?php echo $isgb;?></span></h2>
	<div id="comment-place">
	<div class="box" id="comment-post">
	<ul id="respond-form">
    <form method="post"  name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
<?php if(ROLE == 'visitor'): ?>
<?php if($ckname != ''): ?>
		 <li>欢迎回来，<b class="red"><?php echo $ckname; ?></b>  <a href="javascript:void(0);" onclick="toggleInput()">&nbsp;&nbsp;换个昵称</a></li>
<?php endif; ?>
		 <li id="userinfo"<?php if($ckname != '') echo ' style="display:none;"'; ?>>
			 <p><input type="text" name="comname" id="author" value="<?php echo $ckname; ?>" /><label for="author">昵称 *</label></p>
			 <p><input type="text" name="commail" id="email" value="<?php echo $ckmail; ?>" /><label for="email" class="gray">邮箱 [选填不公布]</label></p>
			 <p><input type="text" name="comurl" id="url" value="<?php echo $ckurl; ?>" /><label for="url" class="gray">网站 [选填]</label></p>
		 </li>
<?php
	else:
	$CACHE = Cache::getInstance();
	$user_cache = $CACHE->readCache('user');
?>
		 <li>您当前已登录为 <b class="red"><?php echo $user_cache[UID]['name']; ?></b></li>
<?php endif; ?>
         <li><textarea name="comment" id="comment"  rows="10" tabindex="4"></textarea></li>
         <li class="form-post">
            <span class="cheackimg"><?php echo $verifyCode; ?></span>
            <button class="btn" type="submit" name="submit" id="submit" value="发表评论" onclick="return checkform()">提交</button>
			<button class="btn cancel-reply" type="button" id="cancel-reply" style="display:none" onclick="cancelReply()">取消</button>
			<input type="hidden" name="gid" value="<?php echo $logid; ?>"  size="22" tabindex="1"/>
			<input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/>
		</li>
	</form>
	</ul>
	</div></div>
</div><div class="f-e"></div>
</div><!-- /respond -->
	<?php endif; ?>
<?php }?>
<?php
//边栏tab：最新评论与最新留言
function tab_newcomm($logid = null,$get_total="5"){
	global $CACHE;
	$timezone = Option::get('timezone');
	$guestbook_id= $GLOBALS['tcms']['guestbook_id'];
	$com_cache = $CACHE->readCache('comment');
    $cmt = array();
    if($logid == null){
        $cmt=$com_cache;
    }else{
        $db=MySql::getInstance();
        $sql = "SELECT cid,gid,date,poster,mail,comment FROM " . DB_PREFIX . "comment WHERE hide='n' and gid=$logid ORDER BY date DESC LIMIT 0, $get_total";
        $ret= $db->query($sql);
        while($row = $db->fetch_array($ret)){
            $cmt[] = array(
                'cid' => $row['cid'],
                'gid' => $row['gid'],
                'name' => htmlspecialchars($row['poster']),
                'mail' => $row['mail'],
                'date' => $row['date'],
                'content' => htmlClean(subString($row['comment'], 0, 36), false)
            ); }
        }
    if(count($cmt)==0){
        echo $logid == null ? "暂无评论":"暂无留言";
    }else{
    $count=0;
	foreach($cmt as $key=>$value):
    if($count==$get_total)break;
    if($logid==null && $value['gid']==$guestbook_id)continue;
    $gface_url = "http://www.gravatar.com/avatar/".md5($value['mail'])."?size=32&d=".TEMPLATE_URL."images/ava_d.gif";
	$cmt_url = Url::log($value['gid']).'#comment-'.$value['cid'];
?>
    <dl>
        <dt class="avatar"><img src="<?php echo $gface_url; ?>" width="32" /></dt>
        <dd class="name"><?php echo $value['name']; ?></dd><dd class="date"><?php echo gmdate('m-d H:i', $value['date']+ $timezone * 3600); ?></dd>
        <dd class="txt"><a href="<?php echo $cmt_url; ?>"><?php echo $value['content']; ?></a></dd>
    </dl>
<?php $count++; endforeach; }?>
<?php }?>
<?php
//tab:最新发表、热评文章、推荐文章
function home_getloglist($way="random",$get_total="8") {
	$timezone = Option::get('timezone');
	$log_target=$GLOBALS['tcms']['log_target'];
	$hot=$GLOBALS['tcms']['hot'];
    $target = $log_target ? 'target="'.$log_target.'"':'';
    if($way=="newpost"){//最新发表
        $order = 'ORDER BY date DESC';
    }elseif($way=="hot"){//热评文章
        $order = 'ORDER BY comnum DESC';
    }else{//推荐文章
        $order = 'ORDER BY rand()';
    }
    $db=MySql::getInstance();
    $logs = $db->query("SELECT gid,title,date,comnum FROM " . DB_PREFIX . "blog WHERE hide='n' and type='blog' $order LIMIT 0, $get_total");
    while ($row = $db->fetch_array($logs)){
        $row['title'] = htmlspecialchars($row['title']);
     ?>
    <li><em><a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>" <?php echo $target;?>><?php echo $row['title']; ?></a></em>
    <?php if($row['comnum'] >= $hot) echo '<i class="hot">热门</i>'; ?>
	<?php if((time() - $row['date']) / 86400 <= 3) echo '<i class="new">最新</i>'; ?>
    <span class="date"><?php echo gmdate('m-d H:i', $row['date'] + $timezone * 3600); ?></span></li>
	<?php } ?>
<?php }?>
<?php
//首页调用的栏目列表
function home_category($to="list",$get_total="8") {
	global $CACHE;
	$timezone = Option::get('timezone');
	$log_target=$GLOBALS['tcms']['log_target'];
	$hot=$GLOBALS['tcms']['hot'];
	$sort_cache = $CACHE->readCache('sort');
	if ($get_total > 8) $get_total = 8; //调用超过8个的话，就得改css来适应高度
    $target = $log_target ? 'target="'.$log_target.'"':'';
    if ($to=="nav") {//调用菜单
		$count=0;
	    foreach ($sort_cache as $value){
			if($count==$get_total)break; 
		    echo "\n".'<li><a href="#part-'.$value['sid'].'"><span>'.$value['sortname'].'</span></a></li>';
	    $count++;
        }
    }else {//调用文章
        foreach($sort_cache as $value){
		echo '<div id="part-'.$value['sid'].'"><ul class="list">';
		$db=MySql::getInstance();
        $sortid = $value['sid'];
		$sql = "SELECT gid,title,date,comnum FROM " . DB_PREFIX . "blog WHERE type='blog' and hide='n' and sortid=$sortid ORDER BY date DESC LIMIT 0, $get_total";
        $logs = $db->query($sql);
        while ($row = $db->fetch_array($logs)){
           $row['title'] = htmlspecialchars(trim($row['title']));
           echo '<li><em><a href="'.Url::log($row['gid']).'" rel="bookmark" title="Permanent Link to '.$row['title'].'" '.$target.'>'.$row['title'].'</a></em>';
	       echo $row['comnum'] >= $hot ? '<i class="hot">热门</i>' : '';
           echo (time() - $row['date']) / 86400 <= 3 ? '<i class="new">最新</i>' : '';
	       echo '<span class="date">'.gmdate('m-d H:i', $row['date'] + $timezone * 3600).'</span></li>'."\n";
        }
		   echo '</ul></div>';
        }
    }
}?>
<?php
//首页幻灯片
function home_slide() {
	$new_img_count=$GLOBALS['tcms']['new_img_count'];
    $slide = '';
    $slide .= '<div id="slide-pic">';
    $db = MySql::getInstance();
    $sql = "SELECT blogid as g,filepath,(SELECT title FROM ".DB_PREFIX."blog where `gid`=g) as t FROM ".DB_PREFIX."attachment WHERE `filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png' GROUP BY `blogid` ORDER BY `addtime` DESC LIMIT 0, $new_img_count";
    //die($sql);
	$imgs = $db->query($sql);
    while($row = $db->fetch_array($imgs)){
        $slide .= '
<div><a title="'.$row['t'].'" href="'.Url::log($row['g']).'"><img src="'.BLOG_URL.substr($row['filepath'],3,strlen($row['filepath'])).'"/></a>
<p><span><a href="'.Url::log($row['g']).'" title="'.$row['t'].'">'.$row['t'].'</a></span></p></div>'."\n";
    }
    $slide .= '</div><div id="controller">';
    for ($i=0; $i<($new_img_count); $i++){
	    $slide .= '<span class="jFlowControl">'.$i.'</span>';
    }
    $slide .= '</div>';
    if ($new_img_count>1){
        $slide .= '<div id="slide-btn"><a title="上一张" class="jFlowPrev">上一张</a><a title="下一张" class="jFlowNext">下一张</a></div>'."\n";
    }
    echo $slide;
}?>
<?php
//blog：导航
function blog_navi(){
        global $CACHE; 
        $navi_cache = $CACHE->readCache('navi');
        ?>
<div id="nav" class="menu-default-container">
    <ul class="menu" id="menu-default">
        <?php 
        foreach($navi_cache as $key=>$value):
            if($value['url'] == 'admin') {continue;}
            $newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
            $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
            $current_tab = (BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url']) ? 'current' : 'common';
        ?>
        <li class="<?php echo $current_tab;?>"><a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a></li>
        <?php endforeach; ?>
    </ul>
</div>
<?php }?>