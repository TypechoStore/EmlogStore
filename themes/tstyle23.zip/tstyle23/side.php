<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
$guestbook_id= $GLOBALS['tcms']['guestbook_id']; 
$nothome= $pageurl == Url::logPage() ? 0:1;
if (!isset($user_cache)) {$user_cache = CACHE::readCache('user');}
?>
<div id="side" class="col-6 last">

	<div id="contact" class="col-6 last">
	<div class="f-s"></div>
	<div class="f-m">
		<h2><em>联系我</em><span>Contact Me</span></h2>
        <div class="content">
		<table width="100%" border="0" cellpadding="0" cellspacing="0"><tr>
				<td class="email"><a href="mailto:<?php echo $user_cache[1]['mail']; ?>" title="给我邮件">电子邮件</a></td>
				<td class="microblog"><a target="_blank" href="<?php echo BLOG_URL; ?>t" title="碎语">碎语</a></td>
				<td class="msn"><a href="msnim:chat?contact=zj86@live.cn" title="MSN联系">MSN</a></td>
				<td class="guestbook"><a href="<?php echo BLOG_URL; ?>?post=<?php echo $guestbook_id;?>" title="留言给我">留言本</a></td>
		</tr></table>
	</div></div>
	<div class="f-e"></div>
	</div><!-- /contact -->

<?php if($nothome) include View::getView('focus');?>

	<div id="side-cmt" class="col-6 last">
		<ul class="tab">
			<li><a href="#side-cmt-1" onFocus="this.blur()">最新留言</a></li>
			<li><a href="#side-cmt-2" onFocus="this.blur()">最新评论</a></li>
		</ul>
		<div class="f-m">
			<div id="side-cmt-1" class="side-cmt">
<?php tab_newcomm($guestbook_id); ?>
			</div>
			<div id="side-cmt-2" class="side-cmt">
<?php tab_newcomm(); ?>
		    </div>
		</div>
		<div class="f-e"></div>
	</div><!-- /side-cmt -->

<?php 
if($nothome){
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
    foreach ($widgets as $val){
		$widget_title = @unserialize($options_cache['widget_title']);
		$custom_widget = @unserialize($options_cache['custom_widget']);
		if(strpos($val, 'custom_wg_') === 0){
			$callback = 'widget_custom_text';
			if(function_exists($callback)) call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content'], $val);
		}else{
			$callback = 'widget_'.$val;
			if(($curpage!=CURPAGE_LOG) && ($val=='tag'))continue;
			if(function_exists($callback)){
				preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
				$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
				call_user_func($callback, htmlspecialchars($wgTitle));
			}
		}
	}
}else{
	$widget_title = @unserialize($options_cache['widget_title']);
	widget_tag($widget_title['tag']);
}
?>
</div>
<!--end sidebar-->