<?php
/*
Template Name:Tstyle 2.3
Description:Emlog的第一个CMS风格模板
Author:Jony
Author Url:http://zj86.info
Sidebar Amount:1
ForEmlog:5.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('options');
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php log_tags($logid);?><?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<!--[if ie 6]><link href="<?php echo TEMPLATE_URL; ?>images/ie6.css" rel="stylesheet" /><![endif]-->
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="wrap">
<div id="head">
    <div id="head-logo" class="col-6">
	<h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
	</div>
	<div id="head-banner" class="col-11"><!-- head-banner --></div>
    <div id="head-nav" class="col-6 last">
		<?php if($istwitter == 'y'):?>
        <a id="suiyu" href="<?php echo BLOG_URL; ?>t/">碎语</a><span class="cut">|</span><div id="sponsor">去瞅瞅最近唠叨些啥</div>
        <?php endif;?>
		<a href="#" onclick="showContact();">给我建议</a><span class="cut">|</span>
<?php if(ROLE == 'admin' || ROLE == 'writer'): ?><span class="adm">
        <a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a>
        <a href="<?php echo BLOG_URL; ?>admin/">管理</a>
		<a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></span>
<?php else: ?>
		<a href="<?php echo BLOG_URL; ?>admin/">登录</a>
<?php endif; ?>
    </div>

    <div id="search" class="col-5 last">
	<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>">
		<input type="text" name="keyword" id="s" onblur="if (this.value == '') {this.value = '请输入关键字...';}" onfocus="if (this.value == '请输入关键字...') {this.value = '';}" value="请输入关键字..." />
		<button type="submit">搜索</button>
	</form>
    </div>

<?php blog_navi();?>
</div><!--head end-->