<?php 
/*
* 日志列表
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
if($pageurl == Url::logPage()){
	include View::getView('home');
}else{
?>
<div id="container" class="clearfix">
<div id="main" class="col-17">

	<div id="archive">
	<div class="f-s"></div>
	<div class="f-m">
		<h2><em><a title="回到首页" href="<?php echo BLOG_URL; ?>">首页</a></em><span class="cut">&raquo;</span>
<?php 
	if ($params[1]=='sort'){ 
		if(isset($_GET['sort'])){
			$sortname= $sort_cache[$_GET['sort']]['sortname'];
		}else{
			foreach($sort_cache as $val){
				if($val['alias']!='' && $params[2]==$val['alias']) $sortname= $val['sortname'];
			}
		}
?>
			<em><?php echo $sortname;?></em>
<?php }elseif ($params[1]=='tag'){ ?>
			<span>包含标签</span><em>“<?php echo urldecode($params[2]);?>”</em><span>的文章</span>
<?php }elseif($params[1]=='author'){ ?>
			<span>作者</span><em>"<?php echo blog_author($author);?>"</em><span>的文章</span>
<?php }elseif($params[1]=='keyword'){ ?>
            <span>包含关键词</span><em>“<?php echo urldecode($params[2]);?>”</em><span>的搜索结果</span>
<?php }elseif($params[1]=='record'){ ?>
            <span>在</span><em>“<?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?>”</em><span>发表的文章</span>
<?php }else{?><?php }?>
			</h2>
		<div class="box">
<?php doAction('index_loglist_top'); ?>
    <ul class="list">
<?php foreach($logs as $value):?>
<li>
	<em><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>" rel="bookmark" title="Permanent Link to <?php echo $value['log_title']; ?>">
    <?php echo $value['log_title']; ?></a></em>
	<?php if(date('ymd',gmmktime()) - gmdate('ymd', $value['date']) <= 3) echo '<i class="new">最新</i>'; ?>
	<?php if($value['comnum'] > 10) echo '<i class="hot">热门</i>'; ?>
	<span class="date"><?php echo gmdate('m-d H:s', $value['date']); ?></span>
</li>
<?php endforeach;?>

    </ul>
<?php if($page_url) : ?><div id="pagenavi"><?php echo $page_url;?></div><?php endif; ?>
	</div>
	</div>
	<div class="f-e"></div>
	</div><!-- /archive -->

<?php 
	$widget_title = @unserialize($options_cache['widget_title']);
	widget_tag($widget_title['tag']);
?>

</div>
<?php include View::getView('side');?>
</div><!--end container-->
<?php include View::getView('footer');?>
<?php mysql_close();}?>