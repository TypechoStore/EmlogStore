<?php
/**
 *模板tstyle配置文件
*/
$GLOBALS['tcms']= array(
	'new_img_count' => 6, 		//首页幻灯片（最新图片）张数
	'guestbook_id' => 76, 		//留言本页面ID（即留言本页面的地址栏中最后面的数字）【此项重要，一定要更改为你的留言本ID】
	'log_target' => '',			//首页日志列表链接打开方式：留空（默认）为当前页打开、新页面打开（_blank）
	'hot' => 10, 				//日志评论数量大于等于多少标记为“热”
    'tabs_event' => 'click'     //切换选项卡的方式，参数：'click'(点击,默认) 或 'mouseover'(鼠标滑过)
);
/*其他说明：
以上默认配置就是我博客的配置，你至少需要修改： “guestbook_id”
边栏【联系我】请修改“side.php” 中 联系我栏目：<table>标记对的代码
*/
?>