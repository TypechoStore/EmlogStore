<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container" class="clearfix">
<div id="main" class="col-17">
<div id="content">
<div class="f-s"></div>
<div class="f-m">
<h2><em><a title="回到首页" href="<?php echo BLOG_URL; ?>">首页</a></em><span class="cut">&raquo;</span>
    <em><?php blog_sort($sortid, $logid); ?></em><span class="cut">&raquo;</span>
    <em><?php echo $log_title; ?></em></h2>
	<div class="box">
    <h1><?php topflg($top); ?><?php echo $log_title; ?></h1>
		<div id="article-inf">
            <span class="author" title="作者">Author:<?php blog_author($author); ?></span>
			<span class="ico date" title="发表时间"><?php echo gmdate('Y-n-j G:i l', $date); ?></span>
			<span class="ico view" title="点击量"><?php echo $views; ?></span>
			<span class="ico cmt" title="文章评论"><a href="#comment-list"><?php echo $comnum; ?></a></span>
			<span class="edit"><?php editflg($logid,$author); ?></span>
			<?php if ($allow_remark == 'y') : ?><span class="ico cmt add"><a class="respond">发表评论</a></span><?php endif; ?>
			<span class="ico rss"></span>
		</div>
		<div id="article-cnt">
            <div id="article-tag">
				<?php blog_tag($logid); ?>
            </div>
            <!--div id="article-dfn"></div-->
            <?php echo $log_content; ?>
        </div>
        <?php blog_att($logid); ?>
        <?php blog_trackback($tb, $tb_url, $allow_tb); ?>
        <div id="p-n"><?php neighbor_log($neighborLog); ?></div>
        <?php doAction('log_related', $logData); ?>
    </div>
</div>
<div class="f-e"></div>
</div><!-- /content -->
<?php if ($allow_remark == 'y'){blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);}?>
<?php blog_comments($comments,$logid,$params); ?>
</div>
<?php include View::getView('side');?>
</div><!--end container-->
<?php include View::getView('footer');?>