<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container" class="clearfix">
<div id="main" class="col-17">
<div id="content">
<div class="f-s"></div><div class="f-m">
<h2><em><a title="回到首页" href="<?php echo BLOG_URL; ?>">首页</a></em><span class="cut">&raquo;</span>
<?php if(isset($_GET['plugin'])){ 
  $log_title=$navibar[addslashes($_GET['plugin'])]['title'];
 } ?>
<em><?php echo $log_title; ?></em></h2>

<div id="article-cnt">
<?php echo $log_content; ?>
</div>

</div><div class="f-e"></div>
</div><!--/content-->
<?php if ($allow_remark == 'y'){
	blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark);
	blog_comments($comments,$logid,$params);
}?>
</div><!--/main-->

<?php include View::getView('side');?>
</div><!--/container-->
<?php include View::getView('footer');?>