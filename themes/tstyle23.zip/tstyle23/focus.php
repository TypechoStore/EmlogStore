    <div id="choice" class="col-11 last">
	<ul class="tab">
		<li><a href="#choice-1" onFocus="this.blur()">最新发表</a></li>
		<li><a href="#choice-2" onFocus="this.blur()">热评文章</a></li>
		<li><a href="#choice-3" onFocus="this.blur()">推荐文章</a></li>
	</ul>
	<div class="f-m">
		<div id="choice-1">
		<ul class="list">
            <?php home_getloglist("newpost","8"); ?>
		</ul>
		</div>
		<div id="choice-2">
		<ul class="list">
            <?php home_getloglist("hot","8"); ?>
		</ul>
		</div>
		<div id="choice-3">
		<ul class="list">
            <?php home_getloglist("random","8"); ?>
		</ul>
		</div>
	</div>
	<div class="f-e"></div>
    </div><!-- /choice -->