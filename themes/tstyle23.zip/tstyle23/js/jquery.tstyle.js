(function(){var dep;var init=function(){(function($){$.fn.idTabs=function(){var s={};for(var i=0;i<arguments.length;++i){var a=arguments[i];switch(a.constructor){case Object:$.extend(s,a);break;case Boolean:s.change=a;break;case Number:s.start=a;break;case Function:s.click=a;break;case String:if(a.charAt(0)=='.')s.current=a;else if(a.charAt(0)=='!')s.event=a;else s.start=a;break;}}
if(typeof s['return']=="function")
s.change=s['return'];return this.each(function(){$.idTabs(this,s);});}
$.idTabs=function(tabs,options){var meta=($.metadata)?$(tabs).metadata():{};var s=$.extend({},$.idTabs.settings,meta,options);if(s.current.charAt(0)=='.')s.current=s.current.substr(1);if(s.event.charAt(0)=='!')s.event=s.event.substr(1);if(s.start==null)s.start=-1;var showId=function(){if($(this).is('.'+s.current))
return s.change;var id="#"+this.href.split('#')[1];var aList=[];var idList=[];$("a",tabs).each(function(){if(this.href.match(/#/)){aList.push(this);idList.push("#"+this.href.split('#')[1]);}});if(s.click&&!s.click.apply(this,[id,idList,tabs,s]))return s.change;for(i in aList)$(aList[i]).removeClass(s.current);for(i in idList)$(idList[i]).hide();$(this).addClass(s.current);$(id).show();return s.change;}
var list=$("a[href*='#']",tabs).unbind(s.event,showId).bind(s.event,showId);list.each(function(){$("#"+this.href.split('#')[1]).hide();});var test=false;if((test=list.filter('.'+s.current)).length);else if(typeof s.start=="number"&&(test=list.eq(s.start)).length);else if(typeof s.start=="string"&&(test=list.filter("[href*='#"+s.start+"']")).length);if(test){test.removeClass(s.current);test.trigger(s.event);}
return s;}
$.idTabs.settings={start:0,change:false,click:null,current:".current",event:"!click"};$.idTabs.version="2.2";$(function(){$(".idTabs").idTabs();});})(jQuery);}
var check=function(o,s){s=s.split('.');while(o&&s.length)o=o[s.shift()];return o;}
var head=document.getElementsByTagName("head")[0];var add=function(url){var s=document.createElement("script");s.type="text/javascript";s.src=url;head.appendChild(s);}
var s=document.getElementsByTagName('script');var src=s[s.length-1].src;var ok=true;for(d in dep){if(check(this,d))continue;ok=false;add(dep[d]);}if(ok)return init();add(src);})();

$(function() {
     //ctrl+enter提交评论
    $("#comment").keydown(function(event){if(event.ctrlKey && event.keyCode == 13){jQuery("#submit").click();} });
    //顶部碎语
	$("#suiyu").hover(
		function() {$("#sponsor").slideDown(200); $("#sponsor").attr("style","display:block;");},
		function() {$("#sponsor").fadeOut(200); }
	);
	//列表隔行换色
	$(".list li:odd ,#related_log p:odd").addClass("odd");
	//初始化选项卡
	$("#choice ul:first").idTabs();
	$("#side-cmt ul:first").idTabs();
	$("#column-nav ul:first").idTabs();
	//鼠标经过tips效果
	$("#container a").mouseover(function(tips){
		this.tipsTxt = this.title;
		this.tipsTxt = (this.tipsTxt.length>50?this.tipsTxt.toString().substring(0,50)+"...":this.tipsTxt);
			if (this.tipsTxt){
				this.tipsUrl = this.href;
				this.title = "";
				var tips = "<div id='tips'><p>"+this.tipsTxt+"</p><p><em>"+this.tipsUrl+"</em>"+"</p></div>";
				$('body').append(tips);
				$('#tips').css({"opacity":"0.8"})
			}
		}).mouseout(function(){
			this.title=this.tipsTxt;
			$('#tips').remove();
		}).mousemove(function(tip){ $('#tips').css({"top":(tip.pageY+22)+"px","left":(tip.pageX-10)+"px"});
	});
	//新窗口打开
	$(function() { $("a[rel*='external']").attr("target","_blank") });
	//滑动到顶部
	$('#to-top').click(function() { $('html,body,#wrap').animate({ scrollTop: 0 }, 1000); });
    //快速评论
    $('.respond').click(function(){$('html,body').animate({scrollTop:$('#comment-place').offset().top}, 1000);});
    //查看评论
    $('#view-cmt').click(function() { $('html,body').animate({ scrollTop:$('#comment-list').offset().top}, 1000); });
});
//闪动联系我
function showContact() {
	for (i = 0; i<5; i++) {
		$("#contact").fadeOut(200);
		$("#contact").fadeIn(100);
	}
}
function toggleInput(){
	$("#userinfo").toggle("normal");
	return !1
}
function showLoad(){
	$("#loading:hidden").animate({top:'10px',opacity:'1'},1000).animate({top:'12px'},500).animate({top:'10px'},500);
}
function hideLoad(){$("#loading:visible").animate({top:'12px'},300).animate({top:'-30px',opacity:'0'},300); $('#head-logo h1').addClass('tada');}
