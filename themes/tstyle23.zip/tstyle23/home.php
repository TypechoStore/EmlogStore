<?php 
/*
* 首页栏目使用
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
$isHome = true;
?>
<div id="container" class="home clearfix">
<?php doAction('index_loglist_top'); ?>
<div id="main" class="col-17">

	<div id="slide" class="col-6">
	<h2>幻灯片</h2>
	<div class="f-s"></div><div class="f-m">
<?php home_slide();?>
	</div><div class="f-e"></div>
	</div><!-- /slide -->

<?php include View::getView('focus');?>

	<div id="home-album" class="col-17 last">
	<div class="f-s"></div><div class="f-m">
		<h2><em>相册图集</em><span>Album</span><a class="more" href="<?php echo BLOG_URL?>?plugin=kl_album">更多...</a></h2>
		<div class="box">
<?php include View::getView('album');?>
		</div>
	</div><div class="f-e"></div>
	</div><!-- /album -->

    <div id="home-column" class="col-17 last">
        <div class="col-5" id="column-nav">
		    <ul><?php home_category("nav","8"); ?></ul>
	    </div>
        <div class="col-12 last" id="part">
        <div class="f-s"></div><div class="f-m">
            <?php home_category("list","8"); ?>
	    </div><div class="f-e"></div>
	    </div>
	</div><!-- /home-column -->

</div><!-- /main -->

<?php include View::getView('side');?>

<div id="friendly">
<div class="f-s"></div><div class="f-m">
	<h2><em>友情链接</em><span>Friendly</span><!--a href="#" title="更多..." class="more">更多...</a--></h2>
	<div class="box">	
	<h3>文字链接</h3>
	<div id="friendly-txt" class="clearfix"><ul>
	<?php 
		global $CACHE; 
		$link_cache = $CACHE->readCache('link');
		foreach($link_cache as $value): ?>
	<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
	<?php endforeach; ?>
	</ul></div>
	</div>
</div><div class="f-e"></div>	
</div>
</div><!--end container-->
<?php include View::getView('footer');?>