<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
    <div id="foot">
        <div class="col-13">
            <p id="copyright">
                Copyright &copy; 2010 <?php echo $blogname; ?>, &nbsp;
                Powered by <a href="http://bbs.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">emlog</a>, 
                Designed by <a href="http://www.dafi.cn" target="_blank">dafi</a>, 
                Themed by <a href="http://zj86.info" target="_blank">Jin</a>.
                <span<?php if(ROLE != 'admin' and ROLE != 'writer'): ?> style="position:absolute;top:-100px;left:-100px;"<?php endif; ?>><script src="http://s4.cnzz.com/stat.php?id=2135532&web_id=2135532" type="text/javascript"></script></span>
             </p>
            <?php if($footer_info) echo '<div>'.$footer_info.'/div'; ?>
        </div>
    </div><!-- /foot -->
    <div id="special"><div id="to-top"><a>回到页首</a></div></div>
</div><!-- /wrap -->
<script>window.jQuery || document.write('<script src="http://ajax.aspnetcdn.com/ajax/jquery/jquery-1.7.1.min.js">\x3C/script>');</script>
<script src="<?php echo TEMPLATE_URL; ?>js/jquery.tstyle.js"></script>
<?php 
if ($GLOBALS['tcms']['tabs_event']=='mouseover') {
    echo '<script>$.idTabs.settings.event="!mouseover";</script>'."\n";
}
if($isHome) {
    echo '<script src="'.TEMPLATE_URL.'js/jquery.flow.js"></script>'."\n";
    echo '<script>$("div#controller").jFlow({ slides: "#slide-pic", width: "220px", height: "227px" });</script>'."\n";
}
?>
<?php doAction('index_footer'); ?>
</body>
</html>