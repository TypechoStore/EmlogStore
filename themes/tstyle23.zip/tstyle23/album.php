<?php
/*
 * 模板tstyle首页相册模块调用，修改自kl_album插件
 * 本页面需要emlog相册插件：kl_album 的支持
 */
!defined('EMLOG_ROOT') && exit('access deined!');
$DB = MySql::getInstance();
$query = $DB->query("SELECT * FROM ".DB_PREFIX."options WHERE option_name='kl_album_info'");
if($DB->num_rows($query) == 0){
    $album_list = "还没有创建相册！";
}else{
    $row = $DB->fetch_row($query);
    $kl = unserialize($row[2]);
    krsort($kl);

    $album_list = '<ul class="clearfix">';
    $count = 0;
    foreach ($kl as $val){
        if($count==6)break;
        if($val['name'] == '') continue;
        if(ROLE != 'admin'){
            if($val['restrict'] == 'private') continue;
        }
        
        if($val['restrict'] == 'private'){
            $coverPath = 'images/only_me.jpg';
        }else{
            if(isset($val['head']) && $val['head'] != 0){
                $iquery = $DB->query("SELECT * FROM ".DB_PREFIX."kl_album WHERE id={$val['head']} LIMIT 1");
                if($DB->num_rows($iquery) > 0){
                    $irow = $DB->fetch_row($iquery);
                    $coverPath = substr($irow[2], strpos($irow[2], 'upload/'), strlen($irow[2])-strpos($irow[2], 'upload/'));
                }else{
                    $coverPath = 'images/no_cover_s.jpg';
                }
            }else{
                $iquery = $DB->query("SELECT * FROM ".DB_PREFIX."kl_album WHERE album={$val['addtime']} LIMIT 1");
                if($DB->num_rows($iquery) > 0){
                    $irow = $DB->fetch_array($iquery);
                    $coverPath = substr($irow['filename'], strpos($irow['filename'], 'upload/'), strlen($irow['filename'])-strpos($irow['filename'], 'upload/'));
                }else{
                    $coverPath = 'images/no_cover_s.jpg';
                }
            }
        }
    $album_list.= '
<li><a href="./?plugin=kl_album&album='.$val['addtime'].'" title="'.$val['name'].'"><img width="80" height="60" src="./content/plugins/kl_album/'.$coverPath.'"><span>'.$val['name'].'</span></a></li>';
        $count++;
    }
    $album_list.= '</ul>';
}
echo $album_list;
?>