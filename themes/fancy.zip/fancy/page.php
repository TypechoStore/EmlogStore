<?php 
/*
* 自建页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="main">
	<div class="leftbar">
    <?php include View::getView('side'); ?>
    </div>
    <div class="main-right">
    	<div class="main-right-top">当前位置：<a href="<?php echo BLOG_URL; ?>">网站首页</a> > <a href="<?php echo $log_url; ?>"><?php echo $log_title; ?></a><div class="edit"><?php editflg($logid,$author); ?></div>
        </div>
        <div class="main-right-content">
            <div class="main-right-content-content"><?php echo $log_content; ?>
            </div>
            <div class="main-right-content-info">点击次数：<?php echo $views; ?> 更新时间：<?php echo gmdate('Y-m-d G:i', $date); ?>
            </div>
        </div>
    </div>
</div>
<?php include View::getView('footer'); ?>