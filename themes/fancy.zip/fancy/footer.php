<?php 
/*
* 尾部
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div class="footer">
    	<div class="footer-title">
        	<div class="footer-title-name">友情链接
            </div>
        </div>
        <div class="footer-content">
        <?php echo widget_link(); ?>
        </div>
	</div>
    <div class="right">
    Powered by <a href="http://emlog.net">emlog</a>. Written by <a href="http://sinkery.com">sinkery</a>.<br /><a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
<?php doAction('index_footer'); ?>
    </div>
    <div class="serv-new">
    	<div class="serv-box">
        	<div class="serv-title">客服盒子
            </div>
            <div class="serv-content">
            <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=399598038&site=qq&menu=yes"><img border="0" src="http://wpa.qq.com/pa?p=2:399598038:41" alt="点击这里给我发消息" title="点击这里给我发消息"/></a>
            </div>
        </div>
    </div>
</div>
</body>
</html>