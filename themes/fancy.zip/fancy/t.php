<?php 
/*
* 公告
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="main">
	<div class="leftbar">
    <?php include View::getView('side'); ?>
    </div>
    <div class="main-t">
  		<div class="main-right-top">当前位置：<a href="<?php echo BLOG_URL; ?>">网站首页</a> > <a href="<?php echo BLOG_URL; ?>t/"><?php echo $Navi_Model->getNaviNameByUrl('t'); ?></a><span class="t-write"><a href="<?php echo BLOG_URL . 'admin/twitter.php' ?>">写碎语</a></span></div>
        <div class="main-t-list">
    		<?php foreach($tws as $val): ?><div class="t"><?php $tid = (int)$val['id'];echo $val['t']; ?></div>
       		<div class="time"><?php echo $val['date'];?></div>
    		<?php endforeach;?>
   		</div>
        <div class="pagenavi"><?php echo $pageurl;?></div>
    </div>
</div>
<?php include View::getView('footer'); ?>