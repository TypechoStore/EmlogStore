<?php 
/*
* 边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="side-comp">
	<div class="side-comp-title">
    	<div class="side-comp-title-name">企业动态
        </div>
        <div class="side-comp-title-more"><a href="<?php echo BLOG_URL; ?>t/">更多</a>
        </div>
    </div>
    <div class="side-comp-content">
    <?php echo widget_twitter(); ?>
    </div>
</div>
<div class="side-new">
	<div class="side-new-title">
    	<div class="side-new-title-name">最近更新
        </div>
    </div>
    <div class="side-new-content">
	<?php widget_newlog(); ?>
    </div>
</div>
<div class="side-contact">
	<div class="side-contact-title">
    	<div class="side-contact-title-name">联系我们
        </div>
    </div>
    <div class="side-contact-content">
    天津骏森投资咨询有限公司<br />
    联系电话：18630970137（冯经理）<br />
    公司地址：天津市河东区小卫国道翰林园底商1-1-101<br />
    乘车路线：<br />
    长征路站：639、842、902、635、665、660<br />
    卫国道站：47、656、912、30、35、608、871<br />
    华北医院站：35、462、803、856、836、600<br />
    	<iframe src="<?php echo TEMPLATE_URL; ?>map.html" frameborder="0" width="300" height="225" scrolling="no">
        </iframe>
    </div>
</div>
<div class="side-human">
	<div class="side-human-title">
    	<div class="side-human-title-name">人才招聘
        </div>
        <div class="side-human-title-more"><a href="">更多</a>
        </div>
    </div>
    <div class="side-human-content">
    </div>
</div>