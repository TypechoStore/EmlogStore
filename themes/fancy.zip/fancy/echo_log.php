<?php 
/*
* 输出
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="main">
	<div class="leftbar">
    <?php include View::getView('side'); ?>
    </div>
    <div class="main-right">
    	<div class="main-right-top">当前位置：<a href="<?php echo BLOG_URL; ?>">网站首页</a> > <?php blog_sort($logid); ?> <div class="edit"><?php editflg($logid,$author); ?></div>
        </div>
        <div class="main-right-content">
        	<div class="main-right-content-title"><?php topflg($top); ?><?php echo $log_title; ?>
            </div>
            <div class="main-right-content-content"><?php echo $log_content; ?>
            </div>
            <div class="main-right-content-info"><?php blog_tag($logid); ?> 点击次数：<?php echo $views; ?> 更新时间：<?php echo gmdate('Y-m-d G:i', $date); ?>
            </div>
            <div class="point"><?php doAction('log_related', $logData); ?></div>
            <div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
        </div>
    </div>
</div>
<?php include View::getView('footer'); ?>