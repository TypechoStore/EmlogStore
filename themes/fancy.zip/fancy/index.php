<?php
/*
首页
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div class="main">
	<div class="main-left">
    	<div class="main-left-about">
        	<div class="main-left-about-title">
            	<div class="aboutus">关于我们</div>
            </div>
            <div class="about-content"><?php echo widget_blogger(); ?>
            </div>
        </div>
        <?php
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort');
	foreach($sort_cache as $value){ ?>
  <div class="sortnum">
    <div class="sorttitle">
    	<div class="sortname"><?php echo $value['sortname']; $a=$value['sortname']; ?></div>
        <div class="sortmore"><a href="<?php echo Url::sort($value['sid']); ?>"><img src="<?php echo TEMPLATE_URL; ?>images/more.gif" width="39" height="11" /></a></div>
    </div>
    <div class="sortcont">
    <?php 
	  $logss = $Log_Model->getLogsForHome($sqlSegment, $page, 999999);
      foreach($logss as $value){
				$b = blogg_sort($value['logid']);
				if($a == $b){
					echo "<a href=".$value['log_url'].">".subString($value['log_title'],0,16)."</a><span>".gmdate('Y-m-d', $value['date'])."</span><br />";
				}
			}?>
    </div>
  </div>
  <?php } ?>
  	<div class="show">
    	<div class="show-title">
        	<div class="show-title-name">企业展示
            </div>
        </div>
        <div class="show-content">
        	<marquee behavior="alternate" scrollamount="10" onmouseover="this.stop()" onmouseout="this.start()">
        		 <?php $imgGalleryArray = glob("content/templates/fancy/images/show/*.*"); ?>
            <?php foreach($imgGalleryArray as $key => $value){ ?>
                <a href="<?php echo BLOG_URL; ?><?php echo $value; ?>" title="<?php echo substr($value,36); ?>" target="_blank" ><img src="<?php echo BLOG_URL; ?><?php echo $value; ?>" height="100" alt="骏森投资"  /></a>
            <?php } ?>
            </marquee>
        </div>
    </div>
	</div>
    <div class="rightbar">
	<?php include View::getView('side'); ?>
	</div>
</div>
<?php
 include View::getView('footer');
?>