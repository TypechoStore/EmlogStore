<?php
/*
Template Name:畅想
Description:红色系，企业站模板（骏森投资专用）
Version:1.5.6
Author:sinkery
Author Url:http://sinkery.com
Sidebar Amount:1
ForEmlog:5.0.1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>css/style.css" rel="stylesheet" type="text/css" />
<link type="text/css" rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>switch/css.css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>

<body>
<div class="wrap">
	<div class="header-back">
    	<div class="header">
    		<a href="<?php echo BLOG_URL; ?>"><div class="logo"></div></a>
            <div class="search" id="search">
            	<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
					<input name="keyword" type="text" value="搜索从这里开始" onFocus="if(value==defaultValue){value='';}"
onBlur="if(!value){value=defaultValue;}" />
					<input name="submit" type="submit" value="搜索" />
				</form>
            </div>
            <div class="info"><?php echo $bloginfo; ?>
            </div>
        	<div class="nav"><?php echo blog_navi(); ?></div>
        </div>
    </div>
    <div class="switcher">
    	<div class="switch">
        <!-- 幻灯片开始 -->
        <DIV id=header>
  <DIV id=content_p2> 
    <SCRIPT src="<?php echo TEMPLATE_URL; ?>switch/keyvisual.js" type=text/javascript></SCRIPT> 
    <SCRIPT type=text/javascript>
		var list_keyvisualimg = new Array();
		var list_gnbtxt = new Array();
		list_keyvisualimg[0] = '<a href="javascript:void(0)" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>switch/001.jpg" alt="骏森投资，改变您投资的思维。" /></a >';																	
		list_gnbtxt[0] = 'gnb_black';						
		list_keyvisualimg[1] = '<a href="javascript:void(0)" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>switch/002.jpg" alt="骏森投资，竭我所能，为您所愿。" /></a >';																		
	</SCRIPT>
    <DIV class=mainkeyvisual>
      <DIV class=keyvisualimage id=keyvisualimage></DIV>
      <DIV class=keyvisualimage id=keyvisualimage2></DIV>
      <DIV class=btn_left id=btn_left><A 
onmouseover="this.style.backgroundImage='url(<?php echo TEMPLATE_URL; ?>switch/keyvisual_array_left_ov.png)';" 
onmouseout="this.style.backgroundImage='url(<?php echo TEMPLATE_URL; ?>switch/keyvisual_array_left_off.png)';" 
href="javascript:leftView();"></A></DIV>
      <DIV class=btn_right id=btn_right><A 
onmouseover="this.style.backgroundImage='url(<?php echo TEMPLATE_URL; ?>switch/keyvisual_array_right_ov.png)';" 
onmouseout="this.style.backgroundImage='url(<?php echo TEMPLATE_URL; ?>switch/keyvisual_array_right_off.png)';" 
href="javascript:rightView();"></A></DIV>
      <DIV class=pagelist id=keyvisual_page></DIV>
    </DIV>
    <SCRIPT type=text/javascript>
		var keyControl = new keyVisualView (list_keyvisualimg,list_gnbtxt,"header","keyvisualimage","keyvisualimage2","keyvisual_page",0);
		if(list_keyvisualimg.length > 1){
			keyvisualAutoPlay();
		}
		function leftView(){
			keyControl.leftView();
		};
		function rightView(){
			keyControl.rightView();
		};
		function selectView(num){
			keyControl.selectView(num);
		};	
	</SCRIPT> 
  </DIV>
</DIV>
<!-- 幻灯片结束 -->
        </div>
    </div>
</div>
