<?php 
/*
* 页面显示判断
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
if($pageurl == Url::logPage())
{
	include View::getView('index');

} else {
	include View::getView('list');
	include View::getView('footer');
}
?>