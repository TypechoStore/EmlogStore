<?php 
/*
* 页面显示判断
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div class="main">
	<div class="leftbar">
    <?php include View::getView('side'); ?>
    </div>
    <div class="main-right">
    	<div class="main-right-top">当前位置：<a href="<?php echo BLOG_URL; ?>">网站首页</a> > <?php foreach($logs as $value){
			 blog_sort($value['logid']);
			 break;
		}?>
        </div>
        <div class="main-right-list">
        	<?php doAction('index_loglist_top'); ?>
			<?php foreach($logs as $value): ?>
            <?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo subString($value['log_title'],0,30); ?></a><span><?php echo gmdate('Y-m-d', $value['date']); ?></span><br />
            <?php endforeach; ?>
        </div>
        <div class="pagenavi">
			<?php echo $page_url;?>
		</div>
    </div>
</div>