<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<script src="<?php echo TEMPLATE_URL; ?>comm_ajax.js" type="text/javascript"></script>
<div id="content">
  <div id="banner">
	    <h1><?php echo $log_title; ?></h1>
  </div>
<div id="contentleft">
	<?php echo $log_content; ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
</div>
<!--end content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>