<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<script src="<?php echo TEMPLATE_URL; ?>comm_ajax.js" type="text/javascript"></script>
<div id="content">
  <div id="banner">
	    <h1><?php topflg($top); ?><?php echo $log_title; ?></h1>
  </div>
<div id="contentleft">
<div id="diary">
<h2 class="posttitle"><a href="<?php echo BLOG_URL; ?>">首页</a> » <?php blog_sort($logid); ?> » <?php topflg($top); ?><?php echo $log_title; ?></h2>
	<p class="date">作者：<?php blog_author($author); ?> 时间：<?php echo gmdate('Y-n-j G:i l', $date); ?> 
	<?php blog_sort($logid); ?> <?php editflg($logid,$author); ?>
	</p>
	<div id="em_content"><?php echo $log_content; ?>
	<p class="tags"><?php blog_tag($logid); ?></p></div>
	<?php doAction('log_related', $logData); ?>
    <div class="clear"></div>
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	</div>
<div id="diary_comm">	
<?php blog_comments($comments); ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
<div class="clear"></div>
</div>
<!--end content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>