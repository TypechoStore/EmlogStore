<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>
</div>
<div class="clear"></div>
<div id="footer">
<div id="userajax">
<div id="copyright">
<div class="center-left">
	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
	<a href="<?php echo BLOG_URL; ?>admin/write_log.php">【写日志】</a>
	<a href="<?php echo BLOG_URL; ?>admin/" target="_blank">【管理中心】</a>
	<a href="<?php echo BLOG_URL; ?>admin/?action=logout">【退出】</a>
	<?php else: ?>
	欢迎你！来自IP: <?php echo $ip=getIp(); ?> 的朋友<a href="<?php echo BLOG_URL; ?>admin/">【登录】</a>
	<?php endif; ?></div>
<div class="center-right">
Powered by <a href="http://www.emlog.net" target="_blank" title="emlog <?php echo Option::EMLOG_VERSION;?>">Emlog</a>. Design By <a href="http://www.happyevery.com/" target="_blank">DLEE</a>=<a href="http://www.miibeian.gov.cn/" target="_blank"><?php echo $icp; ?></a><?php echo $footer_info; ?>
<?php doAction('index_footer'); ?>
</div>
</div>
</div>
</body>
</html>