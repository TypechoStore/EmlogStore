<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!-- Footer -->
<div class="g-ft">
	<p class="m-cprt">&copy;&nbsp;<a href="<?php echo $blogurl; ?>"><?php echo $blogname; ?></a>&nbsp;|&nbsp;Powered by EMLOG&nbsp;|&nbsp;Theme by <a href="http://nimaboke.com">NIMA</a></p> 
</div>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/1.js" ></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/2.js" ></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/3.js" ></script>
<!--
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/JA_AjaxCommentForEmlog.js?list=.bcmtlst&msg=评论提交中... 请稍后"></script>
-->
</body>
</html>