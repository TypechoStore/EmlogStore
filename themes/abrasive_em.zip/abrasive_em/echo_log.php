<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div class="post" id="post-1">
		<div class="title">
			<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
			<p>Posted by <?php blog_author($author); ?> on <?php echo gmdate('Y-n-j', $date); ?> and is filed under <?php blog_sort($logid); ?>.<?php editflg($logid,$author); ?></p>
		</div>
		<div class="entry">
            <?php echo $log_content; ?>
		</div>
</div>

	<div class="navigation">
		<div class="alignleft"></div>
		<?php neighbor_log($neighborLog); ?>
		<div class="alignright"></div>
	</div>
	<div style="clear: both;">&nbsp;</div>
	<?php doAction('log_related', $logData); ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>

</div><!--end #content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>