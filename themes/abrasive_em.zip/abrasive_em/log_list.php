<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
		<div class="post" id="post-1">
			<div class="title">
				<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
				<p>Posted by <?php blog_author($value['author']); ?> on <?php echo gmdate('Y-n-j', $value['date']); ?> and is filed under <?php blog_sort($value['logid']); ?>.<?php editflg($value['logid'],$value['author']); ?></p>
			</div>
			<div class="entry">
				<?php echo $value['log_description']; ?>
			</div>
		</div>
<?php endforeach; ?>

	<div class="navigation">
		<div class="alignleft"></div>
			<?php echo $page_url;?>
		<div class="alignright"></div>
	</div>

</div>
<!-- end #content-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>