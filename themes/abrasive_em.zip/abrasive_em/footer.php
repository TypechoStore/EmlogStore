<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
			<div style="clear: both;">&nbsp;</div>
		</div>
		</div>
	</div>
	<!-- end #page -->
	<!-- end #wrapper2 -->
	<div id="footer">
		<p>Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a>. Theme by <a href="http://www.loek.us/" title="移植自wordpress">loekman</a>
<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
<?php doAction('index_footer'); ?></p>
	</div>
</div>
<!-- end #wrapper -->
<hr />
</body>
</html>