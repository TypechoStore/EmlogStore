<?php
/*
Template Name:BYMT for Emlog
Template Url:http://www.yuxiaoxi.com/2013-08-07-emlog-template-bymt.html
Description:此主题原是wordpress的，现在我移植到emlog上来。
Version:1.0
Author:麦田一根葱
Author Url:http://www.yuxiaoxi.com
Sidebar Amount:1
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="www.yuxiaoxi.com" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link type="text/css" href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" />
<link type="text/css" href="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.css" rel="stylesheet" />
<script type="text/javascript" src="http://libs.baidu.com/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo BLOG_URL; ?>admin/editor/plugins/code/prettify.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/BYMT.js"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="wrapper">
<div id="wrapper-inner">
  <div id="header" class="container">
  	<div id="header_inner">
    <span id="logo"><a title="<?php echo $blogname; ?>" href="<?php echo BLOG_URL; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/logo.png" width="280px" height="60px" alt="<?php echo $blogname; ?>" /></a> 
	</span>
    <span id="topblock"><?php if(empty($bloginfo)){ echo "天气真好啊~";}else{ echo $bloginfo; }?></span>
	</div>
	<div class="line"></div>
	<div id="menu">
	<?php blog_navi();?>
	<form action="<?php echo BLOG_URL; ?>index.php" method="get">
		<div id="search" class="input">
			<input type="text" name="keyword" class="field" value="我是搜索酱..." onFocus="if (this.value == '我是搜索酱...') {this.value = '';}" onBlur="if (this.value == '') {this.value = '我是搜索酱...';}" />
			<input type="submit" value="" />
		</div>
	</form>
	</div>
	</div>
  </div>
  <div id="topbar" class="container">
   <span id="bulletin">
  	 <?php global $CACHE;  $newtws = $CACHE->readCache('newtw'); echo subString(strip_tags($newtws[0]['content']),0,55); ?>
   </span>
   <span id="rss">
   <ul>
		<li><a href="#你的facebook地址" target="_blank" class="icon5" title="My Facebook"></a></li>
		<li><a href="#你的twitter地址" target="_blank" class="icon4" title="Follow me"></a></li>
		<li><a href="#你的腾讯微博地址" target="_blank" class="icon3" title="我的腾讯微博"></a></li>
		<li><a href="#你的新浪微博地址" target="_blank" class="icon2" title="我的新浪微博"></a></li>
		<li><a href="<?php echo BLOG_URL; ?>rss.php" target="_blank" class="icon1" title="订阅RSS"></a></li>
		<li class="weixin"><a href="#" title="关注我的微信"><img src="<?php echo TEMPLATE_URL; ?>images/weixin-28.png" alt="微信" /><b><span></span><i><img src="<?php echo TEMPLATE_URL; ?>images/weixin.jpg" alt="微信" /></i></b></a></li>
	</ul>
   </span>
  </div>