<?php 
/*
 * Template Name:BYMT for Emlog
 * Version:1.0
 * Author:麦田一根葱
 * Author Url:http://www.yuxiaoxi.com
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content_wrap">
	<div id="content">
	<div class="excerpt">
		<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
		<div class="meta_info">
			<span class="pauthor"><?php blog_author($author); ?></span>
			<span class="ptime"><?php echo gmdate('Y-n-j G:i', $date); ?></span>
			<span class="pcata"><?php blog_sort($logid); ?></span>
			<span class="pcomm"><?php if($comnum=="0"){ echo '<a href="#respond">抢沙发</a>'; }else{ echo '<a href="#comments">'.$comnum.'条评论</a>'; } ?></span>
			<span class="pview"><?php echo $views."人打酱油"; ?></span>
			<span><?php editflg($logid,$author); ?></span>
		</div>
		<div class="clear"></div>
		<div class="context">
			<?php echo $log_content; ?>
		</div>
		<div class="cut_line"><span>正文部分到此结束</span></div>
		<div class="post_copyright">
			<p><strong>版权声明：</strong>除非注明，本文由( <?php blog_author($author); ?> )原创，转载请保留文章出处</p>
			<p><strong>本文链接：</strong><a rel="external" href="<?php echo $log_url; ?>" title="<?php echo $log_title; ?>"><?php echo $log_title; ?></a></p>
			<p><strong>继续浏览：</strong><?php blog_tag($logid); ?></p>
			<?php BYMT_txt_share(); ?>
		</div>
		<?php doAction('log_related', $logData); ?>
		<?php neighbor_log($neighborLog); ?>
		<div class="comments">
			<?php blog_comments($comments); ?>
			<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
		</div>
	</div>
	</div>
<?php include View::getView('side'); ?>
</div>
<?php include View::getView('footer'); ?>