<?php 
/*
 * Template Name:BYMT for Emlog
 * Version:1.0
 * Author:麦田一根葱
 * Author Url:http://www.yuxiaoxi.com
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content_wrap">
	<div id="index_content">
<?php doAction('index_loglist_top'); ?>
<?php if (!empty($logs)): ?>
	<ul>
<?php foreach($logs as $value): ?>
	<li>
	<div class="excerpt">
	<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
	<div class="info">
		<span class="pauthor"><?php blog_author($value['author']); ?></span>
		<span class="ptime"><?php echo gmdate('Y-n-j G:i', $value['date']); ?></span>
		<span class="pcata"><?php blog_sort($value['logid']); ?></span>
		<span class="pcomm"><?php if($value['comnum']=="0"){ echo '<a href="'.$value['log_url'].'#respond">抢沙发</a>'; }else{ echo  '<a href="'.$value['log_url'].'#comments">'.$value['comnum'].'条评论</a>'; } ?></span>
		<span class="pview"><?php echo $value['views']."人打酱油"; ?></span>
		<span><?php editflg($value['logid'],$value['author']); ?></span>
	</div>
	<div class="thumbnail_box">
		<div class="thumbnail">
		<?php
		preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
		$imgsrc = !empty($img[1]) ? $img[1][0] : TEMPLATE_URL.'images/random/BYMT'.rand(1,20).'.jpg';
		?>
		<a href="<?php echo $value['log_url']; ?>"><img src="<?php echo $imgsrc; ?>" width="140px" height="100px" alt="<?php echo $value['log_title']; ?>"/></a>
		</div>
	</div>
	<div class="entry">
	<?php echo subString(strip_tags($value['log_description']),0,200); ?>
	</div>
	<div class="clear"></div>
	<div class="tagandmore">
	<?php blog_tag($value['logid']); ?>
	<span class="readmore"><a href="<?php echo $value['log_url']; ?>" rel="nofollow">阅读全文</a></span>
	</div>
	</div>
	</li>
<?php endforeach; ?>
	<ul>
<?php else: ?>
	<div class="excerpt">
	<h2>抱歉，没有符合您查询条件的结果。</h2>
	</div>
<?php endif;?>
<div class="navigation">
	<div class="pagination">
	<?php echo $page_url;?>
	</div>
</div>
	</div>
<?php include View::getView('side'); ?>
</div>
<?php include View::getView('footer'); ?>