<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="sidebar">



	<div id="hot-posts" class="cbx">
		<h3 id="menu1" onclick="setTab(1,3)">
			热门点击
		</h3>
		<div class="ctx" id="con_1">
			<ul class="hide">
				<?php sideBlogList("view" , 10)?>
			</ul>
		</div>
		<h3 id="menu2" onclick="setTab(2,3)">
			最近更新
		</h3>
		<div class="ctx" id="con_2">
			<ul class="hide">
				<?php sideBlogList("new" , 10)?>
			</ul>
		</div>
		<h3 id="menu3" onclick="setTab(3,3)">
			随机文章
		</h3>
		<div class="ctx" id="con_3">
			<ul class="hide">
				<?php sideBlogList("rand" , 10)?>
			</ul>
		</div>
	</div>
	
	
	
	<?php 
	$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
	doAction('diff_side');
	foreach ($widgets as $val)
	{
		$widget_title = @unserialize($options_cache['widget_title']);
		$custom_widget = @unserialize($options_cache['custom_widget']);
		if(strpos($val, 'custom_wg_') === 0)
		{
			$callback = 'widget_custom_text';
			if(function_exists($callback))
			{
				call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
			}
		}else{
			$callback = 'widget_'.$val;
			if(function_exists($callback))
			{
				preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
				$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
				call_user_func($callback, htmlspecialchars($wgTitle));
			}
		}
	}
	?>
</div><!-- 侧边栏结束 -->
<div class="clear"></div>
</div><!--container 结束-->
