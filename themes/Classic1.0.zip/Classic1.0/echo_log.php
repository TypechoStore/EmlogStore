<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content" class="single">
	<div class="sitemap cbx">
		<a href="<?php echo BLOG_URL; ?>" title="返回博客主页">首页</a>
		&nbsp;&raquo;&nbsp;
		<?php blog_sort_4_new($logid); ?>
		<?php echo $log_title; ?>
	<div id="t_share">
		<a href="<?php echo BLOG_URL; ?>rss.php" target="_blank">订阅 RSS
			Feed</a>
	</div>
	</div>
	
	<div class="cbx post">
		<h2>
			<?php echo $log_title; ?>
		</h2>
		<div class="postmeta">
			<ul>
				<li class="meta-date">
					<?php echo gmdate('Y-n-j G:i', $date); ?>
				</li>
				<li class="meta-cat">
					<?php blog_sort($logid); ?>
				</li>
				<li class="meta-views">
					<?php echo $views; ?> 次流览
				</li>
				<li class="meta-comments">
					<a href="#comments"
						title="<?php echo $log_title; ?>上的评论"><?php echo $comnum; ?> 条评论</a>
				</li>
				<li class="meta-tags">
					<?php blog_tag($logid); ?>
				</li>
			</ul>
			<div class="clear"></div>
		</div>
		<div class="post-content">
			<div class="post-content-text">
				<?php echo $log_content; ?>
				
			</div>
			<?php doAction('log_related', $logData); ?>
			<div class="clear"></div>
		</div>
		
		
		
	</div>
	<div id="prext" class="cbx">
		<?php neighbor_log($neighborLog); ?>
	</div>
	<div id="comments">
		<?php blog_comments($comments); ?>
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>
