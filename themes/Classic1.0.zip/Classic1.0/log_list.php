<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
	<?php doAction('index_loglist_top'); ?>
	<?php foreach($logs as $value): ?>
		<div class="cbx post">
			<h2>
				<?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>" rel="bookmark"><?php echo $value['log_title']; ?></a>
			</h2>
			<a href="<?php echo $value['log_url']; ?>" class="readmore readmorea">
			Read more </a>
		<div class="postmeta">
			<ul>
				<li class="meta-date">
					<?php echo gmdate('Y-n-j', $value['date']); ?>
				</li>
				<li class="meta-cat">
					<?php blog_sort($value['logid']); ?> 
				</li>
				<li class="meta-views">
					<?php echo $value['views']; ?> 次浏览
				</li>
				<li class="meta-comments">
					<a href="<?php echo $value['log_url']; ?>#comments"
						title="<?php echo $value['log_title']; ?> 上的评论"><?php echo $value['comnum']; ?> 条评论</a>
				</li>
				<li class="meta-tags">
					<?php blog_tag($value['logid']); ?>
				</li>
			</ul>
			<div class="clear"></div>
		</div>
		
		<div class="post-content">
		
		
		
			<?php echo $value['log_description']; ?>
		</div>
	</div>
	<?php endforeach; ?>
	<div class="pagenavi pnb">
		<?php echo $page_url;?>
	</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>