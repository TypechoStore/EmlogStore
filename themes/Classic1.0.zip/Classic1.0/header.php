<?php
/*
Template Name:经典重现
Description:扁平化,响应式,经典博客样式
Version:1.0
Author:asim
Author Url:http://asim.cn
Sidebar Amount:1
ForEmlog:5.3.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EdishareRI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>css/style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo TEMPLATE_URL; ?>js/jquery-1.6.4.min.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/theme_script.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div id="header">
	<div class="mbox">
	
	<div id="t_share">
		<ul>
          <li><a href="http://feed.feedsky.com/asim" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>img/icon-rss.gif" alt="欢迎订阅本博客!" title="欢迎订阅本博客!" width="21" height="21" /></a></li>
          <li><a href="http://asim.cn/t/" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>img/ioc-weibo.png" alt="新浪微博" title="新浪微博" width="21" height="21" /></a></li>
           <li><a href="http://asim.cn/t/" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>img/icon-tqq.gif" alt="腾讯微博" title="腾讯微博" width="21" height="21" /></a></li>
            <li><a href="http://sighttp.qq.com/authd?IDKEY=f09e5633b1332d0c1af4b4d4cdb2174da5368c5d52d5dfe0" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>img/ioc-qq.png" alt="QQ交谈" title="QQ交谈" width="21" height="21" /></a></li>
          <li><a href="http://asim.cn/" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>img/icon-email.gif" alt="发邮件给我" title="发邮件给我" width="21" height="21" /></a></li>
        </ul>
	</div>
	
		<div id="tide">
			<h1>
				<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a><br><span><?php echo $bloginfo; ?></span>
			</h1>
		</div>

		<div id="h_serch">
			<form name="keyform" method="get" id="searchform" class="search"
				action="<?php echo BLOG_URL; ?>index.php">
				<input type="text" name="keyword" class="keyword"
					onblur="if(this.value =='')this.value='Search Articles';"
					onfocus="this.value='';"
					onclick="if(this.value=='Search ')this.value=''"
					value="Search Articles" />
				<input type="submit" name="submit" value="SO" class="submit" />
			</form>
		</div><div id="navi1">
		<div id="navi">
			<?php blog_navi();?>		
		</div>
		
	</div>	
		
	</div>
</div>
<div id="container">
