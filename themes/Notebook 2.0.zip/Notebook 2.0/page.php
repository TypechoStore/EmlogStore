<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content-wrapper">
<div id="content-inner-wrapper">
<section id="main-content">

<article class="post">
					<header class="postHeader">
					  <div class="date">
				
					  </div>
					 <h2><?php echo $log_title; ?></h2>	<?php editflg($logid,$author); ?> &nbsp;&nbsp;
					</header>
					<section class="postText">
					<p><?php echo $log_content; ?></p>
		
					</section>
				<div class="sidebadge"></div>
				</article>
<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>


</section>

<?php
 include View::getView('side');
 include View::getView('footer');
?>