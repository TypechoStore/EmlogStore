<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content-wrapper">
<div id="content-inner-wrapper">
<section id="main-content">

<article class="post">
					<header class="postHeader">
					  <div class="date"><?php echo gmdate('n', $date); ?> <?php echo gmdate('d', $date); ?>, <?php echo gmdate('Y', $date); ?> - <span>
					  <img src="<?php echo TEMPLATE_URL; ?>images/ico_file.png" alt=""/>
					 <?php blog_sort($logid); ?> <?php editflg($logid,$author); ?> &nbsp;&nbsp;<img src="<?php echo TEMPLATE_URL; ?>images/ico_comment.png" alt=""/>
					   <a title="<?php echo $value['log_title']; ?> 上的评论" href="<?php echo $value['log_url']; ?>#respond"><?php echo $value['comnum']; ?>Comments</a><?php blog_tag($logid); ?></span> </div>
					 <h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
					</header>
					<section class="postText">
					<?php echo $log_content; ?>
		<?php doAction('log_related', $logData); ?>
					</section>
				<div class="sidebadge"></div>
				</article>
<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>


</section>

<?php
 include View::getView('side');
 include View::getView('footer');
?>