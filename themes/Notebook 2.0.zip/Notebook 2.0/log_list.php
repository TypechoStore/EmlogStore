<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content-wrapper">
<div id="content-inner-wrapper">
<section id="main-content">
<article class="post">

<?php foreach($logs as $value): ?><img src="<?php echo TEMPLATE_URL; ?>images/bk_post_header.png" alt=""/>
					<header class="postHeader">
					  <div class="date"><?php echo gmdate('M j Y', $value['date']); ?>  - <span>
					  <img src="<?php echo TEMPLATE_URL; ?>images/ico_file.png" alt=""/>
	 <?php blog_sort($value['logid']); ?>  &nbsp;&nbsp;<img src="<?php echo TEMPLATE_URL; ?>images/ico_comment.png" alt=""/> <a title="<?php echo $value['log_title']; ?> 上的评论" href="<?php echo $value['log_url']; ?>#respond"><?php echo $value['comnum']; ?>Comments</a></span> </div>
					  <h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
					</header>
					<section class="postText">
						<p><?php echo $value['log_description']; ?></p>
		
					</section>
				<div class="sidebadge"></div>
						<?php endforeach; ?>
				</article>
				 <div class="emm-paginate ">
				<span class="emm-title"></span>
					<?php echo $page_url;?>
				</div>
			</section>	
		
<?php
 include View::getView('side');
 include View::getView('footer');
?>