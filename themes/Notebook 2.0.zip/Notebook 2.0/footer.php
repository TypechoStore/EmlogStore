<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div>
</div>
<footer id="page-footer">
	<div id="site5bottom">Theme by <a href="http://skyguo.com" title="浮生">鬼鬼</a> <br>Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a></div>
	<div id="html5">
		
		<img title="HTML5 Inside" alt="HTML5 Inside" src="<?php echo TEMPLATE_URL; ?>images/html5_logo.png">
	</a><br>
  </div>
  
		</footer>
</div><!--end #wrap-->
</body>
</html>