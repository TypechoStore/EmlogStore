<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="main">
      <?php 
    foreach($tws as $val):
    $tid = (int)$val['id'];
	?>
        <div class="block" id="w">
          <span class="wtime"><?php echo $val['date']; ?></span><?php echo $val['t']; ?>
        </div>
      <?php endforeach;?>
</div>
<?php
 include View::getView('footer');
?>
</div> <!-- wrap end -->
</body>
</html>