<?php 
/**
 * 日志列表
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="main">
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
    	<div class="block">
    		<div class="logtitle"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a><span><?php echo gmdate('Y.n.j', $value['date']); ?></span></div>
            <div class="desc"><?php echo $value['log_description']; ?></div>
        </div>
<?php endforeach; endif; ?>
</div> <!-- main end -->
<?php
 include View::getView('footer');
?>
</div> <!-- wrap end -->
</body>
</html>