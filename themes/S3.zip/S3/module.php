<?php 
/**
 * 侧边栏组件、页面模块
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach($navi_cache as $value):
        if ($value['pid'] != 0) {
            continue;
        }
		if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):
			?>
			<a href="<?php echo BLOG_URL; ?>admin/"><div class="common">管理站点</div></a>
			<a href="<?php echo BLOG_URL; ?>admin/?action=logout"><div class="common">退出</div></a>
			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
        $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'current' : 'common';
		?>
        <a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><div class="<?php echo $current_tab;?>"><?php echo $value['naviname']; ?></div></a>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog):?>
	上一篇：<a href="<?php echo Url::log($prevLog['gid']) ?>"><?php echo $prevLog['title'];?></a>
	<?php else: ?>
    上一篇：没有了
	<?php endif;?>
	<?php if($nextLog):?>
	</br>下一篇：<a href="<?php echo Url::log($nextLog['gid']) ?>"><?php echo $nextLog['title'];?></a>
	<?php else: ?>
    </br>下一篇：没有了
	<?php endif;?>
<?php }?>
<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>
<?php
//相恋日
function loveDay($loveDate){
	$loveTime = strtotime($loveDate);
	$loveDays = (time()-$loveTime)/60/60/24;
	$lDay = floor($loveDays)+1;
	return $lDay;
}
?>