<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>jquery.masonry.min.js" type="text/javascript"></script>
<script>
$('#main').masonry({
  itemSelector: '.block',
  isAnimated: true,
});
$(document).ready(function(){
$(window).scroll(function(){
if($(this).scrollTop()!=0){
$('.top').fadeIn(500);}
else{
$('.top').fadeOut(500);} });
$('.top').click(function(){
$('body,html').animate({scrollTop:0},700);});
});
</script>
<div class="top">返回顶部</div>