<?php 
/**
 * 	文章输出
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="content">
	<div class="content-title">
		<?php echo $log_title; ?><span class="date"><?php echo gmdate('Y.n.j', $date); ?></span>
    </div>
	<div class="logcontent"><?php echo $log_content; ?></div>
</div>
<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
<?php
 include View::getView('footer');
?>
</div>
</body>
</html>