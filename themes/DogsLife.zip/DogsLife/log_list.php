<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="body">

<div id="content" class="clearfix">
		<?php doAction('index_loglist_top'); ?>	
<article id="post-10" class="post-10 post type-post status-publish format-standard hentry category-uncategorized post clearfix">
<?php foreach($logs as $value): ?>
	
	
	<h1 class="post-title"><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h1>

	<p class="post-meta"> 
		<span class="post-author"><?php blog_author($value['author']); ?></span>
		<span class="post-category"><?php blog_sort($value['logid']); ?></span>
		<span class="post-comment"><a href="<?php echo $value['log_url']; ?>#comments" title="《<?php echo $value['log_title']; ?>》上的评论"><?php echo $value['comnum']; ?>条评论</a></span>
		<span class="post-tag"><?php blog_tag($value['logid']); ?></span>
		
			</p>
		<div class="note-list"><?php echo $value['log_description']; ?></div><time datetime="2012-05-29" class="post-date" pubdate=""><?php echo gmdate('y年-n月-j日', $value['date']); ?></time><hr />
	
	<div style="clear:both;"></div>
<?php endforeach; ?>	
</article>
<!-- /.post -->	


<div id="pagenavi">
	<?php echo $page_url;?>
</div>
</div><!-- end #content-->

<?php
 include View::getView('side');
 include View::getView('footer');
?>