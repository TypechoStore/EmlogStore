<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

</div><!--end #content-->
<div style="clear:both;"></div>
<div id="footer" role="contentinfo">
		<div id="colophon">

			<div id="site-info">
				<div align="center"><a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>" rel="home"><?php echo $blogname; ?></a>
			      </div>
			</div><!-- #site-info -->

			<div id="site-generator">
				<div align="center">Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog <?php echo Option::EMLOG_VERSION;?></a> 
				Theme by <a href="http://zhangziheng.com">jaeheng</a> <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>			   <a id="gotop" href="#" onclick="MGJS.goTop();return false;">回到顶部</a> </div>
			</div><!-- #site-generator -->
		</div>

<?php doAction('index_footer'); ?>
</div><!--end #footerbar-->
</div><!--end #body-->
</div><!--end #wrap-->
</body>
</html>
