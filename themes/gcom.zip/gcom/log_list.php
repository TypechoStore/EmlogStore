<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
if($pageurl == Url::logPage()){
	include View::getView('index');
	exit;
}
?>
		<div id="pbody">
			<div id="ileft">
<style type="text/css">
#ilc #c<?php echo $value['sid']; ?> a.fc{color:#F60;font-weight:bold;font-size:14px}
</style>
<?php
 include View::getView('side');
?>
            </div>
            <div id="pright">
            	<div id="prtop">
您现在的位置：<a href="<?php echo BLOG_URL; ?>">首页</a>&nbsp;&gt;&nbsp;
<?php if ($params[1]=='sort'){ ?>
		<?php echo '<a href="'.Url::sort($sortid).'">'.$sortName.'</a>';?>
<?php }elseif ($params[1]=='tag'){ ?>
			包含标签 <b><?php echo urldecode($params[2]);?></b> 的所有文章
<?php }elseif($params[1]=='author'){ ?>
			作者 <b><?php echo blog_author($author);?></b> 的所有文章
<?php }elseif($params[1]=='keyword'){ ?>
            搜索 <b><?php echo urldecode($params[2]);?></b> 的结果
<?php }else{?><?php }?>
                </div>
<?php doAction('index_loglist_top'); ?>
				<div id="pagenavi"><?php echo $page_url;?></div>
    <dl class="tlist">
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
    <dt><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></dt>
	<dd><?php echo gmdate('Y-n-j', $value['date']); ?></dd>	
<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
	</dl>
				<div id="pagenavi"><?php echo $page_url;?></div>
			</div>
		</div>
<?php
 include View::getView('footer');
?>