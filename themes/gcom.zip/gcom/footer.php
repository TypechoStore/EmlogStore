<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
		<div id="footerbar">
        	<div class="btl">
<a href="<?php echo $abouturl;?>">关于我们</a><span>|</span><a href="<?php echo $contacturl;?>">联系方式</a><span>|</span><a href="<?php echo $guestbookurl; ?>">在线留言</a><span>|</span><a href="<?php echo BLOG_URL; ?>admin/">网站管理</a><span>|</span><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a><span>|</span><a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a>
            </div>
<!--注意：当前模板免费版需要您保留模板作者信息，强行修改可能导致出错。支持收费版请联系Q77940140或见模板包内说明文件-->
            <div class="btr">
All Rights Reserved. Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>">emlog</a> <?php echo gcomer(); ?><?php echo $footer_info; ?><?php doAction('index_footer'); ?>
    		</div>
		</div><!--end #footerbar-->
	</div><!--end #wrap-->
    <?php if ($pageurl == Url::logPage()): ?>
    <div id="ilink">
        <?php widget_link($title); ?>
    </div>
    <?php endif; ?>
</div><!--end #bigbox-->
<div id="backtop"><a href="javascript:scroll(0,0)">返回顶部</a></div>
<style type="text/css">
<?php
$lhidesid;
foreach ($lhidesid as $value)
{
  echo "#c".$value."{display:none}\n";
}
?>
</style>
</body>
</html>