<?php
/*
Template Name:G调企业模板
Description:G调企业风通用商务EMLOG模板
Version:1.5
Author:尔今 erx@qq.com
Author Url:http://www.ewceo.com
Sidebar Amount:0
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
require_once View::getView('option');
if(function_exists('emLoadJQuery')) {
    emLoadJQuery();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<script src="<?php echo TEMPLATE_URL; ?>js/g.js" type="text/javascript"></script>
<?php if ($qqonline == 1) :?>
<link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>default_blue.css"/>
<script src="<?php echo TEMPLATE_URL; ?>js/jquery.Sonline.js" type="text/javascript"></script>
<script type="text/javascript">
$(function(){
	$().Sonline({
		Position:"right",
		Top:<?php echo $qqoltop;?>,
		Width:<?php echo $qqolwidth;?>,
		DefaultsOpen:<?php echo $qqoloc;?>,
		Style:<?php echo $qqolstyle;?>,
		Tel:"<?php echo $qqoltel;?>",
		Qqlist:"<?php echo $qqolqq;?>" 
	});
})	
</script>
<?php endif;?>
</head>
<body>
<div id="bigbox">
	<div id="wrap">
		<div id="header">
        	<div id="mlogo">
        <?php if ($ilogo == 1) :?>
			<a href="<?php echo BLOG_URL; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/logo.png" alt="<?php echo $blogname; ?>" /></a>
		<?php else: ?>
        	<a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>
        <?php endif;?>
            </div>
            <div id="topto">
<?php if(ROLE == 'admin' || ROLE == 'writer'): ?><a href="<?php echo BLOG_URL; ?>admin/">网站管理</a>&nbsp;&nbsp;<a href="<?php echo BLOG_URL; ?>admin/?action=logout">[退出]</a><?php else: ?><a href="<?php echo BLOG_URL; ?>admin/">登录</a><?php endif; ?>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="<?php echo $guestbookurl; ?>">留言建议</a>
            </div>
            <div id="nav"><?php blog_navi();?></div>
		</div>
		<div id="ifp">
        	<div class="ifpp">
        		<ul>
            		<li><a href="<?php echo $ifpurlA; ?>"><img src="<?php echo TEMPLATE_URL; ?>pic/i2.jpg" /></a></li>
            		<li><a href="<?php echo $ifpurlB; ?>"><img src="<?php echo TEMPLATE_URL; ?>pic/i3.jpg" /></a></li>
            		<li><a href="<?php echo $ifpurlC; ?>"><img src="<?php echo TEMPLATE_URL; ?>pic/i1.jpg" /></a></li>
            	</ul>
            </div>
        	<div class="thnav">
				<ul>
                	<li>1</li><li>2</li><li>3</li>
				</ul>
			</div>
        </div>
