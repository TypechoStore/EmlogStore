<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
		<div id="pbody">
			<div id="ileft">
<style type="text/css">
#ilc #c<?php echo $value['sid']; ?> a.fc{color:#F60;font-weight:bold;font-size:14px}
</style>
<?php
 include View::getView('side');
?>
            </div>
            <div id="pright">
            	<div id="prtop">
您现在的位置：<a href="<?php echo BLOG_URL; ?>">首页</a>&nbsp;&gt;&nbsp;未开放页面
                </div>
                <div style="line-height:30px;padding:50px">
                	当前模板尚未开通该功能<br />如有需要请与模板作者联系 <a href="http://www.ewceo.com/" target="_blank">www.ewceo.com</a><br />
                    <a href="javascript:history.back(-1)">[返回]</a>
                </div>
			</div>
		</div>
<?php
 include View::getView('footer');
?>