<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
		<div id="pbody">
			<div id="ileft">
<?php
 include View::getView('side');
?>
            </div>
            <div id="pright">
            	<div id="prtop">
您现在的位置：<a href="<?php echo BLOG_URL; ?>">首页</a>&nbsp;&gt;&nbsp;<a href="<?php echo Url::log($logid); ?>"><?php echo $log_title; ?></a>
                </div>
				<h1 class="page"><?php echo $log_title; ?></h1>
                <div id="contentbox">
	<?php echo $log_content; ?>
    			</div>
                <div id="pagex">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
    			</div>
			</div>
		</div>
<?php
 include View::getView('footer');
?>