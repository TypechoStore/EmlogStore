<?php 
/**
 * 侧边栏
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
            	<div class="ilti"><img src="<?php echo TEMPLATE_URL; ?>images/title_cpss.jpg" /></div>
                <div id="iseh">
<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
<input name="keyword" type="text" value="全能搜索..." onFocus="if(this.value=='全能搜索...'){this.value=''};" onblur="if(this.value==''){this.value='全能搜索...'};" value="全能搜索..." class="hdin" x-webkit-speech x-webkit-grammar="builtin:translate" /><input type="submit" value="搜 索" class="hdbtn" />
</form>
                </div>
                <div class="ilti"><img src="<?php echo TEMPLATE_URL; ?>images/title_cpxl.jpg" /></div>
                <div id="ilc">
                	<ul>
                    	<?php widget_sort($title); ?>
                    </ul>
                </div>