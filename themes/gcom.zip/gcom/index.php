<?php 
/**
 * G调企业风模板首页
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
		<div id="ibody">
			<div id="ileft">
<?php
 include View::getView('side');
?>
            </div>
            <div id="imid">
            	<div class="imti"><img src="<?php echo TEMPLATE_URL; ?>images/title_xptj.jpg" /><a href="<?php echo Url::sort($indexpid); ?>" title="更多" class="more"><img src="<?php echo TEMPLATE_URL; ?>images/more.jpg" /></a></div>
<script type="text/javascript">
$(document).ready(function(){
	$("#iap").imgscroll({
		speed: <?php echo $indexpspeed;?>,
		dir: "left" 
	});
});
</script>
                <div id="iap">
                	<ul>
                    	<?php thumbs_by_sort($indexpid,$indexpnum); ?>
                    </ul>
                </div>
                <div class="imti"><img src="<?php echo TEMPLATE_URL; ?>images/title_qyjj.jpg" /><a href="<?php echo $abouturl;?>" title="更多" class="more"><img src="<?php echo TEMPLATE_URL; ?>images/more.jpg" /></a></div>
                <div id="iab">
<img src="<?php echo TEMPLATE_URL; ?>images/iab.jpg" /><?php echo $blogname; ?><?php echo $indexabus; ?>
                </div>
            </div>
            <div id="iright">
            	<div class="irti"><img src="<?php echo TEMPLATE_URL; ?>images/title_xwdt.jpg" /></div>
                <ul class="inlist">
                	<?php get_list($indexnewsid); ?>
				</ul>
				<div class="irti"><img src="<?php echo TEMPLATE_URL; ?>images/title_lxwm.jpg" /></div>
				<ul id="ict">
                	<li><a href="<?php echo $contacturl;?>" title="更多联系方式"><img src="<?php echo TEMPLATE_URL; ?>images/ict.gif" /></a></li>
                    <li><?php echo $iaddr;?></li>
                    <li><?php echo $itel;?></li>
                    <li><?php echo $ifax;?></li>
                    <li><?php echo $iemail;?></li>
                </ul>
            </div>
		</div>
<?php
 include View::getView('footer');
?>