<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="focus">
<img class="focus_img" src="<?php echo TEMPLATE_URL; ?>images/jjdd.jpg" width="100%" />
</div>
<div id="main" class="global_width">
<div class="content left">
<?php doAction('index_loglist_top'); ?>
<?php 
if (!empty($logs)):
foreach($logs as $value): 
$img="";
if(preg_match("/<[img|IMG].*?src=[\'|\"](.*?(?:[\.gif|\.jpg]))[\'|\"].*?[\/]?>/i",$value['content'],$kevnImg)):
	$img="<a href=\"".$value['log_url']."\" title='{$value[log_title]}'><img src=\"".$kevnImg[1]."\" width=\"715\" alt='{$value[log_title]}' /></a>";

endif;


?>
<div class="item">
<div class="arc_t">
<h1 class="left"><?php topflg($value['top']); ?><a title='<?php echo $value['log_title']; ?>' href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h1>

<div class="describe_one right">
<span class="author"><?php blog_author($value['author']); ?></span> / <span class="the-time"><?php echo gmdate('Y.m.d', $value['date']); ?></span> / <span class="tags">	<?php blog_sort($value['logid']); ?> 
	<?php editflg($value['logid'],$value['author']); ?></span>
</div>
</div>
<div class="describe_two tt">
<?php echo $img;?>
<p><?php echo extractHtmlData($value['log_description'],"300"); ?></p>
</div>

<div class="arc_tt">
<div class="left d_s">
 <span>浏览（<?php echo $value['views']; ?>）</span><span><a href="<?php echo $value['log_url']; ?>#tb">引用(<?php echo $value['tbcount']; ?>)</a>&nbsp;</span><span><?php blog_tag($value['logid']); ?></span>
</div>
<div class="right look">
<a href="<?php echo $value['log_url']; ?>">查看全文></a>
</div>
</div>
</div>
<?php 
endforeach;
else:
?>
	<h2 style="margin-top: 85px">未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
<div id="pagenavi">
	<?php echo $page_url;?>
</div>

</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>
