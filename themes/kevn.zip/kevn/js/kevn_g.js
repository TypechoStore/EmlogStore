// JavaScript Document
if($.browser.msie && $.browser.version == "6.0"){
	window.location.href="http://windows.microsoft.com/zh-cn/windows/upgrade-your-browser";
}
$(function(){
	$w=$("#footer").width();
	if($w>1014){
		$(".up").css({"left":($w/2)+(970/2)+15+"px"})
	
	}else{
		$(".up").css({"right":15+"px"})
	}

	$(window).scroll(function(){

	if($(window).scrollTop()>10){
		$(".up").css("display","block")
	}else{
		$(".up").css("display","none")
	}
	})

	$(".up").hover(function(){ $(this).css({"background-position":"right top"})  },function(){  $(this).css({"background-position":"left top"})   })

	$(".nvr li").hover(function(){
			$(this).children('a').fadeOut(50);
			$(this).children('.d').fadeIn(250)		
		},function(){
						$(this).children('a').fadeIn(50);
			$(this).children('.d').fadeOut(250)	
	})

	$(".key").click(function(){
		$(this).val("");
		$(".search").css("background","url(content/templates/kevn/images/kevn_search_bgt.png) no-repeat")	
	}).focusout(function(){
		if($(this).val()==""){
			$(this).val("搜索您感兴趣的...");
			$(".search").css("background","url(content/templates/kevn/images/kevn_search_bg.png) no-repeat")	
		}
		
	})
	
	$(".describe_two").hover(function(){ $(this).removeClass("tt")},function(){$(this).addClass("tt")})
	
	$(".focus_img").animate({marginTop:-270},10000)

})

