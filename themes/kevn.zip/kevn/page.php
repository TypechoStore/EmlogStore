<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="main" class="global_width" style="margin-top: 85px">
<div class="content left">

	<div class="arc_t">
	<h1 class="left"><?php echo $log_title; ?></h1>
	</div>
	<div class="tt n_content">
	<?php echo $log_content; ?>
	</div>
<!-- Duoshuo Comment BEGIN -->
	<div class="ds-thread"></div>
<script type="text/javascript">
var duoshuoQuery = {short_name:"kevn"};
	(function() {
		var ds = document.createElement('script');
		ds.type = 'text/javascript';ds.async = true;
		ds.src = 'http://static.duoshuo.com/embed.js';
		ds.charset = 'UTF-8';
		(document.getElementsByTagName('head')[0] 
		|| document.getElementsByTagName('body')[0]).appendChild(ds);
	})();
	</script>
<!-- Duoshuo Comment END -->
</div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>