<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class='cl'></div>
<div id="main" class="global_width" style="margin-top: 85px">
<div class="content left">
	<div class="arc_t">
	<h1 class="left"><?php topflg($top); ?><?php echo $log_title; ?></h1>
	<div class="describe_one right">
	<span class="author"><?php blog_author($author); ?></span> / <span class="the-time"><?php echo gmdate('Y.m.d', $date); ?></span> / <span class="tags">	<?php blog_sort($logid); ?> 
		<?php editflg($logid,$author); ?></span>
	</div>
	</div>
	<div class="tt n_content">
	<?php echo $log_content; ?>
	</div>
	<div class="arc_tt">
	<div class="left d_s">
 	<span><?php blog_tag($logid); ?></span>
	</div>
	<div class="right look">
		<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
	</div>
	</div>
	<?php doAction('log_related', $logData); ?>

	<!-- Duoshuo Comment BEGIN -->
	<div class="ds-thread"></div>
<script type="text/javascript">
var duoshuoQuery = {short_name:"kevn"};
	(function() {
		var ds = document.createElement('script');
		ds.type = 'text/javascript';ds.async = true;
		ds.src = 'http://static.duoshuo.com/embed.js';
		ds.charset = 'UTF-8';
		(document.getElementsByTagName('head')[0] 
		|| document.getElementsByTagName('body')[0]).appendChild(ds);
	})();
	</script>
<!-- Duoshuo Comment END -->
</div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>
