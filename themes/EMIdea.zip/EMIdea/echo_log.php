<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
<div id="content">
<div id="post">        
 <div class="module_top">
 <div class="module_t_content entry">
 <h2 class="title"><?php topflg($top); ?><?php echo $log_title; ?></a></h2>
 <div class="post_info">
   作者：<span><?php blog_author($author); ?></span>
   发布时间：<span><?php echo gmdate('Y-n-j G:i', $date); ?></span>
   <?php blog_sort($logid); ?>
   <span>已有<?php echo $comnum; ?>条评论</a></span>
               	</div>                    
                </div>             
            </div>
            <div class="entry_content">
            <?php echo $log_content; ?>
            </div>
            <div class="module_bottom">
            <div class="module_b_content">
              <?php blog_tag($logid); ?>                
                </div>
            </div>
            <div class="module_tail center">看完了？ 看看评论吧 ^_^</div>
            <div class="clear5">
         </div>       
         <?php doAction('log_related', $logData); ?>
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div>
	 <?php blog_trackback($tb, $tb_url, $allow_tb); ?><br>
        <h4>已有<?php echo $comnum; ?>位潜水的同学浮出水面了 »</h4>
       <div class="entry_comments">
 <div class="module_top">
                <div class="module_t_content"></div>             
            </div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>        
       </div>
<ol class="pages clearfix">

<div style="clear:both;">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>