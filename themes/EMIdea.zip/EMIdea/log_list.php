<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
<div id="content">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<div id="post">        
            <div class="module_top">
            <div class="module_t_content"></div>
            </div>
           <div class="entry_content summary">
<h2 class="title"><a href="<?php echo $value['log_url']; ?>"><?php topflg($value['top']); ?><?php echo $value['log_title']; ?></a></h2>
	  <?php echo $value['log_description']; ?>
          <div class="clear"></div>
            </div>
              <div class="module_bottom">
                <div class="module_b_content">
                <span class="par">作者：<?php blog_author($value['author']); ?></span>
               <span class="par">发布时间：<?php echo gmdate('Y年n月j日', $value['date']); ?></span><?php blog_tag($value['logid']); ?> 
<span>浏览(<?php echo $value['views']; ?>)次</span>
           </div>
         </div>
       <div class="module_tail">
       <span class="par"><?php blog_sort($value['logid']); ?></span>
               	<a href="<?php echo $value['log_url']; ?>#comments" title="已有<?php echo $value['comnum']; ?>条评论">已有<?php echo $value['comnum']; ?>条评论</a>
<span><?php editflg($value['logid'],$value['author']); ?></span>
       </div>
       <div class="clear5"></div>  
 <div class="clear5"></div>       
       </div>
       <?php endforeach; ?>
       <ol class="pages clearfix page-navigator">
        <ol class="page-navigator"><li class="current"><?php echo $page_url;?>
     </ol>
  </div>
</div>

    </div>
   </div>
  </div><!-- end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>