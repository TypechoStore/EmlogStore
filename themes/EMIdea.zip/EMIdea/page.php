<?php 
/*
* 自定义页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="container">
<div id="content">
<div id="post">        
 <div class="module_top">
 <div class="module_t_content entry">
 <h2 class="title"><?php echo $log_title; ?></a></h2>
                     </div>             
            </div>
            <div class="entry_content">
            <?php echo $log_content; ?>
            </div>
            <div class="module_bottom">
            <div class="module_b_content">
            </div>
            </div>
            <div class="module_tail center"></div>
            <div class="clear5">
         </div>       
      	 <br>
        <h4>已有<?php echo $comnum; ?>位潜水的同学浮出水面了 »</h4>
       <div class="entry_comments">
 <div class="module_top">
          <div class="module_t_content"></div>             
            </div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>        
       </div>

<div style="clear:both;">
</div>
</div>
</div>

<?php
 include View::getView('side');
 include View::getView('footer');
?>