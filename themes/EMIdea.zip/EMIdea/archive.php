<?php $this->need('header.php'); ?>

	<div id="content">

		<?php if ($this->have()): ?>
		<?php while($this->next()): ?>  
    	<div id="post">        
            <div class="module_top">
                <div class="module_t_content"></div>
            </div>
            <div class="entry_content summary">
            	<h2 class="title"><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></h2>
				<?php $this->content('阅读剩余部分...'); ?>
                <div class="clear"></div>
            </div>
            <div class="module_bottom">
                <div class="module_b_content">
                    <span class="par"><?php _e('作者：'); ?><?php $this->author(); ?></span>
                    <span class="par"><?php _e('发布时间：'); ?><?php $this->date('Y-m-d H:i'); ?></span>
                    <span class="tags"><?php _e('标签'); ?>: <?php $this->tags(', ', true, 'none'); ?></span>    
                </div>
            </div>
            <div class="module_tail">
            	<span class="par"><?php _e('分类：'); ?><?php $this->category(','); ?></span>
               	<a href="<?php $this->permalink() ?>#comments" title="<?php $this->commentsNum('至今仍未出现不明生物体', '已经出现 1 个不明生物体', '已经出现 %d 个不明生物体'); ?>" ><?php $this->commentsNum('No Comments', '1 Comment', '%d Comments'); ?></a>            	
            </div>
            <div class="clear5"></div>       
        </div>     
        <?php endwhile; ?>
        
        <?php else: ?>
        <div id="post">        
            <div class="module_top">
                <div class="module_t_content thumb"></div>             
            </div>
            <div class="entry_content summary">
            	<h2 class="title"><?php _e('没有找到相关内容，请重新搜索'); ?></h2>
            </div>
            <div class="module_bottom">
                <div class="module_b_content">
                </div>
            </div>
            <div class="module_tail">
            </div>
            <div class="clear5"></div>       
        </div>
   		<?php endif; ?>

        <ol class="pages clearfix page-navigator">
        	<?php $this->pageNav(); ?>
        </ol>
         	
    </div>

	<?php $this->need('sidebar.php'); ?>
	<?php $this->need('footer.php'); ?>