<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<section id="body">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<article>
		<h2 class="post-title"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
	<div class="content">
			<?php echo $value['log_description']; ?><div style="clear:both;"></div>	
	</div>
        <!-- 信息栏 --> 
	<p class="post-meta"><?php echo $value['views']; ?>人気&nbsp;<!--文章观看次数-->&nbsp;&nbsp;<?php echo $value['comnum']; ?>コメント&nbsp;&nbsp;<?php blog_sort($value['logid']); ?>&nbsp;&nbsp;<?php echo gmdate('Y.n.j', $value['date']); ?>			
				</p></p>
</article>
<?php endforeach; ?>
<nav id="pagenavi">
<div class="pagenav clearfix"><?php echo $page_url;?></div>
</nav>
</section>
<?php
 include View::getView('footer');
?>