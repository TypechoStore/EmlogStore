<?php
/*
Template Name:Bbee-x8
Description:扒皮~
Version:1.0
Author:lethe
Author Url:http://imzss.com
Sidebar Amount:0
ForEmlog:4.1.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
		<!--[if IE 6]>
	<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/DD_belatedPNG_0.0.8a.js"></script>
	<script type="text/javascript">
		DD_belatedPNG.fix('#logo, .rssfeed, img');
	</script>
	<![endif]-->
	<!--[if lte IE 9]>
	    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
	<?php doAction('index_head'); ?>
<script type="text/javascript">
jQuery(document).ready(
function($){
$("img").lazyload({
     placeholder : "<?php echo TEMPLATE_URL; ?>images/grey.gif",
     effect      : "fadeIn"
});
});
</script>
</head>
<body>
	<div id="container">
		<header>	
			<div id="logo"><a href="<?php echo BLOG_URL; ?>"><h1><?php echo $blogname; ?></h1></a></div>
			<div id="description1"><a><?php echo $bloginfo; ?></a></div>
			<div id="description2"><a>小站地址：<?php echo BLOG_URL; ?></a></div>
			<div id="description3"><a>小站订阅：<?php echo BLOG_URL; ?>rss.php</a></div>
			<nav id="mainmenu">
			<div class="menu-container"><ul id="menu" class="menu">
	<li class="<?php echo $curpage == CURPAGE_HOME ? 'current' : 'menu-item';?>"><a href="<?php echo BLOG_URL; ?>">Index</a></li>
	<?php if($istwitter == 'y'):?>
	
	<?php endif;?>
	<?php 
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach ($navi_cache as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	$val['is_blank'] = $val['newtab'] == 'y' ? 'target="_blank"' : '';
    $val['url'] = $val['isdefault'] == 'y' ? BLOG_URL . $val['url'] : trim($val['url'], '/');
	?>
	<li class="<?php echo isset($logid) && $key == $logid ? 'current' : 'menu-item';?>"><a href="<?php echo $val['url']; ?>" target="<?php echo $val['is_blank']; ?>"><?php echo $val['naviname']; ?></a></li>
	<?php endforeach;?>
	<?php doAction('navbar', '<li class="menu-item">', '</li>'); ?>
			</ul></div>
			</nav>

			<div id="catalogg">
	<?php widget_sort(''); ?>
</div>

		</header>
		<div id="wrapper">