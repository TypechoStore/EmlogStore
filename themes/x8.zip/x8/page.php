<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<section id="body">
<article>
		<center><h2 class="post-title"><?php echo $log_title; ?></h2></center>	
	<div class="content"><?php if($log_title=="链接"): ?>
<!-- start links-->
<li><dd><a href="http://kisu.me" target="_blank" style="background: #454545;#h;#hh;#hhh;#hh;#h;color: #fff;">Typecho - 私家筆跡</a></dd></li>
<li><dd><a style="background: #454545;#h;#hh;#hhh;#hh;#h;color: #fff;">Links:</a></dd></li>
<?php widget_link(''); ?>
<!-- end links-->
	<?php else: ?>
	<?php if($log_title=="FM"): ?>
<div class="viewbox" id="flash_div_67">
<iframe name="iframe_canvas" src="http://douban.fm/partner/baidu/doubanradio" scrolling="no" frameborder="0" width="450" height="210"></iframe>
</div> <?php else: ?><?php endif; ?>
	<?php echo $log_content; ?><div style="clear:both;"></div>
        <!-- 信息栏 --> 
	<p class="post-meta">
				Post on
				<!-- the date and time -->
				<?php echo gmdate('y.n.j', $date); ?>				
				</p></p>
<?php endif; ?></div>
</article>

	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</section>
<?php
 include View::getView('footer');
?>