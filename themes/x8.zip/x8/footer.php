<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>			
		</div>
		<footer>
			<p class="copyright"><a> Standing on Emlog theme by <a href="http://fourseven.net">kkStx</a></a>
			<p class="copyright"><a> Copyright © <?php echo $blogname; ?> All Rights Reserved   </a>

</div>
			
		</div></p>
	</div>

	<script src="<?php echo TEMPLATE_URL; ?>js/yotheme.js" type="text/javascript"></script>
	<script type="text/javascript">
$('a:has(img)').filter(function(){
  return/\.(jpe?g|png|gif)$/i.test(this.href);
}).phzoom({
capTxtColor:'#efefef',
capBtnColor:'#efefef'
});
</script>			
	<?php doAction('index_footer'); ?>

</body>
</html>