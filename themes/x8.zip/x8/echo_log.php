<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<section id="body">
<article>
	<center><h2 class="post-title"><?php echo $log_title; ?></h2></center>

	<div class="content"><?php echo $log_content; ?><div style="clear:both;"></div>
        <!-- 信息栏 --> 
	<div class="post-meta">
				<!-- the date and time -->
				<span class="post-time">
				<?php echo gmdate('y年n月j日', $date); ?>
				</span>
				<!-- post category -->
				<span class="post-category"><?php blog_sort($logid); ?></span>
				<span class="post-comments"><?php echo $comnum; ?>條評論</span></div>

</div>
</article>
<div id="postnavi"><?php neighbor_log($neighborLog); ?></div>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<div id="slidebox">
            <a class="close"></a> 
			您还有可能感兴趣的日志：
	<?php doAction('log_related', $logData); ?>
</div>
</section>

<?php
 include View::getView('footer');
?>