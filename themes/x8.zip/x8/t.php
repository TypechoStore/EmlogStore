<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<link rel="stylesheet" type="text/css" media="all" href="<?php echo TEMPLATE_URL; ?>t.css" />
<section id="body">
  <div id="tw">
      <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    ?>
<div class="post">	
<div class="entry">
	<div class="status-ava"><h2><img alt="" src="<?php echo $avatar; ?>" class="avatar avatar-48 photo" height="48" width="48"></h2></div>
	
	<div class="status-con"><p> <?php echo $val['t'];?> </p>
</div>
	
	<div class="status-info"><span class="post-info-time"><?php echo $val['date'];?></span><span class="post-info-com"><?php echo $author; ?> </span></div>
</div>
<div class="clear"></div>
</div>
      <?php endforeach;?>
     <?php if($pageurl) echo ' <nav id="pagenavi"><div class="pagenav clearfix">'.$pageurl.'</div></nav>' ?>
  </div>
</div>
</section>
<!--end content-->
<?php
 include View::getView('footer');
?>
