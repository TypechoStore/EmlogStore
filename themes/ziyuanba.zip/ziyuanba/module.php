<?php 
/**
 * 侧边栏组件、页面模块、模板函数
 * 资源网模板定制联系作者QQ：85443298
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
if (!function_exists('_g')) {
  emMsg('请先下载并安装<a href="http://www.emlog.net/plugin/144" target="_blank">模板设置插件</a>', BLOG_URL . 'admin/plugins.php');
}
?>
<?php
//blog：文章标签
function blog_tags($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	$log_cache_tags[$blogid] = array_slice($log_cache_tags[$blogid],0,5); //6是要调用的标签数量
	if (!empty($log_cache_tags[$blogid])){
		$tag = '';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "	<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
		}
		echo $tag;
	}else{
    echo '<a>暂无标签</a>';
  }
}
?>
<?php
//log：blogger
function blogger(){
    global $CACHE;
    $user_cache = $CACHE->readCache('user');
    $name = $user_cache[1]['name'];
    $mail = empty($user_cache[1]['mail']) ? '没填写邮箱' : $user_cache[1]['mail'] ;
     $des = empty($user_cache[1]['des']) ? '该家伙很赖.啥也没写' : $user_cache[1]['des'] ;
    $avatar = empty($user_cache[1]['avatar']) ? BLOG_URL.'avatar/default.jpg' : BLOG_URL. $user_cache[1]['avatar']; 
?>
<div class="brand-wrap" style="background-image:url(<?php echo TEMPLATE_URL; ?>img/brand.jpg)">
<div class="brand">
<a href="/" class="avatar waves-effect waves-circle waves-light"><img src="<?php echo $avatar =preg_replace('/thum-|thum52-/','',$avatar)?>"></a>
<hgroup class="introduce">
<h5 class="nickname"> <?php echo $name; ?> </h5>
<a href="mailto: <?php echo $mail; ?>" title="<?php echo $mail; ?>" class="mail"> <?php echo $des; ?> </a>
</hgroup>
</div>
<?php }?>
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	?>
	 <ul class="layui-nav fly-nav">
	<?php
	foreach($navi_cache as $value):

        if ($value['pid'] != 0) {
            continue;
        }

		if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):
			?>
			<li class="layui-nav-item"><a href="<?php echo BLOG_URL; ?>admin/">管理站点</a></li>
			<li class="layui-nav-item"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
        $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'layui-this' : 'common';
		?>
		<li class="layui-nav-item <?php echo $current_tab;?>">
			<a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php list($a,$b) = split('#',$value['naviname']); if(empty($b)) {echo $a;}else {echo $a;} ?></a>
			<?php if (!empty($value['children'])) :?>
				<dl class="layui-nav-child">
                <?php foreach ($value['children'] as $row){
                        echo '<dd><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></dd>';
                }?>
			</dl>
            <?php endif;?>

            <?php if (!empty($value['childnavi'])) :?>
				<dl class="layui-nav-child">
                <?php foreach ($value['childnavi'] as $row){
                        $newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';
                        echo '<dd><a href="' . $row['url'] . "\" $newtab >" . $row['naviname'].'</a></dd>';
                }?>
			</dl>
            <?php endif;?>

		</li>
	<?php endforeach; ?>
	</ul>
<?php }?>
<?php
//blog：置顶
function topflg($top, $sortop='n', $sortid=null){
    if(blog_tool_ishome()) {
       echo $top == 'y' ? "[置顶]" : '';
    } elseif($sortid){
       echo $sortop == 'y' ? "[分类置顶]" : '';
    }
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
    $editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
    echo $editflg;
}
?>
<?php
//blog：文章标签
function blog_tag($blogid){
    global $CACHE;
    $tag_model = new Tag_Model();

    $log_cache_tags = $CACHE->readCache('logtags');
    if (!empty($log_cache_tags[$blogid])){
        $tag = '';
        foreach ($log_cache_tags[$blogid] as $value){
            $tag .= "	<li class=\"article-tag-list-item\">
<a class=\"article-tag-list-link waves-effect waves-button\"  href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a> </li>';
        }
        echo $tag;
    }
    else
    {
        $tag_ids = $tag_model->getTagIdsFromBlogId($blogid);
        $tag_names = $tag_model->getNamesFromIds($tag_ids);

        if ( ! empty($tag_names))
        {
            $tag = '';

            foreach ($tag_names as $key => $value)
            {
                $tag .= "<li class=\"article-tag-list-item\">
<a class=\"article-tag-list-link waves-effect waves-button\" href=\"".Url::tag(rawurlencode($value))."\">".htmlspecialchars($value).'</a></li>';
            }

            echo $tag;
        }
    }
}
?>
<?php
//blog：文章作者
function blog_author($uid){
    global $CACHE;
    $user_cache = $CACHE->readCache('user');
    $author = $user_cache[$uid]['name'];
    $mail = $user_cache[$uid]['mail'];
    $avatar= getGravatar($mail);
    $des = $user_cache[$uid]['des'];
    $title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
    echo $author;
}
?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
    extract($neighborLog);?>
    <?php if($nextLog || $prevLog){?>
<nav class="post-nav flex-row flex-justify-between">
    <?php if($prevLog):?>
<div class="waves-block waves-effect prev">
<a href= "<?php echo Url::log($prevLog['gid']) ?>"  id="post-prev" class="post-nav-link"><div class="tips"><i class="icon icon-angle-left icon-lg icon-pr"></i> Prev</div><h4 class="title"> <?php echo $prevLog['title'];?> </h4></a></div>
<?php else :  ?>
<div class="waves-block waves-effect prev">
<a href= "#"  id="post-prev" class="post-nav-link"><div class="tips"><i class="icon icon-angle-left icon-lg icon-pr"></i> Prev</div><h4 class="title">没有咯</h4></a></div>
    <?php endif;?>
    <?php if($nextLog):?>
<div class="waves-block waves-effect next"><a href="<?php echo Url::log($nextLog['gid']) ?>" id="post-next" class="post-nav-link"><div class="tips">Next <i class="icon icon-angle-right icon-lg icon-pl"></i></div><h4 class="title"> <?php echo $nextLog['title'];?> </h4></a></div>
<?php else : ?>
<div class="waves-block waves-effect next"><a href="#" id="post-next" class="post-nav-link"><div class="tips">Next <i class="icon icon-angle-right icon-lg icon-pl"></i></div><h4 class="title"> 没有咯 </h4></a></div>
    <?php endif;?>
</nav>
    <?php };?>
<?php }?>
<?php 
//解决页面标题重复
function page_tit($page) {
 if ($page>=2){ 
 echo ' _第'.$page.'页'; 
 }
 }
 ?>
 <?php
//blog：首页最新文章
function cms_newlog($page,$number){
  $db = MySql::getInstance();
  $sql = "SELECT * FROM ".DB_PREFIX."blog WHERE type='blog' AND checked='y' AND hide='n' ORDER BY `top` DESC,`date` DESC LIMIT $page,$number";
  $list = $db->query($sql);
?>
<?php
while($row = $db->fetch_array($list)){
    $time = date('m-d',$row['date']);
/*$search_pattern = '%<img[^>]*?src=[\'\"]((?:(?!\/admin\/|>).)+?)[\'\"][^>]*?>%s';
  preg_match($search_pattern, $row['content'], $img);
  $row['img'] = isset($img[1])?$img[1]:TEMPLATE_URL.'lib/img/default.jpg';*/
?>
<?php if($row['top']=='y'):?>
 <li>
<a href="<?php echo Url::log($row['gid']);?>" target="_blank" title="<?php echo $row['title'];?>" class="tit"><?php echo $row['title'];?></a>
								<font class="ads"><i class="ad">广告</i></font></li>
<?php else:?>
 <li <?php 
	if(getimeLogNum()=='0'){if(date('m-d',time()-24*3600)==date('m-d', $row['date'])){echo "class='new'";} }else{if(date('m-d')==date('m-d', $row['date'])){echo "class='new'";}}
	?>>
								<a href="<?php echo Url::log($row['gid']);?>" target="_blank" title="<?php echo $row['title'];?>" class="tit"><?php echo $row['title'];?></a>
								<font <?php 
	if(getimeLogNum()=='0'){if(date('m-d',time()-24*3600)==date('m-d', $row['date'])){echo "class='new-time'";} }else{if(date('m-d')==date('m-d', $row['date'])){echo "class='new-time'";}}
	?>><?php echo date('m-d', $row['date']);?></font></li>
<?php endif;?>
<?php } ?>
          </ul>
<?php } ?>
<?php
//今日更新
function getimeLogNum1(){
  $Log_Model = new Log_Model();
  //构造时间戳
  $today = strtotime(date('Y-m-d'));
  //查询今日
  $today_sql = "and date>$today and checked='y' and top='n'";
  $today_num = $Log_Model->getLogNum('n', $today_sql);
  //判断输出
  if($today_num=='0'){
    echo '+0';
  }else{
    echo  '+'.$today_num;
  }
}
?>
<?php 
//blog：首页文章分类选项卡
function blog_cmslog($sort){
  $cmsid = explode(',',$sort);
  $db = MySql::getInstance();
  global $CACHE;
  $sort_cache = $CACHE->readCache('sort');
?>
    <div class="title">文章专区
      <div class="type">
<?php
$x=0;
$s=1;
foreach($cmsid as $i){
  $x++;
  foreach($sort_cache as $value){
    if($x == 1){
      if($value['sid'] == $i){
        echo '<a class="hover" alt="'.$value['sortname'].'">'.$value['sortname'].'</a>';
      }
    }else{
      if($value['sid'] == $i){
        echo '<a class="" alt="'.$value['sortname'].'">'.$value['sortname'].'</a>';
      }
    }
  }
}
?>
      </div>
    </div>
    <div class="tpl-tr-wai">
      <div class="tpl-tr layui-clear">
<?php foreach($cmsid as $i){?>
        <div class="list-top">
          <ul class="list-img">
<?php
$result = $db->query("SELECT * FROM ".DB_PREFIX."sort WHERE sid='".$i ."' or pid='".$i."'");
$all = array();
while ($row = $db->fetch_array($result)){$all[] = $row;}
$sorts = array();
$sortids = array();
foreach($all as $v){$sorts[$v['sid']] = $v;$sortids[] = $v['sid'];}
if(!$sortids){$sortids[] = 0;}
$sql2 = "SELECT * FROM ".DB_PREFIX."blog WHERE sortid in(".  join(",", $sortids).") AND checked='y' AND hide='n' ORDER BY `date` DESC LIMIT 5";
$list = $db->query($sql2);
while($row = $db->fetch_array($list)){
  $time = date('m-d',$row['date']);
  $search_pattern = '%<img[^>]*?src=[\'\"]((?:(?!\/admin\/|>).)+?)[\'\"][^>]*?>%s';
  preg_match($search_pattern, $row['content'], $img); 
  $row['img'] = isset($img[1])?$img[1]:TEMPLATE_URL.'lib/img/default.jpg';
?>
            <li>
              <a href="<?php echo Url::log($row['gid']);?>" class="layui-clear" target="_blank">
                <div class="img">
                  <img <?php if($s=='1'){echo ' class="lazy" ';}?> src="<?php echo $row['img'];?>" alt="<?php echo $row['title'];?>"/>
                </div>
                <span><?php echo $row['title'];?></span>
              </a>
            </li>
<?php }?>
          </ul>
          <ul class="list-tit">
<?php
$result = $db->query("SELECT * FROM ".DB_PREFIX."sort WHERE sid='".$i ."' or pid='".$i."'");
$all = array();
while ($row = $db->fetch_array($result)){$all[] = $row;}
$sorts = array();
$sortids = array();
foreach($all as $v){$sorts[$v['sid']] = $v;$sortids[] = $v['sid'];}
if(!$sortids){$sortids[] = 0;}
$sql2 = "SELECT * FROM ".DB_PREFIX."blog WHERE sortid in(".  join(",", $sortids).") AND checked='y' AND hide='n' ORDER BY `date` DESC LIMIT 15";
$list = $db->query($sql2);
while($row = $db->fetch_array($list)){
  $time = date('m-d',$row['date']);
  if((date('Ymd',time())-date('Ymd',$row['date']))< 1){$timec = ' class="new"';}else{$timec = '';}
?>
            <li<?php echo $timec;?>>
              <a href="<?php echo Url::log($row['gid']);?>" title="<?php echo $row['title'];?>" target="_blank"><?php echo $row['title'];?></a>
              <span><?php echo $time;?></span>
            </li>
<?php }?>
          </ul>
        </div>
<?php $s++;}?>
      </div>
    </div>
<?php }?>
<?php 
//blog：首页下载分类选项卡
function blog_downlog($sort){
  $cmsid = explode(',',$sort);
  $db = MySql::getInstance();
  global $CACHE;
  $sort_cache = $CACHE->readCache('sort');
?>
    <div class="title">下载专区
      <div class="type">
<?php
$x=0;
foreach($cmsid as $i){
  $x++;
  foreach($sort_cache as $value){
    if($x == 1){
      if($value['sid'] == $i){
        echo '<a class="hover" alt="'.$value['sortname'].'">'.$value['sortname'].'</a>';
      }
    }else{
      if($value['sid'] == $i){
        echo '<a class="" alt="'.$value['sortname'].'">'.$value['sortname'].'</a>';
      }
    }
  }
}
?>
      </div>
    </div>
    <div class="tpl-tr-wai">
      <div class="tpl-tr layui-clear">
<?php
  $s=1;
foreach($cmsid as $i){
?>
      <div class="list-top">
        <ul>
<?php
$result = $db->query("SELECT * FROM ".DB_PREFIX."sort WHERE sid='".$i ."' or pid='".$i."'");
$all = array();
while ($row = $db->fetch_array($result)){$all[] = $row;}
$sorts = array();
$sortids = array();
foreach($all as $v){$sorts[$v['sid']] = $v;$sortids[] = $v['sid'];}
if(!$sortids){$sortids[] = 0;}
$sql2 = "SELECT * FROM ".DB_PREFIX."blog WHERE sortid in(".  join(",", $sortids).") AND checked='y' AND hide='n' ORDER BY `date` DESC LIMIT 12";
$list = $db->query($sql2);
while($row = $db->fetch_array($list)){
  $time = date('Y-m-d',$row['date']);
  $search_pattern = '%<img[^>]*?src=[\'\"]((?:(?!\/admin\/|>).)+?)[\'\"][^>]*?>%s';
  preg_match($search_pattern, $row['content'], $img); 
  $row['img'] = isset($img[1])?$img[1]:TEMPLATE_URL.'lib/img/default.jpg';
?>
          <li>
            <div class="fl"><img <?php if($s=='1'){echo ' class="lazy" ';}?> src="<?php echo $row['img'];?>" alt="<?php echo $row['title'];?>" /></div>
            <div class="fr">
              <div class="tit">
                    <h3><a href="<?php echo Url::log($row['gid']);?>" target="_blank" title='<?php echo $row['title'];?>'><?php echo $row['title'];?></a></h3>
                    <span><i>★★★☆☆</i> /&nbsp;&nbsp;<?php echo $time;?></span>
              </div>
              <div class="down"><span><a href="<?php echo Url::log($row['gid']);?>" target="_blank">立即下载</a></span></div>
            </div>
          </li>
<?php }?>
        </ul>
      </div>
<?php $s++;}?>
      </div>
    </div>
<?php }?>
<?php
//本周热门排行文章
function blog_hotlog7() {
$db = MySql::getInstance();
$time = time();
$sql = "SELECT gid,title FROM ".DB_PREFIX."blog WHERE type='blog' AND date > $time - 7*24*60*60 ORDER BY `views` DESC LIMIT 0,18";
$list = $db->query($sql);
$i=0;
while($row = $db->fetch_array($list)){
$i++;
?>
        <li><a href="<?php echo Url::log($row['gid']); ?>" target="_blank"><i><?php echo $i;?></i> <?php echo $row['title']; ?> </a></li>
<?php } ?>
<?php } ?>
<?php
//本月热门排行文章
function blog_hotlog30() {
$db = MySql::getInstance();
$time = time();
$sql = "SELECT gid,title FROM ".DB_PREFIX."blog WHERE type='blog' AND hide='n' AND date > $time - 30*24*60*60 ORDER BY `views` DESC LIMIT 0,18";
$list = $db->query($sql);
$i=0;
while($row = $db->fetch_array($list)){
$i++;
?>
        <li><a href="<?php echo Url::log($row['gid']); ?>" target="_blank"><i><?php echo $i;?></i> <?php echo $row['title']; ?> </a></li>
<?php } ?>
<?php } ?>
<?php 
//人气排行右边功能块
function blog_newgg($sort){
  $db = MySql::getInstance();
  global $CACHE;
  $sort_cache = $CACHE->readCache('sort');
  foreach($sort_cache as $value):
  if($value['sid'] == $sort):
?>
	<?php
	$sql1 = "SELECT sortname FROM ".DB_PREFIX."sort WHERE sid=".$sort;
	$s = $db->query($sql1);
	$sortname = $db->fetch_array($s);
	?>
    <div class="title"><?php echo $sortname['sortname'];?>
    </div>
<?php endif;?>
<?php endforeach;?>
<ul class="twdd">
<?php
$sql2 = "SELECT * FROM ".DB_PREFIX."blog WHERE sortid=".$sort." AND checked='y' AND hide='n' ORDER BY `date` DESC LIMIT 5";
$list = $db->query($sql2);
while($row = $db->fetch_array($list)){
  $time = date('Y-m-d',$row['date']);
  $search_pattern = '%<img[^>]*?src=[\'\"]((?:(?!\/admin\/|>).)+?)[\'\"][^>]*?>%s';
  preg_match($search_pattern, $row['content'], $img);
  $row['img'] = isset($img[1])?$img[1]:TEMPLATE_URL.'lib/img/default.jpg';
?>
      <li>
        <a href="<?php echo Url::log($row['gid']);?>" class="layui-clear" target="_blank">
          <div class="list-img">
            <img src="<?php echo $row['img'];?>" />
          </div>
          <div class="info">
            <h3><?php echo $row['title'];?></h3>
            <font class=""><?php echo $time;?></font>
          </div>
        </a>
      </li>
<?php }?>
    </ul>
<?php }?>
<?php
//blog：列表分类
function blog_sort($blogid){
  global $CACHE; 
  $log_cache_sort = $CACHE->readCache('logsort');
  if(!empty($log_cache_sort[$blogid])){
    echo $log_cache_sort[$blogid]['name'];
  }else{
    echo '无分类';
  }
}
?>
<?php
//blog：列表分类
function blog_sort1($blogid){
  global $CACHE; 
  $log_cache_sort = $CACHE->readCache('logsort');
  if(!empty($log_cache_sort[$blogid])){
    echo '<a href="'.Url::sort($log_cache_sort[$blogid]['id']).'" target="_blank" title="本文所属栏目：'.$log_cache_sort[$blogid]['name'].'">'.$log_cache_sort[$blogid]['name'].'</a>';
  }else{
    echo '<a>无分类</a>';
  }
}
?>
<?php
//blog：列表分类
function blog_sort2($blogid){
  global $CACHE; 
  $log_cache_sort = $CACHE->readCache('logsort');
  if(!empty($log_cache_sort[$blogid])){
    echo $log_cache_sort[$blogid]['name'];
  }else{
    echo '无分类';
  }
}
?>
<?php //分页函数
function blog_fy($count,$perlogs,$page,$url,$anchor=''){
$pnums = @ceil($count / $perlogs);
$page = @min($pnums,$page);
$prepg=$page-1;                 //上一页
$nextpg=($page==$pnums ? 0 : $page+1); //下一页
$urlHome = preg_replace("|[\?&/][^\./\?&=]*page[=/\-]|","",$url);
//开始分页导航内容
$re = "";
if($pnums<=1){
  $re .="<li><span class=\"pageinfo\">共 <strong>$pnums</strong> 页</li>";
}else{
if($page!=1) $re .="<li><a href=\"$urlHome$anchor\">首页</a></li>"; 
if($prepg) $re .="<li><a href=\"$url$prepg$anchor\">上一页</a></li>";
for ($i = $page-2;$i <= $page+2 && $i <= $pnums; $i++){
if ($i > 0){if ($i == $page){$re .= "<li class=\"thisclass\"><a>$i</a></li>";
}elseif($i == 1){$re .= "<li><a href=\"$urlHome$anchor\">$i</a></li>";
}else{$re .= "<li><a href=\"$url$i$anchor\">$i</a></li>";}
}}
if($nextpg) $re .="<li><a href=\"$url$nextpg$anchor\">下一页</a></li>"; 
if($page!=$pnums) $re.=" <a href=\"$url$pnums$anchor\" title=\"末页\">末页</a>";
$re .="<li><span class=\"pageinfo\">共 <strong>$pnums</strong> 页</li>";
//下拉跳转列表,循环列出所有页码
}
return $re;
}
?>
<?php
//widget：分类
function blog_listsort($sortid){
  global $CACHE;
$sort_cache = $CACHE->readCache('sort');
foreach($sort_cache as $value):
$children = $value['children'];
if($sortid == $value['pid']){
?>
              <ol><a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?></a></ol>
<?php }?>
<?php endforeach; ?>
<?php }?>
<?php
//列表页本周热门排行文章
function blog_listlog7() {
$db = MySql::getInstance();
$time = time();
$sql = "SELECT gid,title FROM ".DB_PREFIX."blog WHERE type='blog' AND date > $time - 7*24*60*60 ORDER BY `views` DESC LIMIT 0,10";
$list = $db->query($sql);
$i=0;
while($row = $db->fetch_array($list)){
$i++;
?>
        <li><a href="<?php echo Url::log($row['gid']); ?>" target="_blank"><i><?php echo $i;?></i> <?php echo $row['title']; ?> </a></li>
<?php } ?>
<?php } ?>
<?php
//列表页随机文章
function blog_randomlog(){
  $db = MySql::getInstance();
  $sj_num = Option::get('index_randlognum');
  $sql = "SELECT gid,title,date,views,content FROM ".DB_PREFIX."blog where hide = 'n' and `type` = 'blog' ORDER BY RAND() LIMIT 10";
  $list = $db->query($sql);
  $i=0;
  while($row = $db->fetch_array($list)){
  $i++;
?>
          <li><a href="<?php echo Url::log($row['gid']);?>" target="_blank"><i><?php echo $i;?></i> <?php echo $row['title']; ?> </a></li>
<?php }?>
<?php }?>
<?php
//blog：评论列表
function blog_comments($comments,$params){
    extract($comments);
    if($commentStacks): ?>
    <a name="comments"></a>
    <?php endif; ?>
    <?php
    $isGravatar = Option::get('isgravatar');
  $comnum = count($comments);foreach($comments as $value){if($value['pid'] != 0){$comnum--;}}
  $page = isset($params[5])?intval($params[5]):1;
  $i= $comnum - ($page - 1)*Option::get('comment_pnum');
    foreach($commentStacks as $cid):
    $comment = $comments[$cid];
    $comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" rel="external nofollow" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
    ?>
   <div class="comment" id="comment-<?php echo $comment['cid']; ?>">
        <a name="<?php echo $comment['cid']; ?>"></a>
        <?php if($isGravatar == 'y'): ?><div class="avatar"><img src="<?php $DB = Database::getInstance();$userData = $DB->once_fetch_array("SELECT * FROM ".DB_PREFIX."user WHERE email = '".$comment['mail']."'");if(!empty($userData['photo'])){echo $userData['photo'];}else{if(strpos($comment['mail'],'@qq.com') !== false){$Mail=$comment['mail'];$QQ_IMG=str_replace("@qq.com","",$Mail);echo "https://q.qlogo.cn/headimg_dl?bs=qq&dst_uin=".$QQ_IMG."&src_uin=www.wuaif.com&fid=blog&spec=100";}else{echo BLOG_URL . 'avatar/default.jpg';}}?>" /></div><?php endif; ?>
        <div class="comment-info">
            <strong><?php echo $comment['poster']; ?> </strong> 
      <span class="floor">&nbsp;<?php if ($i == 1){ echo "沙发";} elseif ($i == 2){echo "板凳";} elseif ($i == 3){ echo "地板";} else{ echo $i.'楼';}?></span>
      <span class="comment-time">发表于<?php echo $comment['date']; ?></span>
      <span class="comment-reply"><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">@回复</a></span>
            <div class="comment-content"><?php echo $comment['content'];?></div>
        </div>
        <?php blog_comments_children($comments, $comment['children']); ?>
    </div> 
    <?php $i--;endforeach;?>
    <div id="pagenavi">
        <?php echo $commentPageUrl;?>
    </div>
<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){
    $isGravatar = Option::get('isgravatar');
    foreach($children as $child):
    $comment = $comments[$child];
    $comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" rel="external nofollow" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
    ?>
  <div class="comment comment-children" id="comment-<?php echo $comment['cid']; ?>">
        <a name="<?php echo $comment['cid']; ?>"></a>
        <?php if($isGravatar == 'y'): ?><div class="avatar"><img src="<?php $DB = Database::getInstance();$userData = $DB->once_fetch_array("SELECT * FROM ".DB_PREFIX."user WHERE email = '".$comment['mail']."'");if(!empty($userData['photo'])){echo $userData['photo'];}else{if(strpos($comment['mail'],'@qq.com') !== false){$Mail=$comment['mail'];$QQ_IMG=str_replace("@qq.com","",$Mail);echo "https://q.qlogo.cn/headimg_dl?bs=qq&dst_uin=".$QQ_IMG."&src_uin=www.wuaif.com&fid=blog&spec=100";}else{echo BLOG_URL . 'avatar/default.jpg';}}?>" /></div><?php endif; ?>
        <div class="comment-info">
            <strong><?php echo $comment['poster']; ?> </strong><?php if($comment['level'] < 4): ?><span class="comment-reply"><a id="ta" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)"><i class="fa fa-reply"></i>回复</a></span><?php endif; ?>
      <br /><span class="comment-time"><?php echo $comment['date']; ?></span>
            <div class="comment-content"><?php echo $comment['content'];?></div>
            
        </div>
        <?php blog_comments_children($comments, $comment['children']);?>
    </div>
    <?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
$code = Option::get('comment_code');
    if($allow_remark == 'y'): ?>
  <div id="comment-place">
    <div class="comment-post" id="comment-post">
        <div class="cancel-reply" id="cancel-reply" style="display:none"><div id="respond"><a href="javascript:void(0);" onclick="cancelReply()">取消回复</a></div></div>
        <a name="respond"></a>
        <form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
            <input type="hidden" name="gid" value="<?php echo $logid; ?>" />
            <p><textarea name="comment" id="comment" rows="7" tabindex="4" placeholder="来都来了，不随便说两句吗？"></textarea></p>            
            <p class="form-submit">       
      <span class="submit-tool">
	  <?php if(ROLE == ROLE_VISITOR): ?>
      
        <input type="text" name="qq" id="qq" placeholder="输入QQ号" value=""><!--QQ*（输入QQ即可获取资料）-->
        <input type="hidden"  name="comname" id="comname" value="<?php echo $ckname; ?>" placeholder="昵称">
        <input type="hidden" name="commail" id="commail" value="<?php echo $ckmail; ?>" placeholder="邮箱">
        <input type="hidden"  name="comurl" id="comurl" value="<?php echo $ckurl; ?>" placeholder="网址">
            <?php endif; ?>
      </span>
      <?php if($code == 'y'):?><span class="submit-tool code"><?php echo $verifyCode; ?></span><?php endif;?>
      <?php if(SEND_MAIL == 'Y' || REPLY_MAIL == 'Y'){?>
        <span class="checkbox"><input value="y" type="checkbox" name="send" checked="checked">  允许邮件通知</span>
      <?php }?><button class="sendpl" type="submit" id="comment_submit">发布评论</button>     
      </p>
            <input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/>
        </form>
    </div>
    </div>    
    <?php endif; ?>
<?php }?>
<?php
//blog：链接
function ilinks(){
global $CACHE; 
$link_cache = $CACHE->readCache('link');
//if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
?>
<li><a href="https://www.ziyuanba.com" target="_blank">资源吧</a> </li>
<li><a href="https://www.qiyuzy.com" target="_blank">七鱼网</a> </li>
<li><a href="https://www.isiyuan.net" target="_blank">思源网</a> </li>
<?php foreach($link_cache as $value): ?>
          <li><a href="<?php echo $value['url'];?>" title="<?php if($value['des'] == ""){echo $value['link'];}else{echo $value['des'];}?>" target="_blank"><?php echo $value['link'];?></a></li>
<?php endforeach; ?>
<?php }?>
<?php 
function siyuan_flashid($gid){
	$db=MySql::getInstance();	
	$sql=$db->query("SELECT * FROM ".DB_PREFIX."blog WHERE  hide='n' AND type='blog' AND gid IN($gid) order by date DESC");
	while($value = $db->fetch_array($sql)){
	if(pic_thumb($value['content'])){$img = pic_thumb($value['content']);
	}elseif(picthumb($value['gid'])){$img = picthumb($value['gid']);
	}else{$img = TEMPLATE_URL.'lib/img/default.jpg';} 
	$date = gmdate('Y-m-d', $value['date']);?>
<div class=""><a href="<?php echo Url::log($value['gid']);?>"><img class="flash" src="<?php echo $img;?>"></a></div>
			<?php 	
				}	
			}
//getimageurl
function pic_thumb($content){
    preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $content, $img);
    $imgsrc = !empty($img[1]) ? $img[1][0] : '';
    if($imgsrc):
        return $imgsrc;
    endif;
}
//getimage
function picthumb($blogid) {
    $db = MySql::getInstance();
    $sql = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$blogid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";
//    die($sql);
    $imgs = $db->query($sql);
    while($row = $db->fetch_array($imgs)){
        $pict.= ''.BLOG_URL.substr($row['filepath'],3,strlen($row['filepath'])).'';
    }
    return $pict;
}
//30天按点击率排行文章
function getdatelogs($log_num,$sortid,$type)
{
	$db = MySql::getInstance();
        $result = $db->query("SELECT * FROM ".DB_PREFIX."sort WHERE pid in($sortid)");
        while ($row = $db->fetch_array($result)){
		$id .= $row['sid'] . ',';}
	$time = time();
    if ($id == '') {
		$sql = $db->query("SELECT * FROM " . DB_PREFIX . "blog WHERE sortid in ($sortid)  AND type='blog' AND hide='n' AND checked='y' AND date > $time - $type*24*60*60 ORDER BY `views` DESC LIMIT 0,$log_num");
	} else {
		$list0 = rtrim($id, ',');
		$list1 = $sortid . ',' . $list0;
		$sql = $db->query("SELECT * FROM " . DB_PREFIX . "blog WHERE sortid in ($list1) AND type='blog' AND hide='n' AND checked='y' AND date > $time - $type*24*60*60 ORDER BY `views` DESC LIMIT 0,$log_num");
	}
	while ($row = $db->fetch_array($sql)) {
	if(pic_thumb($row['content'])){$img = pic_thumb($row['content']);
}elseif(picthumb($row['gid'])){$img = picthumb($row['gid']);
}else{$img = TEMPLATE_URL.'lib/img/default.jpg';} 	
?>
<li>
				<a href="<?php echo Url::log($row['gid']); ?>" target="_blank" class="layui-clear" title="<?php echo $row['title']; ?>">
				<div class="img">
					<img src="<?php echo $img;?>" alt="<?php echo $row['title']; ?>">
					<span>立即下载</span>
				</div>
				<div class="tit">
					<?php echo $row['title']; ?>
				</div>
				</a>
				</li>
<?php }}
//最新列表-分类文章
function get_sortlogs($sort,$num) {
// 	if($sort){
// 		$where = 'and sortid ='.$sort;
// 	}else{
// 		$where = '';
// 	}
	if($num){
		$num = $num;
	}else{
		$num = '20';
	}
	$db = MySql::getInstance();
	$sql = "SELECT gid,title,date,content,views FROM ".DB_PREFIX."blog WHERE type='blog' and hide='n' and sortid IN ($sort) ORDER BY `date` DESC LIMIT 0,$num";
	$list = $db->query($sql);
	while($row = $db->fetch_array($list)){ 
if(pic_thumb($row['content'])){$img = pic_thumb($row['content']);
}elseif(picthumb($row['gid'])){$img = picthumb($row['gid']);
}else{$img = TEMPLATE_URL.'lib/img/default.jpg';} 	
?>
<li>
<a href="<?php echo Url::log($row['gid']); ?>" target="_blank" title="<?php echo $row['title'];?>" class="tit"><img src="<?php echo $img;?>" alt="<?php echo $row['title'];?>"><?php echo $row['title'];?></a>
<font <?php 
	if(getimeLogNum()=='0'){if(date('m-d',time()-24*3600)==date('m-d', $row['date'])){echo "class='new-time'";} }else{if(date('m-d')==date('m-d', $row['date'])){echo "class='new-time'";}}
	?>><?php echo date('m-d', $row['date']);?></font></li>
<?php 
	} 
}
function siyuan_Specifyid($gid){
$db=MySql::getInstance();	
$sql=$db->query("SELECT * FROM ".DB_PREFIX."blog WHERE  hide='n' AND type='blog' AND gid IN($gid) order by date DESC");
while($value = $db->fetch_array($sql)){
if(pic_thumb($value['content'])){$img = pic_thumb($value['content']);
}elseif(picthumb($value['gid'])){$img = picthumb($value['gid']);
}else{$img = TEMPLATE_URL.'lib/img/default.jpg';} 
$date = gmdate('Y-m-d', $value['date']);?>
<li>
					<div class="fl">
						<img src="<?php echo $img;?>" alt="<?php echo $value['title'];?>">
					</div>
					<div class="fr">
						<div class="tit">
							<h3><a href="<?php echo Url::log($value['gid']);?>" target="_blank" title="<?php echo $value['title'];?>" rel="nofollow"><?php echo $value['title'];?></a></h3>
							<span><i>★★★★☆</i> / 站长推荐</span>
						</div>
						<div class="down">
							<b><?php echo $date;?></b>
							<span><a href="<?php echo Url::log($value['gid']);?>" target="_blank">立即下载</a></span>
						</div>
					</div>
					</li>
		<?php 	
			}	
		}
function cmslist1($sortid){
	$type=30;
	$log_num=10;
	$db = MySql::getInstance();
	$time = time();
	?>
	<?php
$result = $db->query("SELECT * FROM ".DB_PREFIX."sort WHERE pid in($sortid)");
        while ($row = $db->fetch_array($result)){
		$id .= $row['sid'] . ',';}
    if ($id == '') {
		$sql = $db->query("SELECT * FROM " . DB_PREFIX . "blog WHERE sortid in ($sortid)  AND type='blog' AND hide='n' AND checked='y' AND date > $time - $type*24*60*60 ORDER BY `views` DESC LIMIT 0,$log_num");
	} else {
		$list0 = rtrim($id, ',');
		$list1 = $sortid . ',' . $list0;
		$sql = $db->query("SELECT * FROM " . DB_PREFIX . "blog WHERE sortid in ($list1) AND type='blog' AND hide='n' AND checked='y' AND date > $time - $type*24*60*60 ORDER BY `views` DESC LIMIT 0,$log_num");
	}
	while ($row = $db->fetch_array($sql)) {
        $time = date('m-d',$row['date']);
        $aid++;
		$date=date('m-d');
	?>
<li><i><?php echo $aid;?></i><a href="<?php echo Url::log($row['gid']);?>" target="_blank"><?php echo $row['title'];?></a></li>
<?php }?>
<?php }
//相关文章调用代码。
function related_logs($logData = array())
{	$configfile = EMLOG_ROOT.'/content/plugins/related_log/related_log_config.php';
	if (is_file($configfile)) {
	require $configfile;
	}else{$related_log_type = 'sort';//相关日志类型，sort为分类，tag为日志；
	$related_log_sort = 'rand';//排列方式，views_desc 为点击数（降序）comnum_desc 为评论数（降序） rand 为随机 views_asc 为点击数（升序）comnum_asc 为评论数（升序）
	$related_log_num = '3';
	$related_inrss = 'n'; //是否显示在rss订阅中，y为是，其它值为否
	}
	global $value;
	$DB = MySql::getInstance();
	$CACHE = Cache::getInstance();
	extract($logData);
	if($value)
	{
		$logid = $value['id'];
		$sortid = $value['sortid'];
		global $abstract;
	}
	$sql = "SELECT gid,title,content FROM ".DB_PREFIX."blog WHERE hide='n' AND type='blog'";
	if($related_log_type == 'tag')
	{
		$log_cache_tags = $CACHE->readCache('logtags');
		$Tag_Model = new Tag_Model();
		$related_log_id_str = '0';
		foreach($log_cache_tags[$logid] as $key => $val)
		{
			$related_log_id_str .= ','.$Tag_Model->getTagByName($val['tagname']);
		}
		$sql .= " AND gid!=$logid AND gid IN ($related_log_id_str)";
	}else{
		$sql .= " AND gid!=$logid AND sortid=$sortid";
	}
	switch ($related_log_sort)
	{
		case 'views_desc':
		{
			$sql .= " ORDER BY views DESC";
			break;
		}
		case 'views_asc':
		{
			$sql .= " ORDER BY views ASC";
			break;
		}
		case 'comnum_desc':
		{
			$sql .= " ORDER BY comnum DESC";
			break;
		}
		case 'comnum_asc':
		{
			$sql .= " ORDER BY comnum ASC";
			break;
		}
		case 'rand':
		{
			$sql .= " ORDER BY rand()";
			break;
		}
	}
	$sql .= " LIMIT 0,$related_log_num";
	$related_logs = array();
	$query = $DB->query($sql);
	while($row = $DB->fetch_array($query))
	{
		$row['gid'] = intval($row['gid']);
		$row['title'] = htmlspecialchars($row['title']);
		$related_logs[] = $row;
	}
	$out = '';
	if(!empty($related_logs))
	{
		foreach($related_logs as $val)
		{
            if(pic_thumb($val['content'])){$img = pic_thumb($val['content']);
            }elseif(picthumb($val['gid'])){$img = picthumb($val['gid']);
            }else{$img = TEMPLATE_URL.'lib/img/default.jpg';}
			$out .= "<li class='col-xs-12 col-md-6'><a class='layui-clear' href = \"".Url::log($val['gid'])."\" title=\"{$val['title']}\"><div class='img'><img src=\"".$img."\" alt=\"{$val['title']}\"></div><div class='infos'><h3>{$val['title']}</h3><i>查看</i></div></a></li>";
	}
		$out .= "";
	}
	if(!empty($value['content']))
	{
		if($related_inrss == 'y')
		{
			$abstract .= $out;
		}
	}else{
		echo $out;
	}
}
function is_mobile() {
	$user_agent = $_SERVER['HTTP_USER_AGENT'];
	$mobile_browser = Array(
		"mqqbrowser", //手机QQ浏览器
		"opera mobi", //手机opera
		"juc","iuc",//uc浏览器
		"fennec","ios","applewebKit/420","applewebkit/525","applewebkit/532","ipad","iphone","ipaq","ipod",
		"iemobile", "windows ce",//windows phone
		"240x320","480x640","acer","android","anywhereyougo.com","asus","audio","blackberry","blazer","coolpad" ,"dopod", "etouch", "hitachi","htc","huawei", "jbrowser", "lenovo","lg","lg-","lge-","lge", "mobi","moto","nokia","phone","samsung","sony","symbian","tablet","tianyu","wap","xda","xde","zte"
	);
	$is_mobile = false;
	foreach ($mobile_browser as $device) {
		if (stristr($user_agent, $device)) {
			$is_mobile = true;
			break;
		}
	}
	return $is_mobile;
}
function getimeLogNum(){
  $Log_Model = new Log_Model();
  //构造时间戳
  $today = strtotime(date('Y-m-d'));
  //查询今日
  $today_sql = "and date>$today and checked='y' and top='n'";
  $today_num = $Log_Model->getLogNum('n', $today_sql);
  //判断输出
   return $today_num;
}
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
function crawler() {
	$userAgent = strtolower($_SERVER['HTTP_USER_AGENT']);
	$spiders = array(
	  'Googlebot', // Google蜘蛛
	  'Baiduspider', //百度蜘蛛
	  '360Spider',//360蜘蛛
	  'Sogou News Spider',//搜狗蜘蛛
	  'bingbot',//必应蜘蛛
	  'Sosospider',//搜搜蜘蛛
	  
	);
	if(!empty($userAgent)){
		foreach ($spiders as $spider) {
			$spider = strtolower($spider);
			if (strpos($userAgent, $spider) !== false) {
			  return true;
			}
		  }
	}
	return false;
}
function page_tag_key($blogid){
	$Tag_Model = new Tag_Model();
	$tags = $Tag_Model->getTag($blogid);
	if (!empty($tags)){
		foreach ($tags as $value){
			$tag .= $value['tagname'].',';
		}
	echo substr($tag,0,-1);
	}
}