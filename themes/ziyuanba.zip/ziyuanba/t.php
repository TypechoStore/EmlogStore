<?php 
/**
 * 微语
 *模板二次开发QQ85443298
 */
header('HTTP/1.1 404 Not Found');
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>