<?php 
/**
 * 首页页面
 * 二次开发联系作者QQ：85443298
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}

?>
<div class="container">
<?php if(!crawler()):?>
<div class="index-top-ad">
	<?php echo _g('gg0');?>
</div>
    <div class="Textdiv Text-Advertising">
        <!--第1列-->
        <ul class="list-unstyled">
        <?php echo _g('text');?>	</ul>
      <!--第2列------>
        <ul class="list-unstyled">
        <?php echo _g('text1');?>	</ul>
      <!--第3列------>
        <ul class="list-unstyled">
        <?php echo _g('text2');?>	</ul>
      <!--第4列-->
        <ul class="list-unstyled">	
        <?php echo _g('text3');?>	</ul>
      <!--第5列------>
        <ul class="list-unstyled">		
        <?php echo _g('text4');?>	</ul>
      </div>
      <?php endif;?>
<div class="new-position">
	<div class="left">
		<div class="layui-carousel" id="index-lb" lay-anim="" lay-indicator="inside" lay-arrow="hover" style="width: 100%; height: 300px;">
			<div carousel-item="">
<?php echo _g('slide');?>
<?php siyuan_flashid(_g('slideid'));?>
			</div>
		<div class="layui-carousel-ind"><ul><li class=""></li><li class="layui-this"></li></ul></div><button class="layui-icon layui-carousel-arrow" lay-type="sub"></button><button class="layui-icon layui-carousel-arrow" lay-type="add"></button></div>
		<div class="index-soft">
			<div class="title">
                推荐下载
			</div>
			<div class="list">
				<ul>
 <?php siyuan_Specifyid(_g('tgid'));?>
				</ul>
			</div>
		</div>
	</div>
	<div class="center">
		<div class="title">
				最近更新<font><?php getimeLogNum1();?></font>
			<div class="news-type">
				<a class="hover">全部</a>			
				<a>软件</a>
				<a>文章</a>
			</div>
		</div>
		<div class="new-list">
			<div class="new-list-y">
				<div class="r-content" id="newslist">
					<div class="new-list-page">
						<ul class="layui-clear page-wz" id="page-list">
<?php
$ul='<ul>';
$ul1='<ul style="display:none">';
if(is_mobile()){
$listnum=21;
$snum=22;	
}else{
$listnum=30;
$snum=34;	
}
echo $ul;cms_newlog(0,$listnum);
echo $ul1;cms_newlog($listnum,$listnum);
echo $ul1;cms_newlog($listnum*2,$listnum);
echo $ul1;cms_newlog($listnum*3,$listnum);
echo $ul1;cms_newlog($listnum*4,$listnum);

?>

							<div class="page layui-clear">
								<div class="top" id="last">
												上一页
								</div>
								<b class="cfx"></b>
								<div class="bottom" id="next">
												下一页
								</div>
							</div>
						</ul>
<ul class="layui-clear">
 <?php get_sortlogs(_g('index-down'),$snum);?>
						</ul>
<ul class="layui-clear">
 <?php get_sortlogs(_g('index-article'),$snum);?>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php if(_g('gg3')):?>
<div class="indexnews-ad">
	<ul class="indexnewss-ad layui-clear">
	    <li>
	        <img src="<?php echo TEMPLATE_URL; ?>lib/img/tb.jpg">
	        <div>
	            <h3>淘宝优惠券</h3>
	            <span>定期更新剁手优惠券</span>
	        </div>
	        <a class="go" href="<?php echo _g('gg3');?>" target="_blank">去看看</a>
	    </li>
	    <li>
	        <img src="<?php echo TEMPLATE_URL; ?>lib/img/tm.jpg">
	        <div>
	            <h3>天猫优惠券</h3>
	            <span>大额券限时限量领取</span>
	        </div>
	        <a class="go" href="<?php echo _g('gg4');?>" target="_blank">去看看</a>
	    </li>
	    <li>
	        <img src="<?php echo TEMPLATE_URL; ?>lib/img/pdd.jpg">
	        <div>
	            <h3>拼多多优惠券</h3>
	            <span>独家首发拼团优惠券</span>
	        </div>
	        <a class="go" href="<?php echo _g('gg5');?>" target="_blank">去看看</a>
	    </li>
	</ul>
</div>
<?php endif;?>
<div class="down-list">
<?php blog_downlog(_g('index-down'));?>
</div>
<div class="article-list">
<?php blog_cmslog(_g('index-article'));?>		
</div>
<div class="scoend">
	<div class="left">
		<div class="title">人气排行
			<div class="types">
				
				<a class="hover">本周热门</a>
				<a>本月热门</a>
			</div>
		</div>
		<div class="showtopw">
			<div class="showtop layui-clear">
				<ul class="xuhaoul">
<?php blog_hotlog7();?>
				</ul>
				<ul class="xuhaoul">
<?php blog_hotlog30();?>
				</ul>
			</div>
		</div>
	</div>
	<div class="right">
<?php blog_newgg(_g('index-articler'));?>
	</div>
</div>
</div>
<?php include View::getView('footer');?>