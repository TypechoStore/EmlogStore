<?php
/*
 * 思源定制仿资源吧基础二次开发模板设置
 * 二次开发联系作者QQ：85443298
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
	'slideid' => array(
		'type' => 'text',
		'name' => '首页轮播文章id',
		'default' => '1,2',
		'description' => '文章id必须用,间隔',
	),
	'tgid' => array(
		'type' => 'text',
		'name' => '首页推荐下载软件id',
		'default' => '1,2',
		'description' => '文章id必须用,间隔;最多两个',
	),
	'slide' => array(
		'type' => 'text',
		'name' => '轮播自定义广告',
		'multi' => true,
		'default' => '<div class="layui-this"><a href="https://www.ziyuanba.com"><img class="flash" src="content/templates/ziyuanba/lib/img/zyb.jpg"></a></div>',
	),
	'gg0' => array(
		'type' => 'text',
		'name' => '首页导航下广告',
		'multi' => true,
		'default' => '<div><a href="https://www.kjsv.com" target="_blank"><img alt="小K娱乐网" src="content/templates/ziyuanba/lib/img/xiaok.jpg" style="height: 80px; width: 100%;" /></a></div><span><a href="http://www.isiyuan.net" target="_blank"><img alt="思源" src="content/templates/ziyuanba/lib/img/siyuan.jpg" style="height: 80px; width: 100%;" /></a><a href="https://www.qiyuzy.com" target="_blank"><img alt="七鱼" src="content/templates/ziyuanba/lib/img/qiyu.jpg" style="height: 80px; width: 100%;" /></a></span>',
	),
		'text' => array(
		'type' => 'text',
		'name' => '首页文字广告',
		'multi' => true,
		'default' => '<li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#C71585;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#C71585;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#C71585;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#C71585;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#C71585;"> 文字广告位置 </span> </a> </li> ',
		'description' => '第一列',
	),
		'text1' => array(
		'type' => 'text',
		'name' => '首页文字广告',
		'multi' => true,
		'default' => '<li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#FF0033;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#FF0033;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#FF0033;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#FF0033;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#FF0033;"> 文字广告位置 </span> </a> </li> ',
		'description' => '第二列',
	),
		'text2' => array(
		'type' => 'text',
		'name' => '首页文字广告',
		'multi' => true,
		'default' => '<li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#9F79EE;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#9F79EE;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#9F79EE;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#9F79EE;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#9F79EE;"> 文字广告位置 </span> </a> </li> ',
		'description' => '第三列',
	),
		'text3' => array(
		'type' => 'text',
		'name' => '首页文字广告',
		'multi' => true,
		'default' => '<li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#228B22;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#228B22;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#228B22;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#228B22;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#228B22;"> 文字广告位置 </span> </a> </li> ',
		'description' => '第四列',
	),
		'text4' => array(
		'type' => 'text',
		'name' => '首页文字广告',
		'multi' => true,
		'default' => '<li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#0a11d6;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#0a11d6;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#0a11d6;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#0a11d6;"> 文字广告位置 </span> </a> </li><li> <a href="#" rel="nofollow" target="_blank"> <span style="color:#0a11d6;"> 文字广告位置 </span> </a> </li> ',
		'description' => '第五列',
	),
	'toplink' => array(
		'type' => 'text',
		'name' => '首页顶部菜单',
		'multi' => true,
		'default' => '<span><a href="https://www.isiyuan.net" target="_blank">广告投放</a></span><span><a href="https://www.isiyuan.net" target="_blank">留言</a></span>',
	),
	'index-down' => array(
		'type' => 'text',
		'name' => '下载专区分类ID',
		'default' => '1',
		'description' => '用英文逗号隔开可同时指定多个分类',
	),
	'index-article' => array(
		'type' => 'text',
		'name' => '文章专区分类ID',
		'default' => '1',
		'description' => '用英文逗号隔开可同时指定多个分类',
	),
	'index-articler' => array(
		'type' => 'text',
		'name' => '首页热门排行右侧块分类ID',
		'default' => '1',
		'description' => '只填写一个ID，填多了报错',
	),
	'gg3' => array(
		'type' => 'text',
		'name' => '首页最近更新下方淘宝优惠券链接',
		'multi' => true,
		'default' => '',
		'description' => '留空则不显示',
	),
	'gg4' => array(
		'type' => 'text',
		'name' => '首页最近更新下方天猫优惠券链接',
		'multi' => true,
		'default' => '',
	),
	'gg5' => array(
		'type' => 'text',
		'name' => '首页最近更新下方拼多多优惠券链接',
		'multi' => true,
		'default' => '',
	),
		'tags' => array(
		'type' => 'text',
		'name' => '关键词优化',
		'default' => '资源网,小刀资源网',
		'description' => '用英文逗号隔开可',
	),
		'logo' => array(
		'type' => 'image',
		'name' => '上传LOGO图片',
		'values' => array(
			TEMPLATE_URL . 'lib/img/logo.png',
		),
		'description' => '默认尺寸为120X50像素透明PNG图片',
	),
	'logo1' => array(
		'type' => 'image',
		'name' => '上传LOGO图片',
		'values' => array(
			TEMPLATE_URL . 'lib/img/logo1.png',
		),
		'description' => '默认尺寸为120X50像素透明PNG图片',
	),
		'qmimg' => array(
		'type' => 'image',
		'name' => '上传二维码图片',
		'values' => array(
			TEMPLATE_URL . 'lib/img/ewm.png',
		),
		'description' => '默认尺寸为120X50像素PNG图片',
	),
	'foot-url' => array(
		'type' => 'text',
		'name' => '页脚相关链接',
		'multi' => true,
		'default' => '<li><a href="/about" target="_blank" rel="nofollow">关于我们</a></li>
			<li><a href="/about/ad.html" target="_blank" rel="nofollow">广告合作</a></li>
			<li><a href="/about/tg.html" target="_blank" rel="nofollow">我要投稿</a></li>
          	<li><a href="#" target="_blank" rel="nofollow">官方Q群</a></li>',
	),
		'foot-tg' => array(
		'type' => 'text',
		'name' => '站长统计',
		'multi' => true,
		'default' => '',
	),
	'foot-copy' => array(
		'type' => 'text',
		'name' => '页脚文字说明',
		'multi' => true,
		'default' => '本站内容来源于互联网，如果有侵权内容、不妥之处，请第一时间联系我们删除。敬请谅解! E-mail：',
	),
	'email' => array(
		'type' => 'text',
		'name' => '投稿反馈邮箱',
		'default' => 'y@isiyuan.net',
		'description' => '填写邮箱即可',
	),
);