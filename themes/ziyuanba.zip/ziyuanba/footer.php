<?php 
/**
 * 页面底部信息
 * 模板制作思源
 *模板二次开发QQ85443298
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php if(!isset($_GET["Down"]) and !isset($_GET["Article"])and $pageurl == Url::logPage()):?>
		<div class="friends-link">
	<h3 class="container">友情链接：<font style="float: right; font-size: 13px; color: #676767;">（为了做收录和排名,近期调整 所有换链网站必须满足流量大于8000望各位站长谅解）</font></h3>
			<ul class="layui-clear container">
<?php ilinks();?>				
			</ul>
		</div>
<?php endif;?>
<footer>
<div class="layui-clear container">
	<div class="left">
		<p><?php echo _g('foot-copy');?></p>
		<ul class="layui-clear">
		<?php echo _g('foot-url');?>
         <li></li>
			<?php if(!empty($icp)):?><li><a>/</a></li><?php endif;?>
			<li><a target="_blank"><?php echo $icp;?></a></li>
			<?php if(!is_mobile()):?><li style="float: right;margin-right: 0px;"><?php echo _g('foot-tg');?></li><?php endif;?>
		</ul>
			<?php if(is_mobile()):?><li style="float: right;margin-right: 0px;"><?php echo _g('foot-tg');?></li><?php endif;?>
	</div>
</div>
</footer>
<script src="<?php echo TEMPLATE_URL; ?>lib/js/layui.all.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>lib/js/common.js"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script>
function myrefresh()
{
   window.location.reload();
}
$(function () {
Lotto = {};
Lotto.comment = function(){
$("#qq").blur(function(){
		 	$('#qq').attr("sl",true);
		 	layer.msg('QQ资料获取中', {icon: 16,shade: 0.01});
	    	$.getJSON('<?php echo TEMPLATE_URL;?>inc/qq.php?qq='+$('#qq').val()+'&callback=?', function(q){
	    		if(q.name){
	    			$('#comname').val(q.name);
		    		$('#commail').val($('#qq').val()+'@qq.com');
		    		$('#comurl').val('http://user.qzone.qq.com/'+$('#qq').val());
		    		$('#qq').attr("disabled",false);
	    		}else{
	    			layer.msg('QQ资料获取失败', {icon: 16,shade: 0.01});
		   			$('#qq').attr("sl",false);
	    		}
	    	});
		});
}
Lotto.run = function(){this.comment();};
Lotto.run();
});
    $("#commentform").on("submit", function(event) {
        event.preventDefault();
        if ($("#comment").val() == "") {
           layer.msg('请填写评论', { icon: 5 });
            return;
        }else{
			$("#comment_submit").html('<i class="layui-icon layui-icon-loading layui-anim layui-anim-rotate layui-anim-loop"></i>');	
		}
        var a = $("#commentform").serialize();
		var reg = /<div class=\"layui-card-body\">[\r\n]*<p>(.*?)<\/p>/i;
$.ajax({
            type: 'POST',
            url: $("#commentform").attr("action"),
            data: a,
			async:true,
			beforeSend:function(){

    },
    success:function(a){
        if(reg.test(a)){
		if(a.match(reg)[1]=='评论发表成功，请等待管理员审核'){
    			layer.msg(a.match(reg)[1], { icon: 1 });
    			setTimeout('myrefresh()',150)
    			
}else{
   			layer.msg(a.match(reg)[1], { icon: 2 }); 
}
	
		
		}else{
			layer.msg('评论成功', { icon: 1 });
			setTimeout('myrefresh()',150)
		}
    },
    complete:function(){
        $("#comment_submit").html('发布评论');	
    },
    error:function(){
        //请求出错处理
    }
        });
    });
</script>
<?php if($pageurl == Url::logPage()){echo '<script src="'.TEMPLATE_URL.'lib/js/index.js"></script>';}?>
<?php if($logid):?>
<script src="<?php echo TEMPLATE_URL;?>lib/js/jquery.prettify.js"></script>
<script type="text/javascript">
$(function() {
$('pre').addClass('prettyprint linenums').attr('style', 'overflow:auto');
window.prettyPrint && prettyPrint();
});
</script>
<?php endif;?>
<?php doAction('index_footer'); ?>
</body>
</html>