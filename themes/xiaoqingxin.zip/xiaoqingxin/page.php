<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="content">
		<div class="left left_bg">
			<div id="entry_box">
				<div id="entry_title"><h2><?php echo $log_title; ?> </h2></div>
				<div id="entry_info">时间：<?php echo gmdate('Y-n-j G:i', $date); ?> &nbsp;&nbsp;&nbsp;作者：<?php blog_author($author); ?> &nbsp;&nbsp;分类：<?php blog_sort($logid); ?>&nbsp; 阅读：<?php echo $views; ?>次 &nbsp; 评论：<a href="<?php echo $value['log_url']; ?>#comments"><?php echo $comnum; ?>条</a> &nbsp;<?php editflg($logid,$author); ?> 
				</div>
				<div id="hrline"></div>
				<div id="entry"><?php echo $log_content; ?></div>

				<div class="clear"></div>
				<div id="hrline"></div>
				<div class="clear"></div>
				<div id="entry_ping">
					<div class="clear"></div>
					<?php blog_comments($comments,$params); ?>
					<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
				</div>
			</div>
		</div>
		<div class="right">
			<div id="sidead"></div>
			<?php include View::getView('side');?>
		</div>
	</div>
	<?php include View::getView('footer');?>