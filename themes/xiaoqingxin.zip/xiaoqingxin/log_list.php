<?php
/*
页面头部
Template Name:小清新
Description:小清新
Version:1.0 
Author:射雕天龙
Author Url:http://blog.wangyanxiang.com
Sidebar Amount:1
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
	<div id="map">
		<h1>您的位置：<?php if($pageurl == Url::logPage()){ ?>
		<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a>
		<?php }elseif ($params[1]=='sort'){ ?>
		<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> <em>></em> <?php echo '<a href="'.Url::sort($sortid).'">'.$sortName.'</a>';?>
		<?php }elseif ($params[1]=='tag'){ ?>
		<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> <em>></em> 标签 <?php echo htmlspecialchars(urldecode($params[2]));?> 的所有文章
		<?php }elseif($params[1]=='author'){ ?>
		<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> <em>></em> 作者 <?php echo blog_author($author);?> 的所有文章
		<?php }elseif($params[1]=='keyword'){ ?>
		<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> <em>></em> 关键词 <?php echo htmlspecialchars(urldecode($params[2]));?> 的搜索结果
		<?php }elseif($params[1]=='record'){ ?>
		<a title="返回首页" href="<?php echo BLOG_URL; ?>">首页</a> <em>></em> 发表在 <?php echo substr($params[2],0,4).'年'.substr($params[2],4,2).'月';?><?php if(strlen($params[2])=="8"){echo substr($params[2],6,2).'日';}?> 的所有文章
		<?php }?></h1>
	</div>
	<div id="content">
		<div class="left">
			<div id="rbox">
				<?php if (blog_tool_ishome()) : ?>
					<?php blog_image_slide(5); ?>

				<div id="tou">
					<?php 
						require_once View::getView('set'); 
						$Log_Model = new Log_Model();
						$viewslogs = $Log_Model->getLogsForHome("AND gid = {$hot_blog_id}");
					?>
					<?php foreach($viewslogs as $value): ?>
					<dl>
    					<dt><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"  target="_blank" ><?php echo $value['log_title']; ?></a></dt>
    					<dd><?php echo subString(strip_tags($value['content']),0,90,"..."); ?>
		        		<a href="<?php echo $value['log_url']; ?>" target="_blank" >[详细]</a>
						</dd>
					</dl>
					<?php endforeach; ?>
				</div>
				<div id="kinshs"></div>		
					<div id="hot2">
						<ol>
							<?php 
								require_once View::getView('set'); 
								$Log_Model = new Log_Model();
								$viewslogs = $Log_Model->getLogsForHome("AND gid in ({$tuijian_blog_id})");
							?>
							<?php foreach($viewslogs as $value): ?>
								<li>[推荐] <a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" target="_blank" ><?php echo $value['log_title']; ?></a></li> 
							<?php endforeach; ?>
						</ol>
					</div>
				<?php endif; ?></div>


				<?php doAction('index_loglist_top'); ?>
        		<?php foreach($logs as $value): ?>
        		<ul class="i_list" id="post-25">
				    <div class="i_left_date">
						<span><?php echo gmdate('n', $value['date']);?>月<?php echo gmdate('j', $value['date']); ?>日 </span><br>
						<span><?php echo gmdate('Y', $value['date']); ?> </span><br>
					</div> 
					<h2><a href="<?php echo $value['log_url']; ?>" rel="bookmark" title="详细阅读 <?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></h2>
					<li class="i_date">
						<span class="i_date_author"> <?php blog_author($value['author']); ?></span>
						<span class="i_date_category">  <?php blog_sort($value['logid']); ?></span>
						<span class="i_date_views"> <?php echo $value['views']; ?>次浏览 </span>
						<span class="i_date_comments"> <?php echo $value['comnum']; ?>条评论</span>
					</li>
					<?php 
						preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
						$rand_img = TEMPLATE_URL.'images/random/'.rand(1,20).'.jpg';
						$imgsrc = !empty($img[1]) ? $img[1][0] : $rand_img;
					?>
					<li class="i_img">
						<a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><img src="<?php echo $imgsrc; ?>" alt="<?php echo $value['log_title']; ?>" title="<?php echo $value['log_title']; ?>" class="post-thumbnail"></a>
				    </li>
					<li class="i_text"><?php echo subString(strip_tags($value['content']),0,250,"..."); ?></li>
					<li class="i_tag"><span class="tag_left">标签：<?php blog_tag($value['logid']); ?></span> <span class="tag_right"><a href="<?php echo $value['log_url']; ?>" title="详细阅读 <?php echo $value['log_title']; ?>">阅读全文</a></span></li>
				</ul>
				<?php endforeach; ?>
				
				<div id="pagelist">
					<?php echo $page_url;?>
				</div>
			<div>
		</div>


		
	</div>
	<div class="right">
		<div id="sidead"></div>
		<?php include View::getView('side');?>
	</div></div>
<?php include View::getView('footer');?>