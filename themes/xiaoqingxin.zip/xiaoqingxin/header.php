<?php
/*
页面头部
Template Name:小清新
Description:小清新
Version:1.0 
Author:射雕天龙
Author Url:http://blog.wangyanxiang.com
Sidebar Amount:1
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link type="text/css" href="<?php echo TEMPLATE_URL; ?>main.css" rel="stylesheet" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.7.1.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/jquery-1.4a2.min.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/jquery.KinSlideshow-1.2.1.min.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/tcejs.js"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<!--[if lte IE 6]>
<div style="background-color:#FF6600;margin:5px 0 5px 0;padding:3px 10px 3px 10px;border-color:#ccc; border-style:solid;border-width:2px;color:#fff;">

<p><font size="2"><strong>hi~~欢迎光临<?php echo $blogname; ?>！</strong>，您目前使用的是过时版本，安全性能差的 <del>IE 6.0 浏览器</del>，<?php echo $blogname; ?>在IE 6.0过时浏览器下显示会不完整，建议使用更快、更安全、最新版本浏览器！ 推荐：<big><a target="_blank" href="http://www.firefox.com.cn/download/"><u>Firefox</u></a></big>、<a target="_blank" href="http://www.opera.com">Opera</a>、<a target="_blank" href="http://www.google.com/chrome">Google Chrome</a>、<a target="_blank" href="http://www.apple.com/safari/">Safari</a> 或 <a target="_blank" href="http://windows.microsoft.com/zh-CN/internet-explorer/downloads/ie-8">IE8.0</a>。</font></p>

</div>
<![endif]-->
<div id="top_ibox">
	<div id="top_info">
		<div class="top_info_left"></div>
	</div>
	<div id="top">
		<div class="logo"><a href="<?php echo BLOG_URL; ?>/" alt="<?php echo $blogname; ?>" title="<?php echo $blogname; ?>" ><img src="<?php echo TEMPLATE_URL; ?>images/logo.png" alt="<?php echo $blogname; ?>"/></a></div><!--logo-->
  		<div class="top_bannar"></div>
  		<div class="ser">
   			<form role="search" method="get" id="searchform" action="<?php echo BLOG_URL; ?>index.php" >
				<div><label class="screen-reader-text" for="s"></label></div>
	   			<div class="bbut"><input type="text"  name="keyword" title="Search" class="searchinput" id="searchinput" onkeydown="if (event.keyCode==13) {}" onblur="if(this.value=='')value='&nbsp;搜索点什么...';" onfocus="if(this.value=='&nbsp;搜索点什么...')value='';" value="&nbsp;搜索点什么..." size="10"/></div>
				<div class="tbut"><input type="submit" class="searchaction" onclick="if(document.forms['search'].searchinput.value=='&nbsp;搜索点什么...')document.forms['search'].searchinput.value='';" alt="Search" title="Search" value="" hspace="2"/></div>
			</form>
		</div><!--ser-->
	</div><!--top-->
</div>

<div id="nav">
   <ul id="dropmenu" class="navi">
        <?php blog_navi();?>
    </ul>
</div><!--nav-->


<div id="cbox">