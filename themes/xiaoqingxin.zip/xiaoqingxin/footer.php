	<div id="footer">
		<div id="footerbox">
			<div class="footer_left">
				<ul>
					<li><a href="#">留言板</a></li>
					<li><a href="#">关于</a></li>
					<li><a href="#">时间轴</a></li>
					<li><a href="#">留言板</a></li>
					<li><a href="#">关于</a></li>
					<li><a href="#">时间轴</a></li>
					<li><a href="#">留言板</a></li>
					<li><a href="#">关于</a></li>
					<li><a href="#">时间轴</a></li>
				</ul>

				<div class="bline">  THEMES  By <a href="http://blog.wangyanxiang.com" target="_blank" title="射雕天龙的博客">射雕天龙</a><br>  2013-2015 COPYRIGHT BY  <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>  </div>
			</div>
			<div class="footer_right">
				<ul>
				   <h3>Hello 射雕天龙的博客</h3>
				   <li>射雕天龙的博客，分享自己的生活点滴和学到的网络开发技术和其他计算机技术信息！同时分享最新最好看的国产电影、美国电影等等。</li>
				</ul>
				<div class="bline">		  
					<div id="yunsd">						
						<a href="http://www.emlog.net" target="_blank">由emlog强力驱动</a> | <a href="http://www.miibeian.gov.cn" target="_blank"  rel="nofollow"><?php echo $icp; ?></a>  <?php doAction('index_footer'); ?>  <?php echo $footer_info; ?>
					</div>	
				</div>
				
			</div>
		</div>
	<div>
		<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/common_tpl.js"></script>
		<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/x.js"></script>
		<?php if(isset($ckmail) && empty($ckmail)): ?>
			<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/realgravatar.js"></script>
		<?php endif; ?>
</body>
</html>