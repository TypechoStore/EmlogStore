<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="content">
		<div class="left left_bg">
			<div id="entry_box">
				<div id="authorimg"><img alt="" src="http://www.gravatar.com/avatar/<?php global $CACHE;
				$user_cache = $CACHE->readCache('user'); echo md5($user_cache[$author]['mail']);  ?>" class="avatar avatar-60 photo" height="60" width="60"></div>
				<div id="entry_title"><h2><?php topflg($top); ?><?php echo $log_title; ?> </h2></div>
				<div id="entry_info">时间：<?php echo gmdate('Y-n-j G:i', $date); ?> &nbsp;&nbsp;&nbsp;作者：<?php blog_author($author); ?> &nbsp;&nbsp;分类：<?php blog_sort($logid); ?>&nbsp; 阅读：<?php echo $views; ?>次 &nbsp; 评论：<a href="<?php echo $value['log_url']; ?>#comments"><?php echo $comnum; ?>条</a> &nbsp;<?php editflg($logid,$author); ?> 
				</div>
				<div id="hrline"></div>
				<div id="entry"><?php echo $log_content; ?></div>
				<div id="entry_tag">标签： <?php blog_tag($logid); ?>;</div>
				<div id="share">
						<!-- Baidu Button BEGIN -->
						<div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
						<a class="bds_tsina"></a>
						<a class="bds_qzone"></a>
						<a class="bds_renren"></a>
						<a class="bds_t163"></a>
						<a class="bds_tqq"></a>
						<a class="bds_kaixin001"></a>
						<a class="bds_tieba"></a>
						<a class="bds_diandian"></a>
						<a class="bds_mail"></a>
						<a class="bds_bdhome"></a>
						<a class="bds_sqq"></a>
						<a class="bds_fx"></a>
						<a class="bds_ty"></a>
						<span class="bds_more"></span>
						<a class="shareCount"></a>
						</div>
						<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=3134744" ></script>
						<script type="text/javascript" id="bdshell_js"></script>
						<script type="text/javascript">
						document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
						</script>
						<!-- Baidu Button END -->
					</div><br><div style="clear:both;"></div>
				
				<div id="con">
					<ul id="tags">
						<li class="selectTag"><a onclick="selectTag('tagContent0',this)" href="javascript:void(0)"> 相关文章推荐</a> </li>
						<li class=""><a onclick="selectTag('tagContent1',this)" href="javascript:void(0)">随便点击看看</a> </li>
					</ul>
					<div id="tagContent">
						<div class="tagContent  selectTag" id="tagContent0" style="display: block; ">	
							<div id="entry_list">
								<ul>
									<?php $date = time() - 3600 * 24 * 360;
									  $Log_Model = new Log_Model();
									  $viewslogs = $Log_Model->getLogsForHome("AND date > {$date} ORDER BY views DESC,date DESC", 1, 6);?>
									<?php foreach($viewslogs as $value): ?>
									<li>
										<?php 
											preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
											$rand_img = TEMPLATE_URL.'images/random/'.rand(1,20).'.jpg';
											$imgsrc = !empty($img[1]) ? $img[1][0] : $rand_img;
										?>
										<a class="entry_l_img" href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" target="_blank">
											<img src="<?php echo $imgsrc; ?>" width="100" height="100" alt="<?php echo $value['log_title']; ?>" title="<?php echo $value['log_title']; ?>" class="post-thumbnail">
										</a>	  
										<span class="entry_l_t"><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" target="_blank"><?php echo $value['log_title']; ?></a></span>
										<span class="entry_l_c"><?php echo subString(strip_tags($value['content']),0,80,"..."); ?><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" target="_blank"><img src="<?php echo TEMPLATE_URL; ?>images/morei.gif"></a></span>
									</li>
									<?php endforeach; ?>
								</ul>
							</div>
						</div>

						<div class="tagContent" id="tagContent1" style="display: none; ">		
							<ul class="inul">
								<?php 
									$date = time() - 3600 * 24 * 360;
							    	$Log_Model = new Log_Model();
							    	$viewslogs = $Log_Model->getLogsForHome("AND date > {$date} ORDER BY views DESC,date DESC", 1, 10);
							    ?>
							    <?php foreach($viewslogs as $value): ?>
						        <li><a href="<?php echo $value['log_url']; ?>" title="查看文章:<?php echo $value['log_title']; ?>" target="_blank"><?php echo $value['log_title']; ?><img src="<?php echo TEMPLATE_URL; ?>images/more.gif"></a></li> 
						        <?php endforeach; ?>
						    </ul>
						</div>

					</div>
				</div>

				<div class="clear"></div>
				<div id="hrline"></div>
				<div class="clear"></div>
				<div id="entry_ping">
					<div class="clear"></div>
					<?php blog_comments($comments,$params); ?>
					<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
				</div>
			</div>
		</div>
		<div class="right">
			<div id="sidead"></div>
			<?php include View::getView('side');?>
		</div>
	</div>
	<?php include View::getView('footer');?>