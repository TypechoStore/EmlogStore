<?php
// 设置顶部热门推荐日志
$hot_blog_id='88';
//设置推荐日志
$tuijian_blog_id='49,87,85,86,48,47';
?>