<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];
?>
<div id="content">
<div id="contentleft">
	<div class="post">
		<div class="post-title">
			<div class="post-author">
				<img src="<?php echo empty($user_cache[1]['avatar']) ? TEMPLATE_URL.'images/avatar.jpg' : BLOG_URL . $user_cache[1]['avatar'] ?>"  width="50" height="50"/>
			</div>
			<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
			<p class="post-extra">
				作者：<?php blog_author($author); ?> 
				<em class="v-line">|</em>
				时间：<?php echo gmdate('Y-n-j H:i:s', $date); ?>  
				<em class="v-line">|</em>
				<?php blog_sort($logid); ?> 
				&nbsp;&nbsp;<span><?php editflg($logid,$author); ?></span>
			</p>
		</div>
		<div class="h-dotted-line"></div>
		<div class="post-content">
			<?php echo $log_content; ?>
		</div>
		<div class="post-tags">
			<?php blog_tag($logid); ?>
		</div>
		<?php doAction('log_related', $logData); ?>
		<div class="nextlog">
			<?php neighbor_log($neighborLog); ?>
		</div>
		<div style="clear:both;"></div>
		<?php blog_comments($comments); ?>
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	</div>
	<div style="clear:both;"></div>
</div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>