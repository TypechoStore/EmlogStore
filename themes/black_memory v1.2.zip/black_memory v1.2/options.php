<?php
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
    /*网站logo设置*/
    'logo' => array(
        'type' => 'image',
        'name' => '网站logo设置',
        'values' => array(
            TEMPLATE_URL . 'images/logo.png',
        ),
    ),
    /*是否开启幻灯片*/
    'slides' => array(
        'type' => 'radio',
        'name' => '幻灯片',
        'values' => array(
            'yes' => '显示',
            'no' => '隐藏',
        ),
        'default' => 'yes',
    ),
    /*是否开启幻灯片*/
    'slidesnum' => array(
        'type' => 'radio',
        'name' => '幻灯片显示数量',
        'description' => '选择显示数量，会从下面幻灯片依次显示',
        'values' => array(
            '1'=>'1',
            '2'=>'2',
            '3'=>'3',
        ),
        'default' => '2',
    ),
    /*设置自定义轮播图*/
    /*幻灯片1*/
    'hda1' => array(
        'type' => 'text',
        'name' => '首页幻灯1',
        'description' => '填写链接',
        'default' => 'http://sevennight.cc',
        ),
    'hdopen1' => array(
        'type' => 'radio',
        'name' => '',
        'description' => '页面打开方式',
        'values' => array(
            ''=>'当前窗口打开',
            '_blank'=>'新窗口打开'
        ),
        'default' => '',
    ),
    'hdt1' => array(
        'type' => 'text',
        'name' => '首页幻灯1',
        'description' => '填写标题',
        'default' => '既不回头，何必不忘。既然无缘，何须誓言。',
        ),
    'hd1' => array(
        'type' => 'image',
        'name' => '',
        'description' => '建议上传宽880px，高300px的图片，能完美的显示',
        'values' => array(
            'http://i1.tietuku.com/a194ed457f297381.png',
        ),
    ),
    /*幻灯片2*/
    'hda2' => array(
        'type' => 'text',
        'name' => '首页幻灯2',
        'description' => '填写链接',
        'default' => 'http://sevennight.cc',
        ),
    'hdopen2' => array(
        'type' => 'radio',
        'name' => '',
        'description' => '页面打开方式',
        'values' => array(
            ''=>'当前窗口打开',
            '_blank'=>'新窗口打开'
        ),
        'default' => '',
    ),
    'hdt2' => array(
        'type' => 'text',
        'name' => '',
        'description' => '填写标题',
        'default' => '恍惚中，时光停滞，岁月静好。宛如十年前。',
        ),
    'hd2' => array(
        'type' => 'image',
        'name' => '',
        'description' => '建议上传宽880px，高300px的图片，能完美的显示',
        'values' => array(
            'http://i3.tietuku.com/e449e3d45d50d74c.jpg',
        ),
    ),
    /*幻灯片3*/
    'hda3' => array(
        'type' => 'text',
        'name' => '首页幻灯3',
        'description' => '填写链接',
        'default' => '',
        ),
    'hdopen3' => array(
        'type' => 'radio',
        'name' => '',
        'description' => '页面打开方式',
        'values' => array(
            ''=>'当前窗口打开',
            '_blank'=>'新窗口打开'
        ),
        'default' => '',
    ),
    'hdt3' => array(
        'type' => 'text',
        'name' => '',
        'description' => '填写标题',
        'default' => '',
        ),
    'hd3' => array(
        'type' => 'image',
        'name' => '',
        'description' => '建议上传宽880px，高300px的图片，能完美的显示',
        'values' => array(
            TEMPLATE_URL . 'images/null.png',
        ),
    )
);