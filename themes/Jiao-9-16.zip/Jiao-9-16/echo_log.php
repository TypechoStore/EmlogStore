<?php doAction('index_head'); ?> 
<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<!-- 主体内容 -->
<div class="articleDetail container">
        <div class="row">
        <div class="col-md-12">
            <div class="articleContent">
                <!-- 标题 -->
                <div class="title"><?php echo $log_title; ?></div>
                <!-- 访问量 ...-->
                <div class="secTitleBar">
                    <ul>
                        <li>分类：<?php blog_sort($logid); ?></li>
                        <li>发表：<?php echo gmdate('Y-n-j', $date);?></li>
                        <li>作者：<?php blog_author($author); ?></li>
                        <li><a href="#comments">评论(<?php echo $comnum; ?>)</a></li>
                    </ul>
                </div>
                <!-- 内容 -->
                <div class="articleCon post_content">
                    <?php echo $log_content; ?>
                </div>
                <!-- 标签 -->
                <div class="articleTagsBox">
                    <ul><span>标签：</span><?php blog_tag($logid); ?></ul>
                </div>
                <?php if(_g('related_open')=='1'){related_logs($logData);}?>
                <!-- 评论 -->
                <div class="post_content">
					<?php doAction('log_related', $logData); ?> 
				</div>
            </div>
        </div>
    </div>
    </div>
<?php
 include View::getView('footer');
?>