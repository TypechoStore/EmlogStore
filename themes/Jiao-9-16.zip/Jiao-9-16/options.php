<?php
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
'topimg' => array(
		'type' => 'image',
		'name' => '顶部背景图',
		'values' => array(
            TEMPLATE_URL . 'images/1.jpg',
        ),
            ),	
'banana' => array(
		'type' => 'image',
		'name' => '头像',
		'values' => array(
            TEMPLATE_URL . 'images/bananau.jpg',
        ),
            ),
'name' => array(
		'type' => 'text',
		'name' => '名字',
		'values' => array('香蕉'),
'description' => '此处填写'
	),
'duoshuo' => array(
		'type' => 'text',
		'name' => '多说的域名',
		'values' => array('你的多说域名'),
'description' => '此处填写你的多说二级域名，我的就是bananau.duoshuo.com便是bananau'
	),

'QQ' => array(
		'type' => 'text',
		'name' => 'QQ',
		'values' => array('949299965'),
		),
 'weibo' => array(
		'type' => 'text',
		'name' => '微博',
		'values' => array('http://weibo.com/VGEasyhoon'),
'description' => '此处填写你的QQ,微博地址（或者自己修改符号）'
	),
);
