       //初始化一言
       setTimeout("getkoto()",1000);
       //加载一言
       var t;
       function getkoto(){
           var hjs = document.createElement('script');
           hjs.setAttribute('id', 'hjs');
           hjs.setAttribute('src', 'http://api.hitokoto.us/rand?encode=jsc&fun=echokoto');
           document.getElementById("hjsbox").appendChild(hjs);
           t=setTimeout("getkoto()",9000);
       }
       //输出一言
       function echokoto(result){
           var hc = eval(result);
           //$("#hitokoto").fadeTo(300,0);
           document.getElementById("hitokoto").innerHTML = hc.hitokoto;
           //$("#hitokoto").fadeTo(300,0.75);
       }