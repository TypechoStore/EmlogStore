<?php doAction('index_head'); ?> 
<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<!-- 主体文章 -->
<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>
    <div class="articleList container">
        <div class="row">
            <div class="col-md-12">
                <!--single article-->
                <div class="article">
                    <div class="articleHeader">
                        <h1 class="articleTitle"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h1>
                    </div>
                    <div class="articleBody clearfix">
                        <!--缩略图-->
                        <div class="articleThumb">
                            <a href="<?php echo $value['log_url']; ?>"><img src="<?php get_imgsrc($value['content']); ?>" alt="<?php echo $value['log_title']; ?>" class="wp-post-image"width="400" height="200"  /></a>
                        </div>
                        <!--摘要-->
                        <div class="articleFeed">
                           <?php echo subString(strip_tags($value['content']),0,150,"..."); ?>
                        </div>
                        <!--tags-->
                        <div class="articleTags">
                            <ul><?php blog_tag($value['logid']); ?></ul>
                        </div>
                    </div>
                    <div class="articleFooter clearfix">
                        <ul class="articleStatu">
                            <li><i class="fa fa-calendar"></i><?php echo gmdate('Y-n-j', $value['date']); ?></li>
                            <li><i class="fa fa-eye"></i><?php echo $value['views'];?>次浏览</li>
                            <li><a href=""><i class="fa fa-folder-o"></i><?php blog_sort($value['logid']); ?></a></li>
                        </ul>
                        <a href="<?php echo $value['log_url']; ?>" class="btn btn-readmore btn-info btn-md">阅读更多</a>
                    </div>
                </div>
                <!--single article-->
                 <!--single article-->
                </div>
        </div>
    </div>
<!--footer-->
<?php 
endforeach;
else:
?>
            <div class="nofound">
            	<h2>未找到</h2>
            	<p>抱歉，没有符合您查询条件的结果。</p>
            </div>
<?php endif;?>
    <div class="container pageNav">
        <div class="row">   
            <div class="col-md-12">
            <ul class="pagination">
<li class="page-numbers"><?php echo $page_url;?></li>
</ul>
            </div>
        </div>
    </div>

<?php
 include View::getView('footer');
?>