<?php
/*
Template Name:Jiao
Description:移植Wordpress主题
Version:1.2
Author:香蕉
Author Url:http://www.bananau.com
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="zh-CN">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
     <title><?php echo $site_title; ?></title>
    <meta name="HandheldFriendly" content="True" /> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="<?php echo TEMPLATE_URL; ?>/images/bananau.jpg">
    <link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.3/css/font-awesome.min.css">  
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo TEMPLATE_URL; ?>main.css"/>

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	  <script src="http://cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	  <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
	<![endif]-->
	<meta name="keywords" content="<?php echo $site_key; ?>" />
	<meta name="description" content="<?php echo $bloginfo; ?>" />
</head>

<!-- head结束 -->
<body>
<!-- banner -->
<div class="banner" style="background: url(<?php echo _g('topimg');?>);">
	<!-- 菜单按钮 -->
	<div class="menu menuicon hidden-xs">
		<i class="fa fa-bars"></i>
	</div>
	<!-- header -->
	<div class="header container">
		<!--个人信息-->
		<div class="row">
			<div class="col-md-12">
				<div class="personInfo">
					<div class="logo">
					  <a href="<?php echo BLOG_URL; ?>"><img src="<?php echo _g('banana');?>" alt="logo"></a>

					</div>
					<div class="logoTheme">
						<h1><?php echo _g('name');?></h1>
						<h3> <!-- <p href="javascript:;" onclick="getkoto();" title="换一条"><span class="hitokoto" id="hitokoto">Loading...</span></p> --> 难 難しい nán hard 어렵다 Difficile ยาก</h3>
					</div>
					<div id="hjsbox"></div>
				</div>				
			</div>
		</div>
	</div> 
</div>
