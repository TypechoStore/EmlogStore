<?php doAction('index_head'); ?> 
<?php 

/**
 * 微语部分
 */

if(!defined('EMLOG_ROOT')) {exit('error!');} 

?>
<!-- 时间轴-->
    <?php 

    foreach($tws as $val):

    $author = $user_cache[$val['author']]['name'];

    $avatar = empty($user_cache[$val['author']]['avatar']) ? 

                BLOG_URL . 'admin/views/images/avatar.jpg' : 

                BLOG_URL . $user_cache[$val['author']]['avatar'];

    $tid = (int)$val['id'];

    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';

    ?> 
<!-- 微语 -->
<div>
  <link rel="stylesheet" type="text/css" media="all" href="<?php echo TEMPLATE_URL; ?>time.css"/>
  <div class="timeline animated">
      <div class="timeline-row">
        <div class="timeline-time">
          <small style="color:#000">时间</small><?php echo $val['date'];?>
        </div>
        <div class="timeline-icon">
          <div class="bg-primary">
            <i class="fa fa-pencil"></i>
          </div>
        </div>
        <div class="panel timeline-content">
          <div class="panel-body">
            <h2>
              <?php echo _g('name');?>:
            </h2>
            <p style="font-size:20px;width:75%;">
             <?php echo $val['t'].'<br/>'.$img;?>
            </p>
          </div>
</div></div></div>

<?php endforeach;?> 

<?php
 include View::getView('footer');
?>