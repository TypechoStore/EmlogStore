<!-- 多说公共JS代码 start (一个网页只需插入一次) -->
<script type="text/javascript">
var duoshuoQuery = {short_name:"<?php echo _g('duoshuo');?>"};
	(function() {
		var ds = document.createElement('script');
		ds.type = 'text/javascript';ds.async = true;
		ds.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') + '//static.duoshuo.com/embed.js';
		ds.charset = 'UTF-8';
		(document.getElementsByTagName('head')[0] 
		 || document.getElementsByTagName('body')[0]).appendChild(ds);
	})();
</script>
<!-- 多说公共JS代码 end -->
<?php //emlog调用所有分类名称、发布文章数和描述的方法
function sysort(){
global $CACHE;
$sort_cache = $CACHE->readCache('sort');
foreach($sort_cache as $value){?>
<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname'];?>(<?php echo $value['lognum'] ?>)</a> <?php echo strtoupper($value['alias']);?> <?php echo $value['description'];?>
<?php }}?>
<footer>
	<div class="main-footer">
	    <div class="container">
	        <div class="row footrow">
	        	<div class="col-md-3">
	                <div class="widget catebox">
	                    <h4 class="title">分类目录</h4>
	                    <div class="box category clearfix">
				<li class="cat-item cat-item-1"><?php echo sysort();?></li>
								
			</div>
	                </div>
	            </div>

		<div class="col-md-4">
	                <div class="widget tagbox">
	                    <h4 class="title">归档</h4>
	                    <div class="box tags clearfix">
			<ul class="post_tags"><li><?php widget_archive('');?></li></ul>
			</div>
		    </div>
		</div>

		 <div class="col-md-3">
           			 <div class="widget linkbox">
                				<h4 class="title">友情链接</h4>
                				<div class="box friend-links clearfix">
                				<li><?php widget_link();?></li>
				  	<li><a href="http://www.bananau.com" target="_blank">香蕉</a></li>
				  	<li><a href="http://vinceok.com/" target="_blank">醉清风</a></li>
				  	<!-- 请不要删除友链！ 谢谢配合-->
				  	</div>
			</div>
		</div>

		<div class="col-md-2">
	                <div class="widget contactbox">
	                    <h4 class="title">联系我们</h4>
	                    <div class="contact-us clearfix">
				<li><a href="tencent://message/?uin=<?php echo _g('QQ');?>&Site=<?php echo BLOG_URL; ?>&Meu=yes">
				<i class="fa fa-qq"></i><?php echo _g('QQ');?></a></li>
				<li><a href="<?php echo _g('weibo');?>"><i class="fa fa-weibo"></i>博主的微博</a></li>
							<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1259246503'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s4.cnzz.com/stat.php%3Fid%3D1259246503%26show%3Dpic1' type='text/javascript'%3E%3C/script%3E"));</script>
			</div>
	                </div>
	            </div>
	        </div>
	        <div class="row">
	        	<div class="copyright">
	        		<span>Copyright &copy; By<a href="http://www.bananau.com" target="_blank">香蕉</a>&nbsp;&nbsp;</span>
	        		<span>Design by <a href="http://vinceok.com/" target="_blank">醉清风</a></span>
	        		<a href="tencent://message/?uin=<?php echo _g('QQ');?>&Site=<?php echo BLOG_URL; ?>&Meu=yes" class="kefu pull-right hidden-xs"><i class="fa fa-qq"></i>在线联系我</a>
	        	</div>
	        </div>
	    </div>
	</div>
</footer>	


<!-- 菜单&侧边栏按钮 -->
<div class="menu mobile-menuicon hidden-lg hidden-md hidden-sm">
	<i class="fa fa-bars"></i>
</div>
<a class="to-top">
	<span class="topicon"><i class="fa fa-angle-up"></i></span>
	<span class="toptext">Top</span>
</a>
<div class="menubox">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<ul id="menu-menu" class="icon-list"><li id="menu-item-170" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-170"><?php blog_navi();?></li></ul>
				</div>
		</div>
	</div>
	<a href="javascript:;" class="menu-close">&times;</a>
</div>


</body>
   	<script src="http://cdn.bootcss.com/jquery/2.1.1/jquery.min.js"></script>
	<script src="<?php echo TEMPLATE_URL; ?>js/jquery.toTop.min.js"></script>
	<script src="<?php echo TEMPLATE_URL; ?>js/menu.js"></script>
	<script src="<?php echo TEMPLATE_URL; ?>js/main.js"></script>
<!-- 	<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/api.js"></script> -->
	
	<script>
		$('.to-top').toTop({
			position:false,
			offset:1000,
		});
	</script>
</html>