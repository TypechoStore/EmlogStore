<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div class="both"></div>
<footer>
<span>© <a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>版权所有"><?php echo $blogname; ?></a></span><br/><a href="http://hmoe.me" title="Theme by 魔法基佬MKⅡ">搞基部</a> <a href="http://www.emlog.net"  title="Powered by EMLOG <?php echo Option::EMLOG_VERSION;?>" target="_blank">EMLOG</a><?php echo $footer_info; ?><a href="http://www.miibeian.gov.cn" target="_blank"  rel="nofollow"><?php echo $icp; ?></a> <a id="go-top" href="#">Back to top</a>
</footer>
<?php if(isset($ckmail) && empty($ckmail)): ?>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/realgravatar.js"></script>
<?php endif; ?>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js"></script> 
<script src="<?php echo TEMPLATE_URL; ?>js/script.js"></script> 
<script src="<?php echo TEMPLATE_URL; ?>phZoom/phzoom.js"></script> 
<script src="<?php echo TEMPLATE_URL; ?>js/lazyload.js"></script>
<script>jQuery(document).ready(function($){if(navigator.platform=="iPad")return;jQuery("img").lazyload({effect:"fadeIn",placeholder:"<?php echo TEMPLATE_URL; ?>images/grey.gif"})});</script>
<?php doAction('index_footer'); ?>
<noscript>
</body>
</noscript>
</html>