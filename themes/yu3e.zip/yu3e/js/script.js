// JavaScript Document
jQuery(document).ready(function($) {
	$(window).scroll(function() {
		if ($(window).scrollTop() > 200) {
			$("#go-top").fadeIn()
		} else {
			$("#go-top").fadeOut()
		}
	});
	$body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body');
	$('#go-top').click(function() {
		$body.animate({
			scrollTop: $('#home').offset().top
		},
		400);
		return false
	});
	$(function() {
		$('#no').click(function(e) {
			e.preventDefault();
			var htm = '给力加载中',
			t = $(this).html(htm).unbind('click'),
			i = 9;
			ct();
			window.location = this.href;
			function ct() { (i < 0) ? (i = 9, t.html(htm), ct()) : (t[0].innerHTML += '.', i--, setTimeout(ct, 200))
			}
		})
	});
	$("a[href$=jpg],a[href$=gif],a[href$=png],a[href$=jpeg],a[href$=bmp]").phzoom({});
	$("#to_author_info a").toggle(function() {
		$("#profile_input").slideDown(200);
		$(this).text(" Complete ")
	},
	function() {
		$("#profile_input").slideUp(200);
		$(this).text(" Modify ")
	})
	 // Ajax评论
   $("#commentform").submit(function(){
	var q = $("#commentform").serialize();
	$("#comment").attr("disabled","disabled");
	$("#loading").show();
	$.post($("#commentform").attr("action"),q,function(d){
		var reg = /<div class=\"main\">[\r\n]*<p>(.*?)<\/p>/i;
		if(reg.test(d)){
			$("#error").html(d.match(reg)[1]);
			$("#loading").hide();
		}else{
			var p = $("input[name=pid]").val();
			cancelReply();
			$("[name=comment]").val("");
			$("#comment_list").html($(d).find("#comment_list").html());
			if(p != 0) {
				var body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body');
				body.animate({scrollTop: $("#comment-" + p).offset().top - 20},	"normal",function() {$("#loading").hide();});
			} else {
				var body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body');
				body.animate({scrollTop: $("#comment_list").offset().top - 20},	"normal",function() {$("#loading").hide();});
			}
		}
		$("#comment").attr("disabled",false);
	});
	return false;	})   
	$(document).keypress(function(e){
	if(e.ctrlKey && e.which == 13 || e.which == 10) {
	$("#commentform").submit();
	} else if (e.shiftKey && e.which==13 || e.which == 10) {
	$("#commentform").submit();//#commentform是发表评论表单form的ID
	 }
	})	
})(jQuery);