<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="content">
			<div class="border-left"><div class="border-right"><div class="border-bot">
				<div class="border-left02"><div class="border-right02">
				<div class="corner-left-bot"><div class="corner-right-bot">
				
					<div class="border-left"><div class="border-right"><div class="border-top"><div class="border-bot">
						<div class="corner-left-top"><div class="corner-right-top"><div class="corner-left-bot"><div class="corner-right-bot">
						<div class="column-left">	
			<?php include ('side.php');?> 
					</div>
                        <div class="column-center">					
					<div class="navigation">				
						<div class="clear"></div><br>
					</div>	
					<div class="post">
						<div class="indent bgnone">
							<div class="title png">							<h2><?php echo $log_title; ?></h2>
								<div class="date"></div>
			
						
									
							</div>
							
							<div class="text-box">
								
					<p><?php echo $log_content; ?></p>							
							 
					
 
			<div class="postmetadata alt">
			
	                         	 
                               					
			<?php blog_comments($comments); ?>
      <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>                              	 
                                	
	<div id="respond">
			    		
		<div class="navigation">
			<div class="alignleft"></div>
			<div class="alignright"></div>
			<div class="clear"></div>
		</div><br>
					</div>						
						</div>
  
			 </div></div></div>
					</div></div></div></div>
			
				</div></div>
				</div></div>
			</div></div></div>
		</div>
 
					
	 

	<div style="clear:both;"></div>
</div><!--end #contentleft-->
<?php
 include View::getView('footer');
?>