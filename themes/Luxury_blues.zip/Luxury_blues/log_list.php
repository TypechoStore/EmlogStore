<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="content">
			<div class="border-left"><div class="border-right"><div class="border-bot">
				<div class="border-left02"><div class="border-right02">
				<div class="corner-left-bot"><div class="corner-right-bot">
				
					<div class="border-left"><div class="border-right"><div class="border-top"><div class="border-bot">
						<div class="corner-left-top"><div class="corner-right-top"><div class="corner-left-bot"><div class="corner-right-bot">
						<div class="column-left">	
			<?php include ('side.php');?> 
					</div>
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>					​
 
<div class="column-center">
 
    	<div class="post-6 post hentry category-consectetuer category-fusce-suscipit category-lorem-ipsum-dolor category-praesent-vestibulum" id="post-6">

					<div class="indent">
						<div class="title png">							
							<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><font><font><?php echo $value['log_title']; ?></font></font></a></h2>						
							<div class="date"><font><font><?php blog_sort($value['logid']); ?> </font></font></a><font><font> |作者：<?php blog_author($value['author']); ?>|发布时间：<?php echo gmdate('Y-n-j G:i', $value['date']); ?>|被围观<?php echo $value['views']; ?>次<?php editflg($value['logid'],$value['author']); ?></font></font></div>
						</div>
					
						<div class="text-box">
							<p><font><font><?php echo $value['log_description']; ?></font></font></a></p>						</div>	
						<a href="<?php echo $value['log_url']; ?>#comments"><font><font><?php echo $value['comnum']; ?>条评论</font></font></a>
					<br /><br /><?php blog_tag($value['logid']); ?> 
									
						<div class="link-edit"></div>
					
					</div>
				</div>

				 
		<?php endforeach; ?><ol class="pages clearfix">
            <li class="current"><?php echo $page_url;?>
						 </a></li>    </ol>
        
						</div></div></div></div>
					</div></div> </div></div>
			</div></div></div></div>
				</div>			 </div></div></div></div>
				</div></div>
			</div></div></div>		 
		</div></div></div></div>
						
<?php 
 include View::getView('footer');
?>