<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="content">
			<div class="border-left"><div class="border-right"><div class="border-bot">
				<div class="border-left02"><div class="border-right02">
				<div class="corner-left-bot"><div class="corner-right-bot">
				
					<div class="border-left"><div class="border-right"><div class="border-top"><div class="border-bot">
						<div class="corner-left-top"><div class="corner-right-top"><div class="corner-left-bot"><div class="corner-right-bot">
						<div class="column-left">	
			<?php include ('side.php');?> 
					</div>


                        <div class="column-center">

									
					<div class="navigation">
					<?php neighbor_log($neighborLog); ?>
						<div class="clear"></div><br>
					
					
					<div class="post-4 post hentry category-aenean-nonummy category-consectetuer category-fusce-suscipit category-hendrerit-mauris category-praesent-vestibulum" id="post-4">
						
						
						<div class="indent bgnone">
						 
								
								<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
								<div class="date"></div>
								<div class="author"><?php blog_sort($logid); ?> | 作者：<?php blog_author($author); ?> | 发布时间：<?php echo gmdate('Y-n-j G:i', $date); ?>  <?php editflg($logid,$author); ?></div>
						
									
						
								 
							
							<div class="text-box">
								
					<p><?php echo $log_content; ?></p>							
							 
					 	<div class="title png">
								 
								<p class="att"><?php blog_att($logid); ?></p>
 
								<div class="postmetadata"><?php blog_tag($logid); ?></div>
									
								<div class="postmetadata alt">
									 
									
                               <?php blog_trackback($tb, $tb_url, $allow_tb); ?>
                               	 
                               					
			<?php blog_comments($comments); ?>
      <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>                              	 
                                	
	<div id="respond">
			    		
		<div class="navigation">
			<div class="alignleft"></div>
			<div class="alignright"></div>
			<div class="clear"></div>
		</div><br>
					</div>						
						</div>
  
			 </div></div></div>
					</div></div></div></div>
			
				</div></div>
				</div></div>
			</div></div></div>
		</div>
 
					
	 

	<div style="clear:both;"></div>
</div><!--end #contentleft-->
<?php
 include View::getView('footer');
?>