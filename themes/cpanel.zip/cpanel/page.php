<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="contentleft">
<div class="cpanel_index_list">
	<h2><?php echo $log_title; ?></h2>
	<div class="cpanel_box"><?php echo $log_content; ?></div></div>
<div class="cpanel_index_list">	<?php blog_comments($comments); ?><h2>发表评论</h2>
	<div class="cpanel_box"><?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div></div>
</div></div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>