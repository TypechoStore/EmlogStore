<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div id="contentleft">
<div class="cpanel_index_list">
	<h2><?php topflg($top); ?><?php echo $log_title; ?></h2>
	<div class="cpanel_box"><p class="date">作者：<?php blog_author($author); ?> 发布于：<?php echo gmdate('Y-n-j G:i l', $date); ?> 
	<?php blog_sort($logid); ?> <?php editflg($logid,$author); ?>
	</p>
	<?php echo $log_content; ?>
	<p class="tag"><?php blog_tag($logid); ?></p>
	<?php doAction('log_related', $logData); ?>
	<div class="nextlog"><?php neighbor_log($neighborLog); ?></div></div>
	<?php blog_trackback($tb, $tb_url, $allow_tb); ?></div>
<div class="cpanel_index_list"><?php blog_comments($comments); ?><h2>发表评论</h2>
	<div class="cpanel_box"><?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div></div>
</div></div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>