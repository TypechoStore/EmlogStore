<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="wrap">
		<div id="main">
		<?php doAction('index_loglist_top'); ?>
		<?php foreach($logs as $value): ?>
		<?///如果不喜欢太花的话，可以去掉下面的 blog_sortpd($value['logid']); 这段PHP代码，换上你喜欢的样式，目前有几个样式选择：igo，okada,oku,so,yamada和yuji?>
				<div class="entry <?php blog_sortpd($value['logid']); ?>" id="post-<?php echo $value['logid']; ?>">
					<p class="date"><span> <?php topflg($value['top']); ?> <?php echo gmdate('Y年 第W周'); ?> </span><?php echo gmdate('m月d日 H:s l', $value['date']); ?></p>
					<div class="article"><div class="initial">
						<h2><a href="<?php echo $value['log_url']; ?>" title="点击进入阅读《<?php echo $value['log_title']; ?>》全文"><?php echo $value['log_title']; ?></a></h2>
						<div class="txt">
							<?php echo $value['log_description']; ?>
						</div>
						<dl class="tags">
						<dt style="background:url(<?echo TEMPLATE_URL;?>img/fl.gif) no-repeat;">分类 = </dt><?php blog_sort($value['logid']); ?>
						<dt style="margin-left:20px;">TAG =</dt>
						<?php blog_tag($value['logid']); ?> 
						</dl>
						<ul class="state">
							<li class="st01"><a href="<?php echo $value['log_url']; ?>" title="本篇日志固定链接：<br><?php echo $value['log_url']; ?>">固定链接</a></li>
							<li class="st02"><a href="<?php echo $value['log_url']; ?>#comments" title="目前该日志有<?php echo $value['views']; ?>人看过<br><?if($value['comnum']=='0'): ?>可惜没人说过什么<? else: ?>并且留下了<?php echo $value['comnum']; ?>条消息<?endif?>">评论</a><span></span>(<?php echo $value['comnum']; ?>)</li>
							<!-- 引用数 暂不启用
							<li class="st03"><a href="<?php echo $value['log_url']; ?>#trackbacksttl"></a><span><img src="./img/numimg.cgi?0"></span></li>
							-->
						</ul>
					</div></div><!--article,initial end-->
				</div><!--entry yuji end-->
				<hr />
		<?php endforeach; ?>
	</div>
<?php include View::getView('side');?>
	<div id="footer">
		<ul id="pagenum">
			<p style="margin-left:160px;"><?php echo $page_url;?> </p>
		</ul>
<?php  include View::getView('homefooter');?>