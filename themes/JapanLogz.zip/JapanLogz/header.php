<?php
/*
Template Name::Japan Log theme
Description:来自日本情结的主题，比较适合个人博客 from blog.9ye.jp by qzz for emlog
Version:1.2
Author:qzz
Author Url:http://blog.qzee.net/
Sidebar Amount:1
ForEmlog:4.1.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
$class=$_GET[sort]; 
$class.=$sortid;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $blogtitle; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link type="text/css" rel="stylesheet"  href="<?php echo TEMPLATE_URL; ?>css/css.css" />
<script type="text/javascript" charset="shift_jis" src="<?php echo TEMPLATE_URL; ?>css/negojs.cgi"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
<link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>css/jQuery.niceTitle.css" />
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>css/jQuery.niceTitle.js"></script>
<script type="text/javascript">
jQuery(document).ready(function(){
jQuery('#tab-title span').click(function(){
	jQuery(this).addClass("selected").siblings().removeClass();
	jQuery("#tab-content > ul").slideUp('1500').eq(jQuery('#tab-title span').index(this)).slideDown('1500');
});
});
$(document).ready(function() {
$('h2 a').click(function(){
myloadoriginal = this.text;
$(this).text('加载中，请稍候...');
var myload = this;
setTimeout(function() { $(myload).text(myloadoriginal); }, 2012);
});
});
$(document).ready(function(){
	$("a, input, img").niceTitle({showLink: false});
		//要排除一些例外的元素，例如可以用a:not([class='nono'])来排除calss为"nono"的a元素
});
</script>
</head>
<body>
	<div id="header">
		<h1><a href="<?php echo BLOG_URL; ?>"><?php echo $blogtitle; ?></a></h1>
		<span class="<?php echo $curpage == CURPAGE_HOME ? 'current' : 'common';?>"><a href="<?php echo BLOG_URL; ?>" title="<?echo $description?>">首页</a></span>
	<?php 
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	foreach ($navi_cache as $key => $val):
	if ($val['hide'] == 'y'){continue;}
	if (empty($val['url'])){$val['url'] = Url::log($key);}
	$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
	?>
	<span class="<?php echo isset($logid) && $key == $logid ? 'current' : 'commonbb';?>"><a href="<?php echo $val['url']; ?>" <?php echo $newtab; ?> title="<?php echo $val['naviname']; ?>"><?php echo $val['naviname']; ?></a></span>
	<?php endforeach;?>
	<?php doAction('navbar', '<span class="common">', '</span>'); ?>
	<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
	<span class="common"><a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a></span>
	<span class="common"><a href="<?php echo BLOG_URL; ?>admin/">管理中心</a></span>
	<span class="common"><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></span>
	<?php else: ?>
	<span class="commonbb"><a href="<?php echo BLOG_URL; ?>manage/">登录</a></span>
	<?php endif; ?>
		<ul>
			<li id="rss"><a href="<?php echo BLOG_URL; ?>rss.php">RSS</a></li>
			<li id="inc"><a href="http://blog.qzee.net/">qzlog</a></li><!--请改为自己的网站-->
		</ul>
	</div>
	<hr />