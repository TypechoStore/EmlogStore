<?php 
/*
* 侧边栏
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="side">
			<h5>[博客前传]</h5>
			<dl>
				<dt id="add">about blog:</dt>
				<dd id="add01">我主要在这记录一些自己的心 得和一些分享,希望大家能喜 欢本博内容.也同时欢迎大家 在留言簿给出建议.</dd>
				<dt id="tel">contact:</dt>
				<dd id="telno">Email:qq:</dd>
			</dl>
<!--QQmail end-->
<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>
	</div><!--side end-->
</div><!--wrap end-->
<hr />