<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="wrap">
		<div id="main">
				<div class="entry coconoe" id="post-<?php echo $logid;?>">
					<p class="date"><span> <?php topflg($top); ?> <?php echo gmdate('Y年 第W周'); ?> </span><?php echo gmdate('m月d日 H:s l', $date); ?></p>
					<div class="article"><div class="initial">
						<h2><a href="<?php echo $value['log_url']; ?>" title="您正在阅读《<?php echo $log_title; ?>》全文"><?php echo $log_title; ?></a></h2>
						
						<div class="txt">
							<?php echo $log_content; ?>
						</div>
						<dl class="tags">
						<dt style="background:url(<?echo TEMPLATE_URL;?>img/fl.gif) no-repeat;">分类 = </dt><?php blog_sort($logid); ?>
						<dt style="margin-left:20px;">TAG =</dt>
						<?php blog_tag($logid); ?>
						</dl>
						
<div class="txt nopad">
	<h4 id="commentsttl">comments</h4>
	
	<div style="width:500px;margin-top:10px;">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
</div>
<h4 id="trackbacksttl">trackback</h4>
<dl id="trackbackurl">
<?php blog_trackback($tb, $tb_url, $allow_tb); ?>
</dl>
</div>
				</div>
			</div></div>
		</div>
<hr />
<?php include View::getView('side');?>
<?php include View::getView('footer');?>