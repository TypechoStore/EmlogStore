<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	<div id="footer">
		<ul>
		</ul>
		<div><div><div><address>COPYRIGHTS&copy;2007-2009 COCONOE inc.</address><?php doAction('index_footer'); ?></div></div></div>
	</div>
<div style="display:none;"><script src="http://s24.cnzz.com/stat.php?id=3618614&web_id=3618614&online=2" language="JavaScript"></script>
</div>
</body>
</html>