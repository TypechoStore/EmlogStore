<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div class="both"></div>
<footer>
<span>© 2012</span> <a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>版权所有"><?php echo $blogname; ?></a> <a href="<?php echo BLOG_URL; ?>rss.php" title="RSS订阅">rss</a> <?php echo $footer_info; ?><a href="http://www.miibeian.gov.cn" target="_blank"  rel="nofollow"><?php echo $icp; ?></a> <a href="http://www.emlog.net"  title="Powered by Emlog <?php echo Option::EMLOG_VERSION;?>">Emlog</a> <a href="http://zld.me" title="Theme by 自留地">Z3</a>
  <a href="http://www.miibeian.gov.cn" target="_blank"  rel="nofollow"><?php echo $icp; ?></a>
  <?php echo $footer_info; ?> 
</footer>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js"></script> 
<script src="<?php echo TEMPLATE_URL; ?>js/z3.js"></script> 
<script src="<?php echo TEMPLATE_URL; ?>phZoom/phzoom.js"></script> 
<script src="<?php echo TEMPLATE_URL; ?>js/top.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/lazyload.js"></script> 
<script>jQuery(document).ready(function($){if(navigator.platform=="iPad")return;jQuery("img").lazyload({effect:"fadeIn",placeholder:"<?php echo TEMPLATE_URL; ?>images/grey.gif"})});</script>
<?php doAction('index_footer'); ?>
</body>
</html>