<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="container">
        <div class="main">
            <div class="posts">
				<?php doAction('index_loglist_top'); ?>
				<div class="post-box post-text">
                    <div class="post-box-header"></div>
					<div class="post-box-container">
						<?php topflg($value['top']); ?>
						<h2 class="title"><?php echo $value['log_title']; //标题 ?></h2>
                        <div class="entry rich-content"><?php echo $log_content; ?></div>    
						<p class="att"><?php blog_att($logid); ?></p>
						<?php doAction('log_related', $logData); ?>
                            <div class="meta">
                                <a class="date" ><?php echo gmdate('Y-n-j G:i l', $date); ?> </a>
                                <a class="permalink"><?php echo $views; ?> 热度</a>
                            </div>
						<?php blog_comments($comments); ?>
						<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
                    </div>
                    <div class="post-box-footer"></div>
                </div>
			</div>
        </div>
	

<?php
 include View::getView('side');
 include View::getView('footer');
?>