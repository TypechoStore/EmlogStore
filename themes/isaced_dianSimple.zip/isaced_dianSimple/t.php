<?php 
/*
* 碎语部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="container">
        <div class="main">
            <div class="posts">
				<?php doAction('index_loglist_top'); ?>

				<?php 
					foreach($tws as $val):
						$author = $user_cache[$val['author']]['name'];
						$avatar = empty($user_cache[$val['author']]['avatar']) ? 
									BLOG_URL . 'admin/views/images/avatar.jpg' : 
									BLOG_URL . $user_cache[$val['author']]['avatar'];
						$tid = (int)$val['id'];
				?>
				<div class="post-box post-text">
                    <div class="post-box-header"></div>
					<div class="post-box-container">
                        <div class="entry rich-content"><?php echo $val['t'];?></div>                        
                            <div class="meta">
                                <a class="permalink"><?php echo $val['date'];?></a>
                            </div>
							
							
                    </div>
                    <div class="post-box-footer"></div>
                </div>
				<?php endforeach; ?>
				<div id="pagenavi"><?php echo $pageurl;?></div>
			</div>
        </div>
	

<?php
 include View::getView('side');
 include View::getView('footer');
?>