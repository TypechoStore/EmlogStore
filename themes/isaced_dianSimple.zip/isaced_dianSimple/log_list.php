<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div class="container">
        <div class="main">
            <div class="posts">
				<?php doAction('index_loglist_top'); ?>
				<?php foreach($logs as $value): ?>
				<div class="post-box post-text">
                    <div class="post-box-header"></div>
					<div class="post-box-container">
						<?php topflg($value['top']); ?>
						<h2 class="title"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; //标题 ?></a></h2>
                        <div class="entry rich-content"><?php echo $value['log_description']; ?></div>                        
                            <div class="meta">
                                <a class="date" ><?php echo gmdate('Y-n-j G:i l', $value['date']); //时间?> </a>
                                <a class="permalink"><?php echo $value['views']; //浏览量?> 热度</a>
                            </div>
                    </div>
                    <div class="post-box-footer"></div>
                </div>
				<?php endforeach; ?>
			</div>
			<div id="pagenavi">
				<?php echo $page_url;?>
			</div>
        </div>
	

<?php
 include View::getView('side');
 include View::getView('footer');
?>