<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="container">
        <div class="main">
            <div class="posts">
				<?php doAction('index_loglist_top'); ?>
				<div class="post-box post-text">
                    <div class="post-box-header"></div>
					<div class="post-box-container">
						<?php topflg($value['top']); ?>
						<h2 class="title"><?php echo $log_title; ?></h2>
                        <div class="entry rich-content"><?php echo $log_content; ?></div>    
						<p class="att"><?php blog_att($logid); ?></p>
						<?php doAction('log_related', $logData); ?>
						<?php blog_comments($comments); ?>
						<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
                    </div>
                    <div class="post-box-footer"></div>
                </div>
			</div>
        </div>
	

<?php
 include View::getView('side');
 include View::getView('footer');
?>
