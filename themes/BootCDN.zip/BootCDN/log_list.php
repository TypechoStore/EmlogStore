<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
    <!-- start site's main content area -->
    <section class="content-wrap">
        <div class="container">
            <div class="row">
                <main class="col-md-8 col-md-offset-2 main-content">
<?php doAction('index_loglist_top'); ?>

<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>                
<article id="2" class="post tag-https">
    <div class="post-head">
        <h1 class="post-title"><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h1>
        <div class="post-meta">
            <span class="author">作者：<?php blog_author($value['author']); ?></span> •	<?php blog_sort($value['logid']); ?> • 
            <time class="post-date" datetime="<?php echo gmdate('Y-n-j', $value['date']); ?> " title="<?php echo gmdate('Y-n-j', $value['date']); ?> "><?php echo gmdate('Y年n月j日', $value['date']); ?></time><?php editflg($value['logid'],$value['author']); ?>
        </div>
    </div>
    <div class="post-content">
        <p><?php echo subString(DeleteHtml(strip_tags($value['content'])),0,174); //文章简述 ?></p>
    </div>
    <div class="post-permalink">
        <a href="<?php echo $value['log_url']; ?>" class="btn btn-default">阅读全文</a>
    </div>
    <footer class="post-footer clearfix">
        <div class="pull-left tag-list">
            <i class="fa fa-folder-open-o"></i>
            <?php blog_tag($value['logid']); ?> • 浏览(<?php echo $value['views']; ?>) • 评论(<?php echo $value['comnum']; ?>)
        </div>
        <div class="pull-right share">
        </div>
    </footer>
</article>
<?php 
endforeach;
else:
?>
	<h2>未找到</h2>
	<p>抱歉，没有符合您查询条件的结果。</p>
<?php endif;?>
<div id="pagenavi"><?php echo $page_url;?></div>	
                </main>
            </div>
        </div>
    </section>
<?php
 include View::getView('footer');
?>