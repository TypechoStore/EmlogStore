<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!-- start site's main content area -->
    <section class="content-wrap">
        <div class="container">
            <div class="row">
                <main class="col-md-8 col-md-offset-2 main-content">
<article id="2" class="post tag-https">

    <header class="post-head">
        <h1 class="post-title"><?php topflg($top); ?><?php echo $log_title; ?></h1>
        <section class="post-meta"> 
            <span class="author">作者：<?php blog_author($author); ?></a></span> • <?php blog_sort($logid); ?>• 
            <time class="post-date" datetime="<?php echo gmdate('Y-n-j', $date); ?>" title="<?php echo gmdate('Y-n-j', $date); ?>"><?php echo gmdate('Y年n月j日', $date); ?></time><?php editflg($logid,$author); ?>
        </section>
    </header>

<?php echo $log_content; ?>

    <footer class="post-footer clearfix">
        <div class="pull-left tag-list">
            <i class="fa fa-folder-open-o"></i>
           <?php blog_tag($logid); ?>
        </div>
        <div class="pull-right share">
		<?php neighbor_log($neighborLog); ?>
		</div>
    </footer>
</article>
<div class="about-author clearfix">
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<?php blog_comments($comments); ?>
</div>
<div class="prev-next-wrap clearfix">
</div>
</main>
</div>
</div>
</section>
<?php
 include View::getView('footer');
?>