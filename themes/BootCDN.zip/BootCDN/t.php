<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<!-- start site's main content area -->
    <section class="content-wrap">
        <div class="container">
            <div class="row">
                <main class="col-md-8 col-md-offset-2 main-content">
<div class="about-author clearfix">

                    <div class="widget">
                        <h4 class="title">微语</h4>
    <?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?> 
                        <div class="content recent-post">
						<div class="recent-single-post"><?php echo $author; ?>:<?php echo $val['t'].'<br/>'.$img;?>
						<div class="date"><?php echo $val['date'];?></div></div></div>

				    <?php endforeach;?>		
<div id="pagenavi"><?php echo $pageurl;?></div>	
                    </div>
 
</div>
<div class="prev-next-wrap clearfix">
</div>
</main>
</div>
</div>
</section>
<?php
 include View::getView('footer');
?>