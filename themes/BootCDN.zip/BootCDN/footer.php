<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
    <footer class="main-footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <div class="widget">
                        <h4 class="title">搜索文章</h4>
                        <div class="content recent-post">
						<div class="recent-single-post">
							<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
	                        <input name="keyword" class="search" type="text" />
	                        </form>
						</div>
						<?php widget_newlog();?> 
						</div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="widget">
                        <h4 class="title">合作伙伴</h4>
                        <div class="content tag-cloud friend-links">
						<?php widget_link();?> 
                        </div>
                </div></div>
                <div class="col-sm-4">
                    <div class="widget">
                        <h4 class="title">标签云</h4>
                        <?php widget_tag();?> 
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <div class="copyright">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <span>Copyright © 2016-<?php echo $blogname; ?> |  
			 <a href="http://www.rkidc.net/?refcode=kmy28giar"  target="_blank">锐壳科技</a><?php echo $footer_info; ?></span>
                </div>
            </div>
        </div>
    </div>
    <a href="<?php echo BLOG_URL; ?>#" id="back-to-top" style="display: none;"><i class="fa fa-angle-up"></i></a>
    <script src="<?php echo TEMPLATE_URL; ?>js//jquery.min.js"></script>
    <script src="<?php echo TEMPLATE_URL; ?>js/bootstrap.min.js"></script>
    <script src="<?php echo TEMPLATE_URL; ?>js/jquery.fitvids.min.js"></script>
    <script src="<?php echo TEMPLATE_URL; ?>js/highlight.min.js"></script>
    <script src="<?php echo TEMPLATE_URL; ?>js/jquery.magnific-popup.min.js"></script>
    <script src="<?php echo TEMPLATE_URL; ?>js/main.js"></script>
    <script>
        $(function(){
            $('.post-content img').each(function(item){
                var src = $(this).attr('src');

                $(this).wrap('<a href="' + src + '" class="mfp-zoom" style="display:block;"></a>');
            });

            $('.post-content').magnificPopup({
              delegate: 'a',
              type: 'image'
            });
        });
    </script>

    <script>
        window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"24"},"share":{}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];
    </script>
<?php doAction('index_footer'); ?>
</body>
</html>