<?php
/*
Template Name:BootCDN
Description:仿BootCDN官方博客模板，简洁优雅 下载多说插件才能正常使用
Version:1.1
Author:王少凯
Author Url:http://www.kmiwz.com
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<!-- saved from url=(0023)<?php echo BLOG_URL; ?> -->
<html lang="zh-CN"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $site_title; ?></title>
    <meta name="keywords" content="<?php echo $site_key; ?>" />
    <meta name="description" content="<?php echo $site_description; ?>" />
    <meta name="generator" content="emlog" />
    <meta name="HandheldFriendly" content="True">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="<?php echo TEMPLATE_URL; ?>favicon.ico">
    <link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/monokai_sublime.min.css">
    <link href="<?php echo TEMPLATE_URL; ?>css/magnific-popup.min.css" rel="stylesheet">
	<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
    <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
    <link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />   
    <link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>screen.css">
    <script>
    /*====================================================
      THEME SETTINGS & GLOBAL VARIABLES
    ====================================================*/

    //  1. Sidebar Position
    var sidebar_left = false; // Set true or flase for positioning sidebar on left
    
    //  2. Recent Post count
    var recent_post_count = 3;
    
    </script>
<script src="<?php echo TEMPLATE_URL; ?>js/js.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/share.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/ajax_comment.js"></script>
<style id="fit-vids-style">.fluid-width-video-wrapper{width:100%;position:relative;padding:0;}.fluid-width-video-wrapper iframe,.fluid-width-video-wrapper object,.fluid-width-video-wrapper embed {position:absolute;top:0;left:0;width:100%;height:100%;}</style>
</head>
<body class="home-template">
    <!-- start header -->
    <header class="main-header" "="">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <h1><?php echo $blogname; ?></h1>
					<h4><?php echo $bloginfo; ?></h4>
                </div>
            </div>
        </div>
    </header>
    <!-- end header -->
    <!-- start navigation -->
    <nav class="main-navigation">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="navbar-header">
                        <span class="nav-toggle-button collapsed" data-toggle="collapse" data-target="#main-menu">
                        <span class="sr-only">Toggle navigation</span>
                        <i class="fa fa-bars"></i>
                        </span>
                    </div>
                    <div class="collapse navbar-collapse" id="main-menu">
					<?php blog_navi();?> 
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <!-- end navigation -->