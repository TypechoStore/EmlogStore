﻿<?php 
/*
 * @FYS
 * @authors 会飞的鱼 (www.17uw.cn)
 * @date    2018年06月19日
 * @version 2.0
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<?php
//widget：blogger
function widget_blogger($title){
 }?>
<?php
//widget：日历
function widget_calendar($title){ ?>
	<div class="widget widget_ui_calendar wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
	<div id="calendar_wrap" class="calendar_wrap">
	<h3><?php echo $title; ?></h3>
    <div id="calendar" class="f_calendar">
    </div>
	<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
	</div></div>
<?php }?>
<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
	<div class="widget widget_ui_tags wow article-categories fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
	<h3>热门标签</h3>
	<div class="items">
	<?php foreach($tag_cache as $value): ?>
		<a class="wow zoomIn" href="<?php echo Url::tag($value['tagurl']); ?>" style="visibility: visible; animation-name: zoomIn;"><?php echo $value['tagname']; ?> (<?php echo $value['usenum']; ?>)</a>
		<?php endforeach; ?>
	</div>
</div>
<?php }?>
<?php
//page-tags：标签云
function page_tags(){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
	<?php foreach($tag_cache as $value): ?>
	<li><a class="name" href="<?php echo Url::tag($value['tagurl']); ?>"><?php echo $value['tagname']; ?></a><small><?php echo $value['usenum']; ?></small></li>
	<?php endforeach; ?>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	global $arr_sortico1; 
	$sort_cache = $CACHE->readCache('sort'); 
	?>
	<div class="widget widget_ui_sort wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;"><h3 class="widget-title"><?php echo $title; ?></h3><div class="items"> <ul id="blogsort"> 

	<?php
	foreach($sort_cache as $value):
		$sid=$value["sid"];
		if ($value['pid'] != 0) continue;
	?>
		<li> <a title="<?php echo $value['lognum'] ?> 篇文章" href="<?php echo Url::sort($value['sid']); ?>"><i class="<?php if(empty($arr_sortico1[$sid])){echo "fa fa-code";}else{echo $arr_sortico1[$sid];}?>"></i> <?php echo $value['sortname']; ?></a> </li> 
	<?php endforeach; ?>
	</ul> </div> </div>
<?php }?>
<?php
//widget：最新微语 
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	?>
	<div class="widget widget_ui_comments wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;"><h3> 最新微语</h3> <ul> 
	<?php //foreach($newtws_cache as $value): ?>
		<li style="margin-left: 0px;"><a href="/t"> 
		<img class="avatar avatar-50 photo avatar-default" height="50" width="50" src="<?php global $CACHE;$user_cache = $CACHE->readCache('user');if($user_cache[1]['photo']['src']){echo BLOG_URL.$user_cache[1]['photo']['src'];}else{echo TEMPLATE_URL.'img/avatar.png';}?>" style="display: block;"><?php echo smartDate($newtws_cache[0]['date']); ?><br><?php echo comment2emoji($newtws_cache[0]['t']); ?></a></li>
	<?php //endforeach; ?>
	</ul> 
	</div>
<?php }?>
<?php
function commtent_title($gid){
 $db = MySql::getInstance();
 $sql = "SELECT title FROM ".DB_PREFIX."blog WHERE hide='n' and gid in ($gid) ORDER BY `date` DESC LIMIT 0,1";
 $list = $db->query($sql);while($row = $db->fetch_array($list)){return $row['title'];}}?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	//取前6个评论
	$com_cache_slice = array_slice($com_cache, 0,6);
	//if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
	?>
<div class="widget widget_ui_comments wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;"><h3> 最新评论</h3> <ul> 
	<?php
	foreach($com_cache_slice as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	$imgaa=getqqxx($value['mail'],'');
	$title = commtent_title($value['gid']);
			?>
	<li><a href="<?php echo $url; ?>" title="<?php echo $title." 上的评论"; ?>"><img class="avatar avatar-50 photo avatar-default" height="50" width="50" src="<?php echo $imgaa; ?>" style="display: block;" /> <strong><?php echo $value['name']; ?></strong> <?php echo sydate($value['date'],true);?> 说<br /><?php echo comment2emoji($value['content']); ?></a></li>
	<?php endforeach; ?>
</ul> </div>
<?php }?>
<?php
//widget：最新文章
function widget_newlog($title){
$index_newlognum = Option::get('index_newlognum');?>
	<div class="widget widget_ui_posts wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;"><h3><?php echo $title; ?></h3><ul>
<?php 
$db = MySql::getInstance();
$sql = $db->query ("SELECT * FROM ".DB_PREFIX."blog inner join ".DB_PREFIX."sort WHERE hide='n' AND type='blog' AND top='n' AND sortid=sid order by date DESC limit 0,$index_newlognum"); 

while($row = $db->fetch_array($sql)){
	if($module_thum==0){
		$imgsrc = GetThumFromContent($row['content']);
	}else{
		$imgsrc = get_thum($row['gid']);
	}
?>
	<li><a href="<?php echo Url::log($row['gid']);?>"><span class="thumbnail"><img class="thumb" src="<?php echo $imgsrc;?>" style="display: block;"></span><span class="text"><?php echo $row['title'];?></span><i class="fa fa-clock-o fa-fw"></i><span class="muted"><?php echo gmdate('Y-m-d', $row['date']);?></span></a></li>
	<?php }?>
</ul></div>
<?php }?>
<?php
//widget：热门文章
function widget_hotlog($title){
	$db = MySql::getInstance();
	$hot_num = Option::get('index_hotlognum');
	?>
	<div class="widget widget_ui_posts wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
	<h3>热门文章</h3>
	<ul>
	<?php
	$sql = "SELECT gid,title,views,comnum,date,content FROM ".DB_PREFIX."blog inner join ".DB_PREFIX."sort WHERE hide='n' AND type='blog' AND date > $time - 30*24*60*60 AND top='n' AND sortid=sid order by `views` DESC limit $hot_num";
	$list = $db->query($sql);
	while($row = $db->fetch_array($list)){
		if($module_thum==0){
			$imgsrc = GetThumFromContent($row['content']);
		}else{
			$imgsrc = get_thum($row['gid']);
		}
	?> 	
		<li class="wow zoomIn" style="visibility: visible; animation-name: zoomIn;"><a href="<?php echo Url::log($row['gid']);?>"><span class="thumbnail"><img data-src="<?php echo $imgsrc;?>" alt="<?php echo $row['title'];?>" src="<?php echo $imgsrc;?>" class="thumb" style="display: block;"></span><span class="text"><?php echo $row['title'];?></span><span class="muted"><?php echo gmdate('Y-m-d', $row['date']);?></span><span class="muted">评论(<?php echo $row['comnum'];?>)</span></a></li>
	<?php }?>
	</ul>
</div>
<?php }?>
<?php
//widget：随机文章
function widget_random_log($title){
	$db = MySql::getInstance();
	$sj_num = Option::get('index_randlognum');
	?>
	<div class="widget widget_ui_posts widget_fix wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;"><h3>猜你喜欢</h3><ul>
<?php
	$sql = "SELECT gid,title,date,views,content FROM ".DB_PREFIX."blog ORDER BY RAND() LIMIT $sj_num";
	$list = $db->query($sql);
	while($row = $db->fetch_array($list)){
		if($module_thum=="0"){
			$imgsrc = GetThumFromContent($row['content']);
		}else{
			$imgsrc = get_thum($row['gid']);
		}
	?> 	
	<li><a href="<?php echo Url::log($row['gid']);?>"><span class="thumbnail"><img  class="thumb" src="<?php echo $imgsrc;?>" style="display: block;"></span><span class="text"><?php echo $row['title'];?></span><i class="fa fa-clock-o fa-fw"></i><span class="muted"><?php echo gmdate('Y-m-d', $row['date']);?></span></a></li>
	<?php }?>
</ul></div>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
	<div class="widget widget_ui_tags wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;"><h3><?php echo $title; ?>云</h3><div class="items">
	<?php foreach($record_cache as $value): ?>
	<a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?> (<?php echo $value['lognum']; ?>)</a>
	<?php endforeach; ?>
	</div>
	</div>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
<div class="widget widget_ui_textasb wow fadeInUp" style="visibility: visible; animation-name: fadeInUp; top: 0px;"><a class="style05" href="#" target="_blank"><strong><?php echo $title; ?></strong><?php echo $content; ?></a></div>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
    //if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
	?>
	<div class="widget widget_links wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;"> <h3> 友情链接</h3><ul>
	<?php foreach($link_cache as $value): ?>
	<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><i class="fa fa-link fa-fw"></i><?php echo $value['link']; ?></a></li>  
	<?php endforeach; ?></ul>
 </div>
<?php }?>
<?php
//blog：导航
function blog_navi(){
    global $CACHE;
	global $Tconfig;
    $navi_cache = $CACHE->readCache('navi');
            foreach($navi_cache as $value):
            $id=$value["id"];
            if ($value['pid'] != 0) {
                continue;
            }
            $newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
            $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
			$current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'active' : '';
            ?>
		<li id="menu-item" class="<?php if (!empty($value['children']) || !empty($value['childnavi'])) :?>menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item<?php endif;?><?php echo $current_tab;?>" >
                <a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>>
				<?php if(empty($Tconfig['arr_navico'][$id])) {echo $value['naviname'];}else {echo "<i class='".$Tconfig['arr_navico'][$id]."'></i> ".$value['naviname']."";} ?>
				<?php if (!empty($value['children']) || !empty($value['childnavi'])) :?>
				<?php endif;?>                
				</a>
				<?php if (!empty($value['children'])) :?>
                <ul class="sub-menu">
                    <?php foreach ($value['children'] as $row){
                            echo '<li id="menu-item" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item"><a href="'.Url::sort($row['sid']).'"><i class="'.$Tconfig['arr_sortico'][$row['sid']].'"></i> '.$row['sortname'].'</a></li>';
                    }?>
                </ul>
                <?php endif;?>
                <?php if (!empty($value['childnavi'])) :?>
                <ul class="sub-menu">
                    <?php foreach ($value['childnavi'] as $row){
                            $newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';
                            echo '<li id="menu-item" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item"><a href="' . $row['url'] . "\" $newtab >" . $row['naviname'].'</a></li>';
                    }?>
                </ul>
                <?php endif;?>
            </li>
            <?php endforeach; ?>
<?php }?>
<?php
//blog：置顶
function topflg($top, $sortop='n', $sortid=null){
    if(blog_tool_ishome()) {
       echo $top == 'y' ? "<img src=\"".TEMPLATE_URL."/images/top.png\" title=\"首页置顶文章\" /> " : '';
    } elseif($sortid){
       echo $sortop == 'y' ? "<img src=\"".TEMPLATE_URL."/images/sortop.png\" title=\"分类置顶文章\" /> " : '';
    }
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
    <a class="cat" href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
	<?php endif;?>
<?php }?>
<?php
//blog：面包屑导航
function mianbao_sort($blogid,$log_title){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<div class="mbx">
	<a href="<?php echo BLOG_URL; ?>">首页</a> » <?php if(!empty($log_cache_sort[$blogid])): ?><a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a><?php else:?><a href="#">未分类</a><?php endif;?> » <?php echo $log_title; ?>
</div>
<?php }?>
<?php
//blog：文章标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '标签:';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "	<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
		}
		echo $tag;
	}
}
?>
<?php
//blog：文章作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog):?>
	    <li class="previous">
		<a title="<?php echo $prevLog['title'];?>" href="<?php echo Url::log($prevLog['gid']) ?>">上一篇：<?php echo $prevLog['title'];?></a>
		</li>
	<?php endif;?>
	<?php if($nextLog && $prevLog):?>
	<?php endif;?>
	<?php if($nextLog):?>
	<li class="next">		
	<a title="<?php echo $nextLog['title'];?>" href="<?php echo Url::log($nextLog['gid']) ?>">下一篇：<?php echo $nextLog['title'];?></a>
	</li>
	<?php endif;?>
<?php }?>
<?php
//blog：评论列表
function blog_comments($comments,$params){
    extract($comments);
    if($commentStacks): ?>
	<?php endif; ?>
	<?php
    $count_comments = count($comments);
    $count_floors = $count_comments;
    foreach($comments as $value){
        if($value['pid'] != 0){ $count_floors--; }
    }
    $page = isset($params[5])?intval($params[5]):1;
    $i= $count_floors - ($page - 1)*Option::get('comment_pnum');
	$isGravatar = Option::get('isgravatar');
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	global $CACHE;$user_cache = $CACHE->readCache('user');$name = $user_cache[1]['name'];
    $comment['poster'] = $comment['url'] ? '<a title="点击访问：'.$comment['url'].'" href="'.$comment['url'].'" target="_blank" rel="nofollow">'.$comment['poster'].'</a>' : $comment['poster'];
	$patterns = array ("/\[url\](.*?)\[\/url\]/","/\[qq\]([0-9]+)\[\/qq\]/","/\[img=?\]*(.*?)(\[\/img)?\]/e","/\[strong\](.*?)\[\/strong\]/","/\[em\](.*?)\[\/em\]/","/\[del\](.*?)\[\/del\]/","/\[blockquote\](.*?)\[\/blockquote\]/","/\[u\](.*?)\[\/u\]/","/\[code\](.*?)\[\/code\]/","/\[font\](.*?)\[\/font\]/","/\[font1\](.*?)\[\/font\]/","/\[font2\](.*?)\[\/font\]/","/\[font3\](.*?)\[\/font\]/","/\[font4\](.*?)\[\/font\]/","/\[font5\](.*?)\[\/font\]/","/\[font6\](.*?)\[\/font\]/","/\[font7\](.*?)\[\/font\]/","/\[font8\](.*?)\[\/font\]/","/\[font9\](.*?)\[\/font\]/","/\[font10\](.*?)\[\/font\]/","/\[font11\](.*?)\[\/font\]/","/\[font12\](.*?)\[\/font\]/","/\[font13\](.*?)\[\/font\]/","/\[font14\](.*?)\[\/font\]/","/\[font15\](.*?)\[\/font\]/","/\[font16\](.*?)\[\/font\]/","/\[font17\](.*?)\[\/font\]/",); 
	$replace = array ('<a rel="external nofollow" target="_blank" href="$1">$1 </a>','<a title="点击这里给我发消息" rel="external nofollow" target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=$1&site=qq&menu=yes"><img src="http://wpa.qq.com/pa?p=1:$1:52" alt="点击这里给我发消息" /></a>','"<a target=\"_blank\" href=\"$1\" class=\"comment-t-img-a\" data-fancybox=\"images\"><i class=\"fa fa-picture-o\" aria-hidden=\"true\"></i> 查看图片</a>"','<b>$1</b>','<em>$1</em>','<del>$1</del>','<blockquote>$1</blockquote>','<u>$1</u>','<code>$1</code>','<font color="red">$1</font>','<font color="green">$1</font>','<font color="blue">$1</font>','<font color="magenta">$1</font>','<font color="yellow">$1</font>','<font color="chocolate">$1</font>','<font color="black">$1</font>','<font color="aquamarine">$1</font>','<font color="lime">$1</font>','<font color="fuchsia">$1</font>','<font color="orange">$1</font>','<font color="thistle">$1</font>','<font color="brown">$1</font>','<font color="peru">$1</font>','<font color="deeppink">$1</font>','<font color="purple">$1</font>','<font color="slategray">$1</font>','<font color="tomato">$1</font>'); 
	$comment['content']=preg_replace($patterns, $replace, $comment['content']);
	?>
	<li class="comment even thread-even depth-1" id="comment-<?php echo $comment['cid']; ?>"><span class="comt-f">#<?php echo $i; ?></span>
<div class="comt-avatar wow zoomIn animated" style="visibility: visible; animation-name: zoomIn;">																	
<?php
			
				echo '
	<img data-src="'.getqqxx($comment['mail'],$imgavatar).'" class="avatar avatar-40 photo" width="40" height="40" alt="qq_avatar" src="'.getqqxx($comment['mail'],$imgavatar).'" style="display: block;">';
?> 
	</div>
<div class="wow zoomIn comt-main animated" id="div-comment-4285" style="visibility: visible; animation-name: zoomIn;">
	<p>
		<?php echo preg_replace("/\[F(([1-4]?[0-9])|50)\]/",'<img class="face1" alt="face" src="'.TEMPLATE_URL.'images/face/$1.png"  />',$comment['content']); ?>
	</p>
	<div class="comt-meta wow zoomIn animated" style="visibility: visible; animation-name: zoomIn;">
		<span <?php echo $ls_role;?>><?php echo $comment['poster']; ?></span> <?php if(strtotime($comment['date'])) { echo sydate($comment['date']);}else {echo str_replace(' ','',$comment['date']);} ?><a rel="nofollow" class="comment-reply-link" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)" >回复</a>
	</div>
</div>
<?php blog_comments_children($comments, $comment['children']); ?>
</li>
	<?php $i--;endforeach;?>
    <div class="page comment-page">
	    <?php echo $commentPageUrl;?>
    </div>
<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	global $CACHE;$user_cache = $CACHE->readCache('user');$name = $user_cache[1]['name'];
    $comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank" title="点击访问：'.$comment['url'].'" rel="nofollow">'.$comment['poster'].'</a>' : $comment['poster'];
	$patterns = array ("/\[url\](.*?)\[\/url\]/","/\[qq\]([0-9]+)\[\/qq\]/","/\[img=?\]*(.*?)(\[\/img)?\]/e","/\[strong\](.*?)\[\/strong\]/","/\[em\](.*?)\[\/em\]/","/\[del\](.*?)\[\/del\]/","/\[blockquote\](.*?)\[\/blockquote\]/","/\[u\](.*?)\[\/u\]/","/\[code\](.*?)\[\/code\]/","/\[font\](.*?)\[\/font\]/","/\[font1\](.*?)\[\/font\]/","/\[font2\](.*?)\[\/font\]/","/\[font3\](.*?)\[\/font\]/","/\[font4\](.*?)\[\/font\]/","/\[font5\](.*?)\[\/font\]/","/\[font6\](.*?)\[\/font\]/","/\[font7\](.*?)\[\/font\]/","/\[font8\](.*?)\[\/font\]/","/\[font9\](.*?)\[\/font\]/","/\[font10\](.*?)\[\/font\]/","/\[font11\](.*?)\[\/font\]/","/\[font12\](.*?)\[\/font\]/","/\[font13\](.*?)\[\/font\]/","/\[font14\](.*?)\[\/font\]/","/\[font15\](.*?)\[\/font\]/","/\[font16\](.*?)\[\/font\]/","/\[font17\](.*?)\[\/font\]/",); 
	$replace = array ('<a rel="external nofollow" target="_blank" href="$1">$1 </a>','<a title="点击这里给我发消息" rel="external nofollow" target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=$1&site=qq&menu=yes"><img src="http://wpa.qq.com/pa?p=1:$1:52" alt="点击这里给我发消息" /></a>','"<a target=\"_blank\" href=\"$1\" class=\"comment-t-img-a\" data-fancybox=\"images\"><i class=\"fa fa-picture-o\" aria-hidden=\"true\"></i> 查看图片</a>"','<b>$1</b>','<em>$1</em>','<del>$1</del>','<blockquote>$1</blockquote>','<u>$1</u>','<code>$1</code>','<font color="red">$1</font>','<font color="green">$1</font>','<font color="blue">$1</font>','<font color="magenta">$1</font>','<font color="yellow">$1</font>','<font color="chocolate">$1</font>','<font color="black">$1</font>','<font color="aquamarine">$1</font>','<font color="lime">$1</font>','<font color="fuchsia">$1</font>','<font color="orange">$1</font>','<font color="thistle">$1</font>','<font color="brown">$1</font>','<font color="peru">$1</font>','<font color="deeppink">$1</font>','<font color="purple">$1</font>','<font color="slategray">$1</font>','<font color="tomato">$1</font>'); 
	$comment['content']=preg_replace($patterns, $replace, $comment['content']);
	?>
	<ul class="children">
	<li class="comment byuser comment-author-2416359384 even depth-2" id="comment-<?php echo $comment['cid']; ?>">
	<?php
				echo '
	<div class="comt-avatar wow zoomIn animated" style="visibility: visible; animation-name: zoomIn;">
		<img data-src="'.getqqxx($comment['mail'],$imgavatar).'" class="avatar avatar-100" height="50" width="50" src="'.getqqxx($comment['mail'],$imgavatar).'" style="display: block;">
    </div>';
	?> 
	<div class="wow zoomIn comt-main animated" id="div-comment-93" style="visibility: visible; animation-name: zoomIn;">
		<p>
			<?php echo comment2emoji($comment['content']); ?>
		</p>
		<div class="comt-meta wow zoomIn animated" style="visibility: visible; animation-name: zoomIn;">
			<span <?php echo $ls_role;?>><?php echo $comment['poster']; ?></span> <?php if(strtotime($comment['date'])) { echo sydate($comment['date']);}else {echo str_replace(' ','',$comment['date']);} ?><?php if($comment['level']<3){ echo '<a rel="nofollow" class="comment-reply-link" href="#comment-'.$comment['cid'].'" onclick="commentReply('.$comment['cid'].',this)">回复</a>';}?>
		</div>
	</div>
	<?php blog_comments_children($comments, $comment['children']);?>
	</li>
	<!-- #comment-## -->
</ul>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
<!--	<form action="--><?php //echo BLOG_URL; ?><!--index.php?action=addcom" method="post" id="commentform0">-->
        <form id="commentform" onsubmit="return false;">
	        <input type="hidden" name="gid" id="comment-gid" value="<?php echo $logid; ?>" />
			<input type="hidden" name="pid" id="comment-pid" value="0"/>
		<div class="comt">
			<div class="comt-title">
			<?php if(!islogin()){ ?>
				<?php 
							if(ROLE==ROLE_VISITOR) {
								echo '<span class="comment_avator"><img id="toux" src="'.TEMPLATE_URL.'img/avatar.png" title="路过的萌新~" class="avatar avatar-100"><em class="commentUser_type none_user" title="路过的萌新~">游客</em></span>';
							}else{
								global $userData;
								$imgavatar = empty($user_cache[$k]['avatar']) ? 
								BLOG_URL . 'admin/views/img/avatar.png' : 
								BLOG_URL . $user_cache[$k]['avatar'];
								echo '<span class="comment_avator"><img id="toux" src="'.getqqxx($userData["mail"],$imgavatar).'" title="'.$userData["nickname"].'"><em>'.$userData["nickname"].'</em></span>';
							}
				?>
			<?php }else{ ?>
				<img data-src="<?php global $CACHE;$user_cache = $CACHE->readCache('user');if($user_cache[1]['photo']['src']){echo BLOG_URL.$user_cache[1]['photo']['src'];}else{echo TEMPLATE_URL.'img/avatar.png';}?>" class="avatar avatar-100" height="50" width="50" src="<?php global $CACHE;$user_cache = $CACHE->readCache('user');if($user_cache[1]['photo']['src']){echo BLOG_URL.$user_cache[1]['photo']['src'];}else{echo TEMPLATE_URL.'img/avatar.png';}?>" style="display: inline;">
			<?php }?>
			
				<p>
					<a id="cancel-reply" href="javascript:;" style="display: none;" onclick="cancelReply()">取消</a>
				</p>
			</div>
			<div class="comt-box">
				<textarea placeholder="请文明发言，评论敏感词“啊 哦 呵 哎 吖 哈 呃”等" class="input-block-level comt-area" name="comment" id="comment" cols="100%" rows="3" tabindex="1""></textarea>
				<div class="comt-ctrl">
					<div class="comt-tips">
						<input type="hidden" name="comment_post_ID" value="153" id="comment_post_ID">
						<input type="hidden" name="comment_parent" id="comment_parent" value="0">
						<label for="comment_mail_notify" class="checkbox inline hide" style="padding-top:0"><input type="checkbox" name="comment_mail_notify" id="comment_mail_notify" value="comment_mail_notify" checked="checked">有人回复时邮件通知我</label>
						<div class="comt-tip comt-loading" style="display: none;">
							评论提交中...
						</div>
						<div class="comt-tip comt-error" style="display: none;">
							#
						</div>
					</div>
					<div class="position">
						<a href="javascript:;" id="comment-smiley" title="表情"><b><i class="fa fa-smile-o"></i></b></a>
						<a href="javascript:" id="font-color" title="颜色"><b><i class="fa fa-font"></i></b></a>
						<a href="javascript:SIMPALED.Editor.img()" title="插图片"><b><i class="fa fa-image"></i></b></a>
						<a href="javascript:SIMPALED.Editor.ahref()" title="插链接"><b><i class="fa fa-link"></i></b></a><?php if(!empty($verifyCode)) {echo '<span class="comment_verfiy_container"><img src="'.BLOG_URL.'include/lib/checkcode.php" class="c_code" alt="看不清楚？点图切换" title="看不清楚？点图切换"><input type="text" name="imgcode" class="comment_verfiy_code" placeholder="输入验证码" autocomplete="off" title="看不清楚？点图切换"></span>';}; ?>
						<span class="comment_info" id="error1"></span>
					</div>					
					<button onclick="postcomment()" type="submit" name="comment_submit" id="submit" tabindex="5">提交评论</button>
				</div>
			</div>
			<script type="text/javascript">
/* <![CDATA[ */
    function grin(tag) {
      var myField;
      tag = ' ' + tag + ' ';
        if (document.getElementById('comment') && document.getElementById('comment').type == 'textarea') {
        myField = document.getElementById('comment');
      } else {
        return false;
      }
      if (document.selection) {
        myField.focus();
        sel = document.selection.createRange();
        sel.text = tag;
        myField.focus();
      }
      else if (myField.selectionStart || myField.selectionStart == '0') {
        var startPos = myField.selectionStart;
        var endPos = myField.selectionEnd;
        var cursorPos = startPos;
        myField.value = myField.value.substring(0, startPos)
                + tag
                + myField.value.substring(endPos, myField.value.length);
        cursorPos += tag.length;
        myField.focus();
        myField.selectionStart = cursorPos;
        myField.selectionEnd = cursorPos;
      }      else {
        myField.value += tag;
        myField.focus();
      }
    }
/* ]]> */
			</script>
			<div id="smiley" style="display: none;">
				<a href="javascript:grin('[F1]')"><img src="/content/templates/FYS/images/face/1.png" alt=""></a>
				<a href="javascript:grin('[F2]')"><img src="/content/templates/FYS/images/face/2.png" alt=""></a>
				<a href="javascript:grin('[F3]')"><img src="/content/templates/FYS/images/face/3.png" alt=""></a>
				<a href="javascript:grin('[F4]')"><img src="/content/templates/FYS/images/face/4.png" alt=""></a>
				<a href="javascript:grin('[F5]')"><img src="/content/templates/FYS/images/face/5.png" alt=""></a>
				<a href="javascript:grin('[F6]')"><img src="/content/templates/FYS/images/face/6.png" alt=""></a>
				<a href="javascript:grin('[F7]')"><img src="/content/templates/FYS/images/face/7.png" alt=""></a>
				<a href="javascript:grin('[F8]')"><img src="/content/templates/FYS/images/face/8.png" alt=""></a>
				<a href="javascript:grin('[F9]')"><img src="/content/templates/FYS/images/face/9.png" alt=""></a>
				<a href="javascript:grin('[F10]')"><img src="/content/templates/FYS/images/face/10.png" alt=""></a>
				<a href="javascript:grin('[F11]')"><img src="/content/templates/FYS/images/face/11.png" alt=""></a>
				<a href="javascript:grin('[F12]')"><img src="/content/templates/FYS/images/face/12.png" alt=""></a>
				<a href="javascript:grin('[F13]')"><img src="/content/templates/FYS/images/face/13.png" alt=""></a>
				<a href="javascript:grin('[F14]')"><img src="/content/templates/FYS/images/face/14.png" alt=""></a>
				<a href="javascript:grin('[F15]')"><img src="/content/templates/FYS/images/face/15.png" alt=""></a>
				<a href="javascript:grin('[F16]')"><img src="/content/templates/FYS/images/face/16.png" alt=""></a>
				<a href="javascript:grin('[F17]')"><img src="/content/templates/FYS/images/face/17.png" alt=""></a>
				<a href="javascript:grin('[F18]')"><img src="/content/templates/FYS/images/face/18.png" alt=""></a>
				<a href="javascript:grin('[F19]')"><img src="/content/templates/FYS/images/face/19.png" alt=""></a>
				<a href="javascript:grin('[F20]')"><img src="/content/templates/FYS/images/face/20.png" alt=""></a>
				<a href="javascript:grin('[F21]')"><img src="/content/templates/FYS/images/face/21.png" alt=""></a>
				<a href="javascript:grin('[F22]')"><img src="/content/templates/FYS/images/face/22.png" alt=""></a>
				<a href="javascript:grin('[F23]')"><img src="/content/templates/FYS/images/face/23.png" alt=""></a>
				<a href="javascript:grin('[F24]')"><img src="/content/templates/FYS/images/face/24.png" alt=""></a>
			</div>
			<div id="fontcolor" style="display: none;">
				<a href="javascript:SIMPALED.Editor.red()" style="background-color: red"></a>
				<a href="javascript:SIMPALED.Editor.green()" style="background-color: green"></a>
				<a href="javascript:SIMPALED.Editor.blue()" style="background-color: blue"></a>
				<a href="javascript:SIMPALED.Editor.magenta()" style="background-color: magenta"></a>
				<a href="javascript:SIMPALED.Editor.yellow()" style="background-color: yellow"></a>
				<a href="javascript:SIMPALED.Editor.chocolate()" style="background-color: chocolate"></a>
				<a href="javascript:SIMPALED.Editor.black()" style="background-color: black"></a>
				<a href="javascript:SIMPALED.Editor.aquamarine()" style="background-color: aquamarine"></a>
				<a href="javascript:SIMPALED.Editor.lime()" style="background-color: lime"></a>
				<a href="javascript:SIMPALED.Editor.fuchsia()" style="background-color: fuchsia"></a>
				<a href="javascript:SIMPALED.Editor.orange()" style="background-color: orange"></a>
				<a href="javascript:SIMPALED.Editor.thistle()" style="background-color: thistle"></a>
				<a href="javascript:SIMPALED.Editor.brown()" style="background-color: brown"></a>
				<a href="javascript:SIMPALED.Editor.peru()" style="background-color: peru"></a>
				<a href="javascript:SIMPALED.Editor.deeppink()" style="background-color: deeppink"></a>
				<a href="javascript:SIMPALED.Editor.purple()" style="background-color: purple"></a>
				<a href="javascript:SIMPALED.Editor.slategray()" style="background-color: slategray"></a>
				<a href="javascript:SIMPALED.Editor.tomato()" style="background-color: tomato"></a>
			</div>
			<?php if(ROLE == ROLE_VISITOR): ?>
			<div class="comt-comterinfo" id="comment-author-info">
				<ul>
					<li class="form-inline">
					<span class="input-group-addon"><i class="fa fa-qq"></i></span>
					<input id="qqnum" class="ipt" name="qqnum" type="text" value="" placeholder="QQ号(快速获取信息)" onblur="huoquqq()"></li>
					<li class="form-inline">
					<span class="input-group-addon"><i class="fa fa-user"></i></span>
					<input class="ipt" type="text" name="comname" id="comname" value="<?php echo $ckname; ?>" tabindex="2" placeholder="昵称(必填)"></li>
					<li class="form-inline">
					<span class="input-group-addon"><i class="fa fa-envelope"></i></span>
					<input class="ipt" type="text" name="commail" id="commail" value="<?php echo $ckmail; ?>" tabindex="3" placeholder="邮箱(必填)"></li>
					<li class="form-inline">
					<span class="input-group-addon"><i class="fa fa-link"></i></span>
					<input class="ipt" type="text" name="comurl" id="comurl" value="<?php echo $ckurl; ?>" tabindex="4" placeholder="网址"></li>
				</ul>
			</div>
			<?php endif; ?>
		</div>
	</form>
	<?php endif; ?>
<?php }?>
<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>
<?php
//blog-tool:获取Gravatar头像
function myGravatar($email,$role='' ,$s = 50, $d = 'wavatar', $g = 'g') {
	if(!empty($role)){
		return $role;
	}
$hash = md5($email);
$avatar = "http://secure.gravatar.com/avatar/$hash?s=$s&d=$d&r=$g";
return $avatar;
}?>
<?php //分页函数
function sheli_fy($count,$perlogs,$page,$url,$anchor=''){
$pnums = @ceil($count / $perlogs);
$page = @min($pnums,$page);
$prepg=$page-1;                 //shuyong.net上一页
$nextpg=($page==$pnums ? 0 : $page+1); //shuyong.net下一页
$urlHome = preg_replace("|[\?&/][^\./\?&=]*page[=/\-]|","",$url);
//开始分页导航内容
$re = "";
if($pnums<=1) return false;	//如果只有一页则跳出	
if($page!=1) $re .="<li class=\"next-page\"><a href=\"$urlHome$anchor\">首页</a></li>\n"; 
if($prepg) $re .="<li class=\"next-page\"><a href=\"$url$prepg$anchor\" >上一页</a></li>\n";
for ($i = $page-2;$i <= $page+2 && $i <= $pnums; $i++){
if ($i > 0){if ($i == $page){$re .= "<li class=\"active\"><span>$i</span></li>\n";
}elseif($i == 1){$re .= "<li><a href=\"$urlHome$anchor\">$i</a></li>\n";
}else{$re .= "<li><a href=\"$url$i$anchor\">$i</a></li>\n";}
}}
if($nextpg) $re .="<li class=\"next-page\"><a href=\"$url$nextpg$anchor\" class='nextpages'>下一页</a></li>\n"; 
if($page!=$pnums) $re.=" <li class=\"next-page\"><a href=\"$url$pnums$anchor\" title=\"尾页\">尾页</a></li>\n";
return $re;}
?>
<?php
function getrandomim(){
	$imgsrc = TEMPLATE_URL."images/random/".rand(1,10).".jpg";
	return $imgsrc;
}
?>
<?php
//获取图片
function get_thum($logid){
 $db = MySql::getInstance();

	$sqlimg = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$logid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";
//    die($sql);
	$img = $db->query($sqlimg);
    while($roww = $db->fetch_array($img)){
	 $thum_url=BLOG_URL.substr($roww['filepath'],3,strlen($roww['filepath']));
    }
    if (empty($thum_url)) {
            $thum_url = getrandomim();
        }
  
return $thum_url;
}
//获取图片2 
function getThumbnail($blogid){
    $db = Database::getInstance();
    $sql = "SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$blogid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 0,1";
    //die($sql);
    $imgs = $db->query($sql);
    $img_path = "";
	if($db->num_rows($imgs)){
		while($row = $db->fetch_array($imgs)){
			 $img_path .= BLOG_URL.substr($row['filepath'],3,strlen($row['filepath']));
		}
	}else{
		$img_path = false;
	}
    return $img_path;
}

//图片链接
function pic_thumb($content){
    preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $content, $img);
    $imgsrc = !empty($img[1]) ? $img[1][0] : '';
	if($imgsrc):
		return $imgsrc;
	endif;
}
?>
<?php
function GetThumFromContent($content){
	/*图片和摘要*/
	preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $content, $img);
	if($imgsrc = !empty($img[1])){
		 $imgsrc = $img[1][0];}else{ 
			preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $content ,$img);
			if($imgsrc = !empty($img[1])){ $imgsrc = $img[1][0];  }else{
				$imgsrc =getrandomim();	
			}
	}
	return $imgsrc;
}
?>
<?php
//格式化内容工具
function tool_purecontent($content, $strlen = null){
        $content = str_replace('继续阅读&gt;&gt;', '', $content);
		$content = preg_replace("/\[hide\](.*)\[\/hide\]/Uims", '|*********此处内容回复可见*********|', strip_tags($content));
        if ($strlen) {
            $content = subString($content, 0, $strlen);
        }
        return $content;
}
?>
<?php
function sydate($ptime,$isunix=false){
	if(!$isunix){
		$ptime = strtotime($ptime);
	}
	$etime = time() - $ptime;
	if($etime < 1){return '刚刚';}
	$interval = array(
		12 * 30 * 24 * 60 * 60 => '年前 ('.date('Y-m-d', $ptime).')',
		30 * 24 * 60 * 60      => '个月前 ('.date('Y-m-d', $ptime).')',
		7 * 24 * 60 * 60       => '周前 ('.date('Y-m-d', $ptime).')',
		24 * 60 * 60           => '天前',
		60 * 60                => '小时前',
		60                     => '分钟前',
		1                      => '秒前',
	);
foreach ($interval as $secs => $str) {
		$d = $etime / $secs;
		if ($d >= 1){
			$r = round($d);
			return $r . $str ;
		}
	}
}
?>
<?php
//widget：pages_links
function pages_links(){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
    //if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
    foreach($link_cache as $value): ?>
	<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank" rel="nofollow"><?php echo $value['link']; ?></a></li>
	<?php endforeach;}?>
<?php
/**
 * @des 显示评论列表与否的判定方法
 * @param $comnum 评论内容体
 * @return string 
 */
function isShowComment($comnum) {
	return !!$comnum;
} 
?>
<?php
function GetFaceImg(){
	$Face = array(array('url' => 'images/face/1.png',
						'title' =>  "微笑") ,
				  array('url' => 'images/face/5.png',
						'title' => "得意" ) ,
				  array('url' => 'images/face/6.png',
						'title' =>"愤怒") ,
				  array('url' => 'images/face/7.png',
						'title' => "调戏" ) ,
				  array('url' => 'images/face/9.png',
						'title' => "大哭" ) ,
				  array('url' => 'images/face/10.png',
						'title' =>"汗"  ) ,
				  array('url' => 'images/face/11.png',
						'title' => "鄙视" ) ,
				  array('url' => 'images/face/13.png',
						'title' =>  "真棒") ,
				  array('url' => 'images/face/14.png',
						'title' => "金钱" ) ,
				  array('url' => 'images/face/16.png',
						'title' => "瞧不起" ) ,
				  array('url' => 'images/face/19.png',
						'title' =>  "委屈") ,
				  array('url' => 'images/face/21.png',
						'title' =>"惊讶") ,
				  array('url' => 'images/face/24.png',
						'title' =>"可爱") ,
				  array('url' => 'images/face/25.png',
						'title' => "滑稽" ) ,
				  array('url' => 'images/face/26.png',
						'title' => "调皮") ,
				  array('url' => 'images/face/27.png',
						'title' => "大汉") ,
				  array('url' => 'images/face/28.png',
						'title' =>"可怜") ,
				  array('url' => 'images/face/29.png',
						'title' => "睡觉" ) ,
				  array('url' => 'images/face/30.png',
						'title' => "流泪" ) ,
				  array('url' => 'images/face/31.png',
						'title' => "气出泪" ) ,
				  array('url' => 'images/face/33.png',
						'title' =>"喷") ,
				  array('url' => 'images/face/39.png',
						'title' => "月亮")  ,
				  array('url' => 'images/face/40.png',
						'title' => "太阳")  ,
		 		  array('url' => 'images/face/43.png',
						'title' => "咖啡")  ,
				  array('url' => 'images/face/44.png',
						'title' => "蛋糕")  ,
				  array('url' => 'images/face/45.png',
						'title' => "音乐")  ,
				  array('url' => 'images/face/47.png',
						'title' => "yes")  ,
				  array('url' => 'images/face/48.png',
						'title' => "大拇指")  ,
				  array('url' => 'images/face/49.png',
						'title' => "鄙视你"),
				  array('url' => 'images/face/50.png',
						'title' => "程序猿"),
				  );
	foreach ($Face as $key => $value) {
			$faceimg=TEMPLATE_URL.$value["url"];
			$tooltip='['.$value["title"].']';
			echo "<a href='javascript:;' title='$tooltip' data-title='$tooltip'><img src='{$faceimg}'></a>";
	}
}
?>
<?php
/**
 * @des emoji 标签处理评论并输出
 * @param $str 评论数据
 * @return string
 */
function comment2emoji($str) {
		$data = array(array('url' => 'images/face/1.png',
						'title' =>  "微笑") ,
				  array('url' => 'images/face/5.png',
						'title' => "得意" ) ,
				  array('url' => 'images/face/6.png',
						'title' =>"愤怒") ,
				  array('url' => 'images/face/7.png',
						'title' => "调戏" ) ,
				  array('url' => 'images/face/9.png',
						'title' => "大哭" ) ,
				  array('url' => 'images/face/10.png',
						'title' =>"汗"  ) ,
				  array('url' => 'images/face/11.png',
						'title' => "鄙视" ) ,
				  array('url' => 'images/face/13.png',
						'title' =>  "真棒") ,
				  array('url' => 'images/face/14.png',
						'title' => "金钱" ) ,
				  array('url' => 'images/face/16.png',
						'title' => "瞧不起" ) ,
				  array('url' => 'images/face/19.png',
						'title' =>  "委屈") ,
				  array('url' => 'images/face/21.png',
						'title' =>"惊讶") ,
				  array('url' => 'images/face/24.png',
						'title' =>"可爱") ,
				  array('url' => 'images/face/25.png',
						'title' => "滑稽" ) ,
				  array('url' => 'images/face/26.png',
						'title' => "调皮") ,
				  array('url' => 'images/face/27.png',
						'title' => "大汉") ,
				  array('url' => 'images/face/28.png',
						'title' =>"可怜") ,
				  array('url' => 'images/face/29.png',
						'title' => "睡觉" ) ,
				  array('url' => 'images/face/30.png',
						'title' => "流泪" ) ,
				  array('url' => 'images/face/31.png',
						'title' => "气出泪" ) ,
				  array('url' => 'images/face/33.png',
						'title' =>"喷") ,
				  array('url' => 'images/face/39.png',
						'title' => "月亮")  ,
				  array('url' => 'images/face/40.png',
						'title' => "太阳")  ,
		 		  array('url' => 'images/face/43.png',
						'title' => "咖啡")  ,
				  array('url' => 'images/face/44.png',
						'title' => "蛋糕")  ,
				  array('url' => 'images/face/45.png',
						'title' => "音乐")  ,
				  array('url' => 'images/face/47.png',
						'title' => "yes")  ,
				  array('url' => 'images/face/48.png',
						'title' => "大拇指")  ,
				  array('url' => 'images/face/49.png',
						'title' => "鄙视你"),
			    	array('url' => 'images/face/50.png',
						'title' => "程序猿")
				  );
	foreach($data as $key=>$value) {
		$str = str_replace('['.$value['title'].']','<img class="comment_face" src="'.TEMPLATE_URL.$value['url'].'" title="'.$value['title'].'">',$str);
	}
	return $str;
}
?>
<?php 
function sort_name($arrsort){ 
global $arr_sortico1; 
foreach($arrsort as $key => $value){
	$sortid = $value;
	?>
	<div class="col-sm-4 0">
	 <div class="cmslist">
    	<div class="xyti">
            <h3><i class="<?php if(empty($arr_sortico1[$sortid])){echo "fa fa-list-ul";}else{echo $arr_sortico1[$sortid];}?>"></i><a href="<?php echo Url::sort($sortid);?>" class="mcolor"><?php echo getsotrnamefromsid($sortid);?></a></h3>
        </div>
        <ul><?php Get_newlogs($sortid,6);?></ul>
     </div>
	</div>
<?php }}?>
<?php
function Get_newlogs($sortid,$log_num) {
    $db = MySql::getInstance();
    $sql = 	"SELECT gid,title,date,content,views FROM ".DB_PREFIX."blog WHERE type='blog' and hide='n' and sortid='$sortid' ORDER BY `date` DESC LIMIT 0,$log_num";
    $list = $db->query($sql);
	$i=0;
    while($row = $db->fetch_array($list)){$i++; 
    	if($module_thum=="0"){
    		$imgsrc = GetThumFromContent($row['content']);
    	}else{
    		$imgsrc = get_thum($row['gid']);
    	}?>
<?php if($i==1):?>
	<li class="first"><a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>" class="pic"><img src="<?php echo $imgsrc;?>" alt="<?php echo $row['title']; ?>" style="display: inline;"></a><a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>" class="text"><?php echo $row['title']; ?></a><div class="des">
	<?php echo $logdes = tool_purecontent($row['content'], 120); ?></div></li>
<?php else:?>
<li><i class="fa fa-caret-right"></i><a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>"><?php echo $row['title']; ?></a></li>
<?php endif;}}?>
<?php
function islogin(){
if(ROLE == 'admin' || ROLE == 'writer'){
	return true;
	}
	return false;
}
?>
<?php 
function f162_istop($top,$num){
	if($top == "top"){
		$and = "AND top='y'";
	}elseif($top == "sortop"){
		$and = "AND sortop='y'";
	}elseif($top == "all"){
		$and = "AND top='y' OR sortop='y'";
	}
	$db=MySql::getInstance();
	$sql=$db->query("select * from emlog_blog where  hide='n' AND type='blog' $and order by date DESC limit 0,$num");

	while($row = $db->fetch_array($sql)){
	if($module_thum==0){
		$imgsrc = GetThumFromContent($row['content']);
	}else{
		$imgsrc = get_thum($row['gid']);
	}
?>
	<li><time><?php echo gmdate('Y-m-d', $row['date']);?></time><a href="<?php echo Url::log($row['gid']);?>" title="<?php echo $row['title'];?>"><?php echo $row['title'];?></a></li>
<?php 
	} 
}
?>
<?php
// 获取EMLOG固定数量网站标签（随机排序）
function getTags($num){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');
	shuffle($tag_cache); //添加这行代码实现标签随机排序
	foreach($tag_cache as $key => $value):
		if($key < $num):
		?>
<a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇文章"><?php echo $value['tagname']; ?></a>
		<?php 
		endif;
	endforeach;
}
?>
<?php
//comment：输出等级
function echo_levels($comment_author_email){
global $CACHE;$user_cache = $CACHE->readCache('user');$mail = $user_cache[1]['mail'];
  $DB = MySql::getInstance();
  $adminEmail = '"'.$user_cache[1]['mail'].'"';
  $adminEmail1 = '""';
  if($adminEmail==$adminEmail1){
	emMsg('请先设置<a href="../admin/blogger.php" target="_blank">管理员邮箱</a>', BLOG_URL . 'admin/blogger.php');
  }
  if($comment_author_email==$adminEmail)
  { echo '<a class="admin" title="博客管理员"><img src="../content/templates/limh.me/images/admin.png"></a>';}
  $sql = "SELECT cid as author_count FROM ".DB_PREFIX."comment WHERE mail = ".$comment_author_email;
  $res = $DB->query($sql);
  $author_count = mysql_num_rows($res);
  if($author_count>=1 && $author_count<10 && $comment_author_email!=$adminEmail&& $comment_author_email!=$adminEmail1)
    echo '<a class="forum_level lv1" title="访客等级 LV.1"></a>';
  else if($author_count>=10 && $author_count<20 && $comment_author_email!=$adminEmail&& $comment_author_email!=$adminEmail1)
    echo '<a class="forum_level lv2" title="访客等级 LV.2"></a>';
  else if($author_count>=20 && $author_count<30 && $comment_author_email!=$adminEmail&& $comment_author_email!=$adminEmail1)
    echo '<a class="forum_level lv3" title="访客等级 LV.3"></a>';
  else if($author_count>=30 && $author_count<40 && $comment_author_email!=$adminEmail&& $comment_author_email!=$adminEmail1)
    echo '<a class="forum_level lv4" title="访客等级 LV.4"></a>';
  else if($author_count>=40 && $author_count<50 && $comment_author_email!=$adminEmail&& $comment_author_email!=$adminEmail1)
    echo '<a class="forum_level lv5" title="访客等级 LV.5"></a>';
  else if($author_count>=50 && $author_count<60 && $comment_author_email!=$adminEmail&& $comment_author_email!=$adminEmail1)
    echo '<a class="forum_level lv6" title="访客等级 LV.6"></a>';
  else if($author_count>=60 && $author_count<70 && $comment_author_email!=$adminEmail&& $comment_author_email!=$adminEmail1)
    echo '<a class="forum_level lv7" title="访客等级 LV.7"></a>';
  else if($author_count>=70 && $author_count<80 && $comment_author_email!=$adminEmail&& $comment_author_email!=$adminEmail1)
    echo '<a class="forum_level lv8" title="访客等级 LV.8"></a>';
  else if($author_count>=80 && $author_count<90 && $comment_author_email!=$adminEmail&& $comment_author_email!=$adminEmail1)
    echo '<a class="forum_level lv9" title="访客等级 LV.9"></a>';
  else if($author_count>=90 && $author_count<100 && $comment_author_email!=$adminEmail&& $comment_author_email!=$adminEmail1)
    echo '<a class="forum_level lv10" title="访客等级 LV.10"></a>';
  else if($author_count>=100 && $author_count<125 && $comment_author_email!=$adminEmail&& $comment_author_email!=$adminEmail1)
    echo '<a class="forum_level lv11" title="访客等级 LV.11"></a>';
  else if($author_count>=125 && $author_count<150 && $comment_author_email!=$adminEmail&& $comment_author_email!=$adminEmail1)
    echo '<a class="forum_level lv12" title="访客等级 LV.12"></a>';
  else if($author_count>=150 && $author_count<175 && $comment_author_email!=$adminEmail&& $comment_author_email!=$adminEmail1)
    echo '<a class="forum_level lv13" title="访客等级 LV.13"></a>';
  else if($author_count>=175 && $author_count<200 && $comment_author_email!=$adminEmail&& $comment_author_email!=$adminEmail1)
    echo '<a class="forum_level lv14" title="访客等级 LV.14"></a>';
  else if($author_count>=200 && $author_count<225 && $comment_author_email!=$adminEmail&& $comment_author_email!=$adminEmail1)
    echo '<a class="forum_level lv15" title="访客等级 LV.15"></a>';
  else if($author_count>=225 && $author_count<250 && $comment_author_email!=$adminEmail&& $comment_author_email!=$adminEmail1)
    echo '<a class="forum_level lv16" title="访客等级 LV.16"></a>';
  else if($author_count>=250 && $author_count<275 && $comment_author_email!=$adminEmail&& $comment_author_email!=$adminEmail1)
    echo '<a class="forum_level lv17" title="访客等级 LV.17"></a>';
  else if($author_count>=275 && $author_count<300 && $comment_author_email!=$adminEmail&& $comment_author_email!=$adminEmail1)
    echo '<a class="forum_level lv18" title="访客等级 LV.18"></a>';
  else if($author_count>=200 && $author_count<250 && $comment_author_email!=$adminEmail&& $comment_author_email!=$adminEmail1)
    echo '<a class="forum_level lv19" title="访客等级 LV.19"></a>';
  else if($author_count>=250 && $author_count<88888 && $comment_author_email!=$adminEmail&& $comment_author_email!=$adminEmail1)
    echo '<a class="forum_level lv20" title="访客等级 LV.20"></a>';
  else if($comment_author_email==$adminEmail1)
    echo '<div class="lvnull" title="访客等级 LV.1"><i class="fa fa-user"></i></div>';
}
?>
<?php
function kiny_curPageURL(){
    $pageURL = 'http';
    if ($_SERVER["HTTPS"] == "on"){
        $pageURL .= "s";
    }
    $pageURL .= "://";
    if ($_SERVER["SERVER_PORT"] != "80"){
        $pageURL .= $_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"] . $_SERVER["REQUEST_URI"];
    }else{
        $pageURL .= $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];
    }
    return $pageURL;}
?>
<?php
//首页置顶头条
function getZhidingLogs() {
$db = MySql::getInstance();
$sql = "SELECT gid,title,content,date FROM ".DB_PREFIX."blog WHERE type='blog' and top='y' ORDER BY `top` DESC ,`date` DESC LIMIT 0,1";
$list = $db->query($sql);
while($row = $db->fetch_array($list)){
//$row['content'] = htmlspecialchars($row['content']);
$row['content'] = strip_tags($row['content']);?>
<?php echo mb_substr($row['content'],0,85,'utf-8'); ?> 
<?php } ?>
<?php } ?>
<?php
//Custom：获取模板目录名称
function get_template_name(){
    $template_name = str_replace(BLOG_URL,"",TEMPLATE_URL);
    $template_name = str_replace("content/templates/","",$template_name);
    $template_name = str_replace("/","",$template_name);
    return $template_name;
}
?>