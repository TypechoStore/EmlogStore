<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<section class="container">
<div class="mbx">
	<a href="/">首页</a>» <?php echo $log_title; ?>
</div>
</section>
<div class="container container-tags">
	<h1><?php echo $log_title; ?></h1>
	<div class="tagslist">
		<ul>
			<?php echo page_tags();?> 
		</ul>
	</div>
</div>
<?php
 include View::getView('footer');
?>