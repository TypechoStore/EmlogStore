<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<section class="container">
<div class="mbx">
	<a href="/">首页</a>» <?php echo $log_title; ?>
</div>
</section>
<div class="container container-page">
	<div class="pageside">
		<div class="pagemenus">
			<?php include View::getView('page/page-side-menu');?>
		</div>
	</div>
	<div class="content">
		<header class="article-header">
		<h1 class="article-title"><?php echo $log_title; ?></h1>
		</header>
		<article class="article-content">
			<?php echo $log_content; ?>
		</article>
		<?php if($allow_remark == 'y'): ?>
		<div class="title" id="comments">
			<h3>评论 </h3>
		</div>
		<div id="comment-place">
			<div class="no_webshot" id="comment-post">
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
		</div>
		</div>
		<div id="postcomments">	
		<ol class="commentlist">
		<?php blog_comments($comments,$comnum); ?>
		</ol>
		</div>
		<?php endif;?>
	</div>
</div>
<?php
 include View::getView('footer');
?>
