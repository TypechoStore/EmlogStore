<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 

if(isset($_GET["setting"])){
	require_once View::getView('setting');
	exit;
}
if(isset($_GET["user"])){
	require_once View::getView('user');
	exit;
}
$view='';

if(isset($_COOKIE["emlog_dux_mothod"])){
	$web_method = $_COOKIE["emlog_dux_mothod"];
}

//$sort_img = explode(",",$Tconfig['img_id']);
//if(in_array($sortid,$sort_img)){include View::getView('log_img');exit;}
?>
<section class="container">
<div class="content-wrap">
	<div class="content">
	<?php if (blog_tool_ishome()) {?>
	<?php if($Tconfig["Slide"]== 1 ){?>
		<div id="focusslide" class="carousel slide" data-ride="carousel">
			<ol class="carousel-indicators">
				<li data-target="#focusslide" data-slide-to="0" class="active"></li>
				<li data-target="#focusslide" data-slide-to="1"></li>
				<li data-target="#focusslide" data-slide-to="2"></li>
			</ol>
			<div class="carousel-inner" role="listbox">
				<div class="item active">
					<a href="<?php echo $Tconfig["Surl1"];?>" title="<?php echo $Tconfig["title1"];?>"><img src="<?php echo $Tconfig["Slide1"];?>" title="<?php echo $Tconfig["title1"];?>" alt="<?php echo $Tconfig["title1"];?>" /></a>
				</div>
				<div class="item">
					<a href="<?php echo $Tconfig["Surl2"];?>" title="<?php echo $Tconfig["title2"];?>"><img src="<?php echo $Tconfig["Slide2"];?>" title="<?php echo $Tconfig["title2"];?>" alt="<?php echo $Tconfig["title2"];?>" /></a>
				</div>
				<div class="item">
					<a href="<?php echo $Tconfig["Surl3"];?>" title="<?php echo $Tconfig["title3"];?>"><img src="<?php echo $Tconfig["Slide3"];?>" title="<?php echo $Tconfig["title3"];?>" alt="<?php echo $Tconfig["title3"];?>" /></a>
				</div>
			</div>
			<a class="left carousel-control" href="#focusslide" role="button" data-slide="prev"><i class="fa fa-angle-left"></i></a><a class="right carousel-control" href="#focusslide" role="button" data-slide="next"><i class="fa fa-angle-right"></i></a>
		</div>
		<?php }?>
		<?php if($Tconfig['radio_zhiding']== 1 ){?>
		<article class="excerpt-minic excerpt-minic-index">
		<h2><span class="red">【<?php echo $Tconfig['heightkey'];?>】</span><a href="<?php echo $Tconfig['top_titleurl'];?>" title="<?php echo $Tconfig['top_title'];?>"><?php echo $Tconfig['top_title'];?></a></h2>
		<p class="note">
			<?php echo $Tconfig['top_content'];?>...
		</p>
		</article>
		<?php }?>
		<?php if($Tconfig['newsj']== 1 ){?>
		<?php CommonPageFromGFS(); ?>
		<?php }?>	
		<?php if($Tconfig["Sorts"]== 1 ){?>		
		<div class="asb asb-index asb-index-01">
			<div class="asb asb-index asb-index-01">
				<ul class="indexebox">
					<li class="indexebox-i indexebox-01">
					<h4><?php echo $Tconfig["Sorth1"];?></h4>
					<p>
						<?php echo $Tconfig["Sortp1"];?>
					</p>
					<a class="btn btn-success btn-sm" href="<?php echo $Tconfig["Sorta1"];?>" target="_black">立即前往</a>
					</li>
					<li class="indexebox-i indexebox-02">
					<h4><?php echo $Tconfig["Sorth2"];?></h4>
					<p>
						<?php echo $Tconfig["Sortp2"];?>
					</p>
					<a class="btn btn-primary btn-sm" href="<?php echo $Tconfig["Sorta2"];?>" target="_black">立即前往</a>
					</li>
					<li class="indexebox-i indexebox-03">
					<h4><?php echo $Tconfig["Sorth3"];?></h4>
					<p>
						<?php echo $Tconfig["Sortp3"];?>
					</p>
					<a class="btn btn-warning btn-sm" href="<?php echo $Tconfig["Sorta3"];?>">立即前往</a>
					</li>
					<li class="indexebox-i indexebox-04">
					<h4><?php echo $Tconfig["Sorth4"];?></h4>
					<p>
						<?php echo $Tconfig["Sortp4"];?>
					</p>
					<a class="btn btn-info btn-sm" href="<?php echo $Tconfig["Sorta4"];?>">立即前往</a>
					</li>
					<li class="indexebox-i indexebox-100">
					<h4><?php echo $Tconfig["Sorth5"];?></h4>
					<p>
						<?php echo $Tconfig["Sortp5"];?>
					</p>
					<a class="btn btn-sm btn-danger" href="<?php echo $Tconfig["Sorta5"];?>" target="_black">立即前往</a>
					</li>
				</ul>
			</div>
		</div>
		<?php }?>
		<div class="title wow fadeInUp">
			<h3>
				最新发布							
			</h3>
			<div class="more">
				FYS 重写UI，优化死代码无用代码！
			</div>
		</div>
		<?php }?>
		<?php if($Tconfig["ads"]== 1 ){?>
		<article class="title wow fadeInUp"><a href="<?php echo $Tconfig["adurl1"];?>" target="_blank"><img src="<?php echo $Tconfig["adimg1"];?>" style="width: 100%;"></a></article>
		<?php }?>
		<?php doAction('index_loglist_top'); 
if (!empty($logs)){
		if(blog_tool_ishome() && empty($keyword)) {
			//echo '<div class="title"><h3>最新更新</h3></div>';
		}
		if(!empty($sort)) {
			//栏目页显示
			$des = $sort['description']?$sort['description']:'这家伙很懒，还没填写该栏目的介绍呢~';
			echo '<section class="container"><div class="mbx"> <a href="/">首页</a> » '.$sortName.' </div> </section>';
		}
		if(!empty($record)) {
			//日期记录
			$year    = substr($record,0,4);
			$month   = ltrim(substr($record,4,2),'0');
			$day     = substr($record,6,2);
			$archive = $day?$year.'年'.$month.'月'.ltrim($day,'0').'日':$year.'年'.$month.'月';
			echo '<section class="container"><div class="mbx"> <a href="/">首页</a> »  '.$archive.'发布的文章</div> </section>';
		}
		if(!empty($author_name)) {
			//作者日志显示
			echo '<section class="container"><div class="mbx"> <a href="/">首页</a> » '.$author_name.' 共计发布文章'.$lognum.'篇</div> </section>';
		}
		if(!empty($keyword)) {
			//搜索
			echo '<section class="container"><div class="mbx"> <a href="/">首页</a> » 本次搜索帮您找到有关 <strong>'.$keyword.'</strong> 的结果'.$lognum.'条</div> </section>';
		}
		if(!empty($tag)) {
			//关键词
			echo '<section class="container"><div class="mbx"> <a href="/">首页</a> » 关于 <strong>'.$tag.'</strong> 的文章共有'.$lognum.'条</div> </section>';
		}
}

foreach($logs as $key=>$value): 
	$picnum = pic($value['content']);
		if($module_thum=="0"){
			$imgsrc = GetThumFromContent($value['content']);
		}else{
			$imgsrc = get_thum($value['logid']);
		}
	$keys = $key+1;
    $ishowimg = $picnum!=0;
	
?>
		<article class="excerpt <?php echo "excerpt-{$keys}";?> wow fadeInUp">
		<?php
echo '<a class="focus" href="'.$value['log_url'].'">';
echo "<img data-src='$imgsrc' src='$imgsrc' class=\"thumb\" ></a>";
?>
		<header><?php blog_sort($value['logid']); ?>
		<h2><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a></h2>
		</header>
		<p class="meta">
			<time><i class="fa fa-clock-o"></i><?php echo gmdate('Y-n-j', $value['date']); ?></time><span class="author"><i class="fa fa-user"></i><?php blog_author($value['author']); ?> </span><span class="pv"><i class="fa fa-eye"></i>阅读(<?php echo $value['views']; ?>)</span><a class="pc" href="<?php echo $value['log_url']; ?>#comments"><i class="fa fa-comments-o"></i>评论(<?php echo $value['comnum']; ?>)</a>
		</p>
		<p class="note ">
			<?php echo $logdes = tool_purecontent($value['content'], 180); ?>
		</p>
		
		<?php if(((date('Ymd',time())-date('Ymd',$value['date']))<=1)){?>
<?php }elseif($value['views']>=66){?>
<div class="zd">
			<span>热门</span>
		</div>
<?php }?>
<?php if($value['top']=='y'):?>
<div class="zd">
			<span>置顶</span>
		</div>
<?php endif; ?>
		</article>
		<?php endforeach;?>
		<?php if($Tconfig["ads"]== 1 ){?>
		<article class="title wow fadeInUp"><a href="<?php echo $Tconfig["adurl2"];?>" target="_blank"><img src="<?php echo $Tconfig["adimg2"];?>" style="width: 100%;"></a></article>
		<?php }?>
		<div class="pagination">
			<ul>
				<?php echo sheli_fy($lognum,$index_lognum,$page,$pageurl);?>
			</ul>
		</div>
	</div>
</div>
<?php
 include View::getView('side');
?>
</section>
<?php
 include View::getView('footer');
?>