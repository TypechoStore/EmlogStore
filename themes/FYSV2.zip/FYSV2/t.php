<?php 
/**
 * 微语
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<section class="container">
<div class="mbx">
	<a href="/">首页</a>» <?php echo $log_title; ?>
</div>
</section>
<div class="container container-page">
	<div class="pageside">
		<div class="pagemenus">
			<?php include View::getView('page/page-side-menu');?>
		</div>
	</div>
	<div class="content">
		<header class="article-header">
		<h1 class="article-title"><?php echo $log_title; ?></h1>
		</header>
<div class="cleft">
	<ul class="twiter">
		<?php 
    foreach($tws as $val):
    $author = $user_cache[$val['author']]['name'];
    $avatar = empty($user_cache[$val['author']]['avatar']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . $user_cache[$val['author']]['avatar'];
    $tid = (int)$val['id'];
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank">
		<img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?>
		<li class="twiter_list"><section class="comments"><article class="comment"><a class="comment-img" href="#non"><img src="<?php echo $avatar; ?>" alt="fys 1.0 大前端二次开发" width="50" height="50"></a>
		<div class="comment-body">
			<div class="text">
				<p>
					<?php echo comment2emoji($val['t']).'<br/>
					'.$img;?>
				</p>
				<p class="twiter_info">
					<i class="fa fa-user"></i><span class="twiter_author"><?php echo $author; ?>
					</span><time class="twiter_time"><i class="fa fa-clock-o"></i><?php echo $val['date'];?>
					</time>
				</p>
			</div>
		</div>
		</article></section></li>
		<?php endforeach;?>
	</ul>
	<div class="twwiter">
		<div class="page comment-page">
			<?php echo $pageurl;?>
		</div>
	</div>
</div>
		<?php if($allow_remark == 'y'): ?>
		<div class="title" id="comments">
			<h3>评论 </h3>
		</div>
		<div id="comment-place">
			<div class="no_webshot" id="comment-post">
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
		</div>
		</div>
		<div id="postcomments">	
		<ol class="commentlist">
		<?php blog_comments($comments,$comnum); ?>
		</ol>
		</div>
		<?php endif;?>
	</div>
</div>
<?php
 include View::getView('footer');
?>
