<?php 
/**
 * 侧边栏
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<aside class="sidebar">
<?php if($userhide==1):?>
<div class="widget widget-tops">
	<ul class="widget-nav">
		<li class="active">会员中心</li>
		<li class="">站长推荐</li>
		<li>联系我们</li>
	</ul>
	<ul class="widget-navcontent">
		<li class="item item-02 active">
		<?php if(!islogin()){ ?>
		<h4>需要登录才能进入会员中心</h4>
		<p>
			<a href="javascript:;" class="btn btn-primary user-login" data-sign="0">立即登录</a>
			<a href="javascript:;" class="btn btn-default user-reg" data-sign="1">现在注册</a>
		</p>
		<?php }else{ ?>
						<?php 
				global $userData;
			?>
		<dl>
			<dt><img alt="" src="<?php $imgavatar = empty($userData['photo']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . substr($userData['photo'],3);echo myGravatar($userData["email"],$imgavatar);?>" onerror="javascript:this.src=&quot;<?php $imgavatar = empty($userData['photo']) ? 
                BLOG_URL . 'admin/views/images/avatar.jpg' : 
                BLOG_URL . substr($userData['photo'],3);echo myGravatar($userData["email"],$imgavatar);?>&quot;;this.onerror=null;" class="avatar avatar-50 photo" height="50" width="50"></dt>
			<dd><?php if(empty($userData["nickname"])){echo $userData["username"];}else{echo $userData["nickname"];}?> <span class="text-muted"><?php echo $userData["email"];?> </span></dd>
		</dl>
		<ul>
			<li><a href="<?php echo BLOG_URL;?>?user&posts">我的文章</a></li>
			<li><a href="<?php echo BLOG_URL;?>?user&comments">我的评论</a></li>
			<li><a href="<?php echo BLOG_URL;?>?user&info">修改资料</a></li>
			<li><a href="<?php echo BLOG_URL;?>?user&password">修改密码</a></li>
		</ul>
		<?php }?>
		</li>
		<li class="item item-03">
		<ul>
						<?php echo $Tconfig["home_text"];?>			
		</ul>
		</li>
		<li class="item item-04">
          <h2>客服不一定在线，您可以给我们留言 <br>QQ：<?php echo $Tconfig["side_qq"];?></h2>						
		</li>	
	</ul>
</div>
<?php endif;?>
<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>
<?php
$db = Database::getInstance();
$sta_cache = array();
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "user WHERE role = 'admin'");
$blog_admin = $data['total'];
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "blog WHERE  top = 'y' or sortop = 'y' AND type = 'blog'");
$log_top = $data['total'];
$data = $db->once_fetch_array('SELECT COUNT(*) AS total FROM ' . DB_PREFIX . 'blog WHERE type = \'blog\'');
$log_total = $data['total'];
$data = $db->once_fetch_array('SELECT COUNT(*) AS total FROM ' . DB_PREFIX . 'comment');
$log_com = $data['total'];
$data = $db->once_fetch_array('SELECT COUNT(*) AS total FROM ' . DB_PREFIX . 'link');
$log_link = $data['total'];
$data = $db->once_fetch_array('SELECT COUNT(*) AS total FROM ' . DB_PREFIX . 'sort');
$log_sort = $data['total'];
$data = $db->once_fetch_array('SELECT COUNT(*) AS total FROM ' . DB_PREFIX . 'tag');
$log_tag = $data['total'];
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "twitter");
$wei_yu = $data['total'];
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "blog WHERE type = 'page'");
$log_page = $data['total'];
$data = $db->once_fetch_array('SELECT COUNT(*) AS total FROM ' . DB_PREFIX . 'user');
$count_user = $data['total'];
$sql = 'SELECT * FROM ' . DB_PREFIX . 'blog WHERE type=\'blog\' ORDER BY date DESC LIMIT 0,1';
$res = $db->query($sql);
$row = $db->fetch_array($res);
$date = date('n月j日', $row['date']);
?>
<?php if($timehide==1):?>
<div class="widget widget_ui_statistics">
	<h3>网站统计</h3>
	<ul>
      	<?php $sta_cache = Cache::getInstance()->readCache('sta');?>
		<li><strong>用户总数：</strong><?php echo $count_user;?>位</li>
		<li><strong>置顶文章：</strong><?php echo $log_top;?>篇</li>
		<li><strong>标签总数：</strong><?php echo $log_tag;?>条</li>
		<li><strong>日志总数：</strong><?php echo $sta_cache['lognum']; ?>篇</li>
		<li><strong>评论总数：</strong><?php echo $sta_cache['comnum']; ?>条</li>
		<li><strong>微语总数：</strong><?php echo $sta_cache['twnum']; ?>条</li>
		<li><strong>运行天数：</strong><?php echo floor((time()-strtotime($Tconfig['timedate']))/86400); ?>天</li>
		<li><strong>最近更新：</strong><?php echo $date;?></li>
	</ul>
</div>
<?php endif;?>
</aside>