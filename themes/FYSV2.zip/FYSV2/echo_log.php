<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<section class="container">
<?php mianbao_sort($logid,$log_title);?>
</section>
<section class="container">
<div class="content-wrap">
	<article class="card">
	<?php if($Tconfig["ads"]== 1){?>
<header class="card__thumb"><a href="<?php echo $Tconfig["adurl3"];?>" target="_blank"><img data-thumb="default" src="<?php echo $Tconfig["adimg3"];?>" class="thumb"></a></header>
<?php }else{?>
<header class="card__thumb"><img data-thumb="default" src="<?php srand((double)microtime()*1000000);$randval = rand(1,7);echo TEMPLATE_URL.'images/random/'.$randval.'.jpg';?>" class="thumb"></header>
<?php }?>
	<date class="card__date">
	<span class="card__date__day"><?php echo gmdate('Y-n-j', $date); ?></span>
	</date>
	<div class="card__body">
		<div class="card__category">
			 分类：<?php blog_sort($logid); ?>
		</div>
		<h2 class="card__title"><a href="<?php echo kiny_curPageURL();?>"><?php topflg($top); ?><?php echo $log_title; ?></a></h2>
		<div class="card__subtitle">
			文章作者：<?php echo blog_author($author); ?>
		</div>
		<span><img src="http://qr.liantu.com/api.php?text=<?php echo kiny_curPageURL();?>"><small>手机扫码查看</small></span>
		<p class="card__description">
			<?php getZhidingLogs();?>
		</p>
	</div>
	<footer class="card__footer">
	<span><i class="fa fa-eye"></i> 阅读(<?php echo $views; ?>)</span>
	<span><i class="fa fa-comments-o"></i> 评论(<?php echo $comnum; ?>)</span>
	<span><a style="color:#50b7ff;" rel="external nofollow" title="一键帮忙提交给百度，谢谢您！" target="_blank" href="http://zhanzhang.baidu.com/sitesubmit/index?sitename=<?php echo kiny_curPageURL();?>">[卡得一笔暂时不搞]</a></span>
	</footer>
	</article>
	<div class="content">
		<header class="article-header">
		<h1 class="article-title"><a href="<?php echo kiny_curPageURL();?>"><?php topflg($top); ?><?php echo $log_title; ?></a></h1>
		<div class="article-meta">
			<span class="item"><i class="fa fa-clock-o"></i> <?php echo gmdate('Y-n-j', $date); ?></span>
			<span class="item"><i class="fa fa-folder-open"></i> 分类：<?php blog_sort($logid); ?></span>
			<span class="item"><i class="fa fa-eye"></i> 阅读(<?php echo $views; ?>)</span>
			<span class="item"><i class="fa fa-comments-o"></i> 评论(<?php echo $comnum; ?>)</span>
			<span class="item"><a style="color:#50b7ff;" rel="external nofollow" title="一键帮忙提交给百度，谢谢您！" target="_blank" href="http://zhanzhang.baidu.com/sitesubmit/index?sitename=<?php echo kiny_curPageURL();?>">[卡得一笔暂时不搞]</a></span>
			<span class="item"></span>
		</div>
		</header>
		<article class="article-content">
		<?php echo  reply_view($log_content,$logid);//文章回复可见?>
		</article>
		<?php if($Tconfig["ads"]== 1 ){?>
		<div class="asb-post-footer">
			<b>AD：</b><strong>【站长推荐】</strong><a href="<?php echo $Tconfig["adurl4"];?>"><?php echo $Tconfig["adtxt4"];?></a>
		</div>
		<?php }?>
		<div class="article-tags">
			<?php blog_tag($logid); ?>
		</div>
		<p class="iblue">
			<span style="color: #ff0000;">文章如无特别注明均为原创！</span>
			作者:
			<?php echo blog_author($author); ?>，
			转载或复制请以 
			<a href="<?php echo kiny_curPageURL();?>"> 超链接形式</a> 并注明出处 <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>。<br>
			原文地址《
			<a href="<?php echo kiny_curPageURL();?>"><?php topflg($top); ?><?php echo $log_title; ?></a>》发布于<?php echo gmdate('Y-n-j', $date); ?>
		</p>
		<div class="article-actions clearfix">
			<div class="shares">
				<strong>分享到：</strong>
				<a href="javascript:;" class="share-weixin" title="分享到微信"><i class="fa"></i>
				<span class="share-popover">
				<span class="share-popover-inner" id="weixin-qrcode">
				<img src="http://qr.liantu.com/api.php?text=<?php echo kiny_curPageURL();?>" modal="zoomImg" data-tag="bdshare">
				</span></span></a>
				<a target="_blank" href="https://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=<?php echo kiny_curPageURL();?>&amp;title=<?php topflg($top); ?><?php echo $log_title; ?>&amp;desc=&amp;summary=<?php getZhidingLogs();?>" class="share-qzone" title="分享到QQ空间"><i class="fa"></i></a>
				<a target="_blank" href="http://service.weibo.com/share/share.php?title=<?php topflg($top); ?><?php echo $log_title; ?>&amp;url=<?php echo kiny_curPageURL();?>&amp;source=<?php getZhidingLogs();?>" class="share-tsina" title="分享到新浪微博"><i class="fa"></i></a>
				<a target="_blank" href="http://share.v.t.qq.com/index.php?c=share&amp;a=index&amp;url=<?php echo kiny_curPageURL();?>&amp;title=<?php topflg($top); ?><?php echo $log_title; ?>" class="share-tqq" title="分享到腾讯微博"><i class="fa"></i></a>
				<a target="_blank" href="http://connect.qq.com/widget/shareqq/index.html?url=<?php echo kiny_curPageURL();?>&amp;desc=<?php getZhidingLogs();?>" class="share-sqq" title="分享到QQ好友"><i class="fa"></i></a>
				<a target="_blank" href="http://widget.renren.com/dialog/share?srcUrl=<?php get_thum($logid);?>&amp;resourceUrl=<?php echo kiny_curPageURL();?>&amp;title=<?php topflg($top); ?><?php echo $log_title; ?>&amp;description=<?php getZhidingLogs();?>" class="share-renren" title="分享到人人网"><i class="fa"></i></a>
				<a target="_blank" href="https://www.douban.com/share/service?image=<?php get_thum($logid);?>&amp;href=<?php echo kiny_curPageURL();?>&amp;name=<?php topflg($top); ?><?php echo $log_title; ?>&amp;text=<?php getZhidingLogs();?>" class="share-douban" title="分享到豆瓣网"><i class="fa"></i></a>
			</div>
            <?php doAction('ja_related', $logData); ?>
			<!--<a href="javascript:;" data-action="topTop" data-id="4391" class="dotGood action-like">
			<i class="fa"></i>赞
			<span class="count">0</span>
			</a>-->
			<a href="javascript:;" class="action-rewards" id="rewards"><i class="fa"></i>打赏</a>
		</div>
		<!-- 上一篇、下一篇功能 -->
		<nav class="pager" role="navigation">
		<?php neighbor_log($neighborLog, 'nextLog');?>
		<li class="next"></li>
		</nav>
		<!-- 上一篇、下一篇功能 -->
		<div class="pads">
			<ul id="tags_related">
			<?php
					$Log_Model = new Log_Model();
					$randlogs = $Log_Model->getLogsForHome("AND sortid = {$sortid} ORDER BY rand() DESC,date DESC", 1,3);
					foreach($randlogs as $value):
					if(pic_thumb($value['content'])){
                        $imgsrc = pic_thumb($value['content']);
	                }elseif(getThumbnail($value['logid'])){
	                    $imgsrc = getThumbnail($value['logid']);
	                }else{
	                    $imgsrc = TEMPLATE_URL.'images/random/'.substr($value['logid'],-1).'.jpg';
	                }
				?>
	<li><a href="<?php echo $value['log_url']; ?>"><img data-src="<?php echo $imgsrc; ?>" alt="<?php echo $value['log_title']; ?>" src="<?php echo $imgsrc; ?>" class="thumb" style="display: inline;">
	<h4><?php echo $value['log_title']; ?></h4>
	<time><?php echo gmdate('Y-n-j', $value['date']); ?></time></a></li>
<?php endforeach; ?>
</ul>
		</div>
		<div class="relates">
			<?php related_logs($logData);?>
		</div>
				<div class="title" id="comments">
	<h3>评论 <b></b></h3>
</div>
			<div id="comment-place">
			<div class="no_webshot" id="comment-post">
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
		</div>
		</div>
		<div id="postcomments">	
		<ol class="commentlist">
		<?php blog_comments($comments,$comnum); ?>
		</ol>
		</div>

	</div>
</div>
<?php include View::getView('side2'); ?>
</section>
<?php
 include View::getView('footer');
?>