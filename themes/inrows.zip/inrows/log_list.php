<?php 
/**
 * 首页文章列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="mainleft">
<div id="leftbox">
<?php doAction('index_loglist_top'); ?>

<?php 
if (!empty($logs)):
foreach($logs as $value): 
?>

						<div class="tit1"><h3><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h3></div>
						
						<div class="content">
						     
							<div id="conntenttit"> <!--文章作者栏-->
						
							<p class="date">【作者】<?php blog_author($value['author']); ?> 【发布于】<?php echo gmdate('Y-n-j G:i l', $value['date']); ?> 
							<?php blog_tag($value['logid']); ?>
	                        <?php blog_sort($value['logid']); ?> 
	                        <?php editflg($value['logid'],$value['author']); ?>
	                        </p>
							
							</div>
							
							<div id="neirong">
							
	                        <?php echo $value['log_description']; ?>
							
							</div>
						
						</div>

					<div class="nav"></div>
				
	<div style="clear:both;"></div>
<?php 
endforeach;
else:
?>
	<div class="tit1"><h3>未找到</h3></div>
	<div class="content">
	<div id="sorry">
	<p>抱歉，没有符合您查询条件的结果。</p>
	<p><img src="<?php echo TEMPLATE_URL; ?>img/sorry.gif"></img></p>
	</div>
	</div>
<?php endif;?>

<div id="pagelist">
    <ul>
	<li><?php echo $page_url;?></li>
	</ul>
</div>

</div><!-- end #leftbox-->
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>