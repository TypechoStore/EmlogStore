<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="mainleft">
<div id="leftbox">
	<div class="tit1"><h3><?php echo $log_title; ?></h3></div>
	<div class="content">
	<div id="neirong">
	<?php echo $log_content; ?>
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
	</div>
	</div>
</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>