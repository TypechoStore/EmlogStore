<?php
/*
Template Name:z2
Description:灰色风格单栏简洁主题
Version:v2.0
Author:emlog
Author Url:http://zld.me
Sidebar Amount:0
ForEmlog:5.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
if(function_exists('emLoadJQuery')) {
    emLoadJQuery();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="Emlog" />
<meta name="author" content="Sogei" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link type="text/css" href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" />
<?php doAction('index_head'); ?>

<!--[if lt ie 9]>
<script src="<?php echo TEMPLATE_URL; ?>js/ie.js"></script>
<![endif]-->
</head>
<body>
<div id="wrap">
<div id="header">
  <div class="logo">
    <h1><?php echo $blogname; ?></h1>
    <h3><?php echo $bloginfo; ?></h3>
  </div>
  <ul>
    <li><a title="订阅自留地" class="rss" href="<?php echo BLOG_URL; ?>rss.php" target="_blank"></a></li>
    <li><a title="Sogei的腾讯微博" class="tqq" href="http://t.qq.com/FreeSogei" target="_blank"  rel="nofollow"></a></li>
    <li><a title="给Sogei发邮件" class="mail" href="mailto:admin@zld.me"  rel="nofollow"></a></li>
  </ul>
</div>
<?php blog_navi();?>
<!-- end #header-->
<div id="bomb">
  <?php {
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
  <ul class="recentcomments">
    <h3>最新评论</h3>
    <?php
	foreach($com_cache as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	?>
    <li><img src="http://www.gravatar.com/avatar/<?php  echo md5($value['mail']); ?>" width="28" height="28" class="avatar" title="<?php echo $value['name']; ?>" /><?php echo $value['name']; ?> <br />
      <a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a></li>
    <?php endforeach; ?>
  </ul>
  <?php }?>
  <div class="arrow"></div>
</div>
