<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="content">
  <div class="post div">
    <h2>
      <?php topflg($top); ?>
      <?php echo $log_title; ?></h2>
    <div class="data"> <span class="post-time">
      <?php blog_author($author); ?>
      post by：<?php echo gmdate('Y-n-j G:i l', $date); ?></span> <span class="post-sort">Posted in
      <?php blog_sort($logid); ?>
      </span> <span class="post-count" id="go-comments"><a title="点我快速查看评论" href="javascript:void()"><?php echo $comnum; ?>条评论</a></span> <span class="post-views"><?php echo $views; ?>人围观</span> </div>
    <div class="post-content"> <?php echo $log_content; ?>
      <div class="post-footer"> <span class="post-tag">Tags:
        <?php blog_tag($logid); ?>
        </span> </div>
      <div id="copyright">»版权所有：《<a href="<?php echo BLOG_URL; ?>" title="<?php echo $blogname; ?>"><?php echo $blogname; ?></a>》 → 《<a title="<?php echo $log_title; ?>" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];?>"><?php echo $log_title; ?></a>》；<br>
        »本文网址：<a title="<?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];?>" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];?>"><?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];?></a> ；<br>
        »除特别标注,本博客所有文章均为原创. 互联分享,尊重版权,转载请以链接形式标明本文地址 ； </div>
      <div class="dshare-col"> 分享到：<a class="dshare ds_tqq">腾讯微博</a><a class="dshare ds_qzone">QQ空间</a><a class="dshare ds_tsina">新浪微博</a><a class="dshare ds_renren">人人网</a><a class="dshare ds_kaixin">开心网</a><a class="dshare ds_douban">豆瓣</a> </div>
    </div>
  </div>
  <?php neighbor_log($neighborLog); ?>
  <?php blog_comments($comments,$params); ?>
  <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
  <?php blog_trackback($tb, $tb_url, $allow_tb); ?>
</div>
</div>
</div>
<?php
 include View::getView('footer');
?>
