jQuery(function($){
	$('ul.dynamic img').each(function(i, o){
		var me = $(o);
		var deg = Math.round(Math.random()*20)-10;
		var h = Math.round(Math.random()*5)-5;
		me.css('-webkit-transform', 'rotate('+deg+'deg)')
			.css('-moz-transform', 'rotate('+deg+'deg)')
			.css('-o-transform', 'rotate('+deg+'deg)')
			.css('margin-top', h)
			.css('margin-bottom', -h);

		me.hover(function(){
			var tilt = Math.round(Math.random()*10)-5;
			me.css('-webkit-transform', 'rotate('+tilt+'deg)').css('-moz-transform', 'rotate('+tilt+'deg)').css('-o-transform', 'rotate('+tilt+'deg)');
		}, function(){
			me.css('-webkit-transform', 'rotate('+deg+'deg)').css('-moz-transform', 'rotate('+deg+'deg)').css('-o-transform', 'rotate('+tilt+'deg)');
		});
	});
});