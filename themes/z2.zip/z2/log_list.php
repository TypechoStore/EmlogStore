<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<div id="content">
  <?php doAction('index_loglist_top'); ?>
  <?php foreach($logs as $value): ?>
  <div class="post div">
    <h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
    <div class="data"> <span class="post-time"><?php echo gmdate('Y-n-j', $value['date']); ?></span> 
    <span class="post-sort">Posted in <?php blog_sort($value['logid']); ?></span>
    <span class="post-count"><a href="<?php echo $value['log_url']; ?>#comments" title="查看 <?php echo $value['log_title']; ?> 上的评论"><?php echo $value['comnum']; ?>条评论</a></span>
    <span class="post-views"><?php echo $value['views']; ?>人围观</span>
      <?php editflg($value['logid'],$value['author']); ?>
    </div>
    <div class="post-content"> <?php echo $value['log_description']; ?>
      <div class="post-footer"> <span class="post-tag">Tags:
        <?php blog_tag($value['logid']); ?>
        </span> </div>
    </div>
  </div>
  <?php endforeach; ?>
  <div id="pagenavi"> <?php echo $page_url;?> </div>
  <div class="col div">
    <div class="col1">
      <h3>彩色标签</h3>
      <ul class="blogtags">
        <?php {
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
        <?php shuffle($tag_cache);foreach($tag_cache as $value): $color = dechex(rand(0,16777215));?>
        <span style="font-size:<?php echo $value['fontsize']; ?>pt; line-height:12px;"> <a href="<?php echo Url::tag($value['tagurl']); ?>" title="标签为 <?php echo $value['tagname']; ?> 的日志有 <?php echo $value['usenum']; ?> 篇" style="color:#<?php echo $color;?>"><?php echo $value['tagname']; ?></a></span>
        <?php endforeach; ?>
        <?php }?>
      </ul>
    </div>
    <ul class="col2">
      <?php {
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
      <h3>随便看看</h3>
      <?php foreach($randLogs as $value): ?>
      <li><a href="<?php echo Url::log($value['gid']); ?>" title="<?php echo $value['title']; ?>"><?php echo $value['title']; ?></a></li>
      <?php endforeach; ?>
      <?php }?>
    </ul>
    <ul class="col3">
      <h3>关注热点</h3>
      <?php
			$date = time() - 3600 * 24 * 60;
			$Log_Model = new Log_Model();
			$hotlogs = $Log_Model->getLogsForHome("AND date > {$date} ORDER BY comnum DESC,date DESC", 1, 5);
			foreach($hotlogs as $key=>$value): ?>
      <li><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['title']; ?>"><?php echo $value['title']; ?></a></li>
      <?php endforeach;?>
    </ul>
  </div>
  <div class="links div">
    <h3>最有价值</h3>
    <?php {
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
	?>
    <ul>
      <?php foreach($link_cache as $value): ?>
      <li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
      <?php endforeach; ?>
    </ul>
    <?php }?>
  </div>
</div>
</div>
<!-- end #content-->
<?php
 include View::getView('footer');
?>
