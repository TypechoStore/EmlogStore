<?php 
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="footer">
    <div class="credits"> &copy; 2011 <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a> <?php echo $footer_info; ?> / Powered by <a href="http://www.emlog.net" title="emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">emlog</a> / Theme <a title="z2 v1.0" href="http://zld.me" target="_blank">z2</a>  
     <?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
       / <a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a> / <a href="<?php echo BLOG_URL; ?>admin/">管理中心</a> / <a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a>
        <?php else: ?>
       / <a href="<?php echo BLOG_URL; ?>admin/" rel="nofollow">Login</a>
        <?php endif; ?>
    </div>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/common_tpl.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/z2.js"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/lazyload.js"></script>
<script type="text/javascript">
jQuery(document).ready(function($){if(navigator.platform=="iPad")return;jQuery("img").lazyload({effect:"fadeIn",placeholder:"<?php echo TEMPLATE_URL; ?>images/grey.gif"})});
</script>
        <link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>phZoom/phzoom.css" />
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>phZoom/phzoom.js"></script>
    <?php doAction('index_footer'); ?>
  </div><!--end #footerbar-->
  <div id="go-top"><a class="go-top" href="javascript:void()"></a></div>
</body>
</html>