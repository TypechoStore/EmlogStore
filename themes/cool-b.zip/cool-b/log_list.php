<?php
/*
 *首页日志列表部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div id="frame_content">
<div id="content">
<?php doAction('index_loglist_top'); ?>
<?php foreach($logs as $value): ?>
<div class="content-box">
	<div class="thum">
		<div class="pho">
    <?php
    //获取缩略图
    $template_name = str_replace(BLOG_URL,"",TEMPLATE_URL);
    $template_name = str_replace("content/templates/","",$template_name);
    $template_name = str_replace("/","",$template_name); //获取模板目录名称
    $thum_file = EMLOG_ROOT.'/content/templates/'.$template_name.'/thumbnail/'.$value['gid'].'.jpg';
    if (is_file($thum_file)) {
        $thum_src = TEMPLATE_URL.'/thumbnail/'.$value['gid'].'.jpg';
    }else{
        $rand_num = 0; //随机图片数量，按实际数量设置
        if ($rand_num == 0) {
            $thum_src = TEMPLATE_URL.'thumbnail/0.jpg';
            //默认图片须命名为"0.jpg"
        }else{
            $thum_src = TEMPLATE_URL.'thumbnail/rand'.rand(1,$rand_num).'.jpg';
            //随机图片须按"rand1.jpg","rand2.jpg",...的顺序命名
        }
        //上述默认图片与随机图片须保存在模板目录中的"thumbnail"目录下
    } ?>
    <a href="<?php echo $value['log_url']; ?>"><img src="<?php echo $thum_src; ?>" /></a>
		</div>
	</div>
	<div class="desc">
		<div class="desc_tit">
		&nbsp;<font class="top"><?php topflg($value['top']); ?></font><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
		</div>
		<div class="desc_txt">
			<a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_description']; ?></a>
			<div class="clear"></div>
		</div>
  <!--非图形附件列表，5.0己非必须-->
  <!--<div class="att"><?php //blog_att($value['logid']); ?></div>-->
		<div class="desc_ps">
		 <?php //echo $value['gid']; ?> &nbsp; <?php editflg($value['logid'],$value['author']); ?> &nbsp; <a href="<?php echo $value['log_url']; ?>#comments">评论(<?php echo $value['comnum']; ?>)</a> &nbsp; <a href="<?php echo $value['log_url']; ?>">浏览(<?php echo $value['views']; ?>)</a>
		</div>
	</div>
	<div class="addi">
		<div class="log_sort"><?php blog_sort($value['logid']); ?></div>
		&nbsp;<?php echo blog_author($value['author']); ?>&nbsp;发布于<br />
		<div class="date">&nbsp;<?php echo gmdate('Y-n-j', $value['date']); ?>&nbsp;</div>
		<div class="tag"><?php echo blog_tag($value['gid']); ?></div>
	</div>
	<div class="clear"></div>
</div>
<div style="height:1px; border-bottom:1px dotted #333; overflow:hidden;"></div>
<?php endforeach; ?>
<div class="blank"></div>
<div id="pagenavi"><?php echo $page_url; ?></div>
</div><!--#content.End-->
</div><!--#frame_content.End-->
<div id="frame_right"></div>
<?php
	//include View::getView('side');
	include View::getView('footer');
?>