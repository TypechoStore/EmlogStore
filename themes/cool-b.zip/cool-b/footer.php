<?php
/*
* 底部信息
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div class="clear"></div>
</div><!--#frame.End-->
</div><!--#wrap.End-->
<div id="footerbar">
	<a name="bottom"></a><!--设置底部锚点-->
	&nbsp; &nbsp;<a href=# target=_self><?php echo $blogname; ?></a> &copy; 2012 &nbsp; Powered by <a href="http://www.emlog.net/" title="Emlog <?php echo Option::EMLOG_VERSION;?>" target="_blank">Emlog</a> &nbsp; Designed by <a href="http://emlog8.sinaapp.com/" target="_blank">Emlog吧</a> &nbsp; <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> &nbsp; <?php doAction('index_footer'); ?> &nbsp; <?php echo $footer_info; ?>
	<div id="logon">
		<?php if(ROLE == 'admin' || ROLE == 'writer'): ?>
		<a href="<?php echo BLOG_URL; ?>admin/write_log.php">写日志</a>
		<a href="<?php echo BLOG_URL; ?>admin/">管理</a>
		<a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a>&nbsp;
		<?php else: ?>
		<a href="<?php echo BLOG_URL; ?>admin/">登录</a>&nbsp;
		<?php endif; ?>
	</div>
</div>
<div class="blank"></div>
<!-- 无觅相关日志插件 -->
<div id="wumii" style="z-index:999; display:none;">
<?php
if ($type == 'blog') { echo <<<LOADSCRIPT
<script type="text/javascript">
    var wumiiParams = "&num=5&mode=2&pf=emlog";
</script>
<script type="text/javascript" id="wumiiRelatedItems" src="http://widget.wumii.com/ext/relatedItemsWidget.htm"></script>
<a href="http://www.wumii.com/widget/relatedItems.htm" style="border:0;">
    <img src="http://static.wumii.com/images/pixel.png" alt="无觅相关文章插件，快速提升流量" style="border:0;padding:0;margin:0;" />
</a>
LOADSCRIPT;
}
?>
</div>
<!-- 无觅相关日志插件.End -->
<!-- Baidu Button BEGIN -->
<script type="text/javascript" id="bdshare_js" data="type=tools" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
	document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?t=" + new Date().getHours();
</script>
<!-- Baidu Button END -->
</body>
</html>
