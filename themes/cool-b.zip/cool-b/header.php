<?php
/*
Template Name: Cool-B (单栏)
Description: 酷黑。。。
Version: 1.5.0
Author: yuadao
Author Url: http://emlog8.sinaapp.com/
Sidebar Amount: 1
ForEmlog: 5.0.x
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once (View::getView('module'));
if(function_exists('emLoadJQuery')) {emLoadJQuery();}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<link rel="icon" href="favicon.gif" type="image/gif" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>style_nav.css" rel="stylesheet" type="text/css" />
<!--[if IE]>
<link href="<?php echo TEMPLATE_URL; ?>style_ie.css" rel="stylesheet" type="text/css" />
<![endif]-->
<!--[if lt IE 7]>
<link href="<?php echo TEMPLATE_URL; ?>style_ie6.css" rel="stylesheet" type="text/css" />
<![endif]-->
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>

<body>
<div id="topbar">
<div id="top">
	<a href="#" target="_self">你的站点</a> &nbsp;
	<a href="#" target="_self">你的站点</a> &nbsp;
	<a href="#" target="_self">你的站点</a> &nbsp;
    <div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare" style="float:right;">
        <a class="bds_qzone"></a>
        <a class="bds_tsina"></a>
        <a class="bds_tqq"></a>
        <a class="bds_renren"></a>
        <span class="bds_more"></span>
		      <!--<a class="shareCount"></a>-->
    </div>
</div>
</div>
<div id="#anchor">
	<a name="top"></a><!--设置顶部锚点-->
</div>
<div id="header">
	<div id="logo">
		<a href="<?php echo BLOG_URL; ?>" target="_self"><img src="<?php echo TEMPLATE_URL; ?>images/logo.gif" height="60" border="0"></a>
	</div>
 <div id="nav"><?php blog_navi();?></div><!--导航栏-->
	<div id="serch">
		<form id="searchform" name="keyform" action="<?php echo BLOG_URL; ?>" method="get" >
		<input type="text" value="搜一搜…" onfocus="this.value=''" name="keyword" id="s" />
		</form>
	</div>
	<br style="clear:both;" />
</div>
<div id="wrap"><!--内容外框-->
	<div id="frame"><!--IE专用外框-->
		<div id="frame_list">&nbsp;</div>
<!--herder.End-->
