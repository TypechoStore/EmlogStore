<?php 
/*
* 自建页面模板
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div style="width:970px; height:30px;"></div>
<div id="content">
<div id="contentleft">
<div class="main">
	<div class="main-border">
	<h2 style="font-size:20px; padding:25px 0px 10px 0px; font-weight:bold;"><?php echo $log_title; ?></h2>
	<?php echo $log_content; ?>
	</div>
</div>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<?php blog_comments($comments,$allow_remark,$params,$comnum); ?>
	<div style="clear:both;"></div>
</div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>