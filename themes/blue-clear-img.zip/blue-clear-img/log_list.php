<?php 
/*
* 首页日志列表部分
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
<div style="padding-top:5px; width:970px; height:25px;">
<?php doAction('index_loglist_top'); ?>
</div>
<div id="contentleft">
	<?php foreach($logs as $value):
	//获取媒体信息
	preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
	$imgsrc = !empty($img[1]) ? $img[1][0] : '';
	//获取缩略图片
	$logimg = $value['gid'].".jpg";
	$logimg_file = EMLOG_ROOT."/content/templates/".get_template_name()."/gid/".$logimg;
	$logimg_src = BLOG_URL."content/templates/".get_template_name()."/gid/".$logimg;
	$logimg_src0 = TEMPLATE_URL."images/rand/".rand(1,8).".jpg";
	?>
	<div class="main">
	<div class="main-border">
	<div class="unit">
		<div class="pho">
		<a href="<?php echo $value['log_url']; ?>">
		<?php
		if (is_file($logimg_file)){
			echo "<img src='".$logimg_src."' />";
			}
		else{
			if($imgsrc) {echo "<img src='".$imgsrc."' />";}
			else {
				echo "<img src='".$logimg_src0."' />";
				}
			}
		?>
		</a>
		</div>
		<div class="main-txt">
		<div class="main-title">
		<h2><?php topflg($value['top']); ?><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></h2>
		<span>On <?php echo gmdate('m.d.y', $value['date']); ?>&nbsp;,
		<a href="<?php echo $value['log_url']; ?>#comments"><?php echo $value['comnum']; ?> Comments</a>&nbsp;
		<a href="<?php echo $value['log_url']; ?>"><?php echo $value['views']; ?> Views</a>
		<?php editflg($value['logid'],$value['author']); ?>
		<span>
		</div>
		<div class="note-list"><?php echo $value['log_description']; ?></div>
		</div>
		<div class="clear"></div>
	</div><!--unit end-->
	</div>
	<div class="tag-readmore">
		<span class="tag"><?php blog_sort($value['logid']); ?></span>
		<span class="readmore1"><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>">阅读全文</a></span>
	</div>
	</div>
	<div style="clear:both;"></div>
<?php endforeach; ?>

<div id="pagenavi">
<!--<span>共<?php echo ceil($sta_cache['lognum']/$index_lognum);?>页</span>-->
	<?php echo $page_url;?>
</div>
<div style="height:20px;"></div>

</div><!-- end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>