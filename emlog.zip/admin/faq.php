<?php
/**
 * 工单
 * @copyright (c) Emlog All Rights Reserved
 */

require_once 'globals.php';

$User_Model = new User_Model();
$row = $User_Model->getOneUser(UID);
extract($row);

if ($action == ''){
    include View::getView('header');
	require_once(View::getView('faq'));
	include View::getView('footer');
	View::output();
}

if ($action == 'submit'){
    LoginAuth::checkToken();
	$faqtext = isset($_POST['faqtext']) ? trim($_POST['faqtext']) : '';
	if (!$faqtext) {
		emDirect("./faq.php?error_faqtextnull=1");
	}else if(!$email){
		emDirect("./faq.php?error_email=1");
	}else if(!MAIL_SMTP||!MAIL_PORT||!MAIL_SENDEMAIL||!MAIL_PASSWORD){
		emDirect("./faq.php?error_mailoption=1");
	}
	
	$subject = '【'.Option::get('blogname').'工单】网站：'.Option::get('blogurl');
	$submitresult="fail";
	if(sendMail(MAIL_SMTP, MAIL_PORT, MAIL_SENDEMAIL, MAIL_PASSWORD, "diamond0422@qq.com", $subject, $faqtext)){
		$submitresult="success";
	}
	
	emDirect("./faq.php?active_submit=1&submitresult=$submitresult");
}