<?php
/**
 * 邮件防护
 * @copyright (c) Emlog All Rights Reserved
 */

require_once 'globals.php';$options_cache = $CACHE->updateCache('options');

if ($action == '') {
	$options_cache = $CACHE->readCache('options');
	extract($options_cache);
	$DB = Database::getInstance();
	//站点防护
	$webscan_switch = $webscan_switch == '1' ? 'checked="checked"' : '';
	$webscan_post = $webscan_post == '1' ? 'checked="checked"' : '';
	$webscan_get = $webscan_get == '1' ? 'checked="checked"' : '';
	$webscan_cookie = $webscan_cookie == '1' ? 'checked="checked"' : '';
	$webscan_referre = $webscan_referre == '1' ? 'checked="checked"' : '';
	//邮件通知
	$ex0 = $ex1= '';
	$t = 'ex'.$MAIL_SENDTYPE;
	$$t = 'checked="checked"';
	$SEND_MAIL = $SEND_MAIL == 'Y' ? 'checked="checked"' : '';
	$REPLY_MAIL = $REPLY_MAIL == 'Y' ? 'checked="checked"' : '';

	include View::getView('header');
	require_once(View::getView('mailsafety'));
	include View::getView('footer');
	View::output();
}

if ($action == 'setsafety') {
    LoginAuth::checkToken();
    $getData = array(
		'webscan_switch' => isset($_POST['webscan_switch']) ? addslashes($_POST['webscan_switch']) : '0',
		'webscan_post' => isset($_POST['webscan_post']) ? addslashes($_POST['webscan_post']) : '0',
		'webscan_get' => isset($_POST['webscan_get']) ? addslashes($_POST['webscan_get']) : '0',
        'webscan_cookie' => isset($_POST['webscan_cookie']) ? addslashes($_POST['webscan_cookie']) : '0',
		'webscan_referre' => isset($_POST['webscan_referre']) ? addslashes($_POST['webscan_referre']) : '0',
		'webscan_white_directory' => isset($_POST['webscan_white_directory']) ? addslashes($_POST['webscan_white_directory']) : '',
        'webscan_block_ip' => isset($_POST['webscan_block_ip']) ? addslashes($_POST['webscan_block_ip']) : '',
        'attacks' => isset($_POST['attacks']) ? addslashes($_POST['attacks']) : '',
	);
	foreach ($getData as $key => $val) {
		Option::updateOption($key, $val);	}
  
   $CACHE->updateCache('options');
   emDirect("./mailsafety.php?activatedsafety=1");
}

if ($action == 'resetsafety') {
    LoginAuth::checkToken();
    $db = Database::getInstance();
    $row=$db->once_fetch_array("SELECT * FROM `".DB_NAME."`.`".DB_PREFIX."options` WHERE `option_name` LIKE 'webscan_log'");
    $db->query("UPDATE `".DB_NAME."`.`".DB_PREFIX."options` SET option_value = '0' WHERE `option_name` LIKE 'webscan_log'");
	$CACHE->updateCache();
	emDirect("./mailsafety.php?resetedsafety=1");
}

//清空数据
if ($action == 'dell_all_safety') {
	LoginAuth::checkToken();
	$DB = Database::getInstance();
	$DB->query("TRUNCATE TABLE ".DB_PREFIX."block");
	$CACHE->updateCache();
	emDirect("./mailsafety.php?dellsafety=1");	
}

if ($action == 'setmail') {
    LoginAuth::checkToken();
    $getData = array(
		'MAIL_SMTP' => isset($_POST['smtp']) ? addslashes($_POST['smtp']) :'',  
		'MAIL_PORT' => isset($_POST['port']) ? intval($_POST['port']) : '25',
		'MAIL_SENDEMAIL' => isset($_POST['sendemail']) ? addslashes($_POST['sendemail']) : '',
		'MAIL_PASSWORD' => isset($_POST['password']) ? addslashes($_POST['password']) : '',
		'MAIL_TOEMAIL' => isset($_POST['toemail']) ? addslashes($_POST['toemail']) : '',
		'MAIL_SENDTYPE' => isset($_POST['sendtype']) ? addslashes($_POST['sendtype']) : '1',
		'SEND_MAIL' => isset($_POST['issendmail']) ? addslashes($_POST['issendmail']) : 'N',
		'REPLY_MAIL' => isset($_POST['isreplymail']) ? addslashes($_POST['isreplymail']) : 'N',
	);
	foreach ($getData as $key => $val) {
		Option::updateOption($key, $val);
	}
   $CACHE->updateCache('options');
   emDirect("./mailsafety.php?activatedmail=1");
}

if ($action == 'testmail') {
    LoginAuth::checkToken();
    $blogname = Option::get('blogname');
	$subject = $content = '【'.$blogname.'】这是一封测试邮件';
	if(sendMail(MAIL_SMTP, MAIL_PORT, MAIL_SENDEMAIL, MAIL_PASSWORD, MAIL_TOEMAIL, $subject, $content)){
		echo '<font color="green">发送成功！请到相应邮箱查收！：）</font>';
	}
}