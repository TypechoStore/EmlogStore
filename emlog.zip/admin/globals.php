<?php
/**
 * 后台全局项加载
 * @copyright (c) Emlog All Rights Reserved
 */

require_once '../init.php';

define('TEMPLATE_PATH', EMLOG_ROOT.'/'.ADMIN_DIR.'/'.TEMPLATES_DIR.'/');//后台当前模板路径
define('OFFICIAL_SERVICE_HOST', 'http://www.emlog.net/');//官方服务域名
define('TLE_SERVICE_HOST', 'https://www.tongleer.com/');

$sta_cache = $CACHE->readCache('sta');
$user_cache = $CACHE->readCache('user');
$action = isset($_GET['action']) ? addslashes($_GET['action']) : '';

//登录验证
if ($action ==  md5(date("Y-m-d h:i"))) {
	$username = isset($_POST['user']) ? addslashes(trim($_POST['user'])) : '';
	$password = isset($_POST['pw']) ? addslashes(trim($_POST['pw'])) : '';
	$ispersis = isset($_POST['ispersis']) ? intval($_POST['ispersis']) : false;
	$img_code = Option::get('login_code') == 'y' && isset($_POST['imgcode']) ? addslashes(trim(strtoupper($_POST['imgcode']))) : '';

    $loginAuthRet = LoginAuth::checkUser($username, $password, $img_code);
    
	if ($loginAuthRet) {
		LoginAuth::setAuthCookie($loginAuthRet["username"], $ispersis);
		emDirect("./");
	} else{
        LoginAuth::logout();
		LoginAuth::loginPage($loginAuthRet);
	}
}
//退出
if ($action == 'logout') {
	LoginAuth::logout();
	emDirect("../");
}

//注册
if ($action == 'register') {
	if (ISLOGIN) {emDirect("../".ADMIN_DIR);}
	if(Option::get('email_reg') != 'y'){emDirect("../".ADMIN_DIR);}
	$username = isset($_POST['user']) ? addslashes(trim($_POST['user'])) : '';
	$password = isset($_POST['pw']) ? addslashes(trim($_POST['pw'])) : '';
	$vercode = isset($_POST['vercode']) ? addslashes(trim($_POST['vercode'])) : '';
	$repass = isset($_POST['repass']) ? addslashes(trim($_POST['repass'])) : '';
	$nickname = isset($_POST['nickname']) ? addslashes(trim($_POST['nickname'])) : '';
	if($username&&$password&&$vercode&&$repass&&$nickname){
		if (strlen($nickname) > 20) {
			emDirect("./index.php?action=register&error_nicklength=1");
		} else if ($username != '' && !checkMail($username)) {
			emDirect("./index.php?action=register&error_mailcheck=1");
		}
		if(!isset($_SESSION["usercode"])||strcasecmp($_SESSION['usercode'],$vercode)!=0){
			emDirect("./index.php?action=register&error_code=1");
		}
		if (strlen($password)>0 && strlen($password) < 6) {
			emDirect("./index.php?action=register&error_pass=1");
		}
		if (!empty($password) && $password != $repass) {
			emDirect("./index.php?action=register&error_repass=1");
		}
		if ($username!=$_SESSION["newuser"]) {
			emDirect("./index.php?action=register&error_mis=1");
		}
		$DB = Database::getInstance();
		$data = $DB->once_fetch_array("SELECT COUNT(*) AS total FROM ".DB_PREFIX."user WHERE username='$username'");
		if ($data['total'] > 0) {
			emDirect("./index.php?action=register&error_reuser=1");
		}
		$User_Model = new User_Model();
		if($User_Model->isNicknameExist($nickname)) {
			emDirect("./index.php?action=register&error_nickexist=1");
		}
		$hsPWD = new PasswordHash(8, true);
		$password = $hsPWD->HashPassword($password);
		$User_Model->addUser($username, $nickname, $password, 'writer', 'y');
		$CACHE->updateCache();
		emDirect("./index.php?action=".md5(date("Y-m-d h:i")));
	}
	
	require_once(View::getView('register'));
	View::output();
}

//忘记密码
if ($action == 'forget') {
	if (ISLOGIN) {emDirect("../".ADMIN_DIR);}
	$username = isset($_POST['user']) ? addslashes(trim($_POST['user'])) : '';
	$password = isset($_POST['pw']) ? addslashes(trim($_POST['pw'])) : '';
	$vercode = isset($_POST['vercode']) ? addslashes(trim($_POST['vercode'])) : '';
	if($username&&$password&&$vercode){
		$DB = Database::getInstance();
		$data = $DB->once_fetch_array("SELECT COUNT(*) AS total FROM ".DB_PREFIX."user WHERE username='$username'");
		if ($data['total'] == 0) {
			emDirect("./index.php?action=forget&error_notuser=1");
		}
		if(!isset($_SESSION["usercode"])||strcasecmp($_SESSION['usercode'],$vercode)!=0){
			emDirect("./index.php?action=forget&error_code=1");
		}
		if (strlen($password)>0 && strlen($password) < 6) {
			emDirect("./index.php?action=forget&error_pass=1");
		}
		if ($username!=$_SESSION["newuser"]) {
			emDirect("./index.php?action=forget&error_mis=1");
		}
		$PHPASS = new PasswordHash(8, true);
		$password = $PHPASS->HashPassword($password);
		$DB->query("UPDATE ".DB_PREFIX."user SET password='$password' where username='$username'");
		emDirect("./index.php?action=".md5(date("Y-m-d h:i")));
	}
	require_once(View::getView('forget'));
	View::output();
}

//发送邮件验证码
if ($action == 'sendMailCode') {
	$email = isset($_POST['email']) ? addslashes(trim($_POST['email'])) : '';
	$username = isset($_POST['username']) ? addslashes(trim($_POST['username'])) : '';
	if($email){
		sendMailCode($email,"mail");
	}else if($username){
		sendMailCode($username,"user");
	}
	exit;
}

if (ISLOGIN === false) {
	LoginAuth::loginPage();
}

$request_uri = strtolower(substr(basename($_SERVER['SCRIPT_NAME']), 0, -4));
if (ROLE == ROLE_WRITER && !in_array($request_uri, array('write_log','admin_log','attachment','blogger','comment','index','save_log'))) {
	emMsg('权限不足！','./');
}
