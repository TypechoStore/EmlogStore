<?php
	if(!defined('EMLOG_ROOT')) {exit('error!');} 
	
	$url = './views/data/store.json';
	$file = file_get_contents($url);
	$output = json_decode($file);
?>
<div>
	<fieldset class="layui-elem-field layui-field-title">
	  <legend>
		<b>应用商店</b>
		<small><a href="./store.php?action=insupdata&type=data&source=<?php echo $site_store_data  ?>&token=<?php echo LoginAuth::genToken(); ?>" class="layui-btn layui-btn-primary layui-btn-xs">更新数据</a></small>
	  </legend>
	</fieldset>
</div>

<form action="store.php" method="get" id="search-form">
	<input id="keywords" type="text" name="keyword" lay-verify="keyword" autocomplete="off" placeholder="输入插件和模板关键词，回车开始搜索" class="layui-input">
</form>

<div class="layui-tab layui-tab-card">
  <ul class="layui-tab-title">
	<?php if(isset($_GET["keyword"])){?>
	<li class="layui-this">搜索</li>
	<?php }else{ ?>
    <li class="layui-this">模板</li>
    <li>插件</li>
	<?php }?>
  </ul>
  <div class="layui-tab-content" style="background-color:#fff;">
	<?php
	$keyword = isset($_GET['keyword']) ? addslashes($_GET['keyword']) : '';
	if(!empty($keyword)){
		$json = file_get_contents($url);
		$arr = json_decode(trim($json, chr(239) . chr(187) . chr(191)), true);
	?>
	<div class="layui-tab-item layui-show">
		<table class="layui-table">
			<thead>
				<tr>
					<th>序号</th><th>名称</th><th>作者</th><th>预览</th><th>版本</th><th>更新时间</th><th>操作</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$newArr=array();
				foreach($arr as $val){
					if(strpos($val["name"],$keyword) === false&&strpos($val["username"],$keyword) === false&&strpos($val["des"],$keyword) === false){
						continue;
					}
					array_push($newArr,$val);
				}
				
				$isSearch=false;
				if(count($newArr)>0){
					
					$page_now = isset($_GET['page_now']) ? intval($_GET['page_now']) : 1;
					if($page_now<1){
						$page_now=1;
					}
					$page_rec=Option::get('admin_perpage_num');
					$totalrec=count($newArr);
					$page=ceil($totalrec/$page_rec);
					if($page_now>$page){
						$page_now=$page;
					}
					if($page_now<=1){
						$before_page=1;
						if($page>1){
							$after_page=$page_now+1;
						}else{
							$after_page=1;
						}
					}else{
						$before_page=$page_now-1;
						if($page_now<$page){
							$after_page=$page_now+1;
						}else{
							$after_page=$page;
						}
					}
					$searchArr = array_slice($newArr, ($page_now-1)*$page_rec, $page_rec);
					
					foreach($searchArr as $val){
						if(strpos($val["name"],$keyword) === false&&strpos($val["username"],$keyword) === false&&strpos($val["des"],$keyword) === false){
							continue;
						}
						$isSearch=true;
						?>
						<tr>
							<td><?php echo $val["id"]; ?></td>
							<td><?php if($val["type"]=="tpl"){echo "[模板]";}else if($val["type"]=="pls"){echo "[插件]";}?><?php echo $val["name"]; ?></td>
							<td><?php echo $val["username"]; ?></td>
							<td>
								<a class="searchshow" id="searchshow<?php echo $val["id"]; ?>" href="javascript:;" data-pic="<?php echo $val["pic"]  ?>" data-name="<?php echo $val["name"]; ?>" data-des="<?php echo $val["des"]; ?>">
									<img src="./views/images/vlog.gif" align="top" title="" />
								</a>
							</td>
							<td><?php echo $val["version"]; ?></td>	
							<td><?php echo $val["date"]; ?></td>
							<td>
								<?php if(($val["type"]=="tpl"&&is_dir(TPLS_PATH.$val["dir"]))||($val["type"]=="pls"&&is_dir(TPLS_PATH."../plugins/".$val["dir"]))){?>
								已安装
								<?php }else{?>
								<a href="./store.php?action=insplu&type=<?php echo $val["type"];?>&source=<?php echo $val["remark"];?>&token=<?php echo LoginAuth::genToken(); ?>">安装</a>
								<?php }?>
							</td>
						</tr>
						<?php
					}
					?>
					<tr>	
						<td colspan="7">
							<center><div id="searchpage"></div></center>
							<center>(有<?php echo $totalrec; ?>条记录)</center>
						</td>
					</tr>
					<?php
				}
				if(!$isSearch){
					?>
					<tr>	
						<td colspan="7">未搜到该关键词</td>
					</tr>
					<?php
				}
				?>	
			</tbody>
		</table>
	</div>
	<script>
	$(function(){
		layui.use(["laypage", "layer", "form"], function(){
			var layer = layui.layer;
			var form = layui.form;
			var laypage = layui.laypage;
			laypage.render({
				elem: "searchpage"
				,count: <?=$totalrec;?>
				,limit: <?=Option::get('admin_perpage_num');?>
				,curr:<?=$page_now;?>
				,layout: ["prev", "page", "next", "skip"]
				,jump: function(obj,first){
					if(!first){
					  location.href="store.php?keyword=<?=$keyword;?>&page_now="+obj.curr;
					}
				}
			});
			$(".searchshow").each(function(){
				var id=$(this).attr("id");
				$("#"+id).click( function () {
					layer.open({
						type: 1
						,title:$(this).attr("data-name")
						,area: ['60%', '100%']
						,offset: "auto"
						,id: 'searchshow'+id
						,content: '<center><div><a href="'+$(this).attr("data-pic")+'" target="_blank" title=""><img src="'+$(this).attr("data-pic")+'" width="100%" /></a></div>'+$(this).attr("data-des")+'<div></div></center>'
						,btn: '关闭'
						,btnAlign: 'c'
						,shade: 0
						,yes: function(){
						  layer.closeAll();
						}
					});
				});
			});
		});
	});
	</script>
	<?php }else{ ?>
    <div class="layui-tab-item layui-show">
		<table class="layui-table">
			<thead>
				<tr>
					<th>序号</th><th>名称</th><th>作者</th><th>预览</th><th>版本</th><th>更新时间</th><th>操作</th>
				</tr>
			</thead>
			<tbody>
				<?php
				if (!empty($output)){
					$temi=0;
					$tpls=array();
					foreach ($output as $repo){
						if($repo->type!="tpl")continue;
						$tpls[$temi]['id']=$temi+1;
						$tpls[$temi]['name']=$repo->name;
						$tpls[$temi]['username']=$repo->username;
						$tpls[$temi]['type']=$repo->type;
						$tpls[$temi]['pic']=$repo->pic;
						$tpls[$temi]['des']=$repo->des;
						$tpls[$temi]['version']=$repo->version;
						$tpls[$temi]['date']=$repo->date;
						$tpls[$temi]['dir']=$repo->dir;
						$tpls[$temi]['remark']=$repo->remark;
						$temi++;
					}
					$page_now = isset($_GET['page_now']) ? intval($_GET['page_now']) : 1;
					if($page_now<1){
						$page_now=1;
					}
					$page_rec=Option::get('admin_perpage_num');
					$totalrec=count($tpls);
					$page=ceil($totalrec/$page_rec);
					if($page_now>$page){
						$page_now=$page;
					}
					if($page_now<=1){
						$before_page=1;
						if($page>1){
							$after_page=$page_now+1;
						}else{
							$after_page=1;
						}
					}else{
						$before_page=$page_now-1;
						if($page_now<$page){
							$after_page=$page_now+1;
						}else{
							$after_page=$page;
						}
					}
					$tplArr = array_slice($tpls, ($page_now-1)*$page_rec, $page_rec);
					
					foreach ($tplArr as $tpl){
						?>
						<tr>
							<td><?php echo $tpl["id"]; ?></td>
							<td><?php echo $tpl["name"]; ?></td>
							<td><?php echo $tpl["username"]; ?></td>
							<td>
								<a class="tplshow" id="tplshow<?php echo $tpl["id"]; ?>" href="javascript:;" data-pic="<?php echo $tpl["pic"]; ?>" data-name="<?php echo $tpl["name"]; ?>" data-des="<?php echo $tpl["des"]; ?>">
									<img src="./views/images/vlog.gif" align="top" title="" />
								</a>
							</td>
							<td><?php echo $tpl["version"]; ?></td>	
							<td><?php echo $tpl["date"]; ?>	</td>
							<td>
								<?php if(is_dir(TPLS_PATH.$tpl["dir"])){?>
								已安装
								<?php }else{?>
								<a href="./store.php?action=instpl&type=tpl&source=<?php echo $tpl["remark"]; ?>&token=<?php echo LoginAuth::genToken(); ?>">安装</a>
								<?php }?>
							</td>
						</tr>
						<?php
					}
					?>
					<tr>	
						<td colspan="7">
							<center><div id="page"></div></center>
							<center>(有<?php echo $totalrec; ?>个模板)</center>
						</td>
					</tr>
					<?php
				}else{
					?>
					<tr>	
						<td colspan="7">暂无任何模板</td>
					</tr>
					<?php
				}
				?>
			</tbody>
		</table>
	</div>
    <div class="layui-tab-item">
		<table class="layui-table">
			<thead>
				<tr>
					<th>序号</th><th>名称</th><th>作者</th><th>预览</th><th>版本</th><th>更新时间</th><th>操作</th>
				</tr>
			</thead>
			<tbody>
				<?php
				if (!empty($output)){
					$temi=0;
					$plss=array();
					foreach ($output as $repo){
						if($repo->type!="pls")continue;
						$plss[$temi]['id']=$temi+1;
						$plss[$temi]['name']=$repo->name;
						$plss[$temi]['username']=$repo->username;
						$plss[$temi]['type']=$repo->type;
						$plss[$temi]['pic']=$repo->pic;
						$plss[$temi]['des']=$repo->des;
						$plss[$temi]['version']=$repo->version;
						$plss[$temi]['date']=$repo->date;
						$plss[$temi]['dir']=$repo->dir;
						$plss[$temi]['remark']=$repo->remark;
						$temi++;
					}
					$page_now_pls = isset($_GET['page_now_pls']) ? intval($_GET['page_now_pls']) : 1;
					if($page_now_pls<1){
						$page_now_pls=1;
					}
					$page_rec_pls=Option::get('admin_perpage_num');
					$totalrec_pls=count($plss);
					$page=ceil($totalrec_pls/$page_rec_pls);
					if($page_now_pls>$page){
						$page_now_pls=$page;
					}
					if($page_now_pls<=1){
						$before_page=1;
						if($page>1){
							$after_page=$page_now_pls+1;
						}else{
							$after_page=1;
						}
					}else{
						$before_page=$page_now_pls-1;
						if($page_now_pls<$page){
							$after_page=$page_now_pls+1;
						}else{
							$after_page=$page;
						}
					}
					$plsArr = array_slice($plss, ($page_now_pls-1)*$page_rec_pls, $page_rec_pls);
					
					foreach ($plsArr as $pls){
						?>
						<tr>
							<td><?php echo $pls["id"]; ?></td>
							<td><?php echo $pls["name"]; ?></td>
							<td><?php echo $pls["username"]; ?></a></td>
							<td>
								<a class="plsshow" id="plsshow<?php echo $pls["id"]; ?>" href="javascript:;" data-pic="<?php echo $pls["pic"]; ?>" data-des="<?php echo $pls["des"]; ?>" data-name="<?php echo $pls["name"]; ?>">
									<img src="./views/images/vlog.gif" align="top" title="" />
								</a>
							</td>
							<td><?php echo $pls["version"]; ?></td>	
							<td><?php echo $pls["date"]; ?>	</td>
							<td>
							<?php if(is_dir(TPLS_PATH."../plugins/".$pls["dir"])){?>
							已安装
							<?php }else{?>
							<a href="./store.php?action=insplu&type=pls&source=<?php echo $pls["remark"]; ?>&token=<?php echo LoginAuth::genToken(); ?>">安装</a>
							<?php }?>
							</td>
						</tr>
						<?php
					}
					?>
					<tr>	
						<td colspan="7">
							<center><div id="page_pls"></div></center>
							<center>(有<?php echo $totalrec_pls; ?>个插件)</center>
						</td>
					</tr>
					<?php
				}else{
					?>
					<tr>	
						<td colspan="7">暂无任何插件</td>
					</tr>
					<?php
				}
				?>
			</tbody>
		</table>
	</div>
	<script>
	$(function(){
		layui.use(["laypage", "layer", "form"], function(){
			var layer = layui.layer;
			var form = layui.form;
			var laypage = layui.laypage;
			laypage.render({
				elem: "page"
				,count: <?=$totalrec;?>
				,limit: <?=Option::get('admin_perpage_num');?>
				,curr:<?=$page_now;?>
				,layout: ["prev", "page", "next", "skip"]
				,jump: function(obj,first){
					if(!first){
					  location.href="store.php?page_now="+obj.curr;
					}
				}
			});
			laypage.render({
				elem: "page_pls"
				,count: <?=$totalrec_pls;?>
				,limit: <?=Option::get('admin_perpage_num');?>
				,curr:<?=$page_now_pls;?>
				,layout: ["prev", "page", "next", "skip"]
				,jump: function(obj,first){
					if(!first){
					  location.href="store.php?page_now_pls="+obj.curr;
					}
				}
			});
			
			$(".tplshow").each(function(){
				var id=$(this).attr("id");
				$("#"+id).click( function () {
					layer.open({
						type: 1
						,title:$(this).attr("data-name")
						,area: ['60%', '100%']
						,offset: "auto"
						,id: 'tplshow'+id
						,content: '<center><div><a href="'+$(this).attr("data-pic")+'" target="_blank" title=""><img src="'+$(this).attr("data-pic")+'" width="100%" /></a></div>'+$(this).attr("data-des")+'<div></div></center>'
						,btn: '关闭'
						,btnAlign: 'c'
						,shade: 0
						,yes: function(){
						  layer.closeAll();
						}
					});
				});
			});
			$(".plsshow").each(function(){
				var id=$(this).attr("id");
				$("#"+id).click( function () {
					layer.open({
						type: 1
						,title:$(this).attr("data-name")
						,area: ['60%', '100%']
						,offset: "auto"
						,id: 'plsshow'+id
						,content: '<center><div><a href="'+$(this).attr("data-pic")+'" target="_blank" title=""><img src="'+$(this).attr("data-pic")+'" width="100%" /></a></div>'+$(this).attr("data-des")+'<div></div></center>'
						,btn: '关闭'
						,btnAlign: 'c'
						,shade: 0
						,yes: function(){
						  layer.closeAll();
						}
					});
				});
			});
		});
	});
	</script>
	<?php }?>
  </div>
</div>
<script>
$("#menu_store").addClass('layui-this');
$("#menu_store").parent().parent().addClass('layui-nav-itemed');
setTimeout(hideActived,2600);
</script>