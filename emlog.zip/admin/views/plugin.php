<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
		<legend>
			<b>插件管理</b>
		</legend>
	</fieldset>
	<div id="msg"></div>
	<?php if(isset($_GET['activate_install'])):?><blockquote class="actived layui-elem-quote">插件上传成功，请激活使用</blockquote><?php endif;?>
	<?php if(isset($_GET['active'])):?><blockquote class="actived layui-elem-quote">插件激活成功</blockquote><?php endif;?>
	<?php if(isset($_GET['activate_del'])):?><blockquote class="actived layui-elem-quote">删除成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_error'])):?><blockquote class="error layui-elem-quote">插件激活失败</blockquote><?php endif;?>
	<?php if(isset($_GET['inactive'])):?><blockquote class="actived layui-elem-quote">插件禁用成功</blockquote><?php endif;?>
	<?php if(isset($_GET['error_a'])):?><blockquote class="error layui-elem-quote">删除失败，请检查插件文件权限</blockquote><?php endif;?>
</div>
<table width="100%" id="adm_plugin_list" class="layui-table">
  <thead>
      <tr>
        <th width="200">名称</th>
        <th width="40"><b>状态</b></th>
		<th width="60"><b>版本</b></th>
		<th width="450"><b>描述</b></th>
		<th width="60">操作</th>
      </tr>
  </thead>
  <tbody>
	<?php 
	if($plugins):
	$i = 0;
	foreach($plugins as $key=>$val):
		$plug_state = 'inactive';
		$plug_action = 'active';
		$plug_state_des = '点击激活插件';
		if (in_array($key, $active_plugins))
		{
			$plug_state = 'active';
			$plug_action = 'inactive';
			$plug_state_des = '点击禁用插件';
		}
		$i++;
        if (TRUE === $val['Setting']) {
            $val['Name'] = "<a href=\"./plugin.php?plugin={$val['Plugin']}\" title=\"点击设置插件\">{$val['Name']} <img src=\"./views/images/set.png\" border=\"0\" /></a>";
        }
	?>	
      <tr>
        <td><?php echo $val['Name']; ?></td>
		<td id="plugin_<?php echo $i;?>">
		<a href="./plugin.php?action=<?php echo $plug_action;?>&plugin=<?php echo $key;?>&token=<?php echo LoginAuth::genToken(); ?>"><img src="./views/images/plugin_<?php echo $plug_state; ?>.gif" title="<?php echo $plug_state_des; ?>" align="absmiddle" border="0"></a>
		</td>
        <td><?php echo $val['Version']; ?></td>
        <td>
		<?php echo $val['Description']; ?>
		<?php if ($val['Url'] != ''):?><a href="<?php echo $val['Url'];?>" target="_blank">更多信息&raquo;</a><?php endif;?>
		<div style="margin-top:5px;">
		<?php if ($val['ForEmlog'] != ''):?>适用于emlog：<?php echo $val['ForEmlog'];?>&nbsp | &nbsp<?php endif;?>
		<?php if ($val['Author'] != ''):?>
		作者：<?php if ($val['AuthorUrl'] != ''):?>
			<a href="<?php echo $val['AuthorUrl'];?>" target="_blank"><?php echo $val['Author'];?></a>
			<?php else:?>
			<?php echo $val['Author'];?>
			<?php endif;?>
		<?php endif;?>
		</div>
		</td>
		<td>
            <a href="javascript: em_confirm('<?php echo $key; ?>', 'plu', '<?php echo LoginAuth::genToken(); ?>');">删除</a>
        </td>
      </tr>
	<?php endforeach;else: ?>
	  <tr>
        <td colspan="5">还没有安装插件</td>
      </tr>
	<?php endif;?>
	</tbody>
</table>
<button type="button" onclick="location.href='./plugin.php?action=install';" class="layui-btn layui-btn-primary layui-btn-xs">安装插件</button>
<script>
$("#adm_plugin_list tbody tr:odd").addClass("tralt_b");
$("#adm_plugin_list tbody tr")
	.mouseover(function(){$(this).addClass("trover")})
	.mouseout(function(){$(this).removeClass("trover")})
setTimeout(hideActived,2600);
$("#menu_plug").addClass('layui-this');
$("#menu_plug").parent().parent().addClass('layui-nav-itemed');
</script>