<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
	  <legend><b>用户管理</b></legend>
	</fieldset>
	<?php if(isset($_GET['active_del'])):?><blockquote class="actived layui-elem-quote">删除成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_update'])):?><blockquote class="actived layui-elem-quote">修改用户资料成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_add'])):?><blockquote class="actived layui-elem-quote">添加用户成功</blockquote><?php endif;?>
	<?php if(isset($_GET['error_login'])):?><blockquote class="error layui-elem-quote">用户名不能为空</blockquote><?php endif;?>
	<?php if(isset($_GET['error_exist'])):?><blockquote class="error layui-elem-quote">该用户名已存在</blockquote><?php endif;?>
	<?php if(isset($_GET['error_pwd_len'])):?><blockquote class="error layui-elem-quote">密码长度不得小于6位</blockquote><?php endif;?>
	<?php if(isset($_GET['error_pwd2'])):?><blockquote class="error layui-elem-quote">两次输入密码不一致</blockquote><?php endif;?>
	<?php if(isset($_GET['error_del_a'])):?><blockquote class="error layui-elem-quote">不能删除创始人</blockquote><?php endif;?>
	<?php if(isset($_GET['error_del_b'])):?><blockquote class="error layui-elem-quote">不能修改创始人信息</blockquote><?php endif;?>
</div>
<form class="layui-form" action="comment.php?action=admin_all_coms" method="post" name="form" id="form">
  <table class="layui-table" width="100%" id="adm_comment_list">
  	<thead>
      <tr>
        <th width="60"></th>
        <th width="220"><b>用户</b></th>
        <th width="250"><b>描述</b></th>
        <th width="150"><b>电子邮件</b></th>
		<th width="60"><b>文章</b></th>
		<th width="150"><b>注册时间</b></th>
		<th width="150"><b>上次登陆</b></th>
      </tr>
    </thead>
    <tbody>
	<?php
	if($users):
	foreach($users as $key => $val):
		$avatar = empty($user_cache[$val['uid']]['avatar']) ? './views/images/avatar.jpg' : '../' . $user_cache[$val['uid']]['avatar'];
	?>
     <tr>
        <td style="padding:3px; text-align:center;"><img src="<?php echo $avatar; ?>" height="40" width="40" /></td>
		<td>
		<?php echo empty($val['name']) ? $val['login'] : $val['name']; ?><br />
		<?php echo $val['role'] == ROLE_ADMIN ? $val['uid'] == 1 ? '创始人':'管理员' : '作者'; ?>
        <?php if ($val['role'] == ROLE_WRITER && $val['ischeck'] == 'y') echo '(文章需审核)';?>
		<span style="display:none; margin-left:8px;">
		<?php if (UID != $val['uid']): ?>
		<a href="user.php?action=edit&uid=<?php echo $val['uid']?>">编辑</a> 
		<a href="javascript: em_confirm(<?php echo $val['uid']; ?>, 'user', '<?php echo LoginAuth::genToken(); ?>');">删除</a>
		<?php else:?>
		<a href="blogger.php">编辑</a>
		<?php endif;?>
		</span>
		</td>
		<td><?php echo $val['description']; ?></td>
		<td><?php echo $val['email']; ?></td>
		<td><a href="./admin_log.php?uid=<?php echo $val['uid'];?>"><?php echo $sta_cache[$val['uid']]['lognum']; ?></a></td>
		<td><?=$val['instime']!=null?$val['instime']:""; ?></td>
		<td><?=$val['logintime']!=null?$val['logintime']:""; ?></td>
     </tr>
	<?php endforeach;else:?>
	  <tr><td colspan="8">还没有添加作者</td></tr>
	<?php endif;?>
	</tbody>
  </table>
</form>
<center><div id="page"></div></center>
<center><div>(有<?php echo $usernum; ?>位用户)</div> </center>
<form class="layui-form" action="user.php?action=new" method="post">
<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
  <legend>
	<button type="button" onclick="displayToggle('user_new', 2);" class="layui-btn layui-btn-primary">添加用户+</button>
  </legend>
</fieldset>
<div id="user_new">
    <li style="width:180px;">
	<select name="role" id="role" lay-filter="role">
		<option value="writer">作者（投稿人）</option>
		<option value="admin">管理员</option>
	</select>
	</li>
	<li>
		<div style="margin:10px 0px;">用户名</div>
		<input name="login" type="text" id="login" value="" style="width:180px;" class="layui-input" />
	</li>
	<li>
		<div style="margin:10px 0px;">密码（大于6位）</div>
		<input name="password" type="password" id="password" value="" style="width:180px;" class="layui-input" />
	</li>
	<li>
		<div style="margin:10px 0px;">重复密码</div>
		<input name="password2" type="password" id="password2" value="" style="width:180px;" class="layui-input" />
	</li>
	<li id="ischeck" style="margin-top:10px;width:180px;">
		<select name="ischeck">
			<option value="n">文章不需要审核</option>
			<option value="y">文章需要审核</option>
		</select>
	</li>
    <input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
	<li style="margin-top:10px;"><input type="submit" name="" value="添加用户" class="layui-btn" /></li>
</div>
</form>
<script>
$("#user_new").css('display', $.cookie('em_user_new') ? $.cookie('em_user_new') : 'none');
$(document).ready(function(){
	layui.use(["laypage","form"], function(){
		var form = layui.form;
		var laypage = layui.laypage
		  ,layer = layui.layer;
		  laypage.render({
			elem: "page"
			,count: <?=$usernum;?>
			,limit: <?=Option::get('admin_perpage_num');?>
			,curr:<?=$page;?>
			,layout: ["prev", "page", "next", "skip"]
			,jump: function(obj,first){
				if(!first){
				  location.href="user.php?page="+obj.curr;
				}
			}
		  });
		form.on('select(role)', function(data){
			$("#ischeck").toggle();
		});
	});
	$("#adm_comment_list tbody tr:odd").css("background-color","#F7F7F7");
	$("#adm_comment_list tbody tr")
		.mouseover(function(){$(this).css("background-color","#E9F1FA");$(this).find("span").show();})
		.mouseout(function(){$(this).css("background-color","#F7F7F7");$(this).find("span").hide();})
    
});
setTimeout(hideActived,2600);
$("#menu_user").addClass('layui-this');
$("#menu_user").parent().parent().addClass('layui-nav-itemed');
</script>