<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
	  <legend>
		<b>应用商店数据加载页面</b>
		<small><a href="./store.php" class="layui-btn layui-btn-primary layui-btn-xs">返回商店</a></small>
	  </legend>
	</fieldset>
</div>

<div id="addon_ins">
	<blockquote class="layui-elem-quote"><?php echo $source_typename;?>正在下载安装中,请耐心等待</blockquote>
</div>
<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" /> 
<script>
$("#menu_store").addClass('layui-this');
$("#menu_store").parent().parent().addClass('layui-nav-itemed');
$(document).ready(function(){
    $.get('./store.php', {
    action:'addon', 
    source:"<?php echo $source;?>",
     type:"<?php echo $source_type;?>"
      },
      function(data){
        if (data.match("success")) {
            $("#addon_ins").html('<blockquote class="layui-elem-quote"><?php echo $source_typename;?>安装成功，<?php echo $source_typeurl;?></blockquote>');
        } else if(data.match("error_down")){
            $("#addon_ins").html('<blockquote class="layui-elem-quote"><?php echo $source_typename;?>下载失败，可能是服务器网络问题,请联系开发者，<a href="store.php">返回在线商店</a></blockquote>');
        } else if(data.match("error_zip")){
            $("#addon_ins").html('<blockquote class="layui-elem-quote"><?php echo $source_typename;?>安装失败，可能是你的服务器空间不支持zip模块，请手动下载安装，<a href="store.php">返回在线商店</a></blockquote>');
        } else if(data.match("error_dir")){
            $("#addon_ins").html('<blockquote class="layui-elem-quote"><?php echo $source_typename;?>安装失败，可能是应用目录不可写，<a href="store.php">返回在线商店</a></blockquote>');
        }else{
            $("#addon_ins").html('<blockquote id="addonerror"><?php echo $source_typename;?>安装失败，<a href="store.php">返回在线商店</a></blockquote>');
        }
      });
})
</script>
