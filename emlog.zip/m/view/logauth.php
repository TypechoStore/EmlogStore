<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div id="m">
该文章需要密码才能访问，请输入密码：
<form action="" method="post">
<br /><input type="password" name="logpwd" /> <input type="submit" value="确定" />
<br /><br /><a href="./">&laquo;返回首页</a>
</form>
</div>