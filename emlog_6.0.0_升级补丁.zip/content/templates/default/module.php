<?php 
/**
 * 侧边栏组件、页面模块
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
$DB = Database::getInstance();
?>
<?php
//widget：blogger
function widget_blogger($title){
	$DB = Database::getInstance();
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
	<div class="layadmin-homepage-panel layadmin-homepage-shadow" style="word-wrap:break-word;">
		<div class="layui-card text-center">
		  <div class="layui-card-body">
			<div class="layadmin-homepage-pad-ver">
			  <img class="layadmin-homepage-pad-img" src="<?php echo TEMPLATE_URL; ?>images/logo.png" width="96" height="96">
			</div>
			<h4 class="layadmin-homepage-font"><?php echo $blogname; ?></h4>
			<p class="layadmin-homepage-min-font"><?php echo $bloginfo; ?></p>
			<div class="layadmin-homepage-pad-ver">
			  <a href="javascript:;" lay-tips="13700001111" class="layui-icon layui-icon-cellphone"></a>
			  <a href="https://weibo.com/tongleer" target="_blank" href="javascript:;" class="layui-icon layui-icon-login-weibo"></a>
			  <a id="showWxAlert" href="javascript:;" class="layui-icon layui-icon-login-wechat"></a>
			  <a href="http://wpa.qq.com/msgrd?v=3&uin=2293338477&site=qq&menu=yes" target="_blank" class="layui-icon layui-icon-login-qq"></a>
			</div>
			<button id="dashangAlert" class="layui-btn layui-btn-fluid">打赏</button>
		  </div>
		</div>
		<p class="layadmin-homepage-about">
		  关于我
		</p>
		<ul class="layadmin-homepage-list-group">
		  <li class="list-group-item"><i class="layui-icon layui-icon-location"></i>中国北京</li>
		  <li class="list-group-item"><a href="https://weibo.com/tongleer" target="_blank" class="color"><i class="layui-icon layui-icon-login-weibo"></i><span style="word-wrap:break-word;">https://weibo.com/tongleer</span></a></li>
		</ul>
		<div class="layadmin-homepage-pad-hor">
		  <mdall><?php echo $bloginfo; ?></mdall>
		</div>
		<p class="layadmin-homepage-about">
		  技能
		</p>
		<ul class="layadmin-homepage-list-inline">
		  <a href="javascript:;" class="layui-btn layui-btn-primary">Android</a>
		  <a href="javascript:;" class="layui-btn layui-btn-primary">PHP</a>
		  <a href="javascript:;" class="layui-btn layui-btn-primary">太极</a>
		</ul>
		<p class="layadmin-homepage-about">
		  统计
		</p>
		<?php
		$countBlog=$DB->once_fetch_array("SELECT count(*) AS total FROM ".DB_PREFIX."blog WHERE hide='n' and checked='y'");
		$countComment=$DB->once_fetch_array("SELECT count(*) AS total FROM ".DB_PREFIX."comment WHERE hide='n'");
		$countUser=$DB->once_fetch_array("SELECT count(*) AS total FROM ".DB_PREFIX."user");
		$countTwitter=$DB->once_fetch_array("SELECT count(*) AS total FROM ".DB_PREFIX."twitter");
		?>
		<ul class="layadmin-homepage-list-inline">
		  <a href="javascript:;" class="layui-btn layui-btn-primary">文章数 <?=$countBlog["total"];?></a>
		  <a href="javascript:;" class="layui-btn layui-btn-primary">评论数 <?=$countComment["total"];?></a>
		  <a href="javascript:;" class="layui-btn layui-btn-primary">用户数 <?=$countUser["total"];?></a>
		  <a href="javascript:;" class="layui-btn layui-btn-primary">微语数 <?=$countTwitter["total"];?></a>
		</ul>
	</div>
<?php }?>
<?php
//widget：日历
function widget_calendar($title){ ?>
	<div class="layui-card">
		<div class="layui-card-header">
		  <h3 class="panel-title"><?php echo $title; ?></h3>
		</div>
		<div class="layui-card-body">
			<div class="layui-row layui-col-space15" id="calendar"></div>
			<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
		</div>
	</div>
<?php }?>
<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
	<div class="layadmin-homepage-panel layadmin-homepage-shadow" style="word-wrap:break-word;">
		<p class="layadmin-homepage-about"><?php echo $title; ?></p>
		<ul class="layadmin-homepage-list-inline">
		<?php foreach($tag_cache as $value): ?>
		<span style="font-size:<?php echo $value['fontsize']; ?>pt; line-height:30px;">
		  <a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇文章" class="layui-btn layui-btn-primary"><?php echo $value['tagname']; ?></a>
		</span>
		<?php endforeach; ?>
		</ul>
	</div>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	<div class="layui-card">
		<div class="layui-card-header">
		  <h3 class="panel-title"><?php echo $title; ?></h3>
		</div>
		<div class="layui-card-body">
		  <ul class="layui-timeline">
			<?php
			foreach($sort_cache as $value):
				if ($value['pid'] != 0) continue;
			?>
			<li class="layui-timeline-item">
				<i class="layui-icon layui-timeline-axis"></i>
				<div class="layui-timeline-content layui-text">
				  <h3 class="layui-timeline-title">
					<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
				  </h3>
				  <p>
					<?php
					$children = $value['children'];
					foreach ($children as $key):
						$value = $sort_cache[$key];
					?>
					<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
					<?php endforeach; ?>
				  </p>
				</div>
			</li>
			<?php endforeach; ?>
		  </ul>
		</div>
	</div>
<?php }?>
<?php
//widget：最新微语
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	?>
	<div class="layui-card">
		<div class="layui-card-header">
		  <h3 class="panel-title"><?php echo $title; ?></h3>
		</div>
		<div class="layui-card-body">
			<ul class="layui-timeline">
				<?php foreach($newtws_cache as $value): ?>
				<?php $img=BLOG_URL.str_replace('thum-', '', $value['img']);?>
				<li class="layui-timeline-item">
					<i class="layui-icon layui-timeline-axis"></i>
					<div class="layui-timeline-content layui-text">
					  <h3 class="layui-timeline-title"><?php echo smartDate($value['date']); ?></h3>
					  <p>
						<?php echo $value['img']?'<img src="'.$img.'" width="50">':"";?>
						<?php echo unCompress(formatExcerpt($value['t'], 140));?>
					  </p>
					</div>
				</li>
				<?php endforeach; ?>
			</ul>
			<?php if ($istwitter == 'y') :?>
			<button type="button" style="width:100%;" onClick="window.open('<?php echo BLOG_URL . 't/'; ?>');" class="layui-btn layui-btn-primary">更多&raquo;</button>
			<?php endif;?>
		</div>
	</div>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
	<div class="layui-card">
		<div class="layui-card-header">
		  <h3 class="panel-title"><?php echo $title; ?></h3>
		</div>
		<div class="layui-card-body">
		  <ul class="layui-timeline">
			<?php
			foreach($com_cache as $value):
			$url = Url::comment($value['gid'], $value['page'], $value['cid']);
			?>
			<li class="layui-timeline-item">
				<i class="layui-icon layui-timeline-axis"></i>
				<div class="layui-timeline-content layui-text">
				  <div class="layui-timeline-title"><?php echo $value['name']; ?>，<a href="<?php echo $url; ?>" target="_blank"><?php echo $value['content']; ?></a></div>
				</div>
			</li>
			<?php
			endforeach;
			?>
		  </ul>
		</div>
	</div>
<?php }?>
<?php
//widget：最新文章
function widget_newlog($title){
	$DB = Database::getInstance();
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
	<div class="layui-card homepage-bottom">
		<div class="layui-card-header">
		  <h3 class="panel-title">
			<?php echo $title; ?>
		  </h3>
		</div>
		<div class="layui-card-body">
			<?php foreach($newLogs_cache as $value): ?>
			<?php
			$blogInfo=$DB->once_fetch_array("SELECT author,content FROM ".DB_PREFIX."blog WHERE gid=".$value['gid']);
			$anchorInfo=$DB->once_fetch_array("SELECT * FROM ".DB_PREFIX."user WHERE uid=".$blogInfo["author"]);
			?>
			<a href="<?php echo Url::log($value['gid']); ?>" class="layadmin-privateletterlist-item">
			  <div class="meida-left">
				<?=isset(getBlogImages($blogInfo["content"])[0])?'<img src="'.getBlogImages($blogInfo["content"])[0].'">':"";?>
			  </div>
			  <div class="meida-right">
				<p><?=$anchorInfo["nickname"]?$anchorInfo["nickname"]:$anchorInfo["username"];?></p>
                <mdall><?php echo $value['title']; ?></mdall>
			  </div>
			</a>
			<?php endforeach; ?>
		</div>
	</div>
<?php }?>
<?php
//widget：热门文章
function widget_hotlog($title){
	$DB = Database::getInstance();
	$index_hotlognum = Option::get('index_hotlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getHotLog($index_hotlognum);?>
	<div class="layui-card homepage-bottom">
		<div class="layui-card-header">
		  <h3 class="panel-title">
			<?php echo $title; ?>
		  </h3>
		</div>
		<div class="layui-card-body">
			<?php foreach($randLogs as $value): ?>
			<?php
			$blogInfo=$DB->once_fetch_array("SELECT author,content FROM ".DB_PREFIX."blog WHERE gid=".$value['gid']);
			$anchorInfo=$DB->once_fetch_array("SELECT * FROM ".DB_PREFIX."user WHERE uid=".$blogInfo["author"]);
			?>
			<a href="<?php echo Url::log($value['gid']); ?>" class="layadmin-privateletterlist-item">
			  <div class="meida-left">
				<?=isset(getBlogImages($blogInfo["content"])[0])?'<img src="'.getBlogImages($blogInfo["content"])[0].'">':"";?>
			  </div>
			  <div class="meida-right">
				<p><?=$anchorInfo["nickname"]?$anchorInfo["nickname"]:$anchorInfo["username"];?></p>
                <mdall><?php echo $value['title']; ?></mdall>
			  </div>
			</a>
			<?php endforeach; ?>
		</div>
	</div>
<?php }?>
<?php
//widget：随机文章
function widget_random_log($title){
	$DB = Database::getInstance();
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);?>
	<div class="layui-card homepage-bottom">
		<div class="layui-card-header">
		  <h3 class="panel-title">
			<?php echo $title; ?>
		  </h3>
		</div>
		<div class="layui-card-body">
			<?php foreach($randLogs as $value): ?>
			<?php
			$blogInfo=$DB->once_fetch_array("SELECT author,content FROM ".DB_PREFIX."blog WHERE gid=".$value['gid']);
			$anchorInfo=$DB->once_fetch_array("SELECT * FROM ".DB_PREFIX."user WHERE uid=".$blogInfo["author"]);
			?>
			<a href="<?php echo Url::log($value['gid']); ?>" class="layadmin-privateletterlist-item">
			  <div class="meida-left">
				<?=isset(getBlogImages($blogInfo["content"])[0])?'<img src="'.getBlogImages($blogInfo["content"])[0].'">':"";?>
			  </div>
			  <div class="meida-right">
				<p><?=$anchorInfo["nickname"]?$anchorInfo["nickname"]:$anchorInfo["username"];?></p>
                <mdall><?php echo $value['title']; ?></mdall>
			  </div>
			</a>
			<?php endforeach; ?>
		</div>
	</div>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
	<div class="layui-card">
		<div class="layui-card-header">
		  <h3 class="panel-title"><?php echo $title; ?></h3>
		</div>
		<div class="layui-card-body">
		  <div class="layui-row layui-col-space15">
			<form class="layui-form" name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
			<input class="layui-input" name="keyword" type="text" />
			</form>
		  </div>
		</div>
	</div>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
	<div class="layui-card">
		<div class="layui-card-header">
		  <h3 class="panel-title"><?php echo $title; ?></h3>
		</div>
		<div class="layui-card-body">
		  <ul class="layui-timeline">
			<?php foreach($record_cache as $value): ?>
			<li class="layui-timeline-item">
				<i class="layui-icon layui-timeline-axis"></i>
				<div class="layui-timeline-content layui-text">
				  <h3 class="layui-timeline-title"><?=$value['date'];?></h3>
				  <p><a href="<?php echo Url::record($value['date']); ?>" target="_blank"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></p>
				</div>
			</li>
			<?php endforeach; ?>
		  </ul>
		</div>
	</div>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
	<div class="layui-card">
		<div class="layui-card-header">
		  <h3 class="panel-title"><?php echo $title; ?></h3>
		</div>
		<div class="layui-card-body">
		  <div class="layui-row layui-col-space15">
			<?php echo $content; ?>
		  </div>
		</div>
	</div>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
    //if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
	?>
	<div class="layui-card">
		<div class="layui-card-header">
		  <h3 class="panel-title"><?php echo $title; ?></h3>
		</div>
		<div class="layui-card-body">
		  <div class="layui-row layui-col-space15">
			<?php
			foreach($link_cache as $value):
			?>
			<div class="layui-col-md4">
			  <a href="<?php echo $value['url']; ?>" title="<?php echo $value['link']." - ".$value['des']; ?>" target="_blank"><?php echo $value['sitepic']?'<img src="'.$value['sitepic'].'" alt="'.$value['link'].'" width="100%">':$value['link']; ?></a>
			</div>
			<?php
			endforeach;
			?>
		  </div>
		</div>
	</div>
<?php }?> 
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	?>
	<?php
	foreach($navi_cache as $value){
        if ($value['pid'] != 0) {
            continue;
        }
		if($value['url'] == ADMIN_DIR && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):
			?>
			<div class="layui-col-md3 layui-col-sm3 layui-col-xs3" style="margin:5px auto;">
                <mdall><a href="<?php echo BLOG_URL.ADMIN_DIR; ?>/">管理站点</a></mdall>
            </div>
			<div class="layui-col-md3 layui-col-sm3 layui-col-xs3" style="margin:5px auto;">
                <mdall><a href="<?php echo BLOG_URL.ADMIN_DIR; ?>/?action=logout">退出</a></mdall>
            </div>
			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
        $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'current' : 'common';
		?>
		<div class="layui-col-md3 layui-col-sm3 layui-col-xs3" style="margin:5px auto;">
			<mdall>
				<a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a>
			</mdall>
		</div>
		<?php
		if (!empty($value['children'])){
			foreach ($value['children'] as $row){
				?>
				<div class="layui-col-md3 layui-col-sm3 layui-col-xs3" style="margin:5px auto;">
					<mdall>
						<li><a href="<?=Url::sort($row['sid']);?>"><?=$row['sortname'];?></a></li>
					</mdall>
				</div>
				<?php
			}
		}?>

		<?php
		if (!empty($value['childnavi'])){
			foreach ($value['childnavi'] as $row){
				$newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';
				?>
				<div class="layui-col-md3 layui-col-sm3 layui-col-xs3" style="margin:5px auto;">
					<mdall>
						<li><a href="<?=$row['url'];?>"><?=$row['naviname'];?></a></li>
					</mdall>
				</div>
				<?php
			}
		}
		?>
	<?php }?>
<?php }?>
<?php
//blog：置顶
function topflg($top, $sortop='n', $sortid=null){
    if(blog_tool_ishome()) {
       echo $top == 'y' ? "<img src=\"".TEMPLATE_URL."/images/top.png\" title=\"首页置顶文章\" /> " : '';
    } elseif($sortid){
       echo $sortop == 'y' ? "<img src=\"".TEMPLATE_URL."/images/sortop.png\" title=\"分类置顶文章\" /> " : '';
    }
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a href="'.BLOG_URL.ADMIN_DIR.'/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
    <a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
	<?php endif;?>
<?php }?>
<?php
//blog：文章标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '标签:';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "	<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
		}
		echo $tag;
	}
}
?>
<?php
//blog：文章作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<div class="layui-form-item">
	<?php if($prevLog):?>
	<a href="<?php echo Url::log($prevLog['gid']) ?>">&laquo; <?php echo $prevLog['title'];?></a>
	<?php endif;?>
	<?php if($nextLog && $prevLog):?>
		|
	<?php endif;?>
	<?php if($nextLog):?>
	<a href="<?php echo Url::log($nextLog['gid']) ?>"><?php echo $nextLog['title'];?> &raquo;</a>
	<?php endif;?>
	</div>
<?php }?>
<?php
//blog：评论列表
function blog_comments($comments){
    extract($comments);
    if($commentStacks): ?>
	<a name="comments"></a>
	<p class="comment-header"><b></b></p>
	<?php endif; ?>
	<?php
	$isGravatar = Option::get('isgravatar');
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<div class="media-item comment" id="comment-<?php echo $comment['cid']; ?>">
	  <a name="<?php echo $comment['cid']; ?>"></a>
	  <?php if($isGravatar == 'y'): ?><div class="avatar media-item-left"><img class="img-xs" src="<?php echo getGravatar($comment['mail']); ?>" /></div><?php endif; ?>
	  <div class="media-text comment-info">
		<a href="javascript:;"><?php echo $comment['poster']; ?></a>
		<mdall class="comment-time"><?php echo $comment['date']; ?></mdall>
		<a class="comment-reply" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a>
		<div class="comment-content"><?php echo $comment['content']; ?></div>
	  </div>
	</div>
	<?php blog_comments_children($comments, $comment['children']); ?>
	<?php endforeach; ?>
    <div id="pagenavi">
	    <?php echo $commentPageUrl;?>
    </div>
<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<div class="media-item comment comment-children" id="comment-<?php echo $comment['cid']; ?>">
	  <a name="<?php echo $comment['cid']; ?>"></a>
	  <?php if($isGravatar == 'y'): ?><div class="avatar media-item-left"><img class="img-xs" src="<?php echo getGravatar($comment['mail']); ?>" /></div><?php endif; ?>
	  <div class="media-text comment-info">
		<a href="javascript:;"><?php echo $comment['poster']; ?></a>
		<mdall class="comment-time"><?php echo $comment['date']; ?></mdall>
		<?php if($comment['level'] < 4): ?><a class="comment-reply" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a><?php endif; ?>
		<div class="comment-content"><?php echo $comment['content']; ?></div>
	  </div>
	</div>
	<?php blog_comments_children($comments, $comment['children']);?>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
	<div id="comment-place">
	<div class="comment-post" id="comment-post">
		<div class="cancel-reply" id="cancel-reply" style="display:none"><a href="javascript:void(0);" onclick="cancelReply()" class="layui-btn layui-btn-primary">取消回复</a></div>
		<p class="comment-header"><b></b><a name="respond"></a></p>
		<form class="layui-form" method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
			<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
			<?php if(ROLE == ROLE_VISITOR): ?>
			<p>
				<input class="layui-input" type="text" name="comname" maxlength="49" value="<?php echo $ckname; ?>" size="22" tabindex="1" placeholder="昵称">
			</p>
			<p>
				<input class="layui-input" type="text" name="commail"  maxlength="128"  value="<?php echo $ckmail; ?>" size="22" tabindex="2" placeholder="邮件地址 (选填)">
			</p>
			<p>
				<input class="layui-input" type="text" name="comurl" maxlength="128"  value="<?php echo $ckurl; ?>" size="22" tabindex="3" placeholder="个人主页 (选填)">
			</p>
			<?php endif; ?>
			<p><textarea class="layui-textarea" name="comment" id="comment" rows="10" tabindex="4" required="required" placeholder="评论内容"></textarea></p>
			<p><?php echo $verifyCode; ?> <input class="layui-btn layui-btn-primary" type="submit" id="comment_submit" value="发表评论" tabindex="6" /></p>
			<input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/>
		</form>
	</div>
	</div>
	<?php endif; ?>
<?php }?>
<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>
<?php
//格式化摘要
function formatExcerpt($content, $strlen = null){
	$content = preg_replace('/\[iframe\](.*)\[\/iframe\]/Uims', '', $content);
	$content = preg_replace('/\[video\](.*)\[\/video\]/Uims', '', $content);
	$content = str_replace('继续阅读&gt;&gt;', '', $content);
	$content = preg_replace("/\[hide\](.*)\[\/hide\]/Uims", '|*********此处内容回复可见*********|', strip_tags($content));
	if ($strlen) {
		$content = subString($content, 0, $strlen);
	}
	return $content;
}
//格式化内容
function formatContent($content){
	$matche_content=getVideoCode($content);
	for($i=0;$i<count($matche_content[0]);$i++){
		if(strpos($matche_content[0][$i],'iframe')){
			$content = str_replace($matche_content[0][$i], '<iframe height="400" width="100%" src="'.$matche_content[2][$i].'" frameborder="0" "allowfullscreen"></iframe>', $content);
		}else if(strpos($matche_content[0][$i],'video')&&strpos($matche_content[2][$i],'.mp4')){
			$content = str_replace($matche_content[0][$i], '<video width="100%" src="'.$matche_content[2][$i].'" controls="controls"></video>', $content);
		}else if(strpos($matche_content[0][$i],'video')){
			$content = str_replace($matche_content[0][$i], '', $content);
		}
	}
	return $content;
}
/*获取文章中视频代码*/
function getVideoCode($content){
    if(!preg_match_all( "/\[(video|VIDEO|iframe|IFRAME)\](.*)\[\/(video|VIDEO|iframe|IFRAME)\]/Uims", $content, $matches )){
		preg_match_all( "/<(iframe|IFRAME).*?src=[\'|\"](.*?)[\'|\"].*?[\/]?>/", $content, $matches );
	}
    return $matches;
}
/*获取文章中首张图片*/
function getBlogImages($content){
    preg_match_all( "/<(img|IMG).*?src=[\'|\"](.*?)[\'|\"].*?[\/]?>/", $content, $matches );
	$thumb=array();
	if(count($matches[2])!=0){
        array_push($thumb,$matches[2][0]);//文章内容中抓到了图片 输出链接
    }
    return $thumb;
}
//点赞
function syzan(){
	$DB = Database::getInstance();
	if($DB->num_rows($DB->query("show columns from ".DB_PREFIX."blog like 'slzan'")) == 0){
		$sql = "ALTER TABLE ".DB_PREFIX."blog ADD slzan int unsigned NOT NULL DEFAULT '0'";
		$DB->query($sql);
	}
}
syzan();
function update($logid){
	$logid = intval($_POST['id']);
	$DB = Database::getInstance();
	$DB->query("UPDATE " . DB_PREFIX . "blog SET slzan=slzan+1 WHERE gid=$logid");
	setcookie('slzanpd_'. $logid, 'true', time() + 31536000);
}
function lemoninit() {
	if( @$_POST['plugin'] == 'slzanpd' &&@$_POST['action'] == 'slzan' &&isset($_POST['id'])){
		$id = intval($_POST['id']);
		header("Access-Control-Allow-Origin: *");
		update($id);echo getnum($id);die;
	}
}
lemoninit();
function getnum($id){
	static $arr = array();
	$DB = Database::getInstance();
	if(isset($arr[$logid])) return $arr[$logid];
	$sql = "SELECT slzan FROM " . DB_PREFIX . "blog WHERE gid=$id";
	$res = $DB->query($sql);
	$row = $DB->fetch_array($res);
	$arr[$id] = intval($row['slzan']);
	return $arr[$id];
}
//解决页面标题重复
function page_repeat($page) {
	if ($page>=2){ 
		echo ' _第'.$page.'页'; 
	}
}
/*压缩html代码*/
function em_compress_html_main($buffer){
    $initial=strlen($buffer);
    $buffer=explode("<!--em-compress-html-->", $buffer);
    $count=count ($buffer);
    for ($i = 0; $i <= $count; $i++){
        if (stristr($buffer[$i], '<!--em-compress-html no compression-->')){
            $buffer[$i]=(str_replace("<!--em-compress-html no compression-->", " ", $buffer[$i]));
        }else{
            $buffer[$i]=(str_replace("\t", " ", $buffer[$i]));
            $buffer[$i]=(str_replace("\n\n", "\n", $buffer[$i]));
            $buffer[$i]=(str_replace("\n", "", $buffer[$i]));
            $buffer[$i]=(str_replace("\r", "", $buffer[$i]));
            while (stristr($buffer[$i], '  '))
            {
            $buffer[$i]=(str_replace("  ", " ", $buffer[$i]));
            }
        }
        $buffer_out.=$buffer[$i];
    }
    $final=strlen($buffer_out);
    $savings=($initial-$final)/$initial*100;
    $savings=round($savings, 2);
    $buffer_out.="\n<!--压缩前的大小: $initial bytes; 压缩后的大小: $final bytes; 节约：$savings% -->";
    return $buffer_out;
}
function unCompress($content){
    if(preg_match_all('/(crayon-|<\/pre>)/i', $content, $matches)) {
        $content = '<!--em-compress-html--><!--em-compress-html no compression-->'.$content;
        $content.= '<!--em-compress-html no compression--><!--em-compress-html-->';
    }
    return $content;
}
/**
 * 判断是否通过手机访问
 */
function isMobile(){ 
    // 如果有HTTP_X_WAP_PROFILE则一定是移动设备
    if (isset ($_SERVER['HTTP_X_WAP_PROFILE'])){
        return true;
    } 
    // 如果via信息含有wap则一定是移动设备,部分服务商会屏蔽该信息
    if (isset ($_SERVER['HTTP_VIA'])){ 
        // 找不到为flase,否则为true
        return stristr($_SERVER['HTTP_VIA'], "wap") ? true : false;
    } 
    // 脑残法，判断手机发送的客户端标志,兼容性有待提高
    if (isset ($_SERVER['HTTP_USER_AGENT'])){
        $clientkeywords = array ('nokia',
            'sony','ericsson','mot','samsung','htc','sgh','lg','sharp','sie-','philips','panasonic','alcatel','lenovo','iphone','ipod',
            'blackberry','meizu','android','netfront','symbian','ucweb','windowsce','palm','operamini','operamobi','openwave','nexusone','cldc','midp','wap','mobile'
            ); 
        // 从HTTP_USER_AGENT中查找手机浏览器的关键字
        if (preg_match("/(" . implode('|', $clientkeywords) . ")/i", strtolower($_SERVER['HTTP_USER_AGENT']))){
            return true;
        } 
    } 
    // 协议法，因为有可能不准确，放到最后判断
    if (isset ($_SERVER['HTTP_ACCEPT'])){ 
        // 如果只支持wml并且不支持html那一定是移动设备
        // 如果支持wml和html但是wml在html之前则是移动设备
        if ((strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') !== false) && (strpos($_SERVER['HTTP_ACCEPT'], 'text/html') === false || (strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') < strpos($_SERVER['HTTP_ACCEPT'], 'text/html')))){
            return true;
        } 
    } 
    return false;
}
function curPageURL(){
	$pageURL = 'http';
	if ($_SERVER["HTTPS"] == "on"){
		$pageURL .= "s";
	}
	$pageURL .= "://";
	if ($_SERVER["SERVER_PORT"] != "80"){
		$pageURL .= $_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"] . $_SERVER["REQUEST_URI"];
	}else{
		$pageURL .= $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];
	}
	return $pageURL;
}
?>