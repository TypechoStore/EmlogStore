<?php
/*
Template Name:默认模板
Description:默认模板，零门槛 / 响应式 / 清爽 / 极简
Version:1.0.1
Author:二呆
Author Url:https://www.tongleer.com
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?> <?php echo page_repeat($page); ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<meta name="renderer" content="webkit">
<meta property="og:type" content="website" />
<meta property="og:title" content="<?php echo $site_title; ?>">
<meta property="og:description" content="<?php echo $site_description; ?>">
<meta property="og:image" content="https://www.tongleer.com/wp-content/themes/tongleer/assets/images/w-logo-blue.png"/>
<meta property="og:url" content="https://www.tongleer.com">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link rel="alternate icon" href="https://me.tongleer.com/content/templates/dux/images/favicon.png" type="image/png" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link rel="stylesheet" href="<?php echo BLOG_URL.ADMIN_DIR; ?>/views/ui/layui/css/layui.css" media="all">
<link rel="stylesheet" href="<?php echo BLOG_URL.ADMIN_DIR; ?>/views/ui/style/admin.css" media="all">
<link rel="stylesheet" href="<?php echo BLOG_URL.ADMIN_DIR; ?>/views/ui/style/template.css" media="all">
<script type="text/javascript" src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.11.0.js?v=<?php echo Option::EMLOG_VERSION; ?>"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<?php doAction('index_head'); ?>
</head>
<body>
<div class="layui-fluid layadmin-homepage-fluid">
  <div class="layui-row layui-col-space15">
    <div class="layui-col-md12">
      <div class="layui-fluid layadmin-homepage-content">
		<div class="layadmin-homepage-panel layadmin-homepage-shadow" style="word-wrap:break-word;">
			<div class="layui-card text-center">
			  <div class="layui-card-body">
				<div class="layadmin-homepage-pad-ver">
				  <img onClick="location.href='<?php echo BLOG_URL; ?>';" class="layadmin-homepage-pad-img" src="<?php echo TEMPLATE_URL; ?>images/logo.png" width="96" height="96">
				</div>
				<h4 class="layadmin-homepage-font"><?php echo $blogname; ?></h4>
				<p class="layadmin-homepage-min-font"><?php echo $bloginfo; ?></p>
				<div class="layadmin-homepage-pad-ver">
				  <a href="javascript:;" lay-tips="13700001111" class="layui-icon layui-icon-cellphone"></a>
				  <a href="https://weibo.com/tongleer" target="_blank" href="javascript:;" class="layui-icon layui-icon-login-weibo"></a>
				  <a id="showWxAlert" href="javascript:;" class="layui-icon layui-icon-login-wechat"></a>
				  <a href="http://wpa.qq.com/msgrd?v=3&uin=2293338477&site=qq&menu=yes" target="_blank" class="layui-icon layui-icon-login-qq"></a>
				</div>
				<button id="dashangAlert" class="layui-btn layui-btn-fluid layui-btn-primary">打赏</button>
			  </div>
			</div>
			<p class="layadmin-homepage-about">
			  关于我
			</p>
			<ul class="layadmin-homepage-list-group">
			  <li class="list-group-item"><i class="layui-icon layui-icon-location"></i>中国北京</li>
			  <li class="list-group-item"><a href="https://weibo.com/tongleer" target="_blank" class="color"><i class="layui-icon layui-icon-login-weibo"></i><span style="word-wrap:break-word;">https://weibo.com/tongleer</span></a></li>
			</ul>
			<div class="layadmin-homepage-pad-hor">
			  <mdall><?php echo $bloginfo; ?></mdall>
			</div>
			<p class="layadmin-homepage-about">
			  技能
			</p>
			<ul class="layadmin-homepage-list-inline">
			  <a href="javascript:;" class="layui-btn layui-btn-primary">Android</a>
			  <a href="javascript:;" class="layui-btn layui-btn-primary">PHP</a>
			  <a href="javascript:;" class="layui-btn layui-btn-primary">太极</a>
			</ul>
			<p class="layadmin-homepage-about">
			  统计
			</p>
			<?php
			$countBlog=$DB->once_fetch_array("SELECT count(*) AS total FROM ".DB_PREFIX."blog WHERE hide='n' and checked='y'");
			$countComment=$DB->once_fetch_array("SELECT count(*) AS total FROM ".DB_PREFIX."comment WHERE hide='n'");
			$countUser=$DB->once_fetch_array("SELECT count(*) AS total FROM ".DB_PREFIX."user");
			$countTwitter=$DB->once_fetch_array("SELECT count(*) AS total FROM ".DB_PREFIX."twitter");
			?>
			<ul class="layadmin-homepage-list-inline">
			  <a href="javascript:;" class="layui-btn layui-btn-primary">文章数 <?=$countBlog["total"];?></a>
			  <a href="javascript:;" class="layui-btn layui-btn-primary">评论数 <?=$countComment["total"];?></a>
			  <a href="javascript:;" class="layui-btn layui-btn-primary">用户数 <?=$countUser["total"];?></a>
			  <a href="javascript:;" class="layui-btn layui-btn-primary">微语数 <?=$countTwitter["total"];?></a>
			</ul>
		</div>
		
        <div class="layui-row layadmin-homepage-padding15" style="background-color:#fff;">
          <hr class="new-section-xs"></hr>
          <div class="layui-col-md12 layadmin-homepage-padding8">
            <div class="layui-row layadmin-homepage-text-center">
			  <?php blog_navi();?>
            </div>
          </div>
        </div>