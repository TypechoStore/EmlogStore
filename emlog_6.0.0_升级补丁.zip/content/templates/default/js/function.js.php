<script>
layui.config({
base: '<?php echo BLOG_URL.ADMIN_DIR; ?>/views/ui/'
}).extend({
index: 'lib/index'
}).use(['index']);
$(document).ready(function() {
	layui.use(["layer"], function(){
		var layer = layui.layer;
		$("#showWxAlert").click(function(){
			layer.open({
				type: 1
				,title:"微信"
				,offset: "auto"
				,id: 'wxpublicqrcode'
				,content: '<center><img src="<?php echo BLOG_URL.ADMIN_DIR; ?>/views/images/wxpublicqrcode.jpg" width="100" /></center>'
				,btn: '关闭'
				,btnAlign: 'c'
				,shade: 0
				,yes: function(){
				  layer.closeAll();
				}
			});
		});
		$("#dashangAlert").click(function(){
			layer.open({
				type: 1
				,title:"打赏"
				,offset: "auto"
				,id: 'wxpayqrcode'
				,content: '<center><img src="<?php echo BLOG_URL.ADMIN_DIR; ?>/views/images/wxpayqrcode.jpg" width="100" /></center>'
				,btn: '关闭'
				,btnAlign: 'c'
				,shade: 0
				,yes: function(){
				  layer.closeAll();
				}
			});
		});
	});
	/*点赞js代码开始*/
	$(".slzanpd").click(function(){
		var a = $(this),
		id = a.data('slzanpd');
		if (slzanpd_check(id)) {
			layer.msg('您已赞过本文！');
		} else {
			$.post('', {
				plugin: 'slzanpd',
				action: 'slzan',
				id: id
			},
			function(b) {
				a.find('u').html(b);
				slzanpd_(a);
			});
			location.reload();
		}
	});
	$('[data-slzanpd]').each(function() {
		var a = $(this),
		id = a.data('slzanpd');
		if (slzanpd_check(id)) {
			slzanpd_(a);
		} else {
			a.attr('title', '给作者来点动力吧！')
		}
	});
	function slzanpd_check(id) {
		return new RegExp('slzanpd_' + id + '=true').test(document.cookie);
	}
	function slzanpd_(a) {
		a.css('cursor', 'not-allowed').attr('title', '您已赞过本文！');
	}
	/*点赞js代码结束*/
});
</script>