<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content" class="layui-row layui-col-space20 layadmin-homepage-list-imgtxt">
  <div id="contentleft" class="layui-col-md9">
	<style>
	.media-body img{
		display: block;max-width: 100%;height: auto;margin-top: 10px;
	}
	</style>
	<div class="panel-body layadmin-homepage-shadow">
		<?php
		$authorRes = $DB->query("SELECT email FROM ".DB_PREFIX."user WHERE uid=".$author);
		$authorRow = $DB->fetch_array($authorRes);
		$host = 'https://secure.gravatar.com';
		$url = '/avatar/';
		$size = '50';
		$rating = 'g';
		$hash = md5(strtolower($authorRow["email"]));
		$avatar = $host . $url . $hash . '?s=' . $size . '&r=' . $rating . '&d=mm';
		?>
		<a href="<?=Url::author($author);?>" title="<?=$authorRow["email"];?>" class="media-left">
		  <img src="<?=$avatar;?>" height="46px" width="46px">
		</a>
		<div class="media-body">
		  <div class="pad-btm">
			<p class="fontColor"><?php topflg($top); ?><?php echo $log_title; ?></p>
			<p class="min-font">
			  <span class="layui-breadcrumb" lay-separator="-">
				<?php blog_sort($logid); ?> 
				<?php blog_author($author); ?>
				<a href="javascript:;"><?php echo date('Y-n-j', $date); ?></a>
				<?php editflg($logid,$author); ?>
				<?php blog_tag($logid); ?>
			  </span>
			</p>         
		  </div>
		  <?php echo unCompress(formatContent($log_content));?>
		  
		  <style>
			#jingyanfoot{
				position: fixed;
				bottom: 0;
				left:0;
				z-index: 9999;
				width:100%;;
				height:48px;
				background:rgba(0, 0, 0, 0.5) none repeat scroll 0 0 !important;/*实现FF背景透明，文字不透明*/
				filter:Alpha(opacity=0.5);
				background:#fff;/*实现IE背景透明*/
			}
			.jingyandiv{
				width:100%;
				height:48px;
				line-height:48px;
				margin:0 auto;
			}
			.jingyandiv a:active{color:#ffffff;}
			.jingyandiv a:link{color:#ffffff;}
			.jingyandiv a:hover{color:#ffffff;}
			.jingyandiv a:visited{color:#ffffff;}
		  </style>
		  <?php if($copyurl!=""){?>
			<?php if($copyurl!=""&&isMobile()){?>
				<div id="jingyanfoot">
					<div class="jingyandiv">
						<center><a href="<?=$copyurl?>" target="_blank" class="layui-btn">阅读原文</a></center>
					</div>
				</div>
			<?php }else if($copyurl!=""&&!isMobile()){?>
			<center><a href="<?=$copyurl?>" target="_blank" class="layui-btn">阅读原文</a></center>
			<?php }?>
		  <?php }else{?>
			<blockquote class="layui-elem-quote">
				本篇文章<a>如无特别注明</a>均为原创。<span>作者：<?php blog_author($author); ?> ，</span>复制或转载请<a>以超链接形式</a>注明转自 <a href="/"><?php echo $blogname; ?></a> 。<br/>原文地址《<a href="<?php echo $log_url; ?>"><?php echo $log_title; ?></a>》。如果此文侵犯了原作者的权益可联系我们予以删除。
			</blockquote>
		  <?php }?>
		  
		  <?php doAction('log_related', $logData); ?>
		  <div class="media">
			<div class="media-right">
			  <ul class="list-inline">
				<li>
				  <a href="javascript:;">
					<i class="layui-icon layui-icon-share"></i>
					<?php $sharecontent=subString(str_replace('', '', strip_tags(rmBreak($log_content))),0,140);?>
					<a href="https://www.tongleer.com/api/web/?action=qrcode&url=<?=curPageURL();?>" onclick="window.open(this.href, 'share', 'width=200,height=200,top=100,left=100');return false;" ><i class="layui-icon layui-icon-login-wechat"></i></a>
					<a href="http://service.weibo.com/share/share.php?url=<?=curPageURL();?>&title=<?php echo $log_title; ?>" onclick="window.open(this.href, 'share', 'width=550,height=335');return false;" ><i class="layui-icon layui-icon-login-weibo"></i></a>
					<a href="http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=<?=curPageURL();?>&title=<?php echo $log_title; ?>&site=<?php echo BLOG_URL; ?>&desc=这是一篇神奇的文章&summary=<?php echo $sharecontent; ?>&pics=<?php if(getBlogImages($log_content)){echo getBlogImages($log_content)[0];}?>" onclick="window.open(this.href, 'share', 'width=550,height=335');return false;" ><i class="layui-icon layui-icon-login-qq"></i></a></a>
				  </a>
				</li>
				<li>
				  <a href="javascript:;" class="slzanpd" data-slzanpd="<?php echo $logid;?>" title="喜欢这篇文章就赞一个吧！">
					<i class="layui-icon layui-icon-praise"></i>
					<span><?php echo(isset($slzan)?$slzan:getnum($logid));?></span>
				  </a>
				</li>
				<li>
					<a href="javascript:;">
					  <i class="layui-icon layui-icon-reply-fill"></i>
					  <span><?php echo $comnum; ?></span>
					</a>
				</li>
				<li>
					<a href="javascript:;">
					  <i class="layui-icon layui-icon-fire"></i>
					  <span><?php echo $views; ?></span>
					</a>
				</li>
			  </ul>
			</div>
		  </div>
		  <div class="media-list">
			<?php neighbor_log($neighborLog); ?>
		  </div>
		  <div class="media-list">
			<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
			<?php blog_comments($comments); ?>
		  </div>
		</div>
	</div>
  </div><!--end #contentleft-->
  <?php include View::getView('side');?>
</div>
<?php include View::getView('footer');?>