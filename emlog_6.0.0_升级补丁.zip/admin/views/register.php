<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>注册</title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <meta name="description" content="">
  <meta name="author" content="tongleer">
  <link rel="stylesheet" href="./views/ui/layui/css/layui.css" media="all">
  <link rel="stylesheet" href="./views/ui/style/admin.css" media="all">
  <link rel="stylesheet" href="./views/ui/style/login.css" media="all">
  <script type="text/javascript" src="../include/lib/js/jquery/jquery-1.11.0.js?v=<?php echo Option::EMLOG_VERSION; ?>"></script>
</head>
<body>

  <div class="layadmin-user-login layadmin-user-display-show" id="user-login" style="display: none;">
    <div class="layadmin-user-login-main">
      <div class="layadmin-user-login-box layadmin-user-login-header">
        <h2><a href="<?php echo Option::get('blogurl'); ?>"><?php echo Option::get('blogname'); ?></a></h2>
        <p><?php echo Option::get('bloginfo'); ?></p>
      </div>
	  <form name="f" method="post" action="./index.php?action=register">
		  <div class="layadmin-user-login-box layadmin-user-login-body layui-form">
			<div class="layui-form-item">
			  <label class="layadmin-user-login-icon layui-icon layui-icon-username" for="user-login-username"></label>
			  <input type="text" name="user" id="user" lay-verify="email" placeholder="邮箱" class="layui-input">
			</div>
			<div class="layui-form-item">
			  <div class="layui-row">
				<div class="layui-col-xs7">
				  <label class="layadmin-user-login-icon layui-icon layui-icon-vercode" for="user-login-vercode"></label>
				  <input type="text" name="vercode" id="vercode" lay-verify="required" placeholder="验证码" class="layui-input">
				</div>
				<div class="layui-col-xs5">
				  <div style="margin-left: 10px;">
					<button type="button" class="layui-btn layui-btn-primary layui-btn-fluid" id="user-getsmscode">获取验证码</button>
				  </div>
				</div>
			  </div>
			</div>
			<div class="layui-form-item">
			  <label class="layadmin-user-login-icon layui-icon layui-icon-password" for="user-login-password"></label>
			  <input type="password" name="pw" id="pw" lay-verify="required" placeholder="密码" class="layui-input">
			</div>
			<div class="layui-form-item">
			  <label class="layadmin-user-login-icon layui-icon layui-icon-password" for="user-login-repass"></label>
			  <input type="password" name="repass" id="repass" lay-verify="required" placeholder="确认密码" class="layui-input">
			</div>
			<div class="layui-form-item">
			  <label class="layadmin-user-login-icon layui-icon layui-icon-username" for="user-login-nickname"></label>
			  <input type="text" name="nickname" id="nickname" lay-verify="nickname" placeholder="昵称" class="layui-input">
			</div>
			<div class="layui-form-item">
			  <button class="layui-btn layui-btn-fluid" lay-submit lay-filter="user-reg-submit">注 册</button>
			</div>
			<?php if(isset($_GET['error_nicklength'])||isset($_GET['error_mailcheck'])||isset($_GET['error_code'])||isset($_GET['error_pass'])||isset($_GET['error_repass'])||isset($_GET['error_mis'])||isset($_GET['error_reuser'])||isset($_GET['error_nickexist'])){?>
			  <blockquote class="layui-elem-quote layui-quote-nm">
				<?php if (isset($_GET['error_nicklength'])){echo "昵称不能太长";}?>
				<?php if (isset($_GET['error_mailcheck'])){echo "电子邮件格式错误";}?>
				<?php if (isset($_GET['error_code'])){echo "邮箱验证码不正确";}?>
				<?php if (isset($_GET['error_pass'])){echo "密码长度不得小于6位";}?>
				<?php if (isset($_GET['error_repass'])){echo "两次输入的密码不一致";}?>
				<?php if (isset($_GET['error_mis'])){echo "填写邮箱和发送验证码的邮箱不一致";}?>
				<?php if (isset($_GET['error_reuser'])){echo "该登录名已存在";}?>
				<?php if (isset($_GET['error_nickexist'])){echo "该昵称已存在";}?>
			  </blockquote>
			<?php }?>
			<div class="layui-trans layui-form-item layadmin-user-login-other">
			  
			  <a href="./index.php?action=<?=md5(date("Y-m-d h:i"));?>" class="layadmin-user-jump-change layadmin-link layui-hide-xs">用已有帐号登入</a>
			  <a href="./index.php?action=<?=md5(date("Y-m-d h:i"));?>" class="layadmin-user-jump-change layadmin-link layui-hide-sm layui-show-xs-inline-block">登入</a>
			</div>
			<div class="layui-form-item">
			  <?php doAction('register_ext'); ?>
			</div>
		  </div>
	  </form>
    </div>
    
    <div class="layui-trans layadmin-user-login-footer">
      <p>
		© <?=date("Y");?> Dev by <a href="https://www.tongleer.com/" class="blue-text" target="_blank">Tle</a>.
		<br />
		Powered by <a href="https://www.layui.com/" class="blue-text" target="_blank">Layui</a> & <a href="http://www.emlog.net/" class="blue-text" target="_blank">Emlog</a>
	  </p>
      <p>
        <span><a href="http://club.tongleer.com/" target="_blank">获取程序</a></span>
        <span><a href="http://club.tongleer.com/" target="_blank">论坛交流</a></span>
        <span><a href="https://www.tongleer.com/" target="_blank">前往博客</a></span>
      </p>
    </div>

  </div>

  <script src="./views/ui/layui/layui.js"></script>  
  <script>
	layui.config({
		base: './views/ui/'
	}).extend({
		index: 'lib/index'
	}).use(['index', 'user'], function(){
		var $ = layui.$
		,setter = layui.setter
		,admin = layui.admin
		,form = layui.form
		,router = layui.router();

		form.render();
	});
	$("#user-getsmscode").click(function(){
		if(!/^(\w-*\.*)+@(\w-?)+(\.\w{2,})+$/.test($("input[name='user']").val())){
			layer.msg("电子邮件格式错误");
			return;
		}
		$.post("index.php?action=sendMailCode",{username:$("input[name='user']").val()},function(data){
			sendSmsCode();
		});
	});
	var timer;
	var countdown=60;
	function sendSmsCode() {
		if (countdown == 0) {
			$("#user-getsmscode").text('获取验证码');
			$("#user-getsmscode").attr('disabled',false);
			$("#user-getsmscode").removeClass("layui-btn-disabled");
			countdown = 60;
			clearTimeout(timer);
			return;
		} else {
			$("#user-getsmscode").text(countdown+"秒");
			$("#user-getsmscode").attr('disabled',true);
			$("#user-getsmscode").addClass("layui-btn-disabled");
			countdown--; 
		} 
		timer=setTimeout(function() { 
			sendSmsCode();
		},1000) 
	}
  </script>
</body>
</html>