<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
	  <legend><b>链接分类</b></legend>
	</fieldset>
	<?php if(isset($_GET['active_taxis'])):?><blockquote class="actived layui-elem-quote">排序更新成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_del'])):?><blockquote class="actived layui-elem-quote">删除分类成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_edit'])):?><blockquote class="actived layui-elem-quote">修改分类成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_add'])):?><blockquote class="actived layui-elem-quote">添加分类成功</blockquote><?php endif;?>
	<?php if(isset($_GET['error_a'])):?><blockquote class="error layui-elem-quote">分类名称不能为空</blockquote><?php endif;?>
	<?php if(isset($_GET['error_b'])):?><blockquote class="error layui-elem-quote">没有可排序的分类</blockquote><?php endif;?>
</div>
<form class="layui-form" method="post" action="sortlink.php?action=taxis">			
	<table class="layui-table" id="adm_sort_list">
		<thead>
			<tr>
			<th width="40">序号</th>
			<th>分类</th>
			<th width="60">数量</th>
			<th width="90">操作</th>
			</tr>
		</thead>
		<tbody>
		<?php if($sortlink):
		foreach($sortlink as $key=>$value):?>
		<tr>
			<td>
				<input type="hidden" value="<?php echo $value['linksort_id'];?>" class="layui-input" />
				<input maxlength="4" class="layui-input" name="sortlink[<?php echo $value['linksort_id']; ?>]" value="<?php echo $value['taxis']; ?>" />
			</td>
			<td>
				<a href="sortlink.php?action=mod_sortlink&linksort_id=<?php echo $value['linksort_id']; ?>"><?php echo $value['linksort_name']; ?></a>
			</td>
			<td><a href="./link.php?linksortid=<?php echo $value['linksort_id']; ?>"><?php echo $value['linknum']; ?></a></td>
			<td>
				<a href="sortlink.php?action=mod_sortlink&linksort_id=<?php echo $value['linksort_id']; ?>" title="编辑">编辑</a>
				<a href="javascript:em_confirm(<?php echo $value['linksort_id']; ?>,'sortlink','<?php echo LoginAuth::genToken(); ?>');" title="删除">删除</a>
			</td>
		</tr>
		<?php endforeach;else:?><tr><td colspan="8"> 还没有添加分类 </td></tr><?php endif;?>  
		</tbody>
	</table>
	<div style="padding-top:10px">
		  <input type="submit" value="更改排序" class="layui-btn layui-btn-primary layui-btn-xs" />
	</div>
</form>

<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
  <legend>
	<button type="button" onclick="displayToggle('sortlink_new', 2);" class="layui-btn layui-btn-primary">添加分类+</button>
  </legend>
</fieldset>
<div id="sortlink_new">
	<form class="layui-form" action="sortlink.php?action=add" method="post">
		<li><input style="width:240px;" type="text" maxlength="4" name="taxis" class="layui-input" placeholder="序号" /></li>
		<li><input style="width:240px;" type="text" name="linksort_name" id="linksort_name" class="layui-input" placeholder="名称" /></li>
		<li> 
			<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
			<input type="submit" class="layui-btn" name="" value="添加"  />
		</li>
	</form>
</div>
<script>
$("#sortlink_new").css('display', $.cookie('em_sortlink_new') ? $.cookie('em_sortlink_new') : 'none');
$(document).ready(function(){
	$("#adm_sort_list tbody tr:odd").css("background-color","#F7F7F7");
	$("#adm_sort_list tbody tr")
		.mouseover(function(){$(this).css("background-color","#E9F1FA");$(this).find("span").show();})
		.mouseout(function(){$(this).css("background-color","#F7F7F7");$(this).find("span").hide();})
});
setTimeout(hideActived,2600);
$("#menu_linksort").addClass('layui-this');
$("#menu_linksort").parent().parent().addClass('layui-nav-itemed');
</script>