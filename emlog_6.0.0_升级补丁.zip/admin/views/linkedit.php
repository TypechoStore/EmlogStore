<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
	  <legend><b>编辑链接</b></legend>
	</fieldset>
</div>
<form class="layui-form" action="link.php?action=update_link" method="post">
<div>
	<li><input size="40" value="<?php echo $sitename; ?>" class="layui-input" name="sitename" placeholder="名称（必填）" /></li>
	<li><input size="40" value="<?php echo $siteurl; ?>" class="layui-input" name="siteurl" placeholder="地址（必填）" /></li>
	<li><input type="text" id="pic" value="<?php echo $sitepic; ?>" name="sitepic" maxlength="255" class="layui-input" placeholder="图标"></li>
	<li>        
		<select name="linksortid" id="linksortid">
			<option value="-1">选择分类</option>
			 <?php foreach($sortlink as $key=>$value):?>
			<option value="<?php echo $key; ?>"<?php if($linksortid == $key):?> selected="selected"<?php endif; ?>><?php echo $value['linksort_name']; ?></option>
			<?php endforeach; ?>
		</select>
	</li>
	<li><textarea name="description" rows="3" class="layui-textarea" cols="42" placeholder="链接描述"><?php echo $description; ?></textarea></li>
	<li>
	<input type="hidden" value="<?php echo $linkId; ?>" name="linkid" />
	<input type="submit" value="保 存" class="layui-btn" onClick="check_url()" />
	<input type="button" value="取 消" class="layui-btn layui-btn-primary" onclick="javascript: window.history.back();" /></li>
</div>
</form>
<script>
$(function(){
	layui.use(["form"], function(){
		var form = layui.form;
	});
});
function check_url(){  
    var elem = document.getElementById("pic");
    var input_value = elem.value;  
    input_value = input_value.toLowerCase();  
    var regExr = /^(http:|https:)\/\/.*$/m;  
    var result = regExr.test(input_value);  
    if (!result){  
        var new_value = "http://"+input_value;  
        elem.value=new_value;  
    }  
}
$("#menu_link").addClass('layui-this');
$("#menu_link").parent().parent().addClass('layui-nav-itemed');
</script>