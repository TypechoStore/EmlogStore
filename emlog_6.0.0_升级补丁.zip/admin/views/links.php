<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
	  <legend><b>友情链接管理</b></legend>
	</fieldset>
	<?php if(isset($_GET['active_taxis'])):?><blockquote class="actived layui-elem-quote">排序更新成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_del'])):?><blockquote class="actived layui-elem-quote">删除成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_edit'])):?><blockquote class="actived layui-elem-quote">修改成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_add'])):?><blockquote class="actived layui-elem-quote">添加成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_hide'])):?><div class="alert alert-success">显示成功</div><?php endif;?>
	<?php if(isset($_GET['active_hide_select'])):?><div class="alert alert-success">隐藏成功</div><?php endif;?>
	<?php if(isset($_GET['active_move_select'])):?><div class="alert alert-success">移动成功</div><?php endif;?>
	<?php if(isset($_GET['active_del_select'])):?><div class="alert alert-success">删除成功</div><?php endif;?>
	<?php if(isset($_GET['error_a'])):?><blockquote class="error layui-elem-quote">站点名称和地址不能为空</blockquote><?php endif;?>
	<?php if(isset($_GET['error_b'])):?><blockquote class="error layui-elem-quote">没有可排序的链接</blockquote><?php endif;?>
</div>
<form id="form_link" class="layui-form" action="link.php?action=operate_link" method="post">
  <table class="layui-table" width="100%" id="adm_link_list">
    <thead>
      <tr>
		<th><b></b></th>
	  	<th width="50"><b>序号</b></th>
        <th width="230"><b>链接</b></th>
        <th width="80"><b>状态</b></th>
		<th width="80"><b>查看</b></th>
		<th width="400"><b>描述</b></th>
        <th width="100"></th>
      </tr>
    </thead>
    <tbody>
	<?php 
	if($links):
	foreach($links as $key=>$value):
	$linkSortName = ($value['linksortid'] == -1 || $value['linksortid'] == 0) && !array_key_exists($value['linksortid'], $sortlink) ? '未分类' : $sortlink[$value['linksortid']]['linksort_name'];
	doAction('adm_link_display');
	?>  
      <tr>
		<td><input type="checkbox" name="linkids[]" value="<?php echo $value['id']; ?>" class="ids" lay-skin="primary" /></td>
		<td><input class="layui-input" name="link[<?php echo $value['id']; ?>]" value="<?php echo $value['taxis']; ?>" maxlength="4" style="width:30px;" /></td>
		<td><a href="link.php?action=mod_link&amp;linkid=<?php echo $value['id']; ?>" title="修改链接"><?php echo $value['sitename']; ?></a></td>
		<td>
		<?php if ($value['hide'] == 'n'): ?>
		<a href="link.php?action=hide&amp;linkid=<?php echo $value['id']; ?>" title="点击隐藏链接">显示</a>
		<?php else: ?>
		<a href="link.php?action=show&amp;linkid=<?php echo $value['id']; ?>" title="点击显示链接" style="color:red;">隐藏</a>
		<?php endif;?>
		</td>
		<td>
	  	<a href="<?php echo $value['siteurl']; ?>" target="_blank" title="查看链接">
	  	<img src="./views/images/vlog.gif" align="absbottom" border="0" /></a>
	  	</td>
        <td><?php echo $value['description']; ?></td>
        <td>
        <a href="link.php?action=mod_link&amp;linkid=<?php echo $value['id']; ?>">编辑</a>
        <a href="javascript: em_confirm(<?php echo $value['id']; ?>, 'link', '<?php echo LoginAuth::genToken(); ?>');">删除</a>
        </td>
      </tr>
	<?php endforeach;else:?>
	  <tr><td colspan="7">还没有添加链接</td></tr>
	<?php endif;?>
    </tbody>
  </table>
  <div>
	<input type="checkbox" title="全选" lay-filter="select_all">
	<button type="button" class="layui-btn layui-btn-primary" onClick="linkact('del');"><i class="layui-icon"></i></button>
	<button type="button" class="layui-btn layui-btn-primary" onClick="linkact('hide');">隐藏</button>
	<button type="button" class="layui-btn layui-btn-primary" onClick="linkact('show');">显示</button>
	<input type="submit" id="select_order" value="改变排序" class="layui-btn layui-btn-primary" />
	<div class="layui-input-inline">
		<select name="linksort" id="linksort" lay-filter="linksort">
			<option value="" selected="selected">移动到分类...</option>
			<?php foreach($sortlink as $key=>$value):?>
			<option value="<?php echo $value['linksort_id']; ?>"><?php echo $value['linksort_name']; ?></option>
			<?php endforeach;?>
			<option value="-1">未分类</option>
		</select>
	</div>
	<div class="layui-input-inline">
		<select name="bysort" id="bysort" lay-filter="bysort">
			<option value="" selected="selected">按分类查看...</option>
			<?php foreach($sortlink as $key=>$value):$flg = $value['linksort_id'] == $linksortid ? 'selected' : '';?>
			<option value="<?php echo $key; ?>" <?php echo $flg; ?>><?php echo $value['linksort_name']; ?></option>
			<?php endforeach; ?>
			<option value="-1" <?php if($linksortid == -1) echo 'selected'; ?>>未分类</option>
		</select>
	</div>
	<input type="hidden" name="linksortid" id="linksortid" value="<?php echo $linksortid; ?>" />
	<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
	<input name="operate" id="operate" value="" type="hidden" />
  </div>
</form>
<center><div id="page"></div></center>
<center>(有<?php echo $linkNum; ?>个链接)</center>
<form class="layui-form" action="link.php?action=addlink" method="post" name="link" id="link">
<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
  <legend>
	<button type="button" onclick="displayToggle('link_new', 2);" class="layui-btn layui-btn-primary">添加链接+</button>
  </legend>
</fieldset>
<div id="link_new">
	<li><input maxlength="4" style="width:60px;" class="layui-input" name="taxis" placeholder="序号" /></li>
	<li><input maxlength="200" style="width:240px;" class="layui-input" name="sitename" placeholder="名称（必填）" /></li>
	<li><input maxlength="200" style="width:240px;" class="layui-input" name="siteurl" placeholder="地址（必填）" /></li>
	<li><input type="text" maxlength="255" style="width:240px;" id="pic" name="sitepic" class="layui-input" placeholder="图标" /></li>
	<li style="width:240px;">    
	<select name="linksortid" id="linksortid">
        <option value="-1">选择分类</option>
        <?php foreach($sortlink as $key=>$value):?>
        <option value="<?php echo $key; ?>"><?php echo $value['linksort_name']; ?></option>
        <?php endforeach; ?>
    </select>      
    </li>
	
	<li><textarea name="description" type="text" class="layui-textarea" placeholder="描述" style="width:240px;height:60px;overflow:auto;"></textarea></li>
	<li><input type="submit" name="" value="添加" class="layui-btn" onclick="check_url()" /></li>
</div>
</form>
<script>
$("#link_new").css('display', $.cookie('em_link_new') ? $.cookie('em_link_new') : 'none');
$(document).ready(function(){
	layui.use(["laypage", "layer", "form"], function(){
		var form = layui.form;
		var laypage = layui.laypage
		  ,layer = layui.layer;
		  laypage.render({
			elem: "page"
			,count: <?=$linkNum;?>
			,limit: <?=Option::get('admin_perpage_num');?>
			,curr:<?=$page;?>
			,layout: ["prev", "page", "next", "skip"]
			,jump: function(obj,first){
				if(!first){
				  location.href="link.php?<?=$subPage;?>&page="+obj.curr;
				}
			}
		  });
		form.on('checkbox(select_all)', function(data){
			$("input[name='linkids[]']").each(function () {
				this.checked = data.elem.checked;
			});
			form.render('checkbox');
		});
		form.on('select(bysort)', function(data){
			window.open("./link.php?linksortid=" + data.value, "_self");
		});
		form.on('select(linksort)', function(data){
			if (getChecked('ids') == false) {
				layer.msg('请选择要操作的文章');
				return;}
			if($('#linksort').val() == '')return;
			$("#operate").val("move");
			$("#form_link").submit();
		});
	});
	$("#adm_link_list tbody tr:odd").css("background-color","#F7F7F7");
	$("#adm_link_list tbody tr")
		.mouseover(function(){$(this).css("background-color","#E9F1FA");$(this).find("span").show();})
		.mouseout(function(){$(this).css("background-color","#F7F7F7");$(this).find("span").hide();})
});
function check_url(){  
    var elem = document.getElementById("pic");  
    var input_value = elem.value;  
    input_value = input_value.toLowerCase();  
    var regExr = /^(http:|https:)\/\/.*$/m;  
    var result = regExr.test(input_value);  
    if (!result){  
        var new_value = "http://"+input_value;  
        elem.value=new_value;  
    }  
}  
function linkact(act){
	if (getChecked('ids') == false) {
		layer.msg('请选择要操作的链接');
		return;
	}
	if(act == 'del' && !confirm('你确定要删除所选链接吗？')){
		return;
	}
	$("#operate").val(act);
	$("#form_link").submit();
}
$("#select_order").click(function(){
	$("#form_link").attr("action","link.php?action=link_taxis");
	$("#form_link").submit();
})
setTimeout(hideActived,2600);
$("#menu_link").addClass('layui-this');
$("#menu_link").parent().parent().addClass('layui-nav-itemed');
</script>