<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
	  <legend><b>修改作者资料</b></legend>
	</fieldset>
	<?php if(isset($_GET['error_login'])):?><blockquote class="error layui-elem-quote">用户名不能为空</blockquote><?php endif;?>
	<?php if(isset($_GET['error_exist'])):?><blockquote class="error layui-elem-quote">该用户名已存在</blockquote><?php endif;?>
	<?php if(isset($_GET['error_pwd_len'])):?><blockquote class="error layui-elem-quote">密码长度不得小于6位</blockquote><?php endif;?>
	<?php if(isset($_GET['error_pwd2'])):?><blockquote class="error layui-elem-quote">两次输入密码不一致</blockquote><?php endif;?>
</div>
<form class="layui-form" action="user.php?action=update" method="post">
<div>
	<li>
		<div style="margin:10px 0px;">用户名</div>
		<input type="text" value="<?php echo $username; ?>" name="username" style="width:200px;" class="layui-input" />
	</li>
	<li>
		<div style="margin:10px 0px;">昵称</div>
		<input type="text" value="<?php echo $nickname; ?>" name="nickname" style="width:200px;" class="layui-input" />
	</li>
	<li>
		<div style="margin:10px 0px;">新密码（不修改请留空）</div>
		<input type="password" value="" name="password" style="width:200px;" class="layui-input" />
	</li>
	<li>
		<div style="margin:10px 0px;">重复新密码</div>
		<input type="password" value="" name="password2" style="width:200px;" class="layui-input" />
	</li>
	<li>
		<div style="margin:10px 0px;">电子邮件</div>
		<input type="text"  value="<?php echo $email; ?>" name="email" style="width:200px;" class="layui-input" />
	</li>
	<li>
		<div style="margin:10px 0px;">网站</div>
		<input name="website" type="url" id="website" value="<?php echo $website; ?>" style="width:200px;" class="layui-input" /> 
	</li>
    <li style="margin-top:10px;width:200px;">
		<select name="role" id="role" lay-filter="role">
			<option value="writer" <?php echo $ex1; ?>>作者</option>
			<option value="admin" <?php echo $ex2; ?>>管理员</option>
		</select>
	</li>
    <li id="ischeck" style="margin-top:10px;width:200px;">
	<select name="ischeck">
        <option value="n" <?php echo $ex3; ?>>文章不需要审核</option>
		<option value="y" <?php echo $ex4; ?>>文章需要审核</option>
	</select>
	</li>
	<li>
		<div style="margin:10px 0px;">个人描述</div>
		<textarea name="description" rows="5" style="width:200px;" class="layui-textarea"><?php echo $description; ?></textarea>
	</li>
	<li style="margin-top:10px;">
		<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
		<input type="hidden" value="<?php echo $uid; ?>" name="uid" />
		<input type="submit" value="保 存" class="layui-btn" />
		<input type="button" value="取 消" class="layui-btn layui-btn-primary" onclick="window.location='user.php';" /></li>
</div>
</form>
<script>
$(function(){
	layui.use(["form"], function(){
		var form = layui.form;
		form.on('select(role)', function(data){
			$("#ischeck").toggle()
		});
	});
});
$("#menu_user").addClass('layui-this');
$("#menu_user").parent().parent().addClass('layui-nav-itemed');
setTimeout(hideActived,2600);
if($("#role").val() == 'admin') $("#ischeck").hide();
</script>