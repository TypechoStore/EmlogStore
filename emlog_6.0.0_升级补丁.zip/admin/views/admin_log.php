<?php
if(!defined('EMLOG_ROOT')) {exit('error!');}
$isdraft = $pid == 'draft' ? '&pid=draft' : '';
$isDisplaySort = !$sid ? "style=\"display:none;\"" : '';
$isDisplayTag = !$tagId ? "style=\"display:none;\"" : '';
$isDisplayUser = !$uid ? "style=\"display:none;\"" : '';
?>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
	  <legend><?php echo $pwd; ?></legend>
	</fieldset>
	<?php if(isset($_GET['active_del'])):?><blockquote class="actived layui-elem-quote">删除成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_up'])):?><blockquote class="actived layui-elem-quote">置顶成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_down'])):?><blockquote class="actived layui-elem-quote">取消置顶成功</blockquote><?php endif;?>
	<?php if(isset($_GET['error_a'])):?><blockquote class="actived layui-elem-quote">请选择要处理的文章</blockquote><?php endif;?>
	<?php if(isset($_GET['error_b'])):?><blockquote class="actived layui-elem-quote">请选择要执行的操作</blockquote><?php endif;?>
	<?php if(isset($_GET['active_post'])):?><blockquote class="actived layui-elem-quote">发布成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_move'])):?><blockquote class="actived layui-elem-quote">移动成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_change_author'])):?><blockquote class="actived layui-elem-quote">更改作者成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_hide'])):?><blockquote class="actived layui-elem-quote">转入草稿箱成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_savedraft'])):?><blockquote class="actived layui-elem-quote">草稿保存成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_savelog'])):?><blockquote class="actived layui-elem-quote">保存成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_ck'])):?><blockquote class="actived layui-elem-quote">文章审核成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_unck'])):?><blockquote class="actived layui-elem-quote">文章驳回成功</blockquote><?php endif;?>
</div>
<div>
	<div>
		<div style="float:left; margin-top:8px;">
			<button type="button" class="layui-btn <?php echo !$sid && !$tagId && !$uid && !$keyword ? "layui-btn" : 'layui-btn-primary'; ?>" onClick="location.href='./admin_log.php?<?php echo $isdraft; ?>';">全部</button>
			<div class="layui-input-inline layui-form">
				<select name="bysort" id="bysort" lay-filter="bysort">
				<option value="" selected="selected">按分类查看...</option>
				<?php 
				foreach($sorts as $key=>$value):
				if ($value['pid'] != 0) {
					continue;
				}
				$flg = $value['sid'] == $sid ? 'selected' : '';
				?>
				<option value="<?php echo $value['sid']; ?>" <?php echo $flg; ?>><?php echo $value['sortname']; ?></option>
				<?php
					$children = $value['children'];
					foreach ($children as $key):
					$value = $sorts[$key];
					$flg = $value['sid'] == $sid ? 'selected' : '';
				?>
				<option value="<?php echo $value['sid']; ?>" <?php echo $flg; ?>>&nbsp; &nbsp; &nbsp; <?php echo $value['sortname']; ?></option>
				<?php
				endforeach;
				endforeach;
				?>
				<option value="-1" <?php if($sid == -1) echo 'selected'; ?>>未分类</option>
				</select>
			</div>
			<?php if (ROLE == ROLE_ADMIN && count($user_cache) > 1):?>
			<div class="layui-input-inline layui-form">
				<select name="byuser" id="byuser" lay-filter="byuser">
					<option value="" selected="selected">按作者查看...</option>
					<?php 
					foreach($user_cache as $key=>$value):
					$flg = $key == $uid ? 'selected' : '';
					?>
					<option value="<?php echo $key; ?>" <?php echo $flg; ?>><?php echo $value['name']; ?></option>
					<?php
					endforeach;
					?>
				</select>
			</div>
			<?php endif;?>
			<button type="button" class="layui-btn layui-btn-primary" id="f_t_tag">按标签查看</button>
		</div>
		<div style="float:right;">
			<form action="admin_log.php" method="get">
			<input type="text" id="input_s" name="keyword" autocomplete="off" placeholder="输入关键词搜索..." class="layui-input">
			<?php if($pid):?>
			<input type="hidden" id="pid" name="pid" value="draft">
			<?php endif;?>
			</form>
		</div>
		<div style="clear:both"></div>
	</div>
	<div id="f_tag" <?php echo $isDisplayTag ?>>
		<?php 
		$tagshtml='<blockquote class="layui-elem-quote layui-quote-nm">';
		if(empty($tags)){
			$tagshtml.='还没有标签';
		}
		foreach($tags as $val){
			$tagshtml.='
				<button type="button" class="layui-btn layui-btn-primary layui-btn-radius" onClick="location.href=\'./admin_log.php?tagid='.$val["tid"].$isdraft.'\';">'.$val["tagname"].'</button>
			';
		}
		$tagshtml.='</blockquote>';
		echo $tagshtml;
		?>
	</div>
</div>
<form class="layui-form" action="admin_log.php?action=operate_log" method="post" name="form_log" id="form_log">
	<input type="hidden" name="pid" value="<?php echo $pid; ?>">
	<table id="adm_log_list" class="layui-table">
	  <colgroup>
		<col width="60">
		<col width="400">
		<?php if ($pid != 'draft'): ?>
		<col width="60">
		<?php endif; ?>
		<col width="100">
		<col width="150">
		<col width="150">
		<col width="60">
		<col width="60">
	  </colgroup>
	  <thead>
		<tr>
		  <th><b></b></th>
		  <th><b>标题</b></th>
		  <?php if ($pid != 'draft'): ?>
		  <th><b>查看</b></th>
		  <?php endif; ?>
		  <th><b>作者</b></th>
		  <th><b>分类</b></th>
		  <th><b><a href="./admin_log.php?sortDate=<?php echo $sortDate.$sorturl; ?>">时间</a></th>
		  <th><b><a href="./admin_log.php?sortComm=<?php echo $sortComm.$sorturl; ?>">评论</a></b></th>
		  <th><b><a href="./admin_log.php?sortView=<?php echo $sortView.$sorturl; ?>">阅读</a></b></th>
		</tr> 
	  </thead>
	  <tbody>
		<?php
		if($logs){
			foreach($logs as $key=>$value){
				$sortName = $value['sortid'] == -1 && !array_key_exists($value['sortid'], $sorts) ? '未分类' : $sorts[$value['sortid']]['sortname'];
				$author = $user_cache[$value['author']]['name'];
				$author_role = $user_cache[$value['author']]['role'];
				?>
				<tr>
				  <td>
					<input class="ids" type="checkbox" name="blog[]" value="<?php echo $value['gid']; ?>" lay-skin="primary" />
				  </td>
				  <td>
					<a href="write_log.php?action=edit&gid=<?php echo $value['gid']; ?>"><?php echo $value['title']; ?></a>
					<?php if($value['top'] == 'y'): ?>
						<img src="./views/images/top.png" align="top" title="首页置顶" />
					<?php endif; ?>
					<?php if($value['sortop'] == 'y'): ?>
						<img src="./views/images/sortop.png" align="top" title="分类置顶" />
					<?php endif; ?>
					<?php if($value['attnum'] > 0): ?>
						<i class="layui-icon layui-icon-file" lay-tips="附件：<?php echo $value['attnum']; ?>"></i>
					<?php endif; ?>
					<?php if($pid != 'draft' && $value['checked'] == 'n'): ?>
						<span style="color:red;"> - 待审</span>
					<?php endif; ?>
					<span style="display:none; margin-left:8px;">
						<?php if($pid != 'draft' && ROLE == ROLE_ADMIN && $value['checked'] == 'n'): ?>
							<a href="./admin_log.php?action=operate_log&operate=check&gid=<?php echo $value['gid']?>&token=<?php echo LoginAuth::genToken(); ?>">审核</a> 
						<?php elseif($pid != 'draft' && ROLE == ROLE_ADMIN && $author_role == ROLE_WRITER):?>
							<a href="./admin_log.php?action=operate_log&operate=uncheck&gid=<?php echo $value['gid']?>&token=<?php echo LoginAuth::genToken(); ?>">驳回</a> 
						<?php endif;?>
					</span>
				  </td>
				  <?php if ($pid != 'draft'): ?>
				  <td>
					<a href="<?php echo Url::log($value['gid']); ?>" target="_blank" title="在新窗口查看">
					<img src="./views/images/vlog.gif" align="absbottom" border="0" /></a>
				  </td>
				  <?php endif; ?>
				  <td>
					<a href="./admin_log.php?uid=<?php echo $value['author'].$isdraft;?>"><?php echo $author; ?></a>
				  </td>
				  <td><a href="./admin_log.php?sid=<?php echo $value['sortid'].$isdraft;?>"><?php echo $sortName; ?></a></td>
				  <td><?php echo $value['date']; ?></td>
				  <td><a href="comment.php?gid=<?php echo $value['gid']; ?>"><?php echo $value['comnum']; ?></a></td>
				  <td><?php echo $value['views']; ?></a></td>
				</tr>
				<?php
			}
		}else{?>
			<tr><td colspan="8">还没有文章</td></tr>
			<?php
		}
		?>
	  </tbody>
	</table>
	<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
	<input name="operate" id="operate" value="" type="hidden" />
	<div>
		<input type="checkbox" title="全选" lay-filter="select_all">
		<button type="button" class="layui-btn layui-btn-primary" onClick="logact('del');"><i class="layui-icon"></i></button>
		<?php if($pid == 'draft'): ?>
		<button type="button" class="layui-btn layui-btn-primary" onClick="logact('pub');">发布</button>
		<?php else: ?>
		<button type="button" class="layui-btn layui-btn-primary" onClick="logact('hide');">放入草稿箱</button>
		<?php if (ROLE == ROLE_ADMIN):?>
		<div class="layui-input-inline">
		  <select name="top" id="top" lay-filter="top">
			<option value="" selected="selected">置顶操作...</option>
			<option value="top">首页置顶</option>
			<option value="sortop">分类置顶</option>
			<option value="notop">取消置顶</option>
		  </select>
		</div>
		<?php endif;?>
		<div class="layui-input-inline">
			<select name="sort" id="sort" lay-filter="sort">
				<option value="" selected="selected">移动到分类...</option>
				<?php 
				foreach($sorts as $key=>$value):
				if ($value['pid'] != 0) {
					continue;
				}
				?>
				<option value="<?php echo $value['sid']; ?>"><?php echo $value['sortname']; ?></option>
				<?php
					$children = $value['children'];
					foreach ($children as $key):
					$value = $sorts[$key];
				?>
				<option value="<?php echo $value['sid']; ?>">&nbsp; &nbsp; &nbsp; <?php echo $value['sortname']; ?></option>
				<?php
				endforeach;
				endforeach;
				?>
				<option value="-1">未分类</option>
			</select>
		</div>
		<?php if (ROLE == ROLE_ADMIN && count($user_cache) > 1):?>
		<div class="layui-input-inline">
			<select name="author" id="author" lay-filter="author">
				<option value="" selected="selected">更改作者为...</option>
				<?php foreach($user_cache as $key => $val):
				$val['name'] = $val['name'];
				?>
				<option value="<?php echo $key; ?>"><?php echo $val['name']; ?></option>
				<?php endforeach;?>
			</select>
		</div>
		<?php endif;?>
		<?php endif;?>
	</div>
</form>
<center><div id="page"></div></center>
<center>(有<?php echo $logNum; ?>篇<?php echo $pid == 'draft' ? '草稿' : '文章'; ?>)</center>
<script>
$(function(){
	layui.use(["laypage", "layer", "form"], function(){
		var form = layui.form;
		var laypage = layui.laypage
		  ,layer = layui.layer;
		  laypage.render({
			elem: "page"
			,count: <?=$logNum;?>
			,limit: <?=Option::get('admin_perpage_num');?>
			,curr:<?=$page;?>
			,layout: ["prev", "page", "next", "skip"]
			,jump: function(obj,first){
				if(!first){
				  location.href="admin_log.php?<?=$subPage;?>&page="+obj.curr;
				}
			}
		  });
		form.on('select(bysort)', function(data){
			window.open("./admin_log.php?sid=" + data.value + "<?php echo $isdraft?>", "_self");
		});
		form.on('select(byuser)', function(data){
			window.open("./admin_log.php?uid=" + data.value + "<?php echo $isdraft?>", "_self");
		});
		form.on('select(top)', function(data){
			if (getChecked('ids') == false) {
				layer.msg('请选择要操作的文章');
				return;}
			if($('#top').val() == '')return;
			$("#operate").val(data.value);
			$("#form_log").submit();
		});
		form.on('select(sort)', function(data){
			if (getChecked('ids') == false) {
				layer.msg('请选择要操作的文章');
				return;}
			if($('#sort').val() == '')return;
			$("#operate").val('move');
			$("#form_log").submit();
		});
		form.on('select(author)', function(data){
			if (getChecked('ids') == false) {
				layer.msg('请选择要操作的文章');
				return;}
			if($('#author').val() == '')return;
			$("#operate").val('change_author');
			$("#form_log").submit();
		});
		form.on('checkbox(select_all)', function(data){
			$("input[name='blog[]']").each(function () {
				this.checked = data.elem.checked;
			});
			form.render('checkbox');
		});
	});
	$("#adm_log_list tbody tr:odd").css("background-color","#F7F7F7");
	$("#adm_log_list tbody tr")
		.mouseover(function(){$(this).css("background-color","#E9F1FA");$(this).find("span").show();})
		.mouseout(function(){$(this).css("background-color","#F7F7F7");$(this).find("span").hide();})
	$("#f_t_tag").click(function(){$("#f_tag").toggle();});
});
setTimeout(hideActived,2600);
function logact(act){
	if (getChecked('ids') == false) {
		layer.msg('请选择要操作的文章');
		return;}
	if(act == 'del' && !confirm('你确定要删除所选文章吗？')){return;}
	$("#operate").val(act);
	$("#form_log").submit();
}
<?php if ($isdraft) :?>
$("#menu_draft").addClass('layui-this');
$("#menu_draft").parent().parent().addClass('layui-nav-itemed');
<?php else:?>
$("#menu_log").addClass('layui-this');
$("#menu_log").parent().parent().addClass('layui-nav-itemed');
<?php endif;?>
</script>