<?php

/**
 * 附件处理
 * @copyright (c) Emlog All Rights Reserved
 */
require_once 'globals.php';

$DB = Database::getInstance();

//上传表单显示
if ($action == 'selectFile') {
	$attachnum = 0;
	$logid = isset($_GET['logid']) ? intval($_GET['logid']) : '';
	$multi = isset($_GET['multi']) ? intval($_GET['multi']) : 0;

	if ($logid) {
        $Log_Model = new Log_Model();
        $row = $Log_Model->getOneLogForAdmin($logid);
		$attachnum = (int)$row['attnum'];
	}
	$maxsize = changeFileSize(Option::getAttMaxSize());
	//允许附件类型
	$att_type_str = '';
    $att_type_for_muti = '';
	foreach (Option::getAttType() as $val) {
		$att_type_str .= " $val";
        $att_type_for_muti .= '*.'.$val.';';
	}
	$view_tpl = $multi ? 'upload_multi' : 'upload';
	require_once(View::getView($view_tpl));
	View::output();
}

//上传附件
if ($action == 'upload') {
	$logid = isset($_GET['logid']) ? intval($_GET['logid']) : '';
	$type = isset($_GET['type']) ? addslashes(trim($_GET['type'])) : '';
	$attach = isset($_FILES['attach']) ? $_FILES['attach'] : '';
	if(Option::get('att_maxsize')==0){
		emMsg("管理员已禁止附件上传，可通过第三方插件上传。");
	}
	if ($attach) {
			if ($attach['error'] != 4) {
				$isthumbnail = Option::get('isthumbnail') == 'y' ? true : false;

				$file_name = Database::getInstance()->escape_string($attach['name']);
				$file_error = $attach['error'];
				$file_tmp_name = $attach['tmp_name'];
				$file_size = $attach['size'];

				$file_info = uploadFile($file_name, $file_error, $file_tmp_name, $file_size, Option::getAttType(), false, $isthumbnail);
				// 写入附件信息
				$query = "INSERT INTO " . DB_PREFIX . "attachment (blogid, filename, filesize, filepath, addtime, width, height, mimetype, thumfor) VALUES ('%s','%s','%s','%s','%s','%s','%s','%s', 0)";
				$query = sprintf($query, $logid, $file_info['file_name'], $file_info['size'], $file_info['file_path'], time(), $file_info['width'], $file_info['height'], $file_info['mime_type']);
				$DB->query($query);
				$aid = $DB->insert_id();
				$DB->query("UPDATE " . DB_PREFIX . "blog SET attnum=attnum+1 WHERE gid=$logid");
				// 写入缩略图信息
				if (isset($file_info['thum_file'])) {
					$query = "INSERT INTO " . DB_PREFIX . "attachment (blogid, filename, filesize, filepath, addtime, width, height, mimetype, thumfor) VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s')";
					$query = sprintf($query, $logid, $file_info['file_name'], $file_info['thum_size'], $file_info['thum_file'], time(), $file_info['thum_width'], $file_info['thum_height'], $file_info['mime_type'], $aid);
					$DB->query($query);		
					$thumaid = $DB->insert_id();
				}
				$attachment=$DB->once_fetch_array('SELECT blogid FROM '.DB_PREFIX.'attachment WHERE aid='.$aid);
				$blog=$DB->once_fetch_array('SELECT type FROM '.DB_PREFIX.'blog WHERE gid='.$attachment["blogid"]);
				
				$file_path=$file_info['file_path'];
				if($type=="video"){
					$file_path = BLOG_URL.substr($file_info['file_path'],3);
				}
				echo json_encode(array("code"=>0,"msg"=>"ok","data"=>array("src"=>$file_path,"filename"=>$file_info['file_name'],"thumsrc"=>$file_info['thum_file'],"width"=>$file_info['width'],"height"=>$file_info['height'],"aid"=>$aid,"thumaid"=>$thumaid,"BLOG_URL"=>BLOG_URL,"blogtype"=>$blog["type"])));
				exit;
			}
	}
}

//批量上传
if ($action == 'upload_multi') {
	$logid = isset($_GET['logid']) ? intval($_GET['logid']) : '';
	$attach = isset($_FILES['attach']) ? $_FILES['attach'] : '';
	if ($attach&&Option::get('att_maxsize')!=0) {
		if ($attach['error'] != 4) {
			$isthumbnail = Option::get('isthumbnail') == 'y' ? true : false;
			$attach['name'] = Database::getInstance()->escape_string($attach['name']);
			$file_info = uploadFileBySwf($attach['name'], $attach['error'], $attach['tmp_name'], $attach['size'], Option::getAttType(), false, $isthumbnail);
			// 写入附件信息
			$query = "INSERT INTO " . DB_PREFIX . "attachment (blogid, filename, filesize, filepath, addtime, width, height, mimetype, thumfor) VALUES ('%s','%s','%s','%s','%s','%s','%s','%s',0)";
			$query = sprintf($query, $logid, $file_info['file_name'], $file_info['size'], $file_info['file_path'], time(), $file_info['width'], $file_info['height'], $file_info['mime_type']);
			$DB->query($query);
			$aid = $DB->insert_id();
			$DB->query("UPDATE " . DB_PREFIX . "blog SET attnum=attnum+1 WHERE gid=$logid");
			// 写入缩略图信息
			if (isset($file_info['thum_file'])) {
				$query = "INSERT INTO " . DB_PREFIX . "attachment (blogid, filename, filesize, filepath, addtime, width, height, mimetype, thumfor) VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s')";
				$query = sprintf($query, $logid, $file_info['file_name'], $file_info['thum_size'], $file_info['thum_file'], time(), $file_info['thum_width'], $file_info['thum_height'], $file_info['mime_type'], $aid);
				$DB->query($query);		
			}
			echo json_encode(array("code"=>0,"msg"=>"ok","data"=>array("src"=>$file_info['file_path'],"title"=>$file_info['file_name'])));
			exit;
		}
	}
}

//附件库
if ($action == 'attlib') {
	$logid = isset($_GET['logid']) ? intval($_GET['logid']) : '';
	$sql = "SELECT * FROM " . DB_PREFIX . "attachment WHERE blogid = $logid AND thumfor = 0";
	$query = $DB->query($sql);
	$attach = array();
	while ($row = $DB->fetch_array($query)) {
		$attsize = changeFileSize($row['filesize']);
		$filename = htmlspecialchars($row['filename']);
		$attach[$row['aid']] = array(
				'attsize'  => $attsize,
				'aid'      => $row['aid'],
				'filepath' => $row['filepath'],
				'filename' => $filename,
				'width'    => $row['width'],
				'height'   => $row['height'],
				'logid'   => $logid,
		);		
		$thum = $DB->once_fetch_array('SELECT * FROM ' . DB_PREFIX . 'attachment WHERE thumfor = '. $row['aid']);
		if ($thum) {
			$attach[$row['aid']]['thum_filepath']	= $thum['filepath'];
			$attach[$row['aid']]['thum_width']	    = $thum['width'];
			$attach[$row['aid']]['thum_height']  	= $thum['height'];
		}
	}
	$attachnum = count($attach);
	include View::getView('attlib');
	View::output();
}

//删除附件
if ($action == 'del_attach') {
    LoginAuth::checkToken();
	$aid = isset($_GET['aid']) ? intval($_GET['aid']) : '';
	$query = $DB->query("SELECT * FROM " . DB_PREFIX . "attachment WHERE aid = $aid ");
	$attach = $DB->fetch_array($query);
	$logid = $attach['blogid'];
	if (file_exists($attach['filepath'])) {
		@unlink($attach['filepath']) or emMsg("删除附件失败!");
	}

	$query = $DB->query("SELECT * FROM ".DB_PREFIX."attachment WHERE thumfor = ".$attach['aid']);
	$thum_attach = $DB->fetch_array($query);
	if ($thum_attach) {
		if (file_exists($thum_attach['filepath'])) {
			@unlink($thum_attach['filepath']) or emMsg("删除附件失败!");
		}
		$DB->query("DELETE FROM " . DB_PREFIX . "attachment WHERE aid = {$thum_attach['aid']} ");
	}

	$DB->query("UPDATE " . DB_PREFIX . "blog SET attnum=attnum-1 WHERE gid = {$attach['blogid']}");
	$DB->query("DELETE FROM " . DB_PREFIX . "attachment WHERE aid = {$attach['aid']} ");
	emDirect("attachment.php?action=attlib&logid=$logid");
}

//批量删除附件
if ($action== 'dell_all_media') {
	$media = isset($_POST['media']) ? $_POST['media'] : '';
	LoginAuth::checkToken();
	if (!$media) {
		emDirect("./media.php?active_del=1");
	}
	foreach ($media as $key=>$value) {
		$query = $DB->query("SELECT * FROM " . DB_PREFIX . "attachment WHERE aid = $value ");
		$attach = $DB->fetch_array($query);
		$logid = $attach['blogid'];
		
		$attach = $DB->once_fetch_array("select filepath from " . DB_PREFIX . "attachment where aid=$value ");
		if ($attach&&file_exists($attach['filepath'])) {
			@unlink($attach['filepath']);
		}
		$attach = $DB->once_fetch_array("select filepath from " . DB_PREFIX . "attachment where thumfor=$value ");
		if ($attach&&file_exists($attach['filepath'])) {
			@unlink($attach['filepath']);
		}
		$DB->query("DELETE FROM " . DB_PREFIX . "attachment where aid=$value");
		$DB->query("DELETE FROM " . DB_PREFIX . "attachment WHERE thumfor=$value");
		$DB->query("UPDATE " . DB_PREFIX . "blog SET attnum=attnum-1 WHERE gid = $logid");
	}
	$CACHE->updateCache();
	emDirect("./media.php?active_del=1");
}

//微语图片上传
if ($action == 'upload_tw_img') {
	if(ROLE!=ROLE_ADMIN){echo json_encode(array("code"=>-1,"msg"=>"error","data"=>array("src"=>"")));exit;}
	$attach = isset($_FILES['attach']) ? $_FILES['attach'] : '';
	if ($attach) {
		if(Option::get('att_maxsize')==0){
			$temptwimgdir=dirname(__FILE__).'/../content/uploadfile/twitter/';
			if(!is_dir($temptwimgdir)){
				mkdir($temptwimgdir);
			}
			$filename = iconv("utf-8", "gbk", @$attach['name']);
			move_uploaded_file(@$attach['tmp_name'], $temptwimgdir.$filename);
			$ch = curl_init();
			$filePath = $temptwimgdir.$filename;
			$data = array('file' => '@' . $filePath);
			if (class_exists('\CURLFile')) {
				$data['file'] = new \CURLFile(realpath($filePath));
			} else {
				if (defined('CURLOPT_SAFE_UPLOAD')) {
					curl_setopt($ch, CURLOPT_SAFE_UPLOAD, FALSE);
				}
			}
			curl_setopt($ch, CURLOPT_URL, TLE_SERVICE_HOST.'api/web/?action=weiboimg');
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			$json=curl_exec($ch);
			curl_close($ch);
			@unlink($temptwimgdir.$filename);
			echo $json;
			exit;
		}
		
		$file_info = uploadFile($attach['name'], $attach['error'], $attach['tmp_name'], $attach['size'], Option::getAttType(), false, false);
		echo json_encode(array("code"=>0,"msg"=>"ok","data"=>array("src"=>$file_info['file_path'],"title"=>$file_info['file_name'])));
		exit;
	}
	echo json_encode(array("code"=>-1,"msg"=>"error","data"=>array("src"=>"")));
	exit;
}

//微语图片删除
if ($action == 'del_tw_img') {
    if(ROLE!=ROLE_ADMIN){
        emMsg("非管理员不能删除图片！");
    }
	if(Option::get('att_maxsize')==0){
		$temptwimgdir=dirname(__FILE__).'/../content/uploadfile/twitter/';
		if(!is_dir($temptwimgdir)){
			mkdir($temptwimgdir);
		}
		emDeleteFile($temptwimgdir);
		exit;
	}
	$filepath = isset($_GET['filepath']) ? $_GET['filepath'] : '';
	if ($filepath && file_exists($filepath)) {
		@unlink($filepath) or false;
	}
	exit;
}
