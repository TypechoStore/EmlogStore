<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div id="m" class="layui-row layui-col-space20 layadmin-homepage-list-imgtxt">
  <div id="mleft" class="layui-col-md12">
	<div class="grid-demo" style="padding: 20px;">
		<?php if(ROLE == ROLE_ADMIN): ?>
		<form class="layui-form" style="background-color:#fff;" method="post" action="./index.php?action=t" enctype="multipart/form-data">
			<textarea placeholder="微语内容" class="layui-textarea" cols="20" rows="3" name="t"></textarea>
			<input type="file" name="img" /><br />
			<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
			<input type="submit" class="layui-btn layui-btn-primary layui-btn-sm" value="发布" />
		</form>
		<?php endif;?>
		<?php 
		if($tws){
		foreach($tws as $value):
		$img = empty($value['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$value['img'].'"/></a>';
		$by = $value['author'] != 1 ? 'by:'.$user_cache[$value['author']]['name'] : '';
		?>
		<div class="panel-body layadmin-homepage-shadow">
			<div class="media-body">
			  <div class="pad-btm">
				<p class="fontColor">
					<?php echo $value['content'];?>
				</p>
				<p class="min-font">
				  <span class="layui-breadcrumb" lay-separator="-">
					<a href="javascript:;"><?php echo $by.' '.$value['date'];?></a>
				  </span>
				</p>         
			  </div>
			  <?php echo $img;?>
			  <div class="media">
				<div class="media-right">
				  <ul class="list-inline">
					<?php if(ROLE == ROLE_ADMIN): ?>
					<li>
						<a href="./?action=delt&id=<?php echo $value['id'];?>&token=<?php echo LoginAuth::genToken();?>">
						  <i class="layui-icon layui-icon-del"></i>
						  <span>删除</span>
						</a>
					</li>
					<?php endif;?>
				  </ul>
				</div>
			  </div>
			</div>
		</div>
		<?php endforeach; ?>
		<center><div id="page"></div></center>
		<?php
		}
		?>
	</div>
  </div>
  <script>
  $(function(){
	layui.use(["laypage"], function(){
		var laypage = layui.laypage;
		laypage.render({
			elem: "page"
			,count: <?=$twnum;?>
			,limit: <?=Option::get('index_twnum');?>
			,curr:<?=$page;?>
			,layout: ["prev", "page", "next", "skip"]
			,jump: function(obj,first){
				if(!first){
				  location.href="./?action=tw&page="+obj.curr;
				}
			}
		});
	});
  });
  </script>
</div>