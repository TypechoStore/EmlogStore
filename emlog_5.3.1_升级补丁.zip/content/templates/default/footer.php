<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
		<div class="layui-row layadmin-homepage-padding15" style="background-color:#fff;margin-top:15px;">
          <hr class="new-section-xs"></hr>
          <div class="layui-col-md12 layadmin-homepage-padding8">
            <div class="layui-row layadmin-homepage-text-center" style="word-wrap:break-word;">
				<p>
				Powered by <a href="http://www.emlog.net" title="采用emlog系统" target="_blank">emlog</a> Theme By <a href="http://www.tongleer.com" title="同乐儿" target="_blank">Tongleer</a>
				</p>
				<p>
				<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
				</p>
				<p>
				<?php doAction('index_footer'); ?>
				</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="<?php echo BLOG_URL.ADMIN_DIR; ?>/views/ui/layui/layui.js"></script>  
<?php include "js/function.js.php";?>
</body>
</html>
<?php $html=ob_get_contents();ob_get_clean();echo em_compress_html_main($html);?>