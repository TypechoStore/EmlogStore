<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<?php if(isset($_GET['error_a'])):?><blockquote class="error layui-elem-quote">分类名称不能为空</blockquote><?php endif;?>
<?php if(isset($_GET['error_c'])):?><blockquote class="error layui-elem-quote">别名格式错误</blockquote><?php endif;?>
<?php if(isset($_GET['error_d'])):?><blockquote class="error layui-elem-quote">别名不能重复</blockquote><?php endif;?>
<?php if(isset($_GET['error_e'])):?><blockquote class="error layui-elem-quote">别名不得包含系统保留关键字</blockquote><?php endif;?>
<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
  <legend><b>编辑分类</b></legend>
</fieldset>
<form class="layui-form" action="sort.php?action=update" method="post">
<div>
	<li>
		<div style="margin:10px 0px;">名称 <span style="color:red;">*</span></div>
		<input style="width:240px;" value="<?php echo $sortname; ?>" name="sortname" id="sortname" class="layui-input" />
	</li>
	<li>
		<div style="margin:10px 0px;">别名</div>
		<input style="width:240px;" value="<?php echo $alias; ?>" name="alias" id="alias" class="layui-input" />
	</li>
	<?php if (empty($sorts[$sid]['children'])): ?>
	<li style="width:240px;">
		<div style="margin:10px 0px;">父分类</div>
		<select name="pid" id="pid">
			<option value="0"<?php if($pid == 0):?> selected="selected"<?php endif; ?>>无</option>
			<?php
				foreach($sorts as $key=>$value):
					if ($key == $sid || $value['pid'] != 0) continue;
			?>
			<option value="<?php echo $key; ?>"<?php if($pid == $key):?> selected="selected"<?php endif; ?>><?php echo $value['sortname']; ?></option>
			<?php endforeach; ?>
		</select>
	</li>
	<?php endif; ?>
    <li>
		<div style="margin:10px 0px;">模板 <i class="layui-icon layui-icon-tips" lay-tips="（用于自定义分类页面模板，对应模板目录下.php文件，默认为log_list.php）"></i></div>
		<input maxlength="200" style="width:240px;" class="layui-input" name="template" id="template" value="<?php echo $template; ?>" />
	</li>
	<li>
		<div style="margin:10px 0px;">分类描述</div>
		<textarea name="description" type="text" style="width:240px;height:60px;overflow:auto;" class="layui-textarea"><?php echo $description; ?></textarea>
	</li>
	<li style="margin-top:10px;">
		<input type="hidden" value="<?php echo $sid; ?>" name="sid" />
		<input type="submit" value="保 存" class="layui-btn" id="save"  />
		<input type="button" value="取 消" class="layui-btn layui-btn-primary" onclick="javascript: window.history.back();" />
		<span id="alias_msg_hook"></span>
    </li>
</div>
</form>
<script>
$(function(){
	layui.use(["form"], function(){
		var form = layui.form;
	});
});
$("#menu_sort").addClass('layui-this');
$("#menu_sort").parent().parent().addClass('layui-nav-itemed');
$("#alias").keyup(function(){checksortalias();});
function issortalias(a){
	var reg1=/^[\w-]*$/;
	var reg2=/^[\d]+$/;
	if(!reg1.test(a)) {
		return 1;
	}else if(reg2.test(a)){
		return 2;
	}else if(a=='post' || a=='record' || a=='sort' || a=='tag' || a=='author' || a=='page'){
		return 3;
	} else {
		return 0;
	}
}
function checksortalias(){
	var a = $.trim($("#alias").val());
	if (1 == issortalias(a)){
		$("#save").attr("disabled", "disabled");
		$("#alias_msg_hook").html('<span style="color:red;"><small>别名错误，应由字母、数字、下划线、短横线组成</small></span>');
	}else if (2 == issortalias(a)){
		$("#save").attr("disabled", "disabled");
		$("#alias_msg_hook").html('<span style="color:red;"><small>别名错误，不能为纯数字</small></span>');
	}else if (3 == issortalias(a)){
		$("#save").attr("disabled", "disabled");
		$("#alias_msg_hook").html('<span style="color:red;"><small>别名错误，与系统链接冲突</small></span>');
	}else {
		$("#alias_msg_hook").html('');
		$("#msg").html('');
		$("#save").attr("disabled", false);
	}
}
</script>