<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
		<legend>
			<b><a href="./template.php">当前模板</a></b>
			<small><a href="./template.php?action=install" class="layui-btn layui-btn-primary layui-btn-xs">安装模板</a></small>
		</legend>
	</fieldset>
	<?php if(isset($_GET['activated'])):?><blockquote class="actived layui-elem-quote">模板更换成功</blockquote><?php endif;?>
</div>
<?php if(!$nonceTplData): ?>
<blockquote class="actived layui-elem-quote">当前使用的模板(<?php echo $nonce_templet; ?>)已被删除或损坏，请选择其他模板。</blockquote>
<?php else:?>
<div class="layui-col-md12">
	<div class="layui-card">
		<div class="layui-card-body">
			<center>
				<img src="<?php echo TPLS_URL.$nonce_templet; ?>/preview.jpg" width="240" height="180"  border="1" />
			</center>
		</div>
		<div class="layui-card-body">
			<center>
				<?php echo $tplName; ?> <em><?php echo $tplVer; ?></em><br />
				<?php echo $tplAuthor; ?><br />
				<?php echo $tplDes; ?>
			</center>
		</div>
	</div>
</div>
<?php endif;?>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
		<legend>
			<b>模板库</b>(<?php echo $tplnums; ?>)
		</legend>
	</fieldset>
	<a name="tpllib"></a>
	<?php if(isset($_GET['activate_install'])):?><blockquote class="actived layui-elem-quote">模板上传成功</blockquote><?php endif;?>
	<?php if(isset($_GET['activate_del'])):?><blockquote class="actived layui-elem-quote">删除模板成功</blockquote><?php endif;?>
	<?php if(isset($_GET['error_a'])):?><blockquote class="error layui-elem-quote">删除失败，请检查模板文件权限</blockquote><?php endif;?>
</div>
<div class="layui-row layui-col-space15">
<?php 
$i = 0;
foreach($tpls as $key=>$value):
if($i % 3 == 0){echo "<tr>";}
$i++;
?>
	<div class="layui-col-md6">
      <div class="layui-card">
        <div class="layui-card-body">
			<center>
			<a href="template.php?action=usetpl&tpl=<?php echo $value['tplfile']; ?>&side=<?php echo $value['sidebar']; ?>&token=<?php echo LoginAuth::genToken(); ?>" title="点击使用该模板">
				<img alt="" src="<?php echo TPLS_URL.$value['tplfile']; ?>/preview.jpg" width="180" height="150" border="0" />
			</a>
			</center>
		</div>
        <div class="layui-card-body">
			<center>
			<?php echo $value['tplname']; ?>
			<span> | <a href="javascript: em_confirm('<?php echo $value['tplfile']; ?>', 'tpl', '<?php echo LoginAuth::genToken(); ?>');">删除</a></span>
			</center>
        </div>
      </div>
    </div>
<?php 
if($i > 0 && $i % 3 == 0){echo "</tr>";}
endforeach; 
?>
</div>
<script>
setTimeout(hideActived,2600);
$("#menu_tpl").addClass('layui-this');
$("#menu_tpl").parent().parent().addClass('layui-nav-itemed');
</script>