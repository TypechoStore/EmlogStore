<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<script>setTimeout(hideActived,2600);</script>
<div>
	<?php if (ROLE == ROLE_ADMIN):?>
	<button type="button" onclick="location.href='./configure.php'" class="layui-btn layui-btn-primary layui-btn-xs">基本设置</button>
	<button type="button" onclick="location.href='./seo.php'" class="layui-btn layui-btn-primary layui-btn-xs">SEO设置</button>
	<button type="button" onclick="location.href='./mailsafety.php'" class="layui-btn layui-btn-primary layui-btn-xs">邮件防护</button>
	<button type="button" onclick="location.href='./blogger.php'" class="layui-btn layui-btn-primary layui-btn-xs">个人设置</button>
	<?php else:?>
	<button type="button" onclick="location.href='./blogger.php'" class="layui-btn layui-btn-primary layui-btn-xs">个人设置</button>
	<?php endif;?>
	<?php if(isset($_GET['activated'])):?><blockquote class="actived layui-elem-quote">设置保存成功</blockquote><?php endif;?>
</div>

<div style="background-color:#fff;padding:10px;">
	<form class="layui-form" action="configure.php?action=mod_config" method="post" name="input" id="input">
		<table class="layui-table" cellspacing="8" cellpadding="4" width="95%" align="center" border="0">
			<tbody>
			  <tr>
				<td width="18%" align="right">站点标题：</td>
				<td width="82%"><input maxlength="200" style="width:200px;" class="layui-input" value="<?php echo $blogname; ?>" name="blogname" /></td>
			  </tr>
			  <tr>
				<td align="right" valign="top">站点副标题：</td>
				<td><textarea name="bloginfo" cols="" rows="3" style="width:200px;" class="layui-textarea"><?php echo $bloginfo; ?></textarea></td>
			  </tr>
			  <tr>
				<td align="right">站点地址：</td>
				<td>
					<input maxlength="200" style="width:200px;" class="layui-input" value="<?php echo $blogurl; ?>" name="blogurl" />
					<input type="checkbox" value="y" name="detect_url" id="detect_url" lay-skin="primary" <?php echo $conf_detect_url; ?> />自动检测站点地址 (可能和部分CDN解决方案不兼容)
				</td>
			  </tr>
			  <tr>
				<td align="right">每页显示：</td>
				<td>
					<div class="layui-row">
					  <div class="layui-card">
						<div class="layui-card-body">
							<div class="layui-input-inline">
								<input maxlength="5" size="4" class="layui-input" value="<?php echo $index_lognum; ?>" name="index_lognum" />
							</div>
							<div class="layui-input-inline" id="post_options">
								篇文章
							</div>
						</div>
					  </div>
					</div>
				</td>
			  </tr>
			  <tr>
				<td align="right">后台每页显示：</td>
				<td>
					<div class="layui-row">
					  <div class="layui-card">
						<div class="layui-card-body">
							<div class="layui-input-inline">
								<input maxlength="5" size="4" class="layui-input" value="<?php echo $admin_perpage_num; ?>" name="admin_perpage_num" />
							</div>
							<div class="layui-input-inline" id="post_options">
								篇文章
							</div>
						</div>
					  </div>
					</div>
				</td>
			  </tr>
			  <tr>
				<td valign="top" align="right">你所在时区：</td>
				<td>
				<select name="timezone" style="width:200px;" lay-filter="timezone">
				<?php
				foreach($tzlist as $key=>$value){
					$ex = $key==$timezone?"selected=\"selected\"":'';
					?>
					<option value="<?php echo $key; ?>" <?php echo $ex; ?>><?php echo $value; ?></option>
					<?php
				}
				?>
				</select>
				<fieldset class="layui-elem-field">
				  <legend>本地时间</legend>
				  <div class="layui-field-box">
					<?php echo date('Y-m-d H:i:s', time()); ?>
				  </div>
				</fieldset>
				</td>
			  </tr>
			  <tr>
				<td align="right" width="18%" valign="top">功能开关：</td>
				<td width="82%">
					<input type="checkbox" style="vertical-align:middle;" value="y" name="email_reg" id="email_reg" <?php echo $conf_email_reg; ?> lay-skin="primary" />邮箱注册登录<br />
					<input type="checkbox" style="vertical-align:middle;" value="y" name="login_code" id="login_code" <?php echo $conf_login_code; ?> lay-skin="primary" />登录验证码<br />
					<input type="checkbox" style="vertical-align:middle;" value="y" name="isgzipenable" id="isgzipenable" <?php echo $conf_isgzipenable; ?> lay-skin="primary" />Gzip压缩<br />
					<input type="checkbox" style="vertical-align:middle;" value="y" name="isxmlrpcenable" id="isxmlrpcenable" <?php echo $conf_isxmlrpcenable; ?> lay-skin="primary" />离线写作（支持用Windows Live Writer等工具写文章）<br />
					<input type="checkbox" style="vertical-align:middle;" value="y" name="ismobile" id="ismobile" <?php echo $conf_ismobile; ?> lay-skin="primary" />手机访问版，地址：<span id="m"><a title="用手机访问你的站点"><?php echo BLOG_URL.'m'; ?></a></span><br />
					<input type="checkbox" style="vertical-align:middle;" value="y" name="isexcerpt" id="isexcerpt" <?php echo $conf_isexcerpt; ?> lay-skin="primary" />自动摘要，截取文章的前
					<div class="layui-row" style="width:200px;">
					  <div class="layui-card">
						<div class="layui-card-body">
							<div class="layui-input-inline">
								<input type="text" name="excerpt_subnum" maxlength="3" value="<?php echo Option::get('excerpt_subnum'); ?>" class="layui-input" />
							</div>
							<div class="layui-input-inline" id="post_options">
								个字作为摘要
							</div>
						</div>
					  </div>
					</div>
				</td>
			  <tr>
			</tbody>
		</table>
		
		<table class="layui-table" cellspacing="8" cellpadding="4" width="95%" align="center" border="0">
		  <tr>
			<td align="right" width="18%" valign="top">微语：</td>
			<td width="82%">
			<input type="checkbox" style="vertical-align:middle;" value="y" name="istwitter" id="istwitter" <?php echo $conf_istwitter; ?> lay-skin="primary" />开启微语，
			每页显示<input type="text" name="index_twnum" maxlength="3" value="<?php echo Option::get('index_twnum'); ?>" class="input" style="width:25px;" />条微语<br />
			<input type="checkbox" style="vertical-align:middle;" value="y" name="istreply" id="istreply" <?php echo $conf_istreply; ?> lay-skin="primary" />开启微语回复，
			<input type="checkbox" style="vertical-align:middle;" value="y" name="reply_code" id="reply_code" <?php echo $conf_reply_code; ?> lay-skin="primary" />回复验证码，
			<input type="checkbox" style="vertical-align:middle;" value="y" name="ischkreply" id="ischkreply" <?php echo $conf_ischkreply; ?> lay-skin="primary" />回复审核<br />
			</td>
		  </tr>
		</table>
		
		<table class="layui-table" cellspacing="8" cellpadding="4" width="95%" align="center" border="0">
		  <tr>
			<td align="right" width="18%">RSS：</td>
			<td width="82%">
				<div class="layui-row">
				  <div class="layui-card">
					<div class="layui-card-body">
						<div class="layui-input-inline">
							输出
						</div>
						<div class="layui-input-inline" id="post_options">
							<input maxlength="5" size="4" value="<?php echo $rss_output_num; ?>" class="layui-input" name="rss_output_num" />
						</div>
						<div class="layui-input-inline">
							篇文章（0为关闭），且输出
						</div>
						<div class="layui-input-inline">
							<select name="rss_output_fulltext" lay-filter="rss_output_fulltext">
								<option value="y" <?php echo $ex1; ?>>全文</option>
								<option value="n" <?php echo $ex2; ?>>摘要</option>
							</select>
						</div>
					</div>
				  </div>
				</div>
			</td>
		  </tr>
		</table>
	  
		<table class="layui-table" cellspacing="8" cellpadding="4" width="95%" align="center" border="0">
		  <tr>
			<td align="right" width="18%" valign="top">评论：</td>
			<td width="82%">
				<div class="layui-row">
				  <div class="layui-card">
					<div class="layui-card-body">
						<div class="layui-input-inline">
							<input type="checkbox" style="vertical-align:middle;" value="y" name="iscomment" id="iscomment" <?php echo $conf_iscomment; ?> lay-skin="primary" />开启评论，发表评论间隔
						</div>
						<div class="layui-input-inline">
							<input maxlength="5" size="2" class="layui-input" value="<?php echo $comment_interval; ?>" name=comment_interval />
						</div>
						<div class="layui-input-inline" id="post_options">
							秒
						</div>
					</div>
				  </div>
				</div>
				
				<div class="layui-row">
				  <div class="layui-card">
					<div class="layui-card-body">
						<div class="layui-input-inline">
							<input type="checkbox" style="vertical-align:middle;" value="y" name="ischkcomment" id="ischkcomment" <?php echo $conf_ischkcomment; ?> lay-skin="primary" />评论审核
							<input type="checkbox" style="vertical-align:middle;" value="y" name="comment_code" id="comment_code" <?php echo $conf_comment_code; ?> lay-skin="primary" />评论验证码
							<input type="checkbox" style="vertical-align:middle;" value="y" name="isgravatar" id="isgravatar" <?php echo $conf_isgravatar; ?> lay-skin="primary" />评论人头像
							<input type="checkbox" style="vertical-align:middle;" value="y" name="comment_needchinese" id="comment_needchinese" <?php echo $conf_comment_needchinese; ?> lay-skin="primary" />评论内容必须包含中文
						</div>
					</div>
				  </div>
				</div>
				<div class="layui-row">
				  <div class="layui-card">
					<div class="layui-card-body">
						<div class="layui-input-inline">
							<input type="checkbox" style="vertical-align:middle;" value="y" name="comment_paging" id="comment_paging" <?php echo $conf_comment_paging; ?> lay-skin="primary" />评论分页，每页显示
						</div>
						<div class="layui-input-inline">
							<input maxlength="5" size="4" class="layui-input" value="<?php echo $comment_pnum; ?>" name="comment_pnum" />
						</div>
						<div class="layui-input-inline" id="post_options">
							条评论，
						</div>
						<div class="layui-input-inline" id="post_options">
							<select name="comment_order" lay-filter="comment_order">
								<option value="newer" <?php echo $ex3; ?>>较新的</option><option value="older" <?php echo $ex4; ?>>较旧的</option>
							</select>
						</div>
						<div class="layui-input-inline" id="post_options">
							排在前面
						</div>
					</div>
				  </div>
				</div>
			</td>
		  </tr>
		</table>
		
		<table class="layui-table" cellspacing="8" cellpadding="4" width="95%" align="center" border="0">
		  <tr>
			<td align="right" width="18%" valign="top">附件：</td>
			<td width="82%">
			
				<div class="layui-row">
				  <div class="layui-card">
					<div class="layui-card-body">
						<div class="layui-input-inline">
							附件上传最大限制
						</div>
						<div class="layui-input-inline">
							<input maxlength="10" size="6" class="layui-input" value="<?php echo $att_maxsize; ?>" name="att_maxsize" />
						</div>
						<div class="layui-input-inline" id="post_options">
							KB
						</div>
						<div class="layui-input-inline" id="post_options">
							<small>（上传文件还受到服务器空间PHP配置最大上传 <?php echo ini_get('upload_max_filesize'); ?> 限制，设置为0KB即为关闭附件上传，且微语图片会上传外部图床。）</small>
						</div>
					</div>
				  </div>
				</div>
				
				<div class="layui-row">
				  <div class="layui-card">
					<div class="layui-card-body">
						<div class="layui-input-inline">
							允许上传的附件类型
						</div>
						<div class="layui-input-inline">
							<input maxlength="200" style="width:200px;" class="layui-input" value="<?php echo $att_type; ?>" name="att_type" />
						</div>
						<div class="layui-input-inline" id="post_options">
							（多个用半角逗号分隔）
						</div>
					</div>
				  </div>
				</div>
				
				<div class="layui-row">
				  <div class="layui-card">
					<div class="layui-card-body">
						<div class="layui-input-inline">
							<input type="checkbox" style="vertical-align:middle;" value="y" name="isthumbnail" id="isthumbnail" <?php echo $conf_isthumbnail; ?> lay-skin="primary"  />
						</div>
						<div class="layui-input-inline">
							上传图片生成缩略图，最大尺寸：
						</div>
						<div class="layui-input-inline" id="post_options">
							<input maxlength="5" size="4" class="layui-input" value="<?php echo $att_imgmaxw; ?>" name="att_imgmaxw" />
						</div>
						<div class="layui-input-inline">
							x
						</div>
						<div class="layui-input-inline">
							<input maxlength="5" size="4" class="layui-input" value="<?php echo $att_imgmaxh; ?>" name="att_imgmaxh" />
						</div>
						<div class="layui-input-inline">
							（单位：像素）
						</div>
					</div>
				  </div>
				</div>
			</td>
		  </tr>
		</table>
	  
		<table class="layui-table" cellspacing="8" cellpadding="4" width="95%" align="center" border="0">
		  <tr>
			<td align="right">ICP备案号：</td>
			<td><input maxlength="200" style="width:200px;" class="layui-input" value="<?php echo $icp; ?>" name="icp" /></td>
		  </tr>
		  <tr>
			<td align="right" width="18%" valign="top">首页底部信息：<br /></td>
			<td width="82%">
			<textarea name="footer_info" cols="" rows="6" class="layui-textarea" style="width:200px;"><?php echo $footer_info; ?></textarea><br />
			(支持html，可用于添加流量统计代码)
			</td>
		  </tr>
		</table>
		
		<table cellspacing="8" cellpadding="4" width="95%" align="center" border="0">
		  <tr>
			<td align="center" colspan="2">
				<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
				<input type="submit" class="layui-btn" value="保存设置" />
			</td>
		  </tr>
		</table>
	</form>
</div>
<script>
$(function(){
	layui.use(["form"], function(){
		var form = layui.form;
	});
});
</script>