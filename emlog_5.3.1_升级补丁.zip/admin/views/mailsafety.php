<?php if (!defined('EMLOG_ROOT')) {exit('error!');}
?>
<div>
	<?php if (ROLE == ROLE_ADMIN):?>
	<button type="button" onclick="location.href='./configure.php'" class="layui-btn layui-btn-primary layui-btn-xs">基本设置</button>
	<button type="button" onclick="location.href='./seo.php'" class="layui-btn layui-btn-primary layui-btn-xs">SEO设置</button>
	<button type="button" onclick="location.href='./mailsafety.php'" class="layui-btn layui-btn-primary layui-btn-xs">邮件防护</button>
	<button type="button" onclick="location.href='./blogger.php'" class="layui-btn layui-btn-primary layui-btn-xs">个人设置</button>
	<?php else:?>
	<button type="button" onclick="location.href='./blogger.php'" class="layui-btn layui-btn-primary layui-btn-xs">个人设置</button>
	<?php endif;?>
	<?php if (isset($_GET['activatedsafety'])): ?><blockquote class="actived layui-elem-quote">设置保存成功</blockquote><?php endif; ?>
    <?php if (isset($_GET['resetedsafety'])): ?><blockquote class="actived layui-elem-quote">重置成功</blockquote><?php endif; ?>
    <?php if (isset($_GET['dellsafety'])): ?><blockquote class="actived layui-elem-quote">清空成功</blockquote><?php endif; ?>
	<?php if (isset($_GET['activatedmail'])): ?><blockquote class="alert layui-elem-quote">设置保存成功</blockquote><?php endif; ?>
</div>

<div class="layui-tab layui-tab-card">
  <ul class="layui-tab-title">
    <li class="layui-this">站点防护(已防御<?php echo $webscan_log ?>次)</li>
    <li>邮件通知</li>
  </ul>
  <div class="layui-tab-content" style="background-color:#fff;">
    <div class="layui-tab-item layui-show">
		<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
		  <legend>防护设置</legend>
		</fieldset>
		<form class="layui-form" action="mailsafety.php?action=setsafety" method="post" name="input" id="input">
			<li style="margin:10px 0px;"><input value="1" name="webscan_switch" type="checkbox" id="webscan_switch" <?php echo $webscan_switch; ?> lay-skin="primary" />启用防跨站攻击漏洞脚本<small>(推荐火力全开，就是全选)</small></li>
			<li style="margin:10px 0px;"><input value="1" name="webscan_post" type="checkbox" id="webscan_post" <?php echo $webscan_post; ?> lay-skin="primary" />拦截POST方式</li>
			<li style="margin:10px 0px;"><input value="1" name="webscan_get" type="checkbox" id="webscan_get" <?php echo $webscan_get; ?> lay-skin="primary" />拦截GET方式</li>
			<li style="margin:10px 0px;"><input value="1" name="webscan_cookie" type="checkbox" id="webscan_cookie" <?php echo $webscan_cookie; ?> lay-skin="primary" />拦截COOKIE方式</li>
			<li style="margin:10px 0px;"><input value="1" name="webscan_referre" type="checkbox" id="webscan_referre" <?php echo $webscan_referre; ?> lay-skin="primary" />拦截REFERRE方式</li>
			<li>
				<label>目录白名单<small>(以"|"隔开白名单目录)</small>：</label>
				<textarea name="webscan_white_directory" cols="" rows="3" class="layui-textarea"><?php echo $webscan_white_directory; ?></textarea>
			</li>
			<li style="margin:10px 0px;">
				<label>小黑屋IP名单<small>(必须用半角的英文逗号','分割)</small>：</label>
				<textarea name="webscan_block_ip" cols="" rows="3" class="layui-textarea"><?php echo $webscan_block_ip; ?></textarea>
			</li>
			<li>
				<div class="layui-row">
				  <div class="layui-card">
					<div class="layui-card-body">
						<div class="layui-input-inline">
							攻击超过
						</div>
						<div class="layui-input-inline">
							<input type="text" name="attacks" maxlength="3" value="<?php echo $attacks; ?>" class="layui-input" style="width:50px" />
						</div>
						<div class="layui-input-inline">
							次自动加入小黑屋
						</div>
					</div>
				  </div>
				</div>
			</li>
			<li style="margin:10px 0px;">
				<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
				<input type="submit" class="layui-btn" value="确定" />
				<button class="layui-btn layui-btn-primary" onClick="location.href='safety.php?action=resetsafety&token=<?php echo LoginAuth::genToken(); ?>';">重置统计数</button>
			</li>
		</form>
		<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
		  <legend>防护统计</legend>
		</fieldset>
		<form  method="post" action="mailsafety.php?action=dell_all_safety" name="form_ip" id="form_ip">			
			<table class="layui-table">
				<thead>
					<tr>
						<th width="400"><b>攻击来源</b></th>
						<th width="100"><b>次数</b></th>
						<th width="100"><b>时间</b></th>
					</tr>
				</thead>
				<tbody>
				 <?php   
					$DB=Database::getInstance();
					$page=max(1,intval($_GET['page']));
					$pagenum=Option::get('admin_perpage_num');
					$count=$DB->once_fetch_array("select count(*) as num from `".DB_PREFIX."block` ");	
					$res = $DB->query("SELECT `id`, `date`, `serverip`,`attack_num` FROM ".DB_PREFIX."block order by date desc limit ".(($page-1)*$pagenum).",$pagenum");
					$blocknum=$count['num'];
					$pageurl =  pagination($blocknum,$pagenum,$page,"mailsafety.php?page=");
					if($DB->num_rows($res) != 0){
						while($row = $DB->fetch_array($res)){ ?>
						<tr>
							<td>
								<?php echo $row['serverip'] ?>
							</td>
							<td >
								<?php echo $row['attack_num'] ?>
							</td>
							<td>
								<?php echo date("Y-m-d",$row['date']) ?>
							</td>
						</tr>         
						<?php } ?>         
					<?php }else{?>      
						<tr><td colspan="3">近期非常安全，无人攻击网站</td></tr>
					<?php }?>   
				</tbody>
			</table>
			<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
			<input type="submit" value="清空数据" class="layui-btn layui-btn-primary" />      
		</form>
		<center><div id="page"></div></center>
		<center>(有<?php echo $blocknum; ?>篇)</center>
	</div>
	<div class="layui-tab-item">
		<form class="layui-form" action="mailsafety.php?action=setmail" method="post" name="inputmail" id="inputmail">
			<li style="margin:10px 0px;">
				<label> smtp服务器<small> 如:smtp.126.com </small></label>
				<input name="smtp" class="layui-input" type="text" id="smtp" value="<?php echo MAIL_SMTP;?>"/>
			</li>
			<li style="margin:10px 0px;">
				<label> smtp端口 <small> 如:465 </small></label>
				<input name="port" class="layui-input" type="text" id="port" value="<?php echo MAIL_PORT;?>"/>
			</li>
			<li style="margin:10px 0px;">
				<label> 发信邮箱 </label>
				<input name="sendemail" class="layui-input" type="email" id="sendemail" value="<?php echo MAIL_SENDEMAIL;?>"/>
			</li>
			<li style="margin:10px 0px;">
				<label> 发信密码: </label>
				<input type="password" class="layui-input" name="password" value="<?php echo MAIL_PASSWORD;?>" />
			</li>
			<li style="margin:10px 0px;">
				<label> 收信邮箱:</label>
				<input name="toemail" class="layui-input" type="email" id="toemail" value="<?php echo MAIL_TOEMAIL;?>"/>
			</li>
			<li style="margin:10px 0px;">
				<input type="checkbox" name="issendmail" value="Y" <?php echo $SEND_MAIL ?> lay-skin="primary" / /> 收到评论时通知自己<br />
				<input type="checkbox" name="isreplymail" value="Y"  <?php echo $REPLY_MAIL ?> lay-skin="primary" / /> 回复评论时通知评论者
			</li>
			<li style="margin:10px 0px;">
				<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
				<input name="Input" type="submit" class="layui-btn" value="保　存" />
				<input id="testsend" class="layui-btn layui-btn-primary" type="button" value="发送一封测试邮件" />
			</li>
			<div id="testresult" style="height:64px; padding:10px; border-top:1px dashed #ccc; overflow:auto;/*background-color:#bbd9e2;*/"></div>
		</form>
	</div>
  </div>
</div>
<script>
$(function(){
	layui.use(["laypage", "layer", "form"], function(){
		var form = layui.form;
		var laypage = layui.laypage
		  ,layer = layui.layer;
		  laypage.render({
			elem: "page"
			,count: <?=$blocknum;?>
			,limit: <?=$pagenum;?>
			,curr:<?=$page;?>
			,layout: ["prev", "page", "next", "skip"]
			,jump: function(obj,first){
				if(!first){
				  location.href="mailsafety.php?page="+obj.curr;
				}
			}
		  });
	});
});
setTimeout(hideActived, 2600);
</script>
<script>
jQuery.fn.onlyPressNum = function(){$(this).css('ime-mode','disabled');$(this).css('-moz-user-select','none');$(this).bind('keydown',function(event){var k=event.keyCode;if(!((k==13)||(k==9)||(k==35)||(k == 36)||(k==8)||(k==46)||(k>=48&&k<=57)||(k>=96&&k<=105)||(k>=37&&k<=40))){event.preventDefault();}})}
jQuery(function($){
	$('#port').onlyPressNum();
	$('#testsend').click(function(){$('#testresult').html('邮件发送中..');
		$.get('./mailsafety.php?action=testmail&token=<?php echo LoginAuth::genToken(); ?>',{sid:Math.random()},function(result){
			if($.trim(result)!=''){
				$('#testresult').html(result);
			}else{
				$('#testresult').html('发送失败！');
			}
		});
	});
});
</script>