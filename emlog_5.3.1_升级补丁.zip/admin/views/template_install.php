<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
		<legend>
			<b><a href="./template.php?action=install">安装模板</a></b>
			<small><a href="./template.php" class="layui-btn layui-btn-primary layui-btn-xs">当前模板</a></small>
			<small><a href="./store.php" class="layui-btn layui-btn-primary layui-btn-xs">获取更多模板前往应用中心</a></small>
		</legend>
	</fieldset>
	<?php if(isset($_GET['error_a'])):?><blockquote class="error layui-elem-quote">只支持zip压缩格式的模板包</blockquote><?php endif;?>
	<?php if(isset($_GET['error_b'])):?><blockquote class="error layui-elem-quote">上传失败，模板目录(content/templates)不可写</blockquote><?php endif;?>
	<?php if(isset($_GET['error_c'])):?><blockquote class="error layui-elem-quote">空间不支持zip模块，请按照提示手动安装模板</blockquote><?php endif;?>
	<?php if(isset($_GET['error_d'])):?><blockquote class="error layui-elem-quote">请选择一个zip模板安装包</blockquote><?php endif;?>
	<?php if(isset($_GET['error_e'])):?><blockquote class="error layui-elem-quote">安装失败，模板安装包不符合标准</blockquote><?php endif;?>
</div>
<?php if(isset($_GET['error_c'])): ?>
<blockquote class="layui-elem-quote">
手动安装模板： <br />
1、把解压后的模板文件夹上传到 content/templates目录下。 <br />
2、登录后台换模板，模板库中已经有了你刚才添加的模板，点击使用即可。 
</blockquote>
<?php endif; ?>
<form class="layui-form" action="./template.php?action=upload_zip" method="post" enctype="multipart/form-data" >
<div>
	<p>
		<input name="tplzip" type="file" />
	</p>
	<p style="margin:10px 0px;">
		<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
		<input type="submit" value="上传安装" class="layui-btn layui-btn-primary layui-btn-sm" /> (上传一个zip压缩格式的模板安装包)
	</p>
</div>
</form>
<script>
setTimeout(hideActived,2600);
$("#menu_tpl").addClass('layui-this');
$("#menu_tpl").parent().parent().addClass('layui-nav-itemed');
</script>