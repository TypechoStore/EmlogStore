<?php if (!defined('EMLOG_ROOT')) {exit('error!');}?>
<?php if(isset($_GET['active_submit'])):?><blockquote class="layui-elem-quote">工单提交<?php if(isset($_GET['submitresult'])&&$_GET['submitresult']=="success"){echo "成功，反馈结果将发送至邮箱：".$email;}else{echo "失败，请确认邮件是否设置正确。";}?></blockquote><?php endif;?>
<?php if(isset($_GET['error_faqtextnull'])):?><blockquote class="layui-elem-quote">请输入工单内容</blockquote><?php endif;?>
<?php if(isset($_GET['error_email'])):?><blockquote class="layui-elem-quote">请修改个人邮箱以便接收反馈结果</blockquote><?php endif;?>
<?php if(isset($_GET['error_mailoption'])):?><blockquote class="layui-elem-quote">请填写邮件设置</blockquote><?php endif;?>
<div class="layui-col-md8">
	<div class="layui-row layui-col-space15">
	  <div class="layui-col-md12">
		<div class="layui-card">
		  <div class="layui-card-header">发工单</div>
		  <div class="layui-card-body">
			<form class="layui-form" action="faq.php?action=submit" method="post" enctype="multipart/form-data">
				<textarea id="faqtext" name="faqtext"></textarea>
				<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
				<button class="layui-btn layui-btn-primary" style="margin-top:10px;">提交工单</button>
			</form>
		  </div>
		</div>
	  </div>
	  <?php if (ROLE == ROLE_ADMIN){?>
	  <div class="layui-col-md12">
		<div class="layui-card">
		  <div class="layui-tab layui-tab-brief layadmin-latestData">
			<ul class="layui-tab-title">
			  <li class="layui-this">更新记录</li>
			</ul>
			<div class="layui-tab-content">
			  <div class="layui-tab-item layui-show">
				<ul class="layui-timeline" id="updateinfo"></ul>
			  </div>
			</div>
		  </div>
		</div>
	  </div>
	  <?php }?>
	</div>
</div>
<div class="layui-col-md4">
	<div class="layui-card">
	  <div class="layui-card-header">关于</div>
	  <div class="layui-card-body" style="word-wrap: break-word; word-break: normal;">
		<div class="layadmin-homepage-panel layadmin-homepage-shadow">
			<div class="layui-card text-center" style="margin: 0 auto;text-algin:center;">
			  <div class="layui-card-body">
				<div class="layadmin-homepage-pad-ver">
				  <?php
					$host = 'https://secure.gravatar.com';
					$url = '/avatar/';
					$size = '50';
					$rating = 'g';
					$hash = md5(strtolower("diamond0422@qq.com"));
					$avatar = $host . $url . $hash . '?s=' . $size . '&r=' . $rating . '&d=mm';
				  ?>
				  <img class="layadmin-homepage-pad-img" src="<?=$avatar;?>" width="96" height="96">
				</div>
				<h4 class="layadmin-homepage-font">微信公众号：Diamond0422</h4>
				<p class="layadmin-homepage-min-font">邮箱：diamond0422@qq.com</p>
				<div class="layadmin-homepage-pad-ver">
				  <a href="https://github.com/muzishanshi" lay-tips="Github" target="_blank" class="layui-icon layui-icon-home"></a>&nbsp;&nbsp;
				  <a href="http://club.tongleer.com" lay-tips="论坛" target="_blank" class="layui-icon layui-icon-website"></a>&nbsp;&nbsp;
				  <a id="showWxAlert" href="javascript:;" target="_blank" class="layui-icon layui-icon-login-wechat"></a>&nbsp;&nbsp;
				</div>
			  </div>
			</div>
		</div>
	  </div>
	</div>
	
	<div class="layui-card">
	  <div class="layui-card-header">赞助打赏</div>
	  <div class="layui-card-body" style="word-wrap: break-word; word-break: normal;">
		<img src="./views/images/wxpayqrcode.jpg" />
	  </div>
	</div>
	
	<div class="layui-card">
	  <div class="layui-card-header">帮助说明</div>
	  <div class="layui-card-body" style="word-wrap: break-word; word-break: normal;">
		<ul class="layui-timeline">
		  <li class="layui-timeline-item">
			<i class="layui-icon layui-timeline-axis"></i>
			<div class="layui-timeline-content layui-text">
			  <div class="layui-timeline-title">简介</div>
			  <p>
				Emlog 是 "Every Memory Log" 的简称，意即：点滴记忆。它是一款基于PHP和MySQL平台的功能强大的个人博客系统(blog)。致力于为您提供快速、稳定，且在使用上又极其简单、舒适的博客服务。
			  </p>
			</div>
		  </li>
		  
		  <li class="layui-timeline-item">
			<i class="layui-icon layui-timeline-axis"></i>
			<div class="layui-timeline-content layui-text">
			  <div class="layui-timeline-title">功能</div>
			  <p>
				<ul> 
					<li>一键式更换模板，方便快捷打造个性博客</li>
					<li>支持强大的插件扩展功能，随意选择实用的插件，让你的博客无限可能</li>
					<li>支持日志URL自定义，链接样式更适合SEO</li>
					<li>独有的微语功能，让你用简单的文字记录生活</li>
					<li>清爽的日志撰写页面，书写博文更加舒适无忧</li>
					<li>日志草稿箱功能，方便保存你未完成的日志</li>
					<li>灵活的侧边栏组件(widgets)管理，轻松组合、自定义你喜欢的组件</li>
					<li>自定义页面，轻松创建留言板、导航条、博主介绍等个性页面</li>
					<li>多人联合撰写，后台轻松管理多个撰写人</li>
					<li>支持灵活的标签(tag)分类，以及传统分类方式</li>
					<li>方便的附件（图片、文件）上传和管理</li>
					<li>上传的图片可以随意直观的嵌入到日志内容里，让你的日志图文并茂</li>
					<li>首页日历方式查阅日志，方便、直观、快捷</li>
					<li>数据缓存技术，博客访问速度更快</li>
					<li>整体使用UTF-8编码方式，让你的博客和世界接轨。</li>
					<li>支持RSS日志输出功能 ，方便朋友订阅关注你的博客</li>
					<li>博客数据备份/恢复功能 </li>
				</ul>
			  </p>
			</div>
		  </li>
		  
		  <li class="layui-timeline-item">
			<i class="layui-icon layui-timeline-axis"></i>
			<div class="layui-timeline-content layui-text">
			  <div class="layui-timeline-title">帮助</div>
			  <p>
				<ul> 
					<li>把emStrtotime函数改成strtotime函数{比如归档}</li>
					<li>支持SSL ,需要去后台系统里设置地址https</li>
					<li>如果出现权限不足,请尝试清除浏览器缓存和更新缓存功能</li>
					<li>程序是支持PHP7.0+,但有的插件和模板不支持,这要相关作者更新</li>
					<li>便捷的更新检测方便随时修改bug等等。</li>
				</ul>
			  </p>
			</div>
		  </li>
		</ul>
	  </div>
	</div>
</div>
<script>
$(document).ready(function() {
	$("#newsmsg").html("正在读取...");
	$.getJSON("<?php echo OFFICIAL_SERVICE_HOST; ?>services/messenger.php?v=5.3.1&callback=?",
		function(data) {
			$("#newsmsg").html("");
			$.each(data.items, function(i, item) {
				$("#newsmsg").append("<li class=\"layui-timeline-item\"><i class=\"layui-icon layui-timeline-axis\"></i><div class=\"layui-timeline-content layui-text\"><div class=\"layui-timeline-title\">" + item.date + "，<a href=\"" + item.url + "\" target=\"_blank\">" + item.title + "</a></div></div></li>");
			});
		});
	$("#updateinfo").html("正在读取...");
		$.getJSON("<?php echo TLE_SERVICE_HOST; ?>me/api/store/update.php?action=updatehistory",
			function(data) {
				$("#updateinfo").html("");
				$.each(data.items, function(i, item) {
					$("#updateinfo").append("<li class=\"layui-timeline-item\"><i class=\"layui-icon layui-timeline-axis\"></i><div class=\"layui-timeline-content layui-text\"><div class=\"layui-timeline-title\">" + item.date + "，" + item.t + "</div></div></li>");
				});
				if(data.items.length){
					$("#updateinfo").append("<li class=\"layui-timeline-item\"><i class=\"layui-icon layui-anim layui-anim-rotate layui-anim-loop layui-timeline-axis\"></i><div class=\"layui-timeline-content layui-text\"><div class=\"layui-timeline-title\"><a href=\"https://me.tongleer.com/t\" target=\"_blank\">更多</a></div></div></li>");
				}
			});
	layui.use(['layedit', "layer", "form"], function(){
		var layer = layui.layer;
		var form = layui.form;
		var layedit = layui.layedit;
		layedit.set({
			  uploadImage: {
				url: '<?php echo TLE_SERVICE_HOST;?>api/web/?action=weiboimg'
				,type: 'post'
				,accept: 'image'
				,acceptMime: 'image/*'
				,exts: 'jpg|png|gif|bmp|jpeg'
				,size: '2048'
			  }
		});
		layedit.build('faqtext',{
			  height:240,
			  tool: [
					'undo', 'redo', 'code', 'strong', 'italic', 'underline', 'del', 'addhr', '|','removeformat', 'fontFomatt', 'fontfamily','fontSize', 'fontBackColor', 'colorpicker', 'face'
					, '|', 'left', 'center', 'right', '|', 'images', 'image_alt', '|', 'table','preview'
				]
		});
		$("#showWxAlert").click(function(){
			layer.open({
				type: 1
				,title:"微信公众号"
				,offset: "auto"
				,id: 'wxpublicqrcode'
				,content: '<center><img src="./views/images/wxpublicqrcode.jpg" width="100" /></center>'
				,btn: '关闭'
				,btnAlign: 'c'
				,shade: 0
				,yes: function(){
				  layer.closeAll();
				}
			});
		});
	});
});
</script>