<?php
/**
 * 升级程序5.3.1 to 6.1.1
 * @copyright (c) Emlog All Rights Reserved
 */
require_once 'init.php';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0" />
<title>EMLOG升级脚本</title>
<link rel="stylesheet" href="./<?=ADMIN_DIR;?>/views/ui/layui/css/layui.css" media="all">
</head>
<body>
<div class="layui-layout layui-layout-admin">
  <div class="layui-header">
    <div class="layui-logo">Emlog 升级向导</div>
    <ul class="layui-nav layui-layout-right">
      <li class="layui-nav-item">
        <a href="javascript:;">4、升级脚本</a>
      </li>
    </ul>
  </div>
  <blockquote class="layui-elem-quote">
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
		<legend>升级脚本</legend>
	</fieldset>
	<p>
		Emlog <span style="color: #0099FF">5.3.1</span> -----&gt; <span style="color: #FF0000;">6.1.1</span> 升级脚本
	</p>
  </blockquote>
  <?php if(!isset($_GET['action'])){?>
  <form class="layui-form" method="post" action="update_5.3.1.php?action=update" style="padding:0px 20px;">
	<div class="layui-form-item">
		<label>数据库密码</label>
		<input style="margin-top:5px;" class="layui-input" name="password" type="text" value="">
	</div>
	<center>
		<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		<button class="layui-btn">确定</button>
	</center>
  </form>
  <?php }?>
</div>
<?php
	if(isset($_GET['action'])&&$_GET['action'] == "update") {
		$DB = Database::getInstance();
		$CACHE = Cache::getInstance();

		$db_prefix = DB_PREFIX;

		$dbcharset = 'utf8';
		$type = 'MYISAM';
		$table_charset_sql = $DB->getMysqlVersion() > '4.1' ? 'ENGINE='.$type.' DEFAULT CHARSET='.$dbcharset.';' : 'ENGINE='.$type.';';
		$extra = "ENGINE=".$type." DEFAULT CHARSET=".$dbcharset.";";
		$extra2 = "TYPE=".$type;
		$add = $DB->getMysqlVersion() > '4.1' ? $extra : $extra2.";";

		$widgets = Option::getWidgetTitle();
		$sider_wg = Option::getDefWidget();

		$widget_title = serialize($widgets);
		$widgets = serialize($sider_wg);
		$white = addslashes('admin|\/content\/');
		
		if (DB_PASSWD != trim($_POST['password'])){
			emMsg('输入的数据库密码错误,请重新输入');
		}

		if (Option::EMLOG_VERSION != '5.3.1') {
			emMsg('错误:你确定你现在用的是5.3.1升级包吗?');
		}
		   
		if($DB->num_rows($DB->query("SELECT * FROM {$db_prefix}options WHERE option_name='email_reg'")) == 1) {
			emMsg('数据库已升级完成，请勿重复运行升级脚本');
		}	

		$sql = "
			DROP TABLE IF EXISTS {$db_prefix}block;
			CREATE TABLE {$db_prefix}block (
			  id int(10) unsigned NOT NULL auto_increment,
			  date int(10) NOT NULL default '0',
			 serverip varchar(200) NOT NULL default '',
			 attack_num int(10) NOT NULL default '0',
			UNIQUE KEY serverip (serverip),
			KEY block (id)
			)".$table_charset_sql."
			
			DROP TABLE IF EXISTS {$db_prefix}sortlink;
			CREATE TABLE {$db_prefix}sortlink (
			  linksort_id int(10) unsigned NOT NULL auto_increment,
			  linksort_name varchar(255) NOT NULL default '',
			  taxis int(10) unsigned NOT NULL default '0',
			  PRIMARY KEY  (linksort_id)
			)".$table_charset_sql."
		";
		$array_sql = preg_split("/;[\r\n]/", $sql);
		foreach($array_sql as $sql){
			$sql = trim($sql);
			if ($sql) {
				$DB->query($sql);
			}
		}
		/*
		ALTER TABLE {$db_prefix}blog ADD COLUMN tags text AFTER template;
		ALTER TABLE {$db_prefix}blog ADD COLUMN thumbs VARCHAR(255) AFTER tags;
		ALTER TABLE {$db_prefix}blog ADD COLUMN copy int(10) NOT NULL default '-1' AFTER thumbs;
		ALTER TABLE {$db_prefix}blog ADD COLUMN copyurl VARCHAR(255) NOT NULL default '' AFTER copy;
		
		ALTER TABLE {$db_prefix}user ADD COLUMN website VARCHAR(75) NOT NULL default '' AFTER description;
		ALTER TABLE {$db_prefix}user ADD COLUMN authCode VARCHAR(64) AFTER website;
		ALTER TABLE {$db_prefix}user ADD COLUMN instime datetime AFTER authCode;
		ALTER TABLE {$db_prefix}user ADD COLUMN logintime datetime AFTER instime;
		
		ALTER TABLE {$db_prefix}comment ADD COLUMN useragent VARCHAR(128) NOT NULL default '' AFTER hide;
		
		ALTER TABLE {$db_prefix}link ADD COLUMN sitepic VARCHAR(255) NOT NULL default '' AFTER taxis;
		ALTER TABLE {$db_prefix}link ADD COLUMN linksortid int(10) NOT NULL default '0' AFTER sitepic;
		*/
		updateAlterColumn($DB,DB_NAME,$db_prefix.'blog','tags','text');
		updateAlterColumn($DB,DB_NAME,$db_prefix.'blog','thumbs','varchar(255)');
		updateAlterColumn($DB,DB_NAME,$db_prefix.'blog','copy','int(10) NOT NULL default "-1"');
		updateAlterColumn($DB,DB_NAME,$db_prefix.'blog','copyurl','varchar(255) NOT NULL default ""');
		
		updateAlterColumn($DB,DB_NAME,$db_prefix.'user','website','varchar(75) NOT NULL default ""');
		updateAlterColumn($DB,DB_NAME,$db_prefix.'user','authCode','varchar(64)');
		updateAlterColumn($DB,DB_NAME,$db_prefix.'user','instime','datetime');
		updateAlterColumn($DB,DB_NAME,$db_prefix.'user','logintime','datetime');
		
		updateAlterColumn($DB,DB_NAME,$db_prefix.'comment','useragent','varchar(128) NOT NULL default ""');
		
		updateAlterColumn($DB,DB_NAME,$db_prefix.'link','sitepic','VARCHAR(255) NOT NULL default ""');
		updateAlterColumn($DB,DB_NAME,$db_prefix.'link','linksortid','int(10) NOT NULL default "0"');
		$sql = "
			INSERT INTO {$db_prefix}sortlink (linksort_id, linksort_name, taxis) VALUES (1, '默认分类', 0);
			
			INSERT INTO {$db_prefix}options (option_name, option_value) VALUES ('detect_url','n');
			INSERT INTO {$db_prefix}options (option_name, option_value) VALUES ('webscan_log','0');
			INSERT INTO {$db_prefix}options (option_name, option_value) VALUES ('webscan_switch','0');
			INSERT INTO {$db_prefix}options (option_name, option_value) VALUES ('webscan_post','0');
			INSERT INTO {$db_prefix}options (option_name, option_value) VALUES ('webscan_get','0');
			INSERT INTO {$db_prefix}options (option_name, option_value) VALUES ('webscan_cookie','0');
			INSERT INTO {$db_prefix}options (option_name, option_value) VALUES ('webscan_referre','0');
			INSERT INTO {$db_prefix}options (option_name, option_value) VALUES ('webscan_white_directory','".$white."');
			INSERT INTO {$db_prefix}options (option_name, option_value) VALUES ('webscan_block_ip','0.0.0.0');
			INSERT INTO {$db_prefix}options (option_name, option_value) VALUES ('MAIL_SMTP','smtp.exmail.qq.com');
			INSERT INTO {$db_prefix}options (option_name, option_value) VALUES ('MAIL_PORT','465');
			INSERT INTO {$db_prefix}options (option_name, option_value) VALUES ('MAIL_SENDEMAIL','');
			INSERT INTO {$db_prefix}options (option_name, option_value) VALUES ('MAIL_PASSWORD','');
			INSERT INTO {$db_prefix}options (option_name, option_value) VALUES ('MAIL_TOEMAIL','');
			INSERT INTO {$db_prefix}options (option_name, option_value) VALUES ('MAIL_SENDTYPE','1');
			INSERT INTO {$db_prefix}options (option_name, option_value) VALUES ('SEND_MAIL','Y');
			INSERT INTO {$db_prefix}options (option_name, option_value) VALUES ('REPLY_MAIL','Y');
			INSERT INTO {$db_prefix}options (option_name, option_value) VALUES ('attacks','10');
			INSERT INTO {$db_prefix}options (option_name, option_value) VALUES ('email_reg','n');
		";
		$array_sql = preg_split("/;[\r\n]/", $sql);
		foreach($array_sql as $sql){
			$sql = trim($sql);
			if ($sql) {
				$DB->query($sql);
			}
		}

		@unlink('./content/cache/comment');
		@unlink('./content/cache/link');
		@unlink('./content/cache/logalias');
		@unlink('./content/cache/logsort');
		@unlink('./content/cache/logtags');
		@unlink('./content/cache/navi');
		@unlink('./content/cache/newlog');
		@unlink('./content/cache/newtw');
		@unlink('./content/cache/options');
		@unlink('./content/cache/record');
		@unlink('./content/cache/sort');
		@unlink('./content/cache/sortlink');
		@unlink('./content/cache/sta');
		@unlink('./content/cache/tags');
		@unlink('./content/cache/user');

		$CACHE->updateCache();
		@touch('./install/install.lock');
		$result .= "
				<p style=\"font-size:24px; padding:10px 0px;\">恭喜,升级成功！</p>
				<p>您的Emlog已经是最新6.1.1版的了,如果存在update_5.3.1.php,请删除里面的update_5.3.1.php文件</p>
		";
		@unlink('./update_5.3.1.php');
		$result .= "<p style=\"text-align:right;\"><a href=\"./\">访问首页</a> | <a href=\"./".ADMIN_DIR."/\">登录后台</a></p>";
		emMsg($result, 'none');
	}
	echo "</body>";
	echo "</html>";
	/*修改数据表字段*/
	function updateAlterColumn($db,$dbname,$table,$column,$define){
		$row = $db->once_fetch_array("select * from information_schema.columns WHERE TABLE_SCHEMA='".$dbname."' and table_name = '".$table."' AND column_name = '".$column."'");
		if(count($row)==0){
			$db->query('ALTER TABLE `'.$table.'` ADD COLUMN `'.$column.'` '.$define.';');
		}
	}
?>