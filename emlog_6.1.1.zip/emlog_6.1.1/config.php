<?php
header("location: ./install.php");exit;
//mysql database address
define('DB_HOST','localhost');
//mysql database user
define('DB_USER','root');
//database password
define('DB_PASSWD','');
//database name
define('DB_NAME','em');
//database prefix
define('DB_PREFIX','em_');
//auth key
define('AUTH_KEY','*edUfu(eMaGW5ivh1nCdHZksw3Se$H@q8a219704ee12d2880f3ba307c486f66c');
//cookie name
define('AUTH_COOKIE_NAME','EM_AUTHCOOKIE_e8qOhy3plAGHOSsTQXij7J5ZUYCIHFLF');
