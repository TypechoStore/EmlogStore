<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<link rel="stylesheet" href="./views/ui/style/template.css" media="all">
<div>
	<fieldset class="layui-elem-field layui-field-title">
	  <legend>
		<b>媒体管理</b>
	  </legend>
	</fieldset>
	<?php if(isset($_GET['active_del'])):?><blockquote class="layui-elem-quote">删除成功</blockquote><?php endif;?>
</div>

<?php 
if($medianum>0){
	?>
	<form class="layui-form" action="attachment.php?action=dell_all_media" method="post" name="form_media" id="form_media">
		<div class="layui-fluid layadmin-cmdlist-fluid">
		  <div class="layui-row layui-col-space30">
			<?php
			foreach ($medias as $row){
			$extension  = strtolower(substr(strrchr($row['filepath'], "."),1));
			$atturl = BLOG_URL.substr($row['filepath'], 3);
			?>
			<div class="layui-col-md2 layui-col-sm4">
				<div class="cmdlist-container">
					<a href="javascript:;" title="<?php echo $row['filename']."在".$row['filepath']."中，于".date("Y-m-d",$row['addtime'])."上传"; ?>">
					  <img src="<?php if (in_array($extension, array('gif', 'jpg', 'jpeg', 'png', 'bmp'))){?><?php echo $atturl ?><?php }else if(in_array($extension, array('zip', 'rar'))){echo "./views/images/tar.gif";}else{echo "./views/images/fnone.gif";}?>" alt="<?php echo $row['filename']; ?>" />
					</a>
					<a href="javascript:;">
					  <div class="cmdlist-text">
						<p class="info"><a href="<?=Url::log($row['gid']);?>" target="_blank"><?php echo $row['title']; ?></a></p>
						<div class="price">
							<span>
								<input type="checkbox" name="media[]" class="ids" value="<?php echo $row['aid']; ?>" lay-skin="primary" ><?=date("Y-m-d",$row['addtime']);?>
							</span>
						</div>
					  </div>
					</a>
				</div>
			</div>
			<?php
			}
			?>
		  </div>
		</div>
		<div>
			<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
			<input type="checkbox" title="全选" lay-filter="select_all" />
			<button type="button" class="layui-btn layui-btn-primary layui-btn-sm" onClick="pageact('del');">删除</button>
		</div>
	</form>
	<div class="layui-col-md12 layui-col-sm12">
		<center><div id="page"></div></center>
		<center>(有<?php echo $medianum; ?>个媒体)</center>
	</div>
	<?php
}else{
	?>
	<blockquote class="layui-elem-quote">没有任何媒体</blockquote>
	<?php
}
?>
<script>
$(function(){
	layui.use(["laypage", "form"], function(){
		var form = layui.form;
		var laypage = layui.laypage;
		laypage.render({
			elem: "page"
			,count: <?=$medianum;?>
			,limit: <?=Option::get('admin_perpage_num');?>
			,curr:<?=$page;?>
			,layout: ["prev", "page", "next", "skip"]
			,jump: function(obj,first){
				if(!first){
				  location.href="media.php?page="+obj.curr;
				}
			}
		  });
		form.on('checkbox(select_all)', function(data){
			$("input[name='media[]']").each(function () {
				this.checked = data.elem.checked;
			});
			form.render('checkbox');
		});
	});
});
$("#menu_media").addClass('layui-this');
$("#menu_media").parent().parent().addClass('layui-nav-itemed');
setTimeout(hideActived,2600);	
function pageact(act){
	if (getChecked('ids') == false) {
		alert('请选择要操作的附件');
		return;}
	if(act == 'del' && !confirm('确定要删除所选的附件吗？')){return;}
	$("#form_media").submit();
}
</script>