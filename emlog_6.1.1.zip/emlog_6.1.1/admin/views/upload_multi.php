<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"  dir="ltr" lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>upload</title>
<link rel="stylesheet" href="./views/ui/layui/css/layui.css" media="all">
<script type="text/javascript" src="../include/lib/js/jquery/jquery-1.11.0.js"></script>
</head>
<body>
<script>
function showupload(multi){
	var as_logid = parent.document.getElementById('as_logid').value
	window.location.href="attachment.php?action=selectFile&logid="+as_logid+"&multi="+multi;	
}
function showattlib(){
	var as_logid = parent.document.getElementById('as_logid').value
	window.location.href="attachment.php?action=attlib&logid="+as_logid;	
}
</script>
<div>
	<span><button type="button" onclick="showupload(0);" class="layui-btn layui-btn-primary layui-btn-xs">上传附件</button></span>
	<span><button type="button" onclick="showupload(1);" class="layui-btn layui-btn-primary layui-btn-xs n layui-btn-disabled">批量上传</button></span>
	<span><button type="button" onclick="showattlib();" class="layui-btn layui-btn-primary layui-btn-xs">附件库（<?php echo $attachnum; ?>）</button></span>
</div>
<?php if(true === isIE6Or7()): ?>
<blockquote class="actived layui-elem-quote">
	您正在使用的浏览器版本太低，如果无法使用批量上传功能。为了更好的使用emlog，建议您升级浏览器或者换用其他浏览器。
</blockquote>
<?php else:?>
<form enctype="multipart/form-data" method="post" name="upload" action="">
<div class="layui-upload-drag" id="custom-bt" style="width:100%;">
  <i class="layui-icon"></i>
  <p>点击上传，或将文件拖拽到此处</p>
</div>
<div id="custom-queue" style="width:100%;"></div>
</form>
<script src="./views/ui/layui/layui.js"></script>
<script>
layui.use('upload', function(){
	var $ = layui.jquery,upload = layui.upload;
	upload.render({
		elem: '#custom-bt'
		,field:'attach'
		,accept:"file"
		,multiple: true
		,url: 'attachment.php?action=upload_multi&logid='+parent.document.getElementById('as_logid').value
		,before: function(obj){
		  obj.preview(function(index, file, result){
			$("#custom-queue").append("<img src='"+result+"' width='120' height='120' />");
		  });
		}
		,done: function(res){
			window.location.href="attachment.php?action=attlib&logid="+parent.document.getElementById('as_logid').value;
		}
		,error: function(){
			window.location.href="attachment.php?action=attlib&logid="+parent.document.getElementById('as_logid').value;
		}
	});
});
</script>
<?php endif; ?>
</body>
</html>
