<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div>
<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
  <legend><b>标签修改</b></legend>
</fieldset>
<?php if(isset($_GET['error_a'])):?><span class="error layui-elem-quote">标签不能为空</span><?php endif;?>
</div>
<form class="layui-form"  method="post" action="tag.php?action=update_tag">
	<div>
		<li>
			<input size="40" value="<?php echo $tagname; ?>" name="tagname" class="layui-input" />
		</li>
		<li style="margin:10px 0px">
			<input type="hidden" value="<?php echo $tagid; ?>" name="tid" />
			<input type="submit" value="保 存" class="layui-btn" />
			<input type="button" value="取 消" class="layui-btn layui-btn-primary" onclick="javascript: window.location='tag.php';"/>
		</li>
	</div>
</form>
<script>
$("#menu_tag").addClass('layui-this');
$("#menu_tag").parent().parent().addClass('layui-nav-itemed');
</script>