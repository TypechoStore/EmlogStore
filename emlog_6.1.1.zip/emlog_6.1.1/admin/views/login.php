<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta name="description" content="">
<meta name="author" content="tongleer">
<link rel="stylesheet" href="./views/ui/layui/css/layui.css" media="all">
<link rel="stylesheet" href="./views/ui/style/admin.css" media="all">
<link rel="stylesheet" href="./views/ui/style/login.css" media="all">
<title>登录</title>
</head>
<body>
<div class="layadmin-user-login layadmin-user-display-show" id="user-login" style="display: none;">

    <div class="layadmin-user-login-main">
      <div class="layadmin-user-login-box layadmin-user-login-header">
        <h2><a href="<?php echo Option::get('blogurl'); ?>"><?php echo Option::get('blogname'); ?></a></h2>
        <p><?php echo Option::get('bloginfo'); ?></p>
      </div>
	  <form name="f" method="post" action="./index.php?action=<?=md5(date("Y-m-d h:i"));?>">
      <div class="layadmin-user-login-box layadmin-user-login-body layui-form">
        <div class="layui-form-item">
          <label class="layadmin-user-login-icon layui-icon layui-icon-username" for="user-login-username"></label>
          <input type="text" name="user" id="user" lay-verify="required" placeholder="请输入用户名/邮箱" class="layui-input">
        </div>
        <div class="layui-form-item">
          <label class="layadmin-user-login-icon layui-icon layui-icon-password" for="user-login-password"></label>
          <input type="password" name="pw" id="pw" lay-verify="required" placeholder="请输入密码" class="layui-input">
        </div>
		<?php if($ckcode){?>
        <div class="layui-form-item">
          <div class="layui-row">
            <?php echo $ckcode; ?>
          </div>
        </div>
		<?php }?>
        <div class="layui-form-item" style="margin-bottom: 20px;">
          <input type="checkbox" id="ispersis" name="ispersis" title="记住密码">
          <a href="./index.php?action=forget" class="layadmin-user-jump-change layadmin-link" style="margin-top: 7px;">忘记密码？</a>
        </div>
        <div class="layui-form-item">
          <button class="layui-btn layui-btn-fluid" lay-submit lay-filter="login-submit">登 入</button>
        </div>
		<?php if ($error_msg){?>
		  <blockquote class="layui-elem-quote layui-quote-nm">
			  <?php echo $error_msg;?>
		  </blockquote>
		<?php }?>
        <div class="layui-trans layui-form-item layadmin-user-login-other">
          
          <?php if(Option::get('email_reg') == 'y'){?>
          <a href="./index.php?action=register" class="layadmin-user-jump-change layadmin-link">注册帐号</a>
		  <?php }?>
        </div>
		<div class="layui-form-item">
          <?php doAction('login_ext'); ?>
        </div>
      </div>
	  </form>
    </div>
    
    <div class="layui-trans layadmin-user-login-footer">
      <p>© <?=date("Y");?> Powered by <a href="https://www.tongleer.com/" class="blue-text" target="_blank">tongleer</a></p>
      <p>
        <span><a href="http://club.tongleer.com/" target="_blank">获取程序</a></span>
        <span><a href="http://club.tongleer.com/" target="_blank">论坛交流</a></span>
        <span><a href="https://www.tongleer.com/" target="_blank">前往博客</a></span>
      </p>
    </div>
    
</div>
<script src="./views/ui/layui/layui.js"></script>
<script>
  try{document.getElementById("user").focus();}catch(e){}
  layui.config({
    base: './views/ui/'
  }).extend({
    index: 'lib/index'
  }).use(['index', 'user'], function(){
    var $ = layui.$
    ,setter = layui.setter
    ,admin = layui.admin
    ,form = layui.form
    ,router = layui.router()
    ,search = router.search;

    form.render();
    
  });
</script>
</body>
</html>
