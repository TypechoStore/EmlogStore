<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div>
	<?php if (ROLE == ROLE_ADMIN):?>
	<button type="button" onclick="location.href='./configure.php'" class="layui-btn layui-btn-primary layui-btn-xs">基本设置</button>
	<button type="button" onclick="location.href='./seo.php'" class="layui-btn layui-btn-primary layui-btn-xs">SEO设置</button>
	<button type="button" onclick="location.href='./mailsafety.php'" class="layui-btn layui-btn-primary layui-btn-xs">邮件防护</button>
	<button type="button" onclick="location.href='./blogger.php'" class="layui-btn layui-btn-primary layui-btn-xs">个人设置</button>
	<?php else:?>
	<button type="button" onclick="location.href='./blogger.php'" class="layui-btn layui-btn-primary layui-btn-xs">个人设置</button>
	<?php endif;?>
	<?php if(isset($_GET['active_edit'])):?><blockquote class="actived layui-elem-quote">个人资料修改成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_del'])):?><blockquote class="actived layui-elem-quote">头像删除成功</blockquote><?php endif;?>
	<?php if(isset($_GET['error_a'])):?><blockquote class="error layui-elem-quote">昵称不能太长</blockquote><?php endif;?>
	<?php if(isset($_GET['error_b'])):?><blockquote class="error layui-elem-quote">电子邮件格式错误</blockquote><?php endif;?>
	<?php if(isset($_GET['error_c'])):?><blockquote class="error layui-elem-quote">密码长度不得小于6位</blockquote><?php endif;?>
	<?php if(isset($_GET['error_d'])):?><blockquote class="error layui-elem-quote">两次输入的密码不一致</blockquote><?php endif;?>
	<?php if(isset($_GET['error_e'])):?><blockquote class="error layui-elem-quote">该登录名已存在</blockquote><?php endif;?>
	<?php if(isset($_GET['error_f'])):?><blockquote class="error layui-elem-quote">该昵称已存在</blockquote><?php endif;?>
	<?php if(isset($_GET['error_g'])):?><blockquote class="error layui-elem-quote">邮箱验证码不正确</blockquote><?php endif;?>
	<?php if(isset($_GET['error_h'])):?><blockquote class="error layui-elem-quote">填写邮箱和发送验证码的邮箱不一致</blockquote><?php endif;?>
	<?php if(isset($_GET['error_i'])):?><blockquote class="error layui-elem-quote">邮箱已存在</blockquote><?php endif;?>
	<?php if(isset($_GET['error_j'])):?><blockquote class="error layui-elem-quote">登陆账号验证码不正确</blockquote><?php endif;?>
	<?php if(isset($_GET['error_k'])):?><blockquote class="error layui-elem-quote">填写登陆账号和发送账号验证码的邮箱不一致</blockquote><?php endif;?>
</div>

<div style="background-color:#fff;padding:10px;">
	<form class="layui-form" action="blogger.php?action=update" method="post" name="blooger" id="blooger" enctype="multipart/form-data">
		<li>
		<?php echo $icon; ?><input type="hidden" name="photo" value="<?php echo $photo; ?>"/>
		<div style="margin:10px 0px;">头像</div>
		<input name="photo" type="file" /><br />
		(支持JPG、PNG格式图片)
		</li>
		<li><div style="margin:10px 0px;">昵称</div><input maxlength="50" style="width:300px;" class="layui-input" value="<?php echo $nickname; ?>" name="name" /> </li>
		<li><div style="margin:10px 0px;">邮箱</div><input name="email" class="layui-input" value="<?php echo $email; ?>" style="width:300px;" maxlength="200" /></li>
		<li>
			<div class="layui-input-inline">
				<input name="emailcode" class="layui-input" value="" style="width:100px;" maxlength="10" placeholder="邮箱验证码" />
			</div>
			<div class="layui-input-inline" id="post_options">
				<button type="button" id="sendMailCode" class="layui-btn layui-btn-primary">发送</button>
			</div>
		</li>
		<li><div style="margin:10px 0px;">网站</div><input name="website" type="url" id="website" value="<?php echo $website ?>" style="width:300px;" class="layui-input" /></li>
		<li><div style="margin:10px 0px;">个人描述</div><textarea name="description" class="layui-textarea" maxlength="75" style="width:300px; height:65px;" type="text" maxlength="500"><?php echo $description; ?></textarea></li>
		<li><div style="margin:10px 0px;" lay-tips="设置为邮箱登陆账号方便忘记密码时进行找回">登陆账号 <i class="layui-icon layui-icon-tips" lay-tips="设置为邮箱登陆账号方便忘记密码时进行找回"></i></div><input maxlength="200" style="width:300px;" class="layui-input" value="<?php echo $username; ?>" name="username" /></li>
		<li>
			<div class="layui-input-inline">
				<input name="usercode" class="layui-input" value="" style="width:100px;" maxlength="10" placeholder="账号验证码" />
			</div>
			<div class="layui-input-inline" id="post_options">
				<button type="button" id="sendUserCode" class="layui-btn layui-btn-primary">发送</button>
			</div>
		</li>
		<li><div style="margin:10px 0px;">新密码（不小于6位，不修改请留空）</div><input type="password" maxlength="200" class="layui-input" style="width:300px;" value="" name="newpass" /></li>
		<li><div style="margin:10px 0px;">再输入一次新密码</div><input type="password" maxlength="200" class="layui-input" style="width:300px;" value="" name="repeatpass" /></li>
		<li style="margin-top:10px;">
			<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
			<input type="submit" value="保存资料" class="layui-btn" />
		</li>
	</form>
</div>

<script>
$(function(){
	layui.use(["form"], function(){
		var form = layui.form;
	});
	$("#sendMailCode").click(function(){
		if(!/^(\w-*\.*)+@(\w-?)+(\.\w{2,})+$/.test($("input[name='email']").val())){
			layer.msg("电子邮件格式错误");
			return;
		}
		$.post("index.php?action=sendMailCode",{email:$("input[name='email']").val()},function(data){
			$("#sendMailCode").text('重新发送');
		});
	});
	$("#sendUserCode").click(function(){
		if(!/^(\w-*\.*)+@(\w-?)+(\.\w{2,})+$/.test($("input[name='username']").val())){
			layer.msg("登陆账号必须为邮箱格式");
			return;
		}
		$.post("index.php?action=sendMailCode",{username:$("input[name='username']").val()},function(data){
			$("#sendUserCode").text('重新发送');
		});
	});
});
setTimeout(hideActived,2600);
</script>