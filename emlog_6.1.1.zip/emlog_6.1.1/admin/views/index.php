<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div class="layui-col-md8">
	<div class="layui-row layui-col-space15">
	  <div class="layui-col-md6">
		<div class="layui-card">
		  <div class="layui-card-header">快捷方式</div>
		  <div class="layui-card-body">
			
			<div class="layui-carousel layadmin-carousel layadmin-shortcut" style="overflow:scroll;">
			  <div>
				<ul class="layui-row layui-col-space10">
				  <li class="layui-col-xs3">
					<a href="write_log.php">
					  <i class="layui-icon">&#xe642;</i>
					  <cite>撰写</cite>
					</a>
				  </li>
				  <li class="layui-col-xs3">
					<a href="blogger.php">
					  <i class="layui-icon">&#xe63c;</i>
					  <cite>资料</cite>
					</a>
				  </li>
				  <li class="layui-col-xs3">
					<a href="link.php">
					  <i class="layui-icon layui-icon-link"></i>
					  <cite>链接</cite>
					</a>
				  </li>
				  <li class="layui-col-xs3">
					<a href="faq.php">
					  <i class="layui-icon layui-icon-survey"></i>
					  <cite>工单</cite>
					</a>
				  </li>
				</ul>
				<?php if (ROLE == ROLE_ADMIN){?>
				<ul class="layui-row layui-col-space10">
				  <li class="layui-col-xs3">
					<a href="navbar.php">
					  <i class="layui-icon layui-icon-find-fill"></i>
					  <cite>导航</cite>
					</a>
				  </li>
				  <li class="layui-col-xs3">
					<a href="widgets.php">
					  <i class="layui-icon">&#xe631;</i>
					  <cite>工具</cite>
					</a>
				  </li>
				  <li class="layui-col-xs3">
					<a href="template.php">
					  <i class="layui-icon layui-icon-templeate-1"></i>
					  <cite>模板</cite>
					</a>
				  </li>
				  <li class="layui-col-xs3">
					<a href="store.php">
					  <i class="layui-icon layui-icon-app"></i>
					  <cite>商店</cite>
					</a>
				  </li>
				</ul>
				<?php }?>
			  </div>
			</div>
			
		  </div>
		</div>
	  </div>
	  <div class="layui-col-md6">
		<div class="layui-card">
		  <div class="layui-card-header">数据统计</div>
		  <div class="layui-card-body">

			<div class="layui-carousel layadmin-carousel layadmin-backlog" style="overflow:scroll;">
			  <div>
				<ul class="layui-row layui-col-space10">
				  <li class="layui-col-xs6">
					<a href="comment.php" class="layadmin-backlog-body">
					  <h3>评论总数</h3>
					  <p><cite><?php echo $sta_cache[UID]['commentnum'];?></cite></p>
					</a>
				  </li>
				  <li class="layui-col-xs6">
					<a href="admin_log.php" class="layadmin-backlog-body">
					  <h3>文章总数</h3>
					  <p><cite><?php echo $sta_cache[UID]['lognum'];?></cite></p>
					</a>
				  </li>
				  <li class="layui-col-xs6">
					<?php
						$hidecmnum = ROLE == ROLE_ADMIN ? $sta_cache['hidecomnum'] : $sta_cache[UID]['hidecommentnum'];
					?>
					<a href="<?php echo $hidecmnum>0?"./comment.php?hide=y":"javascript:;"; ?>" title="<?php echo $hidecmnum>0?$hidecmnum."条评论待审":""; ?>" class="layadmin-backlog-body">
					  <h3>待审评论</h3>
					  <p>
						<cite>
						<?php
						$hidecmnum = ROLE == ROLE_ADMIN ? $sta_cache['hidecomnum'] : $sta_cache[UID]['hidecommentnum'];
						echo $hidecmnum;
						?>
						</cite>
					  </p>
					</a>
				  </li>
				  <li class="layui-col-xs6">
					<a href="admin_log.php?pid=draft" class="layadmin-backlog-body">
					  <h3>草稿数</h3>
					  <p>
						<cite>
						<?php 
						if (ROLE == ROLE_ADMIN){
							echo $sta_cache['draftnum'] == 0 ? '0' : $sta_cache['draftnum']; 
						}else{
							echo $sta_cache[UID]['draftnum'] == 0 ? '0' : $sta_cache[UID]['draftnum'];
						}
						?>
						</cite>
					  </p>
					</a>
				  </li>
				</ul>
				<?php if (ROLE == ROLE_ADMIN){?>
				<ul class="layui-row layui-col-space10">
				  <li class="layui-col-xs6">
					<?php $checknum = $sta_cache['checknum'];?>
					<a href="<?php echo $checknum>0?"./admin_log.php?checked=n":"javascript:;"; ?>" title="<?php echo $checknum>0?$checknum."篇文章待审":""; ?>" class="layadmin-backlog-body">
					  <h3>待审文章</h3>
					  <p>
						<cite><?php echo $checknum; ?></cite>
					  </p>
					</a>
				  </li>
				  <li class="layui-col-xs6">
					<a href="tag.php" class="layadmin-backlog-body">
					  <h3>标签数</h3>
					  <p><cite><?=count($tags);?></cite></p>
					</a>
				  </li>
				  <li class="layui-col-xs6">
					<a href="twitter.php" class="layadmin-backlog-body">
					  <h3>微语</h3>
					  <p><cite><?php echo($sta_cache[UID]["twnum"]);?></cite></p>
					</a>
				  </li>
				  <li class="layui-col-xs6">
					<a href="link.php" class="layadmin-backlog-body">
					  <h3>链接</h3>
					  <p><cite><?=count($links);?></cite></p>
					</a>
				  </li>
				  <li class="layui-col-xs6">
					<a href="page.php" class="layadmin-backlog-body">
					  <h3>页面</h3>
					  <p><cite><?=$pageNum;?></cite></p>
					</a>
				  </li>
				  <li class="layui-col-xs6">
					<a href="user.php" class="layadmin-backlog-body">
					  <h3>用户</h3>
					  <p><cite><?=$usernum;?></cite></p>
					</a>
				  </li>
				</ul>
				<?php }?>
			  </div>
			</div>
		  </div>
		</div>
	  </div>
	  <div class="layui-col-md12">
		<div class="layui-card">
		  <div class="layui-tab layui-tab-brief layadmin-latestData">
			<ul class="layui-tab-title">
			  <li class="layui-this">最新文章</li>
			  <li>最新评论</li>
			</ul>
			<div class="layui-tab-content" style="word-wrap: break-word; word-break: normal;">
			  <div class="layui-tab-item layui-show">
				<ul class="layui-timeline">
					<?php
					if($newLogs){
						foreach($newLogs as $val){
							?>
							<li class="layui-timeline-item">
								<i class="layui-icon layui-timeline-axis"></i>
								<div class="layui-timeline-content layui-text">
								  <div class="layui-timeline-title"><?=$val['date'];?>，<a href="<?=Url::log($val['gid']);?>" target="_blank"><?=$val['title'];?></a></div>
								</div>
							</li>
							<?php
						}
					}else{
						?>
						暂无文章
						<?php
					}
					?>
				</ul>
			  </div>
			  <div class="layui-tab-item">
				<ul class="layui-timeline">
					<?php
					if($newComments){
						foreach($newComments as $val){
							?>
							<li class="layui-timeline-item">
								<i class="layui-icon layui-timeline-axis"></i>
								<div class="layui-timeline-content layui-text">
								  <div class="layui-timeline-title"><?=$val['date'];?>，<a href="<?=Url::log($val['gid']).'#comment-'.$val["cid"];?>" target="_blank"><?=$val['poster'].'：'.htmlspecialchars ($val['comment']);?></a></div>
								</div>
							</li>
							<?php
						}
					}else{
						?>
						暂无评论
						<?php
					}
					?>
				</ul>
			  </div>
			</div>
		  </div>
		</div>
	  </div>
	  <?php if (ROLE == ROLE_ADMIN){?>
	  <div class="layui-col-md12">
		<div class="layui-card">
		  <div class="layui-tab layui-tab-brief layadmin-latestData">
			<ul class="layui-tab-title">
			  <li class="layui-this">更新记录</li>
			  <li>官方动态</li>
			  <li>站点信息</li>
			</ul>
			<div class="layui-tab-content">
			  <div class="layui-tab-item layui-show">
				<ul class="layui-timeline" id="updateinfo"></ul>
			  </div>
			  <div class="layui-tab-item">
				<ul class="layui-timeline" id="newsmsg"></ul>
			  </div>
			  <div class="layui-tab-item">
				<table class="layui-table"lay-size="sm">
					<tbody>
						<tr>
							<td>MySQL版本</td>
							<td><?php echo $mysql_ver; ?></td>
							<td>版本号</td>
							<td> <?php echo Option::EMLOG_VERSION; ?> </td>
						</tr>
						<tr>
							<td>数据库表</td>
							<td><?php echo DB_NAME; ?></td>
							<td>数据库表前缀</td>
							<td><?php echo DB_PREFIX; ?></td>
						</tr>
						<tr>
							<td>服务器操作系统</td>
							<td><?php echo php_uname('s') ; ?></td>
							<td>服务器端口</td>
							<td><?php echo $_SERVER["SERVER_PORT"]; ?></td>
						</tr>
						<tr>
							<td>服务器剩余空间</td>
							<td><?php echo intval(diskfreespace(".") / (1024 * 1024))."M" ; ?></td>
							<td>服务器时间</td>
							<td><?php date_default_timezone_set("Asia/Shanghai");echo date("Y-m-d H:i:s");?></td>
						</tr>
						<tr>
							<td>WEB服务器版本</td>
							<td><?php echo $_SERVER['SERVER_SOFTWARE'] ; ?></td>
							<td>服务器语种</td>
							<td><?php echo getenv("HTTP_ACCEPT_LANGUAGE") ; ?></td>
						</tr>
						<tr>
							<td>PHP版本</td><td><?php echo $php_ver; ?></td>
							<td>ZEND版本</td><td><?php echo zend_version() ; ?></td>
						</tr>
						<tr>
							<td>脚本运行可占最大内存</td>
							<td><?php echo ini_get("memory_limit"); ?></td>
							<td>脚本上传文件大小限制</td>
							<td><?php echo $uploadfile_maxsize; ?></td>
						</tr>
						<tr>
							<td>POST方法提交限制</td>
							<td><?php echo ini_get("post_max_size"); ?></td>
							<td>脚本超时时间</td>
							<td><?php echo ini_get("max_execution_time"); ?></td>
						</tr>
						<tr>
							<td>GD图形处理库：</td>
							<td><?php echo $gd_ver; ?></td>
							<td colspan="2"><a href="index.php?action=phpinfo&token=<?php echo LoginAuth::genToken();?>" target="_blank">更多信息&raquo;</td>
						</tr>
					</tbody>
				</table>
			  </div>
			</div>
		  </div>
		</div>
	  </div>
	  <?php }?>
	</div>
</div>
  
<div class="layui-col-md4">
	<?php if (ROLE == ROLE_ADMIN){?>
	<div class="layui-card">
	  <div class="layui-card-header">
		微语
		<i class="layui-icon layui-icon-tips" lay-tips="记录生活 感动天地"></i>
	  </div>
	  <div class="layui-card-body layui-text layadmin-text">
		<div class="layui-form-item layui-form-text">
			<label class="layui-form-label">
				<a href="./blogger.php" title="<?php echo $name; ?>">
					<img src="<?php echo $avatar; ?>" class="layui-circle" />
				</a>
			</label>
			<div class="layui-input-block">
			<form class="layui-form" method="post" action="twitter.php?action=post">
			  <textarea maxLength="140" name="t" placeholder="用微语记录生活 ……(最多输入140字)" class="layui-textarea"></textarea>
			  <input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
			  <input type="submit" class="layui-btn layui-btn-primary" value="发布" />
			</form>
			</div>
		</div>
	  </div>
	</div>
	<?php }?>
	
	<div class="layui-card">
	  <div class="layui-card-header">最新微语</div>
	  <div class="layui-card-body" style="word-wrap: break-word; word-break: normal;">
		<ul class="layui-timeline">
			<?php
			if($newTwitters){
				foreach($newTwitters as $val){
					?>
					<li class="layui-timeline-item">
						<i class="layui-icon layui-timeline-axis"></i>
						<div class="layui-timeline-content layui-text">
						  <h3 class="layui-timeline-title"><?=$val['date'];?></h3>
						  <p><a href="../t" target="_blank"><?=emoFormat($val['content']);?></a></p>
						</div>
					</li>
					<?php
				}
			}else{
				?>
				还没有发布任何微语
				<?php
			}
			?>
		</ul>
	  </div>
	</div>
	
	<?php if (ROLE == ROLE_ADMIN){?>
	<div class="layui-card">
	  <div class="layui-card-header">版本信息</div>
	  <div class="layui-card-body layui-text">
		<table class="layui-table">
		  <colgroup>
			<col width="100">
			<col>
		  </colgroup>
		  <tbody>
			<tr>
			  <td>版本检测</td>
			  <td id="versioncheck">
				<!--
				<?php
				define('info_url' , TLE_SERVICE_HOST.'me/api/store/update.php?action=update' ); 
				$ch = curl_init(); 
				curl_setopt($ch, CURLOPT_RETURNTRANSFER,1); 
				curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,2);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,FALSE); 
				curl_setopt($ch,CURLOPT_URL,info_url); 
				$value_info = ext_json_decode(curl_exec($ch));
				define('get_version' , $value_info->version); 
				define('get_fixed' , $value_info->fix_bug); 
				define('get_date' , $value_info->last_time );
				define('get_info_cn' , $value_info->info_cn ); 
				define('get_details_url' , $value_info->details_url ); 
				define('get_down' , $value_info->download_url ); 
				define('get_downs' , $value_info->downloads_url ); 
				define('get_sql' , $value_info->sql_url ); 
				define('get_mysql' , $value_info->mysql ); 
				
				?>
				<?php //echo "V".Option::EMLOG_VERSION; ?>
				<?php if(get_version > Option::EMLOG_VERSION || get_fixed > 0 || get_mysql > 0){ ?>
				<?php if(get_mysql > 0 ): ?>
				<a href="javascript:if(confirm('此更新包会影响数据表结构，确认要更新吗？')){location.href='./store.php?action=update&type=upd&source=<?php echo get_downs ?>&upsql=<?php echo get_sql ?>&token=<?php echo LoginAuth::genToken(); ?>';}" class="layui-btn layui-btn-primary layui-btn-xs" lay-tips="<?php echo "更新时间：".get_date."；更新内容：".get_info_cn;?>">有更新<span class="layui-badge-dot"></span></a>
				<?php else: ?>
				<a href="javascript:if(confirm('确认要更新吗？')){location.href='./store.php?action=update&type=upd&source=<?php echo get_down ?>&token=<?php echo LoginAuth::genToken(); ?>';};" class="layui-btn layui-btn-primary layui-btn-xs" lay-tips="<?php echo "更新时间：".get_date."；更新内容：".get_info_cn;?>">有更新<span class="layui-badge-dot"></span></a>	
				<?php endif ?>
				<a href="<?php echo get_details_url;?>" target="_blank" class="layui-btn layui-btn-primary layui-btn-xs">详情</a>
				<?php }else{ ?>									
				<a href="javascript:void(0);" class="layui-btn layui-btn-primary layui-btn-xs" lay-tips="<?php echo "更新时间：".get_date."；更新内容：".get_info_cn;?>">无需更新</a>
				<?php } ?>
				-->
			  </td>
			</tr>
			<tr>
			  <td>主要特色</td>
			  <td>零门槛 / 响应式 / 清爽 / 极简</td>
			</tr>
			<tr>
			  <td>获取渠道</td>
			  <td style="padding-bottom: 0;">
				<div class="layui-btn-container">
				  <a href="http://club.tongleer.com" target="_blank" class="layui-btn layui-btn-primary layui-btn-xs">同乐论坛</a>
				</div>
			  </td>
			</tr>
		  </tbody>
		</table>
	  </div>
	</div>
	<?php }?>
	<div class="layui-card">
	  <div class="layui-card-header">白板</div>
	  <div class="layui-card-body" style="word-wrap: break-word; word-break: normal;">
		<?php doAction('adm_main_top'); ?>
	  </div>
	</div>
</div>
<script>
	$(document).ready(function() {
		$("#versioncheck").html("<a href=\"javascript:void(0);\" onClick=\"return false;\" class=\"layui-btn layui-btn-primary layui-btn-xs\">检测中……</a>");
		$.getJSON("<?php echo TLE_SERVICE_HOST; ?>me/api/store/update.php?action=update",
			function(data) {
				$("#versioncheck").html("");
				if(data.version>"<?=Option::EMLOG_VERSION;?>"||data.fix_bug>0.6||data.mysql>0){
					if(data.mysql>0){
						$("#versioncheck").append("<a href=\"javascript:if(confirm('此更新包会影响数据表结构，确认要更新吗？')){location.href='./store.php?action=update&type=upd&source="+data.downloads_url+"&upsql="+data.sql_url+"&token=<?php echo LoginAuth::genToken(); ?>';}\" class=\"layui-btn layui-btn-primary layui-btn-xs\" lay-tips=\"更新时间："+data.last_time+"；更新内容："+data.info_cn+"\">有更新<span class=\"layui-badge-dot\"></span></a>");
					}else{
						$("#versioncheck").append("<a href=\"javascript:if(confirm('确认要更新吗？')){location.href='./store.php?action=update&type=upd&source="+data.download_url+"&token=<?php echo LoginAuth::genToken(); ?>';};\" class=\"layui-btn layui-btn-primary layui-btn-xs\" lay-tips=\"更新时间："+data.last_time+"；更新内容："+data.info_cn+"\">有更新<span class=\"layui-badge-dot\"></span></a>");
					}
					$("#versioncheck").append("<a href=\""+data.details_url+"\" target=\"_blank\" class=\"layui-btn layui-btn-primary layui-btn-xs\">详情</a>");
				}else{
					$("#versioncheck").html("<a href=\"javascript:void(0);\" onClick=\"return false;\" class=\"layui-btn layui-btn-primary layui-btn-xs\" lay-tips=\"更新时间："+data.last_time+"；更新内容："+data.info_cn+"\">无需更新</a>");
				}
			});
		$("#newsmsg").html("正在读取...");
		$.getJSON("<?php echo OFFICIAL_SERVICE_HOST; ?>services/messenger.php?v=5.3.1&callback=?",
			function(data) {
				$("#newsmsg").html("");
				$.each(data.items, function(i, item) {
					$("#newsmsg").append("<li class=\"layui-timeline-item\"><i class=\"layui-icon layui-timeline-axis\"></i><div class=\"layui-timeline-content layui-text\"><div class=\"layui-timeline-title\">" + item.date + "，<a href=\"" + item.url + "\" target=\"_blank\">" + item.title + "</a></div></div></li>");
				});
			});
		$("#updateinfo").html("正在读取...");
		$.getJSON("<?php echo TLE_SERVICE_HOST; ?>me/api/store/update.php?action=updatehistory",
			function(data) {
				$("#updateinfo").html("");
				$.each(data.items, function(i, item) {
					$("#updateinfo").append("<li class=\"layui-timeline-item\"><i class=\"layui-icon layui-timeline-axis\"></i><div class=\"layui-timeline-content layui-text\"><div class=\"layui-timeline-title\">" + item.date + "，" + item.t + "</div></div></li>");
				});
				if(data.items.length){
					$("#updateinfo").append("<li class=\"layui-timeline-item\"><i class=\"layui-icon layui-anim layui-anim-rotate layui-anim-loop layui-timeline-axis\"></i><div class=\"layui-timeline-content layui-text\"><div class=\"layui-timeline-title\"><a href=\"https://me.tongleer.com/t\" target=\"_blank\">更多</a></div></div></li>");
				}
			});
	});
	$("#menu_home").addClass('layui-this');
	$("#menu_home").parent().parent().addClass('layui-nav-itemed');
</script>