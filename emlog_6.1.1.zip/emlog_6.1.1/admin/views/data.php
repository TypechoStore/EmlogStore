<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<link href="./views/css/formSelects-v4.css" rel="stylesheet" />
<script src="./views/js/formSelects-v4.min.js"></script>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
	  <legend><b>数据库备份</b></legend>
	</fieldset>
	<?php if(isset($_GET['active_del'])):?><blockquote class="actived layui-elem-quote">备份文件删除成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_backup'])):?><blockquote class="actived layui-elem-quote">数据备份成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_import'])):?><blockquote class="actived layui-elem-quote">备份导入成功</blockquote><?php endif;?>
	<?php if(isset($_GET['error_a'])):?><blockquote class="error layui-elem-quote">请选择要删除的备份文件</blockquote><?php endif;?>
	<?php if(isset($_GET['error_b'])):?><blockquote class="error layui-elem-quote">备份文件名错误(应由英文字母、数字、下划线组成)</blockquote><?php endif;?>
	<?php if(isset($_GET['error_c'])):?><blockquote class="error layui-elem-quote">服务器空间不支持zip，无法导入zip备份</blockquote><?php endif;?>
	<?php if(isset($_GET['error_d'])):?><blockquote class="error layui-elem-quote">上传备份失败</blockquote><?php endif;?>
	<?php if(isset($_GET['error_e'])):?><blockquote class="error layui-elem-quote">错误的备份文件</blockquote><?php endif;?>
	<?php if(isset($_GET['error_f'])):?><blockquote class="error layui-elem-quote">服务器空间不支持zip，无法导出zip备份</blockquote><?php endif;?>
	<?php if(isset($_GET['active_mc'])):?><blockquote class="actived layui-elem-quote">缓存更新成功</blockquote><?php endif;?>
</div>
<form class="layui-form" method="post" action="data.php?action=dell_all_bak" name="form_bak" id="form_bak">
<table width="100%" id="adm_bakdata_list" class="layui-table">
  <thead>
    <tr>
      <th width="683" colspan="2"><b>备份文件</b></th>
      <th width="226"><b>备份时间</b></th>
      <th width="149"><b>文件大小</b></th>
      <th width="87"></th>
    </tr>
  </head>
  <tbody>
	<?php
		if($bakfiles):
		foreach($bakfiles  as $value):
		$modtime = smartDate(filemtime($value),'Y-m-d H:i:s');
		$size =  changeFileSize(filesize($value));
		$bakname = substr(strrchr($value,'/'),1);
	?>
    <tr>
      <td width="22"><input type="checkbox" lay-skin="primary" value="<?php echo $value; ?>" name="bak[]" class="ids" /></td>
      <td width="661"><a href="../content/backup/<?php echo $bakname; ?>"><?php echo $bakname; ?></a></td>
      <td><?php echo $modtime; ?></td>
      <td><?php echo $size; ?></td>
      <td><a href="javascript: em_confirm('<?php echo $value; ?>', 'backup', '<?php echo LoginAuth::genToken(); ?>');">导入</a></td>
    </tr>
	<?php endforeach;else:?>
	  <tr><td colspan="5">还没有备份</td></tr>
	<?php endif;?>
	</tbody>
</table>
<div>
	<input type="checkbox" title="全选" lay-filter="select_all"> 选中项：
	<button type="button" class="layui-btn layui-btn-primary layui-btn-sm" onClick="bakact('del');">删除</button>
	<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
</div>
</form>

<div class="layui-tab layui-tab-card">
  <ul class="layui-tab-title">
    <li class="layui-this">备份数据库</li>
    <li>导入本地备份</li>
    <li>更新缓存</li>
	<li>优化数据</li>
  </ul>
  <div class="layui-tab-content" style="background-color:#fff;">
    <div class="layui-tab-item layui-show">
		<form class="layui-form" action="data.php?action=bakstart" method="post">
			<p>
				<div style="margin:10px 0px;">可备份的数据库表</div>
				<select size="12" name="table_box[]" xm-select="table_box" xm-select-skin="default">
				<?php foreach($tables  as $value): ?>
				<option value="<?php echo DB_PREFIX; ?><?php echo $value; ?>" selected="selected"><?php echo DB_PREFIX; ?><?php echo $value; ?></option>
				<?php endforeach; ?>
				</select>
			</p>
			<p>
				<div style="margin:10px 0px;">将站点内容数据库备份到</div>
				<select name="bakplace" id="bakplace" lay-filter="bakplace">
					<option value="local" selected="selected">本地（自己电脑）</option>
					<option value="server">服务器空间</option>
				</select>
			</p>
			<p id="local_bakzip" style="margin:10px 0px;">
				<input type="checkbox" title="压缩成zip包" value="y" name="zipbak" id="zipbak" lay-filter="zipbak" />
			</p>
			<p style="margin:10px 0px;">
				<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
				<input type="submit" value="开始备份" class="layui-btn layui-btn-primary layui-btn-sm" />
			</p>
		</form>
	</div>
    <div class="layui-tab-item">
		<form class="layui-form" action="data.php?action=import" enctype="multipart/form-data" method="post">
			<p>
				仅可导入相同版本emlog导出的数据库备份文件，且数据库表前缀需保持一致。
				当前数据库表前缀：<?php echo DB_PREFIX; ?>
			</p>
			<p style="margin:10px 0px;"><input type="file" name="sqlfile" /></p>
			<p style="margin:10px 0px;">
				<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
				<input type="submit" value="导入" class="layui-btn layui-btn-primary layui-btn-sm" />
			</p>
		</form>
	</div>
    <div class="layui-tab-item">
		<p>
			缓存可以加快站点的加载速度。通常系统会自动更新缓存，无需手动。有些特殊情况，比如缓存文件被修改、手动修改过数据库、页面出现异常等才需要手动更新。
		</p>
		<p style="margin:10px 0px;">
			<input type="button" onclick="window.location='data.php?action=Cache';" value="更新缓存" class="layui-btn layui-btn-primary layui-btn-sm" />
		</p>
	</div>
	<div class="layui-tab-item">
		<table class="layui-table" id="optimized">
			<thead>
				<tr>
					<th><b>数据表</b></th>
					<th><b> 大小</b></th>
					<th><b> 记录</b></th>
					<th><b> 沉余</b></th>
				</tr>
			</thead>
			<tbody>
				<?php
				$tables = array();
				$result = $DB->query("SHOW TABLE STATUS");
				$tot =0; 
				$rs =0;
				$nrs=0;
				while($row = $DB->fetch_array($result)) {
				$total_size = $row[ "Data_length" ] +  $row[ "Index_length" ];$gain= $row['Data_free'];
				$total_gain += $gain;
				$gain = round ($gain,2);$tbl = $row['Name'];
				$rs++;
				$tot = $tot + $total_size;?>
				<tr>
					<td> <?php echo $tbl?></td>
					<td> <?php echo format_size($total_size);?></td>
					<td>
					<?php
					$q=("select * from $tbl");
					$rez= $DB-> query($q);
					echo $rowss= $DB-> num_rows($rez);
					$nrs =$nrs +$rowss;?>
					</td>
					<?php 
					if ($gain == 0){
					?>
					<td>
					0 KiB
					</td>
					<?php }else{ ?>
					<td style=\"color: #ff0000;\">
					<?php echo format_size($gain) ?>
					<?php } ?>
				</tr>
				<?php }?>
				<tr>
					<td>总共<sup><?php echo $rs ?> </sup></td>
					<td> <?php echo format_size($tot);?> </td>
					<td> <?php echo $nrs ?> </td>
					<td> <?php echo format_size($total_gain);?> </td>
				</tr>
			</tbody>
		</table>
		<button type="button" id="startoptimized" class="layui-btn layui-btn-primary layui-btn-sm">开始优化</button>
	</div>
  </div>
</div>
<script>
setTimeout(hideActived,2600);
$(document).ready(function(){
	layui.use(["form"], function(){
		var form = layui.form;
		form.on('checkbox(select_all)', function(data){
			$("input[name='bak[]']").each(function () {
				this.checked = data.elem.checked;
			});
			form.render('checkbox');
		});
		form.on('select(bakplace)', function(data){
			$("#local_bakzip").toggle();
			$("#server_bakfname").toggle();
		});
		formSelects.render('table_box');
	});
	$("#select_all").toggle(function () {$(".ids").attr("checked", "checked");},function () {$(".ids").removeAttr("checked");});
	$("#adm_bakdata_list tbody tr:odd").css("background-color","#F7F7F7");
	$("#adm_bakdata_list tbody tr")
		.mouseover(function(){$(this).css("background-color","#E9F1FA");$(this).find("span").show();})
		.mouseout(function(){$(this).css("background-color","#F7F7F7");$(this).find("span").hide();});
});
$(document).on("click","#startoptimized",function(){
	$("#optimized").html(' <tbody> <td><i class="layui-icon-loading"></i> 优化中.... </td> </tbody>');	
	var xmlhttp;
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
	  xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
	  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function(){
		if (xmlhttp.readyState==4 && xmlhttp.status==200){
			document.getElementById("optimized").innerHTML=xmlhttp.responseText;
		}
	}
	var url="data.php?action=optimized&token=<?php echo LoginAuth::genToken(); ?>";
	xmlhttp.open("GET",url,true);
	xmlhttp.send();	
});
function bakact(act){
	if (getChecked('ids') == false) {
		alert('请选择要操作的备份文件');
		return;
	}
	if(act == 'del' && !confirm('你确定要删除所选备份文件吗？')){return;}
	$("#operate").val(act);
	$("#form_bak").submit();
}
$("#menu_data").addClass('layui-this');
$("#menu_data").parent().parent().addClass('layui-nav-itemed');
</script>