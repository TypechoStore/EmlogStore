<?php if(!defined('EMLOG_ROOT')) {exit('error!');} ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Language" content="zh-CN" />
<meta name="author" content="tongleer" />
<meta name="robots" content="noindex, nofollow">
<title>管理中心 - <?php echo Option::get('blogname'); ?></title>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link rel="stylesheet" href="./views/ui/layui/css/layui.css" media="all">
<link rel="stylesheet" href="./views/ui/style/admin.css" media="all">
<script src="./views/ui/ace/ace.js"></script>
<script type="text/javascript" src="../include/lib/js/jquery/jquery-1.11.0.js?v=<?php echo Option::EMLOG_VERSION; ?>"></script>
<script type="text/javascript" src="../include/lib/js/jquery/jquery.cookie.js?v=<?php echo Option::EMLOG_VERSION; ?>"></script>
<script type="text/javascript" src="./views/js/common.js?v=<?php echo Option::EMLOG_VERSION; ?>"></script>
<style>
	.layui-layedit-tool .layui-colorpicker-xs {
		border: 0;
	}
	.layui-layedit-tool .layui-colorpicker-trigger-span i {
		display: none !important;
	}
</style>
<?php doAction('adm_head');?>
</head>
<body class="layui-layout-body">
	<div id="LAY_app">
		<div class="layui-layout layui-layout-admin">
		  <div class="layui-header">
			<!-- 头部区域 -->
			<ul class="layui-nav layui-layout-left">
			  <li class="layui-nav-item layadmin-flexible" lay-unselect>
				<a href="javascript:;" title="侧边伸缩" layadmin-event="flexible">
				  <i class="layui-icon layui-icon-shrink-right" id="LAY_app_flexible"></i>
				</a>
			  </li>
			  <li class="layui-nav-item" lay-unselect>
				<a href="<?php echo Option::get('blogurl'); ?>" target="_blank">
				  <i class="layui-icon layui-icon-website" lay-tips="<?=Option::get('blogname');?>前台"></i>
				</a>
			  </li>
			  <li class="layui-nav-item layui-hide-xs" lay-unselect>
				<a href="javascript:location.reload();" layadmin-event="refresh">
				  <i class="layui-icon layui-icon-refresh-3" lay-tips="刷新"></i>
				</a>
			  </li>
			</ul>
			<ul class="layui-nav layui-layout-right">
			  <?php if (ROLE == ROLE_ADMIN){?>
			  <li class="layui-nav-item" lay-unselect>
				<a href="faq.php" layadmin-event="message">
				  <i class="layui-icon layui-icon-notice" lay-tips="工单"></i>  
				</a>
			  </li>
			  <?php }?>
			  <li class="layui-nav-item layui-hide-xs" lay-unselect>
				<a href="javascript:;" layadmin-event="theme">
				  <i class="layui-icon layui-icon-theme" lay-tips="主题"></i>
				</a>
			  </li>
			  <li class="layui-nav-item layui-hide-xs" lay-unselect>
				<a href="javascript:;" layadmin-event="note">
				  <i class="layui-icon layui-icon-note" lay-tips="便签"></i>
				</a>
			  </li>
			  <li class="layui-nav-item layui-hide-xs" lay-unselect>
				<a href="javascript:;" layadmin-event="fullscreen">
				  <i class="layui-icon layui-icon-screen-full" lay-tips="全屏"></i>
				</a>
			  </li>
			  <li class="layui-nav-item" lay-unselect>
				<a href="javascript:;">
				  <cite><img src="<?php echo empty($user_cache[UID]['avatar']) ? './views/images/avatar.jpg' : '../' . $user_cache[UID]['avatar'] ?>" class="layui-nav-img" /><?php echo subString($user_cache[UID]['name'], 0, 12) ?></cite>
				</a>
				<dl class="layui-nav-child">
				  <dd><a href="blogger.php" title="<?php echo subString($user_cache[UID]['name'], 0, 12) ?>">基本资料</a></dd>
				  <?php if (ROLE == ROLE_ADMIN):?>
				  <dd><a href="configure.php">设置</a></dd>
				  <?php endif;?>
				  <hr>
				  <dd style="text-align: center;"><a href="./?action=logout">退出</a></dd>
				</dl>
			  </li>
			</ul>
		  </div>
		  
		  <!-- 侧边菜单 -->
		  <div class="layui-side layui-side-menu">
			<div class="layui-side-scroll">
			  <div class="layui-logo">
				<span>
				  <a href="./index.php" lay-tips="Emlog<?=Option::EMLOG_VERSION;?>">
				  <?php 
					$blog_name = Option::get('blogname');
					echo empty($blog_name) ? '管理后台' : subString($blog_name, 0, 24);
				  ?>
				  <small></small>
				  </a>
				</span>
			  </div>
			  
			  <ul class="layui-nav layui-nav-tree" id="system-side-menu">
				<li class="layui-nav-item">
				  <a href="javascript:;">
					<i class="layui-icon layui-icon-console"></i>
					<cite>仪表盘</cite>
				  </a>
				  <dl class="layui-nav-child">
					<dd id="menu_home">
						<a href="index.php">
							<i class="layui-icon layui-icon-home"></i>
							<cite>首页</cite>
						</a>
					</dd>
				  </dl>
				</li>
				<li class="layui-nav-item">
				  <a href="javascript:;">
					<i class="layui-icon layui-icon-read"></i>
					<cite>文章</cite>
				  </a>
				  <dl class="layui-nav-child">
					<dd id="menu_log">
						<a href="admin_log.php">
							所有文章
							<?php
							$checknum = $sta_cache['checknum'];
							if (ROLE == ROLE_ADMIN && $checknum > 0){
								$n = $checknum > 999 ? '...' : $checknum;
								echo '<span class="layui-badge">'.$n.'</span>';
							}
							?>
						</a>
					</dd>
					<dd id="menu_wt"><a href="write_log.php">写文章</a></dd>
					<dd id="menu_draft">
						<a href="admin_log.php?pid=draft">
							草稿
							<?php 
							if (ROLE == ROLE_ADMIN){
								echo $sta_cache['draftnum'] == 0 ? '' : '<span class="layui-badge">'.$sta_cache['draftnum'].'</span>'; 
							}else{
								echo $sta_cache[UID]['draftnum'] == 0 ? '' : '<span class="layui-badge">'.$sta_cache[UID]['draftnum'].'</span>';
							}
							?>
						</a>
					</dd>
					<?php if (ROLE == ROLE_ADMIN){?>
					<dd id="menu_sort"><a href="sort.php">分类目录</a></dd>
					<dd id="menu_tag"><a href="tag.php">标签</a></dd>
					<?php }?>
				  </dl>
				</li>
				<li class="layui-nav-item" id="menu_cm">
				  <a href="comment.php">
					<i class="layui-icon layui-icon-reply-fill"></i>
					<cite>
						评论
						<?php
						$hidecmnum = ROLE == ROLE_ADMIN ? $sta_cache['hidecomnum'] : $sta_cache[UID]['hidecommentnum'];
						if ($hidecmnum > 0){
							$n = $hidecmnum > 999 ? '...' : $hidecmnum;
							echo '<span class="layui-badge">'.$n.'</span>';
						}
						?>
					</cite>
				  </a>
				</li>
				<?php if (ROLE == ROLE_ADMIN){?>
				<li class="layui-nav-item">
				  <a href="javascript:;">
					<i class="layui-icon layui-icon-template"></i>
					<cite>页面</cite>
				  </a>
				  <dl class="layui-nav-child">
					<dd id="menu_page"><a href="page.php">所有页面</a></dd>
					<dd id="menu_page_new"><a href="page.php?action=new">新建页面</a></dd>
				  </dl>
				</li>
				<li class="layui-nav-item" id="menu_media">
				  <a href="media.php">
					<i class="layui-icon layui-icon-picture"></i>
					<cite>媒体</cite>
				  </a>
				</li>
				<li class="layui-nav-item" id="menu_tw">
				  <a href="twitter.php">
					<i class="layui-icon layui-icon-voice"></i>
					<cite>微语</cite>
				  </a>
				</li>
				<li class="layui-nav-item">
				  <a href="javascript:;">
					<i class="layui-icon layui-icon-link"></i>
					<cite>链接</cite>
				  </a>
				  <dl class="layui-nav-child">
					<dd id="menu_link"><a href="link.php">友情链接</a></dd>
					<dd id="menu_linksort"><a href="sortlink.php">链接分类</a></dd>
				  </dl>
				</li>
				<li class="layui-nav-item">
				  <a href="javascript:;">
					<i class="layui-icon layui-icon-tabs"></i>
					<cite>菜单</cite>
				  </a>
				  <dl class="layui-nav-child">
					<dd id="menu_navbar"><a href="navbar.php">导航</a></dd>
					<dd id="menu_widget"><a href="widgets.php">侧边栏</a></dd>
				  </dl>
				</li>
				<li class="layui-nav-item">
				  <a href="javascript:;">
					<i class="layui-icon layui-icon-set"></i>
					<cite>系统</cite>
				  </a>
				  <dl class="layui-nav-child">
					<dd id="menu_user"><a href="user.php">用户</a></dd>
					<dd id="menu_data"><a href="data.php">数据</a></dd>
					<dd id="menu_tpl"><a href="template.php">模板</a></dd>
					<dd id="menu_plug"><a href="plugin.php">插件</a></dd>
					<dd id="menu_store"><a href="store.php">应用</a></dd>
				  </dl>
				</li>
				<?php if (!empty($emHooks['adm_sidebar_ext'])){ ?>
				<li class="layui-nav-item">
				  <a href="javascript:;">
					<i class="layui-icon layui-icon-app"></i>
					<cite>扩展</cite>
				  </a>
				  <dl class="layui-nav-child">
					<dd><?php doAction('adm_sidebar_ext'); ?></dd>
				  </dl>
				</li>
				<?php }?>
				<?php }?>
			  </ul>
			</div>
		  </div>

		  <!-- 页面标签 -->
		  <div class="layadmin-pagetabs" id="app_tabs">
			<marquee direction="right" behavior="scroll" scrollamount="1" scrolldelay="10" loop="-1" onMouseOver="this.stop()" onMouseOut="this.start()" width="100%" height="50">
				<?php doAction('adm_main_top'); ?>
			</marquee>
		  </div>
		  
		  <div class="layui-body" id="LAY_app_body">
			<div class="layadmin-tabsbody-item layui-show" style="overflow:scroll;background-color:#F8F8F8;">
				<div class="layui-fluid">
					<div class="layui-row layui-col-space15">