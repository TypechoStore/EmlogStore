<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<link rel="stylesheet" href="./views/ui/style/template.css" media="all">
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
	  <legend><b>微语</b></legend>
	</fieldset>
	<?php if(isset($_GET['active_t'])):?><blockquote class="actived layui-elem-quote">发布成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_set'])):?><blockquote class="actived layui-elem-quote">设置保存成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_del'])):?><blockquote class="actived layui-elem-quote">微语删除成功</blockquote><?php endif;?>
	<?php if(isset($_GET['error_a'])):?><blockquote class="error layui-elem-quote">微语内容不能为空</blockquote><?php endif;?>
</div>

<div class="layui-fluid layadmin-message-fluid">
  <div class="layui-row">
    <div class="layui-col-md12">
      <form class="layui-form" method="post" action="twitter.php?action=post">
        <div class="layui-form-item layui-form-text">
          <div class="layui-input-block">
			<textarea maxLength="140" name="t" placeholder="用微语记录生活 ……(最多输入140字)" class="box layui-textarea"></textarea>
          </div>
        </div>

        <div class="layui-form-item" style="overflow: hidden;">
          <div class="layui-input-block layui-input-right">
			<span class="msg">你还可以输入140字</span>
			<input type="submit" class="layui-btn layui-btn-primary layui-btn-sm" onclick="return checkt();" value="发布" />
          </div>
          <div class="layadmin-messag-icon">
            <a id="face" href="javascript:;"><i class="layui-icon layui-icon-face-smile-b"></i></a>
			<a id="img_select" href="javascript:;"><i class="layui-icon layui-icon-picture"></i></a>
			<div class="layui-upload">
			  <div id="uptwimg" class="layui-upload-list">
				<a href="javascript:;" onclick="unSelectFile()" title=""><img class="layui-upload-img" width="100" alt=""></a>
				<p id="uptwerror"></p>
			  </div>
			</div>
			<input type="hidden" name="img" id="imgPath" />
            <input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
			<?php doAction('twitter_form'); ?>
          </div>
        </div>
      </form>
    </div>
    <div class="layui-col-md12 layadmin-homepage-list-imgtxt message-content">
		<?php
		foreach($tws as $val){
			$author = $user_cache[$val['author']]['name'];
			$avatar = empty($user_cache[$val['author']]['avatar']) ? './views/images/avatar.jpg' : '../' . $user_cache[$val['author']]['avatar'];
			$tid = (int)$val['id'];
			$replynum = $Reply_Model->getReplyNum($tid);
			$hidenum = $replynum - $val['replynum'];
			if(strpos($val['img'],"http")===false){
				$bigimg=BLOG_URL.str_replace('thum-', '', $val['img']);
				$smallimg=BLOG_URL.$val['img'];
			}else{
				$bigimg=$val['img'];
				$smallimg=$val['img'];
			}
			$img = empty($val['img']) ? "" : '<a title="查看图片" href="'.$bigimg.'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.$smallimg.'"/></a>';
			?>
			<div class="media-body">
			  <a href="javascript:;" class="media-left" style="float: left;">
			  
				 <img src="<?php echo $avatar; ?>" height="46px" width="46px">
			  </a>
			  <div class="pad-btm">
				<p class="fontColor"><a href="javascript:;"><?php echo $author; ?></a></p>
				<p class="min-font">
				  <span class="layui-breadcrumb post" id="<?php echo $tid;?>" lay-separator="-">
					<a href="javascript:;"><?php echo $val['date'];?></a>
					<a class="replyfirst" id="replyfirst<?php echo $tid;?>" href="javascript:;">回复( 共<span><?php echo $replynum;?></span>条 待审<small><?php echo $hidenum > 0 ? $hidenum : 0;?></small>条 )</a>
					<a href="javascript:em_confirm(<?php echo $tid;?>, 'tw', '<?php echo LoginAuth::genToken(); ?>');;">删除</a>
				  </span>
				</p>         
			  </div>
			  <p class="message-text"><?php echo $val['t'];?></p>
			  <?php echo $img;?>
			  <div>
				<div id="r_<?php echo $tid;?>" class="r"></div>
				<div class="huifu" id="rp_<?php echo $tid;?>" style="display:none;">
					<textarea name="reply" class="layui-textarea"></textarea>
					<button class="layui-btn-primary layui-btn-sm" type="button" onclick="doreply(<?php echo $tid;?>);">回复</button> <span style="color:#FF0000"></span>
				</div>
				<span style="color:#FF0000"></span></div>
			</div>
		<?php
		}
		?>
		<div class="layui-row message-content-btn">
			<center><div id="page"></div></center>
			<center>(有<?php echo $twnum; ?>条微语)</center>
		</div>
    </div>

  </div>
</div>

<div id="faceWraps" style="display:none;width: 150px;overflow: auto;position: absolute;text-align: center;z-index: 10000;border-radius: 5px;border: 1px solid #DDDDDD;background: #FEFEFE;"></div>
<script type="text/javascript" src="../include/lib/js/uploadify/jquery.uploadify.min.js?v=<?php echo Option::EMLOG_VERSION; ?>"></script>
<script type="text/javascript" src="./views/js/emo.js?v=<?php echo Option::EMLOG_VERSION; ?>"></script>
<script>
$(document).ready(function(){
	layui.use(["laypage", "layer", "form",'upload'], function(){
	  var laypage = layui.laypage;
	  var layer = layui.layer;
	  laypage.render({
		elem: "page"
		,count: <?=$twnum;?>
		,limit: <?=Option::get('admin_perpage_num');?>
		,curr:<?=$page;?>
		,layout: ["prev", "page", "next", "skip"]
		,jump: function(obj,first){
			if(!first){
			  location.href="twitter.php?page="+obj.curr;
			}
		}
	  });
	  
	  var $ = layui.jquery
	  ,upload = layui.upload;
	  var uploadInst = upload.render({
		elem: '#img_select'
		,url: 'attachment.php?action=upload_tw_img'
		,method:"post"
		,accept:"images"
		,acceptMime: 'image/*'
		,exts: 'jpg|png|gif|bmp|jpeg'
		,size: '2048'
		,field:'attach'
		,before: function(obj){
		  obj.preview(function(index, file, result){
			$("#uptwimg a img").html("<img src='"+result+"' />");
			layer.load();
		  });
		}
		,done: function(res){
		  layer.closeAll('loading');
		  if(res.code != 0){
			return layer.msg('上传失败');
		  }
		  $("#imgPath").val(res.data.src);
		  $("#img_select").hide();
		  $("#uptwimg").show();
		  $("#uptwimg a").attr("title","点击删除"+res.data.title);
		  $("#uptwimg a").html("<img src='"+res.data.src+"' alt='"+res.data.title+"' />");
		}
		,error: function(){
		  $('#uptwerror').html('<span style="color: #FF5722;">上传失败</span>');
		}
	  });
	});
	
    $(".post .replyfirst").toggle(
      function () {
        tid = $(this).parent().attr('id');
        $.get("twitter.php?action=getreply&tid="+tid+"&stamp="+timestamp(), function(data){
			$("#r_" + tid).html(data);
			$("#rp_"+tid).show();
		});
	  },
      function () {
        tid = $(this).parent().attr('id');
        $("#r_" + tid).html('');
        $("#rp_"+tid).hide();
      }
	);
    $(".box").keyup(function(){
       var t=$(this).val();
       var n = 140 - t.length;
       if (n>=0){
         $(".msg").html("你还可以输入"+n+"字");
       }else {
         $(".msg").html("<span style=\"color:#FF0000\">已超出"+Math.abs(n)+"字</span>");
       }
    });
    setTimeout(hideActived,2600);
    $("#sz_box").css('display', $.cookie('em_sz_box') ? $.cookie('em_sz_box') : '');
	$("#menu_tw").addClass('layui-this');
	$("#menu_tw").parent().parent().addClass('layui-nav-itemed');
    $(".box").focus();
	
	$("#face").click(function(e){
		var wrap = $("#faceWraps");
		if(!wrap.html()){
			var emotionsStr = [];
			$.each(emo,function(k,v){
				emotionsStr.push('<img style="cursor: pointer;padding: 3px;" title="'+k+'" src="./views/ui/layui/images/face/'+v+'"/>');
			});
			wrap.html(emotionsStr.join(""));
		}
		
		wrap.children().unbind('click').click(function () {
			var val= $("textarea").val();
			$("textarea").val((val||"")+$(this).attr("title"));
			$("textarea").focus();
		});

		var offset = $(this).offset();
		wrap.css({
			left : offset.left-180,
			top : offset.top-90
		});
		wrap.show();
		e.stopPropagation();
		e.preventDefault();
		$(document.body).unbind('click').click(function (e) {
			wrap.hide();
		});
		$(document).unbind('click').scroll(function (e) {
			wrap.hide();
		});
	});
});

function unSelectFile(){
	$.get("attachment.php?action=del_tw_img",{filepath:$("#imgPath").val()});
	$("#imgPath").val("");
	$("#img_select").show();
	$("#uptwimg").hide();
	$("#uptwimg a").attr("title","");
	$("#uptwimg a").empty();
}
function reply(tid, rp){
    $("#rp_"+tid+" textarea").val(rp);
    $("#rp_"+tid+" textarea").focus();
}
function doreply(tid){
    var r = $("#rp_"+tid+" textarea").val();
    var post = "r="+encodeURIComponent(r);
	$.post('twitter.php?action=reply&tid='+tid+"&stamp="+timestamp(), post, function(data){
		data = $.trim(data);
		if (data == 'err1'){
            $(".huifu span").text('回复长度需在140个字内');
		}else if(data == 'err2'){
		    $(".huifu span").text('该回复已经存在');
		}else{
    		$("#r_"+tid).append(data);
    		var rnum = Number($("#replyfirst"+tid+" span").text());
    		$("#replyfirst"+tid+" span").html(rnum+1);
    		$(".huifu span").text('')
    	}
	});
}
function delreply(rid,tid){
    if(confirm('你确定要删除该条回复吗？')){
        $.get("twitter.php?action=delreply&rid="+rid+"&tid="+tid+"&stamp="+timestamp(), function(data){
            var tid = Number(data);
            var rnum = Number($("#replyfirst"+tid+" span").text());
            $("#replyfirst"+tid+" span").text(rnum-1);
            if ($("#reply_"+rid+" span button").text() == '审核'){
                var rnum = Number($("#replyfirst"+tid+" small").text());
                if(rnum == 1){$("#replyfirst"+tid+" small").text(0);}else{$("#replyfirst"+tid+" small").text(rnum-1);}
            }
            $("#reply_"+rid).hide("slow");
        })}else {return;}
}
function hidereply(rid,tid){
    $.get("twitter.php?action=hidereply&rid="+rid+"&tid="+tid+"&stamp="+timestamp(), function(){
        $("#reply_"+rid+" blockquote").addClass('layui-quote-nm');
        $("#reply_"+rid+" span button").text('审核');
        $("#reply_"+rid+" span button").attr("onClick","pubreply("+rid+","+tid+")");
        var rnum = Number($("#replyfirst"+tid+" small").text());
        $("#replyfirst"+tid+" small").text(rnum+1);
        });
}
function pubreply(rid,tid){
    $.get("twitter.php?action=pubreply&rid="+rid+"&tid="+tid+"&stamp="+timestamp(), function(){
        $("#reply_"+rid+" blockquote").removeClass('layui-quote-nm');
        $("#reply_"+rid+" span button").text('隐藏');
        $("#reply_"+rid+" span button").attr("onClick","hidereply("+rid+","+tid+")");
        var rnum = Number($("#replyfirst"+tid+" small").text());
        if(rnum == 1){$("#replyfirst"+tid+" small").text(0);}else{$("#replyfirst"+tid+" small").text(rnum-1);}
        });
}
function checkt(){
	var t=$(".box").val();
    if (t.length > 140){return false;}
}
/*修复高版本的jquery中的toggle*/
$.fn.toggle = function( fn ) {
	var args = arguments,
	guid = fn.guid || jQuery.guid++,
	i = 0,
	toggler = function( event ) {
		var lastToggle = ( jQuery._data( this, "lastToggle" + fn.guid ) || 0 ) % i;
		jQuery._data( this, "lastToggle" + fn.guid, lastToggle + 1 );
		event.preventDefault();
		return args[ lastToggle ].apply( this, arguments ) || false;
	};
	toggler.guid = guid;
	while ( i < args.length ) {
		args[ i++ ].guid = guid;
	}
	return this.click( toggler );
}
</script>