<?php 
/**
 * 侧边栏
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="layui-col-md3" id="sidebar">
    <div class="grid-demo" style="word-wrap:break-word;">
	<?php 
	$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
	doAction('diff_side');
	foreach ($widgets as $val)
	{
		$widget_title = @unserialize($options_cache['widget_title']);
		$custom_widget = @unserialize($options_cache['custom_widget']);
		if(strpos($val, 'custom_wg_') === 0)
		{
			$callback = 'widget_custom_text';
			if(function_exists($callback))
			{
				call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
			}
		}else{
			$callback = 'widget_'.$val;
			if(function_exists($callback))
			{
				preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
				$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
				call_user_func($callback, htmlspecialchars($wgTitle));
			}
		}
	}
	?>
	<?php if (Option::get('rss_output_num')):?>
	<div class="layui-card">
		<div class="layui-card-header">
		  <h3 class="panel-title">RSS</h3>
		</div>
		<div class="layui-card-body">
		  <div class="layui-row layui-col-space15">
			<button type="button" style="width:100%;" onClick="window.open('<?php echo BLOG_URL; ?>rss.php');" class="layui-btn layui-btn-primary">RSS订阅</button>
		  </div>
		</div>
	</div>
	<?php endif;?>
	</div>
</div>