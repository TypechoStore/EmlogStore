<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content" class="layui-row layui-col-space20 layadmin-homepage-list-imgtxt">
  <div id="contentleft" class="layui-col-md9">
	<style>
	.media-body img{
		display: block;max-width: 100%;height: auto;margin-top: 10px;
	}
	</style>
	<div class="panel-body layadmin-homepage-shadow">
		<?php
		$authorRes = $DB->query("SELECT email FROM ".DB_PREFIX."user WHERE uid=".$author);
		$authorRow = $DB->fetch_array($authorRes);
		$host = 'https://secure.gravatar.com';
		$url = '/avatar/';
		$size = '50';
		$rating = 'g';
		$hash = md5(strtolower($authorRow["email"]));
		$avatar = $host . $url . $hash . '?s=' . $size . '&r=' . $rating . '&d=mm';
		?>
		<a href="<?=Url::author($author);?>" title="<?=$authorRow["email"];?>" class="media-left">
		  <img src="<?=$avatar;?>" height="46px" width="46px">
		</a>
		<div class="media-body">
		  <div class="pad-btm">
			<p class="fontColor"><?php topflg($top); ?><?php echo $log_title; ?></p>
			<p class="min-font">
			  <span class="layui-breadcrumb" lay-separator="-">
				<?php blog_sort($logid); ?> 
				<?php blog_author($author); ?>
				<a href="javascript:;"><?php echo date('Y-n-j', $date); ?></a>
				<?php editflg($logid,$author); ?>
				<?php blog_tag($logid); ?>
			  </span>
			</p>         
		  </div>
		  <?php echo unCompress(formatContent($log_content));?>
		  <?php doAction('log_related', $logData); ?>
		  <div class="media">
			<div class="media-right">
			  <ul class="list-inline">
				<li>
				  <a href="javascript:;" class="slzanpd" data-slzanpd="<?php echo $logid;?>" title="喜欢这篇文章就赞一个吧！">
					<i class="layui-icon layui-icon-praise"></i>
					<span><?php echo(isset($slzan)?$slzan:getnum($logid));?></span>
				  </a>
				</li>
				<li>
					<a href="javascript:;">
					  <i class="layui-icon layui-icon-reply-fill"></i>
					  <span><?php echo $comnum; ?></span>
					</a>
				</li>
				<li>
					<a href="javascript:;">
					  <i class="layui-icon layui-icon-fire"></i>
					  <span><?php echo $views; ?></span>
					</a>
				</li>
			  </ul>
			</div>
		  </div>
		  <div class="media-list">
			<?php neighbor_log($neighborLog); ?>
		  </div>
		  <div class="media-list">
			<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
			<?php blog_comments($comments); ?>
		  </div>
		</div>
	</div>
  </div><!--end #contentleft-->
  <?php include View::getView('side');?>
</div>
<?php include View::getView('footer');?>