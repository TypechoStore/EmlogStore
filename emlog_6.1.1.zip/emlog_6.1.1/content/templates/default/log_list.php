<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content" class="layui-row layui-col-space20 layadmin-homepage-list-imgtxt">
  <div id="contentleft" class="layui-col-md9">
	<?php doAction('index_loglist_top'); ?>
	<div class="grid-demo">
	  <?php 
		if (!empty($logs)){
		  foreach($logs as $value){
		  ?>
		  <div class="panel-body layadmin-homepage-shadow">
			<?php
			$authorRes = $DB->query("SELECT email FROM ".DB_PREFIX."user WHERE uid=".$value['author']);
			$authorRow = $DB->fetch_array($authorRes);
			$host = 'https://secure.gravatar.com';
			$url = '/avatar/';
			$size = '50';
			$rating = 'g';
			$hash = md5(strtolower($authorRow["email"]));
			$avatar = $host . $url . $hash . '?s=' . $size . '&r=' . $rating . '&d=mm';
			?>
			<a href="<?=Url::author($value['author']);?>" title="<?=$authorRow["email"];?>" class="media-left">
			  <img src="<?=$avatar;?>" height="46px" width="46px">
			</a>
			<div class="media-body">
			  <div class="pad-btm">
				<p class="fontColor">
					<?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?>
					<a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
				</p>
				<p class="min-font">
				  <span class="layui-breadcrumb" lay-separator="-">
					<?php blog_sort($value['logid']); ?> 
					<?php blog_author($value['author']); ?>
					<a href="javascript:;"><?php echo date('Y-n-j', $value['date']); ?></a>
					<?php editflg($value['logid'],$value['author']); ?>
					<?php blog_tag($value['logid']); ?>
				  </span>
				</p>         
			  </div>
			  <?php echo unCompress(formatExcerpt($value['log_description'], 140));?>
			  <img class="h-img" src="<?=getBlogImages($value['content'])[0];?>">
			  <div class="media">
				<div class="media-right">
				  <ul class="list-inline">
					<li>
					  <a href="javascript:;" class="slzanpd" data-slzanpd="<?php echo $value['gid'];?>" title="喜欢这篇文章就赞一个吧！">
						<i class="layui-icon layui-icon-praise"></i>
						<span><?php echo(isset($value['slzan'])?$value['slzan']:getnum($value['gid']));?></span>
					  </a>
					</li>
					<li>
						<a href="<?php echo $value['log_url']; ?>#comments">
						  <i class="layui-icon layui-icon-reply-fill"></i>
						  <span><?php echo $value['comnum']; ?></span>
						</a>
					</li>
					<li>
						<a href="<?php echo $value['log_url']; ?>">
						  <i class="layui-icon layui-icon-fire"></i>
						  <span><?php echo $value['views']; ?></span>
						</a>
					</li>
				  </ul>
				</div>
			  </div>
			</div>
		  </div>
		  <?php 
		  }
		  ?>
		  <center><div id="page"></div></center>
		  <?php
		}else{
	  ?>
		<div class="layui-fluid">
		  <div class="layadmin-tips">
			<i class="layui-icon" face>&#xe664;</i>
			<div class="layui-text" style="width:100%;">
			  <h2>
				未找到
			  </h2>
			  <p>抱歉，没有符合您查询条件的结果。</p>
			</div>
		  </div>
		</div>
	  <?php
		}
	  ?>
	</div>
  </div>
  <script>
  $(function(){
	layui.use(["laypage"], function(){
		var laypage = layui.laypage;
		laypage.render({
			elem: "page"
			,count: <?=$lognum;?>
			,limit: <?=Option::get('index_lognum');?>
			,curr:<?=$page;?>
			,layout: ["prev", "page", "next", "skip"]
			,jump: function(obj,first){
				if(!first){
				  location.href="<?=$pageurl;?>"+obj.curr;
				}
			}
		});
	});
  });
  </script>
  <?php include View::getView('side');?>
</div>
<?php include View::getView('footer');?>