<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div id="m" class="layui-row layui-col-space20 layadmin-homepage-list-imgtxt">
  <div id="mleft" class="layui-col-md12">
	<div class="grid-demo" style="padding: 20px;">
		<form class="layui-form" action="./index.php?action=savelog" method="post">
		<input placeholder="标题" class="layui-input" type="text" name="title" value="<?php echo $title; ?>" />
		<select name="sort" id="sort" lay-filter="sort">
			<?php
			$sorts[] = array('sid'=>-1, 'sortname'=>'选择分类...');
			foreach($sorts as $val):
			$flg = $val['sid'] == $sortid ? 'selected' : '';
			?>
			<option value="<?php echo $val['sid']; ?>" <?php echo $flg; ?>><?php echo $val['sortname']; ?></option>
			<?php endforeach; ?>
		</select>
		<textarea placeholder="内容" name="content" class="layui-textarea"><?php echo $content; ?></textarea>
		<textarea placeholder="摘要" name="excerpt" class="layui-textarea"><?php echo $excerpt; ?></textarea>
		<input placeholder="标签" class="layui-input" type="text" name="tag" value="<?php echo $tagStr; ?>" />
		<input type="hidden" name="gid" value=<?php echo $logid; ?> />
		<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
		<input type="hidden" name="author" value=<?php echo $author; ?> />
		<input name="date" type="hidden" value="<?php print !empty($date) ? date('Y-m-d H:i:s', $date) : ''; ?>" />
		<input type="submit" class="layui-btn layui-btn-primary layui-btn-fluid" value="发布文章" />
		</form>
	</div>
  </div>
</div>