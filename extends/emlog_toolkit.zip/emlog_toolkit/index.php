<?php
/*
Extend Name: emlog工具箱
Version: 1.6.3
Description: emlog工具箱，工具箱初始密码为emlog。
Author: 朦胧中的罪恶
ForEmlog: 6.1.1
Author URL: http://be-evil.org
Email:Colt.hawkins@gmail.com
*/
ob_start();

// 工具箱登录密码,默认为emlog, 采用sha1算法加密
// 图形修改请用浏览器访问emlog工具箱的使用"工具箱密码修改"功能修改
// 手动修改请将下面引号中的sha1码替换为您新密码的sha1码即可
$password = 'cff86098ab3525bfdeed6922c60d6f0fb1b067cc';






/* 程序代码开始 */

// 防止搜索引擎抓取
if (isSearchBot()) {
	header('HTTP/1.1 403 Forbidden');
	die;
}

session_start();


if (get_magic_quotes_gpc()) {
	$_GET = stripslashesDeep($_GET);
	$_POST = stripslashesDeep($_POST);
	$_COOKIE = stripslashesDeep($_COOKIE);
	$_REQUEST = stripslashesDeep($_REQUEST);
}

define('EMLOG_ROOT', dirname(__FILE__)."/../../");

$action = isset($_GET['action']) ? $_GET['action'] : 'index' ;
$todo = isset($_GET['todo']) ? $_GET['todo'] : '' ;
// 功能表
$actions = array (
	// 工具箱首页
	'index',
	// 显示emlog logo
	'logo',
	// 密码重置
	'resetpassword',
	// 文件权限检测
	'permissioncheck',
	// rss 导入
	'rssimport',
	// 执行SQL
	'sqlquery',
	// 更换域名
	'changedomain',
	// 时间调整
	'timeadjust',
	// 关闭插件
	'turnoffplugin',
	// 清除垃圾评论
	'cleanspamcomment',
	// 修复数据表
	'repairtables',
	// 修改密码
	'changepassword',
	// 退出登录
	'logout'
);


// 涉及到数据库操作的功能表
$dataOperateActions = array (
	'resetpassword',
	'rssimport',
	'sqlquery',
	'changedomain',
	'timeadjust',
	'cleanspamcomment',
	'repairtables',
	'turnoffplugin'
);

if (!in_array($action, $actions)) {
	error('未知的操作');
}
if ($action != 'logo') {
	// 用户登录认证
	if (!isset($_SESSION['pass']) || empty($_SESSION['pass']) || $_SESSION['pass'] != $password) {
		if (isPost()) {
			$loginPassword = isset($_POST['password']) ? sha1(trim($_POST['password'])) : error('密码错误！');
			if ($loginPassword != $password) {
				error('密码错误！');
			}
			header('location:'. $_SERVER['PHP_SELF']);
			$_SESSION['version'] = intval($_POST['version']);
			$_SESSION['pass'] = $loginPassword;
			ob_flush();
			exit(0);
		} else {
			htmlHeader('用户登录 - emlog工具箱');
			?>
			<form method="post"> 
				<div class="b">
					<p class="title2">工具箱用户登录</p>
					<li>请输入工具箱登录密码</li>
					<li>
						<input type="text" name="password" size="password"/>
					</li>
					<li>
						请选择您使用的emlog版本:<br>
						<select name="version">
							<option value="6">5.0</option>
							<option value="5">4.2</option>
							<option value="4">4.0-4.1</option>
							<option value="3">3.4-3.5</option>
						</select>
					</li>
					<li>
						<input type="submit" value="登录" />
					</li>
				</div>
			</form>
			<?php
			htmlFooter();
			ob_flush();
			exit(0);
		}
	}
}

// 根据功能载入数据库类
if (in_array($action, $dataOperateActions)) {
	if (file_exists(EMLOG_ROOT . '/config.php')) {
		include_once EMLOG_ROOT .'/config.php';
	} else {
		error('emlog配置文件config.php没有找到!');
	}
}

call_user_func($action, $todo);
ob_flush();


// 过滤xml中的非法字符
function strip_invalid_xml_chars2($in) { 
	$out = "";
	$length = strlen($in);
	for ( $i = 0; $i < $length; $i++) {
		$current = ord($in{$i});
		if ( ($current == 0x9) || ($current == 0xA) || ($current == 0xD) || (($current >= 0x20) && ($current <= 0xD7FF)) || (($current >= 0xE000) && ($current <= 0xFFFD)) || (($current >= 0x10000) && ($current <= 0x10FFFF))) {
			$out .= chr($current);
		} else {
			$out .= " ";
		}
	}
	return $out;
}

function cleanspamcomment() {
	if (isPost()) {
		$db = MySql::getInstance();
		$clean_type = isset($_POST['clean_type']) ? intval($_POST['clean_type']) : 1;
		$use_id = isset($_POST['use_id']) ? intval($_POST['use_id']) : 0;
		$start_id = isset($_POST['start_id']) ? intval($_POST['start_id']) : 0;
		$end_id = isset($_POST['end_id']) ? intval($_POST['end_id']) : 0;
		$conditions = ' hide = \''. ($clean_type == 1 ? 'y' : 'n').'\'';
		$include_posters = isset($_POST['include_posters']) ? intval($_POST['include_posters']) : 0;
		$include_ips = isset($_POST['include_ips']) ? intval($_POST['include_ips']) : 0;
		$include_emails = isset($_POST['include_emails']) ? intval($_POST['include_emails']) : 0;
		$include_urls = isset($_POST['include_urls']) ? intval($_POST['include_urls']) : 0;
		
		$conditions = '';
		if ($include_posters) {
			$posters = isset($_POST['posters']) ? $_POST['posters'] : '';
			if ($posters) {
				$posters = explode(chr(10), $posters);
				foreach ($posters as $data) {
					$data = addslashes($data);
					if ($conditions)
						$conditions .= " OR poster = '$data' ";
					else
						$conditions .= " poster = '$data' ";
				}
			}
		}
		
		if ($include_ips) {
			$ips = isset($_POST['ips']) ? $_POST['ips'] : '';
			if ($ips) {
				$ips = explode(chr(10), $ips);
				foreach ($ips as $data) {
					$data = addslashes($data);
					if ($conditions)
						$conditions .= " OR ip = '$data' ";
					else
						$conditions .= " ip = '$data' ";
				}
			}
		}


		if ($include_emails) {
			$emails = isset($_POST['emails']) ? $_POST['emails'] : '';
			if ($emails) {
				$emails = explode(chr(10), $emails);
				foreach ($emails as $data) {
					$data = addslashes($data);
					if ($conditions)
						$conditions .= " OR mail = '$data' ";
					else
						$conditions .= " mail = '$data' ";
				}
			}
		}

		if ($include_urls) {
			$urls = isset($_POST['urls']) ? $_POST['urls'] : '';
			if ($urls) {
				$urls = explode(chr(10), $urls);
				foreach ($urls as $data) {
					$data = addslashes($data);
					if ($conditions)
						$conditions .= " OR url = '$data' ";
					else
						$conditions .= " url = '$data' ";
				}
			}
		}
		
		if ($use_id && $start_id > 0 && $end_id > 0) {
			if ($start_id > $end_id) {
				$tmp = $end_id;
				$end_id = $start_id;
				$start_id = $end_id;
			}
			if ($conditions)
				$conditions .= ' AND cid >'. $start_id .' AND cid < '. $end_id;
			else
				$conditions .= ' cid >'. $start_id .' AND cid < '. $end_id;
		}
		
		$sql = 'DELETE from '.DB_PREFIX.'comment WHERE '. $conditions;
		$db->query($sql);
		success('评论清理成功！');
	} else {
		htmlHeader('清除垃圾评论 - emlog工具箱');
		?>
		<form method="post" action="?action=cleanspamcomment"> 
			<div class="b">
				<p class="title2">清除垃圾评论</p>
			</div>
			<li><font color="red"><b>请注意：清理前请务必备份您的博客数据库！</b></font></li>
			<li>清除未审核的评论<input type="radio" name="clean_type" value="1" checked />&nbsp;清除已审核的评论<input type="radio" name="clean_type" value="0" /></li>
			<li><input type="checkbox" name="include_posters" value="1" onclick="display('posters', this)"	/>清除包含指定用户名的评论</li>
			<li id="posters" style="display:none;">
			每个用户名占一行：<br>
			<textarea rows="10" cols="40" name="posters"></textarea>
			</li>
			<li><input type="checkbox" name="include_ips" value="1" onclick="display('ips', this)"	/>清除包含指定IP地址的评论</li>
			<li id="ips" style="display:none;">
			每个IP地址占一行：<br>
			<textarea rows="10" cols="40" name="ips"></textarea>
			</li>
			<li><input type="checkbox" name="include_emails" value="1" onclick="display('emails', this)"	/>清除包含指定email地址的评论</li>
			<li id="emails" style="display:none;">
			每个email地址占一行：<br>
			<textarea rows="10" cols="40" name="emails"></textarea>
			</li>
			<li><input type="checkbox" name="include_urls" value="1" onclick="display('urls', this)"	/>清除包含指定主页地址的评论</li>
			<li id="urls" style="display:none;">
			每个主页地址占一行：<br>
			<textarea rows="10" cols="40" name="urls"></textarea>
			</li>
			<li><input type="checkbox" name="use_id" value="1" />只清理指定评论id区间的评论：</li>
			<li>开始id:&nbsp;<input type="text" size="5" name="start_id" /> - 结束id:&nbsp;<input type="text" name="end_id" size="5" />&nbsp;
			<a href="javascript:;" onclick="document.getElementById('find_id').style.display = 'block';this.onclick =function(){};">如何查找开始id和结束id?</a></li> 
			<li id="find_id" style="display:none;">
				请访问后台评论管理页面，直接点击<b>时间最新</b>的一个垃圾评论查看内容，点开后，
				您就可以在浏览器地址栏的url中看到类似http://xxx/admin/comment.php?action=reply_comment&cid=1158这样的地址，
				请记住cid=后面的号码，这个就是<b>结束id</b>。
				然后请回到留言页面向前翻页去寻找<b>时间最早</b>的那个垃圾评论的id，该ID为<b>开始id</b>.两个id号都找到后，请在上面填写您找到的开始id和结束id进行清理。
				请注意本功能也会清除掉两个id区间中的非垃圾留言，所以建议您将不需要删除的评论设置为审核（选择清除未审核的评论时）或非审核状态（选择清除已审核的评论时）以避免被程序清除.</li>
			<li>
				<input type="submit" value="开始清除" />
			</li>
		</form>
		<script type="text/javascript">
		function display(id, checkbox) {
			var ele = document.getElementById(id);
			if (checkbox.checked) {
				ele.style.display = 'block';
			} else {
				ele.style.display = 'none';
			}
		}
		</script>
		<?php
	}
}

// 退出登录
function logout() {
	unset($_SESSION['pass']);
	header('Location:'. $_SERVER['PHP_SELF']);
	ob_flush();
	die();
}

// 修改密码
function changepassword() {
	if (isPost()) {
		$password = isset($_POST['password']) ? trim($_POST['password']) : error('清填写新密码！');
		$password2 = isset($_POST['password2']) ? trim($_POST['password2']) : error('新密码不匹配！');
		if ($password == $password2 && preg_match('/^\w+$/', $password)) {
			if (is_writable(__FILE__)) {
				$_SESSION['pass'] = sha1($password);
				$appContent = file_get_contents(__FILE__);
				$appContent = preg_replace_callback('/\$password\s*=\s*\'(.+?)\';/', 'changePass', $appContent);
				// 更新密码并进入登录状态
				file_put_contents(__FILE__, $appContent);
				header('location:'. $_SERVER['PHP_SELF']);
				success('密码修改成功！');
			} else {
				error('emlog工具箱文件不可写！无法更新工具箱密码');
			}
		} else {
			error('两个输入的密码不匹配或者密码格式不符合要求!');
		}
	} else {
		htmlHeader('密码更新 - emlog工具箱');
		$is_writable = is_writable(__FILE__);
		?>
		<form method="post" action="?action=changepassword"> 
			<div class="b">
				<p class="title2">工具箱密码更新</p>
				<li>您可以在这里直接输入新密码，也可以修改emlog工具箱的程序文件来修改密码.</li>
				<li>请注意：在这里修改工具箱密码需要您给与本程序文件写入权限.<br>
				当前程序文件写入权限状态为：<?php echo is_writable(__FILE__) ? '<font color="green">可写入</font>' : '<font color="red">不可写入</font>'; ?> </li>
				<li>请输入新的登录密码(密码只能由字母、数字构成)</li>
				<li>
					<input type="text" name="password" size="password" <?php !$is_writable && print 'disabled' ?>/>
				</li>
				<li>新密码确认</li>
				<li>
					<input type="text" name="password2" size="password2" <?php !$is_writable && print 'disabled' ?>/>
				</li>
				<li>
					<input type="submit" value="更新密码" <?php !$is_writable && print 'disabled' ?>/>
				</li>
			</div>
		</form>
		<?php
		htmlFooter();
	}
}

function repairtables() {
	if (isPost()) {
		$db = MySql::getInstance();
		$query = $db->query('SHOW TABLES LIKE \'' . DB_PREFIX .'%\'');
		while ($table = $db->fetch_array($query)) {
			$sql = 'REPAIR TABLE `' . $table[0] .'`';
			$db->query('REPAIR TABLE `' . $table[0] .'`');
		}
		success('所有数据表修复完成！');
	} else {
		htmlHeader('数据表修复 - emlog工具箱');
		?>
		<form method="post" action="?action=repairtables">
			<div class="b">
				<p class="title2">修复数据表</p>
				<li>
					如果您的博客访问出现SQL错误提示，内容有"try to repair it"字样，说明您的数据库表需要修复<br />
					本功能可以一键修复emlog数据库中所有出错的数据表,免除复杂的数据库修复操作
				</li>
				<li>
					<input type="submit" value="点击自动修复所有出现问题的表" />
				</li>
			</div>
		</form>
		<?php
		htmlFooter();		
	}
}

function turnoffplugin() {
	if (isPost()) {
		$db = MySql::getInstance();
		$sql = 'UPDATE '. DB_PREFIX .'options SET option_value = \'a:0:{}\' WHERE option_name = \'active_plugins\'';
		$db->query($sql);
		$optionsCacheFile = '';
		if ($_SESSION['version'] >= 5) {
			$optionsCacheFile = EMLOG_ROOT.'/content/cache/options.php';
		}
		if ($_SESSION['version'] < 5) {
			$optionsCacheFile = EMLOG_ROOT.'/content/cache/options';
		}
		
		if (is_file($optionsCacheFile) && is_writable($optionsCacheFile)) {
			unlink($optionsCacheFile);
			success('所有插件已关闭！');
		} else {
			error("缓存文件$optionsCacheFile没有写入权限！");
		}
	} else {
		htmlHeader('关闭所有插件 - emlog工具箱');
		?>
		<form method="post"> 
			<div class="b">
				<p class="title2">关闭所有插件</p>
				<li>如果您的emlog在安装或使用插件时出现异常，这里可以一次关闭emlog的所有插件，让博客运行于无插件状态。</li>
				<li>
					<input type="submit" value="关闭所有启用中的插件" />
				</li>
			</div>
		</form>
		<?php
		htmlFooter();
	}
}

function timeadjust() {
	if (isPost()) {
		$intervaldecrease = isset($_POST['intervaldecrease']) ? intval($_POST['intervaldecrease']) : 0;
		$intervaladd = isset($_POST['intervaladd']) ? intval($_POST['intervaladd']) : 0;
		$timeinterval = 0;
		if (empty($intervaldecrease) && empty($intervaladd)) {
			error('请填写一个时间间隔');
		} elseif (!empty($intervaldecrease) && $intervaldecrease > 0) {
			$timeinterval = $intervaldecrease * -3600;
		} elseif (!empty($intervaladd) && $intervaladd > 0) {
			$timeinterval = $intervaladd * 3600;
		} else {
			error('时间调整间隔必须大于0!');
		}
		$db = MySql::getInstance();
		$sql = 'UPDATE '. DB_PREFIX ."attachment SET addtime = addtime + $timeinterval";
		$db->query($sql);
		$sql = 'UPDATE '. DB_PREFIX ."blog SET date = date + $timeinterval";
		$db->query($sql);
		$sql = 'UPDATE '. DB_PREFIX ."comment SET date = date + $timeinterval";
		$db->query($sql);
		$sql = 'UPDATE '. DB_PREFIX ."trackback SET date = date + $timeinterval";
		$db->query($sql);
		$sql = 'UPDATE '. DB_PREFIX ."twitter SET date = date + $timeinterval";
		$db->query($sql);
		success('时间调整完成!');
	} else {
		htmlHeader('Blog时间调整 - emlog工具箱');
		?>
		<form method="post"> 
		<div class="b">
			<p class="title2">Blog时间调整 - <a href="<?php echo $_SERVER['PHP_SELF']?>">&lt;返回首页</a></p>
			<li>
				本功能用于调整emlog中所有记录(日志,评论,碎语,附件)的时间<br>
				如果你的blog时间出现偏差可以使用本功能来快速调整
			</li>
			<li>
				我的Blog显示的时间多了<input type="text" name="intervaldecrease" size="1"/>小时，或者少了<input type="text" name="intervaladd" size="1"/>小时
			</li>
			<li>
				<input type="submit" value="调整时间" />
			</li>
		</div>
		</form>
		<?php
		htmlFooter();
	}	
}

function rssimport() {

	if (isPost()) {
		// 增加程序的最大执行时间
		ini_set('max_execution_time','600');
		$blogtype = $_POST['blogtype'];
		$rssurl = $_POST['rssurl'];
		$items = array();
		$rss = new rss_php;
		if (isset($_FILES['rssfile'])) {
			// 上传时出现错误
			if ($_FILES['rssfile']['error'] != UPLOAD_ERR_OK) {
				switch ($_FILES['rssfile']['error']) {
					case UPLOAD_ERR_INI_SIZE:
						error('您上传xml文件的体积超过了php.ini规定的大小，文件上传失败!');
					break;
					case UPLOAD_ERR_FORM_SIZE:
						
					break;
					case UPLOAD_ERR_CANT_WRITE:
						error('服务器php上传文件零时目录不可写，文件上传失败！');
					break;
					case UPLOAD_ERR_NO_FILE :
						error('没有找到任何上传的文件，文件上传失败！');
					break;
					case UPLOAD_ERR_NO_TMP_DIR:
						error('服务器没有配置php文件上传临时目录，文件上传失败！');
					break;
				}
			}
			$xmlcontents = file_get_contents($_FILES['rssfile']['tmp_name']);
			if (empty($xmlcontents)) {
				error('上传的内容为空');
			}
			$xmlcontents = strip_invalid_xml_chars2($xmlcontents);
			$rss->loadRSS($xmlcontents);
			$items = $rss->getItems();
			if (empty($items)) {
				error('RSS数据未读取到!');
			}
		} elseif (!empty($rssurl)) {
			if (!preg_match('/https?:\/\/([\w-]+\.)+[\w-]+(\/[\w\-.\/?%&=]*)?/i', $rssurl)) {
				error('RSS地址格式不正确');
			}			
			$rss->loadFromUrl($rssurl);
			$items = $rss->getItems();
			if (empty($items)) {
				error('RSS数据未读取到!');
			}
		}
		$db = MySql::getInstance(); 
		// 分类缓存   
		$categorycache = array();
		$query = $db->query('SELECT sid,sortname FROM ' . DB_PREFIX .'sort');
		while ($row = $db->fetch_array($query)) {
			$categorycache[$row['sid']] = $row['sortname'];
		}
		// 用户缓存
		$usercache = array();
		$query = $db->query('SELECT uid,username FROM ' . DB_PREFIX .'user');
		while ($row = $db->fetch_array($query)) {
			$usercache[$row['uid']] = $row['username'];
		}
		
		$foreignblogapp = array('wordpress','Movable Type', 'Typecho');
		
		$sql = $title = $content = $excerpt = $sortid = $date = $author = '';
		$importcount = 0;
		foreach ($items as $key => $item) {
			// 标题
			if (isset($item['title'])) {
				$title = addslashes($item['title']);
			}
			// 内容
			if (isset($item['description'])) {
				$content = addslashes($item['description']);
			}
			// 针对 wordpress RSS的处理
			if (in_array($blogtype, $foreignblogapp)) {
				// 摘要
				if (isset($item['description'])) {
					$excerpt = addslashes($item['description']);
				}
				// 内容
				if (isset($item['content:encoded'])) {
					$content = addslashes($item['content:encoded']);
				}
			}
			
			// 分类
			$sortid = -1;
			if (isset($item['category'])) {
				// 多个分类默认取第一个
				if (is_array($item['category'])) {
					$category = $item['category'][0];
				}
				
				if (is_string($item['category'])) {
					$category = $item['category'];
				}
				// 判断该分类是否已经添加了
				if (in_array($category, $categorycache)) {
					$sortid = array_search($category, $categorycache);
					if (empty($sortid)) {
					   $sortid = -1; 
					}
				} else {
					// 自动增加分类
					$sql = 'INSERT INTO '. DB_PREFIX ."sort (sortname,taxis) VALUES ('$category',0)";
					$db->query($sql);
					$tmpid = (string) $db->insert_id();
					// 增加到分类缓存中
					$categorycache[$tmpid] = $category;
					$sortid = $tmpid;
				}
			}
			// 发布时间
			if (isset($item['pubDate'])) {
			   $date = strtotime($item['pubDate']); 
			}
			// 发布人
			if (isset($item['author'])) {
				if (in_array($item['author'], $usercache)) {
					$author = array_search($item['author'], $usercache);
				} else {
					$useid = array_keys($usercache);
					$author = $useid[0];
				}
			} else {
				$useid = array_keys($usercache);
				$author = $useid[0];
			}
			$sql = 'INSERT INTO '. DB_PREFIX . "blog (title, date, content, excerpt, author, sortid, type, views, comnum, tbcount, attnum, top, hide, allow_remark, allow_tb, password) VALUES ('$title', '$date', '$content', '$excerpt', $author, $sortid,'blog',0,0,0,0,'n','n','y','y','')";
			$db->query($sql);
			$importcount++;
		}
		success("$importcount 条日志被成功导入!<br>请到emlog后台更新缓存!");
	} else {
		htmlHeader('RSS数据导入 - emlog工具箱');
		?>
		<form method="post" enctype="multipart/form-data"> 
		<div class="b">
			<p class="title2">RSS数据导入 - <a href="<?php echo $_SERVER['PHP_SELF']?>">&lt;返回首页</a></p>
			<li>
				博客RSS地址：<input type="text" name="rssurl" size="50"/>
			</li>
			<li>
				上传博客RSS-XML文件：<input type="file" name="rssfile"/><br><font color="red">服务器文件上传大小限制:<?php echo ini_get('upload_max_filesize') ?></font>
			</li>
			<li>
				博客类型:<select name="blogtype">
							<option value="wordpress">wordpress</option>
							<option value="Movable Type">Movable Type</option>
							<option value="Typecho">Typecho</option>
							<option value="other">其他</option>
						 </select>
			</li>
			<li>
				<input type="submit" value="开始导入" />(请在导入前务必备份博客的数据库)
			</li>
			<li>
				部分blog程序RSS输出设置说明<br>
				1. <b>wordpress</b><br>
				后台 - 阅读 - Feeds<br>
				Feed同步最新 -> 设定数值大于当前blog日志总数即可<br>
				Feed中每篇文章，显示 ->  全部文字<br>
	
				2. <b>bo-blog</b><br>
				后台 - 常规管理 - 参数设置 - RSS设置<br>
				RSS最大输出日志数 -> 设定数值大于当前blog日志总数即可<br>
				RSS输出->    RSS中输出全文<br>
	
				3. <b>typecho</b><br>
				编辑 ./var/Widget/Archive.php 第48行 $this->parameter->pageSize = 10; 将10增加大为超过当前blog日志总数即可<br>
	
				4. <b>sablog</b><br>
				系统设置 - RSS 订阅设置 - RSS 订阅文章数量 -> 设定数值大于当前blog日志总数即可<br>	
			</li>
		</div>
		</form>
		<?php
		htmlFooter();
	}
}

function changedomain() {
	if (isPost()) {
		$olddomain = trim($_POST['olddomain']);
		$newdomain = trim($_POST['newdomain']);
		if (!preg_match('/https?:\/\/([\w-]+\.)+[\w-]+(\/[\w\-.\/?%&=]*)?/i', $olddomain))
			error('原博客地址格式不正确');
		if (!preg_match('/https?:\/\/([\w-]+\.)+[\w-]+(\/[\w\-.\/?%&=]*)?/i', $newdomain))
			error('当前博客地址格式不正确');
		
		// 去除地址最后的 /
		if (substr($olddomain, strlen($olddomain) - 1, 1) == '/')
			$olddomain = strtolower(substr($olddomain, 0, strlen($olddomain) - 1));
		if (substr($newdomain, strlen($newdomain) - 1, 1) == '/')
			$newdomain = strtolower(substr($newdomain, 0, strlen($newdomain) - 1));        
		$sql = 'UPDATE '. DB_PREFIX . "blog SET content = replace(content,'$olddomain','$newdomain'), excerpt = replace(excerpt,'$olddomain','$newdomain')";
		$db = MySql::getInstance();
		$db->query($sql);
		$sql = 'UPDATE '. DB_PREFIX . "options SET option_value = '$newdomain' WHERE option_name = 'blogurl'";
		$db->query($sql);
		success('博客地址更换成功!');
	} else {
		htmlHeader('博客日志链接域名更换 - emlog工具箱');
		?>
		<form method="post"> 
		<div class="b">
			<p class="title2">博客日志链接域名更换 - <a href="<?php echo $_SERVER['PHP_SELF']?>">&lt;返回首页</a></p>
			<li>
				原Blog地址：<input type="text" name="olddomain" /><br>
				(请按照http://www.emlog.net格式填写，如果你原地址是在二级目录，那么在url中请包含二级目录)
			</li>
			<li>
				当前Blog地址：<input type="text" name="newdomain" />
			</li>
			<li>
				<input type="submit" value="开始更换" />(请在更换前务必备份blog的数据库)
			</li>
		</div>
		</form>
		<?php
		htmlFooter();
	}
}

function sqlquery() {
	if (isPost()) {
		$sql = $_POST['sql'];
		if (empty($sql))
			error('SQL语句不能为空!');
		MySql::getInstance()->query($sql);
		success('SQL语句运行成功!');
	} else {
		htmlHeader('运行SQL语句 - emlog工具箱');
		?> 
		<form method="post"> 
		<div class="b">
			<p class="title2">运行SQL语句 - <a href="<?php echo $_SERVER['PHP_SELF']?>">&lt;返回首页</a></p>
			<textarea cols="70" rows="10" name="sql"></textarea>
			<input type="submit" value="提交语句" /> (请注意:每次只能执行一条语句)
		</div>
		</form>
		<?php
		htmlFooter();
	}
}


function permissioncheck() {
	htmlHeader('文件权限检测 - emlog工具箱');
	$safe_mode = ini_get('safe_mode');
	?>
	<div class="b">
		<p class="title2">文件权限检测 - <a href="<?php echo $_SERVER['PHP_SELF']?>">&lt;返回首页</a></p>
		<?php if ($safe_mode):?>
		<p><font color="red">提示：您当前主机PHP开启了安全模式(<a href="http://cn.php.net/manual/zh/features.safe-mode.functions.php" target="_black">Safe Mode</a>)，在该模式下emlog相关功能受到了限制，即使下列目录可写emlog也无法上传文件！</font></p>
		<?php endif;?>
		<li>./config.php <?php echo is_writable(EMLOG_ROOT . '/config.php') ? '<font color="green">可写</font>' : '<font color="red">不可写</font>'?></li>
		<li>./content/cache <?php echo is_writable(EMLOG_ROOT . '/content/cache') ? '<font color="green">可写</font>' : '<font color="red">不可写</font>'?></li>
		<li>./content/uploadfile <?php echo is_writable(EMLOG_ROOT . '/content/uploadfile') ? '<font color="green">可写</font>' : '<font color="red">不可写</font>'?></li>
		<li>./content/backup <?php echo is_writable(EMLOG_ROOT . '/content/backup') ? '<font color="green">可写</font>' : '<font color="red">不可写</font>'?></li>
	</div>
	<?php
	htmlFooter();
}

function resetpassword() {
	if (isPost()) {
		$db = MySql::getInstance();
		$username = isset($_POST['username']) ? addslashes(trim($_POST['username'])) : '';
		$password = isset($_POST['password']) ? addslashes(trim($_POST['password'])) : '';
		$password2 = isset($_POST['password2']) ? addslashes(trim($_POST['password2'])) : '';
		if (empty($username)) {
			error('用户名不能为空');
		} else {
			$user = $db->once_fetch_array('SELECT * FROM '. DB_PREFIX .'user WHERE username = \''. $username .'\'');
			if (empty($user))
				error('您输入用户不存在!');
		}
		
		if (preg_match('/^\w{6,20}$/', $password) && $password == $password2) {
			if ($_SESSION['version'] >= 4)
				include EMLOG_ROOT . '/include/lib/passwordhash.php';
			else
				include EMLOG_ROOT . '/lib/class.phpass.php';
			// 实例化密码加密对象
			$PHPASS = new PasswordHash(8, true);
			$newpass = $PHPASS->HashPassword($password);
			$sql = "UPDATE ". DB_PREFIX ."user SET password = '$newpass' WHERE username = '$username' ";
			$db->query($sql);
			success('密码更新成功');
		} else {
			error('您输入的新密码不符合系统要求!');
		}
	} else {
		htmlHeader('管理员密码重设 - emlog工具箱 ');
		?>
		<form method="post">
		<div class="b">
			<p class="title2">管理员密码重设  - <a href="<?php echo $_SERVER['PHP_SELF']?>">&lt;返回首页</a></p>
			<li>
				用户名：<input type="text" name="username" />（该用户名必须存在）
			</li>
			<li>
				新密码：<input type="password" name="password" />
			</li>
			<li>
				新密码确认：<input type="password" name="password2" />
			</li>
			<li>
				<input type="submit" value="重设密码" />
			</li>
		</div>
		</form>
		<?php
		htmlFooter();
	}
}


function index($todo) {
	htmlHeader('emlog工具箱');
	if ($todo == ''):
	?>
	<div class="b">
	<p class="title2">工具列表</p>
		<li>
			<a href='<?php echo $_SERVER['PHP_SELF']?>?action=permissioncheck'>&middot; Blog文件权限检测</a>
		</li>
		<li>
			<a href='<?php echo $_SERVER['PHP_SELF']?>?action=resetpassword'>&middot; 重置管理员密码</a>
		</li>
		<li>
			<a href='<?php echo $_SERVER['PHP_SELF']?>?action=sqlquery'>&middot; 运行SQL语句</a>
		</li>
		<li>
			<a href='<?php echo $_SERVER['PHP_SELF']?>?action=changedomain'>&middot; Blog域名更换</a>
		</li>
		<li>
			<a href='javascript:void("<?php echo $_SERVER['PHP_SELF']?>?action=rssimport");'>&middot; RSS数据导入</a>
		</li>
		<li>
			<a href='javascript:void("<?php echo $_SERVER['PHP_SELF']?>?action=timeadjust");'>&middot; Blog时间调整</a>
		</li>
		<li>
			<a href='<?php echo $_SERVER['PHP_SELF']?>?action=turnoffplugin'>&middot; 关闭所有插件</a>
		</li>
		<li>
			<a href='javascript:void("<?php echo $_SERVER['PHP_SELF']?>?action=cleanspamcomment");'>&middot; 清除垃圾评论</a>
		</li>
		<li>
			<a href='<?php echo $_SERVER['PHP_SELF']?>?action=repairtables'>&middot; 修复数据表</a>
		</li>
		<li>
			<a href='<?php echo $_SERVER['PHP_SELF']?>?action=changepassword'>&middot; 工具箱密码修改</a>
		</li>
		<li>
			<a href='<?php echo $_SERVER['PHP_SELF']?>?action=logout'>&middot; 退出登录</a>
		</li>
	</div>
	<?php
	endif;
	htmlFooter();
}

/** 核心函数区 **/

function logo() {
	Header('Content-type: image/png');
	echo base64_decode('iVBORw0KGgoAAAANSUhEUgAAALwAAACHCAIAAAAjlqSSAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAR/dJREFUeNrsvWewZdd1JrbDiTe93DkBHYHuRiQIgAgEEwiRNANMWdSQnJkyR/aU5ZLsKs/8sGvK/KGyXVaNqlQjjSiprDGHA5qloYYUSZAECQEEiJy6gQbQDaADOr0OL9584t5ea6/7dh/cF7obQ3Aa0j1sPtx77ol7r/2tb4W9Ntdas8E22C5n4wOhGWwDoRlsA6EZbAOhGWwDoRlsA6EZbINtIDSDbSA0g20gNINtIDSDbSA0g22wDYRmsA2EZrANhGawDYRmsA2E5te2JSwrfHPMXwX/F/A/eFzzXbDY/Nc1XzsM3kFXlaAzczpeMldqekM4AX6JzU+w1ZhmCafrwGFwTTxP4z+dM8FxHx4r4JZ4bhu+dXUZfvB1C3/SCn9TFfO5i8dKeE4pzWNGgtFzSnz6DC+kst5Tc4dxNzf3og2ekPP3n9CI98uDqoWWznOW5qm+0PKccUFNz80X0+P55V4fLsixB7mi7pT4JUtJnJiivTTAUGLUAGmupI2GpdMwnVTC4UoPKLq9zgWx0GFPktKUCUdI6Os6dKTOR+BwxVECHBaZI/DI3AwNqdiCZGUsayyMGZ/JEORFvVOAVJJ6gE+cRzLMMlXhBtuk384FXN8VLLBCzBce2SAHoyPxo1OUXAsokrBTsx7ycXeANO/pttBRSqG4wNO7LkoMdYqQFhI4u2zQTw2qWMjxPA+hJkmggTzHQEuEUuhKlJh/4DTwykMa6junyy6wDsNs+DwCABuBUZqbR85lF/YIXQIIcVVq2AGQBgbkxqgZcwWOKEJjPzBoEjHRYz2MhcQqiEshPgFriZCCaMSOyBnGs7rHWf3I3N99e2TnTrb3fuZt7nB8npJ50Iy5BB7InADAtL22CwzGMJoFoDSHSThDL0g/3FiDFhTvO6Fx3jecBoVBEJZgB3GkxriTI8dAOdKm/8W7p5Z4HidiI4h+A3+aPXDgxLMPVqPJ06dP79nx6STr6HKND5DmitNAujdcleztyfHf6S47el7tPzX73Nn6q50kDku1Snls7/iX17Gbyvmu3qGOMZ80YI/ZIds5Gk5l+Iz/z2PGyQLyEVaE2zOvEGo6zPMS4YD4hbzLklPswPfy538xe3bS6UyNlNsRbLv+m+Ev/kvm7tEe3CVbUIqiBy6GdWnEL0YcSRspzxeoDJIfbYAUhdKPevjHBkjzXm2z0eyrR59/+9xTKjglym0Qmnqj47ntydcfuu2q8AOrdxHD7A2FdwEFQGLSVPkOcKT56enTz/xMv/ZwrXUuAM4bBEky5/v+22fPVg8elDfuGfhpriykSVlk7F5URgrxAJ6xPRW//OihL8Uqqqct4TopH9FSRPyE67o6VUOsevu6/3XP6FckW53ljEtEHA8HOqgXMG641C6H8Z4YTlMSvGfpKJbGxhtj7qISxiM28wx7/gds/w+azabya47jhM0ZUfbSqJk6PPc3zQQ7tvz219mazWBJGWJlmJOeAJHNjbWOlwWCpRMjuYKleR4Mad0zn5weZcMtNnzIHyDNr0CKTeumeepKV5iGbmfdN954o16va0eVaqU4S4UQ3SRxKy5YUY6UWZy99dZbO25NQDE4kiUaPXRgJ0un5xLs+fyQ9PQwqDdQQGK0zuIUhINJceL1g+1nf+ieemFd0gFcAXEAjVR2HNXpcMlBQOGm061p/7XX1oTDiY/qzjdCk+lKAhRXosIqcZHFncBBjhV1Yzcsz9cbw0M1PUCa93JDW0fnPur9PIXH49KLozwSbx6d2ndm9tTp1vNN/wfCc0Uw2mg0vEoHjslnhz536/+2zfnvJA5d9NsQ5xCJ43SAOMyyky8wr85GRlj5WsaqTHrIKlLmukymM2z25fzBP9KTB7P6pJQyCYfzDMRLuU7QZW4cxyh/Uo2pjsqy82wiDMM4w+ecSM+gT5oPK+6QN8hNuyA/DvoGeUtU6+FV8cS12/+rr7GxrYz7RVspMQLtDZDmV+T8VT1OIqVOU/jsB1KK8rUbr92xcesMG/3poUcanXbW6Xiel2UN+OsGAVg32zajl0UgtQXbFzpRSNlTAC89+WTn7IFqtVr64G9u3nWLV/XSNAXwSFP25lNPnX/6rzdFJ8bTbtnzAMbiBXWSZVmqWalU0iyL4laaxm61qtu63W47/tJNBzInMa6R4WgUrNVqbblhPavVClRfv1vaNRCa5SQm99GEFsaA4onA+FKcdxKntEmwTdDUI+zWcv6N1DmeiBaMZtVZx5OKG7iT+kXF5n02xnIX5c71M50hzQAr5dC/HT37neH03ESnkvzokfaPKt4Nt7vXXsumpqJ9L4/MHBvXuRv4yinPpVJnUahi33FSDYKVODLDNuq0S1yBALFuNOSqUrWa1usoVaKEmAHAosnSk61wCJBpXLRBdUZJVgrzoFoFBZYZdaaMAvaA8eQLGCO9gdD8So1vIJXokBEyDM24B0sa8R0oSNSOtJ+D0MDnPMuTRPujfo8UpUbrMENgQOTS9K19+6RSQFM6nY5jTO/D+/eLV16BPVk3FlkaloJGs+lL5jrCC0MnTfI811zDAalW8DmL47ASSicA7InNVpIX3P8KfUdk4nOgQXDf1DisXdeHu548eXLzLZ4uRBIYPdj7Nr/gihOaDBiBAibbhbHO0Ysr8lhL+AiswuUUrY74Ke4K4VRBlQhV11K2s0ol2I3+4MzvhXQkOmUZP52/9UB55qerctfpDuVtr1n1tI4384bIs2Q+AmWS+2HSbY4GEvs+h+4XYIEBRxFgeykF7BuuNeKCqdU9605IXwK/4XnimKhCy0ERdEVb6m45wRvPyrLv+eVoEoW+VE1mzh+BJ568w13jMWcokx6KjsZH08jCmXgfCs0V98wgMY5gDvBKnSsTScJ2NsEfjnYK/u12uwAwMNyTJIGhL80GexSGGHJ02KiFYV2vP/PMM4b6ZCxJZBCAmBESKIM99BnIDXzlZoMj4bNrNuAldKMiKiDRSZGh923M/IPrw1OhXSYFPAxsQIn2/+xn9Gu/GfL+JDZXnke4i3Hf2JkBCQjVBPo1VAczFTzZRpiZOZ08/uSrv9uJ5qqj5Va3E6sN0K9cH4Xxv3Ht3det/uoo+60ABrnKWTPtPvq/N155sJKeB7npRiW0xTwOHQldC3Kmc5RLoR07fIiBS40hcYdhJk2ercO/ToMBPzY+Xw7HA4PRXmHkKUliqp3pELVkKUvCLKe8n1jKhlvWq3ev+43/lk1cx8Rq5pbThbi6r1HQNUhyj8pdiMpyzMVJrE6IjT/JHyDNElLsmjgTIksvYI0SY0wq+Ntl3X379sFYB6MX2ANhDAgBfTh+/PgjTz9y4OiBDOxtgJyZmSNHjhB40NiAswhR4BTADwISlJ73fuTMz8+/8Ld/Gx85AvCijYSZ8IgmiwskRuU9ZEU5S+IB0lyW+QT4zzpegwgXDGcnrwFqdL235tkrDx//P+bm5lSGUhKJKS4SLlLjXKsiOwbeoTNZXjNc3v6JDV+M9h+ceeSJrY3meD4D/RFHmGsXV+BAx1MZz9GYVyrJRQOpkfaZ9kVubBzZNMPcN8/QMWZyCL8qE6rQnEiTiT1pipOn+NVk0vjmx0j6CYfjEY1cnXh57jCU0bb2Rnbdxu7+IltzPXNWMzlOSOLCVTmPep8vuB8X4vPG0dwbRc4AaRapJw3GETRW3MgajaSRGr+7kKzJmk8efHJmZgb4BOiaoqx7HqIF0RT4CT6cOXPmx7/4ca1Wu/3OOwFdYA90CTCYcqVCGEMwQ5BDDObXZHc4zvlz51787ndf//GPs1ZLKxOl59ZTbWK1+kpPC7wCo9xKs+w/Hrv9zNR5GMbDQ6s3jGwfGRk5fO7pY6dO8JIPqJBlZ6GV3bCUJoJx1Dgea3gYCsfPuWtIscZRulbfeO+We88+8Vbn1bfXB4fE6bk1/gadppFKgIboAFFEJaNwTa1zRAtnxsQcasBOlOnI2EmBzYR5G+wnoRymSrkaNi2HxzviHB6OtL3UZRsNrrQl70jWlnCqyctRqgwolXEXBCRzWbPbccsVz6ky4Q1ffTO77T42fBULNzPlx0yC+Ip8DoZO7IzZXJxy3jDoVWNXRlT8SvTTYD6LEAAMIDRABRpnXg+CoKFPlivlmU5zdHQUbBd064E9rOEvQoXiSkqwwl1AjlQhljho+uh6o/7LX/7yE1fdVl634/jfHVg1NJTOdQGW4IKAYV1Dhsg+cpz3FnSBVzmBD08HWOj5frvZabbn0uj140dmVl9/z/oPDouRdR6lfuorPd38Cow9gRjkvzz3B/tOfzv2JrENlQodTwqv3W6Hw6VGc7ZWNU62diV0wRZqQi+0nTHo+EzVHTcfMhqtEwunEkZe1ul0wjzcVtl5y9avdl54M3jsdTY/I4PJKnd1yysrWfIAurqpVIlkER82Pp55wK1yQjkxOLYbgcEM0OZalhJjN6GzOev4HWpGmQflCL3DHU8ZXtIAg1saYpvxEOhRLkNAEXj4wAN+lMq04/sua7dZWIo7+Vx10+jO270b72Ybr2fehOZjicDxLHs5xdBPGVOUp1wecJqlnknKHet2ABiAQJth6RMRAXbS7Xbhb7vdhZ8qlQr8JTYDvwL2wE/kcYE9cBbsBAsL9sBFpqenH3roIThl2yc/uX79em0cKrCfoy2j1K9ldgGIb7lcRtKtFMbVQWJAjUaRH4aw89ChQ/t+/ONTjz+eTk8b83uANJcBNGCG5BGff/nsw8+e+KOcny1V806j5SnX92pxrrLEK+k7dm/+9M0bP/zKa6/sm/pXWWkylbPSc7sZioiKqzggkXPkmYgwcRdNWpEjZql15XV3bbxj6ODOIz95Yl17bkS3mDodSDfVmaO5VLHr+2kUZqnU1QrIXE0LnisuYZRniYrAqlI+ihoXTpIkjk59CVJuvHgsVxIsqJrktSQFdYkuZrDKgiDPk47g6MsxISonZ8BvWCqU4Sj4bOcjXiqVxpsHYc/0+G3j9/wTdsvvmNYw+TrCzxZmY1QHfpqltxwD1DvW7Ni2bRuqhkaDmAd0Ifzdvn37J+78xJ6NeySTu3fv/tw9nwOajG8ihHXeoIgYDx5gCblhyD0Dp8/Ozj777LOg6T70xS9u2baNIIcMKIM4KjWghSa9QSkALboCbEG5XCqXMYRtIlBwGMEhXI2sMziF7kXQhXBi2MwKIxOuD6cPDQ2hzxqMuCBotVrMdQdIczlbanLofOToLRZP10/MtY52o5abZ9ArV22+1WPjgrloK8UddJRJP/LE/sl//8vX/z8+dlx488rYGtBhgAQw+tEeYZ7oSj8NcafIYp4kXgYG+c0TX6tNpjMPv7xuKh3vPl8GQOIKlIgsD7tOGM1HIIWZaEB3csxX5w3tNtlQKxxnYkRrDEFU4lZNR2WnE6ezqY7CsnC6eHfAKrgvpuYkCXe6qAQNH2GqwEjM3E0tK6it2mcBaVoJa4vRmdv+5933fjXz0avkmHdJjN3kqbY56788p7nyrCcNpigiYK4B7OXqodWrhtyEdUvkpmceWD0+c9M4cefmWKnEqyH8sHvd7vF1X3j06L+rt2dBMsgxg3hjbCsMBEnJM3QNy1CmcSoC2Ww2n3/7+dtHdtz1+c+rh1/ovrkP9BichZ4ew4rIlcx99OWAOMFlXe5ODE9s23Uz27CbVcZxJlRrjh092Dr4LIw9kLBOZ66GUXlBuomCWYSC+TK0CdWaEXG4ArAv3/F333XXAGkuUzWxGHQTz12aSxlnGA3G/DrWMr+6IFRO5mJe3vxjT/zVv73zrg+yXbtYeIeuOGdZfKzx6rOv/msl9gt2slQKmFPtxCzWDMOPop5ipLFEPQTdmXjzGH1ob/no9fevOnv12z9+onbi9e0l3Z0/BOJSWrO21U27cVSqjh9xtqZj115912c3XnWjYjzOQTd6ciEq6nXbrQOPTu77uXd+38ZoH15ZhKn2EozFC7qX0JHxHSu5IDyU6deLgXh+O9JHwmuv+9TvuDd+AaOz5leH0AWtNicxyRhXQvaN/PrXv36FOWkwHMwzSZOYTJ4l7ceE806SCOFI7rBIs9abZ994bfLIG+70dLjqejUcdpga8sNNG1nmnk6Tc2g9JcBhPeGi/4bpDkhOphwwYcAKQ+oqI2QzavzYwTO1zvgdt314tYpmjxwaqWJG8HSzBfIJxpt0gl13f3bLJ74wNLYxybgULhcm8m4bkWlvvDS2ujrcPC3mDyOJkR4TboaGoOxJBgfuaxIiFgap5j0fMQpZCtf1RnfdXr3jvpiNWKeRoCkvpi1y0xBygDRL2KWGnKNbBEakM2NEpowJKKasQ27aDDO4s5Q1H37xG//immgOXXMj66rXf4x96LeYv5WJ8STkL55+9Nj0T8+1fsbKJ3nYiNK0CxLl+0zFeZTUwiDrxsPhELBswLbK8FArybka/tCuz24VVx3+T0/zg6dv57zTbu//8D+9/Zb7eXkdSzUDS8lhiTOlMXvdpFmxClclwQPjj0GelfzFfz87uV/wpCQTnrRC7oC0qFyAZQbQAqMB/xp/D81Ih0vlqjMuYgzR/vO/YWvu6DghvHpF4fUjMzMrKESj+ABpllJP2Do41Q3j2xTO87CJzZ5UIRBJzDlXrPF6/c1nR6IWmDDtjB0/1zz71vmx4U1iYgPg1FAtGFqTKu9MvXOimzYdV3C3hhaKzkPPT7pdh4ssQncOzuCNwZYWgpdOH56TDXH3B+7Z6NfY22+7N9yw8bP/hDtjmAghzdQYyTLRnu1On546OTU/xVKnHAzBpeGxFJLd3D/5XHfmhMoTDyzqLBaYUCbBGgPVhNDClQEYg6K90GQehi7vYNC0s+p2d/3e1KS4upocg7KPePIB0izhbu/xc9NkRgVgk2EQp5ePrZnTi/2e+Mnxf//1SloP0qmQZ0LqTtploVfa+5vs5vvZ6CdYBXCre6T+8stHH5hpPec406ALWjLDdIj8DLx4JMcQLUQTPne0DMOK29btVlQZHrn2mhuvcX5nhN3qZWMAdnneZSBN/ODB1s8eO/m9dloHkeskMXNRkd226SN7Sp+tsC8gJBx69Om//jdX8zPlZCrQmPrZFEP4FhrTjx2jbmIR5kYacjCPpAPKK5QCc8GGVw994Z+xzf9Iy1Jq5okGCqvvJE45zXF2jr4yYk9XHNKoBeLHFvLvxIXdlOsmaKKrUz9cf/kXPjRp3naAVjrAdkScZ5Oz4uSxuVK41V8zmvK8FDhr1godznY65zErzxVgVJf8DEd25mAinzZJn8KJIlBr3tDQSJymJ46fbs2N1vyrRsJVaaIcj8/OTT78zLcPHnsmrTTirAsEV7qOSSlUs8cbc5NsqHzjcAh2cmvu9edL8bSXd3zDXyKNzkCB0/8UzeDNuas55VuJzAxakAeMmjGQDpdfc68CoDGTyqUZRLkwmav8SjF3rzihEaorEFcAzJ3IaCvJaLa0ouI0SBvN/Gu3cfrMgWdHVUMJt+V4be1F+VquxmtZa6xzsn3oAefkD8LxzaHcNKw/uGXoN0f8O0+db86Lw7VxtxV3UmCz3qokwcINWa6k0C70Y+ZEcTeRs8LvdsQrR+a+13VfK1XfOtD95kMH/uDUqsfTiWkQPj+EZ/DiNFvTnBsXyelq+7yYc7KRHcMaL3bggN896esY6AwGQLiPXj4MQwILxldQKDHAclCSqnm9zGP4jK+Zd6Kzh8MNV4mRNRIsLzC7hA/t4DAQJYywO9pMIB14hP8zN/SecdQRZIYYMOLkHZ6enn76W986//zzlPu3enT1/Xfcv3fv3larRU4UClGhpgsCOrHXKAK9MnAMGFmHDh168NkH9+/fT45guJ1rbDF027huGPa8yfDriRMnmAjgXtVq1eYak3OZLx+1FmYzziQ0teCsgy+8AG/FaJLDBXxlS2YZD5CGLUC3i8nfOvOY8nQi8ibTMQMLRXgJ2CAmdw2sIHbup2z/L1302TGJDhzpOHNcNHOdqDyF/5Y7aot7Onnjb+KjPyrVuOd8IHQ2b/O+uKn2T9vTUbvT8JxWNz6f+GmkOsLVmNUuwaCGq8kcJ/emohyfHT45Ex53dV2Ws9CDa0dhnFWdSj6nw0xGHp9hPPEkINNEe+qGdSNg7vsnz7rNoyyOHMml4ybci6IIHQU49ROIMGIMN+nIoIW9vI1qK48kz+FI5dXE1MEhOa23/gYXsK/FdYociEknbSHCCm8gNIsdwpbT6B7JMalMZk6rzK3XAn6debFz4EVfapXlucrMBF504zrS890g9MBQ1+2oHlYr57rpW2+c8/Tm8upR7nvCDbas5Xp4eq5xygtBLWEfapU7QirlZGkKVASwBzq3G3djDx2DYYyhqExHmA2jRLeThMEIJuKoFnNl4qA9UatXz710wn/9bPzG21HzOM8SblzM2iub6JUyieO58dBwawk5CpM8MUeYgZZylPAdz5s/N6f2/tdB4HNj2OdGUBxligpcAUJz5cWeTMYd4+j57RFesyfn78jDx+p2xx88+a0/WNN5CWeNOKu1cBJlPHa65aJPGT2twnXBxkHkcp00zYLyWOmT/yPbcgeTewGspmYPPnXkb4+qnyfhqcxpapaBJgFRKHfRdawkdF8pSzKd+8wt68Cd95txHN94Tu/q+EOvJqhNeM49QJpEedKpDddndeVMsCpzQ2fe54lKIrwQmPrIYFBFesaGIl5vmA10AKrXyBlGNQf4prVbHjo/H6+65x+XPvIl5q3LRSU1Ayi8Yhw173tOA31MMe2FSY2YPQN74AMRCwo1wwGwH+ym53/0oxNPPcVmZ4EyTKxee++H7r3pppvoIuTypzlNGHUwM5hs9Bs+UzQbrnbmzBns6QgdynBN+As/nT592mQAOhT3pog3hdxXGrVmowgUuY/hXGBFBw4cYM1mfxnRK2OAX4H5NL0MktxU/7WOc8qQEykLXfKxMX7yFy9+819vi48wOcsE/i5zH/8pxCRl8k8yHtIsa6zLJ0/gHmdiLgviEW/LHfeya7/C2FamK23defDtPzrTfSoJnwUJGHZDEJFIIjnVeWjc+Z0KzvPkpfn4Yy/4Mgp0VvYUq2QtzH0walPnE/icrskdNogisQQfS+BdOGCSUTE6gZ3wl+ztnDsaLCzuJManXMo7vfCClpHiE3tuYV/4v5i7qQvPLkwWnx4gzeVvntsbe2mamyDkZUeDMa+qVgM4ee6xx048+CA7exbAqlytfvz6j+/ZsweGOIEKDf13CLNSmdnUryXTD8y6k6+8gmYUwJUw04WvmNF9xSFN3PMI0xSjC3WjwKRC55s4xdI51m2xk6+3fvIXWd7OTOZsSHm7OAkzi6l+r6pJ5YR0AYM6LQcRqNJpggbp+Dr3ZD2Pc8+/6rpPsVt+mw3fmDhOU5196sBPjrS+rSpndTWbb5wexZgFS4WjlXf7W/qqk061LlQWpuZqQQb8Ne94iBwe8NUc6Krxa5vZSYQovZiaNPmEBn5cHZljPOvONNOaGM2hHE6n8I7ca/KKf9fvlu/5Z9qfUMo4+uA/jjdAmkvmx2jReDiRbnLyhe9979VHHgEy8S4kHhmPmZRJeYCwnTp06PC3v419puKyKN91/V033ngjIMr8/Hy5XLbMgxAIo1cFj857OJo5JoC+8cYb7MrLF77ikrD8BRshNz4bkmuHZULNs8mX2S/+7+YbB3aoJOAp9H4SRUJjrmfb6+bC2CM6dDEMRfOS2s2yMWgx+depxAheXQ8M9NxXlZKUUd6O5uo8eXWsNMlko5xtAoNNyLU82ht6LyjeYEmGGKO1yEdYWrrzIOZuxgEoDL2q2zX4AYxHVCMJt6tk84gfAux+n54cs2cWmA1fNAWOwk9hnhjeg5zGN6jZdnDWFfNLp+eF+tD9TJa47spUo24WzkBoLg9q3njhherhwzWTOok5dQpnYqv0Mnm28b0KhpZRLvMgCKSDCcjoKpG9+q3dbhdtolD5gasyRVlUbCHLjoy19/p1sYTWluu8W27pfXcNm+NyIDRL4jKVM4rNlB/BcB4AjH/HlbUtt31m6siPWp2pUlDqppXI9aDjhT8HTMLN/FIEdpNJ5JZJLvLE1Dx3ch8sEQkWkHYSU/cxk12tlSsyR3qJKmfK8WPtVkcS4BWiJbXjCUcEh8qyxVOt4qRdKuWK1/J83XRHsERrL8jLaJXjo2ZCNBJpuIiWXrravMA8VqMwPhi4IoAfRbbFhdUX5IL5TFWGPYtDsy5eYVVyCihN/arPTnzuf8rLazNTWRuYlZunV4imet9wGs64Pz6+4Z57CAnA/EGwuXxuQThhNwIeoEu0JIKDi/Aw4i4UDLowy5qK0Cx8fq/fd8edd4rx8aIzT1wx5ObKQxqThRWRbWIqxOAn7cxzX8qx6t5/xWY3NZ77D6PJ0SA5g7XTEk/lXsJ1VpJgnoIw1Xg3VEmYIGOtO2ORKGcuDu7R/JSbM9mcMHU3W2DtlCTvxFkjCEaGq35nrQp5wrMO64p8I/NGZiunQSH4cRwIr+vJ19dm/Jp853m2qeUyns7IOAw93m14TAR8rB1Hc66ZcpuYXDvK7dUYOUh4aCyp1I7S1OwhiynUM5gxI6qAmZV8jjOnLcrDm7bmu79mQAkoEfPMXIaEXyk5wu8bpJGmDBYMtzW33rp582acqLYw66CXZpskVDXCVAjIlqdGmrywhBb0AWtXSVu3QYPZYkDIJLSbyDMcIE34GmNSJopOicblahX2A//wfaxMQF7pv/fbFclpOAvMKEx4meQaOrSqY6zACAhU3u7d9y+mG1JOPxbILI66FTcbZk2FmStBqoO2rjKvGgIr0pmfx/AvFuWcsw4fZVhjuiMdXXdxbsNIJl1c6Q0IzBxzzjNWTbQo8cru6o0nZp9s8LkoS0vhWMpUQ8zC8fu3iZe3JEp3HM1HJ7vXtEvRC3KEjYzVoqg1GYhRnLlSqBTM+QWLSS6ynmgq1Jy3NmFeZiJr3Miz0tmwU0p7EozBcW5QysOKOFdEf71/PMI08AES4EOttvejH6WUF8plYcbAIW8KJbtc1AtCqENIE0UR7BJcuEYF+K4PoMJM5axms2lsF5esJ0qRAVyp1WrtdrtSqWCJ0CgihFP/MFacu/KQRtACLLRaU6/2rkJdngFVTYKKGZFr3R33u7fVjz/2ndV+rLrTmZnfyhRGK+GTl6swr+M455RMacKBxts8HYK8BMPzOwGUJD+F13eCMyGr1N9kpd2+42dalcSH9l699q0zU43uvsp41GX1kTkMfwKtilTWSca73as3tD/k1c9U4yeSbDrWCWg018UZnYlhHQvzVBS7sO6mZgurs/Tq7RkcqmWzmN7V8w6jNGMuoVoXsK5moVl+hjlkaeuF5TEHSHMZm2EqKVY1xNTc6i237Nq1C4Y7xaKRFC/4UVYY8UU2wwrW0NFDh7AEV64dR0ghN67ZeP311wOc0NxsqukHgAS32Lhx44dv+/DN992395ZbKB4+Mjoame0fCNJcgZWwYjOcJHpF9QXZboN6Rzex9mBvGjmYa63YbGPuga/EZ98YDlEIunHEHb8DPED4TOEQzWlWLNPAb8pqCst26jIWk3Yb2hG54ooHcK80r2Rrbl3zj/8X5u5kvt8ymmiIJVnr1POTL07PHY26pwFL5KrtEyM71w/tXS3LfOq75779b+Sp437AYmUKmkQTWDCAnWULVUKL1TrfCRDKolEiA9sFuJILvIX2x66+QXz1m1qUKXbls4VS3GZMDNTTJT8oR+vJQSHQDjAMXIonAXIz8sEPNv/uVKtxDviHNMscm6VZuF7Jt6yLn81icnxubm7iwAF53VZtitaAfc/akVOr3Tx0M2PbJcPFEOfZqGDjLivXm/U3v//9NXE84vuuqwCMQDmGNN3f+/uPNA67hMalLKFewRUj6dazXmh6voLbnlgkFX42eiajpCebJMUMKcHMKTNpowOji7MS8V/AHkAYGdJo1XmCNWykjB0wd5nzgf+hOeXW9/1ghzwj21g5q+wNR906QA5O5Y+wYkPKAABUBwwjwUtdeAwZ+9vgdsJt6aweZo3AbbL4fOPpkyNjLb7troBvV4ynZeBPTputhueDT7zbGcf5kBE7+f+0H3tw14lzruxq2cIJJq4Dz9lRp72KJ7pYgsQFsONuqhXOzgNtKrxsAXHIRdgrwW/i3oxqbMFngZVNtOdHolrKG1y7XAI9wwlQ2IQc5zLohfa0HVQk9Yv3v0tnmelu68/s8ysui3XkArF1D+ASMZiuCxJzoUz3O78uUcfbHEC0wL4GZcrhkjjGC0KytZAco2nVAG0/LmThS+NEQactCAsWKu85StfddFO5XO50cD1BdM6bLTUbMRjy5ZDIUmQbDiafMtg+NBgAqM6dO/fSY4+9vW9fN+4KU3PTjioUXYS3fPa55w489NDZs2etf4iSbGxv0fWh0Sl5r1dKvcB1bJMuhj2aunCBk9Fbm1U54aOpNNg7ntJ66JSuCZ0uFpFL6Z3FG9U9tVPQbULjpXIaEjcCAzgMHg76lbIY+3jlCkgDw534I7Wm7UXoJHsKFQ5qtXBVFUc1UFnINYYHaC9nQ+o8foax6zhxMKqNpMedtOqyNEmaEtMx517+cffcEZEjrjRzz4x1kbe6KqnL+TN+Ml1Jz01Eb+P7KxCfoUNjUlY2uuoDuRxJghL3HCXmk7TL5zvVVrQlfDHcsoVt3MNWr0ZR7STs5DQ7fLIz9VNR7wY5pqw3vBnhuWkSqNwdy0JcEozPZKHzTPmTecb9MBgdmfDLpThn0L0Sk/egrVy9qF/VQj1YaKIKxrYAeURpdPWa27+Y5E5QAaVnIuHk/lFKS5cKMRVBmkIrlB32n0lSgfuTcoDnITemlYRLUk8kMbDNzMxgSZ9GgwBjSYleDhup7C9stJQBle0EYIDr4Opt3S5cFj7ALagtQGjQ5SWFGY8oNHGOQpPkWaVSaXpJtTIMOFHxw1Nnz8CztRysdbV2YiIcBjHpgs1dTyS6dLOER6kP50+fTKaOdCdTb3oSXcZ+GHVy4EJrr94WVG9muqr8MEY1Mlutldh8JzsxOf3aI/P790+/fhqkOAX7N+drcq/SVTydG9YuQFlu5iVdSOzNTLP6El5s69atq1etL42OwM4kTZiDswsAH416cnTBfOvBgOBWZZcUTuNNQFeVhs7Mzzc7OZtBR/NEkFXDElycLfiioCVpwQfKR4Y2JDjHxWPeqacuV0mdOnUK2nnt2rUE/BTg6+v0ZZGGGAZ0T9tstDAEYcaS0LoYxCwOEcoxk8JIM9AAZuBqQ0NDU1NTsKfZbFIiNyaEZwi2VPE7M2eVVSfI44ChsE/noXLLiktopk0VLBcSdeMwrB479bb0SiLASo4yzzypfY4qzxteB8NxNBRO41Tj6JP1/Y/ubB/Gqoh3/9767befPD8teZWpEB8ySKKoXRH82rGaePS70+eeS3TdyVtVpQORqQwVTVKdgBaI0+NYNU3hiNQOdnM39VKxobXhK6Wrr66sX5WlGuy4qJuluAK0i8t8I4dzCp6bheUQlRbMyJ9Twtr9DBdGTIDCOH4wvhGrOjnYWzVX4cKIw+Ojo6O2/6h45ezsLIU4SFwIaawGfBdCY+tdguiEZsWky0AaLOWSZadPnyZReOGFF5555hlS0n2gUtTTfZrLyg1NZyQesG3btk9/+tPwqvMwmJpNQJ1XX331ySefhF8RQkzRn6LQlPI2CE3IMa706a/88/JoAKPzyJEjf/3zb+PU+aAEKrgZtbTwYo1yifUW8thROTx/7o8MDw/fefOeW7ZObNm1K+pOspcOe6XS2NgYPM8DDzwAQpNEWPI5km3QDDfu3HHNvR/hpRLSZE+U/FJeb2iuKbaFC8o5DkgMAvhCiSvyEa9atWrNtm1i3bpjs+deeH7fq6+/BkpK+G4SA8ozUzU9N41jOnVBaDCLh2HIDIQGV4VRSPJSDbLmzqXO6Miq2fo83O5Ln7sPhj4h/cTEBI1AuCmQMHhOOOCJJ5546qmnLIlcjjMt9okv3gApP/7xj69fvz7srbGV0fIRl2Q9QX+cPHkSfeRZ9ud//ucgLvB8gA0wlPuyBSxftsyrKDG9pCdDQqkGHUgGqUywcuHJ/viP/xiuiXPQlEJfSIaN63PliCgTYCzI3PHajteNs/Fg5D/8u2/t3r371LnTc3NTnZy7bqgyL253xsbH4ayzjQhGSBx1HO6WeDsMfBjts2fPPvwMe3Ny070fvWP45p21xuTb588ncpcTVGeYWyk7qR+0YYAmfkmUEycAU2p0tS9ORl56Ou6qytCG2WazAkdVwkTNArgNpeucJPclgK6OxGidDYnyNdk1953ZFp44duyH//EXWNNTjHGfawF8BFuyk4DEOwIFJsW/DCuJ4tQsxJiwm/DcKSMG53FPChmvlp3ZmXNUwPEH3/9P11577d2/cf98qxsETcAAOAz0CBwJn//wD/+Q9L4VpqKgLOdvXC7RAvqiZMZM8bA+xFpWaGg6Dxz9l3/5l+TrhOFIQ82KSB/SLCk05DOl2r5UFJieAx5ufHz8T/7kT+DisJNe2zIvbdbQgrOxoq7hgDCe6vW65wUAS34FxzpAFLZvxgG06/VZOABABa6D5e+A0zQaBth8YD/Ndvu1117buXVDuGGitGFD9/hx31B7OAUzhV0sjo8GunCobCcz1ibFmKAdUKumcI22WzN+51buLizcYmLmDHquOjZ2qF7/+c9/zoFUO05vcigXduSgWcSJ+GICnkShMT+ZAcWM0SR5Tloe2WQawwuSsyNnObx1edXm66+/3g4wcluAxLCFCVMXWq/QNcsJxwqGC3V0kWD0Hbys0AAYwsmHDx+GRiRVhQBgVtWiByJLkmSiLx+qKD3W4AxNiWU4kpbDgA578803KcOBZvCT4ouNjIMScMzDkU1rRkwWVEPT+iJJoiAo4dVUJp1U8SQcHsVGzLplwYWMTcmXMGUykZjJ4IpMavHUE49d99v3tzZ8/OzVQ1cnMxW9vpoJ5dUyFgdgPeV+rnjZ8Wuqlfui4fjDsa9BVcgEy42KEjpKYvT0OiLNWJpLnObiar6W+c/u/OjV5S1vP/Ocrgc6F57vCTXlAGOJ0Red1bAesZPjwJP++oiniYhdT402ZqA9Z7WH8wtoXimmZ6A04dLPJEZSGiqJHf/0L39x8/V7QKFXq1VimQA2JBNkRtFUPRImEiAqWnBZSEPaAIbBYipzcaEhLX7w4EH4C88NPW0dPqTFi3ft+1qUG1tggRZksxFjeEMqxUCFx0mYQFJpSSY6kQCMAsjEeOBSuHatiUtTDfOki1QUaAcOZWhxPBXPhdGMqCDI7cF4jhYH0MbRcZd8x1axatVzCgsuimr3IuGOhQLEAAPwSPD858+ft/2H3J+zcrkKpDhjvYvj+CE5CEud7hxZlCIo9w19eioaRSAi8LQ2WQewlmZmId+XEkYdwZilobigxDvdY5c7NYzMHSI0S0rMRTgNPBDIMhXjIERZvXr1Rz7yERIae4wlg0ua4vS21qtGnzEWzdjk5CQRZGhxaIVarQYCRIJlzTy6bG9dQjPsKFcB2o5oVjVELIk1N6gOj5K5HJsYyDL0aqcdmUWPuSuFq9Ju1FJyyC1VtQhTJbTrC1ysFsvAMO4qrEostXIUrS33jsXD1OK3QyWSg8j1FCXQUnQZwFmOyLyJ0lDl1u27OZA3YVrJC0Bqx6I59HiV/TzfUgGWnTn+ms1LWjqYXthqPfzww2SxEsDDHprpR0zx2LFjtpQJHAMcFvQX9Dd5F2mkrZCPtpwHf2RkBNrZOg9peFyq0JBmofWSEIpdd82aNeT8oZ9WyFwp6lQbNLCrugFm0FxrglO4Jjzl1VdffcMNN9il3opNSU3w/e9/H7gzAQ+MUWD4wPOdHA3v2VZkXJk5yxJfo66MgQLXm6+8cdy0msJC90wUV3fqOalB0LSpwSmc4k37QuLLtS+8gTaTIuiRPDdEMYIedQW81J49e6Sju1nXrLqLrtv1DFffPK+AwHkqzlyn0vaqxZtasgiPBLJIcz1JMqit8NXgRp5HP5EHmY6HzgYji4AKi5sUOOKlcxqK51OCoh2xl2py00IVtgS8fTKScZpFRpJkPTcrWHok+/CeaBK7LqAFaGW4CNnwNH0fLguvTa59moVP14TjqaY8fICXoZVOyUOI0K2Qu/lVfAbPkTxTnojRUPSCt4+dPHT0lMQ0igwRSGJ2TaqA3vgpCDMoI+lpgzTK1JWQGOPBErSAPLjAci8yrQv5MYVGF/hGDvzNVJ5m0EKgT7R0Ih+17ark6FDqezLptDvrXv8L7G/HrEsFNxViPMtbfrW+8yt+dbTMNLWtfmceGekIO4SoL2n0W+1DyqgYorHNCJhNQrac9bQCESbGWZSE/t5cQWdT/1GEyFY2IEcFGD72rsXS3MtdqghxWKRudtZ6VMnAgxsR+YLrw4eiO9zm/NooEuEctTVhoSiZMlgqj5ptGNAASKvXri9CGg5WIYuhvh74US0qjjk0cL4NqV66K4y6KjCUIlW9usAylzROQKGAEsFCkAq9QbqDuAjWHRtbu/WuVdXqqGa6Tz2RZXT06NG+ZGeyPSm8BZe1dgaFdwiE4AA4bGxszLJSYgLvJkfFCABpkku1nuwKFNS+BCoUtrSFymzPXbSaRtGxSJEEa4jSy1u5BBmCgVJ8SjiM6Itd9phQkBbeKVWq1fGJqqCRofRorLrDfngehA44s+MHQMJVlmI1IIZzK4EfAy3GqdECl/bGFduxErhGAxh2clwt20zHU1ghj2WMq+Xa1NaytzCcowZEIHRxDmjOdeKIfEvjObhNrlKJSsqf52NxsGZs961ebdRUFORLXpyWAoHWsP1H9N+mqNq2pcYk/WXRiNr2XUiMtWep9+lSNoR5kSg36Wlyn1BP09ApFlxZLqTQJ3z2Vxs7JZ83DRobaqbHLRKLopq3S2Fbu4CEjPbYSg7wosAFhoeHqd1Jsdo1UQhILPJZO4VYzgrx5+VSPuhpSXzpBelq/STUKFRtOD6dFd50Uy98v9RdaGe8sNHLUnaitYnINIG/RBXoNamVrBlxuSyY8KyIcLZs4CUhDWlHamiiEXRFimKeOXPGdsDKeN7nnSTlQqIT4EpIOXnlqVEIz5ZkSNZMsGEskuCUw1hFFrJQbw3VTMa9THil8jCTQYLrAJY9lWmRaFqrkmHdqjyLHakcgBmhklj5jpcmMTQ8F0BSMoAczxVICQp9WmQ2C5NzYVA6UZbDZaQTwtVH+XyWZI1g86yzLguqXnt6Sq4fFl2ZdYTjd7kLBDX/xP/Jgmsc1cQxy2sXjP/CB7oLDSdyIhTNSZuGYafXUAMWHTB0FtBH4s5ktZAxS+7W5YQGjiQFZ8Pdlyo0pD5sV9ncEbKkCGP6wGA5xCJ8s45ggg1LNayCW5kYFdNNLClZKfnZ5IFQi8MHEz7ifaExPMK4UDzPgQNAfIkGEhWljBzHk5dIbiyfNW3l2AkMwGbjblyS+Ei+B3LjrN+1C1+h2+Xl8KLXtOu49AX46Fe734YR7Aa6DCgdrkhN/mhj31Ff0JrCS96UfEJwIhlQS1JmZwX1ZEW4twyOiRZZB3NfTNVGufvCCKSMbSExUkbAo8kmtCNj8TsvKQdF5diTHhz/gorjc5onDTQUSzpiISsuXROKMBXmGQmOCRoyfCoHj0R5MnUUOQBMkkYgmYEfgp7RAFMlGMrJhfkDRpsT3uQ2YYz2YCgAO9A3k2DiFOw4rLwUi3woqPg6ZlkrTvLjzsj2T/9+5I1kilXKEpO7xEWEpkj7+jPoCg1ix5LtHWjhRqMB8jE1NWXrzVoDfoXshlWrVtXrdSs0i490Vs7at6qERKRuwitFm8gKTTE7cHFAqgjpa9euvemmm+CZbBTTtsgKNIKOtLZlcRSuoBYXhqDmiry+F8KoPe8tOoSN7sNVmRmhoGOz4xClLjKroWia4s5cF+E5NjX0ZAa8GMd3tVqVu3YlhRa5KNJYAOsDY6upl+Nh5OMAiXnppZcA4C23W1Lj2G3Lli2gm2w2y2V7hC3VWoBcvpgtrmD02+g3AVIxS6hWqxHFtsTwUmzd4rC7ENTFzH8lFsrRGaxTQitc8QsgBHEGMyalyITOMFsSPSUyN5au9MDuYKkiVesEIUBMOdNOhMmdAQuHedbQPC1QGVW0Hgi2rHSiP1l4CUN/wbCKwrzhO6Ljj3ppLMujndwE7z71L5m3K8R1Op126vmYXbxSmKKYbVls+eKQ6DOm+tzxQ0NDdnjbhNfFXWa/Ai7YvrAZCpcqNNZzb517fQp1yfzzxQfYCLZNUKfQQVFPW+W1ssFSVIIXrZpphcyQFuOAUbxYWsa+YE7uOybtOCHLBcNh8OsyBXCsBdA39D0HE+pc3ktIIm84vG8n6q7fvp3BPxByeH04znVXnjJhwdV69JeM9/Wxz+Lp5KohBmkJ9eIhWvxMXNOat0sGup0ViWTP909QRl27nIm4XBfiJCMTjLQYbtMCi1JMQrAy2PQhTc/K7c3J7c0toqmIJrFCYzITSooGXuOA6cJSD+wluIYfSNfLTXCTMwcXR2CudErQsRmYUmiOedIvK5a02g3f75XRW9YFtdAecBGjnlJH8MRf7Y5vjkUpd3i89eMnzp1zJsbXf+Zrc3x7LhlWEMkAbTLP9S5FPS2X6WbtKSteiwdtT5RN+1s6YfXGYqEhk7bIky573pN1O9oJA0V/STFpZrlIAr0PmdOkSqnUb2+RvkKOz6WY7hZp+mB5BU5jfMFglCvX+FDg1qHZMqzwapgmxp/cOIpLQUAx9qFqde8NN7BoNnr1mTiuX4o3oThSyRdH4379+vVjGz674cQJVh5ltRoVs4WRBB3uSS9DT6BzUevJIkpfTxd/6suksRBuQ0DWhnrHhIdFvWaNFRuTXjyYV0IaKthsXfiwZ926dddddx1Z/Db4t3IigY1uWnJDX+2qxjZIthw1K1qDxWk0NHoys5aCLEaJuYs7BTpyAqeHTGDNaKekRq4+z5yRnTu63bjTbvtBxdTfw6gUKBMhonJt7Yy7Nhq+as0NXwbF9Mam/Ru+/4+UJ6JuBkOwksybljGRsjQpVaun8sqZ4evKTqC4x7zATOxNEOpklOtWlus4HWbrrjXYgttozxnSW1iQJGZJekGeVRsPLnrYqAUIv4uBvyIBwrQyH1d/Afr4+c9/vmiyFL3z8PVnP/uZTewirUQ3taP6MtRTH9WiZ7VIQ5qPhpTl5Ctzaus/JUVrPXUr8OuV/TQXRSZ7Tfv8RbvUMiRuGKeJG/bqnNPNoEd37twZjI/PTE+TgJLV2vPcu0G7Xi+vWnPzzTfPrV5db/Zg33V7r2mHeLEa+cr0aDFGFnVTH63sS+Zf3ICUHE5RqsWuPEpTIeCh+EPRHf/uZ1gWn5U+kC6EJhsZGaEWpLZYoY5Qn6VHV5ienraYUXRerWxyF90SF3Xu9Vlwiw0Nyn0RvXwRJrlJ1TDkFHsaXs0RAC7stx44/v9+fWfzlzrTk4q7Xg0ulMR8hq0bveNzlbt/lw/72cnDOmqVAuD7WRo7RU5Kz3xZ4c9i/LIvwtqXqLW4BWyzEHJPTExQKstiNyz8nZmZIby3CRhL5kVdntAUW7z4FYZduVy20mAnv61siNn5XUVboM99fonWECuUlrmo9VHMbzfn6r6UR5uyY2m745QkDrsMl/GqVm/6zGfq33q0VCoFQK0V3nR4eGTDvfezzXfpmk+jFhqEQMV1w+KVL5T1u5zwso04LpakJTmNlRIrEHY82xy6xfOhQGhISVkjvNBKSwD2pQpNEQyKThc7jC7af30vVjQRFzshLmo9FdfxumhPLHZ/mblp6BLGCXAaM/VQL+leMMvoFB/XeMN64xJdOfCTP8R2fdL5yuoH/+bba3mbO3ztrZ9bfefHmV8yK2rOAbmYyv0k45UUy0XPa2ldLEXzZ4X26Uv+KoZ4i+NquRmJfb8W41B9Erbc7CKLhRaoVvZ9OBe1VoqchpSLneFXxMzl+tsGom0SDEEi0XLrPLgU517R73yJzsDFdkefpWA6qedAImIOY7Rer6M7NY08ECAR+zyqeN7nv/QlNnWMAaCWN82fORP7mBdcDV2Tp4GpbgA2zWZThbW+Tr0o5ysSl2I7W3VcjMwv9lotnhldvOPimWjFdF7LLC3vuZSGdS6R0BQdlDTPzYZerVisAA/2hW0yYp/f5VLUUxGBV0hk7BN6Sxh7SIvONfgtNwu8XeANYIzb+LlJYo/g/VKWZxyEwwuDMZ1GfNVmOOZMU60bWZd2u2mzoSOspxTkWd7ERZLl6GigHet+pDIAQOCSJLloYLhoBtvqTH1C04cWxYlOFl3AFJqamiIHR9Eduphrw5GkmHoBkEtYaOhSiXDfnCaKzqiFjR50ZW5hZ5PbeJa195acw3BRpLl0a6sYTF3Ap3dM1zIP0JsFAh18/vx5C36Og70V5ejamZnugDEtTQliXl3z2muvhWCbOLKb1qERRtdvIZMVo8eJKqoVmkhFCYQrWJfFHOriBIMirSyy1D6WaSdvEJuB21mLdUmXvWXZlOtCxOsSWfAleYQpjE5TLUGEyTBb7N9bsvL74qIVOGM5DFetWmVmJoW2jiuGCU22h22vop/e6i+y9ulexcwbezBxbbJ+4eJwCzLT4LJY0R5USRZbagUWKeUA0CRAYCTw4a233rIQiEEAJDhcCoSKullJZTjFiSNtLWf80bNpCT5/YVsZLFtRWxtrXRJdnG7HGICxfRhbUWW5XlkcgSGBo/Qu69ewlj9JCRVYoZRqaA2ANMostnGAvko2xfxi6g47X5bwlVaRtTbvcku2rhSwhG3Lli3Hjx+n56bkOlwTdpGOXDLnrfh8RJ/pzcEOHBsbs0SnqKSKRZOKolM06YvJe4uXXio6r6y7gqI/uO4XtGnJo/tC1w4PDwMLoYam5yzOh+qV2uPCCE3PLYnDQJFrTsZpSifCReCntWvXHjt2TGQR3ZEWWLAwUJy2UWy3Jeuu29RjWxpiZGQE7mJ5pE2VgltQyUECGNL7NoGJHnjJfrGxAut3teGFlWvHrCQ0ROugIc6ePXshkWAhg3CxdujTLJagUaUIi9jWkiziCl2TXEyLLQVrB8IBlMHZw4B3xmX6rGjrbqbDKCUb+jjqNEMfa1ZAW2/atImSTlxXRlFSZP3mWphYHDL0As+6WzE4Hzdd1ZXm7WPJHN0aF6eAIiVis/CCrSMj0eRk5CjbULbCo33HPiyxeLkYaah9YM/Q0BDgH+AWICKhLOkUEEroHegjigcXXfPFCY0rJ8dZwSLKUeQ0S5pmFxEacibCq4I4w5NRUSMbWF+Ocq4Av9R81JTWQW4nX9oCT+RXKI7FYnyOqosX47pLjlH4lWa9WFmndiTliK3vY6klpkW1WqVUSOsLviB/puyUox17EVdhkro0CRI51liSUZowKWhOOKjY0dHR6foUqSfK1LRrOPTqHS8qtVFke8W3BkGp1WpwKfLbrjIb9QvNhyLkg2PqZqNRYZ3mFjCWDAvahrVQbYH2HXNPF0b+pfpp4DhoUBqOJ0+eJAQu5gQVPT99DvvFucYEIdTT0MTUVXZ+E8WnrCd7SW5kCyIV8nN78Zdijrd9f0I4C0vUbcYs6tZqLAzKa1atbQIRMYoPwMZWcML702QXc8Ekn+DYSogTbT+Dm7mGrcZZxeOezDvwQBNqNmFJUuVuqaInFc3qopFAvlDrKShmrvU5n/osIwAYWsYMGgpwcf369dSM0HSEKyAuMIxhSMP1LVrY4WctXxLKJbumCHJEnmx2ZdGDehnOPZJcKguyceNGeHR4B1BVNn2zzyzvI8JWqkjBF8NPNCfZDj4iy4Q3IBnkWrUWBJ1C6SAUgraF7Cg7347gYouTyidOYIcyTbQjFkLzrVpmwt6GDRtgDwwMwjD8VVzQklLjIuw9lQo4q3LH+HW0WR8ba05zRWvQ4YzudgRXg76EPXNzc8TBi3C4uOcW1/spTnkum9JadoE79EqbaWxwFojL7OwsXB/2AOOhYgDFwVNkEUtOmraobDsLWozmD5FyX+7clSphUUyLqnNR+SoryMu5GhdzdVJblHVFqECGDOk7W8eQpAf2A8LTZB9rf1KFMDCGQVyoyWj8kTCNj48DYvehKDwnyDczqZZ2uQ2KmgUezsqrmCr28GZwHcAbwiRMm8+z/v7TGeaEclytTqjMxNVlJCsNF6edVx3lJvURjiM+KmHdobg+awmmHSd2lsXi1rZBlT6hodnKDVMwhaQBGEzfVCbgD9Am8I522kBRsxSDPIv715LCvoAxXBCaB0THFjpZggNcyuweAtuWadzFD7FYVfdZYcT5bdEJClSRk9CWxiTSUDZTlpZUT9B8ZIyQS4pSIzBdwcw/ZYtqosJhtkHJM0SqbahaC8KQnBXcZFS0Ox0QHTgSG7owSbZH1IzQYEkZLFydm5L0KDR1U4ao5uogb42KqDI+ngj0Befdrl2Umy3UrLPV1FdIjWWLSrzawAuoKjtaLM+wFhmJDgUdrTJanKO9OF/b+q6KoXiatwVCY0f7Yg/Tlbcu99+XrVhAuRiqW6wg7GguikJxjFlUKOa72Dmz9kY2SmMTbvqO7CsGbWXCCmvxSVaoSjwQml/9Rn385ptvvvbaazSXisqFwOebbrqJjCCgI2+88QboUECR6667jub0EJyQWoGv+/btO3369Jo1a3bv3g3qj0om0C2AMD3++OPbt2+/5pprikp5Zmbm+eefh/07d+5kplLikSNH7r77brg+qWm47xNPPEEHwI3gGYAM0XQ2azTcdtttcNOiX+MyotyD7d1tNKxBIJ555hnKNqQqeaBeN2/eDEJz7ty5b33rW1THFY6EXvzyl78MhNd6MuGnP/uzP6NKPAcOHHjsscfuv/9+EB0LFSBSzz77LFz22muvtahAEy5BUED7g0xMTk4++uijJLWWbsM14alA+EDa4EbwkA8//DBVoyHfD3ymh7TBrGJ9loHQvIcbdOQHPvCB66+/Hlr8r/7qr6DRv/a1r2H28dAQ/PrDH/4QuudTn/oUdC1gxne+853vfve7v//7vw8dTAYHiBSIxWc+8xnoWsCGBx544Cc/+QkcbF0SJDpFx4e1xQjVQFJBGgB4vvrVr9IcW1YoC0+zvuEDgMott9wCN/3TP/1TMOZ/7/d+D86dmJhgC8XYlszEFYMO/pVTGbawFDvQSUAaEAvoD+i51atXg1iAGXj48GFQECBVcMBVV111zz33ALSAmiDeA59BUHbt2gUHgJDBuL/33nspKEY2IJEbkC1KGSvWY7DVFF555RU4/q677gJ8Khor5Hog6YENIAdsNHgMIl5gulKxXEoxLubZDITmPdyK8yXYQrFM+olmNE9PT4MMrVu3jkKqtIAUSMDRo0fJPUbCsWHDBlJzgBzAMOCwM2fOWHubcMLGj8gVYgOxoP5AMcHXe8ziwpaJk4eavMl2Nj6d2zdp3FL4Yl7YQGjeW91UzECgQK8tH0ZYAuObRIr8k+RNoP4jBwm5IrH2vamSWahyqmwUmnz01uyydBjIL2AVnHLy5MklHS3W5Wjlg4S76FBdISFrIDS/eokpRo9tZTirQajEPyV1004ABhARECPqJHKBglKzZVkAnCiwQNfsFVBaIMWka2zyNS16smPHDjjsoYcesphB8kQl6GzhIxuTgVNI0xWzKG0ttwGneW83sjWseqL4mp1XCh/Wr18PHfzSSy/ZdD74DKwTyA31GZAYOGv//v24GJE569VXX4Ue3bJli43YFH0nNlnARkCHh4e/9KUv7dmzhyxwtpBG2KvUvDAPpBjKsP6hfvlYajbFwHp6T+xtGtakmEjRWMsFuuHOO+985JFHvvGNb4DBfPz4cVAiN9xwA63PSw49OODxxx//5je/CcymXq+D0MABlLlGgRdyn1D1booYgMUO3Jkc0GAQwU2B0MABQG727t1Lc0Uo0da6DUna6BRairxvOaBl33HQzb9ypCGiYAsJgDSQhqIugQ933303dN7TTz8NkgHHQ2ffd999FEmlIOuHP/xhgJkXX3wRyC8cALIF9rkND8EemhN54sSJyclJ6n4wfNhCdI/CzOPj4zfeeCPc5amnnvrYxz5GghKYjfJGSBPBKRRyAS51KRIz8Ai/h4a3DVICkAAdsYtvkSeGmdUnAEVgPxHkYiVOOhL4MpV+gu5nJsZE1d1JdMBEt9MJYCdWvjEgNDU1BbcD5IDTYScwYhBEsPbtQjjAkOCmVB+IKBGuiTQ9TRMqLmkK4kBofuVEuG86Hwxr6A8rE33ZPxQcsDttHj4xCVqYwh5PTjlbcbIoo7az7eyiYtI0K0TdF8eurYivUOxoIDS/DqRZMmnExo+WTAqw68XZ4uTUhcUskWIM3GYjWc1ow42EH7TCTbFCEXtnKNQeyS5nRbGB9fSeOGnYoplp1G125S1WSGGhlUtZYX4FW8iYJpbDFnIXizNc+6aoFu9I9cJt5VRm1tQhicFabuYne4p1ECw5n2SANL8mIlz0vi8eu4tTF6yTl9xrRT3F3plBUZwp1ne6nbhYhI2+DAeyq+1Oyri1ht5yKVcDoRlsv4JtIDSDbSA0g20gNINtIDSDbSA0g20gNINtsF3K9v8LMADmQ20v2CzlogAAAABJRU5ErkJggg==');
}


function stripslashesDeep($value) {
	$value = is_array($value) ? array_map('stripslashesDeep', $value) : stripslashes($value);
	return $value;
}

function error($errorMessage) {
	htmlHeader($errorMessage);
	echo '<p class="error_message">' . $errorMessage .'</p>';
	echo '<p class="error_message"><a href="javascript:history.go(-1);">返回</a></p>';
	htmlFooter();
	die;
}

function success($successMessage) {
	htmlHeader($successMessage);
	echo '<p class="error_message">' . $successMessage .'</p>';
	echo '<p class="error_message"><a href="'. $_SERVER['PHP_SELF'] .'">返回工具箱首页</a></p>';
	htmlFooter();
	die;
}


function isPost() {
	return $_SERVER['REQUEST_METHOD'] == 'POST';
}

function changePass($matchs) {
	global $password;
	if (isset($matchs[1])) {
		return '$password = \''. $_SESSION['pass'] .'\';'. chr(10);
	} else {
		return '';
	}
}

function htmlHeader($headText) {
?>
<html>
<head>
<meta name="robots" content="noindex,nofollow" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $headText?></title>
<style type="text/css">
body {
	background-color: #D4E9EA;
	font-family: Verdana, Tahome, Arial;
	font-size: 12px;
	line-height:150%;
}
a {
	color:#0066CC;
	text-decoration:none;
}
.main {
	background-color:#FFFFFF;
	margin-top:20px;
	font-size: 12px;
	color: #666666;
	width:650px;
	margin:10px auto;
	padding:10px;
	list-style:none;
}
#top-title{
	background:url(<?php echo $_SERVER['PHP_SELF'] . '?action=logo'?>) no-repeat center;
	padding:35px 0px;
	margin:30px 0px 50px 0px;
}
.input {
	border: 1px solid #CCCCCC;
	font-family: Verdana, Tahome, Arial;
	font-size: 18px;
	height:28px;
	background-color:#F7F7F7;
	color: #666666;
	margin:5px 25px;
}
.submit{
	background-color:#FFFFFF;
	border: 3px double #999;
	border-left-color: #ccc;
	border-top-color: #ccc;
	color: #333;
	padding: 0.25em;
	cursor:hand;
}
.title{
	font-size:30px;
	font-weight:bold;
	text-align:left;
	padding-left:40px;
}
.care{
	color:#0066CC;
	padding:0px 10px;
}
.title2{
	font-size:12px;
	color:#666;
	padding-left:20px;
	border-bottom: #CCCCCC 1px solid;
	font-weight:bold;
}
.foot{
	text-align:center;
}
li{
	border-bottom:#CCCCCC 1px dotted;
	margin:20px 20px;
}

.error_message {
	text-align:center;
	font-weight:bold;
	font-size:16px;
}
</style>
</head>
<body>
<div class="main">
<div id="top-title">
<p>&nbsp;</p>
</div>
<?php if (isset($_SESSION['pass']) && $_SESSION['pass'] == 'cff86098ab3525bfdeed6922c60d6f0fb1b067cc'):?>
	<div class="b">
		<p style="text-align:center"><font color="red"><b>注意：您正在使用的是默认密码，为了您空间的安全，请更新工具箱密码！</b></font></p>
	</div>
<?php endif;?>
<?php
}

function htmlFooter() {
?>
<p class="foot">
&copy;2010 emlog
</p>
</div>
</body>
<?php
}

function isSearchBot() {
	$user_agent = strtolower($_SERVER['HTTP_USER_AGENT']);
	$identify = array(
		'googlebot',
		'adsbot-google',
		'gsa-crawler',
		'mediapartners-google',
		'baiduspider',
		'yahoo!slurp',
		'inktomi',
		'msnbot',
		'yodaobot',
		'outfoxbot',
		'sogou spider',
		'sosospider',
		'iaskspider',
		'naverrobot'
	);
	foreach ($identify AS $key => $tag) {
		if (strstr($user_agent, $tag)) {
			return true;
		}
	}
	return false;
}


/** 核心类部分 **/
/**
 * MYSQL数据操方法封装类
 */

class MySql {
	/**
	 * 查询次数
	 * @var int
	 */
	private $queryCount = 0;
	/**
	 * 内部数据连接对象
	 * @var resourse
	 */
	private $conn;
	/**
	 * 内部数据结果
	 * @var resourse
	 */
	private $result;
	/**
	 * 内部实例对象
	 * @var object MySql
	 */
	private static $instance = null;

	/**
	 * 构造函数
	 *
	 */
	private function __construct($host = null, $user = null, $pass = null, $name = null, $charset = 'utf8') {
		if (!function_exists('mysql_connect')) {
			error('服务器PHP不支持MySql数据库');
		}
		// 自定义信息链接数据库
		if ($host && $user) {
			if (!$this->conn = @mysql_connect($host, $user, $pass)) {
				error("MySQL 错误:<br>" . $this->geterror());
			}
			if ($this->getMysqlVersion() > '4.1') {
				mysql_query("SET NAMES '$charset'");
			}
			@mysql_select_db($name, $this->conn) OR error("未找到指定数据库");
		} else {// 使用常量链接数据库
			if (!$this->conn = @mysql_connect(DB_HOST, DB_USER, DB_PASSWD)) {
				error("MySQL 错误:<br>" . $this->geterror());
			}
			if ($this->getMysqlVersion() > '4.1') {
				mysql_query("SET NAMES '$charset'");
			}
			@mysql_select_db(DB_NAME, $this->conn) OR error("未找到指定数据库");
		}
	}

	/**
	 * 静态方法，返回数据库连接实例
	 *
	 * @return MySql
	 */
	public static function getInstance($host = null, $user = null, $pass = null, $name = null, $charset = 'utf8') {
		return new MySql($host, $user, $pass, $name, $charset);
	}

	/**
	 * 关闭数据库连接
	 *
	 * @return boolean
	 */
	function close() {
		return mysql_close($this->conn);
	}

	/**
	 * 发送查询语句
	 *
	 * @param string $sql
	 * @return boolean
	 */
	function query($sql) {
		$this->result = @mysql_query($sql, $this->conn);
		$this->queryCount++;
		if (!$this->result) {
			error("SQL语句执行错误：$sql <br />" . $this->geterror());
		}else {
			return $this->result;
		}
	}

	/**
	 * 从结果集中取得一行作为关联数组/数字索引数组
	 *
	 * @param resource $query
	 * @return array
	 */
	function fetch_array($query) {
		return mysql_fetch_array($query);
	}

	function once_fetch_array($sql) {
		$this->result = $this->query($sql);
		return $this->fetch_array($this->result);
	}

	/**
	 * 从结果集中取得一行作为数字索引数组
	 *
	 * @param resource $query
	 * @return integer
	 */
	function fetch_row($query) {
		return mysql_fetch_row($query);
	}

	/**
	 * 取得行的数目
	 *
	 * @param resource $query
	 * @return integer
	 */
	function num_rows($query) {
		return mysql_num_rows($query);
	}

	/**
	 * 取得结果集中字段的数目
	 *
	 * @param resource $query
	 * @return integer
	 */
	function num_fields($query) {
		return mysql_num_fields($query);
	}
	/**
	 * 取得上一步 INSERT 操作产生的 ID
	 *
	 * @return integer
	 */
	function insert_id() {
		return mysql_insert_id($this->conn);
	}

	/**
	 * 获取mysql错误
	 *
	 * @return unknown
	 */
	function geterror() {
		return mysql_error();
	}

	/**
	 * Get number of affected rows in previous MySQL operation
	 *
	 * @return int
	 */
	function affected_rows() {
		return mysql_affected_rows();
	}

	/**
	 * 取得数据库版本信息
	 *
	 * @return string
	 */
	function getMysqlVersion() {
		return mysql_get_server_info();
	}

	/**
	 * 取得数据库查询次数
	 *
	 * @return string
	 */
	function getQueryCount() {
		return $this->queryCount;
	}
}

/*
	RSS_PHP - the PHP DOM based RSS Parser
	Author: <rssphp.net>
	Published: 200801 :: blacknet :: via rssphp.net
	
	RSS_PHP is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY.

	Usage:
		See the documentation at http://rssphp.net/documentation
	Examples:
		Can be found online at http://rssphp.net/examples
*/

class rss_php {
	
	public $document;
	public $channel;
	public $items;

	# load RSS by URL
		public function loadFromUrl($url = false, $unblock = true) {
			if($url) {
//                if($unblock) {
//                    $this->loadParser(file_get_contents($url, false, $this->randomContext()));
//                } else {
//                    $this->loadParser(file_get_contents($url));
//                }
				$content = '';
				try { 
					// curl 方式
					$http = Http::factory($url, Http::TYPE_CURL); 
					$content = $http->get();
				} catch (Exception $e) { 
					try { 
						// fsockopen 方式
						$http = Http::factory($url, Http::TYPE_SOCK); 
						$content = $http->get();
					} catch (Exception $e) { 
						try { 
							// file_get_contents 方式
							$http = Http::factory($url, Http::TYPE_STREAM); 
							$content = $http->get();
						} catch (Exception $e) { 
							
						}
					}  
				}
				$content = strip_invalid_xml_chars2($content);
				$this->loadParser($content);
			}
		}
		
	# load raw RSS data
		public function loadRSS($rawxml=false) {
			if($rawxml) {
				$this->loadParser($rawxml);
			}
		}
		
	# return full rss array
		public function getRSS($includeAttributes=false) {
			if($includeAttributes) {
				return $this->document;
			}
			return $this->valueReturner();
		}
	# return channel data
		public function getChannel($includeAttributes=false) {
			if($includeAttributes) {
				return $this->channel;
			}
			return $this->valueReturner($this->channel);
		}
	# return rss items
		public function getItems($includeAttributes=false) {
			if($includeAttributes) {
				return $this->items;
			}
			return $this->valueReturner($this->items);
		}


	private function loadParser($rss=false) {
		if($rss) {
			$this->document = array();
			$this->channel = array();
			$this->items = array();
			$DOMDocument = new DOMDocument;
			$DOMDocument->strictErrorChecking = false;
			$DOMDocument->loadXML($rss);
			$this->document = $this->extractDOM($DOMDocument->childNodes);
		}
	}
	
	private function valueReturner($valueBlock=false) {
		if(!$valueBlock) {
			$valueBlock = $this->document;
		}
		foreach($valueBlock as $valueName => $values) {
				if(isset($values['value'])) {
					$values = $values['value'];
				}
				if(is_array($values) && !empty($values)) {
					$valueBlock[$valueName] = $this->valueReturner($values);
				} else {
					$valueBlock[$valueName] = $values;
				}
		}
		return $valueBlock;
	}
	
	private function extractDOM($nodeList,$parentNodeName=false) {
		$itemCounter = 0;
		$tempNode = array();
		foreach($nodeList as $values) {
			if(substr($values->nodeName,0,1) != '#') {
				if($values->nodeName == 'item') {
					$nodeName = $values->nodeName.':'.$itemCounter;
					$itemCounter++;
				} else {
					$nodeName = $values->nodeName;
				}
				if (is_array($tempNode) == false)
					$tempNode = array();
				$tempNode[$nodeName] = array();                
				if($values->attributes) {
					for($i=0;$values->attributes->item($i);$i++) {
						$tempNode[$nodeName]['properties'][$values->attributes->item($i)->nodeName] = $values->attributes->item($i)->nodeValue;
					}
				}
				if(!$values->firstChild) {
					$tempNode[$nodeName]['value'] = $values->textContent;
				} else {
					$tempNode[$nodeName]['value']  = $this->extractDOM($values->childNodes, $values->nodeName);
				}
				if(in_array($parentNodeName, array('channel','rdf:RDF'))) {
					if($values->nodeName == 'item') {
						$this->items[] = $tempNode[$nodeName]['value'];
					} elseif(!in_array($values->nodeName, array('rss','channel'))) {
						$this->channel[$values->nodeName] = $tempNode[$nodeName];
					}
				}
			} elseif(substr($values->nodeName,1) == 'text') {
				$tempValue = trim(preg_replace('/\s\s+/',' ',str_replace("\n",' ', $values->textContent)));
				if($tempValue) {
					$tempNode = $tempValue;
				}
			} elseif(substr($values->nodeName,1) == 'cdata-section'){
				$tempNode = $values->textContent;
			}
		}
		return $tempNode;
	}
	
	private function randomContext() {
		$headerstrings = array();
		$headerstrings['User-Agent'] = 'Mozilla/5.0 (Windows; U; Windows NT 5.'.rand(0,2).'; en-US; rv:1.'.rand(2,9).'.'.rand(0,4).'.'.rand(1,9).') Gecko/2007'.rand(10,12).rand(10,30).' Firefox/2.0.'.rand(0,1).'.'.rand(1,9);
		$headerstrings['Accept-Charset'] = rand(0,1) ? 'en-gb,en;q=0.'.rand(3,8) : 'en-us,en;q=0.'.rand(3,8);
		$headerstrings['Accept-Language'] = 'en-us,en;q=0.'.rand(4,6);
		$setHeaders =     'Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5'."\r\n".
						'Accept-Charset: '.$headerstrings['Accept-Charset']."\r\n".
						'Accept-Language: '.$headerstrings['Accept-Language']."\r\n".
						'User-Agent: '.$headerstrings['User-Agent']."\r\n";
		$contextOptions = array(
			'http'=>array(
				'method'=>"GET",
				'header'=>$setHeaders
			)
		);
		return stream_context_create($contextOptions);
	}
	
}

/************************************************************ 
  *  描述：HTTP操作类 
  *  作者：heiyeluren 
  *  修改/优化: 朦胧中的罪恶
  *  email:colt.hawkins@gmail.com
  * 
  ************************************************************/  

/** 
 * HTTP功能工厂方法类 
 *
 */  
class Http {  
	/** 
	 * @var 使用 CURL 
	 */  
	const TYPE_CURL   = 1;  
	/** 
	 * @var 使用 Socket 
	 */   
	const TYPE_SOCK   = 2;  
	/** 
	 * @var 使用 Stream 
	 */   
	const TYPE_STREAM  = 3;  
	/**
	 * http 静态实例
	 */
	protected static $_instance = null;

	/** 
	 * 保证对象不被clone 
	 */  
	protected function __clone() {}  

	/** 
	 * 构造函数 
	 */  
	protected function __construct() {}  
   
   
	/** 
	 * HTTP工厂操作方法 
	 * 
	 * @param string $url 需要访问的URL 
	 * @param int $type 需要使用的HTTP类 
	 * @return object 
	 */  
	public static function factory($url = '', $type = self::TYPE_SOCK) {  
		if (self::$_instance instanceof Http_Basic) {
			return self::$_instance;
		}
		if ($type == '') {  
			$type = self::TYPE_SOCK;  
		}
		switch($type) {  
			case self::TYPE_CURL :  
				if (!function_exists('curl_init')) {  
					throw new Exception(__CLASS__ . " PHP CURL extension not install");  
				}  
				self::$_instance = new Http_Curl($url);  
				break;  
			case self::TYPE_SOCK :  
				if (!function_exists('fsockopen')) {  
					throw new Exception(__CLASS__ . " PHP function fsockopen() not support");  
				}      
				self::$_instance = new Http_Sock($url);  
				break;  
			case self::TYPE_STREAM :  
				if (!function_exists('stream_context_create')) {  
					throw new Exception(__CLASS__ . " PHP Stream extension not install");  
				}      
				self::$_instance = new Http_Stream($url);  
				break;  
				default:  
				throw new Exception("http access type $type not support");  
		}  
		return self::$_instance;
	}  
	
	
	/** 
	 * 生成一个供Cookie或HTTP GET Query的字符串 
	 * 
	 * @param array $data 需要生产的数据数组，必须是 Name => Value 结构 
	 * @param string $sep 两个变量值之间分割的字符，缺省是 &  
	 * @return string 返回生成好的Cookie 查询字符串 
	 */  
	public static function makeQuery($data, $sep = '&'){  
		$encoded = '';  
		while (list($k,$v) = each($data)) {   
			$encoded .= ($encoded ? "$sep" : "");  
			$encoded .= rawurlencode($k) ."=". rawurlencode($v);   
		}   
		return $encoded;
	}
}  
   
abstract class Http_Basic {
	/** 
	 * @var object 对象单例 
	 */  
	static $_instance = NULL;  

	/** 
	 * @var string 需要发送的cookie信息 
	 */  
	protected $cookies = '';  
	/** 
	 * @var array 需要发送的头信息 
	 */  
	protected $header = array();  
	/** 
	 * @var string 需要访问的URL地址 
	 */   
	protected $uri = '';  
	/** 
	 * @var array 需要发送的数据 
	 */  
	protected $vars = array(); 
	/** 
	 * 保证对象不被clone 
	 */  
	protected function __clone() {}
	
	/** 
	 * 构造函数 
	 * 
	 * @param string $configFile 配置文件路径 
	 */  
	public function __construct($url) {  
		$this->uri = $url;  
	}  

	/** 
	 * 设置需要发送的HTTP头信息 
	 *  
	 * @param array/string 需要设置的头信息，可以是一个 类似 array('Host: example.com', 'Accept-Language: zh-cn') 的头信息数组 
	 *       或单一的一条类似于 'Host: example.com' 头信息字符串 
	 * @return void 
	 */  
	public function setHeader($header) {  
		if (empty($header)) {  
			return;  
		}
		if (is_array($header)) {  
			foreach ($header as $k => $v){  
				$this->header[] = is_numeric($k) ? trim($v) : (trim($k) .": ". trim($v));      
			}  
		} elseif (is_string($header)) {  
			$this->header[] = $header;  
		}  
	}  
	
	/** 
	* 设置Cookie头信息 
	*  
	* 注意：本函数只能调用一次，下次调用会覆盖上一次的设置 
	* 
	* @param string/array 需要设置的 Cookie信息，一个类似于 'name1=value1&name2=value2' 的Cookie字符串信息， 
	*         或者是一个 array('name1'=& gt;'value1', 'name2'=>'value2') 的一维数组 
	* @return void 
	*/  
	public function setCookie($cookie){  
		if (empty($cookie)) {  
			return;  
		}  
		if (is_array($cookie)) {  
			$this->cookies = Http::makeQuery($cookie, ';');  
		} elseif (is_string($cookie)) {  
			$this->cookies = $cookie;  
		}  
	}  
	
	/** 
	 * 设置要发送的数据信息 
	 * 
	 * 注意：本函数只能调用一次，下次调用会覆盖上一次的设置 
	 * 
	 * @param array 设置需要发送的数据信息，一个类似于 array('name1'=>'value1', 'name2'=>'value2') 的一维数组 
	 * @return void 
	 */  
	public function setVar($vars) {  
		if (empty($vars)) {  
			return;  
		}  
		if (is_array($vars)) {  
			$this->vars = $vars;  
		}   
	}  
	
	/** 
	 * 设置要请求的URL地址 
	 * 
	 * @param string $url 需要设置的URL地址 
	 * @return void 
	 */  
	public function setUrl($url) {  
		if ($url != '') {  
			$this->uri = $url;  
		}  
	}  
	 
   
	/** 
	 * 发送HTTP GET请求 
	 * 
	 * @param string $url 如果初始化对象的时候没有设置或者要设置不同的访问URL，可以传本参数 
	 * @param array $vars 需要单独返送的GET变量 
	 * @param array/string 需要设置的头信息，可以是一个 类似 array('Host: example.com', 'Accept-Language: zh-cn') 的头信息数组 
	 *         或单一的一条类似于 'Host: example.com' 头信息字符串 
	 * @param string/array 需要设置的Cookie信息，一个类似于 'name1=value1&name2=value2' 的Cookie字符串信息， 
	 *         或者是一个 array('name1'=& gt;'value1', 'name2'=>'value2') 的一维数组 
	 * @param int $timeout 连接对方服务器访问超时时间，单位为秒 
	 * @param array $options 当前操作类一些特殊的属性设置 
	 * @return unknown 
	 */  
	public function get($url = '', $vars = array(), $header = array(), $cookie = '', $timeout = 5, $options = array()){  
		$this->setUrl($url);  
		$this->setHeader($header);  
		$this->setCookie($cookie);  
		$this->setVar($vars);  
		return $this->send('GET', $timeout);  
	}   
	
   
	/** 
	 * 发送HTTP POST请求 
	 * 
	 * @param string $url 如果初始化对象的时候没有设置或者要设置不同的访问URL，可以传本参数 
	 * @param array $vars 需要单独返送的GET变量 
	 * @param array/string 需要设置的头信息，可以是一个 类似 array('Host: example.com', 'Accept-Language: zh-cn') 的头信息数组 
	 *         或单一的一条类似于 'Host: example.com' 头信息字符串 
	 * @param string/array 需要设置的Cookie信息，一个类似于 'name1=value1&name2=value2' 的Cookie字符串信息， 
	 *         或者是一个 array('name1'=& gt;'value1', 'name2'=>'value2') 的一维数组 
	 * @param int $timeout 连接对方服务器访问超时时间，单位为秒 
	 * @param array $options 当前操作类一些特殊的属性设置 
	 * @return unknown 
	 */  
	public function post($url = '', $vars = array(), $header = array(), $cookie = '', $timeout = 5, $options = array()) {  
		$this->setUrl($url);  
		$this->setHeader($header);  
		$this->setCookie($cookie);  
		$this->setVar($vars);  
		return $this->send('POST', $timeout);  
	}
	
	protected function unchunkHttp11($data) {
		$fp = 0;
		$outData = '';
		while ($fp < strlen($data)) {
			$rawnum = substr($data, $fp, strpos(substr($data, $fp), "\r\n") + 2);
			$num = hexdec(trim($rawnum));
			$fp += strlen($rawnum);
			$chunk = substr($data, $fp, $num);
			$outData .= $chunk;
			$fp += strlen($chunk);
		}
		return $outData;
	}
}


 
   
   
 /** 
  * 使用CURL 作为核心操作的HTTP访问类 
  * 
  * @desc CURL 以稳定、高效、移植性强作为很重要的HTTP 协议访问客户端，必须在PHP中安装 CURL 扩展才能使用本功能 
  */  
class Http_Curl extends Http_Basic {
	/** 
	 * 发送HTTP请求核心函数 
	 * 
	 * @param string $method 使用GET还是 POST方式访问 
	 * @param array $vars 需要另外附加发送的GET/POST数据 
	 * @param int $timeout 连接对方服务器访问超时时间，单位为秒 
	 * @param array $options 当前操作类一些特殊的属性设置 
	 * @return string 返回服务器端读取的返回数据 
	 */  
	public function send($method = 'GET', $timeout = 5, $options = array()) {  
		// 处理参数是否为空  
		if ($this->uri == '') {  
			throw new Exception(__CLASS__ .": Access url is empty");  
		}  

		// 初始化CURL  
		$ch = curl_init();  
		curl_setopt($ch, CURLOPT_HEADER, 0);  
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);  
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
		curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);  

		// 设置特殊属性  
		if (!empty($options)){  
			curl_setopt_array($ch , $options);  
		}          
		// 处理GET请求参数  
		if ($method == 'GET' && !empty($this->vars)) {  
			$query = Http::makeQuery($this->vars);  
			$parse = parse_url($this->uri);  
			$sep = isset($parse['query'])  ?  '&'  : '?';  
			$this->uri .= $sep . $query;  
		}  
		// 处理POST请求数据  
		if ($method == 'POST'){  
			curl_setopt($ch, CURLOPT_POST, 1 );  
			curl_setopt($ch, CURLOPT_POSTFIELDS, $this->vars);  
		}  

		// 设置cookie信息  
		if (!empty($this->cookies)) {  
			curl_setopt($ch, CURLOPT_COOKIE, $this->cookies);  
		}  
		// 设置HTTP缺省头  
		if (empty($this->header)) {  
			$this->header = array(  
				'User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; InfoPath.1)',  
				//'Accept-Language: zh-cn',            
				//'Cache-Control: no-cache',  
			);  
		}  
		curl_setopt($ch, CURLOPT_HTTPHEADER, $this->header);  
		// 发送请求读取输数据  
		curl_setopt($ch, CURLOPT_URL, $this->uri);          
		$data = curl_exec($ch);  
		if ($err = curl_error($ch)) {  
			curl_close($ch);  
			throw new  Exception(__CLASS__ ." error: ". $err);  
		}  
		curl_close($ch);  
		return $data;  
	}
}  
   
   
   
   
/** 
 * 使用 Socket操作(fsockopen) 作为核心操作的HTTP访问接口 
 * 
 * @desc Network/fsockopen 是PHP 内置的一个Sokcet网络访问接口，必须安装/打开 fsockopen 函数本类才能工作， 
 *    同时确保其他相关网络环境和配置是正确的 
 */  
class Http_Sock extends Http_Basic {
	/** 
	 * 发送HTTP请求核心函数 
	 * 
	 * @param string $method 使用GET还是 POST方式访问 
	 * @param array $vars 需要另外附加发送的GET/POST数据 
	 * @param int $timeout 连接对方服务器访问超时时间，单位为秒 
	 * @param array $options 当前操作类一些特殊的属性设置 
	 * @return string 返回服务器端读取的返回数据 
	 */  
	public function send($method = 'GET', $timeout = 5, $options = array()) {  
		//处理参数是否为空  
		if ($this->uri == ''){  
			throw new Exception(__CLASS__ .": Access url is empty");  
		}  

		// 处理GET请求参数  
		if ($method == 'GET' && !empty($this->vars)){  
			$query = Http::makeQuery($this->vars);  
			$parse = parse_url($this->uri);  
			$sep = isset($parse['query'])&&($parse['query']!='')  ?  '&'  : '?';  
			$this->uri .= $sep . $query;  
		}  

		// 处理POST请求数据  
		$data = '';  
		if ($method == 'POST' && !empty($this->vars)){  
			$data = Http::makeQuery($this->vars);  
			$this->setHeader('Content-Type: application/x-www-form-urlencoded');    
			$this->setHeader('Content-Length: '. strlen($data));  
		}  

		//解析URL地址  
		$url = parse_url($this->uri);  
		$host = $url['host'];  
		$port = isset($url['port']) && ($url['port']!='') ? $url['port'] : 80;  
		$path = isset($url['path']) && ($url['path']!='') ? $url['path'] : '/';  
		$path .= isset($url['query']) ? "?". $url['query'] : '';  

		// 组织HTTP请求头信息  
		array_unshift($this->header, $method ." ". $path ." HTTP/1.1");  
		$this->setHeader('User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; InfoPath.1)');  
		if (!preg_match("/^[\d]{1,3}\.[\d]{1,3}\.[\d]{1,3}\.[\d]{1,3}$/", $host)) {  
			$this->setHeader("Host: ".$host);  
		}  
		if ($this->cookies != ''){  
			$this->setHeader("Cookie: ". $this->cookies);  
		}
		$this->setHeader("Connection: keep-alive");  
		//'Accept-Language: zh-cn',  
		//'Cache-Control: no-cache',  

		// 构造请求信息  
		$header = '';  
		foreach ($this->header as $h) {  
			$header .= $h ."\r\n";  
		}  
		$header .= "\r\n";  
		if ($method == 'POST' && $data != ''){  
			$header .= $data ."\r\n";  
		}  

		// 连接服务器发送请求数据  
		$ip = gethostbyname($host);  
		if (!($fp = fsockopen($ip, $port, $errno, $errstr, $timeout))){  
			throw new Exception(__CLASS__ .": Can't connect $host:$port, errno:$errno,message:$errstr");  
		}  

		fputs($fp, $header);  
		$lineSize = 1024;    

		// 处理301,302跳转页面访问  
		$line = fgets($fp, $lineSize);  
		$first = preg_split("/\s/", trim($line));  
		if ( isset($first[1]) && in_array($first[1], array('301','302')) ){  
			while (!feof($fp)) {     
				$line = fgets($fp, $lineSize);  
				$second = preg_split("/\s/", trim($line));  
				if (ucfirst(trim($second[0]))=='Location:' && $second[1]!='') {  
					$this->header = array();  
					return $this->get(trim($second[1]));  
				}  
			}  
		}  

		$response = '';
		while (!feof($fp)) {
			$response .= fgets($fp, 1160);
		}
		
		die($response);
		// 取内容
		$data = substr($response, (strpos($response, "\r\n\r\n") + 4));
		// 处理分块传输的数据
		if (strpos(strtolower($response), 'transfer-encoding: chunked') !== FALSE) {
			$data = $this->unchunkHttp11($data);
		}
		fclose($fp);
		return $data;   
	}
}  
   

/** 
 * 使用文件流操作函数为核心操作的HTTP访问接口 
 * 
 * @desc stream_* 和 fopen/file_get_contents 是 PHP内置的一个流和文件操作接口，必须打开 fsockopen 函数本类才能工作， 
 *    同时确保其他相关网络环境和配置是正确的，包括 allow_url_fopen 等设置 
 */  
class Http_Stream extends Http_Basic {
	/** 
	 * 发送HTTP请求核心函数 
	 * 
	 * @param string $method 使用GET还是 POST方式访问 
	 * @param array $vars 需要另外附加发送的GET/POST数据 
	 * @param int $timeout 连接对方服务器访问超时时间，单位为秒 
	 * @param array $options 当前操作类一些特殊的属性设置 
	 * @return string 返回服务器端读取的返回数据 
	 */  
	public function send($method = 'GET', $timeout = 5, $options = array()){  
		// 处理参数是否为空  
		if ($this->uri == ''){  
			throw new Exception(__CLASS__ .": Access url is empty");  
		}  
		$parse = parse_url($this->uri);  
		$host = $parse['host'];  

		// 处理GET请求参数  
		if ($method == 'GET' && !empty($this->vars)){  
			$query = Http::makeQuery($this->vars);  
			$sep = isset($parse['query'])&&($parse['query']!='')  ?  '&'  : '?';  
			$this->uri .= $sep . $query;   
		}  


		// 处理POST请求数据  
		$data = '';  
		if ($method == 'POST' && !empty($this->vars)){  
			$data = Http::makeQuery($this->vars);   
		}  

		// 设置缺省头  
		$this->setHeader('User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; InfoPath.1)');  
		if (!preg_match("/^[\d]{1,3}\.[\d]{1,3}\.[\d]{1,3}\.[\d]{1,3}$/", $host)){  
			$this->setHeader("Host: ".$host);  
		}  
		if ($this->cookies != ''){  
			$this->setHeader("Cookie: ". $this->cookies);  
		}  
		$this->setHeader("Connection: Close");  
		//'Accept-Language: zh-cn',  
		//'Cache-Control: no-cache',          

		//构造头信息  
		$opts = array(  
			'http' => array(  
				'method'   => $method,  
				'timeout'  => $timeout,  
			)  
		);  
		if ($data != ''){  
			$opts['http']['content'] = $data;  
		}  
		$opts['http']['header'] = '';  
		foreach ($this->header as $h){  
			$opts['http']['header'] .= $h . "\r\n";  
		} 

		// 读取扩展设置选项  
		if (!empty($options)) {  
			isset($options['proxy']) ? $opts['http']['proxy'] = $options['proxy'] : '';           
			isset($options['max_redirects']) ? $opts['http']['max_redirects'] = $options['max_redirects'] : '';  
			isset($options['request_fulluri']) ? $opts['http']['request_fulluri'] = $options['request_fulluri'] : '';  
		}  

		// 发送数据返回  
		$context = stream_context_create($opts);  
		if (($buf = file_get_contents($this->uri, null, $context)) === false) {  
			throw new Exception(__CLASS__ .": file_get_contents(". $this->uri .") fail");  
		}
		return $buf;    
	}
}
