<?php
/*
Extend Name: Hype数字产品企业单页
Version: 1.0.1
Description: Hype数字产品企业单页
Author: 二呆
ForEmlog: 6.1.1
Author URL: https://www.tongleer.com
*/
include "../../init.php";
error_reporting(7);
$db=Database::getInstance();
HypePageInitData();
HypePageCreateSubscribeTable($db);
$HypePageOption=HypePageGetData();
global $CACHE;
$Log_Model=new Log_Model();
?>
<?php
$action = isset($_POST['action']) ? addslashes(trim($_POST['action'])) : '';
if($action=="updateHypePageBasic"){
	if(ROLE==ROLE_ADMIN){
		$_POST=HypePageAddslashesArr($_POST);
		$HypePageOption["title"]=$_POST["title"];
		$HypePageOption["keywords"]=$_POST["keywords"];
		$HypePageOption["description"]=$_POST["description"];
		$HypePageOption["icon"]=$_POST["icon"];
		$HypePageOption["logo"]=$_POST["logo"];
		
		$HypePageOption["banner"]=$_POST["banner"];
		$HypePageOption["ad"]=$_POST["ad"];
		$HypePageOption["about"]=$_POST["about"];
		$HypePageOption["product"]=$_POST["product"];
		$HypePageOption["info"]=$_POST["info"];
		
		$db->query("UPDATE `".DB_PREFIX."options` SET `option_value`='".addslashes(serialize($HypePageOption))."' WHERE `option_name`='tlepage:HypePage'");
	}
	exit;
}else if($action=="subscribeEmail"){
	$email = isset($_POST['email']) ? addslashes($_POST['email']) : '';
	$subscribe = $db -> once_fetch_array("SELECT * FROM `".DB_PREFIX."tlepage_hypepage_subscribe` WHERE `hypepage_subscribe_email` = '".$email."'");
	if(empty($subscribe)){
		$data=array("hypepage_subscribe_email"=>$email);
		$kItem = array();
		$dItem = array();
		foreach ($data as $key => $data) {
			$kItem[] = $key;
			$dItem[] = $data;
		}
		$field = implode(',', $kItem);
		$values = "'" . implode("','", $dItem) . "'";
		$db->query("INSERT INTO " . DB_PREFIX . "tlepage_hypepage_subscribe ($field) VALUES ($values)");
	}
	exit;
}else if($action=="clearSubscribeEmail"){
	if(ROLE==ROLE_ADMIN){
		$db->query("truncate " . DB_PREFIX . "tlepage_hypepage_subscribe");
		echo "清空成功";
	}
	exit;
}else if($action=="sendSubscribeEmail"){
	if(ROLE==ROLE_ADMIN){
		$articleId = isset($_POST['sendSubscribeArticleId']) ? addslashes($_POST['sendSubscribeArticleId']) : 0;
		$subscribe = $db -> once_fetch_array("SELECT * FROM `".DB_PREFIX."tlepage_hypepage_subscribe`");
		if(empty($subscribe)){
			echo "订阅邮箱为空";
			exit;
		}
		$blog = $db -> once_fetch_array("SELECT * FROM `".DB_PREFIX."blog` WHERE gid=".$articleId);
		$blogname = Option::get('blogname');
		$subject = '【'.$blogname.'】'.$blog["title"];
		$content = preg_replace("/\[hide\](.*)\[\/hide\]/Uims", '', $blog["content"]);
		$content = preg_replace("/\[[c|l]v\](.*?)\[\/[c|l]v\]/is", '', $content);
		
		$content = '<style type="text/css">.qmbox{margin:0;padding:0;font-family:微软雅黑;background-color:#fff}.qmbox a{text-decoration:none;}.qmbox .box{position:relative;width:780px;padding:0;margin:0 auto;border:1px solid #ccc;font-size:13px;color:#333;}.qmbox .header{width:100%;padding-top:50px;}.qmbox .logo{float:right;padding-right:50px;}.qmbox .clear{clear:both;}.qmbox .content{width:585px;padding:0 50px;}
			.qmbox .content p{line-height:40px;word-break:break-all;}.qmbox .content ul{padding-left:40px;}
			.qmbox .xiugai{height:50px;line-height:30px;font-size:16px;}.qmbox .xiugai a{color:#0099ff;}
			.qmbox .fuzhi{word-break:break-all;color:#b0b0b0;}.qmbox .table{border:1px solid #ccc;border-left:0;border-top:0;border-collapse:collapse;}
			.qmbox .table td{border:1px solid #ccc;border-right:0;border-bottom:0;padding:6px;min-width:160px;}.qmbox .gray{background:#f5f5f5;}
			.qmbox .no_indent{font-weight:bold;height:40px;line-height:40px;color:#737171}.qmbox .no_indent a{text-decoration:none !important;color:#737171}.qmbox .no_indent span{padding-right:20px;}.qmbox .no_after{height:40px;line-height:40px; text-align:right;font-weight:bold}
			.qmbox .btnn{padding:50px 0 0 0;font-weight:bold}.qmbox .btnn a{padding-right:20px;text-decoration:none !important;color:#000;}.qmbox .need{background:#fa9d00;}
			.qmbox .noneed{background:#3784e0;}.qmbox .footer{width:100%;height:10px;padding-top:20px;}</style><div class="qmbox"><div class="box"><div class="header"></div><div class="content">
			<p>欢迎订阅'.$blogname.'</p>
			<p class="no_indent" style="color:#383838">《'.$blog["title"].'》：</p><p style="line-height:25px;padding:10px;background:#5C96BE;border-radius:4px;color:#fff;">'.$content.'</p
			>
			<p>时间：'.date("Y-m-d",$blog["date"]).'</p>
			<p>本邮件为'.$blogname.'自动发送，请勿直接回复</p>
			<table cellspacing="0" class="table">	</table><div class="btnn"><a href="'.Url::log($blog["gid"]).'" target="_blank">查看该文章</a></div></div><div class="footer clear"></div></div></div>';
		
		$res = $db->query("SELECT * FROM ".DB_PREFIX."tlepage_hypepage_subscribe");
		$subscribeEmail = array();
		while($row = $db->fetch_array($res)) {
			$subscribeEmail[] = $row;
		}
		$countFlag=0;
		foreach($subscribeEmail as $value){
			if(sendmail_do(MAIL_SMTP, MAIL_PORT, MAIL_SENDEMAIL, MAIL_PASSWORD, $value["hypepage_subscribe_email"], $subject, $content,$blogname)){
				
			}else{
				$countFlag++;
			}
		}
		if($countFlag==0){
			echo "群发成功";
		}else{
			echo "部分订阅邮箱群发失败";
		}
	}
	exit;
}
?>
<!doctype html>
<html lang="zh-cn">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title><?=!empty($HypePageOption["title"])?$HypePageOption["title"]:"Hype";?></title>
	<meta name="keywords" content="<?=!empty($HypePageOption["keywords"])?$HypePageOption["keywords"]:"";?>">
	<meta name="description" content="<?=!empty($HypePageOption["description"])?$HypePageOption["description"]:"";?>">
	<link rel="shortcut icon" href="<?=!empty($HypePageOption["icon"])?$HypePageOption["icon"]:"";?>" type="image/x-icon">
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli:400,600,700&display=swap" rel="stylesheet">
  </head>
  <body id="home">
	<section class=" w3l-header-4 header-sticky">
        <header class="absolute-top">
            <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <h1><a class="navbar-brand" href="">
					<span class="<?=!empty($HypePageOption["logo"])?$HypePageOption["logo"]:"";?>" aria-hidden="true"></span>
					<?=!empty($HypePageOption["title"])?$HypePageOption["title"]:"Hype";?>
                </a></h1>
                <button class="navbar-toggler bg-gradient" type="button" data-toggle="collapse"
                    data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
          
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
						<?php
						$navi_cache = $CACHE->readCache('navi');
						foreach($navi_cache as $value){
							if ($value['pid'] != 0) {
								continue;
							}
							if($value['url'] == ADMIN_DIR && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)){
								?>
								<li class="nav-item">
									<a class="nav-link" href="<?php echo BLOG_URL.ADMIN_DIR; ?>/">管理站点</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="<?php echo BLOG_URL.ADMIN_DIR; ?>/?action=logout">退出</a>
								</li>
								<?php 
								continue;
							}
							$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
							$value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
							$current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'current' : 'common';
							?>
							<li class="nav-item">
								<a class="nav-link" href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a>
							</li>
							<?php
							if (!empty($value['children'])){
								foreach ($value['children'] as $row){
									?>
									<li class="nav-item">
										<li><a class="nav-link" href="<?=Url::sort($row['sid']);?>"><?=$row['sortname'];?></a></li>
									</li>
									<?php
								}
							}?>

							<?php
							if (!empty($value['childnavi'])){
								foreach ($value['childnavi'] as $row){
									$newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';
									?>
									<li class="nav-item">
										<a class="nav-link" href="<?=$row['url'];?>"><?=$row['naviname'];?></a>
									</li>
									<?php
								}
							}
						}
						?>
                    </ul>
                    <ul class="navbar-nav search-righ">
                        <li class="nav-item" title="Search"><a href="#search" class="btn search-search"><i class="fa fa-search mr-2" aria-hidden="true"></i>搜索</a></li>
                    </ul>
                    <!-- search popup -->
                    <div id="search" class="pop-overlay">
                        <div class="popup">
                            <form action="<?php echo BLOG_URL; ?>index.php" method="GET" class="d-flex">
                                <input type="search" placeholder="输入关键字.." name="keyword" required="required" autofocus>
                                <button type="submit">搜索</button>
                                <a class="close" href="#">&times;</a>
                            </form>
                        </div>
                    </div>
                    <!-- /search popup -->
                </div>
            </div>
  
            </nav>
        </div>
          </header>
    </section>

    <!-- Common jquery plugin <script src="assets/js/jquery-3.3.1.min.js"></script>-->
	<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
    <!--bootstrap working-->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- //bootstrap working-->
<!-- disable body scroll which navbar is in active -->
<script>
    $(function () {
      $('.navbar-toggler').click(function () {
        $('body').toggleClass('noscroll');
      })
	  
	  $("#basicForm").submit(function(){
		var formData = new FormData($("#basicForm")[0]);
		$.ajax({
			url:"",
			type: 'POST',
			data: formData,
			dataType:"text",
			contentType: false,
			processData: false,
			success:function(data){
				window.location.reload();
			}
		});
		return false;
	  });
	  
	  $("#subscribeForm").submit(function(){
		var formData = new FormData($("#subscribeForm")[0]);
		$.ajax({
			url:"",
			type: 'POST',
			data: formData,
			dataType:"text",
			contentType: false,
			processData: false,
			success:function(data){
				alert("订阅成功");
			}
		});
		return false;
	  });
	  
	  $("#clearSubscribeEmail").click(function(){
		$.ajax({
			url:"",
			type: 'POST',
			data: {action:"clearSubscribeEmail"},
			dataType:"text",
			success:function(data){
				alert(data);
			}
		});
		
	  });
	  
	  $("#sendSubscribeEmail").click(function(){
		if($("#sendSubscribeArticleId").val()==""){
			alert("输入需要群发至订阅邮箱的文章ID");
			return;
		}
		$.ajax({
			url:"",
			type: 'POST',
			data: {action:"sendSubscribeEmail",sendSubscribeArticleId:$("#sendSubscribeArticleId").val()},
			dataType:"text",
			success:function(data){
				alert(data);
			}
		});
	  });
    });
</script>
<!-- disable body scroll which navbar is in active -->

<?php
$banner=json_decode($HypePageOption["banner"],true);
if($banner){
?>
<div class="w3l-hero-headers-9">
    <section class="slide slide-one">
      <div class="container">
        <!-- <div class="row"> -->
          <div class="row">
        <div class="banner-text col-lg-5">
          <h5><?=!empty($banner["banner_title"])?$banner["banner_title"]:"";?><br><?=!empty($banner["banner_subtitle"])?$banner["banner_subtitle"]:"";?></h5>
          <p><?=!empty($banner["banner_desc"])?$banner["banner_desc"]:"";?></p>
          <a href="<?=!empty($banner["banner_href"])?$banner["banner_href"]:"";?>" class="btn logo-button top-margin"><?=!empty($banner["banner_btn"])?$banner["banner_btn"]:"";?></a>
          <h6 class="para"><?=!empty($banner["banner_remarks"])?$banner["banner_remarks"]:"";?></h6>
        </div>
        <div class="image-postion col-lg-7">
          <img src="<?=!empty($banner["banner_img"])?$banner["banner_img"]:"";?>" alt="product" class="img-responsive banner-images">
        </div>
        
      </div>
      <!-- </div> -->
    </div>
    </section>
</div>
<?php
}
?>
<?php
$ad=json_decode($HypePageOption["ad"],true);
if($ad){
?>
<section class="w3l-call-to-action_9">
    <div class="call-w3">
        <div class="container">
            <div class=" main-cont-wthree-2">
                <div class="left-contect-calls text-center">

                  <div class="call-grids-w3 ">
						<?php if($ad["ad1"]){?>
                        <div class="grids-effect-2">
                            <img src="<?=$ad["ad1"];?>" alt="">
                        </div>
						<?php }?>
						<?php if($ad["ad2"]){?>
                        <div class=" grids-effect-2">
                            <img src="<?=$ad["ad2"];?>" alt="">
                        </div>
						<?php }?>
						<?php if($ad["ad3"]){?>
                        <div class="grids-effect-2">
                            <img src="<?=$ad["ad3"];?>" alt="">
                        </div>
						<?php }?>
						<?php if($ad["ad4"]){?>
                        <div class="grids-effect-2">
                            <img src="<?=$ad["ad4"];?>" alt="">
                        </div>
						<?php }?>
						<?php if($ad["ad5"]){?>
                        <div class="grids-effect-2">
                            <img src="<?=$ad["ad5"];?>" alt="">
                        </div>
						<?php }?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
}
?>
<?php
$about=json_decode($HypePageOption["about"],true);
if($about){
?>
<section class="w3l-teams-15">

	<div class="team-single-main">
		<div class="container">
			<div class=" grid grid-column-2 row">
				<div class="column1 col-lg-6">
					<img src="<?=!empty($about["about_img"])?$about["about_img"]:"";?>" alt="product" class="img-responsive ">
				</div>
				<div class="column2 col-lg-6">
					<h3 class="team-head"><?=!empty($about["about_title"])?$about["about_title"]:"";?></h3>
					<p class="para text"><?=!empty($about["about_desc"])?$about["about_desc"]:"";?></p>
						<p class="para mt-2 dis-none"><?=!empty($about["about_hidden"])?$about["about_hidden"]:"";?></p>
				</div>
			</div>
		</div>
	</div>
</section>
<?php
}
?>
<section class="w3l-specification-6">
    <div class="specification-layout">
        <div class="container">
            <div class="main-titles-head">

                <h3 class="header-name">最新资讯</h3>
              
            </div>
            <div class="specification-effect row text-center">
				<?php 
				$logs = $Log_Model->getLogsForHome("ORDER BY top DESC ,date DESC", 1, 6);
				if (!empty($logs)){
					$i=0;foreach($logs as $value){
						if($i>5){continue;}
					?>
					<div class="grids-effect-2 col-lg-4 col-md-6 col-sm-6 mt-4 pt-1">
						<div class="back-color">
							<img src="<?=$value["thumbs"];?>" width="300" />
							<h4><a href="<?=Url::log($value["gid"]);?>" class="title-head"><?=subString($value["title"], 0,25);?></a></h4>
							<p class="para"><?=subString($value["content"], 0,140);?></p>
						</div>
					</div>
					<?php
					$i++;
					}
				}
				?>
			</div>
        </div>
    </div>
</section>

<!-- grids block 4 -->
<?php
$product=json_decode($HypePageOption["product"],true);
if($product){
?>
<section class="w3l-grids-7">
    <div class="grids4-block">
        <div class="container">
			<div class="row">
				<div class="column-text col-lg-6">
					<h3 class="team-head"><?=!empty($product["product_title"])?$product["product_title"]:"";?></h3>
					<p class="para text"><?=!empty($product["product_desc"])?$product["product_desc"]:"";?></p>
					<?php
					if($product["product_article_ids"]){
						$product_article_ids = explode(',', $product["product_article_ids"]);
						$product_article_idArr = array_unique($product_article_ids);
						foreach ($product_article_idArr as $k => $v) {
							$product_article_idStr.=intval($v).",";
						}
						$product_article_idStr=substr($product_article_idStr, 0, -1);
						if($product_article_idStr){
							$articleIdSql=" AND gid in (".$product_article_idStr.")";
						}else{
							$articleIdSql="";
						}
						$productLogs = $Log_Model->getLogsForHome($articleIdSql." ORDER BY top DESC ,date DESC", 1, 6);
						if (!empty($productLogs)){
							?>
							<div class="call-grids-w3">
								<?php foreach($productLogs as $value){?>
								<div class="grids-1 grids-effect-2">
									<h4><a href="<?=Url::log($value["gid"]);?>" class="title-head"><?=subString($value["title"], 0,25);?></a></h4>
									<p class="para"><?=subString($value["content"], 0,50);?></p>
								</div>
								<?php }?>
							</div>
							<?php
						}
					}
					?>
					<?php
					if($product["product_category_id"]){
						?>
						<a href="<?=Url::sort($product["product_category_id"]);?>" class="btn action-button mt-lg-5 mt-4 ">更多</a>
						<?php
					}
					?>
				</div>
				<div class="col-lg-6">
					<img src="<?=!empty($product["product_img"])?$product["product_img"]:"";?>" alt="product" class="img-responsive ">
				</div>
			</div>
        </div>
    </div>
</section>
<?php
}
?>
<!-- grids block 4 -->

<section class="w3l-clients">
    <div class="main-w3">
        <div class="container">
            <!-- main-slider -->
            <div class="main-titles-head">

                <h3 class="header-name">网站明星</h3>
       
            </div>

            <div class="row">
					<?php
					$res = $db->query("SELECT nickname,username,email,photo,description FROM ".DB_PREFIX."user WHERE role='admin'");
					$users = array();
					while($row = $db->fetch_array($res)) {
						$row['nickname'] = htmlspecialchars($row['nickname']);
						$row['username'] = htmlspecialchars($row['username']);
						$row['email'] = htmlspecialchars($row['email']);
						$row['photo'] = htmlspecialchars($row['photo']);
						$row['description'] = htmlspecialchars($row['description']);
						$users[] = $row;
					}
					foreach($users as $value){
						$host = 'https://secure.gravatar.com';
						$url = '/avatar/';
						$size = '50';
						$rating = 'g';
						$hash = md5(strtolower($value["email"]));
						$avatar = $host . $url . $hash . '?s=' . $size . '&r=' . $rating . '&d=mm';
					?>
                    <div class="col-lg-6 col-md-6 hh14-text">
                        <div class="hh14-info">
                            <img src="<?=$value["photo"]?BLOG_URL."content/".$value["photo"]:$avatar;?>" alt="product" class="img-responsive ">
                            <p class="para mt-3"><?=$value["description"];?></p>
                            <h4><?=$value["nickname"]?$value["nickname"]:$value["username"];?></h4>
                        </div>
                    </div>
					<?php
					}
					?>
            </div>
        </div>
    </div>
</section>

<section class="w3l-footers-20">
	<div class="footers20">
		<div class="container">
			<h2>
				<a class="footer-logo" href="">
					<span class="<?=!empty($HypePageOption["logo"])?$HypePageOption["logo"]:"";?>" aria-hidden="true"></span><?=!empty($HypePageOption["title"])?$HypePageOption["title"]:"Hype";?>
				</a>
			</h2>
			<div class=" row">
				<div class="grid-col col-lg-7 col-md-7">
					<h3>获取最新更新和活动</h3>
					<div class="footer-subscribe mt-4">
						<form action="" method="post" class="input-button" id="subscribeForm">
							<input type="email" name="email" class="form-control" placeholder="输入电子邮箱.." required="">
							<input type="hidden" name="action" value="subscribeEmail" />
							<button class="btn footer-button btn-secondary action-button">订阅</button>
						</form>
					</div>
				</div>
				<div class="col-lg-5 col-md-5 footer-bottom-two">
					<ul>
						<li><a href="#footer" class="btn action-sub-button">联系</a></li>
						<?php
						$banner=json_decode($HypePageOption["banner"],true);
						if($banner){
						?>
						<li>
							<a href="<?=!empty($banner["banner_href"])?$banner["banner_href"]:"";?>" class="btn logo-button top-margin mt-md-3"><?=!empty($banner["banner_btn"])?$banner["banner_btn"]:"";?></a>
						</li>
						<?php
						}
						?>
					</ul>
				</div>

			</div>
			<div class="border-line-bottom"><a name="footer"></a></div>
			<div class="row">
				<div class="grids-content col-lg-2 col-md-2 col-sm-6">
					<h4>页面</h4>
					<div class="footer-nav">
						<?php
						$navi_cache = $CACHE->readCache('navi');
						foreach($navi_cache as $value){
							if ($value['pid'] != 0||$value['type']!=5) {
								continue;
							}
							$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
							$value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
							?>
							<a class="contact-para3" href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a>
							<?php
						}
						?>
					</div>

				</div>
				<div class="grids-content col-lg-3 col-md-3 col-sm-6">
					<h4>信息</h4>
					<?php
					$info=json_decode($HypePageOption["info"],true);
					if($info){
						?>
						<?php if($info["info_email"]){?>
						<a href="mailto:<?=$info["info_email"];?>">
							<p class="contact-text-sub contact-para3"><?=$info["info_email"];?></p>
						</a>
						<?php }?>
						<?php if($info["info_phone"]){?>
						<a href="tel:<?=$info["info_phone"];?>">
							<p class="contact-text-sub contact-para3"><?=$info["info_phone"];?></p>
						</a>
						<?php }?>
						<?php if($info["info_country"]){?>
						<p class="contact-text-sub contact-para3"><?=$info["info_country"];?></p>
						<?php }?>
						<?php if($info["info_address"]){?>
						<p class="contact-text-sub contact-para3"><?=$info["info_address"];?></p>
						<?php }?>
						<?php if($info["info_qq"]||$info["info_weibo"]||$info["info_github"]){?>
						<div class="buttons-teams">
							<a href="http://wpa.qq.com/msgrd?v=3&uin=<?=$info["info_qq"];?>&site=qq&menu=yes"><span class="fa fa-qq" aria-hidden="true"></span></a>
							<a href="<?=$info["info_weibo"];?>"><span class="fa fa-weibo" aria-hidden="true"></span></a>
							<a href="<?=$info["info_github"];?>"><span class="fa fa-github" aria-hidden="true"></span></a>
						</div>
						<?php }?>
						<?php
					}
					?>
				</div>
				<div class="col-lg-7 col-md-7 col-12 copyright-grid ">
					<p class="copy-footer-29">Copyright &copy; <?=date("Y");?>.<a href="<?=BLOG_URL;?>"><?=!empty($HypePageOption["title"])?$HypePageOption["title"]:"Hype";?></a> All rights reserved.</p>
				</div>
			</div>
		</div>
	</div>
	</div>
	</div>
	</div>
</section>

<!-- move top -->
<button onclick="topFunction()" id="movetop" title="Go to top">
	<span class="fa fa-angle-up"></span>
</button>
<script>
	// When the user scrolls down 20px from the top of the document, show the button
	window.onscroll = function () {
		scrollFunction()
	};

	function scrollFunction() {
		if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
			document.getElementById("movetop").style.display = "block";
		} else {
			document.getElementById("movetop").style.display = "none";
		}
	}

	// When the user clicks on the button, scroll to the top of the document
	function topFunction() {
		document.body.scrollTop = 0;
		document.documentElement.scrollTop = 0;
	}
</script>
<!-- /move top -->
</body>

</html>
<?php if(ROLE==ROLE_ADMIN){?>
<form method="post" id="basicForm" name="basicForm" class="w3layouts-contact-fm" action="">
	<div class="row main-cont-sec">
		<div class="col-lg-6 left-cont-contact">
			<div class="form-group input-gap">
				<input class="form-control" type="text" name="title" id="title" placeholder="网站标题" value="<?=!empty($HypePageOption["title"])?$HypePageOption["title"]:"";?>">
			</div>
			<div class="form-group input-gap">
				<input class="form-control" type="text" name="keywords" value="<?=!empty($HypePageOption["keywords"])?$HypePageOption["keywords"]:"";?>" id="keywords" placeholder="网站关键词">
			</div>
			<div class="form-group input-gap">
				<input class="form-control" type="text" id="description" name="description" value="<?=!empty($HypePageOption["description"])?$HypePageOption["description"]:"";?>" placeholder="网站描述">
			</div>
			<div class="form-group input-gap">
				<input class="form-control" type="text" id="logo" name="logo" value="<?=!empty($HypePageOption["logo"])?$HypePageOption["logo"]:"fa fa-line-chart";?>" placeholder="网站logo">
			</div>
			<div class="form-group">
				<input class="form-control" id="icon" name="icon" value="<?=!empty($HypePageOption["icon"])?$HypePageOption["icon"]:"";?>" class="form-control" placeholder="网站标志" />
			</div>
		</div>
		<div class="col-lg-6 right-cont-contact">
			<textarea rows="10" class="form-control" name="banner" id="banner" placeholder="首页大图"><?=!empty($HypePageOption["banner"])?$HypePageOption["banner"]:'
{
"banner_title":"Digital Products",
"banner_subtitle":"for Business",
"banner_desc":"Adipi sicing elit. Quia, aliquid odio gg Lorem ipsum dolor.",
"banner_btn":"Our Service",
"banner_href":"",
"banner_remarks":"Try a <strong>free demo </strong>with all the features.",
"banner_img":"https://ae04.alicdn.com/kf/Uf6359b756376407b8bd986c4492d9967i.jpg"
}';?></textarea>
		</div>
		<div class="col-lg-6 left-cont-contact">
			<textarea rows="10" class="form-control" name="ad" id="ad" placeholder="广告地址"><?=!empty($HypePageOption["ad"])?$HypePageOption["ad"]:'
{
"ad1":"assets/images/log1.png",
"ad2":"assets/images/log2.png",
"ad3":"assets/images/log3.png",
"ad4":"assets/images/log4.png",
"ad5":"assets/images/log5.png"
}';?></textarea>
		</div>
		<div class="col-lg-6 right-cont-contact">
			<textarea rows="10" class="form-control" name="about" id="about" placeholder="关于信息"><?=!empty($HypePageOption["about"])?$HypePageOption["about"]:'
{
"about_title":"A better Business means better Client experience",
"about_img":"https://ae03.alicdn.com/kf/U16bfb5a49d39434688c8e8f3f764e0a2P.jpg",
"about_desc":"Mollitia placeat modi explicabo voluptatum corporis unde? Dicta, provident! Rem adipisci Mollitia placeat modi explicabo voluptatum corporis unde? Dicta, provident! Rem adipisci consectetur adipisicing elit. Deleniti possimus culpa nemo asperiores aperiam mollitia, maiores fugiat tempor Vero est aliquid nisi fugit.",
"about_hidden":"Placeat modi explicabo voluptatum corporis unde? Dicta, provident! Rem adipisci consectetur adipisicing elit. Deleniti possimus culpa nemo asperiores aperiam mollitia, maiores"
}';?></textarea>
		</div>
		<div class="col-lg-6 left-cont-contact">
			<textarea rows="10" class="form-control" name="product" id="product" placeholder="产品介绍（product_article_ids为文章ID并用英文,分割；product_category_id为唯一分类ID。）"><?=!empty($HypePageOption["product"])?$HypePageOption["product"]:'
{
"product_title":"Create Digital Products",
"product_desc":"Mollitia placeat modi explicabo voluptatum corporis unde? Dicta, provident! Rem adipisci Mollitia placeat modi explicabo voluptatum corporis unde? Dicta, provident! Rem adipisci consectetur adipisicing elit.",
"product_article_ids":"1,1",
"product_img":"https://ae03.alicdn.com/kf/U3ef901df63944db0a5f6eef9d1ce839fU.jpg",
"product_category_id":"1"
}';?></textarea>
		</div>
		<div class="col-lg-6 right-cont-contact">
			<textarea rows="10" class="form-control" name="info" id="info" placeholder="个人信息"><?=!empty($HypePageOption["info"])?$HypePageOption["info"]:'
{
"info_email":"diamond0422@qq.com",
"info_phone":"15900001111",
"info_country":"中国",
"info_address":"北京 朝阳",
"info_qq":"2293338477",
"info_weibo":"https://weibo.com/tongleer",
"info_github":"https://github.com/muzishanshi"
}';?></textarea>
		</div>
		<div class="col-lg-6 left-cont-contact">
			<input class="form-control" type="number" id="sendSubscribeArticleId" placeholder="文章ID" />
			<button type="button" id="sendSubscribeEmail" class="btn action-button mt-3">群发文章</button>
		</div>
		<div class="col-lg-6 right-cont-contact">
			<input type="hidden" name="action" value="updateHypePageBasic" />
			<button type="submit" class="btn action-button mt-3">修改</button>
			<button type="button" onClick="location.href='<?=BLOG_URL.ADMIN_DIR."/?action=logout";?>';" class="btn action-button mt-3">退出</button>
			<button type="button" id="clearSubscribeEmail" class="btn action-button mt-3">清空订阅邮箱</button>
		</div>
	</div>
	<div class="form-group-2">
		
	</div>
</form>
<?php }?>
<?php
function HypePageGetPostImg($gid){
	$db = Database::getInstance();
	$rs = $db->once_fetch_array("SELECT content FROM " . DB_PREFIX . "blog WHERE gid = ".$gid);
	$text = $rs['content'];
	$pattern = '/\<img.*?src\=\"(.*?)\"[^>]*>/i';
	$patternMD = '/\!\[.*?\]\((http(s)?:\/\/.*?(jpg|png))/i';
	$patternMDfoot = '/\[.*?\]:\s*(http(s)?:\/\/.*?(jpg|png))/i';
	if (preg_match($patternMDfoot, $text, $img)) {
		$img_url = $img[1];
	} else if (preg_match($patternMD, $text, $img)) {
		$img_url = $img[1];
	} else if (preg_match($pattern, $text, $img)) {
		preg_match("/(?:\()(.*)(?:\))/i", $img[0], $result);
		$img_url = $img[1];
	} else {
		$img_url ='';
	}
	return $img_url;
}
function HypePageInitData(){
	$db = Database::getInstance();
	$pageHypePage = $db->query("SELECT * FROM " . DB_PREFIX . "options WHERE option_name = 'tlepage:HypePage'");
	if($db->num_rows($pageHypePage)==0){
		$HypePageOption=serialize(array());
		$db->query("INSERT INTO `".DB_PREFIX."options` (`option_name`,`option_value`) VALUES ('tlepage:HypePage','".$HypePageOption."')");
	}
}
function HypePageGetData(){
	$db = Database::getInstance();
	$pageHypePage = $db->once_fetch_array("SELECT * FROM " . DB_PREFIX . "options WHERE option_name = 'tlepage:HypePage'");
	$HypePageOption=unserialize($pageHypePage["option_value"]);
	return $HypePageOption;
}
function HypePageAddslashesArr($string) { 
	if(is_array($string)) { 
		foreach($string as $key => $val) { 
			$string[$key] = HypePageAddslashesArr($val); 
		} 
	} else { 
		$string = trim($string); 
	} 
	return $string; 
}
function HypePageCreateSubscribeTable($db){
	$db->query('CREATE TABLE IF NOT EXISTS `'.DB_PREFIX.'tlepage_hypepage_subscribe` (
	  `hypepage_subscribe_email` varchar(60) DEFAULT NULL COMMENT "订阅邮箱"
	) DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;');
}
?>