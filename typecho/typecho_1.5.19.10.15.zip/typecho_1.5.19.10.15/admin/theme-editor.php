<?php
include 'common.php';
include 'header.php';
include 'menu.php';

Typecho_Widget::widget('Widget_Themes_Files')->to($files);
?>
      <div class="admin-content-body">
		<div class="am-cf am-padding typecho-page-title">
			<div class="am-fl am-cf">
				<?php include 'page-title.php'; ?>
			</div>
		</div>
		<div class="am-g row typecho-page-main typecho-edit-theme">
			<div class="am-u-sm-12 am-u-md-4 am-u-md-push-8">
				<ul class="am-list am-list-static">
					<li><strong>模板文件</strong></li>
                    <?php while($files->next()): ?>
                    <li <?php if($files->current): ?>class="current"<?php endif; ?>>
                    <a href="<?php $options->adminUrl('theme-editor.php?theme=' . $files->currentTheme() . '&file=' . $files->file); ?>"><?php $files->file(); ?></a></li>
                    <?php endwhile; ?>
				</ul>
			</div>

			<div class="am-u-sm-12 am-u-md-8 am-u-md-pull-4">
				<div class="am-btn-toolbar typecho-option-tabs clearfix">
					<div class="am-btn-group am-btn-group-xs">
						<a href="<?php $options->adminUrl('themes.php'); ?>" class="am-btn am-btn-default"><?php _e('可以使用的外观'); ?></a>
						<a href="<?php $options->adminUrl('theme-editor.php'); ?>" class="am-btn am-btn-primary">
						<?php if ($options->theme == $files->theme): ?>
						<?php _e('编辑当前外观'); ?>
						<?php else: ?>
						<?php _e('编辑%s外观', ' <cite>' . $files->theme . '</cite> '); ?>
						<?php endif; ?>
						</a>
						<?php if (Widget_Themes_Config::isExists()): ?>
						<a href="<?php $options->adminUrl('options-theme.php'); ?>" class="am-btn am-btn-default"><?php _e('设置外观'); ?></a>
						<?php endif; ?>
					</div>
				</div>
				<form method="post" name="theme" id="theme" action="<?php $security->index('/action/themes-edit'); ?>">
					<label for="content" class="sr-only"><?php _e('编辑源码'); ?></label>
					<textarea name="content" id="content" class="w-100 mono" <?php if(!$files->currentIsWriteable()): ?>readonly<?php endif; ?>><?php echo $files->currentContent(); ?></textarea>
					<p class="submit">
						<?php if($files->currentIsWriteable()): ?>
						<input type="hidden" name="theme" value="<?php echo $files->currentTheme(); ?>" />
						<input type="hidden" name="edit" value="<?php echo $files->currentFile(); ?>" />
						<button type="submit" class="am-btn am-btn-primary"><?php _e('保存文件'); ?></button>
						<?php else: ?>
							<em><?php _e('此文件无法写入'); ?></em>
						<?php endif; ?>
					</p>
				</form>
			</div>
		</div>
      </div>
	  <footer class="admin-content-footer">
		<?php
		include 'copyright.php';
		?>
	  </footer>
<?php
include 'common-js.php';
Typecho_Plugin::factory('admin/theme-editor.php')->bottom($files);
include 'footer.php';
?>
