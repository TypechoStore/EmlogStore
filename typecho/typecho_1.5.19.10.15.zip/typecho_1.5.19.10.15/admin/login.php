<?php
include 'common.php';

if ($user->hasLogin()) {
    $response->redirect($options->adminUrl);
}
$rememberName = htmlspecialchars(Typecho_Cookie::get('__typecho_remember_name'));
Typecho_Cookie::delete('__typecho_remember_name');

$bodyClass = 'body-100';

include 'header.php';
?>
<meta name="format-detection" content="telephone=no">
<style>
    .header {
      text-align: center;
    }
    .header h1 {
      font-size: 200%;
      color: #333;
      margin-top: 30px;
    }
    .header p {
      font-size: 14px;
    }
</style>
<div class="header">
  <div class="am-g">
    <h1><?php echo $options->title;?></h1>
    <p><?php echo $options->description;?></p>
  </div>
  <hr />
</div>
<div class="am-g typecho-login-wrap">
  <div class="am-u-lg-6 am-u-md-8 am-u-sm-centered typecho-login">
    <h3><?php _e('登录'); ?></h3>
    <hr>
    <div class="am-btn-group">
    </div>
    <br />

    <form action="<?php $options->loginAction(); ?>" method="post" name="login" role="form" class="am-form">
      <p>
		<label for="name"><?php _e('用户名'); ?>:</label>
		<input type="text" name="name" id="name" value="<?php echo $rememberName; ?>" placeholder="<?php _e('用户名'); ?>" autofocus />
	  </p>
      <p>
      <label for="password"><?php _e('密码'); ?>:</label>
      <input type="password" name="password" id="password" value="" placeholder="<?php _e('密码'); ?>">
      </p>
      <label for="remember-me">
        <input id="remember-me" type="checkbox" name="remember" value="1" id="remember" />
        <?php _e('下次自动登录'); ?>
      </label>
      <div class="am-cf">
		<input type="hidden" name="referer" value="<?php echo htmlspecialchars($request->get('referer')); ?>" />
        <input type="submit" name="" value="<?php _e('登录'); ?>" class="am-btn am-btn-primary am-btn-sm am-fl">
      </div>
    </form>
	<p class="more-link">
		<a href="<?php $options->siteUrl(); ?>"><?php _e('返回首页'); ?></a>
		<?php if($options->allowRegister): ?>
		<a href="<?php $options->registerUrl(); ?>"><?php _e('用户注册'); ?></a>
		<?php endif; ?>
	</p>
    <hr>
    <p>© <?php echo date("Y");?> <?php echo $options->title;?>.</p>
  </div>
</div>
<?php 
include 'common-js.php';
?>
<script>
$(document).ready(function () {
    $('#name').focus();
});
</script>
<?php
include 'footer.php';
?>
