<?php
include 'common.php';
include 'header.php';
include 'menu.php';
?>
      <div class="admin-content-body">
		<div class="am-cf am-padding typecho-page-title">
			<div class="am-fl am-cf">
				<?php include 'page-title.php'; ?>
			</div>
		</div>
		<div class="am-g row typecho-page-main">
			<div class="am-u-sm-12 am-u-md-12">
			  <?php Typecho_Widget::widget('Widget_Options_Permalink')->form()->render(); ?>

			</div>
			
		</div>
      </div>
	  <footer class="admin-content-footer">
		<?php
		include 'copyright.php';
		?>
	  </footer>
<?php
include 'common-js.php';
include 'form-js.php';
?>

<?php include 'footer.php'; ?>
