<?php if(!defined('__TYPECHO_ADMIN__')) exit; ?>
<strong class="am-text-primary am-text-lg">
	<?php echo $menu->title; ?><?php 
    if (!empty($menu->addLink)) {
        echo "<small> / <a href=\"{$menu->addLink}\">" . _t("新增") . "</a></small>";
    }
    ?>
</strong>