<?php
include 'common.php';
include 'header.php';
include 'menu.php';

$stat = Typecho_Widget::widget('Widget_Stat');
?>
      <div class="admin-content-body">
		<div class="am-cf am-padding typecho-page-title">
			<div class="am-fl am-cf">
				<?php include 'page-title.php'; ?>
			</div>
		</div>
		<div class="am-g row typecho-page-main">
			<div class="am-u-sm-12 am-u-md-4 am-u-md-push-8">
			  <div class="am-panel am-panel-default">
				<div class="am-panel-bd">
				  <div class="am-g">
					<div class="am-u-md-4">
					  <a href="http://gravatar.com/emails/" title="<?php _e('在 Gravatar 上修改头像'); ?>"><?php echo '<img class="am-img-circle am-img-thumbnail profile-avatar" src="' . Typecho_Common::gravatarUrl($user->mail, 220, 'X', 'mm', $request->isSecure()) . '" alt="' . $user->screenName . '" />'; ?></a>
					</div>
					<div class="am-u-md-8">
					  <h2><?php $user->screenName(); ?></h2>
					  <p><?php $user->name(); ?></p>
					  <p><?php _e('目前有 <em>%s</em> 篇日志, 并有 <em>%s</em> 条关于你的评论在 <em>%s</em> 个分类中.', $stat->myPublishedPostsNum, $stat->myPublishedCommentsNum, $stat->categoriesNum); ?></p>
					  <p>
						<?php
						if ($user->logged > 0) {
							$logged = new Typecho_Date($user->logged);
							_e('最后登录: %s', $logged->word());
						}
						?>
					  </p>
					</div>
				  </div>
				</div>
			  </div>

			</div>

			<div class="am-u-sm-12 am-u-md-8 am-u-md-pull-4 typecho-content-panel">
				<div class="am-panel-group" id="accordion">
				  <div class="am-panel am-panel-default">
					<div class="am-panel-hd">
					  <h4 class="am-panel-title" data-am-collapse="{parent: '#accordion', target: '#profilePanel'}">
						<?php _e('个人资料'); ?>
					  </h4>
					</div>
					<div id="profilePanel" class="am-panel-collapse am-collapse am-in">
					  <div class="am-panel-bd">
						<?php Typecho_Widget::widget('Widget_Users_Profile')->profileForm()->render(); ?>
					  </div>
					</div>
				  </div>
				  <div class="am-panel am-panel-default">
					<div class="am-panel-hd">
					  <h4 class="am-panel-title" data-am-collapse="{parent: '#accordion', target: '#optionsPanel'}">
						<?php _e('撰写设置'); ?>
					  </h4>
					</div>
					<div id="optionsPanel" class="am-panel-collapse am-collapse">
					  <div class="am-panel-bd">
						<?php Typecho_Widget::widget('Widget_Users_Profile')->optionsForm()->render(); ?>
					  </div>
					</div>
				  </div>
				  <div class="am-panel am-panel-default">
					<div class="am-panel-hd">
					  <h4 class="am-panel-title" data-am-collapse="{parent: '#accordion', target: '#passwordPanel'}"><?php _e('密码修改'); ?>
					  </h4>
					</div>
					<div id="passwordPanel" class="am-panel-collapse am-collapse">
					  <div class="am-panel-bd">
						<?php Typecho_Widget::widget('Widget_Users_Profile')->passwordForm()->render(); ?>
					  </div>
					</div>
				  </div>
				  <?php Typecho_Widget::widget('Widget_Users_Profile')->personalFormList(); ?>
				</div>
			</div>
		</div>
      </div>
	  <footer class="admin-content-footer">
		<?php
		include 'copyright.php';
		?>
	  </footer>
<?php
include 'common-js.php';
include 'form-js.php';
Typecho_Plugin::factory('admin/profile.php')->bottom();
include 'footer.php';
?>
