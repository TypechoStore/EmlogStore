<?php
include 'common.php';
include 'header.php';
include 'menu.php';
?>
    <div class="admin-content-body typecho-list row typecho-page-main">
      <div class="am-cf am-padding typecho-page-title">
			<div class="am-fl am-cf">
				<?php include 'page-title.php'; ?>
			</div>
	  </div>
      <div class="am-g typecho-list-operate clearfix">
		<form method="get">
			<div class="operate am-u-sm-12 am-u-md-6">
			  <div class="am-btn-toolbar typecho-option-tabs">
				<div class="am-btn-group am-btn-group-xs">
				  <button type="button" class="am-btn am-btn-xs" style="height:28px;"><label><i class="sr-only"><?php _e('全选'); ?></i><input type="checkbox" class="typecho-table-select-all" /></label></button>
				  <div class="am-dropdown am-btn-group am-btn-group-xs" data-am-dropdown>
					<button class="am-btn am-dropdown-toggle" data-am-dropdown-toggle><i class="sr-only"><?php _e('操作'); ?></i><?php _e('选中项'); ?> <span class="am-icon-caret-down"></span></button>
					<ul class="am-dropdown-content dropdown-menu">
					  <li><a lang="<?php _e('你确认要删除这些用户吗?'); ?>" href="<?php $security->index('/action/users-edit?do=delete'); ?>"><?php _e('删除'); ?></a></li>
					</ul>
				  </div>
				</div>
			  </div>
			</div>
			<div class="am-u-sm-12 am-u-md-3">
			  <div class="am-input-group am-input-group-sm">
				<input type="text" class="am-form-field" placeholder="<?php _e('请输入关键字'); ?>" value="<?php echo htmlspecialchars($request->keywords); ?>" name="keywords" />
				<span class="am-input-group-btn">
					<button class="am-btn am-btn-default" type="submit"><?php _e('筛选'); ?></button>
					<?php if ('' != $request->keywords): ?>
					<a href="<?php $options->adminUrl('manage-users.php'); ?>" class="am-btn am-btn-default"><?php _e('&laquo; 取消筛选'); ?></a>
					<?php endif; ?>
				</span>
			  </div>
			</div>
		</form>
      </div>

      <div class="am-g">
		<form method="post" name="manage_users" class="am-form operate-form">
			<div class="typecho-table-wrap am-u-sm-12">
				<table class="typecho-list-table am-table am-table-striped am-table-hover table-main">
				  <thead>
				  <tr>
					<th> </th>
					<th> </th>
					<th><?php _e('用户名'); ?></th>
					<th><?php _e('昵称'); ?></th>
					<th class="am-hide-sm-only"><?php _e('电子邮件'); ?></th>
					<th class="am-hide-sm-only"><?php _e('用户组'); ?></th>
				  </tr>
				  </thead>
				  <tbody>
					<?php Typecho_Widget::widget('Widget_Users_Admin')->to($users); ?>
					<?php while($users->next()): ?>
					<tr id="user-<?php $users->uid(); ?>">
						<td><input type="checkbox" value="<?php $users->uid(); ?>" name="uid[]"/></td>
						<td><a href="<?php $options->adminUrl('manage-posts.php?uid=' . $users->uid); ?>" class="balloon-button left size-<?php echo Typecho_Common::splitByCount($users->postsNum, 1, 10, 20, 50, 100); ?>"><?php $users->postsNum(); ?></a></td>
						<td><a href="<?php $options->adminUrl('user.php?uid=' . $users->uid); ?>"><?php $users->name(); ?></a>
						<a href="<?php $users->permalink(); ?>" title="<?php _e('浏览 %s', $users->screenName); ?>"><i class="i-exlink"></i></a>
						</td>
						<td><?php $users->screenName(); ?></td>
						<td><?php if($users->mail): ?><a href="mailto:<?php $users->mail(); ?>"><?php $users->mail(); ?></a><?php else: _e('暂无'); endif; ?></td>
						<td><?php switch ($users->group) {
							case 'administrator':
								_e('管理员');
								break;
							case 'editor':
								_e('编辑');
								break;
							case 'contributor':
								_e('贡献者');
								break;
							case 'subscriber':
								_e('关注者');
								break;
							case 'visitor':
								_e('访问者');
								break;
							default:
								break;
						} ?></td>
					</tr>
					<?php endwhile; ?>
				  </tbody>
				</table>
				<div class="am-g typecho-list-operate clearfix">
					<form method="get">
						<div class="operate am-u-sm-12 am-u-md-6">
						  <div class="am-btn-toolbar typecho-option-tabs">
							<div class="am-btn-group am-btn-group-xs">
							  <button type="button" class="am-btn am-btn-xs" style="height:28px;"><label><i class="sr-only"><?php _e('全选'); ?></i><input type="checkbox" class="typecho-table-select-all" /></label></button>
							  <div class="am-dropdown am-btn-group am-btn-group-xs" data-am-dropdown>
								<button class="am-btn am-dropdown-toggle" data-am-dropdown-toggle><i class="sr-only"><?php _e('操作'); ?></i><?php _e('选中项'); ?> <span class="am-icon-caret-down"></span></button>
								<ul class="am-dropdown-content dropdown-menu">
								  <li><a lang="<?php _e('你确认要删除这些用户吗?'); ?>" href="<?php $security->index('/action/users-edit?do=delete'); ?>"><?php _e('删除'); ?></a></li>
								</ul>
							  </div>
							</div>
						  </div>
						</div>
						<?php if($users->have()): ?>
                        <ul class="typecho-pager">
                            <?php $users->pageNav(); ?>
                        </ul>
                        <?php endif; ?>
					</form>
				</div>
				
			</div>
		</form>
      </div>
    </div>
	<footer class="admin-content-footer">
	<?php include 'copyright.php';?>
	</footer>
<?php
include 'common-js.php';
include 'table-js.php';
include 'footer.php';
?>
