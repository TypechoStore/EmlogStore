<?php
include 'common.php';
include 'header.php';
include 'menu.php';

$stat = Typecho_Widget::widget('Widget_Stat');
?>
    <div class="admin-content-body">
      <div class="am-cf am-padding typecho-page-title">
        <div class="am-fl am-cf">
			<?php include 'page-title.php'; ?>
		</div>
      </div>
	  <div class="am-cf am-padding">
        <div class="am-fl am-cf">
			<div class="am-btn-toolbar">
				<div class="am-btn-group am-btn-group-xs">
					<?php if($user->pass('contributor', true)){?>
						<a href="<?php $options->adminUrl('write-post.php'); ?>" class="am-btn am-btn-default"><?php _e('撰写新文章'); ?></a>
						<?php if($user->pass('editor', true) && 'on' == $request->get('__typecho_all_comments') && $stat->waitingCommentsNum > 0){?>
							<a href="<?php $options->adminUrl('manage-comments.php?status=waiting'); ?>" class="am-btn am-btn-default"><?php _e('待审核的评论'); ?> <?php echo $stat->waitingCommentsNum(); ?></a>
						<?php }elseif($stat->myWaitingCommentsNum > 0){?>
							<a href="<?php $options->adminUrl('manage-comments.php?status=waiting'); ?>" class="am-btn am-btn-default"><?php _e('待审核评论'); ?> <?php echo $stat->myWaitingCommentsNum(); ?></a>
						<?php }?>
						<?php if($user->pass('editor', true) && 'on' == $request->get('__typecho_all_comments') && $stat->spamCommentsNum > 0){?>
							<a href="<?php $options->adminUrl('manage-comments.php?status=spam'); ?>" class="am-btn am-btn-default"><?php _e('垃圾评论'); ?> <?php echo $stat->spamCommentsNum(); ?></a>
						<?php }elseif($stat->mySpamCommentsNum > 0){?>
							<a href="<?php $options->adminUrl('manage-comments.php?status=spam'); ?>" class="am-btn am-btn-default"><?php _e('垃圾评论'); ?> <?php echo $stat->mySpamCommentsNum(); ?></a>
						<?php }?>
						<?php if($user->pass('administrator', true)){?>
							<a href="<?php $options->adminUrl('themes.php'); ?>" class="am-btn am-btn-default"><?php _e('更换外观'); ?></a>
							<a href="<?php $options->adminUrl('plugins.php'); ?>" class="am-btn am-btn-default"><?php _e('插件管理'); ?></a>
							<a href="<?php $options->adminUrl('options-general.php'); ?>" class="am-btn am-btn-default"><?php _e('系统设置'); ?></a>
						<?php }?>
					<?php }?>
				</div>
			</div>
			<?php $version = Typecho_Cookie::get('__typecho_check_version'); ?>
			<?php if ($version && $version['available']){?>
			<div class="update-check">
                <p class="message notice">
				<?php _e('您当前使用的版本是'); ?> <?php echo $version['current']; ?> &rarr;
				<strong><a href="<?php echo $version['link']; ?>"><?php _e('官方最新版本是'); ?> <?php echo $version['latest']; ?></a></strong>
				</p>
            </div>
			<?php }?>
		</div>
      </div>

      <ul class="am-avg-sm-1 am-avg-md-4 am-margin am-padding am-text-center admin-content-list ">
        <li><a href="#" class="am-text-success"><span class="am-icon-btn am-icon-file-text"></span><br/>文章<br/><?php echo $stat->myPublishedPostsNum;?></a></li>
        <li><a href="#" class="am-text-warning"><span class="am-icon-btn am-icon-briefcase"></span><br/>评论<br/><?php  echo $stat->myPublishedCommentsNum;?></a></li>
        <li><a href="#" class="am-text-danger"><span class="am-icon-btn am-icon-recycle"></span><br/>分类<br/><?php  echo $stat->categoriesNum;?></a></li>
        <li><a href="#" class="am-text-secondary"><span class="am-icon-btn am-icon-user-md"></span><br/>草稿<br/><?php  echo $stat->myDraftPostsNum;?></a></li>
      </ul>

      <div class="am-g">
        <div class="am-u-sm-6">
		  <div class="am-panel am-panel-default">
            <div class="am-panel-hd am-cf" data-am-collapse="{target: '#collapse-panel-1'}"><?php _e('最近发布的文章'); ?><span class="am-icon-chevron-down am-fr" ></span></div>
            <div id="collapse-panel-1" class="am-in">
				<?php Typecho_Widget::widget('Widget_Contents_Post_Recent', 'pageSize=10')->to($posts); ?>
				<table class="am-table am-table-bd am-table-striped admin-content-table">
					<thead>
					</thead>
					<tbody>
						<?php if($posts->have()){?>
						<?php while($posts->next()){?>
						<tr><td><?php $posts->date('n.j'); ?></td><td><a href="<?php $posts->permalink(); ?>"><?php $posts->title(); ?></a></td></tr>
						<?php }?>
						<?php }else{?>
							<tr><td colspan="2"><center><?php _e('暂时没有文章'); ?></center></td></tr>
						<?php }?>
					</tbody>
				</table>
			</div>
		  </div>
        </div>
		<div class="am-u-md-6">
          <div class="am-panel am-panel-default">
            <div class="am-panel-hd am-cf" data-am-collapse="{target: '#collapse-panel-2'}"><?php _e('最近得到的回复'); ?><span class="am-icon-chevron-down am-fr" ></span></div>
            <div id="collapse-panel-2" class="am-in">
              <table class="am-table am-table-bd am-table-bdrs am-table-striped am-table-hover">
                <tbody>
				<?php Typecho_Widget::widget('Widget_Comments_Recent', 'pageSize=10')->to($comments); ?>
				<?php if($comments->have()): ?>
				<?php while($comments->next()): ?>
                <tr>
                  <td><?php $comments->date('n.j'); ?></td>
                  <td><a href="<?php $comments->permalink(); ?>"><?php $comments->author(true); ?></a>:<?php $comments->excerpt(35, '...'); ?></td>
                </tr>
				<?php endwhile; ?>
				<?php else: ?>
				<tr>
                  <td colspan="2"><center><?php _e('暂时没有回复'); ?></center></td>
                </tr>
				<?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
	  <?php if($user->pass('administrator', true)){?>
      <div class="am-g">
		<div class="am-u-md-6">
          <div class="am-panel am-panel-default">
            <div class="am-panel-hd am-cf" data-am-collapse="{target: '#collapse-panel-3'}"><?php _e('更新日志'); ?><span class="am-icon-chevron-down am-fr" ></span></div>
            <div id="collapse-panel-3" class="am-in">
              <table class="am-table am-table-bd am-table-bdrs am-table-striped am-table-hover">
                <tbody id="typecho-updateinfo">
                <tr>
                  <td colspan="2"><?php _e('读取中...'); ?></td>
                </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="am-u-md-6">
          <div class="am-panel am-panel-default">
            <div class="am-panel-hd am-cf" data-am-collapse="{target: '#collapse-panel-4'}"><?php _e('官方最新日志'); ?><span class="am-icon-chevron-down am-fr" ></span></div>
            <div id="collapse-panel-4" class="am-in">
              <table class="am-table am-table-bd am-table-bdrs am-table-striped am-table-hover">
                <tbody id="typecho-message">
                <tr>
                  <td colspan="2"><?php _e('读取中...'); ?></td>
                </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
	  <?php }?>
    </div>
	<footer class="admin-content-footer">
	<?php
	include 'copyright.php';
	include 'common-js.php';
	?>
	<script>
	$(document).ready(function () {
		$.getJSON("https://joke.tongleer.com/api/update.php?action=updateReleaseHistory",
			function(data) {
				$("#typecho-updateinfo").html("");
				$.each(data.items, function(i, item) {
					var d = new Date(item.created * 1000);    //根据时间戳生成的时间对象
					var date = (d.getFullYear()) + "-" + 
							   (d.getMonth() + 1) + "-" +
							   (d.getDate());
					$("#typecho-updateinfo").append("<tr><td width='20%'>" + date + "</td><td>" + item.text + "</td></tr>");
				});
				if(data.items.length){
					$("#typecho-updateinfo").append("<tr><td colspan=\"2\"><a href='https://joke.tongleer.com/87.html' target=\"_blank\"><center>更多</center></a></td></tr>");
				}
			});
			
		var tr = $('#typecho-message tr'), cache = window.sessionStorage,
			html = cache ? cache.getItem('feed') : '',
			update = cache ? cache.getItem('update') : '';

		if (!!html) {
			tr.html(html);
		} else {
			html = '';
			$.get('<?php $options->index('/action/ajax?do=feed'); ?>', function (o) {
				for (var i = 0; i < o.length; i ++) {
					var item = o[i];
					html += '<tr><td colspan="2">&nbsp;&nbsp;' + item.date + '&nbsp;&nbsp;<a href="' + item.link + '" target="_blank">' + item.title + '</a></td></tr>';
				}

				tr.html(html);
				cache.setItem('feed', html);
			}, 'json');
		}

		function applyUpdate(update) {
			if (update.available) {
				$('<div class="update-check message error"><p>'
					+ '<?php _e('您当前使用的版本是 %s'); ?>'.replace('%s', update.current) + '<br />'
					+ '<strong><a href="' + update.link + '" target="_blank">'
					+ '<?php _e('官方最新版本是 %s'); ?>'.replace('%s', update.latest) + '</a></strong></p></div>')
				.insertAfter('.typecho-page-title').effect('highlight');
			}
		}

		if (!!update) {
			applyUpdate($.parseJSON(update));
		} else {
			$.get('<?php $options->index('/action/ajax?do=checkVersion'); ?>', function (o, status, resp) {
				applyUpdate(o);
				cache.setItem('update', resp.responseText);
			}, 'json');
		}
	});

	</script>
	</footer>
<?php include 'footer.php'; ?>
