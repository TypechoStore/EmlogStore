<?php if(!defined('__TYPECHO_ADMIN__')) exit; ?>
  </div>
  <!-- content end -->
</div>

<a href="#" class="am-icon-btn am-icon-th-list am-show-sm-only admin-menu" data-am-offcanvas="{target: '#admin-offcanvas'}"></a>
<!--[if lt IE 9]>
<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
<script src="https://cdn.staticfile.org/modernizr/2.8.3/modernizr.js"></script>
<script src="<?php echo Typecho_Common::url('amazeui.ie8polyfill.min.js?v=' . $suffixVersion, $options->adminStaticUrl('assets/js'));?>"></script>
<![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<script src="<?php echo Typecho_Common::url('jquery.min.js?v=' . $suffixVersion, $options->adminStaticUrl('assets/js'));?>"></script>
<!--<![endif]-->
<script src="<?php echo Typecho_Common::url('amazeui.min.js?v=' . $suffixVersion, $options->adminStaticUrl('assets/js'));?>"></script>
<script src="<?php echo Typecho_Common::url('app.js?v=' . $suffixVersion, $options->adminStaticUrl('assets/js'));?>"></script>
<script>
$("form").addClass("am-form");
</script>
</body>
</html>
<?php
/** 注册一个结束插件 */
Typecho_Plugin::factory('admin/footer.php')->end();