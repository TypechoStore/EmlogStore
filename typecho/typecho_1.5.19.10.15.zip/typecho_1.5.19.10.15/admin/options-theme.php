<?php
include 'common.php';
include 'header.php';
include 'menu.php';
?>
    <div class="admin-content-body row typecho-page-main">
      <div class="am-cf am-padding typecho-page-title">
			<div class="am-fl am-cf">
				<?php include 'page-title.php'; ?>
			</div>
	  </div>
      <div class="am-g">
		<div class="am-u-sm-12 am-u-md-12">
		  <div class="am-btn-toolbar typecho-option-tabs clearfix">
			<div class="am-btn-group am-btn-group-xs">
				<a href="<?php $options->adminUrl('themes.php'); ?>" class="am-btn am-btn-default"><?php _e('可以使用的外观'); ?></a>
				<?php if (!defined('__TYPECHO_THEME_WRITEABLE__') || __TYPECHO_THEME_WRITEABLE__): ?>
				<a href="<?php $options->adminUrl('theme-editor.php'); ?>" class="am-btn am-btn-default"><?php _e('编辑当前外观'); ?></a>
				<?php endif; ?>
				<a href="<?php $options->adminUrl('options-theme.php'); ?>" class="am-btn am-btn-primary"><?php _e('设置外观'); ?></a>
			</div>
		  </div>
		  <?php Typecho_Widget::widget('Widget_Themes_Config')->config()->render(); ?>
		</div>
      </div>
    </div>
	<footer class="admin-content-footer">
	<?php include 'copyright.php';?>
	</footer>
<?php
include 'common-js.php';
include 'form-js.php';
include 'footer.php';
?>
