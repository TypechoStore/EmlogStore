<?php
include 'common.php';
include 'header.php';
include 'menu.php';

$stat = Typecho_Widget::widget('Widget_Stat');
?>
    <div class="admin-content-body typecho-list row typecho-page-main">
      <div class="am-cf am-padding typecho-page-title">
			<div class="am-fl am-cf">
				<?php include 'page-title.php'; ?>
			</div>
	  </div>
      <div class="am-g typecho-list-operate clearfix">
		<form method="get">
			<div class="operate am-u-sm-12 am-u-md-6">
			  <div class="am-btn-toolbar">
				<div class="am-btn-group am-btn-group-xs">
				  <button type="button" class="am-btn am-btn-xs" style="height:28px;"><label><i class="sr-only"><?php _e('全选'); ?></i><input type="checkbox" class="typecho-table-select-all" /></label></button>
				  <div class="am-dropdown am-btn-group am-btn-group-xs" data-am-dropdown>
					<button class="am-btn am-dropdown-toggle" data-am-dropdown-toggle><i class="sr-only"><?php _e('操作'); ?></i><?php _e('选中项'); ?> <span class="am-icon-caret-down"></span></button>
					<ul class="am-dropdown-content dropdown-menu">
					  <li><a lang="<?php _e('你确认要删除这些页面吗?'); ?>" href="<?php $security->index('/action/contents-page-edit?do=delete'); ?>"><?php _e('删除'); ?></a></li>
					</ul>
				  </div>
				</div>
				
			  </div>
			</div>
			<div class="am-u-sm-12 am-u-md-3">
			  <div class="am-input-group am-input-group-sm">
				<input type="text" class="am-form-field" placeholder="<?php _e('请输入关键字'); ?>" value="<?php echo htmlspecialchars($request->keywords); ?>" name="keywords" />
				<span class="am-input-group-btn">
					<button class="am-btn am-btn-default" type="submit"><?php _e('筛选'); ?></button>
					<?php if ('' != $request->keywords): ?>
					<a href="<?php $options->adminUrl('manage-pages.php'); ?>" class="am-btn am-btn-default"><?php _e('&laquo; 取消筛选'); ?></a>
					<?php endif; ?>
				</span>
			  </div>
			</div>
		</form>
      </div>

      <div class="am-g">
		<form method="post" name="manage_pages" class="operate-form">
			<div class="typecho-table-wrap am-u-sm-12">
				<table class="typecho-list-table am-table am-table-striped am-table-hover table-main">
				  <thead>
				  <tr>
					<th class="table-check"></th>
					<th class="table-id"></th>
					<th class="table-title"><?php _e('标题'); ?></th>
					<th class="table-slug"><?php _e('缩略名'); ?></th>
					<th class="table-author am-hide-sm-only"><?php _e('作者'); ?></th>
					<th class="table-date am-hide-sm-only"><?php _e('日期'); ?></th>
				  </tr>
				  </thead>
				  <tbody>
					<?php Typecho_Widget::widget('Widget_Contents_Page_Admin')->to($pages); ?>
					<?php if($pages->have()): ?>
					<?php while($pages->next()): ?>
					<tr id="<?php $pages->theId(); ?>">
						<td><input type="checkbox" value="<?php $pages->cid(); ?>" name="cid[]"/></td>
						<td><a href="<?php $options->adminUrl('manage-comments.php?cid=' . $pages->cid); ?>" class="balloon-button size-<?php echo Typecho_Common::splitByCount($pages->commentsNum, 1, 10, 20, 50, 100); ?>" title="<?php $pages->commentsNum(); ?> <?php _e('评论'); ?>"><?php $pages->commentsNum(); ?></a></td>
						<td>
						<a href="<?php $options->adminUrl('write-page.php?cid=' . $pages->cid); ?>"><?php $pages->title(); ?></a>
						<?php 
						if ($pages->hasSaved || 'page_draft' == $pages->type) {
							echo '<em class="status">' . _t('草稿') . '</em>';
						} else if ('hidden' == $pages->status) {
							echo '<em class="status">' . _t('隐藏') . '</em>';
						}
						?>
						<a href="<?php $options->adminUrl('write-page.php?cid=' . $pages->cid); ?>" title="<?php _e('编辑 %s', htmlspecialchars($pages->title)); ?>"><i class="i-edit"></i></a>
						<?php if ('page_draft' != $pages->type): ?>
						<a href="<?php $pages->permalink(); ?>" title="<?php _e('浏览 %s', htmlspecialchars($pages->title)); ?>"><i class="i-exlink"></i></a>
						<?php endif; ?>
						</td>
						<td><?php $pages->slug(); ?></td>
						<td><?php $pages->author(); ?></td>
						<td>
						<?php if ($pages->hasSaved): ?>
						<span class="description">
						<?php $modifyDate = new Typecho_Date($pages->modified); ?>
						<?php _e('保存于 %s', $modifyDate->word()); ?>
						</span>
						<?php else: ?>
						<?php $pages->dateWord(); ?>
						<?php endif; ?>
						</td>
					</tr>
					<?php endwhile; ?>
					<?php else: ?>
					<tr>
						<td colspan="6"><h6 class="typecho-list-table-title"><?php _e('没有任何页面'); ?></h6></td>
					</tr>
					<?php endif; ?>
				  </tbody>
				</table>
			</div>
		</form>
      </div>
    </div>
	<footer class="admin-content-footer">
	<?php include 'copyright.php';?>
	</footer>
<?php
include 'common-js.php';
include 'table-js.php';
?>

<?php if(!isset($request->status) || 'publish' == $request->get('status')): ?>
<script type="text/javascript">
(function () {
    $(document).ready(function () {
        var table = $('.typecho-list-table').tableDnD({
            onDrop : function () {
                var ids = [];

                $('input[type=checkbox]', table).each(function () {
                    ids.push($(this).val());
                });

                $.post('<?php $security->index('/action/contents-page-edit?do=sort'); ?>',
                    $.param({cid : ids}));
            }
        });
    });
})();
</script>
<?php endif; ?>

<?php include 'footer.php'; ?>
