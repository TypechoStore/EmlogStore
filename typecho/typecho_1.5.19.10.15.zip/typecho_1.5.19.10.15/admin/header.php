<?php
if (!defined('__TYPECHO_ADMIN__')) {
    exit;
}
$header = '<link rel="icon" type="image/png" href="' . Typecho_Common::url('favicon.png?v=' . $suffixVersion, $options->adminStaticUrl('assets/i')) . '">
<link rel="apple-touch-icon-precomposed" href="' . Typecho_Common::url('app-icon72x72@2x.png?v=' . $suffixVersion, $options->adminStaticUrl('assets/i')) . '">
<link rel="stylesheet" href="' . Typecho_Common::url('amazeui.min.css?v=' . $suffixVersion, $options->adminStaticUrl('assets/css')) . '">
<link rel="stylesheet" href="' . Typecho_Common::url('admin.css?v=' . $suffixVersion, $options->adminStaticUrl('assets/css')) . '">
<link rel="stylesheet" href="' . Typecho_Common::url('style.css?v=' . $suffixVersion, $options->adminStaticUrl('assets/css')) . '">';
/** 注册一个初始化插件 */
$header = Typecho_Plugin::factory('admin/header.php')->header($header);
?>
<!doctype html>
<html class="no-js fixed-layout">
<head>
  <meta charset="<?php $options->charset(); ?>">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php _e('%s - %s - Powered by Typecho', $menu->title, $options->title); ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="renderer" content="webkit">
  <meta http-equiv="Cache-Control" content="no-siteapp" />
  <meta name="robots" content="noindex, nofollow">
  <?php echo $header; ?>
  <meta name="apple-mobile-web-app-title" content="Amaze UI" />
</head>
<body<?php if (isset($bodyClass)) {echo ' class="' . $bodyClass . '"';} ?>>
<!--[if lt IE 9]>
    <script type="text/javascript">
        var str = '<p class="browsehappy">你正在使用<strong>过时</strong>的浏览器，此网站框架暂不支持。 请 <a href="https://browsehappy.com/" target="_blank">升级浏览器</a>以获得更好的体验！</p>';
        document.writeln("<pre style='text-align:center;color:#fff;background-color:#0cc; height:100%;border:0;position:fixed;top:0;left:0;width:100%;z-index:1234'>" +
                "<h2 style='padding-top:200px;margin:0'><strong>" + str + "<br/></strong></h2><h2 style='margin:0'><strong>如果你的使用的是双核浏览器,请切换到极速模式访问<br/></strong></h2></pre>");
        document.execCommand("Stop");
    </script>
<![endif]-->