<?php
/**
 * 这是 Typecho 1.5 系统的一套默认皮肤，仅仅为了滥竽充数而已。<br /><div class="ureyset"><br /><a href="javascript:;" title="插件因兴趣于闲暇时间所写，故会有代码不规范、不专业和bug的情况，但完美主义促使代码还说得过去，如有bug或使用问题进行反馈即可。">鼠标轻触查看备注</a>&nbsp;<a href="http://club.tongleer.com" target="_blank">论坛</a>&nbsp;<a href="https://www.tongleer.com/api/web/pay.png" target="_blank">打赏</a>&nbsp;<a href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=diamond0422@qq.com" target="_blank">反馈</a></div><style>.ureyset a{background: #4DABFF;padding: 5px;color: #fff;}</style>
 * @package Typecho Urey Theme 
 * @author 二呆
 * @version 1.0.1&nbsp;<span id="ureyUpdateInfo"></span><script>ureyXmlHttp=new XMLHttpRequest();ureyXmlHttp.open("GET","https://joke.tongleer.com/api/update.php?action=updateReleaseThemeDefault&version=1",true);ureyXmlHttp.send(null);ureyXmlHttp.onreadystatechange=function () {if (ureyXmlHttp.readyState ==4 && ureyXmlHttp.status ==200){document.getElementById("ureyUpdateInfo").innerHTML=ureyXmlHttp.responseText;}}</script>
 * @link https://www.tongleer.com
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
 $this->need('header.php');
 ?>
<!-- Slider -->
<?php
$sliderPostId=$this->options->sliderPostId;
$sliderPostIdArr = explode(',', $sliderPostId);
$sliderPostIdArr = array_unique($sliderPostIdArr);
if($sliderPostId!=null&&$sliderPostId!=0) {
	$sliderPostIdStr=implode(",",$sliderPostIdArr);
	$sliderQuery="select cid from ".$this->db->getPrefix()."contents where cid in (".$sliderPostIdStr.") order by `order` asc,cid desc";
	$sliderData = $this->db->fetchAll($sliderQuery);
	if(count($sliderData)>0){
	?>
	<div data-am-widget="slider" class="am-slider am-slider-a1" data-am-slider='{"directionNav":false}'>
	  <ul class="am-slides">
		<?php
		foreach($sliderData as $value){
			if(getPostImg($value["cid"])){
				?>
				<li>
				  <a href="<?=getArticleUrl($value["cid"]);?>"><img height="300" src="<?=getPostImg($value["cid"]);?>"></a>
				</li>
				<?php
			}
		}
		?>
	  </ul>
	</div>
	<?php
	}
}
?>
<div class="am-container" style="opacity:0.9;">
	<div class="am-g">
		<div class="am-u-sm-12">
			<div data-am-widget="list_news" class="am-panel am-panel-secondary am-list-news-bd am-list-news am-list-news-default">
			  <div class="am-panel-hd">
				<h3 class="am-panel-title am-cf">
					<a href="JavaScript:;">最新文章</a>
				</h3>
			  </div>
			  <?php if ($this->have()): ?>
			  <ul class="am-list am-list-static">
				<!--缩略图在标题左边-->
				  <?php while($this->next()): ?>
				  <li class="am-g am-list-item-desced<?php if(getPostImg($this)){?> am-list-item-thumbed am-list-item-thumb-left<?php }?>">
					<?php if(getPostImg($this)){?>
					<div class="am-u-sm-4 am-list-thumb">
					  <a href="<?php $this->permalink() ?>">
						<img src="<?=getPostImg($this);?>" alt="<?php $this->title() ?>" height="100" />
					  </a>
					</div>
					<?php }?>
					<div class="<?php if(getPostImg($this)){?>am-u-sm-8 <?php }?>am-list-main">
					  <h3 class="am-list-item-hd">
						<a href="<?php $this->permalink() ?>"><?php $this->title() ?></a>
					  </h3>
					  <small>
						<a href="<?php $this->author->permalink(); ?>" rel="author"><?php $this->author(); ?></a>
						<time datetime="<?php $this->date('c'); ?>"><?php $this->date(); ?></time>
						<?php $this->category(','); ?>
						<a href="<?php $this->permalink() ?>#comments"><?php $this->commentsNum('评论', '1 条评论', '%d 条评论'); ?></a>
					  </small>
					  <div class="am-list-item-text"><small><?php $this->excerpt(140, "..."); ?></small></div>
					</div>
				  </li>
				  <?php endwhile; ?>
			  </ul>
			  <div class="am-panel-footer">
				<?php $this->pageNav('首页', '尾页', 1, '...', array('wrapTag' => 'ul', 'wrapClass' => 'am-pagination am-pagination-default am-text-right', 'itemTag' => 'li', 'prevClass' => 'am-pagination-prev', 'nextClass' => 'am-pagination-next', 'currentClass' => 'am-active' )); ?>
			  </div>
			  <?php else: ?>
				<ul class="am-list am-list-static">
					<li class="am-g am-list-item-desced">
						<div class="am-list-main">
						  <h3 class="am-list-item-hd"><?php _e('没有找到内容'); ?></h3>
						  <small>
						</div>
					</li>
				</ul>
			  <?php endif; ?>
			</div>
		</div>
	</div>
	<?php
	$homeCateId=$this->options->homeCateId;
	$homeCateIdArr = explode(',', $homeCateId);
	$homeCateIdArr = array_unique($homeCateIdArr);
	if($homeCateId!=null&&$homeCateId!=0) {
		//$homeCateIdStr=implode(",",$homeCateIdArr);
		//$homeCateQuery="SELECT * FROM ".$this->db->getPrefix()."metas WHERE type='category' AND mid in (".$homeCateIdStr.") ORDER BY parent,`order`,mid ASC";
		//$homeCateData = $this->db->fetchAll($homeCateQuery);
		$this->widget('Widget_Metas_Category_List')->to($categories);
		//if(count($homeCateData)>0){
		?>
		<div class="am-g">
			<?php
			//foreach($homeCateData as $cate){
			while($categories->next()){
				
				if(!in_array($categories->mid,$homeCateIdArr)){
					continue;
				}
				//$mid=$cate["mid"];
				$mid=$categories->mid;
				?>
				<div class="am-u-lg-6">
					<div data-am-widget="list_news" class="am-panel am-panel-secondary am-list-news am-list-news-default">
					  <div class="am-panel-hd">
						<h3 class="am-panel-title am-cf"><a href="<?php echo $categories->permalink;?>"><?php echo $categories->name;//echo $cate["name"];?></a></h3>
					  </div>
					  <ul class="am-list am-list-static">
						<?php
						//$archives = $this->widget('Widget_Archive', 'pageSize=5&type=category', 'mid='.$categories->mid);
						$cateQuery="SELECT * FROM ".$this->db->getPrefix()."metas AS m INNER JOIN ".$this->db->getPrefix()."relationships AS r ON m.mid=r.mid INNER JOIN ".$this->db->getPrefix()."contents AS c ON c.cid=r.cid WHERE m.type='category' AND m.mid = ".$mid." AND c.type='post' AND c.status='publish' ORDER BY created DESC LIMIT 0,5";
						$catePost = $this->db->fetchAll($cateQuery);
						foreach($catePost as $value){
						?>
						<li class="am-g">
							<a href="<?=getArticleUrl($value["cid"]);?>" class="am-list-item-hd"><?php echo $value["title"];?></a>
						</li>
						<?php
						}
						?>
					  </ul>
					</div>
				</div>
			<?php
			}
			?>
		</div>
		<?php
		//}
	}
	?>
	<?php $this->need('sidebar.php'); ?>
</div>

<?php $this->need('footer.php'); ?>