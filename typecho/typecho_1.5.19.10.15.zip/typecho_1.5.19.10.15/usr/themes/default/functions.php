<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

function themeConfig($form) {
    $bgUrl = new Typecho_Widget_Helper_Form_Element_Text('bgUrl', NULL, NULL, _t('网页背景地址'), _t('在这里填入一个图片URL地址，以为网站添加一个背景。'));
    $form->addInput($bgUrl);
	
	$sliderPostId = new Typecho_Widget_Helper_Form_Element_Text('sliderPostId', NULL, NULL, _t('指定幻灯片文章ID'), _t('多个请用英文逗号隔开，默认为空或0即为不显示幻灯片。'));
    $form->addInput($sliderPostId);
	
	$homeCateId = new Typecho_Widget_Helper_Form_Element_Text('homeCateId', NULL, NULL, _t('指定首页栏目ID'), _t('多个分类ID请用英文逗号隔开，默认为空或0即为不显示栏目。'));
    $form->addInput($homeCateId);
    
    $sidebarBlock = new Typecho_Widget_Helper_Form_Element_Checkbox('sidebarBlock', 
    array('ShowRecentPosts' => _t('显示最新文章'),
    'ShowRecentComments' => _t('显示最近回复'),
    'ShowOther' => _t('显示其它杂项')),
    array('ShowRecentPosts', 'ShowRecentComments', 'ShowCategory', 'ShowArchive', 'ShowOther'), _t('侧边栏显示'));
    $form->addInput($sidebarBlock->multiMode());
	
	$friendlinkvalue='
		[{
			"name":"同乐儿",
			"link":"https://www.tongleer.com",
			"target":"_blank",
			"rel":"friend",
			"detail":"共同分享快乐",
			"icon":"2293338477",
			"order":"1"
		},{
			"name":"Amaze",
			"link":"http://amazeui.clouddeep.cn",
			"target":"_blank",
			"rel":"",
			"detail":"中国首个开源HTML5跨屏前端框架",
			"icon":"http://amazeui.clouddeep.cn/assets/i/favicon.png",
			"order":"2"
		}]
	';
	$friendlink = new Typecho_Widget_Helper_Form_Element_Textarea('friendlink', array("value"), $friendlinkvalue, _t('友情链接'), _t('此处可以随意添加链接到导航栏的下拉菜单中，name=链接名，link=链接地址，target=打开方式，rel=链接关系，detail=链接描述，icon=链接图标(支持QQ号)，order=链接排序。注：target包括_blank、_self、_parent、_top；rel可以指定任意关系名称；icon可以是一个QQ号，也可以是链接图标的地址，如果是QQ号，那么既包含QQ链接也包含QQ头像；order的排序规则是越大越靠前。填写格式参考此页面底部。'));
	$form->addInput($friendlink);
	
	$foot_custom = new Typecho_Widget_Helper_Form_Element_Textarea('foot_custom', array('value'), '', _t('底部自定义代码'), _t('在这里填入底部自定义代码'));
    $form->addInput($foot_custom);
	
	$foot_count = new Typecho_Widget_Helper_Form_Element_Textarea('foot_count', array('value'), '', _t('统计代码'), _t('在这里填入统计代码'));
    $form->addInput($foot_count);
	
	$contactUrl = new Typecho_Widget_Helper_Form_Element_Text('contactUrl', NULL, NULL, _t('联系方式二维码'), _t('在这里填入一个二维码图片URL地址，以为网站添加一个联系方式，供用户扫描。'));
    $form->addInput($contactUrl);
	
	$otherlinkvalue='
		[{
			"name":"同乐儿",
			"link":"https://www.tongleer.com",
			"target":"_blank",
			"rel":"friend",
			"detail":"共同分享快乐",
			"icon":"2293338477",
			"order":"1"
		},{
			"name":"Amaze",
			"link":"http://amazeui.clouddeep.cn",
			"target":"_blank",
			"rel":"",
			"detail":"中国首个开源HTML5跨屏前端框架",
			"icon":"http://amazeui.clouddeep.cn/assets/i/favicon.png",
			"order":"2"
		}]
	';
	$otherlink = new Typecho_Widget_Helper_Form_Element_Textarea('otherlink', array("value"), $otherlinkvalue, _t('底部其他链接'), _t('此处可以随意添加链接到导航栏的下拉菜单中，name=链接名，link=链接地址，target=打开方式，rel=链接关系，detail=链接描述，icon=链接图标(不支持QQ号)，order=链接排序。注：target包括_blank、_self、_parent、_top；rel可以指定任意关系名称；icon是链接图标的地址，为空为默认图标；order的排序规则是越大越靠前。友情链接和底部其他链接必须按照以下格式填写：
		<pre>
[{
	"name":"同乐儿",
	"link":"https://www.tongleer.com",
	"target":"_blank",
	"rel":"friend",
	"detail":"共同分享快乐",
	"icon":"",
	"order":"1"
},{
	"name":"Amaze",
	"link":"http://amazeui.clouddeep.cn",
	"target":"_blank",
	"rel":"",
	"detail":"中国首个开源HTML5跨屏前端框架",
	"icon":"",
	"order":"2"
}]
		</pre>
	'));
	$form->addInput($otherlink);
}
function themeFields($layout) {
    $src = new Typecho_Widget_Helper_Form_Element_Select('src', array(_t('内容'),_t('附件')), NULL, _t('图片源'), _t('选择前台展示的图片源'));
	$layout->addItem($src);
	
	$thumb = new Typecho_Widget_Helper_Form_Element_Text('thumb', NULL, NULL, _t('封面图片'), _t('在这里填写封面图片的地址（留空将按照图片源获取图片）'));
	$layout->addItem($thumb);
}
/*输出友情链接*/
function printFriends($link){
	?>
	<?php
	$friendlink=json_decode($link,true);
	if(isset($friendlink)){
		$friendlinks='<p><marquee direction="up" behavior="scroll" scrollamount="1" scrolldelay="10" loop="-1" onMouseOver="this.stop()" onMouseOut="this.start()" width="100%" height="30" style="text-align:center;">友情链接：';
		array_multisort(array_column($friendlink, 'order'), SORT_DESC, $friendlink);
		$isHaveLink=false;
		foreach($friendlink as $value){
			if($value["name"]!=null&&$value["link"]!=null){
				$isHaveLink=true;
				$icon=$value["icon"]!=""?$value["icon"]:"0";
				$iconlink=is_numeric($icon)?'https://wpa.qq.com/msgrd?v=3&uin='.$icon.'&site=qq&menu=yes':$value["link"];
				$iconimg=is_numeric($icon)?'https://q1.qlogo.cn/g?b=qq&nk='.$icon.'&s=100':$icon;
				$friendlinks.='<a href=javascript:open("'.$iconlink.'");><img src="'.$iconimg.'" width="16" /></a><a href="'.$value["link"].'" target="'.$value["target"].'" title="'.$value["detail"].'" rel="'.$value["rel"].'">'.$value["name"].'</a>&nbsp;';
			}
		}
		$friendlinks.='</marquee></p>';
		if(!$isHaveLink){
			$friendlinks='';
		}
		echo $friendlinks;
	}
}
//获取文章内容图
function get_post_html_img($obj){
	if(is_numeric($obj)){
		$cid = $obj;
	}else{
		$cid = $obj->cid;
	}
	$db = Typecho_Db::get();
	$rs = $db->fetchRow($db->select('table.contents.text')
	->from('table.contents')
	->where('cid=?', $cid));
	$text = $rs['text'];
	$pattern = '/\<img.*?src\=\"(.*?)\"[^>]*>/i';
	$patternMD = '/\!\[.*?\]\((http(s)?:\/\/.*?(jpg|png))/i';
	$patternMDfoot = '/\[.*?\]:\s*(http(s)?:\/\/.*?(jpg|png))/i';
	if (preg_match($patternMDfoot, $text, $imgs)) {
		$img=$imgs[1];
	} else if (preg_match($patternMD, $text, $imgs)) {
		$img=$imgs[1];
	} else if (preg_match($pattern, $text, $imgs)) {
		$img=$imgs[1];
	} else {
		$img ="";
	}
	return $img;
}
//获取文章附件图
function getPostAttImg($obj) {
	$atts = array();
	$img ="";
	if(is_numeric($obj)){
		$db = Typecho_Db::get();
		$rs = $db->fetchAll($db->select('table.contents.text')
			->from('table.contents')
			->where('table.contents.parent=?', $obj)
			->order('table.contents.cid', Typecho_Db::SORT_ASC));
		foreach($rs as $attach) {
			$attach = unserialize($attach['text']);
			if(strpos($attach['mime'],"image/")!==false) {
				$query= $db->select('value')->from('table.options')->where('name = ?', 'siteUrl'); 
				$row = $db->fetchRow($query);
				$atts[] = array($attach['name'], $row["value"].$attach['path']);
				$img =$atts[0][1];
			}
		}
	}else{
		$stack = $obj->attachments()->stack;
		for($i = 0; $i < count($stack); $i++) {
			$att = $stack[$i]['attachment'];
			if($att->isImage) {
				$atts[] = array('name' => $att->name, 'url' => $att->url);
				$img =$atts[0]["url"];
			}
		}
	}
	return $img;
}
//获取文章图片 整合 getPostAttImg() 与 get_post_html_img()
function getPostImg($obj) {
	$imgs = array();
	$img = "";
	if(is_numeric($obj)){
		$db = Typecho_Db::get();
		$queryField= $db->select()->from('table.fields')->where('name = ?', 'thumb')->where('cid = ?', $obj)->where('type = ?', "str"); 
		$rowsField = $db->fetchRow($queryField);
		if($rowsField){
			if(!empty($rowsField)&&$rowsField["str_value"] != ""){
				array_push($imgs,$rowsField["str_value"]);
				$img=$imgs[0];
			}else{
				$queryField= $db->select()->from('table.fields')->where('name = ?', 'src')->where('cid = ?', $obj)->where('type = ?', "str"); 
				$rowsField = $db->fetchRow($queryField);
				if($rowsField["str_value"] == 0) {
					$img = get_post_html_img($obj);
				}elseif($rowsField["str_value"] == 1) {
					$img = getPostAttImg($obj);
				}
			}
		}
	}else{
		if($obj->fields->thumb) {
			array_push($imgs,$obj->fields->thumb);
			$img=$imgs[0];
		}else{
			if($obj->fields->src == 0) {
				$img = get_post_html_img($obj);
			}elseif($obj->fields->src == 1) {
				$img = getPostAttImg($obj);
			}
		}
	}
	return $img;
}
/*获取文章url*/
function getArticleUrl($cid){
	$options = Typecho_Widget::widget('Widget_Options');
	$db = Typecho_Db::get();
	$posts= $db->fetchRow($db->select()->from('table.contents')
		->where('table.contents.status = ?', 'publish')
		->where('table.contents.cid = ?', $cid)
		->order('table.contents.created', Typecho_Db::SORT_DESC));
	//去掉附件
	$type = $posts['type'];
	if(true){
		$routeExists = (NULL != Typecho_Router::get($type));
		$pathinfo = $routeExists ? Typecho_Router::url($type, $posts) : '#';
		$permalink = Typecho_Common::url($pathinfo, $options->index);
		return $permalink;
	}
}
/*
* 回复评论添加 @ 标签
*/
function get_comment_at($coid){
    $db   = Typecho_Db::get();
    $prow = $db->fetchRow($db->select('parent')->from('table.comments')->where('coid = ? AND status = ?', $coid, 'approved'));
    $parent = $prow['parent'];
    if ($parent != "0") {
        $arow = $db->fetchRow($db->select('author')->from('table.comments')->where('coid = ? AND status = ?', $parent, 'approved'));
        $author = $arow['author'];
        $href = '回复 <a href="#comment-' . $parent . '">@' . $author . '</a>';
        echo $href;
    } else {
        echo '';
    }
}