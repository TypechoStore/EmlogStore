<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
<div class="am-container" style="opacity:0.9;">
	<div class="am-g">
		<div class="am-u-sm-12">
			<div data-am-widget="list_news" class="am-panel am-panel-secondary am-list-news-bd am-list-news am-list-news-default">
			  <div class="am-panel-hd">
				<h3 class="am-panel-title am-cf">
					<a href="<?php $this->permalink() ?>"><?php $this->title() ?></a>
				</h3>
			  </div>
			  <ul class="am-list am-list-static">
				  <li class="am-g am-list-item-desced">
					<div class="am-cf am-article">
						<?php $this->content(); ?>
					</div>
					<?php $this->need('comments.php'); ?>
				  </li>
			  </ul>
			</div>
		</div>
	</div>
	<?php $this->need('sidebar.php'); ?>
</div>
<?php $this->need('footer.php'); ?>
