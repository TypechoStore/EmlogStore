<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!doctype html>
<html class="no-js">
<head>
  <meta charset="<?php $this->options->charset(); ?>">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php $this->archiveTitle(array(
            'category'  =>  _t('分类 %s 下的文章'),
            'search'    =>  _t('包含关键字 %s 的文章'),
            'tag'       =>  _t('标签 %s 下的文章'),
            'author'    =>  _t('%s 发布的文章')
        ), '', ' - '); ?><?php $this->options->title(); ?></title>
  <meta name="description" content="<?php $this->options->description() ?>">
  <meta name="keywords" content="<?php $this->options->keywords() ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="renderer" content="webkit">
  <meta http-equiv="Cache-Control" content="no-siteapp" />
  <link rel="icon" type="image/png" href="<?php $this->options->themeUrl('assets/img/favicon.png'); ?>">
  <link rel="stylesheet" href="<?php $this->options->themeUrl('assets/css/amazeui.min.css'); ?>">
  <link rel="stylesheet" href="<?php $this->options->themeUrl('assets/css/app.css'); ?>">
  <!-- 通过自有函数输出HTML头部信息 -->
  <?php $this->header(); ?>
</head>
<body style="background-image:url('<?php echo $this->options->bgUrl;?>');">
<!--[if lt IE 9]>
    <script type="text/javascript">
        var str = '<p class="browsehappy">你正在使用<strong>过时</strong>的浏览器，此网站框架暂不支持。 请 <a href="https://browsehappy.com/" target="_blank">升级浏览器</a>以获得更好的体验！</p>';
        document.writeln("<pre style='text-align:center;color:#fff;background-color:#0cc; height:100%;border:0;position:fixed;top:0;left:0;width:100%;z-index:1234'>" +
                "<h2 style='padding-top:200px;margin:0'><strong>" + str + "<br/></strong></h2><h2 style='margin:0'><strong>如果你的使用的是双核浏览器,请切换到极速模式访问<br/></strong></h2></pre>");
        document.execCommand("Stop");
    </script>
<![endif]-->
<!-- Header -->
<header data-am-widget="header" class="am-header am-header-default">
  <h1 class="am-header-title">
    <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title() ?></a>
  </h1>
</header>

<!-- Menu -->
<nav data-am-widget="menu" class="am-menu  am-menu-offcanvas1" data-am-menu-offcanvas>
  <a href="javascript: void(0)" class="am-menu-toggle">
    <i class="am-menu-toggle-icon am-icon-bars"></i>
  </a>
  <div class="am-offcanvas">
    <div class="am-offcanvas-bar">
      <ul class="am-menu-nav sm-block-grid-1">
        <li class="">
          <a href="<?php $this->options->siteUrl(); ?>"><?php _e('首页'); ?></a>
        </li>
		<?php
		$this->widget('Widget_Metas_Category_List')->to($categories);
		while($categories->next()){
			if($categories->parent!=0){
				continue;
			}
			?>
			<li class="am-parent">
			  <?php
			  $children = $categories->getAllChildren($categories->mid);
			  if(count($children)>0){
				?>
				<a href="<?php echo $categories->permalink;?>" title="<?php echo $categories->name;?>"><?php echo $categories->name;?></a>
				<ul class="am-menu-sub am-collapse sm-block-grid-3">
				<?php
				foreach ($children as $mid) {
					$child = $categories->getCategory($mid);
					?>
					<li class="">
					  <a href="<?php echo $child['permalink'];?>" title="<?php echo $child['name'];?>"><?php echo $child['name']; ?></a>
					</li>
					<?php
					}
				?>
				</ul>
				<?php
				}else{
					?>
					<li class="">
					  <a href="<?php echo $categories->permalink;?>" title="<?php echo $categories->name;?>"><?php echo $categories->name;?></a>
					</li>
					<?php
			  }
			  ?>
			</li>
			<?php
		}
		?>
		<?php
		$stat = Typecho_Widget::widget('Widget_Stat');
		if($stat->publishedPagesNum>0){
		?>
		<li class="am-parent">
          <a href="##">页面</a>
          <ul class="am-menu-sub am-collapse sm-block-grid-2 ">
			<?php $this->widget('Widget_Contents_Page_List')->to($pages);?>
			<?php while($pages->next()): ?>
			<li class="">
			  <a href="<?php $pages->permalink(); ?>" title="<?php $pages->title(); ?>"><?php $pages->title(); ?></a>
			</li>
			<?php endwhile; ?>
          </ul>
        </li>
		<?php
		}
		?>
      </ul>
    </div>
  </div>
</nav>