Typecho Urey Theme 这是 Typecho 1.5 系统的一套默认皮肤
---
# 模板截图

<img src="https://img14.360buyimg.com/uba/jfs/t1/106051/12/107/45147/5da74cc8E854b9d52/1db368af9a68ee03.png" width="100%">

# 模板介绍

这是 Typecho 1.5 系统的一套默认皮肤

# 版本记录

2019-10-17 V1.0.1

	第一个版本