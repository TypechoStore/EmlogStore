<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
<div class="am-container" style="opacity:0.9;">
	<div class="am-g">
        <div class="am-u-sm-12">
			<h2 class="am-text-center am-text-xxxl am-margin-top-lg">404. Not Found</h2>
			<p class="am-text-center"><?php _e('没有找到你要的页面'); ?></p>
			<center>
				<form class="am-form-inline" role="search" method="post">
				  <div class="am-form-group">
					<input type="text" name="s" class="am-form-field" placeholder="<?php _e('搜索关键字'); ?>" autofocus>
				  </div>
				  <button type="submit" class="am-btn am-btn-secondary"><?php _e('搜索'); ?></button>
				</form>
			</center>
			<pre class="page-404">
          .----.
       _.'__    `.
   .--($)($$)---/#\
 .' @          /###\
 :         ,   #####
  `-..__.-' _.-\###/
        `;_:    `"'
      .'"""""`.
     /,  ya ,\\
    //  404!  \\
    `-._______.-'
    ___`. | .'___
   (______|______)
			</pre>
        </div>
    </div>
</div>
<?php $this->need('footer.php'); ?>
