<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<div class="am-g">
	<div class="am-u-sm-12">
		<!-- Gallery -->
		<?php if (!empty($this->options->sidebarBlock) && in_array('ShowRecentComments', $this->options->sidebarBlock)): ?>
		<div class="am-panel am-panel-secondary am-list-news am-list-news-default">
		  <div class="am-panel-hd">
			<h3 class="am-panel-title"><?php _e('最近回复'); ?></h3>
		  </div>
		  <ul data-am-widget="gallery" class="am-gallery am-avg-sm-2 am-avg-md-3 am-avg-lg-4 am-gallery-default am-list am-list-static" data-am-gallery="{ pureview: true }">
			<?php $this->widget('Widget_Comments_Recent')->to($comments); ?>
			<?php while($comments->next()){?>
			<li>
				<div class="am-gallery-item">
				  <a href="<?php $comments->permalink(); ?>" class="">
					<img style="height:200px;" src="<?=getPostImg($comments->cid)?getPostImg($comments->cid):$this->options->themeUrl('assets/img/favicon.png',$this->options->theme);?>" alt="<?=$comments->title;?>" />
					<h3 class="am-gallery-title"><?php $comments->author(false); ?></a>: <?php $comments->excerpt(35, '...'); ?></h3>
					<div class="am-gallery-desc"><?=date("Y-m-d",$comments->created);?></div>
				  </a>
				</div>
			</li>
			<?php }?>
		  </ul>
		  <div class="am-panel-footer"></div>
		</div>
		<?php endif; ?>
	</div>
	
	<div class="am-u-sm-12">
		<!-- Gallery -->
		<?php if (!empty($this->options->sidebarBlock) && in_array('ShowRecentPosts', $this->options->sidebarBlock)): ?>
		<div class="am-panel am-panel-secondary am-list-news am-list-news-default">
		  <div class="am-panel-hd">
			<h3 class="am-panel-title"><?php _e('最新文章'); ?></h3>
		  </div>
		  <ul data-am-widget="gallery" class="am-gallery am-avg-sm-2 am-avg-md-3 am-avg-lg-4 am-gallery-default am-list am-list-static" data-am-gallery="{ pureview: true }">
			<?php 
			$this->widget('Widget_Contents_Post_Recent','pageSize=4')->to($recent);
			if($recent->have()){
				while($recent->next()){
					?>
					<li>
						<div class="am-gallery-item">
						  <a href="<?php $recent->permalink();?>" class="">
							<img style="height:200px;" src="<?=getPostImg($recent->cid)?getPostImg($recent->cid):$this->options->themeUrl('assets/img/favicon.png',$this->options->theme);?>" alt="<?php $recent->title();?>" />
							<h3 class="am-gallery-title"><?php $recent->title();?></h3>
							<div class="am-gallery-desc"><?php $recent->year();?>-<?php $recent->month();?>-<?php $recent->day();?></div>
						  </a>
						</div>
					</li>
					<?php
				}
			}
			?>
		  </ul>
		  <div class="am-panel-footer"></div>
		</div>
		<?php endif; ?>
	</div>
</div>