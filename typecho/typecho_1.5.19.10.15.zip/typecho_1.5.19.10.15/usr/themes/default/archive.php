<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
<div class="am-container" style="opacity:0.9;">
	<div class="am-g">
		<div class="am-u-sm-12">
			<div data-am-widget="list_news" class="am-panel am-panel-secondary am-list-news-bd am-list-news am-list-news-default">
			  <div class="am-panel-hd">
				<h3 class="am-panel-title am-cf">
					<a href="JavaScript:;">
						<?php
						$this->archiveTitle(array(
							'category'  =>  _t('分类 %s 下的文章'),
							'search'    =>  _t('包含关键字 %s 的文章'),
							'tag'       =>  _t('标签 %s 下的文章'),
							'author'    =>  _t('%s 发布的文章')
						), '', '');
						?>
					</a>
				</h3>
			  </div>
			  <?php if ($this->have()): ?>
			  <ul class="am-list am-list-static">
				<!--缩略图在标题左边-->
				  <?php while($this->next()): ?>
				  <li class="am-g am-list-item-desced<?php if(getPostImg($this)){?> am-list-item-thumbed am-list-item-thumb-left<?php }?>">
					<?php if(getPostImg($this)){?>
					<div class="am-u-sm-4 am-list-thumb">
					  <a href="<?php $this->permalink() ?>">
						<img src="<?=getPostImg($this);?>" alt="<?php $this->title() ?>" height="100" />
					  </a>
					</div>
					<?php }?>
					<div class="<?php if(getPostImg($this)){?>am-u-sm-8 <?php }?>am-list-main">
					  <h3 class="am-list-item-hd">
						<a href="<?php $this->permalink() ?>"><?php $this->title() ?></a>
					  </h3>
					  <small>
						<a href="<?php $this->author->permalink(); ?>" rel="author"><?php $this->author(); ?></a>
						<time datetime="<?php $this->date('c'); ?>"><?php $this->date(); ?></time>
						<?php $this->category(','); ?>
						<a href="<?php $this->permalink() ?>#comments"><?php $this->commentsNum('评论', '1 条评论', '%d 条评论'); ?></a>
					  </small>
					  <div class="am-list-item-text"><small><?php $this->excerpt(140, "..."); ?></small></div>
					</div>
				  </li>
				  <?php endwhile; ?>
			  </ul>
			  <div class="am-panel-footer">
				<?php $this->pageNav('首页', '尾页', 1, '...', array('wrapTag' => 'ul', 'wrapClass' => 'am-pagination am-pagination-default am-text-right', 'itemTag' => 'li', 'prevClass' => 'am-pagination-prev', 'nextClass' => 'am-pagination-next', 'currentClass' => 'am-active' )); ?>
			  </div>
			  <?php else: ?>
				<ul class="am-list am-list-static">
					<li class="am-g am-list-item-desced">
						<div class="am-list-main">
						  <h3 class="am-list-item-hd"><?php _e('没有找到内容'); ?></h3>
						  <small>
						</div>
					</li>
				</ul>
			  <?php endif; ?>
			</div>
		</div>
	</div>
	<?php $this->need('sidebar.php'); ?>
</div>
<?php $this->need('footer.php'); ?>
