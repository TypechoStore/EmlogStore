<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<style>
.footer p {
  color: #7f8c8d;
  margin: 0;
  padding: 15px 0;
  text-align: center;
  background: #2d3e50;
}
.footer .friendlink {
  background: #2d3e50;
}
</style>
<footer class="footer">
  <?php echo printFriends($this->options->friendlink);?>
  <?php echo $this->options->foot_custom?"<p>".$this->options->foot_custom."</p>":""; ?>
  <p>
	© <?php echo date('Y'); ?> <a href="<?php $this->options->siteUrl(); ?>" target="_blank"><?php $this->options->title(); ?>.</a> <?php _e('Powered by <a href="http://www.typecho.org">Typecho</a>'); ?>. Theme By <a href="https://www.tongleer.com" target="_blank">Tongleer</a>. 
	<?php if (!empty($this->options->sidebarBlock) && in_array('ShowOther', $this->options->sidebarBlock)){?>
		<a href="<?php $this->options->feedUrl(); ?>"><?php _e('文章RSS'); ?></a>. <a href="<?php $this->options->commentsFeedUrl(); ?>"><?php _e('评论 RSS'); ?></a>. 
	<?php }?>
  </p>
  <p style="display:none;"><?php echo $this->options->foot_count; ?></p>
</footer>
<!-- Navbar -->
<div data-am-widget="navbar" class="am-navbar am-cf am-navbar-default " id="">
  <ul class="am-navbar-nav am-cf am-avg-sm-4">
    <li>
      <a href="<?php $this->options->siteUrl(); ?>">
        <span class="am-icon-home"></span>
        <span class="am-navbar-label">首页</span>
      </a>
    </li>
    <li>
      <a href="<?php if(!$this->user->hasLogin()){ ?>javascript:;<?php }else{?><?php $this->options->adminUrl(); ?><?php }?>" <?php if(!$this->user->hasLogin()){ ?>data-am-modal="{target: '#login_modal'}"<?php }?>>
        <span class="am-icon-user"></span>
		<?php if(!$this->user->hasLogin()){ ?>
        <span class="am-navbar-label">登陆</span>
		<?php }else{?>
		<span class="am-navbar-label">后台</span>
		<?php }?>
      </a>
    </li>
    <li>
      <a href="javascript:;" data-am-modal="{target: '#search_modal'}">
        <span class="am-icon-search"></span>
        <span class="am-navbar-label">搜索</span>
      </a>
    </li>
	<li data-am-navbar-qrcode="<?php echo $this->options->contactUrl;?>">
      <a href="###">
        <span class="am-icon-qrcode"></span>
        <span class="am-navbar-label">联系</span>
      </a>
    </li>
	<li data-am-navbar-share>
      <a href="###">
        <span class="am-icon-share-square-o"></span>
        <span class="am-navbar-label">分享</span>
      </a>
    </li>
	<?php
	$otherlink=json_decode($this->options->otherlink,true);
	if(isset($otherlink)){
		array_multisort(array_column($otherlink, 'order'), SORT_DESC, $otherlink);
		foreach($otherlink as $value){
			?>
			<li>
			  <a href="<?php echo $value["link"];?>" target="<?php echo $value["target"];?>" title="<?php echo $value["detail"];?>" rel="<?php echo $value["rel"];?>">
				<?php if($value["icon"]){?>
				<img width="16" src="<?php echo $value["icon"];?>" />
				<?php }else{?>
				<span class="am-icon-link"></span>
				<?php }?>
				<span class="am-navbar-label"><?php echo $value["name"];?></span>
			  </a>
			</li>
			<?php
		}
	}
	?>
  </ul>
</div>

<div class="am-modal am-modal-no-btn" tabindex="-1" id="login_modal">
  <div class="am-modal-dialog">
    <div class="am-modal-hd">
		<span></span>
		<a href="javascript: void(0)" class="am-close am-close-spin" data-am-modal-close>&times;</a>
    </div>
    <div class="am-modal-bd">
		<div class="am-tabs" data-am-tabs="{noSwipe: 1}">
		  <ul class="am-tabs-nav am-nav am-nav-tabs">
			<li class="am-active"><a href="#tab_login">登陆</a></li>
		  </ul>

		  <div class="am-tabs-bd">
			<div class="am-tab-panel am-fade am-in am-active" id="tab_login">
				<div class="am-g">
				  <div class=" col-md-8 col-sm-centered">
					<form class="am-form" action="<?php $this->options->loginAction(); ?>" method="post">
					  <fieldset class="am-form-set">
						<input type="text" name="name" placeholder="<?php _e('用户名'); ?>" autofocus />
						<input type="password" name="password" placeholder="<?php _e('密码'); ?>" />
						<input type="checkbox" name="remember" value="1" checked /><small><?php _e('下次自动登录'); ?></small>
					  </fieldset>
					  <input type="hidden" name="referer" value="<?php echo htmlspecialchars(@$_GET["referer"]); ?>" />
					  <button type="submit" class="am-btn am-btn-secondary am-btn-block">登陆</button>
					</form>
				  </div>
				</div>
			</div>
		  </div>
		</div>
    </div>
  </div>
</div>

<div class="am-modal am-modal-no-btn" tabindex="-1" id="search_modal">
  <div class="am-modal-dialog">
    <div class="am-modal-hd">
		<label for="s" class="sr-only"><?php _e('搜索关键字'); ?></label>
		<a href="javascript: void(0)" class="am-close am-close-spin" data-am-modal-close>&times;</a>
    </div>
    <div class="am-modal-bd">
		<form id="search" class="am-form-inline" role="search" method="post" action="<?php $this->options->siteUrl(); ?>">
		  <div class="am-form-group">
			<input type="text" name="s" class="am-form-field" placeholder="<?php _e('搜索关键字'); ?>">
		  </div>
		  <button type="submit" class="am-btn am-btn-secondary"><?php _e('搜索'); ?></button>
		</form>
    </div>
  </div>
</div>

<script src="<?php $this->options->themeUrl('assets/js/jquery.min.js'); ?>"></script>
<script src="<?php $this->options->themeUrl('assets/js/amazeui.min.js'); ?>"></script>
<?php $this->footer(); ?>
</body>
</html>