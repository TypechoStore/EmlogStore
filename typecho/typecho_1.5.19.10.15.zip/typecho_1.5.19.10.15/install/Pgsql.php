<?php if(!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<div class="am-g am-margin-top">
	<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库地址'); ?></div>
	<div class="am-u-sm-8 am-u-md-4">
		<input type="text" class="am-input-sm" name="dbHost" id="dbHost" value="<?php _v('dbHost', 'localhost'); ?>">
	</div>
	<div class="am-u-sm-12 am-u-md-8"><?php _e('您可能会使用 "%s"', 'localhost'); ?></div>
</div>
<div class="am-g am-margin-top">
	<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库端口'); ?></div>
	<div class="am-u-sm-8 am-u-md-4">
		<input type="text" class="am-input-sm" name="dbPort" id="dbPort" value="<?php _v('dbPort', '5432'); ?>">
	</div>
	<div class="am-u-sm-12 am-u-md-8"><?php _e('如果您不知道此选项的意义, 请保留默认设置'); ?></div>
</div>
<div class="am-g am-margin-top">
	<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库用户名'); ?></div>
	<div class="am-u-sm-8 am-u-md-4">
		<input type="text" class="am-input-sm" name="dbUser" id="dbUser" value="<?php _v('dbUser', 'postgres'); ?>">
	</div>
	<div class="am-u-sm-12 am-u-md-8"><?php _e('您可能会使用 "%s"', 'postgres'); ?></div>
</div>
<div class="am-g am-margin-top">
	<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库密码'); ?></div>
	<div class="am-u-sm-8 am-u-md-4">
		<input type="password" class="am-input-sm" name="dbPassword" id="dbPassword" value="<?php _v('dbPassword'); ?>">
	</div>
	<div class="am-u-sm-12 am-u-md-8"></div>
</div>
<div class="am-g am-margin-top">
	<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库名'); ?></div>
	<div class="am-u-sm-8 am-u-md-4">
		<input type="text" class="am-input-sm" name="dbDatabase" id="dbDatabase" value="<?php _v('dbDatabase', 'typecho'); ?>">
	</div>
	<div class="am-u-sm-12 am-u-md-8"><?php _e('请您指定数据库名称'); ?></div>
</div>
<input type="hidden" name="dbCharset" value="<?php _e('utf8'); ?>" />
