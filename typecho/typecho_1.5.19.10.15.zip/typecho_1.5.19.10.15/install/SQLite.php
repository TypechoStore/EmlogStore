<?php if(!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $defaultDir = dirname($_SERVER['SCRIPT_FILENAME']) . '/usr/' . uniqid() . '.db'; ?>
<div class="am-g am-margin-top">
	<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库文件路径'); ?></div>
	<div class="am-u-sm-8 am-u-md-4">
		<input type="text" class="am-input-sm" name="dbFile" id="dbFile" value="<?php _v('dbFile', $defaultDir); ?>">
	</div>
	<div class="am-u-sm-12 am-u-md-8"><?php _e('"%s" 是我们为您自动生成的地址', $defaultDir); ?></div>
</div>