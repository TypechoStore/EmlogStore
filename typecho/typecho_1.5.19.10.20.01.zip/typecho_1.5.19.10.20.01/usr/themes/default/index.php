<?php
/**
 * 这是 Typecho 1.5 系统的一套默认皮肤，仅仅为了滥竽充数而已。<br /><div class="moblogset"><br /><a href="javascript:;" title="插件因兴趣于闲暇时间所写，故会有代码不规范、不专业和bug的情况，但完美主义促使代码还说得过去，如有bug或使用问题进行反馈即可。">鼠标轻触查看备注</a>&nbsp;<a href="http://club.tongleer.com" target="_blank">论坛</a>&nbsp;<a href="https://www.tongleer.com/api/web/pay.png" target="_blank">打赏</a>&nbsp;<a href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=diamond0422@qq.com" target="_blank">反馈</a></div><style>.moblogset a{background: #4DABFF;padding: 5px;color: #fff;}</style>
 * @package Typecho Moblog Theme 
 * @author 二呆
 * @version 1.0.1&nbsp;<span id="moblogUpdateInfo"></span><script>moblogXmlHttp=new XMLHttpRequest();moblogXmlHttp.open("GET","https://joke.tongleer.com/api/update.php?action=updateDevelopThemeDefault&version=1",true);moblogXmlHttp.send(null);moblogXmlHttp.onreadystatechange=function () {if (moblogXmlHttp.readyState ==4 && moblogXmlHttp.status ==200){document.getElementById("moblogUpdateInfo").innerHTML=moblogXmlHttp.responseText;}}</script>
 * @link https://www.tongleer.com
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;$blogtype="blog";
$this->need('header.php');
$this->need('headernav.php');
?>

<!-- banner start -->
<?php
$sliderPostId=$this->options->sliderPostId;
$sliderPostIdArr = explode(',', $sliderPostId);
$sliderPostIdArr = array_unique($sliderPostIdArr);
if($sliderPostId!=null&&$sliderPostId!=0) {
	$sliderPostIdStr=implode(",",$sliderPostIdArr);
	$sliderQuery="select * from ".$this->db->getPrefix()."contents as c,".$this->db->getPrefix()."users as u where c.authorId=u.uid AND cid in (".$sliderPostIdStr.") order by `order` asc,cid desc";
	$sliderData = $this->db->fetchAll($sliderQuery);
	if(count($sliderData)>0){
	?>
	<div class="am-g am-g-fixed blog-fixed am-u-sm-centered blog-article-margin">
		<div data-am-widget="slider" class="am-slider am-slider-b1" data-am-slider='{&quot;controlNav&quot;:false}' >
		<ul class="am-slides">
			<?php
			foreach($sliderData as $value){
				if(getPostImg($value["cid"])){
					?>
					<li>
						<img height="620" src="<?=getPostImg($value["cid"]);?>">
						<div class="blog-slider-desc am-slider-desc ">
							<div class="blog-text-center blog-slider-con">
								<span><a href="" class="blog-color"><?=$value["screenName"]?$value["screenName"]:$value["name"];?> &nbsp;</a></span>               
								<h1 class="blog-h-margin"><a href="<?=getArticleUrl($value["cid"]);?>"><?=$value["title"];?></a></h1>
								<p><?php echo formatExcerpt($value["text"],140);?></p>
								<span class="blog-bor"><?=date("Y/m/d",$value["created"]);?></span>
							</div>
						</div>
					</li>
					<?php
				}
			}
			?>
		</ul>
		</div>
	</div>
	<?php
	}
}
?>
<!-- banner end -->

<!-- content srart -->
<div class="am-g am-g-fixed blog-fixed">
    <div class="am-u-md-8 am-u-sm-12">
		<?php while($this->next()){?>
        <article class="am-g blog-entry-article">
			<?php if(getPostImg($this)){?>
            <div class="am-u-lg-6 am-u-md-12 am-u-sm-12 blog-entry-img">
                <img src="<?=getPostImg($this);?>" alt="" class="am-u-sm-12">
            </div>
			<?php }?>
            <div class="am-u-lg-6 am-u-md-12 am-u-sm-12 blog-entry-text">
                <span><a href="<?php $this->author->permalink(); ?>" class="blog-color"><?php $this->author(); ?> &nbsp;</a></span>
                <span> <?php $this->category(','); ?> &nbsp;</span>
                <span><time datetime="<?php $this->date('c'); ?>" itemprop="datePublished"><?php $this->date(); ?></time></span>
				<span><a itemprop="discussionUrl" href="<?php $this->permalink() ?>#comments"><?php $this->commentsNum('评论', '1 条评论', '%d 条评论'); ?></a></span>
                <h1><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></h1>
                <p><?php $this->excerpt(140, "..."); ?></p>
                <p><a href="<?php $this->permalink() ?>" class="blog-continue">continue reading</a></p>
            </div>
        </article>
		<?php }?>
		<?php $this->pageNav('首页', '尾页', 1, '...', array('wrapTag' => 'ul', 'wrapClass' => 'am-pagination', 'itemTag' => 'li', 'prevClass' => 'am-pagination-prev', 'nextClass' => 'am-pagination-next', 'currentClass' => 'am-active' )); ?>
    </div>
	<?php $this->need('sidebar.php'); ?>
</div>
<!-- content end -->
<?php $this->need('footerdiv.php');?>
<?php $this->need('footer.php'); ?>
