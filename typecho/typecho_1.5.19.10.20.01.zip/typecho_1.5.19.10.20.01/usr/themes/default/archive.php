<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit;$blogtype="blog"; ?>
<?php $this->need('header.php'); ?>
<?php $this->need('headernav.php');?>
	
	<!-- content srart -->
	<div class="am-g am-g-fixed blog-fixed">
		<div class="am-u-md-8 am-u-sm-12">
			<?php if ($this->have()): ?>
			<?php while($this->next()){?>
			<article class="am-g blog-entry-article">
				<?php if(getPostImg($this)){?>
				<div class="am-u-lg-6 am-u-md-12 am-u-sm-12 blog-entry-img">
					<img src="<?=getPostImg($this);?>" alt="" class="am-u-sm-12">
				</div>
				<?php }?>
				<div class="am-u-lg-6 am-u-md-12 am-u-sm-12 blog-entry-text">
					<span><a href="<?php $this->author->permalink(); ?>" class="blog-color"><?php $this->author(); ?> &nbsp;</a></span>
					<span> <?php $this->category(','); ?> &nbsp;</span>
					<span><time datetime="<?php $this->date('c'); ?>" itemprop="datePublished"><?php $this->date(); ?></time></span>
					<span><a itemprop="discussionUrl" href="<?php $this->permalink() ?>#comments"><?php $this->commentsNum('评论', '1 条评论', '%d 条评论'); ?></a></span>
					<h1><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></h1>
					<p><?php $this->excerpt(140, "..."); ?></p>
					<p><a href="<?php $this->permalink() ?>" class="blog-continue">continue reading</a></p>
				</div>
			</article>
			<?php }?>
			<?php $this->pageNav('首页', '尾页', 1, '...', array('wrapTag' => 'ul', 'wrapClass' => 'am-pagination', 'itemTag' => 'li', 'prevClass' => 'am-pagination-prev', 'nextClass' => 'am-pagination-next', 'currentClass' => 'am-active' )); ?>
			<?php else: ?>
				<h2 class="am-text-center am-text-xxxl am-margin-top-lg">404. Not Found</h2>
				<p class="am-text-center"><?php _e('没有找到你要的页面'); ?></p>
				<center>
					<form class="am-form-inline" role="search" method="post">
					  <div class="am-form-group">
						<input type="text" name="s" class="am-form-field" placeholder="<?php _e('搜索关键字'); ?>" autofocus>
					  </div>
					  <button type="submit" class="am-btn am-btn-secondary"><span class="am-icon-search"></span></button>
					</form>
				</center>
				<pre class="page-404">
          .----.
       _.'__    `.
   .--($)($$)---/#\
 .' @          /###\
 :         ,   #####
  `-..__.-' _.-\###/
        `;_:    `"'
      .'"""""`.
     /,  ya ,\\
    //  404!  \\
    `-._______.-'
    ___`. | .'___
   (______|______)
				</pre>
			<?php endif; ?>
		</div>
		<?php $this->need('sidebar.php'); ?>
	</div>
	<!-- content end -->
<?php $this->need('footerdiv.php');?>
<?php $this->need('footer.php'); ?>