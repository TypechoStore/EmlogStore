<?php
/**
 * 归档页面
 * @package custom
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;$blogtype="blog-article-sidebar";
?>
<?php $this->need('header.php'); ?>
<?php $this->need('headernav.php');?>

<!-- content srart -->
<div class="am-g am-g-fixed blog-fixed blog-content">
    <div class="am-u-sm-12">
        <h1 class="blog-text-center"><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></h1>
		<?php $this->widget('Widget_Contents_Post_Recent', 'pageSize=10000')->to($archives);?>
		<?php
			$i=1;$year=0; $mon=0;
			$output = "";
			while($archives->next()):
			$year_tmp = date('Y',$archives->created);
			$mon_tmp = date('m',$archives->created);
			if ($mon != $mon_tmp && $mon > 0){
				$output .= '
						</ul>
						<br />
				';  //结束拼接
			}
			if ($year != $year_tmp && $year > 0){
					$output .= "
					</div>
				";
			}
			if ($year != $year_tmp) {
				$year = $year_tmp;
				$output .= "
					<div class=\"timeline-year\">
						<h1>".$year."年</h1>
						<hr />
				";
			}
			if ($mon != $mon_tmp) {
				$mon = $mon_tmp;
				$output .= "
						<ul>
							<h3>".$mon."月</h3>
							<hr />
				";
			}
			$output .= "
				<li><span class=\"am-u-sm-4 am-u-md-2 timeline-span\">".date('Y/m/d',$archives->created)."</span><span class=\"am-u-sm-8 am-u-md-6\"><a href=\"".$archives->permalink."\">".$archives->title."</a></span><span class=\"am-u-sm-4 am-u-md-2 am-hide-sm-only\">".$archives->commentsNum."</span><span class=\"am-u-sm-4 am-u-md-2 am-hide-sm-only\">".($archives->user->screenName?$archives->user->screenName:$archives->user->name)."</span></li>
			";
			$i++;
			endwhile;
			echo $output.'
				</div>
				<hr />
			';
		?>
    </div>

</div>
<!-- content end -->
<?php $this->need('footerdiv.php');?>
<?php $this->need('footer.php'); ?>