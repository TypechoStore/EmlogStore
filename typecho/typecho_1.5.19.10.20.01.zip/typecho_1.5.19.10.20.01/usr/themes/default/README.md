Typecho Moblog Theme 这是 Typecho 1.5 系统的一套默认皮肤
---
# 模板截图

<img src="https://img14.360buyimg.com/uba/jfs/t1/44946/39/14042/64439/5dabf20eE73b0eb87/a7cff04a0ae76ac8.png" width="100%">

# 模板介绍

这是 Typecho 1.5 系统的一套默认皮肤

# 版本记录

2019-10-20 V1.0.1

	第一个版本