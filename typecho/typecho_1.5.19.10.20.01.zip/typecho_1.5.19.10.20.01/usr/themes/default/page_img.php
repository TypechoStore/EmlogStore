<?php
/**
 * 相册页面
 * @package custom
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;$blogtype="blog-article-sidebar";
?>
<?php $this->need('header.php'); ?>
<?php $this->need('headernav.php');?>
<!-- content srart -->
<div class="am-g am-g-fixed blog-fixed blog-content">
	<?php
	$page_rec = $this->options->albumPicNum ? intval($this->options->albumPicNum) : 0;
	if($page_rec>0){
		$albumCateId=$this->options->albumCateId;
		$albumCateIdArr = explode(',', $albumCateId);
		$albumCateIdArr = array_unique($albumCateIdArr);
		if($albumCateId!=null&&$albumCateId!=0) {
			$query= $this->db->select()->from('table.contents')->join('table.relationships', 'table.contents.cid = table.relationships.cid',Typecho_Db::INNER_JOIN)->join('table.metas', 'table.relationships.mid = table.metas.mid',Typecho_Db::INNER_JOIN)->where('table.metas.mid in ?', $albumCateIdArr)->where('table.contents.type = ?', 'post')->where('table.contents.status = ?', 'publish')->order('table.contents.created',Typecho_Db::SORT_DESC);
		}else{
			$query= $this->db->select()->from('table.contents')->join('table.relationships', 'table.contents.cid = table.relationships.cid',Typecho_Db::INNER_JOIN)->join('table.metas', 'table.relationships.mid = table.metas.mid',Typecho_Db::INNER_JOIN)->where('table.contents.type = ?', 'post')->where('table.contents.status = ?', 'publish')->order('table.contents.created',Typecho_Db::SORT_DESC);
		}
		$result = $this->db->fetchAll($query);
		$album=array();
		$temi=0;
		foreach($result as $value){
			$match_str = "/((http)+.*?((.gif)|(.jpg)|(.bmp)|(.png)|(.GIF)|(.JPG)|(.PNG)|(.BMP)))/";
			preg_match_all ($match_str,$value['text'],$matches,PREG_PATTERN_ORDER);
			if(count($matches[1])==0){
				continue;
			}
			for($j=0;$j<count($matches[1]);$j++){
				$album[$temi]['src']=$matches[1][$j];
				$album[$temi]['title']=$value['title'];
				$album[$temi]['created']=$value['created'];
				$temi++;
			}
		}
		$albumArr = array_slice($album, 0, $page_rec);
		?>
		<figure data-am-widget="figure" class="am am-figure am-figure-default" data-am-figure="{pureview:'true'}">
		  <div id="container">
				<?php
				foreach($albumArr as $value){
					?>
					<div class="albumitem"><img src="<?=$value["src"];?>"><h3><?=$value["title"];?></h3></div>
					<?php
				}
			  ?>
		</div>
		</figure>
		<?php
	}
	?>
</div>
<!-- content end -->
<?php $this->need('footerdiv.php');?>
<?php $this->need('footer.php'); ?>