<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!doctype html>
<html>
<head>
  <meta charset="<?php $this->options->charset(); ?>">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php $this->archiveTitle(array(
            'category'  =>  _t('分类 %s 下的文章'),
            'search'    =>  _t('包含关键字 %s 的文章'),
            'tag'       =>  _t('标签 %s 下的文章'),
            'author'    =>  _t('%s 发布的文章')
        ), '', ' - '); ?><?php $this->options->title(); ?></title>
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <meta name="renderer" content="webkit">
  <meta http-equiv="Cache-Control" content="no-siteapp"/>
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <meta name="apple-mobile-web-app-title" content="Amaze UI"/>
  <meta name="msapplication-TileColor" content="#0e90d2">
  <meta name="msapplication-TileImage" content="<?php $this->options->themeUrl('assets/i/app-icon72x72@2x.png'); ?>">
  <link rel="icon" type="image/png" href="<?php $this->options->themeUrl('assets/i/favicon.png'); ?>">
  <link rel="icon" sizes="192x192" href="<?php $this->options->themeUrl('assets/i/app-icon72x72@2x.png'); ?>">
  <link rel="apple-touch-icon-precomposed" href="<?php $this->options->themeUrl('assets/i/app-icon72x72@2x.png'); ?>">
  <link rel="stylesheet" href="<?php $this->options->themeUrl('assets/css/amazeui.min.css'); ?>">
  <link rel="stylesheet" href="<?php $this->options->themeUrl('assets/css/app.css'); ?>">
  <!-- 通过自有函数输出HTML头部信息 -->
  <?php $this->header(); ?>
</head>
<body id="<?php if(isset($blogtype)){echo $blogtype;}?>">
<!--[if lt IE 9]>
    <script type="text/javascript">
        var str = '<p class="browsehappy">你正在使用<strong>过时</strong>的浏览器，此网站框架暂不支持。 请 <a href="https://browsehappy.com/" target="_blank">升级浏览器</a>以获得更好的体验！</p>';
        document.writeln("<pre style='text-align:center;color:#fff;background-color:#0cc; height:100%;border:0;position:fixed;top:0;left:0;width:100%;z-index:1234'>" +
                "<h2 style='padding-top:200px;margin:0'><strong>" + str + "<br/></strong></h2><h2 style='margin:0'><strong>如果你的使用的是双核浏览器,请切换到极速模式访问<br/></strong></h2></pre>");
        document.execCommand("Stop");
    </script>
<![endif]-->