<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<div class="am-u-md-4 am-u-sm-12 blog-sidebar">
	<?php if (!empty($this->options->sidebarBlock) && in_array('ShowAboutMe', $this->options->sidebarBlock)): ?>
	<div class="blog-sidebar-widget blog-bor">
		<h2 class="blog-text-center blog-title"><span>关于我</span></h2>
		<?php echo $this->options->aboutMyFace?'<img src="'.$this->options->aboutMyFace.'" alt="about me" class="blog-entry-img" >':""; ?>
		<p><?php echo $this->options->aboutMyNick?$this->options->aboutMyNick:""; ?></p>
		<p><?php echo $this->options->aboutMyInfo?$this->options->aboutMyInfo:""; ?></p>
	</div>
	<?php endif; ?>
	<?php if (!empty($this->options->sidebarBlock) && in_array('ShowContactMe', $this->options->sidebarBlock)): ?>
	<div class="blog-sidebar-widget blog-bor">
		<h2 class="blog-text-center blog-title"><span>联系我</span></h2>
		<p>
			<a href="<?php echo $this->options->contactQQ?"http://wpa.qq.com/msgrd?v=3&uin=".$this->options->contactQQ."&site=qq&menu=yes":"javascript:;"; ?>" target="_blank"><span class="am-icon-qq am-icon-fw am-primary blog-icon blog-icon"></span></a>
			<a <?php if($this->options->contactWeixin){?>data-am-modal="{target: '#weixin-modal'}"<?php }?> href="javascript:;"><span class="am-icon-weixin am-icon-fw blog-icon blog-icon"></span></a>
			<a href="<?php echo $this->options->contactWeibo?$this->options->contactWeibo:"javascript:;"; ?>" target="_blank"><span class="am-icon-weibo am-icon-fw blog-icon blog-icon"></span></a>
			<a href="<?php echo $this->options->contactGithub?$this->options->contactGithub:"javascript:;"; ?>" target="_blank"><span class="am-icon-github am-icon-fw blog-icon blog-icon"></span></a>
			<a href="<?php echo $this->options->contactRenren?$this->options->contactRenren:"javascript:;"; ?>" target="_blank"><span class="am-icon-renren am-icon-fw blog-icon blog-icon"></span></a>
		</p>
	</div>
	<?php endif; ?>
	<?php if (!empty($this->options->sidebarBlock) && in_array('ShowTagCloud', $this->options->sidebarBlock)): ?>
	<div class="blog-clear-margin blog-sidebar-widget blog-bor am-g ">
		<h2 class="blog-title"><span>标签云</span></h2>
		<div class="am-u-sm-12 blog-clear-padding">
		<?php
		$randomcolor=array("am-btn-default","am-btn-primary","am-btn-secondary","am-btn-success","am-btn-warning","am-btn-danger");
		?>
		<?php $this->widget('Widget_Metas_Tag_Cloud', 'ignoreZeroCount=1&limit=30')->to($tags); ?>
		<?php while($tags->next()): ?>
		<a href="<?php $tags->permalink(); ?>" title='<?php $tags->name(); ?>' class="am-btn <?=$randomcolor[rand(0,5)];?>"><?php $tags->name(); ?></a>
		<?php endwhile; ?>
		</div>
	</div>
	<?php endif; ?>
	<?php if (!empty($this->options->sidebarBlock) && in_array('ShowRecentPosts', $this->options->sidebarBlock)): ?>
	<div class="blog-sidebar-widget blog-bor">
		<h2 class="blog-title"><span><?php _e('最新文章'); ?></span></h2>
		<ul class="am-list">
			<?php $this->widget('Widget_Contents_Post_Recent')
            ->parse('<li><a href="{permalink}">{title}</a></li>'); ?>
		</ul>
	</div>
	<?php endif; ?>
	<?php if (!empty($this->options->sidebarBlock) && in_array('ShowRecentComments', $this->options->sidebarBlock)): ?>
	<div class="blog-sidebar-widget blog-bor">
		<h2 class="blog-title"><span><?php _e('最近回复'); ?></span></h2>
		<ul class="am-list">
			<?php $this->widget('Widget_Comments_Recent')->to($comments); ?>
			<?php while($comments->next()): ?>
			<li><a href="<?php $comments->permalink(); ?>"><?php $comments->author(false); ?></a>: <?php $comments->excerpt(35, '...'); ?></li>
			<?php endwhile; ?>
		</ul>
	</div>
	<?php endif; ?>
	<?php if (!empty($this->options->sidebarBlock) && in_array('ShowCategory', $this->options->sidebarBlock)): ?>
	<div class="blog-sidebar-widget blog-bor">
		<h2 class="blog-title"><span><?php _e('分类'); ?></span></h2>
		<ul class="am-list">
			<?php $this->widget('Widget_Metas_Category_List')->listCategories('wrapClass=widget-list'); ?>
		</ul>
	</div>
    <?php endif; ?>
	<?php if (!empty($this->options->sidebarBlock) && in_array('ShowArchive', $this->options->sidebarBlock)): ?>
	<div class="blog-sidebar-widget blog-bor">
		<h2 class="blog-title"><span><?php _e('归档'); ?></span></h2>
		<ul class="am-list">
			<?php $this->widget('Widget_Contents_Post_Date', 'type=month&format=F Y')
            ->parse('<li><a href="{permalink}">{date}</a></li>'); ?>
		</ul>
	</div>
    <?php endif; ?>
	<?php if (!empty($this->options->sidebarBlock) && in_array('ShowOther', $this->options->sidebarBlock)): ?>
	<div class="blog-sidebar-widget blog-bor">
		<h2 class="blog-text-center blog-title"><span>Other</span></h2>
		<p>
			<?php if($this->user->hasLogin()): ?>
				<a href="<?php $this->options->adminUrl(); ?>" title="<?php $this->user->screenName(); ?>"><span class="am-icon-user am-icon-fw am-primary blog-icon"></span></a>
				<a href="<?php $this->options->logoutUrl(); ?>" title="登出"><span class="am-icon-sign-out am-icon-fw blog-icon"></span></a>
			<?php else: ?>
				<a href="<?php $this->options->adminUrl('login.php'); ?>" title="登入"><span class="am-icon-sign-in am-icon-fw blog-icon"></span></a>
            <?php endif; ?>
			<a href="<?php $this->options->feedUrl(); ?>" title="<?php _e('文章 RSS'); ?>"><span class="am-icon-rss am-icon-fw blog-icon"></span></a>
			<a href="<?php $this->options->commentsFeedUrl(); ?>" title="<?php _e('评论 RSS'); ?>"><span class="am-icon-rss-square am-icon-fw blog-icon"></span></a>
		</p>
	</div>
	<?php endif; ?>
</div>