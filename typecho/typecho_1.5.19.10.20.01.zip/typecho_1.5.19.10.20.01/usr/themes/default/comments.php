<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<div id="comments" class="am-u-sm-centered am-g-fixed">
	<?php $this->comments()->to($comments); ?>
	<?php if($this->allow('comment')): ?>
		<div id="<?php $this->respondId(); ?>" class="respond">
			<div></div>
            <h6 class="blog-comment"><?php _e('添加新评论'); ?></h6>
			<form class="am-form am-g" method="post" action="<?php $this->commentUrl() ?>" id="comment-form" role="form">
				<div class="comment-box">
					<div class="comment-form">
						<fieldset class="am-form-set">
							<?php if($this->user->hasLogin()): ?>
								<div class="am-form-group">
									<small>
										<?php _e('当前用户: '); ?><a href="<?php $this->options->profileUrl(); ?>"><?php $this->user->screenName(); ?></a>
										<a href="<?php $this->options->logoutUrl(); ?>" title="Logout"><?php _e('退出'); ?></a>
									</small>
								</div>
							<?php else: ?>
								<div class="am-form-group am-u-sm-4 blog-clear-left">
									<input type="text" name="author" id="author" placeholder="<?php _e('昵称'); ?>" value="<?php $this->remember('author'); ?>" aria-label="Username" aria-describedby="ico-name" required />
								</div>
								<div class="am-form-group am-u-sm-4">
									<input type="email" name="mail" id="mail" placeholder="<?php _e('邮箱'); ?>" value="<?php $this->remember('mail'); ?>" aria-label="Email" aria-describedby="ico-email" <?php if ($this->options->commentsRequireMail): ?> required <?php endif; ?> />
								</div>
								<div class="am-form-group am-u-sm-4 blog-clear-right">
									<input type="url" name="url" id="url" placeholder="<?php _e('网站'); ?>" value="<?php $this->remember('url'); ?>" aria-label="Email" aria-describedby="ico-url" <?php if ($this->options->commentsRequireURL): ?> required <?php endif; ?> />
								</div>
							<?php endif; ?>
							<div class="am-form-group">
								<textarea rows="8" cols="50" name="text" id="respond-textarea" placeholder="发表一下观点吧" required><?php $this->remember('text'); ?></textarea>
							</div>
							<p>
								<button type="submit" class="am-btn am-btn-success am-btn-xs">提交</button>
								<?php $comments->cancelReply('<button type="button" class="am-btn am-btn-default am-btn-xs">取消回复</button>'); ?>
							</p>
						</fieldset>
						<div style="clear:both;"></div>
					</div>
				</div>
			</form>
		</div>
	<?php else: ?>
		<h3><?php _e('暂时无法评论哦~'); ?></h3>
	<?php endif; ?>
	<?php if ($comments->have()){?>
		<h6 class="blog-comment"><?php $this->commentsNum(_t('暂无评论'), _t('仅有一条评论'), _t('已有 %d 条评论')); ?></h6>
		<?php function threadedComments($comments, $singleCommentOptions) {
			//开始自定义评论区域
			$commentClass = '';
			$singleCommentOptions->dateFormat = 'Y-m-d H:i:s';
			$singleCommentOptions->replyWord = '回复';
			if ($comments->authorId) {
				if ($comments->authorId == $comments->ownerId) {
					$commentClass .= ' comment-by-author';
				} else {
					$commentClass .= ' comment-by-user';
				}
			}
			$commentLevelClass = $comments->_levels > 0 ? ' comment-child' : ' comment-parent';
			?>
			<div id="<?php $comments->theId(); ?>" class="am-comment comment-body<?php
				if ($comments->_levels > 0) {
					echo ' comment-child';
					$comments->levelsAlt(' comment-level-odd', ' comment-level-even');
				} else {
					echo ' comment-parent';
				}
				$comments->alt(' comment-odd', ' comment-even');
				echo $commentClass;
				//下面正式自定义
				?>">
				<a href="javascript:;">
				  <?php
					$number=$comments->mail?$comments->mail:0;
					echo '<img src="https://q2.qlogo.cn/headimg_dl? bs='.$number.'&dst_uin='.$number.'&dst_uin='.$number.'&;dst_uin='.$number.'&spec=100&url_enc=0&referer=bu_interface&term_type=PC" class="am-comment-avatar" width="48" height="48">';
				  ?>
				</a>
				<div class="am-comment-main">
				  <header class="comment-author am-comment-hd">
					<div class="am-comment-meta comment-reply">
					  <a href="#link-to-user" class="am-comment-author">
						<?php
						$singleCommentOptions->beforeAuthor();
						$comments->author();
						$singleCommentOptions->afterAuthor(); //输出评论者
						?>
					  </a> 评论于 
					  <time datetime="" title="">
						<a href="<?php $comments->permalink(); ?>">
							<?php
								$singleCommentOptions->beforeDate();
								//$comments->date($singleCommentOptions->dateFormat);
								$comments->dateWord();
								$singleCommentOptions->afterDate();  //输出评论日期
							?>
						</a>|
						<?php $comments->reply($singleCommentOptions->replyWord); //输出 回复 链接?>
					  </time>
					</div>
				  </header>
				  <div class="am-comment-bd">
					<p>
						<?php get_comment_at($comments->coid); ?>
						<?php $comments->content(); //输出评论内容，包含 <p></p> 标签 ?>
					</p>
				  </div>
				</div>
			</div>
			<?php if ($comments->levels > 0) { //子回复 ?>
			<?php if ($comments->children) { ?>
			<div class="comment-childrens">
				<?php $comments->threadedComments($singleCommentOptions); //评论嵌套?>
			</div>
			<?php } ?>
			<?php }else{ //父回复 ?>
			<?php if ($comments->children) { ?>
			<div class="comment-children">
				<?php $comments->threadedComments($singleCommentOptions); //评论嵌套?>
			</div>
			<?php } ?>
			<?php } ?>
		<?php } //结束自定义评论区域?>
		<?php $comments->listComments(); ?>
		<style>
		.page-nav{font-size:9pt;float:right;}
		.page-nav a:link,.page-nav a:visited,.page-nav a:hover,.page-nav a:active{color:#fff;}
		.page-nav .current a:link,.page-nav .current a:visited,.page-nav .current a:hover,.page-nav .current a:active{background-color:#fff;color:green;}
		.page-nav div{text-align:center;line-height:30px;width:50px;height:30px;margin:0px 5px;float:left;background-color:green;border:1px solid green;}
		.page-nav a{display:block;text-align:center;line-height:28px;}
		</style>
		<?php $comments->pageNav('首页', '尾页', 1, '...', array('wrapTag' => 'nav', 'wrapClass' => 'page-nav', 'itemTag' => 'div', 'prevClass' => 'prev', 'nextClass' => 'next', 'currentClass' => 'current' )); ?>
			
	<?php }else{?>
		<h6 class="blog-comment"><?php $this->commentsNum(_t('暂无评论'), _t('仅有一条评论'), _t('已有 %d 条评论')); ?></h6>
	<?php }?>
</div>