<?php
/**
 * 注册页面
 * @package custom
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
if($this->user->hasLogin()){$this->response->redirect($this->options->siteUrl);}
?>
<?php $this->need('header.php'); ?>
<div class="log"> 
  <div class="am-g">
  <div class="am-u-lg-3 am-u-md-6 am-u-sm-8 am-u-sm-centered log-content">
    <h1 class="log-title am-animation-slide-top"><a href="<?=$this->options->siteUrl;?>"><?php $this->options->title(); ?></a></h1>
    <br>
    <form class="am-form" id="log-form" action="<?php $this->options->registerAction(); ?>" method="post">
      <div class="am-input-group am-radius am-animation-slide-left">       
        <input type="text" id="name" class="am-radius" id="name" name="name" placeholder="用户名" value="" autofocus />
        <span class="am-input-group-label log-icon am-radius"><i class="am-icon-user am-icon-sm am-icon-fw"></i></span>
      </div>
      <br>
      <div class="am-input-group am-animation-slide-left log-animation-delay">       
        <input type="email" id="mail" name="mail" placeholder="Email" value="" />
        <span class="am-input-group-label log-icon am-radius"><i class="am-icon-lock am-icon-sm am-icon-fw"></i></span>
      </div>
      <br>
      <button type="submit" class="am-btn am-btn-primary am-btn-block am-btn-lg am-radius am-animation-slide-bottom log-animation-delay-b">注 册</button>
      <!--
	  <p>
		  <div class="am-btn-group am-animation-slide-bottom log-animation-delay-b">
			  <a href="#" class="am-btn am-btn-secondary am-btn-xs"><i class="am-icon-github am-icon-sm"></i> Github</a>
			  <a href="#" class="am-btn am-btn-success am-btn-xs"><i class="am-icon-google-plus-square am-icon-sm"></i> Google+</a>
			  <a href="#" class="am-btn am-btn-primary am-btn-xs"><i class="am-icon-stack-overflow am-icon-sm"></i> stackOverflow</a>
		  </div>
	  </p>
	  -->
    </form>
  </div>
  </div>
  <footer class="log-footer">   
    © <?php echo date('Y'); ?> <a href="<?php $this->options->siteUrl(); ?>" target="_blank"><?php $this->options->title(); ?>.</a> <?php _e('Powered by <a href="http://www.typecho.org">Typecho</a>'); ?>. Theme By <a href="https://www.tongleer.com" target="_blank">Tongleer</a>.
  </footer>
</div>
<script>
$(document).ready(function () {
    $('#name').focus();
});
</script>
<?php $this->need('footer.php'); ?>
