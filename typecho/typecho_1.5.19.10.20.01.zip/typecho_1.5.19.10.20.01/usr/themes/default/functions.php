<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

function themeConfig($form) {
    $logoUrl = new Typecho_Widget_Helper_Form_Element_Text('logoUrl', NULL, NULL, _t('站点 LOGO 地址'), _t('在这里填入一个图片 URL 地址, 以在网站标题前加上一个 LOGO'));
    $form->addInput($logoUrl);
	
	$sliderPostId = new Typecho_Widget_Helper_Form_Element_Text('sliderPostId', NULL, NULL, _t('指定幻灯片文章ID'), _t('多个请用英文逗号隔开，默认为空或0即为不显示幻灯片。'));
    $form->addInput($sliderPostId);
	
	$albumCateId = new Typecho_Widget_Helper_Form_Element_Text('albumCateId', array("value"), NULL, _t('指定哪一分类ID的图片显示到相册'), _t('多个分类ID请用英文逗号隔开，默认为空或0即为所有分类。'));
    $form->addInput($albumCateId);
	
	$albumPicNum = new Typecho_Widget_Helper_Form_Element_Text('albumPicNum', array("value"), 20, _t('指定相册中图片显示的数量'), _t('填写一个数字，默认为空或0即为不显示。'));
    $form->addInput($albumPicNum);
	
	$homeCateId = new Typecho_Widget_Helper_Form_Element_Text('homeCateId', NULL, NULL, _t('指定首页栏目ID'), _t('多个分类ID请用英文逗号隔开，默认为空或0即为不显示栏目。'));
    $form->addInput($homeCateId);
    
    $sidebarBlock = new Typecho_Widget_Helper_Form_Element_Checkbox('sidebarBlock', 
    array('ShowAboutMe' => _t('显示关于我'),
	'ShowContactMe' => _t('显示联系我'),
	'ShowTagCloud' => _t('显示标签云'),
	'ShowRecentPosts' => _t('显示最新文章'),
    'ShowRecentComments' => _t('显示最近回复'),
    'ShowCategory' => _t('显示分类'),
    'ShowArchive' => _t('显示归档'),
    'ShowOther' => _t('显示其它杂项')),
    array('ShowAboutMe', 'ShowContactMe', 'ShowTagCloud', 'ShowRecentPosts', 'ShowRecentComments', 'ShowCategory', 'ShowArchive', 'ShowOther'), _t('侧边栏显示'));
    $form->addInput($sidebarBlock->multiMode());
	
	$aboutMyFace = new Typecho_Widget_Helper_Form_Element_Text('aboutMyFace', NULL, NULL, _t('关于我的头像'), _t('在这里填入关于我中显示的头像图片Url。'));
    $form->addInput($aboutMyFace);
	
	$aboutMyNick = new Typecho_Widget_Helper_Form_Element_Text('aboutMyNick', NULL, NULL, _t('关于我的昵称'), _t('在这里填入关于我中显示的昵称。'));
    $form->addInput($aboutMyNick);
	
	$aboutMyInfo = new Typecho_Widget_Helper_Form_Element_Text('aboutMyInfo', NULL, NULL, _t('关于我的描述'), _t('在这里填入关于我中显示的描述。'));
    $form->addInput($aboutMyInfo);
	
	$contactQQ = new Typecho_Widget_Helper_Form_Element_Text('contactQQ', NULL, NULL, _t('联系QQ号码'), _t('在这里填入一个QQ号码。'));
    $form->addInput($contactQQ);
	
	$contactWeixin = new Typecho_Widget_Helper_Form_Element_Text('contactWeixin', NULL, NULL, _t('联系微信二维码'), _t('在这里填入一个微信二维码图片URL地址。'));
    $form->addInput($contactWeixin);
	
	$contactWeibo = new Typecho_Widget_Helper_Form_Element_Text('contactWeibo', NULL, NULL, _t('联系微博网址'), _t('在这里填入一个微博URL地址。'));
    $form->addInput($contactWeibo);
	
	$contactGithub = new Typecho_Widget_Helper_Form_Element_Text('contactGithub', NULL, NULL, _t('联系Github地址'), _t('在这里填入一个Github地址。'));
    $form->addInput($contactGithub);
	
	$contactRenren = new Typecho_Widget_Helper_Form_Element_Text('contactRenren', NULL, NULL, _t('联系人人网址'), _t('在这里填入一个人人URL地址。'));
    $form->addInput($contactRenren);
	
	$foot_custom1 = new Typecho_Widget_Helper_Form_Element_Textarea('foot_custom1', array('value'), '<h3>自定义内容1</h3><p><small>自定义简介1</small></p>', _t('底部左侧自定义代码'), _t('在这里填入底部左侧自定义代码'));
    $form->addInput($foot_custom1);
	
	$foot_custom2 = new Typecho_Widget_Helper_Form_Element_Textarea('foot_custom2', array('value'), '<h3>自定义内容2</h3><p><small>自定义简介2</small></p>', _t('底部中间自定义代码'), _t('在这里填入底部中间自定义代码'));
    $form->addInput($foot_custom2);
	
	$foot_custom3 = new Typecho_Widget_Helper_Form_Element_Textarea('foot_custom3', array('value'), '
		<h1>自定义内容3</h1>
		<h3>自定义简介3</h3>
		<p>
			<ul>
				<li>firt</li>
				<li>second</li>
				<li>third</li>
			</ul>
		</p>
	', _t('底部右侧自定义代码'), _t('在这里填入底部右侧自定义代码'));
    $form->addInput($foot_custom3);
	
	$foot_count = new Typecho_Widget_Helper_Form_Element_Textarea('foot_count', array('value'), '', _t('统计代码'), _t('在这里填入统计代码'));
    $form->addInput($foot_count);
	
	$friendlinkvalue='
		[{
			"name":"同乐儿",
			"link":"https://www.tongleer.com",
			"target":"_blank",
			"rel":"friend",
			"detail":"共同分享快乐",
			"icon":"2293338477",
			"order":"1"
		},{
			"name":"Amaze",
			"link":"http://amazeui.clouddeep.cn",
			"target":"_blank",
			"rel":"",
			"detail":"中国首个开源HTML5跨屏前端框架",
			"icon":"http://amazeui.clouddeep.cn/assets/i/favicon.png",
			"order":"2"
		}]
	';
	$friendlink = new Typecho_Widget_Helper_Form_Element_Textarea('friendlink', array("value"), $friendlinkvalue, _t('友情链接'), _t('此处可以随意添加链接到导航栏的下拉菜单中，name=链接名，link=链接地址，target=打开方式，rel=链接关系，detail=链接描述，icon=链接图标(支持QQ号)，order=链接排序。注：target包括_blank、_self、_parent、_top；rel可以指定任意关系名称；icon可以是一个QQ号，也可以是链接图标的地址，如果是QQ号，那么既包含QQ链接也包含QQ头像；order的排序规则是越大越靠前。友情链接必须按照以下格式填写：
		<pre>
[{
	"name":"同乐儿",
	"link":"https://www.tongleer.com",
	"target":"_blank",
	"rel":"friend",
	"detail":"共同分享快乐",
	"icon":"",
	"order":"1"
},{
	"name":"Amaze",
	"link":"http://amazeui.clouddeep.cn",
	"target":"_blank",
	"rel":"",
	"detail":"中国首个开源HTML5跨屏前端框架",
	"icon":"",
	"order":"2"
}]
		</pre>
	'));
	$form->addInput($friendlink);
}

function themeFields($layout) {
    $src = new Typecho_Widget_Helper_Form_Element_Select('src', array(_t('内容'),_t('附件')), NULL, _t('图片源'), _t('选择前台展示的图片源'));
	$layout->addItem($src);
	
	$thumb = new Typecho_Widget_Helper_Form_Element_Text('thumb', NULL, NULL, _t('封面图片'), _t('在这里填写封面图片的地址（留空将按照图片源获取图片）'));
	$layout->addItem($thumb);
}

/*输出友情链接*/
function printFriends($link){
	?>
	<?php
	$friendlink=json_decode($link,true);
	if(isset($friendlink)){
		$friendlinks='<p><marquee direction="up" behavior="scroll" scrollamount="1" scrolldelay="10" loop="-1" onMouseOver="this.stop()" onMouseOut="this.start()" width="100%" height="30" style="text-align:center;">友情链接：';
		array_multisort(array_column($friendlink, 'order'), SORT_DESC, $friendlink);
		$isHaveLink=false;
		foreach($friendlink as $value){
			if($value["name"]!=null&&$value["link"]!=null){
				$isHaveLink=true;
				$icon=$value["icon"]!=""?$value["icon"]:"0";
				$iconlink=is_numeric($icon)?'https://wpa.qq.com/msgrd?v=3&uin='.$icon.'&site=qq&menu=yes':$value["link"];
				$iconimg=is_numeric($icon)?'https://q1.qlogo.cn/g?b=qq&nk='.$icon.'&s=100':$icon;
				$friendlinks.='<a href=javascript:open("'.$iconlink.'");><img src="'.$iconimg.'" width="16" /></a><a href="'.$value["link"].'" target="'.$value["target"].'" title="'.$value["detail"].'" rel="'.$value["rel"].'">'.$value["name"].'</a>&nbsp;';
			}
		}
		$friendlinks.='</marquee></p>';
		if(!$isHaveLink){
			$friendlinks='';
		}
		echo $friendlinks;
	}
}

//获取文章内容图
function get_post_html_img($obj){
	if(is_numeric($obj)){
		$cid = $obj;
	}else{
		$cid = $obj->cid;
	}
	$db = Typecho_Db::get();
	$rs = $db->fetchRow($db->select('table.contents.text')
	->from('table.contents')
	->where('cid=?', $cid));
	$text = $rs['text'];
	$pattern = '/\<img.*?src\=\"(.*?)\"[^>]*>/i';
	$patternMD = '/\!\[.*?\]\((http(s)?:\/\/.*?(jpg|png))/i';
	$patternMDfoot = '/\[.*?\]:\s*(http(s)?:\/\/.*?(jpg|png))/i';
	if (preg_match($patternMDfoot, $text, $imgs)) {
		$img=$imgs[1];
	} else if (preg_match($patternMD, $text, $imgs)) {
		$img=$imgs[1];
	} else if (preg_match($pattern, $text, $imgs)) {
		$img=$imgs[1];
	} else {
		$img ="";
	}
	return $img;
}
//获取文章附件图
function getPostAttImg($obj) {
	$atts = array();
	$img ="";
	if(is_numeric($obj)){
		$db = Typecho_Db::get();
		$rs = $db->fetchAll($db->select('table.contents.text')
			->from('table.contents')
			->where('table.contents.parent=?', $obj)
			->order('table.contents.cid', Typecho_Db::SORT_ASC));
		foreach($rs as $attach) {
			$attach = unserialize($attach['text']);
			if(strpos($attach['mime'],"image/")!==false) {
				$query= $db->select('value')->from('table.options')->where('name = ?', 'siteUrl'); 
				$row = $db->fetchRow($query);
				$atts[] = array($attach['name'], $row["value"].$attach['path']);
				$img =$atts[0][1];
			}
		}
	}else{
		$stack = $obj->attachments()->stack;
		for($i = 0; $i < count($stack); $i++) {
			$att = $stack[$i]['attachment'];
			if($att->isImage) {
				$atts[] = array('name' => $att->name, 'url' => $att->url);
				$img =$atts[0]["url"];
			}
		}
	}
	return $img;
}
//获取文章图片 整合 getPostAttImg() 与 get_post_html_img()
function getPostImg($obj) {
	$imgs = array();
	$img = "";
	if(is_numeric($obj)){
		$db = Typecho_Db::get();
		$queryField= $db->select()->from('table.fields')->where('name = ?', 'thumb')->where('cid = ?', $obj)->where('type = ?', "str"); 
		$rowsField = $db->fetchRow($queryField);
		if($rowsField){
			if(!empty($rowsField)&&$rowsField["str_value"] != ""){
				array_push($imgs,$rowsField["str_value"]);
				$img=$imgs[0];
			}else{
				$queryField= $db->select()->from('table.fields')->where('name = ?', 'src')->where('cid = ?', $obj)->where('type = ?', "str"); 
				$rowsField = $db->fetchRow($queryField);
				if($rowsField["str_value"] == 0) {
					$img = get_post_html_img($obj);
				}elseif($rowsField["str_value"] == 1) {
					$img = getPostAttImg($obj);
				}
			}
		}
	}else{
		if($obj->fields->thumb) {
			array_push($imgs,$obj->fields->thumb);
			$img=$imgs[0];
		}else{
			if($obj->fields->src == 0) {
				$img = get_post_html_img($obj);
			}elseif($obj->fields->src == 1) {
				$img = getPostAttImg($obj);
			}
		}
	}
	return $img;
}
/*获取文章url*/
function getArticleUrl($cid){
	$options = Typecho_Widget::widget('Widget_Options');
	$db = Typecho_Db::get();
	$posts= $db->fetchRow($db->select()->from('table.contents')
		->where('table.contents.status = ?', 'publish')
		->where('table.contents.cid = ?', $cid)
		->order('table.contents.created', Typecho_Db::SORT_DESC));
	//去掉附件
	$type = $posts['type'];
	if(true){
		$routeExists = (NULL != Typecho_Router::get($type));
		$pathinfo = $routeExists ? Typecho_Router::url($type, $posts) : '#';
		$permalink = Typecho_Common::url($pathinfo, $options->index);
		return $permalink;
	}
}
//格式化摘要
function formatExcerpt($text, $strlen = null,$trim="..."){
	$content=Markdown::convert($text);
	$contents = explode('<!--more-->', $content);
    list($excerpt) = $contents;
	$excerpt=Typecho_Common::fixHtml($excerpt);
	$excerpt = preg_replace('/\<img.*?src\=\"(.*?)\"[^>]*>/i', '', $excerpt);
	if ($strlen) {
		$excerpt = Typecho_Common::subStr(strip_tags($excerpt), 0, $strlen, $trim);
	}
	return $excerpt;
}
/**
 * 获取gravatar头像地址 
 * 
 * @param string $mail 
 * @param int $size 
 * @param string $rating 
 * @param string $default 
 * @param bool $isSecure 
 * @return string
 */
function gravatarUrl($mail, $size, $rating, $default, $isSecure = false){
		$reg = "/^\d{5,11}@[qQ][Qq]\.(com)$/";
		if (preg_match($reg, $mail)) {
			$img    = explode("@", $mail);
			$url = "//q2.qlogo.cn/headimg_dl?dst_uin={$img[0]}&spec=240";
		} else {
			if (defined('__TYPECHO_GRAVATAR_PREFIX__')) {
				$url = __TYPECHO_GRAVATAR_PREFIX__;
			} else {
				$url = $isSecure ? 'https://secure.gravatar.com' : 'http://www.gravatar.com';
				$url .= '/avatar/';
			}
			if (!empty($mail)) {
				$url .= md5(strtolower(trim($mail)));
			}
			$url .= '?s=' . $size;
			$url .= '&amp;r=' . $rating;
			$url .= '&amp;d=' . $default;
		}
		return $url;
}
/*
* 回复评论添加 @ 标签
*/
function get_comment_at($coid){
    $db   = Typecho_Db::get();
    $prow = $db->fetchRow($db->select('parent')->from('table.comments')->where('coid = ? AND status = ?', $coid, 'approved'));
    $parent = $prow['parent'];
    if ($parent != "0") {
        $arow = $db->fetchRow($db->select('author')->from('table.comments')->where('coid = ? AND status = ?', $parent, 'approved'));
        $author = $arow['author'];
        $href = '回复 <a href="#comment-' . $parent . '">@' . $author . '</a>';
        echo $href;
    } else {
        echo '';
    }
}