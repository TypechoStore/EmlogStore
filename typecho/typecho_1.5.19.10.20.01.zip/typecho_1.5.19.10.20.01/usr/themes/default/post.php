<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit;$blogtype="blog-article-sidebar"; ?>
<?php $this->need('header.php'); ?>
<?php $this->need('headernav.php');?>

<!-- content srart -->
<div class="am-g am-g-fixed blog-fixed blog-content">
    <div class="am-u-md-8 am-u-sm-12">
      <article class="am-article blog-article-p">
        <div class="am-article-hd">
          <h1 class="am-article-title blog-text-center"><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></h1>
          <p class="am-article-meta blog-text-center">
              <span><a href="<?php $this->author->permalink(); ?>" class="blog-color"><?php $this->author(); ?> &nbsp;</a></span>-
              <span><a href="#"><?php $this->category(','); ?> &nbsp;</a></span>-
              <span><a href="#"><time datetime="<?php $this->date('c'); ?>" itemprop="datePublished"><?php $this->date(); ?></time></a></span>
          </p>
        </div>        
        <div class="am-article-bd">
			<?php $this->content(); ?>
        </div>
      </article>
        
        <div class="am-g blog-article-widget blog-article-margin">
          <div class="am-u-lg-4 am-u-md-5 am-u-sm-7 am-u-sm-centered blog-text-center">
            <span class="am-icon-tags"> &nbsp;</span><?php $this->tags(', ', true, '暂无标签'); ?>
            <hr>
			<?php if (!empty($this->options->sidebarBlock) && in_array('ShowContactMe', $this->options->sidebarBlock)){?>
            <a href="<?php echo $this->options->contactQQ?"http://wpa.qq.com/msgrd?v=3&uin=".$this->options->contactQQ."&site=qq&menu=yes":"javascript:;"; ?>" target="_blank"><span class="am-icon-qq am-icon-fw am-primary blog-icon blog-icon"></span></a>
			<a <?php if($this->options->contactWeixin){?>data-am-modal="{target: '#weixin-modal'}"<?php }?> href="javascript:;"><span class="am-icon-weixin am-icon-fw blog-icon blog-icon"></span></a>
			<a href="<?php echo $this->options->contactWeibo?$this->options->contactWeibo:"javascript:;"; ?>" target="_blank"><span class="am-icon-weibo am-icon-fw blog-icon blog-icon"></span></a>
			<a href="<?php echo $this->options->contactGithub?$this->options->contactGithub:"javascript:;"; ?>" target="_blank"><span class="am-icon-github am-icon-fw blog-icon blog-icon"></span></a>
			<a href="<?php echo $this->options->contactRenren?$this->options->contactRenren:"javascript:;"; ?>" target="_blank"><span class="am-icon-renren am-icon-fw blog-icon blog-icon"></span></a>
			<?php }?>
          </div>
        </div>

        <hr>
        <div class="am-g blog-author blog-article-margin">
          <div class="am-u-sm-3 am-u-md-3 am-u-lg-2">
            <a href="<?=$this->author->url?$this->author->url:"javascript:;";?>" target="_blank" rel="nofollow"><img src="<?=gravatarUrl($this->author->mail,30,"X","",true);?>" alt="" class="blog-author-img am-circle"></a>
          </div>
          <div class="am-u-sm-9 am-u-md-9 am-u-lg-10">
			<h3><span>作者 &nbsp;: &nbsp;</span><span class="blog-color"><?php $this->author(); ?></span></h3>
			<p><?=$this->author->mail?$this->author->mail:"";?></p>
          </div>
        </div>
        <hr>
        <ul class="am-pagination blog-article-margin">
          <li class="am-pagination-prev"><?php $this->thePrev('%s','<a href="javascript:;">当前第一篇</a>'); ?></li>
          <li class="am-pagination-next"><?php $this->theNext('%s','<a href="javascript:;">当前第一篇</a>'); ?></li>
        </ul>
        <hr>
		<?php $this->need('comments.php'); ?>
        <hr>
    </div>
	<?php $this->need('sidebar.php'); ?>
</div>
<!-- content end -->
<?php $this->need('footerdiv.php');?>
<?php $this->need('footer.php'); ?>
