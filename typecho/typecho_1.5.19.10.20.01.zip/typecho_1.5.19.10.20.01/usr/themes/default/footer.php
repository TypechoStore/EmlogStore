<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!--[if (gte IE 9)|!(IE)]><!-->
<script src="<?php $this->options->themeUrl('assets/js/jquery.min.js'); ?>"></script>
<!--<![endif]-->
<!--[if lte IE 8 ]>
<script src="https://libs.baidu.com/jquery/1.11.3/jquery.min.js"></script>
<script src="https://cdn.staticfile.org/modernizr/2.8.3/modernizr.js"></script>
<script src="<?php $this->options->themeUrl('assets/js/amazeui.ie8polyfill.min.js'); ?>"></script>
<![endif]-->
<script src="<?php $this->options->themeUrl('assets/js/amazeui.min.js'); ?>"></script>
<script src="<?php $this->options->themeUrl('assets/js/pinto.min.js'); ?>"></script>
<script src="<?php $this->options->themeUrl('assets/js/img.js'); ?>"></script>
<?php $this->footer(); ?>
</body>
</html>
</body>
</html>
