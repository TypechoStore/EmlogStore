<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<footer class="blog-footer">
	<?php if($this->options->foot_custom1||$this->options->foot_custom2||$this->options->foot_custom3||$this->options->contactQQ||$this->options->contactWeixin||$this->options->contactWeibo||$this->options->contactGithub||$this->options->contactRenren){?>
    <div class="am-g am-g-fixed blog-fixed am-u-sm-centered blog-footer-padding">
        <div class="am-u-sm-12 am-u-md-4- am-u-lg-4">
			<?php echo $this->options->foot_custom1?$this->options->foot_custom1:""; ?>
        </div>
        <div class="am-u-sm-12 am-u-md-4- am-u-lg-4">
			<div class="am-modal am-modal-alert" tabindex="-1" id="weixin-modal">
			  <div class="am-modal-dialog">
				<div class="am-modal-hd">
					<img src="<?php echo $this->options->contactWeixin?$this->options->contactWeixin:""; ?>" />
				</div>
			  </div>
			</div>
            <h3>社交账号</h3>
            <p>
				<?php if (!empty($this->options->sidebarBlock) && in_array('ShowContactMe', $this->options->sidebarBlock)){?>
                <a href="<?php echo $this->options->contactQQ?"http://wpa.qq.com/msgrd?v=3&uin=".$this->options->contactQQ."&site=qq&menu=yes":"javascript:;"; ?>" target="_blank"><span class="am-icon-qq am-icon-fw am-primary blog-icon blog-icon"></span></a>
				<a <?php if($this->options->contactWeixin){?>data-am-modal="{target: '#weixin-modal'}"<?php }?> href="javascript:;"><span class="am-icon-weixin am-icon-fw blog-icon blog-icon"></span></a>
                <a href="<?php echo $this->options->contactWeibo?$this->options->contactWeibo:"javascript:;"; ?>" target="_blank"><span class="am-icon-weibo am-icon-fw blog-icon blog-icon"></span></a>
				<a href="<?php echo $this->options->contactGithub?$this->options->contactGithub:"javascript:;"; ?>" target="_blank"><span class="am-icon-github am-icon-fw blog-icon blog-icon"></span></a>
                <a href="<?php echo $this->options->contactRenren?$this->options->contactRenren:"javascript:;"; ?>" target="_blank"><span class="am-icon-renren am-icon-fw blog-icon blog-icon"></span></a>
				<?php }else{?>
				<a href="javascript:;"><span class="am-icon-qq am-icon-fw am-primary blog-icon blog-icon"></span></a>
                <a href="javascript:;"><span class="am-icon-weixin am-icon-fw blog-icon blog-icon"></span></a>
                <a href="javascript:;"><span class="am-icon-weibo am-icon-fw blog-icon blog-icon"></span></a>
                <a href="javascript:;"><span class="am-icon-github am-icon-fw blog-icon blog-icon"></span></a>
                <a href="javascript:;"><span class="am-icon-renren am-icon-fw blog-icon blog-icon"></span></a>
				<?php }?>
            </p>
            <?php echo $this->options->foot_custom2?$this->options->foot_custom2:""; ?>
        </div>
        <div class="am-u-sm-12 am-u-md-4- am-u-lg-4">
			<?php echo $this->options->foot_custom3?$this->options->foot_custom3:""; ?>
        </div>
    </div>
	<?php }?>
    <div class="blog-text-center">
		<?php echo printFriends($this->options->friendlink);?>
		<p>
			© <?php echo date('Y'); ?> <a href="<?php $this->options->siteUrl(); ?>" target="_blank"><?php $this->options->title(); ?>.</a> <?php _e('Powered by <a href="http://www.typecho.org">Typecho</a>'); ?>. Theme By <a href="https://www.tongleer.com" target="_blank">Tongleer</a>.
		</p>
		<p style="display:none;"><?php echo $this->options->foot_count; ?></p>
	</div>    
</footer>