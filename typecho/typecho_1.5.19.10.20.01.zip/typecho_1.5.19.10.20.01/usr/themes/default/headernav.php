<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<header class="am-g am-g-fixed blog-fixed blog-text-center blog-header">
    <div class="am-u-sm-8 am-u-sm-centered">
		<?php if ($this->options->logoUrl){?>
        <img width="200" src="<?php $this->options->logoUrl() ?>" alt="<?php $this->options->title() ?>"/>
		<?php }?>
        <h2 class="am-hide-sm-only"><?php $this->options->title() ?></h2>
		<p><?php $this->options->description() ?></p>
    </div>
</header>
<hr>
<!-- nav start -->
<nav class="am-g am-g-fixed blog-fixed blog-nav">
  <button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-success am-show-sm-only blog-button" data-am-collapse="{target: '#blog-collapse'}" ><span class="am-sr-only">导航切换</span> <span class="am-icon-bars"></span></button>

  <div class="am-collapse am-topbar-collapse" id="blog-collapse">
    <ul class="am-nav am-nav-pills am-topbar-nav">
      <li <?php if($this->is('index')): ?>class="am-active"<?php endif; ?>><a href="<?php $this->options->siteUrl(); ?>"><?php _e('首页'); ?></a></li>
	  <?php
		$this->widget('Widget_Metas_Category_List')->to($categories);
		while($categories->next()){
			if($categories->parent!=0){
				continue;
			}
			?>
			<li class="am-dropdown" data-am-dropdown>
			  <?php
			  $children = $categories->getAllChildren($categories->mid);
			  if(count($children)>0){
				?>
				<a class="am-dropdown-toggle" data-am-dropdown-toggle href="<?php echo $categories->permalink;?>"><?php echo $categories->name;?></a>
				<ul class="am-dropdown-content">
				<?php
				foreach ($children as $mid) {
					$child = $categories->getCategory($mid);
					?>
					<li class="">
					  <a href="<?php echo $child['permalink'];?>" title="<?php echo $child['name'];?>"><?php echo $child['name']; ?></a>
					</li>
					<?php
					}
				?>
				</ul>
				<?php
				}else{
					?>
					<li class="">
					  <a href="<?php echo $categories->permalink;?>" title="<?php echo $categories->name;?>"><?php echo $categories->name;?></a>
					</li>
					<?php
			  }
			  ?>
			</li>
			<?php
		}
	  ?>
      <?php
		$stat = Typecho_Widget::widget('Widget_Stat');
		if($stat->publishedPagesNum>0){
		?>
		<li class="am-dropdown" data-am-dropdown>
          <a class="am-dropdown-toggle" data-am-dropdown-toggle href="javascript:;">页面 <span class="am-icon-caret-down"></span></a>
          <ul class="am-dropdown-content">
			<?php $this->widget('Widget_Contents_Page_List')->to($pages);?>
			<?php while($pages->next()): ?>
			<li <?php if($this->is('page', $pages->slug)): ?> class="am-active"<?php endif; ?>>
			  <a href="<?php $pages->permalink(); ?>" title="<?php $pages->title(); ?>"><?php $pages->title(); ?></a>
			</li>
			<?php endwhile; ?>
          </ul>
        </li>
		<?php
		}
	  ?>
    </ul>
    <form id="search" method="post" action="<?php $this->options->siteUrl(); ?>" class="am-topbar-form am-topbar-right am-form-inline" role="search">
      <div class="am-form-group">
        <input type="text" id="s" name="s" class="am-form-field am-input-sm" placeholder="<?php _e('搜索关键字'); ?>" />
      </div>
    </form>
  </div>
</nav>
<hr>
<!-- nav end -->