Typecho 1.5/19.10.20.01
---
# 朦胧中所修改文件

var/Widget/Menu.php

install.php
install/Mysql.php
install/SQLite.php
install/Pgsql.php

admin/header.php
admin/menu.php
admin/footer.php
admin/copyright.php
admin/page-title.php
admin/index.php
admin/upgrade.php
admin/login.php
admin/register.php
admin/profile.php
admin/write-post.php
admin/file-upload-js.php
admin/write-js.php
admin/manage-posts.php
admin/plugins.php
admin/options-plugin.php
admin/themes.php
admin/theme-editor.php
admin/option-theme.php
admin/backup.php
admin/write-page.php
admin/manage-pages.php
admin/options-general.php
admin/options-discussion.php
admin/options-reading.php
admin/options-permalink.php
admin/manage-comments.php
admin/manage-categories.php
admin/category.php
admin/manage-tags.php
admin/manage-medias.php
admin/media.php
admin/manage-users.php
admin/user.php
admin/welcome.php

usr/themes/default

# 版本记录

2019-10-20 1.5/19.10.20.01

	第一个版本（由原Typecho开发版修改）

2019-10-15 1.5/19.10.15

	第一个版本（由原Typecho正式版修改）