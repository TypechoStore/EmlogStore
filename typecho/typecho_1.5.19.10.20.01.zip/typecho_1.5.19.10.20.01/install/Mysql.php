<?php if(!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<?php
$engine = '';

if (defined('SAE_MYSQL_DB') && SAE_MYSQL_DB != "app_") {
    $engine = 'SAE';
} else if (!!getenv('HTTP_BAE_ENV_ADDR_SQL_IP')) {
    $engine = 'BAE';
} else if (ini_get('acl.app_id') && class_exists('Alibaba')) {
    $engine = 'ACE';
} else if (isset($_SERVER['SERVER_SOFTWARE']) && strpos($_SERVER['SERVER_SOFTWARE'],'Google App Engine') !== false) {
    $engine = 'GAE';
}
?>

<?php if (!empty($engine)): ?>
<h3 class="warning"><?php _e('系统将为您自动匹配 %s 环境的安装选项', $engine); ?></h3>
<?php endif; ?>

<?php if ('SAE' == $engine): ?>
<!-- SAE -->
    <input type="hidden" name="config" value="array (
    'host'      =>  SAE_MYSQL_HOST_M,
    'user'      =>  SAE_MYSQL_USER,
    'password'  =>  SAE_MYSQL_PASS,
    'charset'   =>  '<?php _e('utf8'); ?>',
    'port'      =>  SAE_MYSQL_PORT,
    'database'  =>  SAE_MYSQL_DB
)" />
    <input type="hidden" name="dbHost" value="<?php echo SAE_MYSQL_HOST_M; ?>" />
    <input type="hidden" name="dbPort" value="<?php echo SAE_MYSQL_PORT; ?>" />
    <input type="hidden" name="dbUser" value="<?php echo SAE_MYSQL_USER; ?>" />
    <input type="hidden" name="dbPassword" value="<?php echo SAE_MYSQL_PASS; ?>" />
    <input type="hidden" name="dbDatabase" value="<?php echo SAE_MYSQL_DB; ?>" />
<?php elseif ('BAE' == $engine):
$baeDbUser = "getenv('HTTP_BAE_ENV_AK')";
$baeDbPassword = "getenv('HTTP_BAE_ENV_SK')";
?>
<!-- BAE -->
    <?php if (!getenv('HTTP_BAE_ENV_AK')): $baeDbUser = "'{user}'"; ?>
	<div class="am-g am-margin-top">
		<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('应用API Key'); ?></div>
		<div class="am-u-sm-8 am-u-md-4">
			<input type="text" class="am-input-sm" name="dbUser" id="dbUser" value="<?php _v('dbUser'); ?>">
		</div>
		<div class="am-u-sm-12 am-u-md-8"></div>
	</div>
    <?php else: ?>
    <input type="hidden" name="dbUser" value="<?php echo getenv('HTTP_BAE_ENV_AK'); ?>" />
    <?php endif; ?>

    <?php if (!getenv('HTTP_BAE_ENV_SK')): $baeDbPassword = "'{password}'"; ?>
	<div class="am-g am-margin-top">
		<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('应用Secret Key'); ?></div>
		<div class="am-u-sm-8 am-u-md-4">
			<input type="text" class="am-input-sm" name="dbPassword" id="dbPassword" value="<?php _v('dbPassword'); ?>">
		</div>
		<div class="am-u-sm-12 am-u-md-8"></div>
	</div>
    <?php else: ?>
    <input type="hidden" name="dbPassword" value="<?php echo getenv('HTTP_BAE_ENV_SK'); ?>" />
    <?php endif; ?>
	<div class="am-g am-margin-top">
		<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库名'); ?></div>
		<div class="am-u-sm-8 am-u-md-4">
			<input type="text" class="am-input-sm" name="dbDatabase" id="dbDatabase" value="<?php _v('dbDatabase'); ?>">
		</div>
		<div class="am-u-sm-12 am-u-md-8"><?php _e('可以在MySQL服务的管理页面看到您创建的数据库名称'); ?></div>
	</div>
    <input type="hidden" name="config" value="array (
    'host'      =>  getenv('HTTP_BAE_ENV_ADDR_SQL_IP'),
    'user'      =>  <?php echo $baeDbUser; ?>,
    'password'  =>  <?php echo $baeDbPassword; ?>,
    'charset'   =>  '<?php _e('utf8'); ?>',
    'port'      =>  getenv('HTTP_BAE_ENV_ADDR_SQL_PORT'),
    'database'  =>  '{database}'
)" />
    <input type="hidden" name="dbHost" value="<?php echo getenv('HTTP_BAE_ENV_ADDR_SQL_IP'); ?>" />
    <input type="hidden" name="dbPort" value="<?php echo getenv('HTTP_BAE_ENV_ADDR_SQL_PORT'); ?>" />
<?php elseif ('ACE' == $engine): ?>
<!-- ACE -->
	<div class="am-g am-margin-top">
		<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库地址'); ?></div>
		<div class="am-u-sm-8 am-u-md-4">
			<input type="text" class="am-input-sm" name="dbHost" id="dbHost" value="<?php _v('dbHost', 'localhost'); ?>">
		</div>
		<div class="am-u-sm-12 am-u-md-8"><?php _e('您可以访问 RDS 控制台获取详细信息'); ?></div>
	</div>
	<div class="am-g am-margin-top">
		<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库端口'); ?></div>
		<div class="am-u-sm-8 am-u-md-4">
			<input type="text" class="am-input-sm" name="dbPort" id="dbPort" value="<?php _v('dbPort', 3306); ?>">
		</div>
		<div class="am-u-sm-12 am-u-md-8"></div>
	</div>
	<div class="am-g am-margin-top">
		<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库用户名'); ?></div>
		<div class="am-u-sm-8 am-u-md-4">
			<input type="text" class="am-input-sm" name="dbUser" id="dbUser" value="<?php _v('dbUser'); ?>">
		</div>
		<div class="am-u-sm-12 am-u-md-8"></div>
	</div>
	<div class="am-g am-margin-top">
		<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库密码'); ?></div>
		<div class="am-u-sm-8 am-u-md-4">
			<input type="password" class="am-input-sm" name="dbPassword" id="dbPassword" value="<?php _v('dbPassword'); ?>">
		</div>
		<div class="am-u-sm-12 am-u-md-8"></div>
	</div>
	<div class="am-g am-margin-top">
		<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库名'); ?></div>
		<div class="am-u-sm-8 am-u-md-4">
			<input type="text" class="am-input-sm" name="dbDatabase" id="dbDatabase" value="<?php _v('dbDatabase', 'typecho'); ?>">
		</div>
		<div class="am-u-sm-12 am-u-md-8"></div>
	</div>

<?php elseif ('GAE' == $engine): ?>
<!-- GAE -->
    <h3 class="warning"><?php _e('系统将为您自动匹配 %s 环境的安装选项', 'GAE'); ?></h3>
<?php if (0 === strpos($adapter, 'Pdo_')): ?>
	<div class="am-g am-margin-top">
		<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库实例名'); ?></div>
		<div class="am-u-sm-8 am-u-md-4">
			<input type="text" class="am-input-sm" name="dbHost" id="dbHost" value="<?php _v('dbHost'); ?>">
		</div>
		<div class="am-u-sm-12 am-u-md-8"><?php _e('请填入您在Cloud SQL面板中创建的数据库实例名称, 示例: %s', '<em class="warning">/cloudsql/typecho-gae:typecho</em>'); ?></div>
	</div>
<?php else: ?>
	<div class="am-g am-margin-top">
		<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库实例名'); ?></div>
		<div class="am-u-sm-8 am-u-md-4">
			<input type="text" class="am-input-sm" name="dbHost" id="dbHost" value="<?php _v('dbHost'); ?>">
		</div>
		<div class="am-u-sm-12 am-u-md-8"><?php _e('请填入您在Cloud SQL面板中创建的数据库实例名称, 示例: %s', '<em class="warning">:/cloudsql/typecho-gae:typecho</em>'); ?></div>
	</div>
<?php endif; ?>
	
	<div class="am-g am-margin-top">
		<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库用户名'); ?></div>
		<div class="am-u-sm-8 am-u-md-4">
			<input type="text" class="am-input-sm" name="dbUser" id="dbUser" value="<?php _v('dbUser'); ?>">
		</div>
		<div class="am-u-sm-12 am-u-md-8"></div>
	</div>
	<div class="am-g am-margin-top">
		<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库密码'); ?></div>
		<div class="am-u-sm-8 am-u-md-4">
			<input type="password" class="am-input-sm" name="dbPassword" id="dbPassword" value="<?php _v('dbPassword'); ?>">
		</div>
		<div class="am-u-sm-12 am-u-md-8"></div>
	</div>
	<div class="am-g am-margin-top">
		<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库名'); ?></div>
		<div class="am-u-sm-8 am-u-md-4">
			<input type="text" class="am-input-sm" name="dbDatabase" id="dbDatabase" value="<?php _v('dbDatabase', 'typecho'); ?>">
		</div>
		<div class="am-u-sm-12 am-u-md-8"><?php _e('请填入您在Cloud SQL的实例中创建的数据库名称'); ?></div>
	</div>

<?php if (0 === strpos($adapter, 'Pdo_')): ?>
    <input type="hidden" name="dbDsn" value="mysql:dbname={database};unix_socket={host};charset=<?php _e('utf8'); ?>" />
    <input type="hidden" name="config" value="array (
    'dsn'       =>  '{dsn}',
    'user'      =>  '{user}',
    'password'  =>  '{password}'
)" />
<?php else: ?>
    <input type="hidden" name="config" value="array (
    'host'      =>  '{host}',
    'database'  =>  '{database}',
    'user'      =>  '{user}',
    'password'  =>  '{password}'
)" />
<?php endif; ?>


<?php  else: ?>
    <div class="am-g am-margin-top">
		<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库地址'); ?></div>
		<div class="am-u-sm-8 am-u-md-4">
			<input type="text" class="am-input-sm" name="dbHost" id="dbHost" value="<?php _v('dbHost', 'localhost'); ?>">
		</div>
		<div class="am-u-sm-12 am-u-md-8"><?php _e('您可能会使用 "%s"', 'localhost'); ?></div>
	</div>
	<div class="am-g am-margin-top">
		<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库端口'); ?></div>
		<div class="am-u-sm-8 am-u-md-4">
			<input type="text" class="am-input-sm" name="dbPort" id="dbPort" value="<?php _v('dbPort', '3306'); ?>">
		</div>
		<div class="am-u-sm-12 am-u-md-8"><?php _e('如果您不知道此选项的意义, 请保留默认设置'); ?></div>
	</div>
	<div class="am-g am-margin-top">
		<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库用户名'); ?></div>
		<div class="am-u-sm-8 am-u-md-4">
			<input type="text" class="am-input-sm" name="dbUser" id="dbUser" value="<?php _v('dbUser', 'root'); ?>">
		</div>
		<div class="am-u-sm-12 am-u-md-8"><?php _e('您可能会使用 "%s"', 'root'); ?></div>
	</div>
	<div class="am-g am-margin-top">
		<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库密码'); ?></div>
		<div class="am-u-sm-8 am-u-md-4">
			<input type="password" class="am-input-sm" name="dbPassword" id="dbPassword" value="<?php _v('dbPassword'); ?>">
		</div>
		<div class="am-u-sm-12 am-u-md-8"></div>
	</div>
	<div class="am-g am-margin-top">
		<div class="am-u-sm-4 am-u-md-4 am-text-right"><?php _e('数据库名'); ?></div>
		<div class="am-u-sm-8 am-u-md-4">
			<input type="text" class="am-input-sm" name="dbDatabase" id="dbDatabase" value="<?php _v('dbDatabase', 'typecho'); ?>">
		</div>
		<div class="am-u-sm-12 am-u-md-8"><?php _e('请您指定数据库名称'); ?></div>
	</div>
<?php  endif; ?>
<input type="hidden" name="dbCharset" value="<?php _e('utf8'); ?>" />

