<?php
include 'common.php';

$body_type = 'widgets';

include 'header.php';
include 'menu.php';
?>
			<div class="container-fluid am-cf">
                <div class="row">
                    <div class="am-u-sm-12 am-u-md-12 am-u-lg-9">
                        <?php include 'page-title.php'; ?>
                        <p class="page-header-description">Typecho有许多不同的外观可用。</p>
                    </div>
                </div>
            </div>
            <div class="row-content am-cf">
                <div class="row">
                    <div class="am-u-sm-12 am-u-md-12 am-u-lg-12">
                        <div class="widget am-cf">
                            <div class="widget-body am-fr">

                                <div class="am-u-sm-12 am-u-md-6 am-u-lg-6">
                                    <div class="am-form-group typecho-option-tabs">
                                        <div class="am-btn-toolbar">
                                            <div class="am-btn-group am-btn-group-xs">
                                                <a href="<?php $options->adminUrl('themes.php'); ?>" class="am-btn am-btn-default am-btn-success"><?php _e('可以使用的外观'); ?></a>
												<?php if (!defined('__TYPECHO_THEME_WRITEABLE__') || __TYPECHO_THEME_WRITEABLE__): ?>
												<a href="<?php $options->adminUrl('theme-editor.php'); ?>" class="am-btn am-btn-default"><?php _e('编辑当前外观'); ?></a>
												<?php endif; ?>
												<?php if (Widget_Themes_Config::isExists()): ?>
												<a href="<?php $options->adminUrl('options-theme.php'); ?>" class="am-btn am-btn-default"><?php _e('设置外观'); ?></a>
												<?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="am-u-sm-12 typecho-table-wrap">
                                    <table width="100%" class="am-table am-table-compact am-table-striped tpl-table-black typecho-list-table typecho-theme-list">
                                        <thead>
                                            <tr>
                                                <th><?php _e('截图'); ?></th>
												<th><?php _e('详情'); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php Typecho_Widget::widget('Widget_Themes_List')->to($themes); ?>
											<?php while($themes->next()): ?>
											<tr id="theme-<?php $themes->name(); ?>" class="<?php if($themes->activated): ?>current<?php endif; ?>">
												<td valign="top"><img src="<?php $themes->screen(); ?>" alt="<?php $themes->name(); ?>" /></td>
												<td valign="top">
													<h3><?php '' != $themes->title ? $themes->title() : $themes->name(); ?></h3>
													<cite>
														<?php if($themes->author): ?><?php _e('作者'); ?>: <?php if($themes->homepage): ?><a href="<?php $themes->homepage() ?>"><?php endif; ?><?php $themes->author(); ?><?php if($themes->homepage): ?></a><?php endif; ?> &nbsp;&nbsp;<?php endif; ?>
														<?php if($themes->version): ?><?php _e('版本'); ?>: <?php $themes->version() ?><?php endif; ?>
													</cite>
													<p><?php echo nl2br($themes->description); ?></p>
													<?php if($options->theme != $themes->name): ?>
														<p>
															<?php if (!defined('__TYPECHO_THEME_WRITEABLE__') || __TYPECHO_THEME_WRITEABLE__): ?>
															<a class="edit" href="<?php $options->adminUrl('theme-editor.php?theme=' . $themes->name); ?>"><?php _e('编辑'); ?></a> &nbsp;
															<?php endif; ?>
															<a class="activate" href="<?php $security->index('/action/themes-edit?change=' . $themes->name); ?>"><?php _e('启用'); ?></a>
														</p>
													<?php endif; ?>
												</td>
											</tr>
											<?php endwhile; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php
include 'copyright.php';
include 'common-js.php';
include 'footer.php';
?>