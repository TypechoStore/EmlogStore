<?php if(!defined('__TYPECHO_ADMIN__')) exit; ?>
	<div class="am-g tpl-g typecho-dashboard">
        <!-- 头部 -->
        <header>
            <!-- logo -->
            <div class="am-fl tpl-header-logo">
                <a href="<?php $options->adminUrl(); ?>" title="<?php echo $options->title; ?>"><img src="<?php echo Typecho_Common::url('logo.png?v=' . $suffixVersion, $options->adminStaticUrl('assets/img'));?>" alt=""></a>
            </div>
            <!-- 右侧内容 -->
            <div class="tpl-header-fluid">
                <!-- 侧边切换 -->
                <div class="am-fl tpl-header-switch-button am-icon-list">
                    <span></span>
                </div>
                <!-- 其它功能-->
                <div class="am-fr tpl-header-navbar">
                    <ul>
						<?php Typecho_Plugin::factory('admin/menu.php')->navBar(); ?>
                        <!-- 欢迎语 -->
                        <li class="am-text-sm tpl-header-navbar-welcome">
                            <a href="<?php $options->adminUrl('profile.php'); ?>" title="<?php
								if ($user->logged > 0) {
									$logged = new Typecho_Date($user->logged);
									_e('最后登录: %s', $logged->word());
								}
								?>">欢迎你, <span><?php $user->screenName(); ?></span>
							</a>
                        </li>
						
						<li class="am-text-sm">
                            <a href="<?php $options->siteUrl(); ?>">
                                <span class="am-icon-sitemap"></span> <?php _e('网站'); ?>
                            </a>
                        </li>

                        <!-- 退出 -->
                        <li class="am-text-sm">
                            <a href="<?php $options->logoutUrl(); ?>">
                                <span class="am-icon-sign-out"></span> <?php _e('登出'); ?>
                            </a>
                        </li>
                    </ul>
                </div>
				<script>$(".tpl-header-navbar ul a").wrap("<li></li>");</script>
            </div>

        </header>
        <!-- 风格切换 -->
		<div class="tpl-skiner">
            <div class="tpl-skiner-toggle am-icon-cog">
            </div>
            <div class="tpl-skiner-content">
                <div class="tpl-skiner-content-title">
                    选择主题
                </div>
                <div class="tpl-skiner-content-bar">
                    <span class="skiner-color skiner-white" data-color="theme-white"></span>
                    <span class="skiner-color skiner-black" data-color="theme-black"></span>
                </div>
            </div>
        </div>
        <!-- 侧边导航栏 -->
        <div class="left-sidebar">
            <!-- 用户信息 -->
            <div class="tpl-sidebar-user-panel">
                <div class="tpl-user-panel-slide-toggleable">
                    <div class="tpl-user-panel-profile-picture">
                        <a href="http://gravatar.com/emails/" title="<?php _e('在 Gravatar 上修改头像'); ?>"><img src="<?php echo Typecho_Common::gravatarUrl($user->mail, 220, 'X', 'mm', $request->isSecure());?>" alt=""></a>
                    </div>
                    <span class="user-panel-logged-in-text">
					  <i class="am-icon-circle-o am-text-success tpl-user-panel-status-icon"></i>
					  <?php $user->screenName(); ?>
					</span>
                </div>
            </div>

            <!-- 菜单 -->
			<?php $menu->output(); ?>
        </div>
		<!-- 内容区域 -->
		<style>.contentpadding{padding:15px;}</style>
        <div class="tpl-content-wrapper typecho-page-main contentpadding">