<?php
include 'common.php';

$body_type = 'widgets';

include 'header.php';
include 'menu.php';

Typecho_Widget::widget('Widget_Themes_Files')->to($files);
?>
            <div class="container-fluid am-cf">
                <div class="row">
                    <div class="am-u-sm-12 am-u-md-12 am-u-lg-9">
                        <?php include 'page-title.php'; ?>
                        <p class="page-header-description"></p>
                    </div>
                </div>
            </div>

            <div class="row-content am-cf">

                <div class="row typecho-page-main typecho-edit-theme">
                    <div class="am-u-sm-12 am-u-md-12 am-u-lg-8">
                        <div class="widget am-cf">
                            <div class="widget-body am-fr">
                                <div class="am-u-sm-12 am-u-md-12 am-u-lg-12">
                                    <div class="am-form-group typecho-option-tabs">
                                        <div class="am-btn-toolbar">
                                            <div class="am-btn-group am-btn-group-xs">
                                                <a href="<?php $options->adminUrl('themes.php'); ?>" class="am-btn am-btn-default am-btn-default"><?php _e('可以使用的外观'); ?></a>
												<?php if (!defined('__TYPECHO_THEME_WRITEABLE__') || __TYPECHO_THEME_WRITEABLE__): ?>
												<a href="<?php $options->adminUrl('theme-editor.php'); ?>" class="am-btn am-btn-success"><?php _e('编辑当前外观'); ?></a>
												<?php endif; ?>
												<?php if (Widget_Themes_Config::isExists()): ?>
												<a href="<?php $options->adminUrl('options-theme.php'); ?>" class="am-btn am-btn-default"><?php _e('设置外观'); ?></a>
												<?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
									<form class="tpl-form-border-form" method="post" name="theme" id="theme" action="<?php $security->index('/action/themes-edit'); ?>">
										<label for="content" class="sr-only"><?php _e('编辑源码'); ?></label>
										<textarea name="content" id="content" class="w-100 mono" <?php if(!$files->currentIsWriteable()): ?>readonly<?php endif; ?>><?php echo $files->currentContent(); ?></textarea>
										<p class="submit">
											<?php if($files->currentIsWriteable()): ?>
											<input type="hidden" name="theme" value="<?php echo $files->currentTheme(); ?>" />
											<input type="hidden" name="edit" value="<?php echo $files->currentFile(); ?>" />
											<button type="submit" class="am-btn am-btn-primary"><?php _e('保存文件'); ?></button>
											<?php else: ?>
												<em><?php _e('此文件无法写入'); ?></em>
											<?php endif; ?>
										</p>
									</form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="am-u-sm-12 am-u-md-12 am-u-lg-4">
                        <div class="widget am-cf">
                            <div class="widget-body am-fr">
								<div class="am-scrollable-horizontal ">
                                    <table width="100%" class="am-table am-table-compact am-text-nowrap tpl-table-black " id="example-r">
                                        <thead>
                                            <tr>
                                                <th>模板文件</th>
                                            </tr>
                                        </thead>
                                        <tbody>
											<?php while($files->next()): ?>
                                            <tr class="gradeX" <?php if($files->current): ?>class="current"<?php endif; ?>>
                                                <td><a href="<?php $options->adminUrl('theme-editor.php?theme=' . $files->currentTheme() . '&file=' . $files->file); ?>"><?php $files->file(); ?></a></td>
                                            </tr>
											<?php endwhile; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
<?php
include 'copyright.php';
include 'common-js.php';
Typecho_Plugin::factory('admin/theme-editor.php')->bottom($files);
include 'footer.php';
?>