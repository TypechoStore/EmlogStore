<?php
include 'common.php';

$body_type = 'widgets';

include 'header.php';
include 'menu.php';
?>
            <div class="container-fluid am-cf">
                <div class="row">
                    <div class="am-u-sm-12 am-u-md-12 am-u-lg-9">
                        <?php include 'page-title.php'; ?>
                        <p class="page-header-description"></p>
                    </div>
                </div>
            </div>
            <div class="row-content am-cf">
                <div class="row">
                    <div class="am-u-sm-12 am-u-md-12 am-u-lg-12">
                        <div class="widget am-cf">
                            <div class="widget-body am-fr tpl-form-line-form">
                                <?php Typecho_Widget::widget('Widget_Options_General')->form()->render(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php
include 'copyright.php';
include 'common-js.php';
include 'form-js.php';
include 'footer.php';
?>