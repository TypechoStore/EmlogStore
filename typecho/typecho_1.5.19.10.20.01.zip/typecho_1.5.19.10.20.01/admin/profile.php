<?php
include 'common.php';

$body_type = 'widgets';

include 'header.php';
include 'menu.php';

$stat = Typecho_Widget::widget('Widget_Stat');
?>
            <div class="container-fluid am-cf">
                <div class="row">
                    <div class="am-u-sm-12 am-u-md-12 am-u-lg-9">
                        <?php include 'page-title.php'; ?>
                        <p class="page-header-description">
							<?php $user->name(); ?> <?php echo $user->screenName?"(".$user->screenName.")":""; ?> <?php _e('目前有 <em>%s</em> 篇日志, 并有 <em>%s</em> 条关于你的评论在 <em>%s</em> 个分类中.', $stat->myPublishedPostsNum, $stat->myPublishedCommentsNum, $stat->categoriesNum); ?> <?php
							if ($user->logged > 0) {
								$logged = new Typecho_Date($user->logged);
								_e('最后登录: %s', $logged->word());
							}
							?>
						</p>
                    </div>
                </div>

            </div>

            <div class="row-content am-cf tpl-form-line-form typecho-content-panel">

                <div class="row">

                    <div class="am-u-sm-12 am-u-md-12 am-u-lg-12">
                        <div class="widget am-cf">
                            <div class="widget-head am-cf">
                                <div class="widget-title am-fl"><?php _e('个人资料'); ?></div>
                                <div class="widget-function am-fr">
                                    <a href="javascript:;" class="am-icon-cog"></a>
                                </div>
                            </div>
                            <div class="widget-body am-fr">
                                <?php Typecho_Widget::widget('Widget_Users_Profile')->profileForm()->render(); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">

                    <div class="am-u-sm-12 am-u-md-12 am-u-lg-12">
                        <div class="widget am-cf">
                            <div class="widget-head am-cf">
                                <div class="widget-title am-fl"><?php _e('撰写设置'); ?></div>
                                <div class="widget-function am-fr">
                                    <a href="javascript:;" class="am-icon-cog"></a>
                                </div>
                            </div>
                            <div class="widget-body am-fr">
								<?php Typecho_Widget::widget('Widget_Users_Profile')->optionsForm()->render(); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">

                    <div class="am-u-sm-12 am-u-md-12 am-u-lg-12">
                        <div class="widget am-cf">
                            <div class="widget-head am-cf">
                                <div class="widget-title am-fl"><?php _e('密码修改'); ?></div>
                                <div class="widget-function am-fr">
                                    <a href="javascript:;" class="am-icon-cog"></a>
                                </div>
                            </div>
                            <div class="widget-body am-fr">
								<?php Typecho_Widget::widget('Widget_Users_Profile')->passwordForm()->render(); ?>
                            </div>
                        </div>
                    </div>
                </div>
				
				<?php Typecho_Widget::widget('Widget_Users_Profile')->personalFormList(); ?>
            </div>
<?php
include 'copyright.php';
include 'common-js.php';
include 'form-js.php';
Typecho_Plugin::factory('admin/profile.php')->bottom();
include 'footer.php';
?>