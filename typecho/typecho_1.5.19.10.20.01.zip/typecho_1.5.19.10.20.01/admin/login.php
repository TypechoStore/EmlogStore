<?php
include 'common.php';

if ($user->hasLogin()) {
    $response->redirect($options->adminUrl);
}
$rememberName = htmlspecialchars(Typecho_Cookie::get('__typecho_remember_name'));
Typecho_Cookie::delete('__typecho_remember_name');

$body_type = 'login';

include 'header.php';
?>
	<div class="am-g tpl-g">
        <!-- 风格切换 -->
        <div class="tpl-skiner">
            <div class="tpl-skiner-toggle am-icon-cog">
            </div>
            <div class="tpl-skiner-content">
                <div class="tpl-skiner-content-title">
                    选择主题
                </div>
                <div class="tpl-skiner-content-bar">
                    <span class="skiner-color skiner-white" data-color="theme-white"></span>
                    <span class="skiner-color skiner-black" data-color="theme-black"></span>
                </div>
            </div>
        </div>
        <div class="tpl-login typecho-login-wrap">
            <div class="tpl-login-content typecho-login">
                <div class="tpl-login-logo">

                </div>

                <form class="am-form tpl-form-line-form" action="<?php $options->loginAction(); ?>" method="post" name="login" role="form">
                    <div class="am-form-group">
                        <input type="text" class="tpl-form-input" id="name" name="name" value="<?php echo $rememberName; ?>" placeholder="<?php _e('用户名'); ?>" autofocus />
                    </div>
                    <div class="am-form-group">
                        <input type="password" class="tpl-form-input" id="password" name="password" placeholder="<?php _e('密码'); ?>" />
                    </div>
                    <div class="am-form-group tpl-login-remember-me">
                        <input name="remember" class="checkbox" value="1" id="remember" type="checkbox" />
                        <label for="remember-me">
                        <?php _e('下次自动登录'); ?>
                         </label>
                    </div>
                    <div class="am-form-group">
                        <button type="submit" class="am-btn am-btn-primary  am-btn-block tpl-btn-bg-color-success  tpl-login-btn"><?php _e('登录'); ?></button>
						<input type="hidden" name="referer" value="<?php echo htmlspecialchars($request->get('referer')); ?>" />
                    </div>
                </form>
				<p class="more-link">
					<a href="<?php $options->siteUrl(); ?>"><?php _e('返回首页'); ?></a>
					<?php if($options->allowRegister): ?>
					&bull;
					<a href="<?php $options->registerUrl(); ?>"><?php _e('用户注册'); ?></a>
					<?php endif; ?>
				</p>
				<hr>
				<p>© <?php echo date("Y");?> <?php echo $options->title;?>.</p>
            </div>
        </div>
    </div>
<?php 
include 'common-js.php';
?>
<script>
$(document).ready(function () {
    $('#name').focus();
});
</script>
<?php
include 'footer.php';
?>