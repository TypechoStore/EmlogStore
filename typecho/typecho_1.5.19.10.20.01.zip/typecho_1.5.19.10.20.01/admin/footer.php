<?php if(!defined('__TYPECHO_ADMIN__')) exit; ?>
		</div>
    </div>
<script src="<?php echo Typecho_Common::url('amazeui.min.js?v=' . $suffixVersion, $options->adminStaticUrl('assets/js'));?>"></script>
<script src="<?php echo Typecho_Common::url('amazeui.datatables.min.js?v=' . $suffixVersion, $options->adminStaticUrl('assets/js'));?>"></script>
<script src="<?php echo Typecho_Common::url('dataTables.responsive.min.js?v=' . $suffixVersion, $options->adminStaticUrl('assets/js'));?>"></script>
<script src="<?php echo Typecho_Common::url('app.js?v=' . $suffixVersion, $options->adminStaticUrl('assets/js'));?>"></script>
<script>
$("form").addClass("am-form");
$(".typecho-label").css("color","#0aa");
$(".typecho-label a").css("color","#0aa");
$("select").css("color","#aaa");
</script>
</body>
</html>
<?php
/** 注册一个结束插件 */
Typecho_Plugin::factory('admin/footer.php')->end();