<?php
include 'common.php';

$body_type = 'widgets';

include 'header.php';
include 'menu.php';
?>
            <div class="container-fluid am-cf">
                <div class="row">
                    <div class="am-u-sm-12 am-u-md-12 am-u-lg-9">
                        <?php include 'page-title.php'; ?>
                        <p class="page-header-description"></p>
                    </div>
                </div>
            </div>
            <div class="row-content am-cf">
                <div class="row">
                    <div class="am-u-sm-12 am-u-md-12 am-u-lg-12">
                        <div class="widget am-cf">
                            <div class="widget-body am-fr tpl-form-line-form">
                                <?php Typecho_Widget::widget('Widget_Options_Reading')->form()->render(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php
include 'copyright.php';
include 'common-js.php';
include 'form-js.php';
?>
<script>
$('#frontPage-recent,#frontPage-page,#frontPage-file').change(function () {
    var t = $(this);
    if (t.prop('checked')) {
        if ('frontPage-recent' == t.attr('id')) {
            $('.front-archive').addClass('hidden');
        } else {
            $('.front-archive').insertAfter(t.parent()).removeClass('hidden');
        }
    }
});
</script>
<?php
include 'footer.php';
?>