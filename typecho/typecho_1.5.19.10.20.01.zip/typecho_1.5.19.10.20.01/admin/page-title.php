<?php if(!defined('__TYPECHO_ADMIN__')) exit; ?>
<div class="page-header-heading typecho-page-title">
	<span class="am-icon-home page-header-heading-icon"></span> <?php echo $menu->title; ?> <?php 
    if (!empty($menu->addLink)) {
        echo "<small> / <a href=\"{$menu->addLink}\">" . _t("新增") . "</a></small>";
    }
    ?>
</div>