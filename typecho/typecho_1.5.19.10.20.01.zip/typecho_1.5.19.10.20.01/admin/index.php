<?php
include 'common.php';

$body_type = 'index';

include 'header.php';
include 'menu.php';

$stat = Typecho_Widget::widget('Widget_Stat');
?>
            <div class="container-fluid am-cf">
                <div class="row">
                    <div class="am-u-sm-12 am-u-md-12 am-u-lg-9">
						<?php include 'page-title.php'; ?>
                        <p class="page-header-description">
							<div class="am-btn-toolbar">
								<div class="am-btn-group am-btn-group-xs">
									<small>
									<?php if($user->pass('contributor', true)){?>
										<a href="<?php $options->adminUrl('write-post.php'); ?>"><?php _e('撰写新文章'); ?></a>
										<?php if($user->pass('editor', true) && 'on' == $request->get('__typecho_all_comments') && $stat->waitingCommentsNum > 0){?>
											<a href="<?php $options->adminUrl('manage-comments.php?status=waiting'); ?>"><?php _e('待审核的评论'); ?> <?php echo $stat->waitingCommentsNum(); ?></a>
										<?php }elseif($stat->myWaitingCommentsNum > 0){?>
											<a href="<?php $options->adminUrl('manage-comments.php?status=waiting'); ?>"><?php _e('待审核评论'); ?> <?php echo $stat->myWaitingCommentsNum(); ?></a>
										<?php }?>
										<?php if($user->pass('editor', true) && 'on' == $request->get('__typecho_all_comments') && $stat->spamCommentsNum > 0){?>
											<a href="<?php $options->adminUrl('manage-comments.php?status=spam'); ?>"><?php _e('垃圾评论'); ?> <?php echo $stat->spamCommentsNum(); ?></a>
										<?php }elseif($stat->mySpamCommentsNum > 0){?>
											<a href="<?php $options->adminUrl('manage-comments.php?status=spam'); ?>"><?php _e('垃圾评论'); ?> <?php echo $stat->mySpamCommentsNum(); ?></a>
										<?php }?>
										<?php if($user->pass('administrator', true)){?>
											<a href="<?php $options->adminUrl('themes.php'); ?>"><?php _e('更换外观'); ?></a>
											<a href="<?php $options->adminUrl('plugins.php'); ?>"><?php _e('插件管理'); ?></a>
											<a href="<?php $options->adminUrl('options-general.php'); ?>"><?php _e('系统设置'); ?></a>
										<?php }?>
									<?php }?>
									</small>
								</div>
							</div>
							<?php $version = Typecho_Cookie::get('__typecho_check_version'); ?>
							<?php if ($version && $version['available']){?>
							<div class="update-check">
								<p class="message notice">
								<?php _e('您当前使用的版本是'); ?> <?php echo $version['current']; ?> &rarr;
								<strong><a href="<?php echo $version['link']; ?>"><?php _e('官方最新版本是'); ?> <?php echo $version['latest']; ?></a></strong>
								</p>
							</div>
							<?php }?>
						</p>
                    </div>
                </div>

            </div>

            <div class="row-content am-cf">
                <div class="row  am-cf">
                    <div class="am-u-sm-12 am-u-md-12 am-u-lg-4">
                        <div class="widget am-cf">
                            <div class="widget-head am-cf">
                                <div class="widget-title am-fl">文章数</div>
                                <div class="widget-function am-fr">
                                    <a href="javascript:;" class="am-icon-file"></a>
                                </div>
                            </div>
                            <div class="widget-body am-fr">
                                <div class="am-fl">
                                    <div class="widget-fluctuation-period-text">
                                        <?php echo $stat->myPublishedPostsNum;?>
                                        <button onClick="location.href='write-post.php';" class="widget-fluctuation-tpl-btn">Go</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="am-u-sm-12 am-u-md-6 am-u-lg-4">
                        <div class="widget widget-primary am-cf">
                            <div class="widget-statistic-header">
                                评论数
                            </div>
                            <div class="widget-statistic-body">
                                <div class="widget-statistic-value">
                                    <?php  echo $stat->myPublishedCommentsNum;?>
                                </div>
								<div class="widget-statistic-description">
                                    分布在<?php  echo $stat->categoriesNum;?>个分类中
                                </div>
                                <span class="widget-statistic-icon am-icon-comment"></span>
                            </div>
                        </div>
                    </div>
                    <div class="am-u-sm-12 am-u-md-6 am-u-lg-4">
                        <div class="widget widget-purple am-cf">
                            <div class="widget-statistic-header">
                                草稿
                            </div>
                            <div class="widget-statistic-body">
                                <div class="widget-statistic-value">
                                    <?php  echo $stat->myDraftPostsNum;?>
                                </div>
                                <span class="widget-statistic-icon am-icon-file-archive-o"></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row am-cf">
                    <div class="am-u-sm-12 am-u-md-12 am-u-lg-6 widget-margin-bottom-lg">
                        <div class="widget am-cf widget-body-lg">
							<?php Typecho_Widget::widget('Widget_Contents_Post_Recent', 'pageSize=10')->to($posts); ?>
                            <div class="widget-body am-fr">
                                <div class="am-scrollable-horizontal ">
                                    <table width="100%" class="am-table am-table-compact am-text-nowrap tpl-table-black ">
                                        <thead>
                                            <tr>
                                                <th><?php _e('最近发布的文章'); ?></th>
                                                <th>时间</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($posts->have()){?>
											<?php while($posts->next()){?>
											<tr class="gradeX">
                                                <td><a href="<?php $posts->permalink(); ?>"><?php $posts->title(); ?></a></td>
                                                <td><?php $posts->date('n.j'); ?></td>
                                            </tr>
                                            <?php }?>
											<?php }else{?>
												<tr><td colspan="2"><center><?php _e('暂时没有文章'); ?></center></td></tr>
											<?php }?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
					
					<div class="am-u-sm-12 am-u-md-12 am-u-lg-6 widget-margin-bottom-lg ">
                        <div class="widget am-cf widget-body-lg">
                            <div class="widget-body am-fr">
                                <div class="am-scrollable-horizontal ">
                                    <table width="100%" class="am-table am-table-compact am-text-nowrap tpl-table-black ">
                                        <thead>
                                            <tr>
                                                <th><?php _e('最近得到的回复'); ?></th>
                                                <th>时间</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php Typecho_Widget::widget('Widget_Comments_Recent', 'pageSize=10')->to($comments); ?>
											<?php if($comments->have()): ?>
											<?php while($comments->next()): ?>
											<tr class="gradeX">
                                                <td><a href="<?php $comments->permalink(); ?>"><?php $comments->author(true); ?></a>:<?php $comments->excerpt(35, '...'); ?></td>
                                                <td><?php $comments->date('n.j'); ?></td>
                                            </tr>
                                            <?php endwhile; ?>
											<?php else: ?>
											<tr>
											  <td colspan="2"><center><?php _e('暂时没有回复'); ?></center></td>
											</tr>
											<?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				<?php if($user->pass('administrator', true)){?>
				<div class="row am-cf">
                    <div class="am-u-sm-12 am-u-md-12 am-u-lg-6 widget-margin-bottom-lg">
                        <div class="widget am-cf widget-body-lg">
                            <div class="widget-body am-fr">
                                <div class="am-scrollable-horizontal ">
                                    <table width="100%" class="am-table am-table-compact am-text-nowrap tpl-table-black ">
                                        <thead>
                                            <tr>
												<th colspan="2"><?php _e('更新日志'); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody id="typecho-updateinfo">
										<tr>
										  <td colspan="2"><?php _e('读取中...'); ?></td>
										</tr>
										</tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
					
					<div class="am-u-sm-12 am-u-md-12 am-u-lg-6 widget-margin-bottom-lg ">
                        <div class="widget am-cf widget-body-lg">
                            <div class="widget-body am-fr">
                                <div class="am-scrollable-horizontal ">
                                    <table width="100%" class="am-table am-table-compact am-text-nowrap tpl-table-black ">
                                        <thead>
                                            <tr>
												<th colspan="2"><?php _e('官方最新日志'); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody id="typecho-message">
										<tr>
										  <td colspan="2"><?php _e('读取中...'); ?></td>
										</tr>
										</tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				<?php }?>
            </div>
			<?php
			include 'copyright.php';
			include 'common-js.php';
			?>
			<script>
			$(document).ready(function () {
				$.getJSON("https://joke.tongleer.com/api/update.php?action=updateDevelopHistory",
					function(data) {
						$("#typecho-updateinfo").html("");
						$.each(data.items, function(i, item) {
							var d = new Date(item.created * 1000);    //根据时间戳生成的时间对象
							var date = (d.getFullYear()) + "-" + 
									   (d.getMonth() + 1) + "-" +
									   (d.getDate());
							$("#typecho-updateinfo").append("<tr><td>" + item.text + "</td><td width='20%'>" + date + "</td></tr>");
						});
						if(data.items.length){
							$("#typecho-updateinfo").append("<tr><td colspan=\"2\"><a href='https://joke.tongleer.com/87.html' target=\"_blank\"><center>更多</center></a></td></tr>");
						}
					});
					
				var tr = $('#typecho-message tr'), cache = window.sessionStorage,
					html = cache ? cache.getItem('feed') : '',
					update = cache ? cache.getItem('update') : '';

				if (!!html) {
					tr.html(html);
				} else {
					html = '';
					$.get('<?php $options->index('/action/ajax?do=feed'); ?>', function (o) {
						for (var i = 0; i < o.length; i ++) {
							var item = o[i];
							html += '<tr><td colspan="2">&nbsp;&nbsp;<a href="' + item.link + '" target="_blank">' + item.title + '</a>&nbsp;&nbsp;' + item.date + '</td></tr>';
						}

						tr.html(html);
						cache.setItem('feed', html);
					}, 'json');
				}

				function applyUpdate(update) {
					if (update.available) {
						$('<div class="update-check message error"><p>'
							+ '<?php _e('您当前使用的版本是 %s'); ?>'.replace('%s', update.current) + '<br />'
							+ '<strong><a href="' + update.link + '" target="_blank">'
							+ '<?php _e('官方最新版本是 %s'); ?>'.replace('%s', update.latest) + '</a></strong></p></div>')
						.insertAfter('.typecho-page-title').effect('highlight');
					}
				}

				if (!!update) {
					applyUpdate($.parseJSON(update));
				} else {
					$.get('<?php $options->index('/action/ajax?do=checkVersion'); ?>', function (o, status, resp) {
						applyUpdate(o);
						cache.setItem('update', resp.responseText);
					}, 'json');
				}
			});

			</script>
<?php include 'footer.php'; ?>