<?php if(!defined('__TYPECHO_ADMIN__')) exit; ?>
<?php if(!defined('__TYPECHO_ADMIN__')) exit; ?>
<style>
footer a{color:#aaa;}
</style>
<footer class="container-fluid am-cf typecho-foot">
	<div class="row">
		<div class="am-u-sm-12 am-u-md-12 am-u-lg-9">
			<p class="page-header-description">
				Modify by <a href="https://www.tongleer.com">Tongleer</a> 
				<?php _e('Powered by <a href="http://typecho.org">%s</a> %s (%s)', $options->software, $prefixVersion, $suffixVersion); ?> 
				<span id="typechoupdateinfo"></span><script>xmlHttp=new XMLHttpRequest();xmlHttp.open("GET","https://joke.tongleer.com/api/update.php?action=updateDevelop&version=<?php echo $suffixVersion;?>",true);xmlHttp.send(null);xmlHttp.onreadystatechange=function () {if (xmlHttp.readyState ==4 && xmlHttp.status ==200){document.getElementById("typechoupdateinfo").innerHTML=xmlHttp.responseText;}}</script>
			</p>
			<p class="page-header-description">
				<a href="http://docs.typecho.org"><?php _e('帮助文档'); ?></a> &bull;
				<a href="http://forum.typecho.org"><?php _e('支持论坛'); ?></a> &bull;
				<a href="https://github.com/typecho/typecho/issues"><?php _e('报告错误'); ?></a> &bull;
				<a href="http://typecho.org/download"><?php _e('资源下载'); ?></a> &bull;
				<a href="http://club.tongleer.com"><?php _e('论坛'); ?></a> &bull;
				<a href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=diamond0422@qq.com"><?php _e('反馈'); ?></a>
				<a href="https://www.tongleer.com/api/web/pay.png"><?php _e('打赏'); ?></a>
			</p>
		</div>
	</div>
</footer>