<?php
if(!defined('EMLOG_ROOT')) {exit('error!');}
$isdraft = $hide == 'y' ? true : false;
?>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
	  <legend><b><?php echo $containertitle; ?></b></legend>
	</fieldset>
	<span id="msg_2"></span>
</div>
<div id="msg"></div>
<form class="layui-form" action="save_log.php?action=add" method="post" enctype="multipart/form-data" id="addlog" name="addlog">
	<div id="post">
		<div class="layui-form-item">
			<div class="layui-row">
			  <input type="text" name="title" id="title" value="<?php echo $title; ?>" maxlength="50" autocomplete="off" placeholder="输入文章标题" class="layui-input">
			</div>
		</div>
		<div class="layui-form-item">
			<div class="layui-row">
			  <input type="text" name="thumbs" id="thumbs" value="<?php echo $thumbs; ?>" maxlength="255" autocomplete="off" placeholder="设置封面，从附件库中设置或者自定义" class="layui-input">
			</div>
		</div>
		<div id="post_bar">
			<div>
				<?php if(Option::get('att_maxsize')!=0){?>
				<button type="button" onclick="displayToggle('FrameUpload', 0);autosave(1);" class="layui-btn layui-btn-primary layui-btn-xs">上传插入</button>
				<?php }?>
				<?php doAction('adm_writelog_head'); ?>
				<?php doAction('adm_writelog_inner'); ?>
				<span id="asmsg"></span>
				<input type="hidden" name="as_logid" id="as_logid" value="<?php echo $logid; ?>">
			</div>
			<div id="FrameUpload" style="display: none;">
				<iframe width="100%" height="320" frameborder="0" src="<?php echo $att_frame_url;?>"></iframe>
			</div>
		</div>
		<div style="background-color:#fff;">
			<textarea id="content" name="content"><?php echo $content; ?></textarea>
		</div>
		<div class="layui-form-item">
			<div class="layui-inline" style="width:100%;">
				<div class="layui-input-inline" style="width:35%;">
					<input type="text" name="tag" id="tag" value="<?php echo $tagStr; ?>" maxlength="200" placeholder="文章标签，逗号或空格分隔，过多的标签会影响系统运行效率" class="layui-input">
				</div>
				<div class="layui-input-inline" style="width:15%;">
					<button type="button" onclick="displayToggle('tagbox', 0);" class="layui-btn layui-btn-primary">已有标签+</button>
				</div>
				<div class="layui-input-inline" style="width:20%;">
					<select name="sort" id="sort" lay-filter="sort">
						<option value="-1">选择分类...</option>
						<?php 
						foreach($sorts as $key=>$value):
						if ($value['pid'] != 0) {
							continue;
						}
						$flg = $value['sid'] == $sortid ? 'selected' : '';
						?>
						<option value="<?php echo $value['sid']; ?>" <?php echo $flg; ?>><?php echo $value['sortname']; ?></option>
						<?php
							$children = $value['children'];
							foreach ($children as $key):
								$value = $sorts[$key];
								$flg = $value['sid'] == $sortid ? 'selected' : '';
								?>
								<option value="<?php echo $value['sid']; ?>" <?php echo $flg; ?>>&nbsp; &nbsp; &nbsp; <?php echo $value['sortname']; ?></option>
								<?php
							endforeach;
						endforeach;
						?>
					</select>
				</div>
				<div class="layui-input-inline">
					<input type="text" name="postdate" id="postdate" value="<?php echo $postDate; ?>" maxlength="200" placeholder="发布时间" class="layui-input">
				</div>
			</div>
		</div>
	</div>
	<div id="tagbox" style="display: none;">
	<?php
		$tagshtml='<blockquote class="layui-elem-quote layui-quote-nm">';
		if ($tags) {
			foreach ($tags as $val){
				$tagshtml.='
					<button type="button" class="layui-btn layui-btn-primary layui-btn-radius" onClick=\'insertTag("'.$val['tagname'].'","tag");\'>'.$val["tagname"].'</button>
				';
			}
		} else {
			$tagshtml.='还没有标签';
		}
		$tagshtml.='</blockquote>';
		echo $tagshtml;
	?>
	</div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
	  <legend>
		<button type="button" onclick="displayToggle('advset', 1);" class="layui-btn layui-btn-primary">高级选项</button>
	  </legend>
	</fieldset>
	
	<div id="advset">
		<div style="background-color:#fff;">
			<textarea id="excerpt" name="excerpt"><?php echo $excerpt; ?></textarea>
		</div>
		
		<div class="layui-form-item">
			<div class="layui-row">
				<select name="copy" id="copy" lay-filter="copy">
					<option value="-1" <?php echo  $copy =='-1' ? 'selected' : '';?>>版权设置...</option>
					<option value="1" <?php echo  $copy =='1' ?  'selected' : '';?>>原创</option>
					<option value="2" <?php echo  $copy =='2' ? 'selected' : '';?>>转载</option>
				</select>
			</div>
		</div>
		
		<div class="layui-form-item">
			<div class="layui-row">
				<input type="text" name="copyurl" id="copyurl" value="<?php echo $copyurl; ?>" maxlength="255" autocomplete="off" placeholder="转载地址，填入原文地址，原创忽略" class="layui-input">
			</div>
		</div>
		
		<div class="layui-row">
		  <div class="layui-card">
			<div class="layui-card-header">
				文章链接别名：(需要<a href="./seo.php" target="_blank">启用文章链接别名</a>)<span id="alias_msg_hook"></span>
			</div>
			<div class="layui-card-body">
				<input type="text" name="alias" id="alias" placeholder="文章链接别名，用于自定义文章链接" class="layui-input" value="<?php echo $alias;?>">
			</div>
		  </div>
		</div>
		
		<div class="layui-row">
		  <div class="layui-card">
			<div class="layui-card-body">
				<div class="layui-input-inline">
					<input type="text" name="password" id="password" value="<?php echo $password; ?>" placeholder="文章访问密码" class="layui-input">
				</div>
				<div class="layui-input-inline" id="post_options">
					<input type="checkbox" name="top" value="y" <?php echo $is_top; ?> title="首页置顶" id="top" />
					<input type="checkbox" name="sortop" value="y" <?php echo $is_sortop; ?> title="分类置顶" id="sortop" />
					<input type="checkbox" name="allow_remark" value="y" <?php echo $is_allow_remark; ?> title="允许评论" id="allow_remark" />
				</div>
			</div>
		  </div>
		</div>
	</div>
	<div id="post_button">
		<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
		<input type="hidden" name="ishide" id="ishide" value="<?php echo $hide; ?>">
		<input type="hidden" name="gid" value=<?php echo $logid; ?> />
		<input type="hidden" name="author" id="author" value=<?php echo $author; ?> />
		<?php if ($logid < 0):?>
		<input type="submit" onclick="return checkform();" class="layui-btn" value="发布文章" />
		<input type="button" name="savedf" id="savedf" value="保存草稿" onclick="autosave(2);" class="layui-btn layui-btn-primary" />
        <?php else:?>
        <input type="submit" value="保存并返回" onclick="return checkform();" class="layui-btn" />
		<input type="button" name="savedf" id="savedf" value="保存" onclick="autosave(2);" class="layui-btn layui-btn-primary" />
        <?php if ($isdraft) :?>
        <input type="submit" name="pubdf" id="pubdf" value="发布" onclick="return checkform();" class="layui-btn" />
        <?php endif;?>
        <?php endif;?>
	</div>
</form>
<script>
checkalias();
$("#alias").keyup(function(){checkalias();});
$("#advset").css('display', $.cookie('em_advset') ? $.cookie('em_advset') : '');
setTimeout("autosave(0)",60000);
<?php if ($isdraft) :?>
$("#menu_draft").addClass('layui-this');
$("#menu_draft").parent().parent().addClass('layui-nav-itemed');
<?php else:?>
$("#menu_wt").addClass('layui-this');
$("#menu_wt").parent().parent().addClass('layui-nav-itemed');
<?php endif;?>
</script>
<script>
var layedit;
var contentLayUIEditor;
var excerptLayUIEditor;
$(function(){
	layui.use(['layedit', 'jquery',"laypage", "layer", "form"], function(){
	  var $ = layui.jquery;
	  var layer = layui.layer;
	  layedit = layui.layedit;
	  var form = layui.form;
	  layedit.set({
		  <?php if($logid){?>
		  uploadImage: {
			url: '<?php echo TLE_SERVICE_HOST;?>api/web/?action=weiboimg'
			,type: 'post'
			,accept: 'image'
			,acceptMime: 'image/*'
			,exts: 'jpg|png|gif|bmp|jpeg'
			,size: '2048'
		  },
		  uploadVideo: {
			url: 'attachment.php?action=upload&logid=<?=$logid?>&type=video',
			accept: 'video',
			acceptMime: 'video/*',
			exts: 'mp4|flv|avi|rm|rmvb',
			size: '20480',
			field:'attach'
		  }
		  <?php }else{?>
		  uploadImage: {
			url: '<?php echo TLE_SERVICE_HOST;?>api/web/?action=weiboimg'
			,type: 'post'
			,accept: 'image'
			,acceptMime: 'image/*'
			,exts: 'jpg|png|gif|bmp|jpeg'
			,size: '2048'
		  }
		  <?php }?>
	  });
	  <?php if($logid){?>
	  contentLayUIEditor=layedit.build('content',{
		  height:400,
		  tool: [
                'html', 'undo', 'redo', 'code', 'strong', 'italic', 'underline', 'del', 'addhr', '|','removeformat', 'fontFomatt', 'fontfamily','fontSize', 'fontBackColor', 'colorpicker', 'face'
                , '|', 'left', 'center', 'right', '|', 'link', 'unlink', 'images', 'image_alt', 'video', 'anchors', '|', 'table','customlink','preview'
            ]
	  });
	  <?php }else{?>
	  contentLayUIEditor=layedit.build('content',{
		  height:400,
		  tool: [
                'html', 'undo', 'redo', 'code', 'strong', 'italic', 'underline', 'del', 'addhr', '|','removeformat', 'fontFomatt', 'fontfamily','fontSize', 'fontBackColor', 'colorpicker', 'face'
                , '|', 'left', 'center', 'right', '|', 'link', 'unlink', 'images', 'image_alt', 'anchors', '|', 'table','customlink','preview'
            ]
	  });
	  <?php }?>
	  excerptLayUIEditor=layedit.build('excerpt',{
		  height:200,
		  tool: [
                'html', 'undo', 'redo', 'code', 'strong', 'italic', 'underline', 'del', 'addhr', '|','removeformat', 'fontFomatt', 'fontfamily','fontSize', 'fontBackColor', 'colorpicker', 'face'
                , '|', 'left', 'center', 'right', '|', 'link', 'unlink', 'images', 'image_alt', 'anchors', '|', 'table','customlink','preview'
            ]
	  });
	});
});
</script>