<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
	  <legend><b>修改导航</b></legend>
	</fieldset>
</div>
<form class="layui-form" action="navbar.php?action=update" method="post">
<div>
	<li>
		<div style="margin:10px 0px;">导航名称</div>
	<input size="20" value="<?php echo $naviname; ?>" class="layui-input" name="naviname" />
	</li>
	<li>
		<div style="margin:10px 0px;">导航地址</div>
		<input class="layui-input" size="50" value="<?php echo $url; ?>" name="url" <?php echo $conf_isdefault; ?> /> 
    </li>
	<li style="margin:10px 0px;">
		<input type="checkbox" style="vertical-align:middle;" value="y" name="newtab" <?php echo $conf_newtab; ?> lay-skin="primary" />在新窗口打开
	</li>
    <?php if ($type == Navi_Model::navitype_custom && $pid != 0): ?>
    <li>
		<div style="margin:10px 0px;">父导航</div>
		<select name="pid" id="pid">
			<option value="0">无</option>
			<?php
				foreach($navis as $key=>$value):
					if($value['type'] != Navi_Model::navitype_custom || $value['pid'] != 0) {
						continue;
					}
					$flg = $value['id'] == $pid ? 'selected' : '';
			?>
			<option value="<?php echo $value['id']; ?>" <?php echo $flg;?>><?php echo $value['naviname']; ?></option>
			<?php endforeach; ?>
		</select>
    </li>
    <?php endif; ?>
	<li style="margin:10px 0px;">
		<input type="hidden" value="<?php echo $naviId; ?>" name="navid" />
		<input type="hidden" value="<?php echo $isdefault; ?>" name="isdefault" />
		<input type="submit" value="保 存" class="layui-btn" />
		<input type="button" value="取 消" class="layui-btn layui-btn-primary" onclick="javascript: window.history.back();" />
	</li>
</div>
</form>
<script>
$(function(){
	layui.use(["form"], function(){
		var form = layui.form;
	});
});
$("#menu_navbar").addClass('layui-this');
$("#menu_navbar").parent().parent().addClass('layui-nav-itemed');
</script>