<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
				<div>
					<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
					  <legend><b><?php echo $containertitle; ?></b></legend>
					</fieldset>
					<span id="msg_2"></span>
				</div>
				<div id="msg"></div>
				<form class="layui-form" action="page.php?action=save" method="post" enctype="multipart/form-data" id="addlog" name="addlog">
					<div id="post">
						<div class="layui-form-item">
							<div class="layui-row">
							  <input type="text" name="title" id="title" maxlength="200" autocomplete="off" placeholder="输入页面标题" value="<?php echo $title; ?>" class="layui-input">
							</div>
						</div>
						<div id="post_bar">
							<div>
								<?php if(Option::get('att_maxsize')!=0){?>
								<button type="button" onclick="displayToggle('FrameUpload', 0);autosave(4);" class="layui-btn layui-btn-primary layui-btn-xs">上传插入</button>
								<?php }?>
								<?php doAction('adm_writelog_head'); ?>
								<span id="asmsg"></span>
								<input type="hidden" name="as_logid" id="as_logid" value="<?php echo $pageId; ?>">
							</div>
							<div id="FrameUpload" style="display: none;">
								<iframe width="100%" height="320" frameborder="0" src="<?php echo $att_frame_url; ?>"></iframe>
							</div>
						</div>
						<div style="background-color:#fff;">
							<textarea id="content" name="content"><?php echo $content; ?></textarea>
						</div>
					</div>
					
					<div class="layui-row">
					  <div class="layui-card">
						<div class="layui-card-header">
							链接别名：(需要<a href="./seo.php" target="_blank">启用链接别名</a>)<span id="alias_msg_hook"></span>
						</div>
						<div class="layui-card-body">
							<input type="text" name="alias" id="alias" placeholder="链接别名，用于自定义该页面的链接地址" value="<?php echo $alias; ?>" class="layui-input">
						</div>
					  </div>
					</div>
					
					<div class="layui-row">
					  <div class="layui-card">
						<div class="layui-card-header">
							页面模板
						</div>
						<div class="layui-card-body">
							<div class="layui-input-inline">
								<input type="text" maxlength="200" name="template" id="template" placeholder="自定义页面模板，对应模板目录下.php文件" class="layui-input" value="<?php echo $template;?>">
							</div>
						</div>
						<div class="layui-card-body">
							<div class="layui-input-inline" id="page_options">
								<input type="checkbox" name="allow_remark" value="y" <?php echo $is_allow_remark; ?> title="页面接受评论" id="allow_remark" class="layui-input" />
							</div>
						</div>
					  </div>
					</div>
				
					<div id="post_button">
						<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
						<input type="hidden" name="ishide" id="ishide" value="<?php echo $hide; ?>">
						<input type="hidden" name="gid" value=<?php echo $pageId; ?> />
						<?php if ($pageId < 0):?>
						<input type="submit" value="发布页面" onclick="return checkform();" class="layui-btn" />
						<input type="button" name="savedf" id="savedf" value="保存" onclick="autosave(3);" class="layui-btn layui-btn-primary" />
						<?php else:?>
						<input type="submit" value="保存并返回" onclick="return checkform();" class="layui-btn" />
						<input type="button" name="savedf" id="savedf" value="保存" onclick="autosave(3);" class="layui-btn layui-btn-primary" />
						<?php endif;?>
					</div>
				</form>
<script>
checkalias();
$("#alias").keyup(function(){checkalias();});
$("#menu_page_new").addClass('layui-this');
$("#menu_page_new").parent().parent().addClass('layui-nav-itemed');
</script>
<script>
var layedit;
var contentLayUIEditor;
$(function(){
	layui.use(['layedit', 'jquery',"laypage", "layer", "form"], function(){
	  var $ = layui.jquery;
	  var layer = layui.layer;
	  layedit = layui.layedit;
	  var form = layui.form;
	  layedit.set({
		  uploadImage: {
			url: '<?php echo TLE_SERVICE_HOST;?>api/web/?action=weiboimg'
			,type: 'post'
		  }
	  });
	  contentLayUIEditor=layedit.build('content',{
		  height:400,
		  tool: [
                'html', 'undo', 'redo', 'code', 'strong', 'italic', 'underline', 'del', 'addhr', '|','removeformat', 'fontFomatt', 'fontfamily','fontSize', 'fontBackColor', 'colorpicker', 'face'
                , '|', 'left', 'center', 'right', '|', 'link', 'unlink', 'images', 'image_alt', 'anchors', '|', 'table','customlink','preview'
            ]
	  });
	});
});
</script>