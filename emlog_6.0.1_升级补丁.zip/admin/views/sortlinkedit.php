<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
	  <legend><b>编辑分类</b></legend>
	</fieldset>
	<?php if(isset($_GET['error_a'])):?><blockquote class="error layui-elem-quote">分类名称不能为空</blockquote><?php endif;?>
</div>
<div>
<form class="layui-form" action="sortlink.php?action=update" method="post">
	<input style="width:240px;" type="text" name="linksort_name" id="linksort_name" value="<?php echo $linksort_name; ?>" class="layui-input" placeholder="名称" />
	<input type="hidden" value="<?php echo $linksort_id; ?>" name="linksort_id" />
	<input type="submit" class="layui-btn" name="" value="保存"  />
	<input type="button" value="取消" class="layui-btn layui-btn-primary"  onclick="javascript: window.history.back();" />
</form>
</div>
<script>
setTimeout(hideActived,2600);;
$("#menu_linksort").addClass('layui-this');
$("#menu_linksort").parent().parent().addClass('layui-nav-itemed');
</script>