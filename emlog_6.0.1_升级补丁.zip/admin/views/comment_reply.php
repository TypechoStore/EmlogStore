<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
	  <legend>回复评论</legend>
	</fieldset>
</div>
<form class="layui-form" action="comment.php?action=doreply" method="post">
<div>
	<li style="margin:10px 0px;">评论人：<?php echo $poster; ?></li>
	<li style="margin:10px 0px;">时间：<?php echo $date; ?></li>
	<li style="margin:10px 0px;">内容：<?php echo $comment; ?></li>
	<li style="margin:10px 0px;"><textarea name="reply" rows="5" cols="60" class="layui-textarea"></textarea></li>
	<li style="margin:10px 0px;">
		<input type="hidden" value="<?php echo $commentId; ?>" name="cid" />
		<input type="hidden" value="<?php echo $gid; ?>" name="gid" />
		<input type="hidden" value="<?php echo $hide; ?>" name="hide" />
		<input type="submit" value="回复" class="layui-btn" />
		<?php if ($hide == 'y'): ?>
			<input type="submit" value="回复并审核" name="pub_it" class="layui-btn layui-btn-primary" />
		<?php endif; ?>
		<input type="button" value="取 消" class="layui-btn layui-btn-primary" onclick="javascript: window.history.back();"/></li>
</div>
</form>
<script>
$("#menu_cm").addClass('layui-this');
$("#menu_cm").parent().parent().addClass('layui-nav-itemed');
</script>