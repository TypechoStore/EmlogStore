<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<script>setTimeout(hideActived,2600);</script>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
		<legend>
			<b>安装插件</b>
			<small><a href="./store.php" class="layui-btn layui-btn-primary layui-btn-xs">获取更多插件前往应用中心</a></small>
		</legend>
	</fieldset>
	<div id="msg"></div>
	<?php if(isset($_GET['error_a'])):?><blockquote class="error layui-elem-quote">只支持zip压缩格式的插件包</blockquote><?php endif;?>
	<?php if(isset($_GET['error_b'])):?><blockquote class="error layui-elem-quote">上传失败，插件目录(content/plugins)不可写</blockquote><?php endif;?>
	<?php if(isset($_GET['error_c'])):?><blockquote class="error layui-elem-quote">空间不支持zip模块，请按照提示手动安装插件</blockquote><?php endif;?>
	<?php if(isset($_GET['error_d'])):?><blockquote class="error layui-elem-quote">请选择一个zip插件安装包</blockquote><?php endif;?>
	<?php if(isset($_GET['error_e'])):?><blockquote class="error layui-elem-quote">安装失败，插件安装包不符合标准</blockquote><?php endif;?>
</div>
<?php if(isset($_GET['error_c'])): ?>
<blockquote class="layui-elem-quote">
手动安装插件： <br />
1、把解压后的插件文件夹上传到 content/plugins 目录下。<br />
2、登录后台进入插件管理,插件管理里已经有了该插件，点击激活即可。
</blockquote>
<?php endif; ?>
<form class="layui-form" action="./plugin.php?action=upload_zip" method="post" enctype="multipart/form-data" >
<div>
	<p>
		<input name="pluzip" type="file" />
	</p>
	<p style="margin:10px 0px;">
		<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
		<input type="submit" value="上传安装" class="layui-btn layui-btn-primary layui-btn-sm" /> （上传一个zip压缩格式的插件安装包）
	</p>
</div>
</form>
<script>
$("#menu_plug").addClass('layui-this');
$("#menu_plug").parent().parent().addClass('layui-nav-itemed');
</script>