<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content" class="layui-row layui-col-space20 layadmin-homepage-list-imgtxt">
  <div id="contentleft" class="layui-col-md9">
	<div id="tw" class="grid-demo">
		<?php 
		if($tws){
			foreach($tws as $val):
			$author = $user_cache[$val['author']]['name'];
			$avatar = empty($user_cache[$val['author']]['avatar']) ? 
						BLOG_URL.ADMIN_DIR . '/views/images/avatar.jpg' : 
						BLOG_URL . $user_cache[$val['author']]['avatar'];
			$tid = (int)$val['id'];
			$img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img class="h-img" style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
			?> 
			<div class="panel-body layadmin-homepage-shadow">
				<a href="javascript:;" class="media-left">
				  <img src="<?php echo $avatar; ?>" width="46px" height="46px" />
				</a>
				<div class="media-body">
				  <div class="pad-btm">
					<p class="fontColor"><a href="javascript:;"><?php echo $author; ?></p>
					<p class="min-font">
					  <span class="layui-breadcrumb" lay-separator="-">
						<a href="javascript:;"><?php echo $val['date']; ?></a>
						<a href="javascript:;"><span id="rn_<?php echo $tid;?>"><?php echo $val['replynum']; ?></span>人回复</a>
					  </span>
					</p>         
				  </div>
				  <?php echo unCompress(formatContent($val['t'])).'<br/>'.$img;?>
				  <div class="media">
					<div class="media-right">
					  <ul class="list-inline">
						<?php if(Option::get('istreply') == 'y'){?>
						<li>
							<a href="javascript:loadr('<?php echo DYNAMIC_BLOGURL; ?>t/?action=getr&tid=<?php echo $tid;?>','<?php echo $tid;?>');">
							  <i class="layui-icon layui-icon-reply-fill"></i>
							  <span><?php echo $val['replynum']; ?></span>
							</a>
						</li>
						<?php }?>
					  </ul>
					</div>
				  </div>
				  <?php if ($istreply == 'y'):?>
					<div id="rp_<?php echo $tid;?>" style="display:none;">
					<textarea class="layui-textarea" maxLength="140" id="rtext_<?php echo $tid; ?>" placeholder="回复内容"></textarea>
					<div>
						<div style="display:<?php if(ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER){echo 'none';}?>">
						<input class="layui-input" placeholder="昵称" type="text" id="rname_<?php echo $tid; ?>" value="" />
						<span style="display:<?php if($reply_code == 'n'){echo 'none';}?>"><input class="layui-input" placeholder="验证码" type="text" id="rcode_<?php echo $tid; ?>" value="" /><?php echo $rcode; ?></span>
						</div>
						<input class="layui-btn layui-btn-primary layui-btn-sm" type="button" onclick="reply('<?php echo DYNAMIC_BLOGURL."t/"; ?>index.php?action=reply',<?php echo $tid;?>);" value="回复" /> 
						<span id="rmsg_<?php echo $tid; ?>" style="color:#FF0000"></span>
					</div>
					</div>
				  <?php endif;?>
				  <div class="media-list" id="r_<?php echo $tid;?>" style="display:none;"></div>
				</div>
			</div>
			<?php endforeach;?>
			<center><div id="page"></div></center>
		<?php
		}else{
		?>
		<div class="layui-fluid">
		  <div class="layadmin-tips">
			<i class="layui-icon" face>&#xe664;</i>
			<div class="layui-text" style="width:100%;">
			  <h2>
				未找到
			  </h2>
			  <p>抱歉，没有任何微语。</p>
			</div>
		  </div>
		</div>
		<?php
		}
		?>
	</div><!--end #tw-->
  </div>
  <script>
  $(function(){
	layui.use(["laypage"], function(){
		var laypage = layui.laypage;
		laypage.render({
			elem: "page"
			,count: <?=$twnum;?>
			,limit: <?=Option::get('index_twnum');?>
			,curr:<?=$page;?>
			,layout: ["prev", "page", "next", "skip"]
			,jump: function(obj,first){
				if(!first){
				  location.href="<?=BLOG_URL;?>t/?page="+obj.curr;
				}
			}
		});
	});
  });
  </script>
  <?php include View::getView('side');?>
</div><!--end #contentleft-->
<?php include View::getView('footer');?>