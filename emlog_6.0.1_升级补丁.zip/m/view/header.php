<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');}
echo '<?xml version="1.0" encoding="UTF-8"?>';
$DB = Database::getInstance();
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title." ".$page_repeat; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link rel="stylesheet" href="<?php echo BLOG_URL.ADMIN_DIR; ?>/views/ui/layui/css/layui.css" media="all">
<link rel="stylesheet" href="<?php echo BLOG_URL.ADMIN_DIR; ?>/views/ui/style/admin.css" media="all">
<link rel="stylesheet" href="<?php echo BLOG_URL.ADMIN_DIR; ?>/views/ui/style/template.css" media="all">
<script type="text/javascript" src="<?php echo BLOG_URL; ?>include/lib/js/jquery/jquery-1.11.0.js?v=<?php echo Option::EMLOG_VERSION; ?>"></script>
</head>
<body>
<ul id="navi" class="layui-nav layui-bg-blue" lay-filter="">
  <li class="layui-nav-item"><a href="./"><?php echo Option::get('blogname'); ?></a></li>
  <li class="layui-nav-item"><a class="" href="./">首页</a></li>
  <?php if(Option::get('istwitter') == 'y'): ?>
  <li class="layui-nav-item"><a class="" href="./?action=tw">微语</a></li>
  <?php endif;?>
  <?php if(ISLOGIN === true): ?>
  <li class="layui-nav-item"><a href="./?action=write">写文章</a></li>
  <li class="layui-nav-item"><a href="./?action=logout">退出</a></li>
  <?php else:?>
  <li class="layui-nav-item"><a href="<?php echo BLOG_URL; ?>m/?action=login">登录</a></li>
  <?php endif;?>
</ul>