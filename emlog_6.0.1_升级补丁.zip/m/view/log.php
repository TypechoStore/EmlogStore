<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div id="m" class="layui-row layui-col-space20 layadmin-homepage-list-imgtxt">
  <div id="mleft" class="layui-col-md12">
	<div class="grid-demo" style="padding: 20px;">
		<?php if($logs){?>
		<?php foreach($logs as $value): ?>
		<div class="panel-body layadmin-homepage-shadow">
			<div class="media-body">
			  <div class="pad-btm">
				<p class="fontColor">
					<a href="<?php echo BLOG_URL; ?>m/?post=<?php echo $value['logid'];?>"><?php echo $value['log_title']; ?></a>
				</p>
				<p class="min-font">
				  <span class="layui-breadcrumb" lay-separator="-">
					<a href="javascript:;"><?php echo date('Y-n-j', $value['date']); ?></a>
				  </span>
				</p>         
			  </div>
			  <div class="media">
				<div class="media-right">
				  <ul class="list-inline">
					<li>
						<a href="javascript:;">
						  <i class="layui-icon layui-icon-reply-fill"></i>
						  <span><?php echo $value['comnum']; ?></span>
						</a>
					</li>
					<li>
						<a href="javascript:;">
						  <i class="layui-icon layui-icon-fire"></i>
						  <span><?php echo $value['views']; ?></span>
						</a>
					</li>
					<?php if(ROLE == ROLE_ADMIN || $value['author'] == UID): ?>
					<li>
						<a href="./?action=write&id=<?php echo $value['logid'];?>">
						  <i class="layui-icon layui-icon-edit"></i>
						  <span>编辑</span>
						</a>
					</li>
					<?php endif;?>
				  </ul>
				</div>
			  </div>
			</div>
		</div>
		<?php endforeach; ?>
		<center><div id="page"></div></center>
		<?php
		}
		?>
	</div>
  </div>
  <script>
  $(function(){
	layui.use(["laypage"], function(){
		var laypage = layui.laypage;
		laypage.render({
			elem: "page"
			,count: <?=$lognum;?>
			,limit: <?=Option::get('index_lognum');?>
			,curr:<?=$page;?>
			,layout: ["prev", "page", "next", "skip"]
			,jump: function(obj,first){
				if(!first){
				  location.href="./?page="+obj.curr;
				}
			}
		});
	});
  });
  </script>
</div>