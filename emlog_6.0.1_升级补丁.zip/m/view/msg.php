<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div id="m" class="layui-row layui-col-space20 layadmin-homepage-list-imgtxt">
  <div id="mleft" class="layui-col-md12">
	<div class="grid-demo">
		<center>
		  <div class="layui-card">
			<div class="layui-card-header" style="background-color:#eee;">提示</div>
			<div class="layui-card-body">
				<?php echo $msg;?>
				<a href="<?php echo $url; ?>">返回</a>
			</div>
		  </div>
		</center>
	</div>
  </div>
</div>