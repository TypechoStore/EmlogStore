<?php
/**
 * 升级程序6.0.1 to 6.1.1
 * @copyright (c) Emlog All Rights Reserved
 */
require_once 'init.php';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0" />
<title>EMLOG升级脚本</title>
<link rel="stylesheet" href="./<?=ADMIN_DIR;?>/views/ui/layui/css/layui.css" media="all">
</head>
<body>
<div class="layui-layout layui-layout-admin">
  <div class="layui-header">
    <div class="layui-logo">Emlog 升级向导</div>
    <ul class="layui-nav layui-layout-right">
      <li class="layui-nav-item">
        <a href="javascript:;">4、升级脚本</a>
      </li>
    </ul>
  </div>
  <blockquote class="layui-elem-quote">
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
		<legend>升级脚本</legend>
	</fieldset>
	<p>
		Emlog <span style="color: #0099FF">6.0.1</span> -----&gt; <span style="color: #FF0000;">6.1.1</span> 升级脚本
	</p>
  </blockquote>
  <?php if(!isset($_GET['action'])){?>
  <form class="layui-form" method="post" action="update_6.0.1.php?action=update" style="padding:0px 20px;">
	<div class="layui-form-item">
		<label>数据库密码</label>
		<input style="margin-top:5px;" class="layui-input" name="password" type="text" value="">
	</div>
	<center>
		<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		<button class="layui-btn">确定</button>
	</center>
  </form>
  <?php }?>
</div>
<?php
	if(isset($_GET['action'])&&$_GET['action'] == "update") {
		$DB = Database::getInstance();
		$CACHE = Cache::getInstance();

		$db_prefix = DB_PREFIX;

		$dbcharset = 'utf8';
		$type = 'MYISAM';
		$table_charset_sql = $DB->getMysqlVersion() > '4.1' ? 'ENGINE='.$type.' DEFAULT CHARSET='.$dbcharset.';' : 'ENGINE='.$type.';';
		$extra = "ENGINE=".$type." DEFAULT CHARSET=".$dbcharset.";";
		$extra2 = "TYPE=".$type;
		$add = $DB->getMysqlVersion() > '4.1' ? $extra : $extra2.";";

		$widgets = Option::getWidgetTitle();
		$sider_wg = Option::getDefWidget();

		$widget_title = serialize($widgets);
		$widgets = serialize($sider_wg);
		$white = addslashes('admin|\/content\/');
		
		if (DB_PASSWD != trim($_POST['password'])){
			emMsg('输入的数据库密码错误,请重新输入');
		}

		if (Option::EMLOG_VERSION != '6.0.1') {
			emMsg('错误:你确定你现在用的是6.0.1升级包吗?');
		}
		   
		if($DB->num_rows($DB->query("SELECT * FROM {$db_prefix}options WHERE option_name='email_reg'")) == 1) {
			emMsg('数据库已升级完成，请勿重复运行升级脚本');
		}	

		$sql = "
			DROP TABLE IF EXISTS {$db_prefix}reply;
			CREATE TABLE {$db_prefix}reply (
			  id int(10) unsigned NOT NULL auto_increment,
			  tid int(10) unsigned NOT NULL default '0',
			  date bigint(20) NOT NULL,
			  name varchar(20) NOT NULL default '',
			  content text NOT NULL,
			  hide enum('n','y') NOT NULL default 'n',
			  ip varchar(128) NOT NULL default '',
			  PRIMARY KEY  (id),
			  KEY gid (tid),
			  KEY hide (hide)
			)".$table_charset_sql."
		";
		$array_sql = preg_split("/;[\r\n]/", $sql);
		foreach($array_sql as $sql){
			$sql = trim($sql);
			if ($sql) {
				$DB->query($sql);
			}
		}
		/*
		ALTER TABLE {$db_prefix}twitter ADD COLUMN replynum int(10) unsigned NOT NULL default '0' AFTER date;

		ALTER TABLE {$db_prefix}user ADD COLUMN authCode VARCHAR(64) AFTER website;
		ALTER TABLE {$db_prefix}user ADD COLUMN instime datetime AFTER authCode;
		ALTER TABLE {$db_prefix}user ADD COLUMN logintime datetime AFTER instime;
		*/
		updateAlterColumn($DB,DB_NAME,$db_prefix.'twitter','replynum','int(10) unsigned NOT NULL default "0"');
		
		updateAlterColumn($DB,DB_NAME,$db_prefix.'user','authCode','VARCHAR(64)');
		updateAlterColumn($DB,DB_NAME,$db_prefix.'user','instime','datetime');
		updateAlterColumn($DB,DB_NAME,$db_prefix.'user','logintime','datetime');
		$sql = "
			UPDATE {$db_prefix}options SET option_value = 'smtp.exmail.qq.com' WHERE {$db_prefix}options.option_name = 'MAIL_SMTP';
			UPDATE {$db_prefix}options SET option_value = '465' WHERE {$db_prefix}options.option_name = 'MAIL_PORT';
			UPDATE {$db_prefix}options SET option_value = 'Y' WHERE {$db_prefix}options.option_name = 'SEND_MAIL';
			UPDATE {$db_prefix}options SET option_value = 'Y' WHERE {$db_prefix}options.option_name = 'REPLY_MAIL';
			
			INSERT INTO {$db_prefix}options (option_name, option_value) VALUES ('email_reg','n');
		";
		$array_sql = preg_split("/;[\r\n]/", $sql);
		foreach($array_sql as $sql){
			$sql = trim($sql);
			if ($sql) {
				$DB->query($sql);
			}
		}

		@unlink('./content/cache/comment');
		@unlink('./content/cache/link');
		@unlink('./content/cache/logalias');
		@unlink('./content/cache/logsort');
		@unlink('./content/cache/logtags');
		@unlink('./content/cache/navi');
		@unlink('./content/cache/newlog');
		@unlink('./content/cache/newtw');
		@unlink('./content/cache/options');
		@unlink('./content/cache/record');
		@unlink('./content/cache/sort');
		@unlink('./content/cache/sortlink');
		@unlink('./content/cache/sta');
		@unlink('./content/cache/tags');
		@unlink('./content/cache/user');

		$CACHE->updateCache();
		@touch('./install/install.lock');
		$result .= "
				<p style=\"font-size:24px; padding:10px 0px;\">恭喜,升级成功！</p>
				<p>您的Emlog已经是最新6.1.1版的了,如果存在update_6.0.1.php,请删除里面的update_6.0.1.php文件</p>
		";
		@unlink('./update_6.0.1.php');
		$result .= "<p style=\"text-align:right;\"><a href=\"./\">访问首页</a> | <a href=\"./".ADMIN_DIR."/\">登录后台</a></p>";
		emMsg($result, 'none');
	}
	echo "</body>";
	echo "</html>";
	/*修改数据表字段*/
	function updateAlterColumn($db,$dbname,$table,$column,$define){
		$row = $db->once_fetch_array("select * from information_schema.columns WHERE TABLE_SCHEMA='".$dbname."' and table_name = '".$table."' AND column_name = '".$column."'");
		if(count($row)==0){
			$db->query('ALTER TABLE `'.$table.'` ADD COLUMN `'.$column.'` '.$define.';');
		}
	}
?>