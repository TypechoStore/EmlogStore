<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div id="m" class="layui-row layui-col-space20 layadmin-homepage-list-imgtxt">
  <div id="mleft" class="layui-col-md12">
	<div class="grid-demo" style="padding: 20px;">
		<fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
		  <legend><div class="comcont">回复<b><?php echo $poster; ?></b>：<?php echo $comment; ?></div></legend>
		</fieldset>
		<form class="layui-form" method="post" action="./index.php?action=addcom&gid=<?php echo $gid; ?>&pid=<?php echo $cid; ?>">
		<?php
			if(ISLOGIN == true):
			$CACHE = Cache::getInstance();
			$user_cache = $CACHE->readCache('user');
		?>
		<fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
		  <legend>当前已登录为<b><?php echo $user_cache[UID]['name']; ?></b></legend>
		</fieldset>
		<input type="hidden" name="comname" value="<?php echo $user_cache[UID]['name']; ?>" />
		<input type="hidden" name="commail" value="<?php echo $user_cache[UID]['mail']; ?>" />
		<input type="hidden" name="comurl" value="<?php echo BLOG_URL; ?>" />
		<?php else: ?>
		<input placeholder="昵称" class="layui-input" type="text" name="comname" value="" />
		<input placeholder="邮件地址 (选填)" class="layui-input" type="text" name="commail" value="" />
		<input placeholder="个人主页 (选填)" class="layui-input" type="text" name="comurl" value="" />
		<?php endif; ?>
		<textarea placeholder="内容" class="layui-textarea" name="comment" rows="10"></textarea>
		<?php echo $verifyCode; ?>
		<input class="layui-btn layui-btn-primary layui-btn-sm" type="submit" value="发表评论" />
		</form>
	</div>
  </div>
</div>