<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div id="m" class="layui-row layui-col-space20 layadmin-homepage-list-imgtxt">
  <div id="mleft" class="layui-col-md12">
	<div class="grid-demo" style="padding: 20px;">
		<form class="layui-form" method="post" action="./index.php?action=auth" style="background-color:#fff;">
			<input placeholder="用户名" class="layui-input" type="text" name="user" />
			<input placeholder="密码" class="layui-input" type="password" name="pw" />
			<?php echo $ckcode; ?>
			<input type="submit" class="layui-btn layui-btn-primary layui-btn-fluid" value=" 登 录" />
		</form>
	</div>
  </div>
</div>