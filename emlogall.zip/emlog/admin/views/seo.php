<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<script>setTimeout(hideActived,2600);</script>
<div>
	<?php if (ROLE == ROLE_ADMIN):?>
	<button type="button" onclick="location.href='./configure.php'" class="layui-btn layui-btn-primary layui-btn-xs">基本设置</button>
	<button type="button" onclick="location.href='./seo.php'" class="layui-btn layui-btn-primary layui-btn-xs">SEO设置</button>
	<button type="button" onclick="location.href='./mailsafety.php'" class="layui-btn layui-btn-primary layui-btn-xs">邮件防护</button>
	<button type="button" onclick="location.href='./blogger.php'" class="layui-btn layui-btn-primary layui-btn-xs">个人设置</button>
	<?php else:?>
	<button type="button" onclick="location.href='./blogger.php'" class="layui-btn layui-btn-primary layui-btn-xs">个人设置</button>
	<?php endif;?>
	<?php if(isset($_GET['activated'])):?><blockquote class="actived layui-elem-quote">设置保存成功</blockquote><?php endif;?>
	<?php if(isset($_GET['error'])):?><blockquote class="actived layui-elem-quote">保存失败：根目录下的.htaccess不可写</blockquote><?php endif;?>
</div>
<div style="background-color:#fff;padding:10px;">
	<form class="layui-form" action="seo.php?action=update" method="post">
		<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
		  <legend><b>文章链接设置</b></legend>
		</fieldset>
		<blockquote class="layui-elem-quote layui-quote-nm">
		  你可以在这里修改文章链接的形式，如果修改后文章无法访问，那可能是你的服务器空间不支持URL重写，请修改回默认形式、关闭文章连接别名。
			<br />启用链接别名后可以自定义文章和页面的链接地址。
		</blockquote>
		<div>
			<li><input type="radio" name="permalink" value="0" <?php echo $ex0; ?>>默认形式：<span><?php echo BLOG_URL; ?>?post=1</span></li>
			<li><input type="radio" name="permalink" value="1" <?php echo $ex1; ?>>文件形式：<span><?php echo BLOG_URL; ?>post-1.html</span></li>
			<li><input type="radio" name="permalink" value="2" <?php echo $ex2; ?>>目录形式：<span><?php echo BLOG_URL; ?>post/1</span></li>
			<li><input type="radio" name="permalink" value="3" <?php echo $ex3; ?>>分类形式：<span><?php echo BLOG_URL; ?>category/1.html</span></li>
			<div style="border-top:1px solid #F7F7F7; width:300px; margin:10px 0px 10px 0px;"></div>
			<li>启用文章链接别名：<input type="checkbox" style="vertical-align:middle;" value="y" name="isalias" id="isalias" <?php echo $isalias; ?> lay-skin="primary" /></li>
			<li>启用文章链接别名html后缀：<input type="checkbox" style="vertical-align:middle;" value="y" name="isalias_html" id="isalias_html" <?php echo $isalias_html; ?> lay-skin="primary" /></li>
		</div>
		<div style="border-top:1px solid #F7F7F7; width:300px; margin:10px 0px 10px 0px;"></div>
		<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
		  <legend><b>meta信息设置</b></legend>
		</fieldset>
		<div>
			<li><div style="margin:10px 0px;">站点浏览器标题（title）</div><input maxlength="200" style="width:300px;" class="layui-input" value="<?php echo $site_title; ?>" name="site_title" placeholder="站点浏览器标题（title）" /></li>
			<li><div style="margin:10px 0px;">站点关键字（keywords）</div><input maxlength="200" style="width:300px;" class="layui-input" value="<?php echo $site_key; ?>" name="site_key" placeholder="站点关键字（keywords）" /></li>
			<li><div style="margin:10px 0px;">站点浏览器描述（description）</div><textarea name="site_description" class="layui-textarea" cols="" rows="4" style="width:300px;" placeholder="站点浏览器描述（description）"><?php echo $site_description; ?></textarea></li>
			<li><div style="margin:10px 0px;">文章浏览器标题方案</div>
				<select name="log_title_style" lay-filter="log_title_style">
					<option value="0" <?php echo $opt0; ?>>文章标题</option>
					<option value="1" <?php echo $opt1; ?>>文章标题 - 站点标题</option>
					<option value="2" <?php echo $opt2; ?>>文章标题 - 站点浏览器标题</option>
				</select>
			</li>
			<li style="margin-top:10px;">
				<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
				<input type="submit" class="layui-btn" value="保存设置" />
			</li>
		</div>
	</form>
</div>
<script>
$(function(){
	layui.use(["form"], function(){
		var form = layui.form;
	});
});
</script>