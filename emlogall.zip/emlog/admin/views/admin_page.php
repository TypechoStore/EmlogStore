<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
	  <legend>页面管理</legend>
	</fieldset>
	<?php if(isset($_GET['active_del'])):?><blockquote class="actived layui-elem-quote">删除页面成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_hide_n'])):?><blockquote class="actived layui-elem-quote">发布页面成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_hide_y'])):?><blockquote class="actived layui-elem-quote">禁用页面成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_pubpage'])):?><blockquote class="actived layui-elem-quote">页面保存成功</blockquote><?php endif;?>
</div>
<form class="layui-form" action="page.php?action=operate_page" method="post" name="form_page" id="form_page">
	<table id="adm_comment_list" class="layui-table">
	  <colgroup>
		<col width="60">
		<col width="450">
		<col width="60">
		<col width="140">
		<col width="50">
		<col width="140">
	  </colgroup>
	  <thead>
		<tr>
		  <th><b></b></th>
		  <th><b>标题</b></th>
		  <th><b>查看</b></th>
		  <th><b>模板</b></th>
		  <th><b>评论</b></th>
		  <th><b>时间</th>
		</tr> 
	  </thead>
	  <tbody>
		<?php
		if($pages){
			foreach($pages as $key => $value){
				if (empty($navibar[$value['gid']]['url'])){
					$navibar[$value['gid']]['url'] = Url::log($value['gid']);
				}
				$isHide = $value['hide'] == 'y' ? 
				'<font color="red"> - 草稿</font>' : 
				'<a href="'.$navibar[$value['gid']]['url'].'" target="_blank" title="查看页面"><img src="./views/images/vlog.gif" align="absbottom" border="0" /></a>';
				?>
				<tr>
					<td>
						<input type="checkbox" name="page[]" value="<?php echo $value['gid']; ?>" class="ids" lay-skin="primary" />
					</td>
					<td>
						<a href="page.php?action=mod&id=<?php echo $value['gid']?>"><?php echo $value['title']; ?></a> 
						<?php if($value['attnum'] > 0): ?>
						<i class="layui-icon layui-icon-file" lay-tips="附件：<?php echo $value['attnum']; ?>"></i>
						<?php endif; ?>
					</td>
					<td><?php echo $isHide; ?></td>
					<td><?php echo $value['template']; ?></td>
					<td><a href="comment.php?gid=<?php echo $value['gid']; ?>"><?php echo $value['comnum']; ?></a></td>
					<td><?php echo $value['date']; ?></td>
				</tr>
				<?php
			}
		}else{?>
			<tr><td colspan="6">还没有页面</td></tr>
			<?php
		}
		?>
	  </tbody>
	</table>
	<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
	<input name="operate" id="operate" value="" type="hidden" />

	<div>
		<input type="checkbox" title="全选" lay-filter="select_all" />
		<button type="button" class="layui-btn layui-btn-primary" onClick="pageact('del');">删除</button>
		<button type="button" class="layui-btn layui-btn-primary" onClick="pageact('hide');">转为草稿</button>
		<button type="button" class="layui-btn layui-btn-primary" onClick="pageact('pub');">发布</button>
	</div>
</form>
<center><div id="page"></div></center>
<center><?php echo $pageurl; ?> (有<?php echo $pageNum; ?>个页面)</center>
<script>
$(function(){
	layui.use(["laypage", "layer", "form"], function(){
		var form = layui.form;
		var laypage = layui.laypage
		  ,layer = layui.layer;
		  laypage.render({
			elem: "page"
			,count: <?=$pageNum;?>
			,limit: <?=Option::get('admin_perpage_num');?>
			,curr:<?=$page;?>
			,layout: ["prev", "page", "next", "skip"]
			,jump: function(obj,first){
				if(!first){
				  location.href="page.php?page="+obj.curr;
				}
			}
		  });
		form.on('checkbox(select_all)', function(data){
			$("input[name='page[]']").each(function () {
				this.checked = data.elem.checked;
			});
			form.render('checkbox');
		});
	});
	$("#adm_comment_list tbody tr:odd").css("background-color","#F7F7F7");
	$("#adm_comment_list tbody tr")
		.mouseover(function(){$(this).css("background-color","#E9F1FA");$(this).find("span").show();})
		.mouseout(function(){$(this).css("background-color","#F7F7F7");$(this).find("span").hide();})
});
setTimeout(hideActived,2600);
function pageact(act){
	if (getChecked('ids') == false) {
		alert('请选择要操作的页面');
		return;}
	if(act == 'del' && !confirm('你确定要删除所选页面吗？')){return;}
	$("#operate").val(act);
	$("#form_page").submit();
}
$("#menu_page").addClass('layui-this');
$("#menu_page").parent().parent().addClass('layui-nav-itemed');
</script>