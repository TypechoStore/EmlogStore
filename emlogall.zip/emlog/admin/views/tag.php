<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
	  <legend><b>标签管理</b></legend>
	</fieldset>
	<?php if(isset($_GET['active_del'])):?><blockquote class="actived layui-elem-quote">删除标签成功</blockquote><?php endif;?>
	<?php if(isset($_GET['active_edit'])):?><blockquote class="actived layui-elem-quote">修改标签成功</blockquote><?php endif;?>
	<?php if(isset($_GET['error_a'])):?><blockquote class="error layui-elem-quote">请选择要删除的标签</blockquote><?php endif;?>
</div>
<form class="layui-form" action="tag.php?action=dell_all_tag" method="post" name="form_tag" id="form_tag">
	<div>
		<li>
			<?php 
			if($tags):
			foreach($tags as $key=>$value): ?>	
				<input type="checkbox" name="tag[<?php echo $value['tid']; ?>]" class="ids" value="1" lay-skin="primary" />
				<a href="tag.php?action=mod_tag&tid=<?php echo $value['tid']; ?>"><?php echo $value['tagname']; ?></a> &nbsp;&nbsp;&nbsp;
			<?php endforeach; ?>
		</li>
		
		<li style="margin:20px 0px">
			<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
			<input type="checkbox" title="全选" lay-filter="select_all"> 选中项：
			<button type="checkbox" onClick="deltags();" class="layui-btn layui-btn-primary layui-btn-sm">删除</button>
		</li>
		<?php else:?>
		<li style="margin:20px 30px">
			<blockquote class="layui-elem-quote">还没有标签，写文章的时候可以给文章打标签</blockquote>
		</li>
		<?php endif;?>
	</div>
</form>
<script>
$(function(){
	$("#menu_tag").addClass('layui-this');
	$("#menu_tag").parent().parent().addClass('layui-nav-itemed');
	layui.use(["form"], function(){
		var form = layui.form;
		form.on('checkbox(select_all)', function(data){
			$(".ids").each(function () {
				this.checked = data.elem.checked;
			});
			form.render('checkbox');
		});
	});
});
function deltags(){
	if (getChecked('ids') == false) {
		alert('请选择要删除的标签');
		return;
	}
	if(!confirm('你确定要删除所选标签吗？')){return;}
	$("#form_tag").submit();
}
setTimeout(hideActived,2600);
</script>