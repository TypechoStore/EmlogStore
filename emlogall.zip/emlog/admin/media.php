<?php
/**
 * 媒体管理
 * @copyright (c) Emlog All Rights Reserved
 */

require_once 'globals.php';

if ($action == '') {
	$DB=Database::getInstance(); 
	
	$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
	
	$timezone = Option::get('timezone');
	$perpage_num = Option::get('admin_perpage_num');
	$start_limit = !empty($page) ? ($page - 1) * $perpage_num : 0;
	$limit = "LIMIT $start_limit, " . $perpage_num;
	$sql = "SELECT * FROM " . DB_PREFIX . "attachment as a," . DB_PREFIX . "blog as b where a.blogid=b.gid AND thumfor = 0 order by aid desc $limit";;
	$res = $DB->query($sql);
	$medias = array();
	while ($row = $DB->fetch_array($res)) {
		$row['date']	= date("Y-m-d H:i", $row['addtime']);
		$row['title'] 	= !empty($row['title']) ? htmlspecialchars($row['title']) : '无标题';
		$medias[] = $row;
	}
	
	$data = $DB->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "attachment as a," . DB_PREFIX . "blog as b where a.blogid=b.gid AND thumfor = 0");
	$medianum=$data["total"];

	$pageurl =  pagination($medianum, Option::get('admin_perpage_num'), $page, "./media.php?page=");
	
	include View::getView('header');
	require_once(View::getView('media'));
	include View::getView('footer');
	View::output();
}

