<?php 
/**
 * 自定义404页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>错误提示-页面未找到</title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <link rel="stylesheet" href="<?php echo BLOG_URL.ADMIN_DIR; ?>/views/ui/layui/css/layui.css" media="all">
  <link rel="stylesheet" href="<?php echo BLOG_URL.ADMIN_DIR; ?>/views/ui/style/admin.css" media="all">
</head>
<body>

<div class="layui-fluid">
  <div class="layadmin-tips">
    <i class="layui-icon" face>&#xe664;</i>
    <div class="layui-text">
      <h1>
        <span class="layui-anim layui-anim-loop layui-anim-">4</span> 
        <span class="layui-anim layui-anim-loop layui-anim-rotate">0</span> 
        <span class="layui-anim layui-anim-loop layui-anim-">4</span>
      </h1>
	  <p>抱歉，你所请求的页面不存在！</p>
	  <p><a href="javascript:history.back(-1);">&laquo;点击返回</a></p>
    </div>
  </div>
</div>

<script src="<?php echo BLOG_URL.ADMIN_DIR; ?>/views/ui/layui/layui.js"></script>  
<script>
layui.config({
base: '<?php echo BLOG_URL.ADMIN_DIR; ?>/views/ui/'
}).extend({
index: 'lib/index'
}).use(['index']);
</script>
</body>
</html>