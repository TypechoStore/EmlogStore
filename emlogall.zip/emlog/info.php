<?php require_once 'init.php';?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>emlog 说明文档</title>
<style type="text/css">
<!--
body {background-color:#F7F7F7;font-family: Arial;font-size: 12px;line-height:150%;}
.main {background-color:#FFFFFF;color: #666666;width:730px;margin:10px auto;padding:10px;list-style:none;border:#DFDFDF 1px solid;}
#logo{background:url(<?=ADMIN_DIR;?>/views/images/logo.gif) no-repeat center;padding:50px 0px;}
#ver{font-size:18px;text-align:center;}
.title{font-size:24px;font-weight:bold;}
.iteam{font-size:18px;font-weight:bold;color:#666666;border-bottom: #CCCCCC 1px solid;padding:10px;}
li{list-style:none;}
.foot{text-align:center;}
-->
</style>
</head>
<body>
<div class="main">
<div>
<p id="logo"></p>
<p id="ver">版本编号：5.3.1</p>
</div>
<div>
<p class="iteam">简介</p>
<ul>
<li>emlog 是一款基于PHP和MySQL的功能强大的博客及CMS建站系统。致力于为您提供快速、稳定，且在使用上又极其简单、舒适的内容创作及站点搭建服务。</li>
</ul>
<p class="iteam">安装步骤</p>
<ul>
<li>1、将src文件夹下的所有文件上传到服务器你要安装emlog的目录。</li>
<li>2、在浏览器上访问您的站点域名会出现安装界面，按照提示填写后提交。</li>
<li>3、安装成功，开始你的创作吧。</li>
</ul>
<p class="iteam">功能简介</p>
<ul>
<li>一键式更换模板，方便快捷打造个性站点</li>
<li>支持强大的插件扩展功能，随意选择实用的插件，让你的站点无限可能</li>
<li>支持日志URL自定义，链接样式更适合SEO</li>
<li>独有的微语功能，让你用简单的文字记录生活</li>
<li>拥有专门的手机版本，随时随地记录你的生活</li>
<li>清爽的日志撰写页面、配以自动保存，书写博文更加舒适无忧</li>
<li>日志草稿箱功能，方便保存你未完成的日志</li>
<li>支持离线写作，你可以使用Windows Live Write等软件撰写博文</li>
<li>灵活的侧边栏组件(widgets)管理，轻松组合、自定义你喜欢的组件</li>
<li>自定义页面，轻松创建留言板、导航条、个人介绍等页面</li>
<li>多人联合撰写，后台轻松管理多个撰写人</li>
<li>支持灵活的标签(tag)分类，以及传统分类方式</li>
<li>方便的附件（图片、文件）上传和管理</li>
<li>上传的图片可以随意直观的嵌入到日志内容里，让你的日志图文并茂</li>
<li>首页日历方式查阅日志，方便、直观、快捷</li>
<li>数据缓存技术，站点访问速度更快</li>
<li>使用跨浏览器可视化日志编辑器，轻松编辑文章格式</li>
<li>支持RSS日志输出功能 ，方便朋友订阅关注你的站点内容</li>
<li>站点数据备份/恢复功能 </li>
</ul>
<p class="iteam">模板说明</p>
<ul>
<li>
emlog支持一键式更换模板，让你方便快捷的打造自己的个性站点。<a href="http://www.emlog.net" target="_blank">官方站点</a>为您免费提供了许多漂亮的模板下载，如果你喜欢可以下载使用。站点后台可以方便的自行安装管理模板。
</li>
</ul>
<p class="iteam">插件说明</p>
<ul>
<li>
emlog支持强大的插件扩展，让你的站点拥有无限的可能。<a href="http://www.emlog.net" target="_blank">官方站点</a>为您免费提供更多实用的插件下载，如果你喜欢可以下载使用。站点后台可以方便的自行安装管理插件。
</li>
</ul>
<p class="iteam">交流、获取帮助</p>
<ul>
<li>对emlog有任何的意见建议、疑问困惑、或者是发现bug，请进入<a href="http://bbs.emlog.net" target="_blank">emlog讨论组</a>参与讨论。</li>
</ul>
<p class="iteam">需要你的支持和帮助</p>
<ul>
<li>如果你喜欢 emlog请将它介绍给你身边的站长朋友。<br />
要是能在你自己的站点上撰写一篇介绍emlog的文章或者发一条推荐emlog的微博那就更好了：）</li>
</ul>
<p class="iteam">授权方式</p>
<ul>
<li>
<p><a href="http://www.emlog.net/license">Emlog用户授权协议(license)</a></p>
</li>
</ul>
</div>

</div>
</form>
</body>
</html>