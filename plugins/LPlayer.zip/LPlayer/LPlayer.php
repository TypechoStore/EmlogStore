<?php
/**
 * Plugin Name: LPlayer媒体播放器
 * Version: 1.3
 * Plugin URL: http://www.liuzp.com
 * Description: 可以在文章和页面中添加音乐(mp3)或者视频(flv)，支持自定义宽度，高度和是否自动播放。
 * Author: Liuzp
 * Author Email: root@liuzp.com
 * Author URL: http://www.liuzp.com
 */
 
!defined('EMLOG_ROOT') && exit('access deined!');

function allPalyer() {
	$musicPlayerUrl = BLOG_URL."content/plugins/LPlayer/musicPlayer.swf";
	//若想使用循环播放，请使用musicPlayer2.swf（修改上面播放器路径）
	$videoPlayerUrl = BLOG_URL."content/plugins/LPlayer/videoPlayer.swf";
	$showPlayer = ob_get_clean();
	if(preg_match("/(.*)musicPlayer2.swf/", $musicPlayerUrl)){
		$showPlayer = preg_replace("/\[music url=(.*) w=(.*) h=(.*) auto=(.*)\]/", '<embed src="'.$musicPlayerUrl.'?song=liuzp.com&amp;autoStart=yes&amp;repeatPlay=yes&amp;mp3=\1" width="150" height="80" type="application/x-shockwave-flash" wmode="transparent"></embed>', $showPlayer);
	}else{
		$showPlayer = preg_replace("/\[music url=(.*) w=(.*) h=(.*) auto=(.*)\]/", '<embed src="'.$musicPlayerUrl.'?url=\1&amp;autoplay=\4" type="application/x-shockwave-flash" wmode="transparent" allowscriptaccess="always" width="\2" height="\3"></embed>', $showPlayer);
	}
	$showPlayer = preg_replace("/\[video url=(.*) w=(.*) h=(.*) auto=(.*)\]/", '<embed src="'.$videoPlayerUrl.'" allowfullscreen="true" flashvars="vcastr_file=\1&LogoText=www.liuzp.com&IsAutoPlay=\4" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="\2" height="\3"></embed>', $showPlayer);
	$showPlayer = preg_replace('/(<meta name="description" content=")(.*)(<embed.*<\/embed>)(.*)(" \/>)/', '\1\2\4\5', $showPlayer);
	ob_start();
	echo $showPlayer;
}

function insertPlayer(){
	?>
	<link href="/content/plugins/LPlayer/style.css" type="text/css" rel="stylesheet" />
	<span class="lplayer">
		<a id="insertMedia" href="javascript:void(0);">插入媒体</a>
		<div class="insertMain" id="insertMain">
			<a class="a-close" href="javascript:void(0);">×</a>
			<p>媒体类型：<input type="radio" name="mediaType" id="lpMusci" value="music" checked /><label for="lpMusci">mp3音乐</label>　<input type="radio" name="mediaType" id="lpVideo" value="video" /><label for="lpVideo">flv视频</label></p>
			<p>媒体地址：<input type="text" name="mediaUrl" id="mediaUrl" /></p>
			<p>播放器　宽：<input type="text" name="mediaW" id="mediaW" value="300" /> px　高：<input type="text" name="mediaH" id="mediaH" value="30" /> px</p>
			<p>自动播放：<input type="radio" name="medisAuto" id="apY" value="1" /><label for="apY">是</label>　<input type="radio" name="medisAuto" id="apN" value="0" checked /><label for="apN">否</label></p>
			<p class="last"><span id="mediaTips"></span><a href="javascript:void(0);" class="a-sub" id="insertSub">确定</a></p>
		</div>
	</span>
	<script>
		$(function(){
			var insertBtn = $("#insertMedia");
			var insertMain = $("#insertMain");
			var insertSub = $("#insertSub");
			var closeBtn = $(".a-close");
			var mediaTips = $("#mediaTips");
			insertBtn.click(function(){
				if(insertMain.css("display")=="block"){
					insertMain.fadeOut("fast");
				}else{
					insertMain.fadeIn("fast");
				}
			});
			
			insertSub.click(function(){
				var mediaType = $('input:radio[name="mediaType"]:checked').val();
				var mediaUrl = $("#mediaUrl").val();
				var mediaW = $("#mediaW").val();
				var mediaH = $("#mediaH").val();
				var medisAuto = $('input:radio[name="medisAuto"]:checked').val();
				
				if(mediaUrl.length < 1){
					mediaTips.text("地址不能为空");
				}else if(mediaW.length < 1 || mediaH.length < 1){
					mediaTips.text("宽高不能为空");
				}else if(isNaN(mediaW) || isNaN(mediaH)){
					mediaTips.text("宽高须为数字");
				}else{
					mediaTips.text("");
					insertMain.fadeOut("fast");
					editor("["+mediaType+" url="+mediaUrl+" w="+mediaW+" h="+mediaH+" auto="+medisAuto+"]");
				}
			});
			
			$('input:radio[name="mediaType"]').change(function(){
				if($(this).val()=="music"){
					$("#mediaW").val("300");
					$("#mediaH").val("30");
				}else{
					$("#mediaW").val("600");
					$("#mediaH").val("400");
				}
			});
			
			closeBtn.click(function(){
				insertMain.fadeOut("fast");
			});
			
			function editor(c) {
				if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
					layedit.setContent(contentLayUIEditor,layedit.getContent(contentLayUIEditor)+c,false);
				}else{
					var editorContent = $(".ke-edit-iframe").contents().find(".ke-content");
					var newContent = editorContent.html()+c;
					editorContent.html(newContent);
				}
			}
		});
	</script>
	<?php
}
addAction('index_footer','allPalyer');
addAction('adm_writelog_head', 'insertPlayer');