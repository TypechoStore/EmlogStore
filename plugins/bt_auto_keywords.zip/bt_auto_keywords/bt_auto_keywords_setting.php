<?php
/**
 * kl_auto_excerpt_setting.php
 * design by KLLER
 */
!defined('EMLOG_ROOT') && exit('access deined!');

function plugin_setting_view()
{
	include(EMLOG_ROOT.'/content/plugins/bt_auto_keywords/bt_auto_keywords_config.php');
?>
<script type="text/javascript">
<?php if(Option::EMLOG_VERSION>="6.1.1"){?>
$("#bt_auto_keywords").addClass('layui-this');
$("#bt_auto_keywords").parent().parent().addClass('layui-nav-itemed');
<?php }else if(Option::EMLOG_VERSION=="6.0.0"){?>
$("#bt_auto_keywords a").addClass('active');
<?php }else if(Option::EMLOG_VERSION=="6.0.1"){?>
$("#bt_auto_keywords").addClass('active');
<?php }else if(Option::EMLOG_VERSION=="5.3.1"){?>
$("#bt_auto_keywords").addClass('sidebarsubmenu1');
<?php }?>
function myKeyDown(e){
	if(window.event){//IE
		var k = e.keyCode;
		if ((k == 13)||(k == 9) || (k == 35) || (k == 36) || (k == 8) || (k == 46) || (k >= 48 && k <=57 )||( k >= 96 && k <= 105)||(k >= 37 && k <= 40)){
		}else{
			window.event.returnValue = false;
		}
	}else{//火狐
		var k = e.which;
		if ((k == 13)||(k == 9) || (k == 35) || (k == 36) || (k == 8) || (k == 46) || ( k>= 48 && k <= 57)||(k >= 96 && k <= 105)||(k >= 37 && k <= 40)){
		}else{
			e.preventDefault();
		}
	}
}
setTimeout(hideActived,2600);
</script>
<div class=containertitle><b>关键字提取</b><?php if(isset($_GET['setting'])):?><span class="actived">操作成功</span><?php endif;?></div>
<div class=line></div>
<form action="./plugin.php?plugin=bt_auto_keywords&action=setting" method="POST">
<div>设置关键字提取的数量：<input type="text" name="strlength" size="4" maxlength="4" value="<?php echo BT_AUTO_KEYWORDS_LENGTH; ?>" style="ime-mode:disabled;" onkeydown="myKeyDown(event);" /></div>
<div>文章中单个关键字链接数：<input type="text" name="limit" size="4" maxlength="4" value="<?php echo BT_AUTO_KEYWORDS_LIMIT; ?>" style="ime-mode:disabled;" onkeydown="myKeyDown(event);" />(-1表示不限制)</div>
<div>是否使用本地标签库：<input type="checkbox" name="local" <?php echo BT_AUTO_KEYWORDS_LOCAL ? "checked='checked'" : ''?>/>(将会从你已有标签中过滤。)</div>
<input type="submit" value="提 交" />
</form>
<?php
}
function plugin_setting()
{
	$fso = fopen(EMLOG_ROOT.'/content/plugins/bt_auto_keywords/bt_auto_keywords_config.php','r');
	$config = fread($fso,filesize(EMLOG_ROOT.'/content/plugins/bt_auto_keywords/bt_auto_keywords_config.php'));
	fclose($fso);
	$strlength = intval($_POST['strlength']);
	$limit = intval($_POST['limit']) == 0 ? -1 :  intval($_POST['limit']);
	$local = $_POST['local'] == 'on' ? 'TRUE' : 'FALSE';
	
	$pattern = array("/define\('BT_AUTO_KEYWORDS_LENGTH',(.*)\)/","/define\('BT_AUTO_KEYWORDS_LIMIT',(.*)\)/","/define\('BT_AUTO_KEYWORDS_LOCAL',(.*)\)/");
	$replace = array("define('BT_AUTO_KEYWORDS_LENGTH','".$strlength."')","define('BT_AUTO_KEYWORDS_LIMIT',".$limit.")","define('BT_AUTO_KEYWORDS_LOCAL',".$local.")");
	$new_config = preg_replace($pattern, $replace, $config);
	$fso = fopen(EMLOG_ROOT.'/content/plugins/bt_auto_keywords/bt_auto_keywords_config.php','w');
	fwrite($fso,$new_config);
	fclose($fso);
}
?>