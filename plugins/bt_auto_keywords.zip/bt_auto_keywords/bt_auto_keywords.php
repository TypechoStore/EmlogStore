﻿<?php
/*
Plugin Name: 关键字提取
Version: 2.4
Plugin URL: https://www.zjimmi.com/3033.html
Description: 自动提前文章关键词，并且对关键字加链接(摘要除外。2.4修复了关键词带/ 会导致文章内容被清空的bug
Author: GodSon
ForEmlog: 6.1.1
Author Email: wmails@126.com
Author URL: https://www.zjimmi.com
*/

!defined('EMLOG_ROOT') && exit('access deined!');
include(EMLOG_ROOT.'/content/plugins/bt_auto_keywords/bt_auto_keywords_config.php');

function bt_auto_keywords()
{
	echo '<div class="sidebarsubmenu layui-nav-item" id="bt_auto_keywords"><a href="./plugin.php?plugin=bt_auto_keywords" class="waves-effect">关键字提取</a></div>';
}
addAction('adm_sidebar_ext', 'bt_auto_keywords');

function bt_auto_keywords_do($blogid)
{
	global $logData, $Tag_Model,$tagstring,$ishide, $action;

    if('y' == $ishide) {//忽略写日志时自动保存
        return false;
    }
    if('edit' == $action) {//忽略编辑日志
        return false;
    }
	
    if('autosave' == $action && 'n' == $ishide) {//忽略编辑日志时移步保存
        return false;
    }
	
	if(!isset($_POST['bt_auto_extract_keywords_option'])){
		$bt_auto_newKeys = !empty($tagstring) ? explode(',', $tagstring) : array();
		if(!empty($bt_auto_newKeys)){
		bt_auto_addAtag($bt_auto_newKeys,$logData,$blogid);
		}
		return false;
	}
	
	if(BT_AUTO_KEYWORDS_LOCAL){
		$bt_auto_keywords = bt_auto_extract_localTag_keywords($logData['content'], BT_AUTO_KEYWORDS_LENGTH);
	}else{
		$bt_auto_keywords = bt_auto_extract_keywords($logData['content'], BT_AUTO_KEYWORDS_LENGTH);
	}
	
	if(count($bt_auto_keywords)>0){
		$Tag_Model->addTag(join(",",$bt_auto_keywords),$blogid);
		$bt_auto_newKeys = array_merge($bt_auto_keywords,!empty($tagstring) ? explode(',', $tagstring) : array());
		bt_auto_addAtag($bt_auto_newKeys,$logData,$blogid);
	}
}
addAction('save_log', 'bt_auto_keywords_do');

function bt_auto_addAtag($bt_auto_Keys,$logData, $blogid){
	global $Log_Model,$CACHE;
	foreach($bt_auto_Keys as $v){
	    $v = preg_replace('/\//','\\\/',$v);
		if(!preg_match('/<a[^>]*>[^<]*'.$v.'[^<]*<\/a>/',$logData['content']) && !preg_match('/<pre[^>]*>[^<]*'.$v.'[^<]*<\/pre>/',$logData['content'])){
			$viewtag = preg_replace('/\\\/','',$v);
			$logData['content'] = preg_replace('/'.$v.'/u','<a href="'.Url::tag(urlencode($viewtag)).'">'.$viewtag.'</a>',$logData['content'],BT_AUTO_KEYWORDS_LIMIT);
		}
	}
	if(!empty($logData['content'])){
		$Log_Model->updateLog($logData, $blogid);
		$CACHE->updateCache('logtags');
	}
}

function bt_auto_extract_keywords($bt_auto_content,$bt_auto_len=5){
	$bt_auto_url = "#";
	$bt_auto_post_data = array (
		"text" => $bt_auto_content,
		"c" => $bt_auto_len
	);
	$bt_auto_ch = curl_init();
	curl_setopt($bt_auto_ch, CURLOPT_URL, $bt_auto_url);
	curl_setopt($bt_auto_ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($bt_auto_ch, CURLOPT_POST, 1);
	curl_setopt($bt_auto_ch, CURLOPT_POSTFIELDS, $bt_auto_post_data);
	$bt_auto_output = curl_exec($bt_auto_ch);
	curl_close($bt_auto_ch);
	return !empty($bt_auto_output) ? explode(',', $bt_auto_output) : array();
}

function bt_auto_extract_localTag_keywords($bt_auto_content,$bt_auto_len=5){
	//查询所有tag遍历
	$DB = Database::getInstance();
	$bt_auto_tag= $DB->query("SELECT * FROM  ".DB_PREFIX."tag");
	$bt_auto_ref = array();
	$bt_auto_i = 0;
	$bt_auto_content = preg_replace("/&[a-z]+\;/i",'',strip_tags($bt_auto_content));
	while($tmp = $DB->fetch_array($bt_auto_tag)){
		if(strstr($bt_auto_content,$tmp['tagname'])){
		$bt_auto_ref[$bt_auto_i] = $tmp['tagname'];
		$bt_auto_i++;}
		if($bt_auto_i == intval($bt_auto_len)){
		break;}
	}	
	return $bt_auto_ref;
}

function bt_auto_extract_keywords_open(){
	echo '
		<input style="width:20px;" type="checkbox" name="bt_auto_extract_keywords_option"  checked="checked" title="启用关键字提取">
	';
	if(Option::EMLOG_VERSION>="6.1.1"){
		echo '
			<script>$(function(){
				var getKeywors = $("<button onclick=\"displayToggle(\'tagbox\', 0);\" type=\"button\" class=\"layui-btn layui-btn-primary\" ></button>").text("获取标签").css({marginLeft:10,color:"red"});
				$("#tagbox").prev().append(getKeywors);
				getKeywors.click(function(){
					var text = layedit.getContent(contentLayUIEditor);
					$.ajax({
						url:"'.BLOG_URL.'content/plugins/bt_auto_keywords/bt_auto_keywords_ajax.php",
						data:{text:text,c:'.BT_AUTO_KEYWORDS_LENGTH.'},
						type:"POST",
						success:function(resp){
						  $("#tag").val(resp).focus();
						  $("input[name=\'bt_auto_extract_keywords_option\']").attr("checked",false);
						}
					});
				});
			});
			</script>
		';
	}else{
		echo '
			<script>$(function(){
				var getKeywors = $("<a/>").text("获取标签").css({marginLeft:10,color:"red"});
				$("#tagbox").prev().append(getKeywors);
				getKeywors.click(function(){
					var text = KE.text("content");
					$.ajax({
						url:"'.BLOG_URL.'content/plugins/bt_auto_keywords/bt_auto_keywords_ajax.php",
						data:{text:text,c:'.BT_AUTO_KEYWORDS_LENGTH.'},
						type:"POST",
						success:function(resp){
						  $("#tag").val(resp).focus();
						  $("input[name=\'bt_auto_extract_keywords_option\']").attr("checked",false);
						}
					});
				});
			});
			</script>
		';
	}
}
addAction('adm_writelog_head', 'bt_auto_extract_keywords_open');
?>