﻿<?php
    $bt_auto_content = $_POST['text'];
	$bt_auto_len = $_POST['c'];
	
	$bt_auto_url = "#";
	$bt_auto_post_data = array (
		"text" => $bt_auto_content,
		"c" => $bt_auto_len
	);
	$bt_auto_ch = curl_init();
	curl_setopt($bt_auto_ch, CURLOPT_URL, $bt_auto_url);
	curl_setopt($bt_auto_ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($bt_auto_ch, CURLOPT_POST, 1);
	curl_setopt($bt_auto_ch, CURLOPT_POSTFIELDS, $bt_auto_post_data);
	$bt_auto_output = curl_exec($bt_auto_ch);
	curl_close($bt_auto_ch);
	if(!empty($bt_auto_output)){
		echo $bt_auto_output;
	}
?>