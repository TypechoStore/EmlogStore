<?php
		$url ="";
		$bucket ="";
		$apikey ="";
		$operator ="";
		$opasswd ="";
		$picwidth ="580px";
		$sdir ="/emlog/";
		$format ="time";
		?>
		