<?php
$config = array(
    "tel" => "我是固定电话",
	"phone" => "我是联系手机",
	"dianhua" => "我是400电话",
	"QQ1" => "我是QQ号码1",
	"QQ2" => "我是QQ号码2",
	"QQ3" => "我是QQ号码3",
	"off" => "no",
);