<?php
/*
Plugin Name: 在线客服
Version: 1.0
Plugin URL: http://www.shuyong.net/
Description:给博客加入悬浮客服！
ForEmlog:5.3.x
Author: 舍力
Author URL: http://www.shuyong.net/
*/

!defined('EMLOG_ROOT') && exit('access deined!');
function sl_kf(){require_once 'sl_kf_config.php';if($config["tel"] || $config["phone"] || $config["dianhua"] || $config["QQ1"] || $config["QQ2"] || $config["QQ3"]){if($config["off"] == 'yes'){?><script src="<?php echo BLOG_URL;?>/include/lib/js/jquery/jquery-1.7.1.js" type="text/javascript"></script><?php }?>
<link href="<?php echo BLOG_URL;?>content/plugins/sl_kf/sl_kf.css" rel="stylesheet" type="text/css" /><script>$(function(){$(".sl_conct").hover(function(){$(".sl_conct").css("right", "5px");},function(){$(".sl_conct").css("right", "-127px");});});</script><div class="sl_conct"><ul><?php if($config["tel"]){?><li class="sl_phone"><?php echo $config["tel"];?></li><?php }?>
<?php if($config["phone"]){?><li class="sl_phone"><?php echo $config["phone"];?></li><?php }?>
<?php if($config["dianhua"]){?><li class="sl_phone"><?php echo $config["dianhua"];?></li><?php }?>
<?php if($config["QQ1"]){?><li class="sl_QQ"><a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $config["QQ1"];?>&site=qq&menu=yes" ><?php echo $config["QQ1"];?></a></li><?php }?>
<?php if($config["QQ2"]){?><li class="sl_QQ"><a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $config["QQ2"];?>&site=qq&menu=yes" ><?php echo $config["QQ2"];?></a></li><?php }?>
<?php if($config["QQ3"]){?><li class="sl_QQ"><a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $config["QQ3"];?>&site=qq&menu=yes" ><?php echo $config["QQ3"];?></a></li><?php }?></ul></div>
<?php }}?>


<?php 
function sl_kf_menu(){
	echo '<div class="sidebarsubmenu"><a href="./plugin.php?plugin=sl_kf">在线客服</a></div>';
}?>

<?php 
addAction('index_footer','sl_kf');
addAction('adm_sidebar_ext', 'sl_kf_menu');
?>
