<?php
!defined('EMLOG_ROOT') && exit('出错了！！！!');

function plugin_setting_view(){
require_once 'sl_kf_config.php';
?>
<div class="sl_kf">
<span style=" font-size:18px; font-weight:bold;">配置文件</span><?php if(isset($_GET['setting'])){echo "<span class='actived'>设置保存成功!</span>";}?><br />
<br />
<link href="<?php echo BLOG_URL;?>content/plugins/sl_kf/sl_kf.css" rel="stylesheet" type="text/css" />
<form action="plugin.php?plugin=sl_kf&action=setting" method="post">
<ul>
<li><h4>是否加载jQuery</h4>
<div class="radio"><input type="radio" name="off" value="yes"<?php if($config["off"] == 'yes'){echo ' checked="checked"';}?> /><label>加载</label></div>
<div class="radio"><input type="radio" name="off" value="no"<?php if($config["off"]=='no'){echo ' checked="checked"';}?> /><label>不加载</label></div>
<p>如果模板或其他插件已经加载过jQuery，必须选择不加载，否则出错</p></li>

<li><h4>固定电话</h4>
<div class="one"><input type="text" class="txt" name="tel" value="<?php echo $config["tel"];?>" size="33"/></div>
<p>填写固定电话，仅限一个；不填则不显示</p></li>

<li><h4>联系手机</h4>
<div class="one"><input type="text" class="txt" name="phone" value="<?php echo $config["phone"];?>" size="33"/></div>
<p>填写手机号码，仅限一个；不填则不显示</p></li>

<li><h4>400电话</h4>
<div class="one"><input type="text" class="txt" name="dianhua" value="<?php echo $config["dianhua"];?>" size="33"/></div>
<p>填写手机号码，仅限一个；不填则不显示</p></li>

<li><h4>QQ号码1</h4>
<div class="one"><input type="text" class="txt" name="QQ1" value="<?php echo $config["QQ1"];?>" size="33"/></div>
<p>填写QQ号码，仅限一个；不填则不显示</p></li>

<li><h4>QQ号码2</h4>
<div class="one"><input type="text" class="txt" name="QQ2" value="<?php echo $config["QQ2"];?>" size="33"/></div>
<p>填写QQ号码，仅限一个；不填则不显示</p></li>

<li><h4>QQ号码3</h4>
<div class="one"><input type="text" class="txt" name="QQ3" value="<?php echo $config["QQ3"];?>" size="33"/></div>
<p>填写QQ号码，仅限一个；不填则不显示</p></li>

<div class="sl">注意事项：<br />
1、模板必须含有挂载点(没有请自行加上)：&lt;?php doAction('index_footer');?&gt;<br />
查看当前插件挂载点及说明：<a href="http://wiki.emlog.net/doku.php?id=plugindev" target="_blank">wiki.emlog.net/doku.php?id=plugindev</a><br /><br />
2、默认什么也不显示，随便填写一项才会显示；
</div>
</ul>
<input type="submit" class="button" name="submit" value="保存设置" />
</form></div>
<?php }?>
<?php 
function plugin_setting(){
	require_once 'sl_kf_config.php';
	$tel = $_POST["tel"]==""?"":$_POST["tel"];
	$phone = $_POST["phone"]==""?"":$_POST["phone"];
	$dianhua = $_POST["dianhua"]==""?"":$_POST["dianhua"];
	$QQ1 = $_POST["QQ1"]==""?"":$_POST["QQ1"];
	$QQ2 = $_POST["QQ2"]==""?"":$_POST["QQ2"];
	$QQ3 = $_POST["QQ3"]==""?"":$_POST["QQ3"];
	$off = $_POST["off"]==""?"no":$_POST["off"];
	$newConfig = '<?php
$config = array(
    "tel" => "'.$tel.'",
	"phone" => "'.$phone.'",
	"dianhua" => "'.$dianhua.'",
	"QQ1" => "'.$QQ1.'",
	"QQ2" => "'.$QQ2.'",
	"QQ3" => "'.$QQ3.'",
	"off" => "'.$off.'",
);';
	echo $newConfig;
	@file_put_contents(EMLOG_ROOT.'/content/plugins/sl_kf/sl_kf_config.php', $newConfig);
}
?>