<?php
/*
Plugin Name: tod_wap
Version: 1.0
Plugin URL:http://aisheji.org
Description: 判断手机浏览器并自动跳转到wap模板
Author: Tod
Author Email: i@tod.cc
Author URL: http://aisheji.org
*/
!defined('EMLOG_ROOT') && exit('access deined!');

function tod_wap() {
?>
<?php 
$acceptHeader = $_SERVER['HTTP_USER_AGENT'];
		if(strpos(strtoupper($_SERVER['HTTP_ACCEPT']), "VND.WAP.WML") || strpos($acceptHeader,"NetFront") || strpos($acceptHeader,"iPhone") || strpos($acceptHeader,"MIDP-2.0") || strpos($acceptHeader,"Opera Mini") || strpos($acceptHeader,"UCWEB") || strpos($acceptHeader,"Android") || strpos($acceptHeader,"Windows CE") || strpos($acceptHeader,"SymbianOS"))
		{
			$wap_url = BLOG_URL.'m';
			header("location: $wap_url");
		}
?>
<?php
}
addAction('index_head', 'tod_wap');