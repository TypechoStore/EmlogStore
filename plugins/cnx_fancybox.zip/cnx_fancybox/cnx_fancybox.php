<?php
/*
Plugin Name: fancybox看图特效灯箱插件
Version: 1.0
Plugin URL: https://www.cnx0.com/
Description: 给博客中的图片添加fancybox效果，需要注意：插入的图片需要用a超链接标签包含，并跳转到图片地址，才能出现灯箱效果。
Author: 潮男心
Author Email: cnxblog@qq.com
Author URL: https://www.cnx0.com
*/
!defined('EMLOG_ROOT') && exit('access deined!');
emLoadJQuery();
function cnx_fancybox(){

	
	if(isset($_GET['plugin']) && $_GET['plugin'] == 'kl_album') return;

	$path = '';
	if(isset($_SERVER['REQUEST_URI']))
	{
		$path = $_SERVER['REQUEST_URI'];
	}else{
		if(isset($_SERVER['argv']))
		{
			$path = $_SERVER['PHP_SELF'].'?'.$_SERVER['argv'][0];
		}else{
			$path = $_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
		}
	}
	//for ie6 header location
	$r = explode('#', $path, 2);
	$path = $r[0];
	//for iis6
	$path = str_replace('index.php', '', $path);
	//for subdirectory
	$t = parse_url(BLOG_URL);
	$path = str_replace($t['path'], '/', $path);
	if($path == '/t/') return;

	$data = ob_get_contents();
	$dataArr = array();
	
	$search_pattern = "%<a([^>]*?)href=\"[^\"]*?(jpg|gif|png|jpeg|bmp|webp)\"([^>]*?)>.*?</a>%s";
	preg_match_all($search_pattern, $data, $dataArr, PREG_PATTERN_ORDER);
	if(empty($dataArr[0])) return;

	$data = ob_get_contents();
	ob_get_clean();
	$data = preg_replace("%<a([^>]*?)href=\"[^\"]*?(jpg|gif|png|jpeg|bmp|webp)\"%s","$0 data-fancybox=\"images\" ",$data);
echo $data.'
	<link href="'.BLOG_URL.'content/plugins/cnx_fancybox/fancybox.css" rel="stylesheet" type="text/css" />
	<script src="'.BLOG_URL.'content/plugins/cnx_fancybox/fancybox.js"></script>
	<script type="text/javascript">$(document).ready(function() {$(".fancybox").fancybox();});</script>'."\r\n";
}
addAction('index_footer', 'cnx_fancybox');
