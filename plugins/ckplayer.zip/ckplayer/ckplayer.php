<?php
/*
Plugin Name:简单ckplayer播放器
Version: 1.0
Plugin URL: https://www.isiyuan.net/emckplay.html
Description:ckplayer多功能播放器支持自定义右键以及自定义logo等等，需要高度定制请联系我吧
ForEmlog:5.3.x
Author: 思源资源博客&二呆
Author URL: http://www.isiyuan.net
程序十分简单，但是也是作者的劳动成果，留个版权吧~
*/
!defined('EMLOG_ROOT') && exit('access deined!');
function ckplayer(){
?>
<script>
  $(document).ready(function(){
    $(".ckplayer_insert").click(function(){
      /*
	  $($(".ke-edit-iframe:first").contents().find(".ke-content")).append('<iframe width="'+$('#videowidth').val()+'" height="'+$('#videoheight').val()+'" allowtransparency="true" frameborder="0" scrolling="no" src="<?php echo BLOG_URL;?>content/plugins/ckplayer/?url='+$('#videourl').val()+'"></iframe>');
	  */
	  if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
		layedit.setContent(contentLayUIEditor,layedit.getContent(contentLayUIEditor)+'<p><iframe width="'+$('#videowidth').val()+'" height="'+$('#videoheight').val()+'" allowtransparency="true" frameborder="0" scrolling="no" src="<?php echo BLOG_URL;?>content/plugins/ckplayer/?url='+$('#videourl').val()+'"></iframe></p>',false);
	  }
    }); 
    $("#ckplayer_button").click(function(){
      $("#ckplayer_button").hide();
      $("#ckplayer_buttons").show();
      $("#ckplayer_text").show();});
    $("#ckplayer_buttons").click(function(){
      $("#ckplayer_buttons").hide();
      $("#ckplayer_button").show();
      $("#ckplayer_text").hide();}); 

  });
</script>
<style>
  #ckplayer_box{font-weight:bold;font-size:12px;margin:5px 0; cursor:pointer;}
  #ckplayer_box #ckplayer_button{width:100px;height:auto;border: 0;padding: 3px 3px;font-size: 12px;margin: 3px 3px 3px 0;color: #fff;background-color: #20A2DE;cursor:pointer;text-align:center;}
  #ckplayer_box #ckplayer_button:hover{background-color:#ff9000;}
  #ckplayer_box #ckplayer_buttons{width:100px;height:auto;border: 0;padding: 3px 3px;font-size: 12px;margin: 3px 3px 3px 0;color: #fff;background-color: #20A2DE;cursor:pointer;text-align:center;}
  #ckplayer_box #ckplayer_buttons:hover{background-color:#ff9000;}
  #ckplayer_text{font-weight:normal;margin:5px 0 10px 0;display:none;border: 1px solid #ccc;padding: 10px;width:500px;float:left;}
  #ckplayer_text p{margin:0 0 10px 0;font-size:14px;}
  #ckplayer_text input[type="text"]{font-size:12px; outline:none}
  #ckplayer_text span{cursor:pointer;padding:3px 3px;float:left;font-size: 14px;margin: 0 10px 0 0;background: #6F8EC5;color:#fff;font-weight:bold;}
  #ckplayer_text span:hover{background:#00aff0 !important;color:#fff !important;}
  #videowidth,#videoheight{width:55px !important;}
</style>
<div id="ckplayer_box">
  <div id="ckplayer_button" title="打开视频插入界面">ckplayer</div>
  <div id="ckplayer_buttons" title="关闭视频插入界面" style="display:none;">ckplayer</div> 
  <div id="ckplayer_text">
    <p>视频地址①:<input type="text" name="videourl" id="videourl" placeholder="填写需要插入的视频地址" /></p>
    <p>设置宽度：<input type="text" name="videowidth" id="videowidth" placeholder="650" value="650"/></p>
    <p>设置高度：<input type="text" name="videoheight" id="videoheight" placeholder="400" value="400"/></p>
    <p style="margin:10px 0 10px 0px;"><span class="ckplayer_insert">插入视频代码</span></p></div>
</div><div style="clear:both"></div>
<?php
}
addAction('adm_writelog_head', 'ckplayer');