<?php
/*
 Plugin Name: 蓝叶背景图插件
 Version: 1.0
 Plugin URL: http://lanyes.org
 Description: 设置一张好看的壁纸图片，来装饰网站的背景。’。
 ForEmlog:5.3.x
 Author: 蓝叶
 Author Email: w@lanyes.org
 Author URL: http://lanyes.org
*/
!defined('EMLOG_ROOT') && exit('access deined!');
function lanye_imgbg_menu(){
 echo '<div class="sidebarsubmenu" id="lanye_imgbg_menu"><a href="./plugin.php?plugin=lanye_imgbg">背景设置</a></div>';}
addAction('adm_sidebar_ext', 'lanye_imgbg_menu');
function lanye_imgbg_echo(){
 require_once 'lanye_imgbg_config.php';
 if($config["imgbg_type"]=="2"){$bgimgurl=BLOG_URL.'?plugin=lanye_imgbg&type=rand';}elseif($config["imgbg_type"]=="3"){$bgimgurl=BLOG_URL.'?plugin=lanye_imgbg&type=bing';}else{$bgimgurl=BLOG_URL.substr($config["imgbg_one"],3,strlen($config["imgbg_one"]));};
 echo '<div id="lanye_imgbg" style="left:0;top:0;position:absolute;width:100%;height:100%;z-index:-9999;"><img src="'.$bgimgurl.'" height="100%" width="100%" style="position:fixed;top:0;left:0;"></div>';
}
addAction('index_footer', 'lanye_imgbg_echo');