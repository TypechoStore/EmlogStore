<?php
!defined('EMLOG_ROOT') && exit('access deined!');
error_reporting(0);
global $CACHE;
$options_cache = $CACHE->readCache('options');
$type = isset($_GET['type']) ? addslashes(trim($_GET['type'])) : '';
if($type==''){
echo '404 error'; 
}
if($type=='bing'){
$path=EMLOG_ROOT.'/content/plugins/lanye_imgbg/images';
@chmod($attachpath, 0777);
$pathurl = $path.'/'.date('Ymd').'.jpg';
if(!is_file($pathurl)){
$str=file_get_contents('http://cn.bing.com/HPImageArchive.aspx?idx=0&n=1');
 if(preg_match("/<urlBase>(.+?)<\/urlBase>/ies",$str,$matches)){
  $imgurl='http://s.cn.bing.com'.$matches[1].'_1920x1080.jpg';
  copy($imgurl,$pathurl);
 }
}
 header('Content-Type: image/JPEG');
  @ob_end_clean();
  @readfile($pathurl);
  @flush(); @ob_flush();
exit(); 
}
if($type=='rand'){
$img_array = glob(EMLOG_ROOT."/content/plugins/lanye_imgbg/images/*.{gif,jpg,png,jpeg}",GLOB_BRACE); 
$img = array_rand($img_array);
header('Content-Type: image/JPEG');
  @ob_end_clean();
  @readfile($img_array[$img]);
  @flush(); @ob_flush();
exit(); 
}