<?php
!defined('EMLOG_ROOT') && exit('access deined!');
function lanye_imgFile($fileName, $errorNum, $tmpFile, $fileSize, $type, $isIcon = false) {
	$result = lanye_imgUp($fileName, $errorNum, $tmpFile, $fileSize, $type, $isIcon);
	switch ($result) {
		case '100':
			emMsg('文件大小超过系统' . ini_get('upload_max_filesize') . '限制');
			break;
		case '101':
			emMsg('上传文件失败,错误码：' . $errorNum);
			break;
		case '102':
			emMsg('错误的文件类型');
			break;
		case '103':
			$ret = changeFileSize(Option::getAttMaxSize());
			emMsg("文件大小超出{$ret}的限制");
			break;
		case '104':
			emMsg('创建文件上传目录失败');
			break;
		case '105':
			emMsg('上传失败。文件上传目录(content/plugins/lanye_imgbg/images/)不可写');
			break;
		default:
			return $result;
			break;
	}
}
function lanye_imgUp($fileName, $errorNum, $tmpFile, $fileSize, $type, $isIcon = false) {
	if ($errorNum == 1) {
		return '100'; //文件大小超过系统限制
	} elseif ($errorNum > 1) {
		return '101'; //上传文件失败
	}
	$extension = getFileSuffix($fileName);
	if (!in_array($extension, $type)) {
		return '102'; //错误的文件类型
	}
	if ($fileSize > Option::getAttMaxSize()) {
		return '103'; //文件大小超出emlog的限制
	}
	$file_info = array();
	$file_info['file_name'] = $fileName;
	$file_info['mime_type'] = get_mimetype($extension);
	$file_info['size'] = $fileSize;
	$file_info['width'] = 0;
	$file_info['height'] = 0;
	$uppath = '../content/plugins/lanye_imgbg/images/';
	$fname = substr(md5($fileName), 0, 4) . time() . '.' . $extension;
	$attachpath = $uppath . $fname;
	$file_info['file_path'] = $attachpath;
	if (!is_dir($uppath)) {
		@umask(0);
		$ret = @mkdir($uppath, 0777);
		if ($ret === false) {
			return '104'; //创建文件上传目录失败
		}
	}
	if (!is_dir($uppath)) {
		@umask(0);
		$ret = @mkdir($uppath, 0777);
		if ($ret === false) {
			return '105'; //上传失败。文件上传目录(content/uploadfile)不可写
		}
	}

	if (@is_uploaded_file($tmpFile)) {
		if (@!move_uploaded_file($tmpFile, $attachpath)) {
			@unlink($tmpFile);
			return '105'; //上传失败。文件上传目录(content/plugins/lanye_imgbg/images/)不可写
		}
		@chmod($attachpath, 0777);
	}	
	// 如果附件是图片需要提取宽高
	if (in_array($file_info['mime_type'], array('image/jpeg', 'image/png', 'image/gif', 'image/bmp'))) {
		$size = getimagesize($file_info['file_path']);
		if ($size) {
			$file_info['width'] = $size[0];
			$file_info['height'] = $size[1];
		}
	}
	return $file_info;
}
function plugin_setting_view(){require_once 'lanye_imgbg_config.php';?>
<link href="<?php echo BLOG_URL;?>content/plugins/lanye_imgbg/admin.css" rel="stylesheet" type="text/css" />
<div class="containertitle"><b>蓝叶背景图插件设置</b><?php if(isset($_GET['setting'])):?><span class="actived">设置成功</span><?php endif;?></div>
<div class=line></div>
<div class="imgbg_tips"><p>选择图片显示模式，让你的网站显示设置的好看背景图片。</p>
<p>选择自定义单图模式，请在下方选择图片，保存设置自动上传图片。</p>
<p>选择每日必应壁纸模式，每天当打开网站时会自动下载壁纸到文件里然后调用。</p>
<p>选择自定义随机壁纸，请把喜欢的壁纸图片通过FTP或者下方大单图上传功能上传到，content/plugins/lanye_imgbg/images目录下，文件名不可以设置中文。</p>
<p>content/plugins/lanye_imgbg/images必须要有可写权限，不然图片无法上传，必应壁纸也无法下载。</p>
</div>
<form action="./plugin.php?plugin=lanye_imgbg&action=setting" method="POST" enctype="multipart/form-data">
<div class="imgbg_set_box">
 <div class="set_name">背景模式设置<div class="set_desc"></div></div>
 <div class="set_body"><select name="imgbg_type"><option value="1" <?php if($config["imgbg_type"]=="1") echo "selected"; ?>>自定义单图模式</option><option value="2" <?php if($config["imgbg_type"]=="2") echo "selected"; ?>>自定义随机壁纸</option><option value="3" <?php if($config["imgbg_type"]=="3") echo "selected"; ?>>每日必应壁纸</option></select></div>
</div>
<div class="imgbg_set_box">
  <div class="set_name">自定义单图上传：<div class="set_desc">选择你喜欢的图片，保存设置自动上传。</div></div>
 <div class="set_body">
 <img src="<?php echo $config["imgbg_one"];?>" width="150" height="150" />
<input type="hidden" name="imgbg_one" value="<?php echo $config["imgbg_one"];?>"/><br />
 <input name="imgbg_one" type="file" />
 </div>
</div>

<div class="imgbg_set_submit"><input type="submit" value="保存设置" /></div>
</form>
<?php
}
function plugin_setting(){
 $imgbg_one = isset($_POST['imgbg_one']) ? addslashes(trim($_POST['imgbg_one'])) : '';
  $imgbg_one_type = array('gif', 'jpg', 'jpeg','png');
	if ($_FILES['imgbg_one']['size'] > 0) {
		$file_info = lanye_imgFile($_FILES['imgbg_one']['name'], $_FILES['imgbg_one']['error'], $_FILES['imgbg_one']['tmp_name'], $_FILES['imgbg_one']['size'], $imgbg_one_type, false);
		if (!empty($file_info['file_path'])) {
			$imgbg_one = $file_info['file_path'];
		}
}
	$newConfig = '<?php
$config = array(
 "imgbg_type" => "'.addslashes($_POST["imgbg_type"]).'",
 "imgbg_one" => "'.$imgbg_one.'"
);';
	@file_put_contents(EMLOG_ROOT.'/content/plugins/lanye_imgbg/lanye_imgbg_config.php', $newConfig);
}
?>