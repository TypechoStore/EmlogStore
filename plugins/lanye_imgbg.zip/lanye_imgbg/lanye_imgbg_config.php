<?php
$config = array(
 "imgbg_type" => "1",
 "imgbg_one" => "../content/plugins/lanye_imgbg/images/515c1470460361.jpg"
);