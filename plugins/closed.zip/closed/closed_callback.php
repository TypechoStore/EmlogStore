<?php

defined('EMLOG_ROOT') or die('access deined!');
function callback_init() {
}

function callback_rm() {
}
