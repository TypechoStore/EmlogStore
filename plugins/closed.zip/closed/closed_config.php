<?php
define('CLOSED_YN','N'); //博客状态
define('MCLOSED_YN','Y'); //手机版状态
define('CLOSED_BE','博客维护中......暂停访问。'); //博客关闭原因说明
?>
