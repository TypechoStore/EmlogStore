<?php
$lianjie = '0';
$url = 'http://www.taobao.com/go/chn/tbk_channel/channelcode.php?pid=mm_15075444_2624866_10463177&eventid=101329';
$gaodu = '3510';
$soure = '淘宝购物街关闭维护中，很快就会开通，尽请留意。。。。。。。。。';
$xiangshang = '26';
?>