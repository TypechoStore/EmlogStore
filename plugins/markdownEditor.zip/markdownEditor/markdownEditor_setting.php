<?php
!defined('EMLOG_ROOT') && exit('access deined!');

function plugin_setting_view(){
	?>
	<fieldset class="layui-elem-field layui-field-title">
	  <legend>版本检测</legend>
	</fieldset>
	<span id="markdownEditorUpdateInfo"></span><script>markdownEditorXmlHttp=new XMLHttpRequest();markdownEditorXmlHttp.open("GET","https://www.tongleer.com/api/interface/markdownEditor.php?action=update&version=<?=MARKDOWNEDITOR_VERSION;?>",true);markdownEditorXmlHttp.send(null);markdownEditorXmlHttp.onreadystatechange=function () {if (markdownEditorXmlHttp.readyState ==4 && markdownEditorXmlHttp.status ==200){document.getElementById("markdownEditorUpdateInfo").innerHTML=markdownEditorXmlHttp.responseText;}}</script>
	<?php
}
?>