<?php
/*
Plugin Name: MarkdownEditorForEmlog
Version: 1.0.1
Plugin URL: https://www.tongleer.com
Description: 一款将Emlog编辑器替换为Markdown的插件，使用注意：1、若有插件需要插入编辑器操作，则需要手动用$("#markdownEditor_content").val($("#markdownEditor_content").val()+"新增内容");的方式使该插件正常使用；2、模板echo_log.php中保证输出内容部分不被代码压缩才能使Markdown正常解析；3、若模板head标签内加载过jquery导致js冲突，则可以删除markdownEditor.php中markdownEditor_footer函数加载jquery的代码。
Author: 二呆
Author Email: diamond0422@qq.com
Author URL: https://www.tongleer.com
*/
!defined('EMLOG_ROOT') && exit('access deined!');

addAction('adm_writelog_head', 'markdownEditor_html');
function markdownEditor_html() {
	require 'markdownEditor_html.php';
}

addAction('index_head', 'markdownEditor_head');
function markdownEditor_head() {
	if(Option::EMLOG_VERSION<"6.1.1"){
		echo '
			<link rel="stylesheet" href="'.BLOG_URL.'content/plugins/markdownEditor/easyeditor/layui/css/layui.css">
		';
	}
	echo '
		<link rel="stylesheet" href="'.BLOG_URL.'content/plugins/markdownEditor/easyeditor/css/easyeditor.css">
		<link rel="stylesheet" type="text/css" href="//at.alicdn.com/t/font_1531710_xb357ub1wmg.css" />
	';
}
addAction('index_footer', 'markdownEditor_footer');
function markdownEditor_footer(){
	echo '<script src="'.BLOG_URL.'content/plugins/markdownEditor/easyeditor/js/jquery-1.11.0.js"></script>';
	if(Option::EMLOG_VERSION<"6.1.1"){
		echo '
			<script src="'.BLOG_URL.'content/plugins/markdownEditor/easyeditor/layui/layui.js"></script>
		';
		$baseDir=BLOG_URL."content/plugins/markdownEditor/easyeditor/mods/";
	}else{
		$baseDir=BLOG_URL.ADMIN_DIR."/views/ui/";
	}
	echo '
		<script src="'.BLOG_URL.'content/plugins/markdownEditor/easyeditor/js/marked.min.js" type="text/javascript" charset="utf-8"></script>
		<script>
			$(function(){
				layui.config({
					base: "'.$baseDir.'"
				}).extend({
					easyeditor: "easyeditor"
				}).use(["easyeditor"], function() {
					var easyeditor = layui.easyeditor;
					easyeditor.render({
						elem:".markEditTag"
					});
				});
			});
		</script>
	';
}
function markdownEditor_Related($logData){
	$db = Database::getInstance();
	$data=ob_get_clean();
	$rowBlog = $db->fetch_array($db->query("SELECT * FROM ".DB_PREFIX."blog WHERE gid ='".$logData["logid"]."'"));
	$rowMarkdown = $db->once_fetch_array("SELECT * FROM ".DB_PREFIX."markdown WHERE logid ='".$logData["logid"]."'");
	$data=str_replace($rowBlog['content'],'<div class="markEditTag">'.$rowMarkdown["content"].'</div>',$data);
	ob_start();
	echo $data;
}
addAction("log_related","markdownEditor_Related");
/**
 * 添加
 * @param array $logData
 * @return int
 */
function markdownEditor_add($logData) {
    $db = Database::getInstance();
    $kItem = array();
    $dItem = array();
    foreach ($logData as $key => $data) {
        $kItem[] = $key;
        $dItem[] = $data;
    }
    $field = implode(',', $kItem);
    $values = "'" . implode("','", $dItem) . "'";
    $db->query("INSERT INTO " . DB_PREFIX . "markdown ($field) VALUES ($values)");
    $logid = $db->insert_id();
    return $logid;
}
/**
 * 更新
 * @param array $logData
 * @param int $blogId
 */
function markdownEditor_update($logData, $blogId) {
    $db = Database::getInstance();
    $Item = array();
    foreach ($logData as $key => $data) {
        $Item[] = "$key='$data'";
    }
    $upStr = implode(',', $Item);
    $db->query("UPDATE " . DB_PREFIX . "markdown SET $upStr WHERE logid=$blogId");
}

function markdownEditor_save_log($logid){
	$markdownEditor_content = isset($_POST['markdownEditor_content']) ? addslashes(trim($_POST['markdownEditor_content'])) : '';
	$content = isset($_POST['content']) ? addslashes(trim($_POST['content'])) : '';
	
	include(EMLOG_ROOT.'/content/plugins/markdownEditor/easyeditor/libs/parsedown.php');
	$db = Database::getInstance();
	$Parsedown = new Parsedown();
	
	$Log_Model = new Log_Model();
	$Log_Model->updateLog(array("content"=>$Parsedown->text($markdownEditor_content)), $logid);
	
    $db = Database::getInstance();
    $data = $db->query("SELECT * FROM ".DB_PREFIX."markdown WHERE logid ='$logid'");
    if($db->fetch_array($data) == ""){
        $logData = array('logid' => $logid,'content' => $markdownEditor_content);
        markdownEditor_add($logData);
    }else{
        $UplogData = array('content' => $markdownEditor_content);
        markdownEditor_update($UplogData, $logid);
    }
}
addAction('save_log', 'markdownEditor_save_log');