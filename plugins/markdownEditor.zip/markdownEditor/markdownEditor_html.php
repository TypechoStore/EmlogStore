<?php
$query = $_SERVER["QUERY_STRING"];
$logid = preg_replace('/action=edit&gid=/','',$query);
$db = Database::getInstance();
$data = $db->query("SELECT * FROM ".DB_PREFIX."markdown WHERE logid ='".@$logid."'");
$row = $db->fetch_array($data);
if($row != ""){
    $content = $row["content"];
    echo '<textarea id="markdownEditor_text" style="display:none;">'.$content.'</textarea>';
}
?>
<?php if(Option::EMLOG_VERSION<"6.1.1"){?>
<script src="<?php echo BLOG_URL; ?>content/plugins/markdownEditor/easyeditor/layui/layui.js"></script>
<link rel="stylesheet" href="<?php echo BLOG_URL; ?>content/plugins/markdownEditor/easyeditor/layui/css/layui.css">
<?php }?>
<link rel="stylesheet" href="<?php echo BLOG_URL; ?>content/plugins/markdownEditor/easyeditor/css/easyeditor.css">
<link rel="stylesheet" type="text/css" href="//at.alicdn.com/t/font_1531710_jcnwhov8w1.css" />
<script src="<?php echo BLOG_URL; ?>content/plugins/markdownEditor/easyeditor/js/marked.min.js" type="text/javascript" charset="utf-8"></script>

<textarea id="markdownEditor_content" name="markdownEditor_content" style="" required lay-verify="required" placeholder="请输入发表内容" class="layui-textarea markdownEditor"></textarea>
<script src="<?php echo BLOG_URL; ?>content/plugins/markdownEditor/easyeditor/mods/showdown.min.js"></script>
<script type="text/javascript">
	$(function(){
		if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
			layedit.setContent(contentLayUIEditor,markdownEditorToHtml($('#markdownEditor_content').val()),false);
		}else{
			$('form[name="addlog"] textarea[name="content"]').val(markdownEditorToHtml($('#markdownEditor_content').val()));
		}
		$('#markdownEditor_content').keyup(function(){
			if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
				layedit.setContent(contentLayUIEditor,markdownEditorToHtml($('#markdownEditor_content').val()),false);
			}else{
				$('form[name="addlog"] textarea[name="content"]').val(markdownEditorToHtml($('#markdownEditor_content').val()));
			}
		});
		
		var context = $('#markdownEditor_text').val()?$('#markdownEditor_text').val():$('form[name="addlog"] textarea[name="content"]').val();
		$('#markdownEditor_content').val(context);
		$('form[name="addlog"] textarea[name="content"]').parent().hide();
		$('#FrameUpload').hide();
		
		<?php if(Option::EMLOG_VERSION>="6.1.1"){?>
		var baseDir="./views/ui/";
		$(".show_advset,button").hide();
		<?php }else if(Option::EMLOG_VERSION>="6.0.0"){?>
		var baseDir="<?php echo BLOG_URL; ?>content/plugins/markdownEditor/easyeditor/mods/";
		$(".show_advset span").hide();
		<?php }else if(Option::EMLOG_VERSION>="5.3.1"){?>
		var baseDir="<?php echo BLOG_URL; ?>content/plugins/markdownEditor/easyeditor/mods/";
		$(".show_advset,span").hide();
		<?php }else{?>
		var baseDir="<?php echo BLOG_URL; ?>content/plugins/markdownEditor/easyeditor/mods/";
		<?php }?>
		
		layui.config({
			base: baseDir
		}).extend({
			easyeditor: 'easyeditor'
		}).use(['easyeditor'], function() {
			var easyeditor = layui.easyeditor;
			easyeditor.init({
				elem: '.markdownEditor' /*textarea 元素class*/
				,uploadUrl: '<?php echo TLE_SERVICE_HOST;?>api/web/?action=weiboimg&return=url' /*图片上传地址*/
				,videoUploadUrl : '<?php echo BLOG_URL; ?>content/plugins/markdownEditor/easyeditor/upload/uploadVideo.php?action=uploadVideo&logid=<?=$logid;?>'
				,videoUploadSize:'<?=Option::get('att_maxsize');?>' /*限制的上传大小 单位kb 默认 10240 kb*/
				,uploadSize: '<?=Option::get('att_maxsize');?>' /*限制的上传大小 单位kb 默认 1024k */
				,style: 'fangge' /*内置样式  目前只有default和fangge两种*/
				,codeStyle:'layuiCode' /*代码风格 layuiCode风格 与 默认风格*/
				,codeSkin:'notepad' /*代码框样式 默认不填 与notepad 该属性与codeStyle='layuiCodexw'搭配使用*/
				,buttonColor:'#009688' /*自定义按钮颜色*/
				,hoverBgColor:'#F2F2F2'  /*自定义鼠标悬浮背景颜色*/
				,hoverColor:'#000000' /*自定义鼠标悬浮按钮颜色*/
			});
			/*upload接口要求返回的数据格式：{code:0,msg:"ok",url:"http://x/x.jpg"}*/
		});
		
		function markdownEditorToHtml(content){
			var converter = new showdown.Converter();
			return converter.makeHtml(content);
		}
	});
</script>