<?php
/*
Plugin Name: 蜘蛛爬行记录
Version: 2.1
Plugin URL: http://www.youngxj.cn
Description: 为支持Emlog6.1.1(二呆)修复了使用Database类来调用数据库和增加了分页，蜘蛛爬行记录二改技术人员：<a href="http://www.youngxj.cn/">杨小杰博客</a>。
ForEmlog: 6.1.1
Author: Young小杰
Author Email: blog@youngxj.cn
Author URL: http://www.youngxj.cn
时间: 2018年6月15日
*/

!defined('EMLOG_ROOT') && exit('access deined!');

require_once('forwhat_spider_config.php');

addAction('index_footer', 'forwhat_spider_fun');

function forwhat_spider_fun(){
	dete();
	$spiders=array(
		1=>array('baidu',array('baiduspider')),
		2=>array('360',array('360spider','qihoobot')),
		3=>array('google',array('googlebot','mediapartners-google','feedfetcher-google')),
		4=>array('soso',array('sosospider')),
		5=>array('msn',array('msnbot')),
		6=>array('yodao',array('yodaobot')),
		7=>array('yahoo',array('yahoo')),
		8=>array('sogou',array('sogou')),
		9=>array('bing',array('bingbot')),
		10=>array('sohu',array('sohu')),
		11=>array('iask',array('iask')),
	);

	$agent=strtolower($_SERVER["HTTP_USER_AGENT"]);
	$ip = getIp();
	$uri = $_SERVER['REQUEST_URI'];
	$tim = date("Y-m-d H:i:s");	
	foreach ($spiders as $key => $value) {
		foreach($value[1] as $v){
			if (strpos($agent, $v) !== false) {
				$spider = $value[0];
				break;
			}
		}
		if($spider)//如果符合其中任何一个
		break;
	}
	if ($spider) {//爬行数据入库
		$spider_data = array(
			'sname' => $spider,
			'stime' => $tim,
			'surl' => $uri,
			'sip' => $ip
		);
		$db=Database::getInstance();
		$db->query("insert into " .DB_SPIDER_TABLENAME. "(sname,stime,surl,sip) VALUES ('".$spider."','".$tim."','".$uri."','".$ip."')");
	}
}

function dete(){
	$db=Database::getInstance();
  	$tim = date("Y-m-d");
	$num1 = $db->once_fetch_array("SELECT COUNT(*) AS total FROM ".DB_SPIDER_TABLENAME);
	$num2 = $num1['total'];
  	//记录蜘蛛数达到3000条删除今天以外的所有数据
  	if($num2>3000){
    	$db->query("delete from ".DB_SPIDER_TABLENAME." WHERE `stime` not LIKE  '%$tim%'");
    }
}