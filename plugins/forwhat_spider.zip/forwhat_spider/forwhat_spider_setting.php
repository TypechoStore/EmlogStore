<?php
!defined('EMLOG_ROOT') && exit('access deined!');

require_once('forwhat_spider_config.php');

function plugin_setting_view() {
	?>
<h3 style="color:red">温馨提示：记录蜘蛛数达到3000条将会清空之前的记录</h3>
<?php
$time1=date("Y-m-d");
$tongji = mysql_query("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE  `stime` LIKE  '%$time1%'");
$row1 = mysql_fetch_array($tongji);
$tj=$row1['0'];
if(!$tj){
	exit('当前数据库内没有蜘蛛记录，请模拟抓取一次即可！');
}
$result = mysql_query("SELECT * FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%'  ORDER BY `stime` DESC");
echo "<h5> $time1 总计:$tj</h5>";
$baidu0 = mysql_query("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%baidu%'");
$baidu1 = mysql_fetch_array($baidu0);
$baidu2 = $baidu1['0'];
$google0 = mysql_query("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%google%'");
$google1 = mysql_fetch_array($google0);
$google2 = $google1['0'];
$q360 = mysql_query("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%360%'");
$a360 = mysql_fetch_array($q360);
$b360 = $a360['0'];
$bing0 = mysql_query("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%bing%'");
$bing1 = mysql_fetch_array($bing0);
$bing2 = $bing1['0'];
$yahoo0 = mysql_query("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%yahoo%'");
$yahoo1 = mysql_fetch_array($yahoo0);
$yahoo2 = $yahoo1['0'];
$sogou0 = mysql_query("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%sogou%'");
$sogou1 = mysql_fetch_array($sogou0);
$sogou2 = $sogou1['0'];
$msn0 = mysql_query("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%msn%'");
$msn1 = mysql_fetch_array($msn0);
$msn2 = $msn1['0'];
$yodao0 = mysql_query("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%yodao%'");
$yodao1 = mysql_fetch_array($yodao0);
$yodao2 = $yodao1['0'];
$sohu0 = mysql_query("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%sohu%'");
$sohu1 = mysql_fetch_array($sohu0);
$sohu2 = $sohu1['0'];
$iask0 = mysql_query("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%iask%'");
$iask1 = mysql_fetch_array($iask0);
$iask2 = $iask1['0'];
$soso0 = mysql_query("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%soso%'");
$soso1 = mysql_fetch_array($soso0);
$soso2 = $soso1['0'];
?>
<table width='100%' style='table-layout:fixed' class="table">
  <thead>
  <tr>
    <th>百度</th>
    <th>好搜</th>
    <th>谷歌</th>
    <th>搜搜</th>
    <th>有道</th>
    <th>雅虎</th>
    <th>搜狗</th>
    <th>必应</th>
    <th>搜狐</th>
    <th>iask</th>
    <th>msn</th>
  </tr>
  <tr>
    <td><?php echo $baidu2;?></td>
    <td><?php echo $b360;?></td>
    <td><?php echo $google2;?></td>
    <td><?php echo $soso2;?></td>
    <td><?php echo $yodao2;?></td>
    <td><?php echo $yahoo2;?></td>
    <td><?php echo $sogou2;?></td>
    <td><?php echo $bing2;?></td>
    <td><?php echo $sohu2;?></td>
    <td><?php echo $iask2;?></td>
    <td><?php echo $msn2;?></td>
  </tr>
    </thead>
  </table>
<?php
echo "<table  width='100%' style=\"table-layout:fixed;\" class=\"table table-striped\">
<thead>
<tr>
<th>name</th>
<th>time</th>
<th>url</th>
<th>ip</th>
</tr></thead><tbody>";
while($row = mysql_fetch_array($result))
  {
  echo "<tr>";
  echo "<td >" . $row['sname'] . "</td>";
  echo "<td >" . $row['stime'] . "</td>";
  echo "<td style='word-wrap:break-word;word-break:break-all;'>".$row['surl']."</td>";
  echo "<td >" . $row['sip'] . "</td>";
  echo "</tr>";
  }
echo "<tbody></table>";
//mysql_close($con);
}
?>
