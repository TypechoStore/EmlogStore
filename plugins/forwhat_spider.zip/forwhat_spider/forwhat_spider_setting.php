<?php
!defined('EMLOG_ROOT') && exit('access deined!');

require_once('forwhat_spider_config.php');

function plugin_setting_view() {
	$db=Database::getInstance();
	?>
	<h3 style="color:red">温馨提示：记录蜘蛛数达到3000条将会清空之前的记录</h3>
	<?php
	$time1=date("Y-m-d");
	$row1 = $db->once_fetch_array("SELECT COUNT( 1 ) AS total FROM ".DB_SPIDER_TABLENAME." WHERE  `stime` LIKE  '%$time1%'");
	$tj=$row1['total'];
	if(!$tj){
		echo('<center>当前数据库内没有蜘蛛记录，请模拟抓取一次即可！</center>');
	}else{
		echo "<h5> $time1 总计:$tj</h5>";
		$baidu1 = $db->once_fetch_array("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%baidu%'");
		$baidu2 = $baidu1['total'];
		$google1 = $db->once_fetch_array("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%google%'");
		$google2 = $google1['total'];
		$a360 = $db->once_fetch_array("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%360%'");
		$b360 = $a360['total'];
		$bing1 = $db->once_fetch_array("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%bing%'");
		$bing2 = $bing1['total'];
		$yahoo1 = $db->once_fetch_array("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%yahoo%'");
		$yahoo2 = $yahoo1['total'];
		$sogou1 = $db->once_fetch_array("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%sogou%'");
		$sogou2 = $sogou1['total'];
		$msn1 = $db->once_fetch_array("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%msn%'");
		$msn2 = $msn1['total'];
		$yodao1 = $db->once_fetch_array("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%yodao%'");
		$yodao2 = $yodao1['total'];
		$sohu1 = $db->once_fetch_array("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%sohu%'");
		$sohu2 = $sohu1['total'];
		$iask1 = $db->once_fetch_array("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%iask%'");
		$iask2 = $iask1['total'];
		$soso1 = $db->once_fetch_array("SELECT COUNT( 1 ) FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%' and `sname` LIKE '%soso%'");
		$soso2 = $soso1['total'];
		?>
		<table class="layui-table" width='100%' style='table-layout:fixed' class="table">
			<thead>
				<tr>
					<th>百度</th>
					<th>好搜</th>
					<th>谷歌</th>
					<th>搜搜</th>
					<th>有道</th>
					<th>雅虎</th>
					<th>搜狗</th>
					<th>必应</th>
					<th>搜狐</th>
					<th>iask</th>
					<th>msn</th>
				</tr>
				<tr>
					<td><?php echo $baidu2;?></td>
					<td><?php echo $b360;?></td>
					<td><?php echo $google2;?></td>
					<td><?php echo $soso2;?></td>
					<td><?php echo $yodao2;?></td>
					<td><?php echo $yahoo2;?></td>
					<td><?php echo $sogou2;?></td>
					<td><?php echo $bing2;?></td>
					<td><?php echo $sohu2;?></td>
					<td><?php echo $iask2;?></td>
					<td><?php echo $msn2;?></td>
				</tr>
			</thead>
		</table>
		<?php
		$result = $db->query("SELECT * FROM ".DB_SPIDER_TABLENAME." WHERE `stime` LIKE  '%$time1%'  ORDER BY `stime` DESC");
		$spiders = array();
		while ($row = $db->fetch_array($result)) {
			$spiders[] = $row;
		}
		$page_now = isset($_GET['page_now']) ? intval($_GET['page_now']) : 1;
		if($page_now<1){
			$page_now=1;
		}
		$page_rec=50;
		$totalrec=count($spiders);
		$page=ceil($totalrec/$page_rec);
		if($page_now>$page){
			$page_now=$page;
		}
		if($page_now<=1){
			$before_page=1;
			if($page>1){
				$after_page=$page_now+1;
			}else{
				$after_page=1;
			}
		}else{
			$before_page=$page_now-1;
			if($page_now<$page){
				$after_page=$page_now+1;
			}else{
				$after_page=$page;
			}
		}
		$spiderArr = array_slice($spiders, ($page_now-1)*$page_rec, $page_rec);
		
		echo "
		<table class='layui-table' width='100%' style=\"table-layout:fixed;\" class=\"table table-striped\">
			<thead>
				<tr>
					<th>name</th>
					<th>time</th>
					<th>url</th>
					<th>ip</th>
				</tr>
			</thead>
			<tbody>
		";
		foreach($spiderArr as $value){
			echo "<tr>";
			echo "<td >" . $value['sname'] . "</td>";
			echo "<td >" . $value['stime'] . "</td>";
			echo "<td style='word-wrap:break-word;word-break:break-all;'>".$value['surl']."</td>";
			echo "<td >" . $value['sip'] . "</td>";
			echo "</tr>";
		}
		echo "
			<tbody>
		</table>
		";
		?>
		<ul>
		  <?php if($page_now!=1){?>
			<li style="float:left;"><a href="?plugin=forwhat_spider&page_now=1">首页</a></li>
		  <?php }?>
		  <?php if($page_now>1){?>
			<li style="float:left;"><a href="?plugin=forwhat_spider&page_now=<?=$before_page;?>">&laquo; 上一页</a></li>
		  <?php }?>
		  <?php if($page_now<$page){?>
			<li style="float:left;"><a id="nextpage" href="?plugin=forwhat_spider&page_now=<?=$after_page;?>">下一页 &raquo;</a></li>
		  <?php }?>
		  <?php if($page_now!=$page){?>
			<li style="float:left;"><a href="?plugin=forwhat_spider&page_now=<?=$page;?>">尾页</a></li>
		  <?php }?>
		</ul>
		<?php
	}
}
?>