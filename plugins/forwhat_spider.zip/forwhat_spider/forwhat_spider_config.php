<?php
	define('DB_SPIDER_TABLENAME',DB_PREFIX.'forwhat_spiders');
?>