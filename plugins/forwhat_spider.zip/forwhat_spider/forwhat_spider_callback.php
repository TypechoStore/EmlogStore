<?php
!defined('EMLOG_ROOT') && exit('fuck♂you');
//插件激活
function callback_init() {
	$sql ="
		create table if not exists `".DB_PREFIX."forwhat_spiders` (
		`id` int(10) unsigned NOT NULL auto_increment,
		`sname` varchar(255),
		`stime` datetime,
		`surl` varchar(255),
		`sip` varchar(255),
		UNIQUE KEY `id` (`id`),
		KEY `forwhat_spiders` (`id`)
		);
	";
	$db = Database::getInstance();
	$db->query($sql);
}
//插件禁用事件
function callback_rm(){
	/*
	$db = Database::getInstance();
	$query = $db->query("DROP TABLE IF EXISTS `".DB_PREFIX."forwhat_spiders`");
	*/
}
?>