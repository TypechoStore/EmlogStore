﻿<?php
if(!defined('EMLOG_ROOT')) {exit('error!');}
global $CACHE;$options_cache = $CACHE->readCache('options');ob_clean();require_once 'sltg.php';
if($config["admin"]==''){echo '<font color="#FF0000">注意：首次使用请点【保存设置】启用默认参数，否则插件无法正常使用</font>';exit;}
$sl = isset($_GET['sl'])?intval($_GET['sl']):0;?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="Cache-Control" content="no-transform" />
<meta http-equiv="Cache-Control" content="no-siteapp" />
<title><?php echo $config["name"];?> - <?php echo $options_cache['blogname'];?></title>
<link href="<?php echo BLOG_URL;?>content/plugins/tougao/sltg.css" rel="stylesheet" type="text/css" />
<link href="<?php echo BLOG_URL;?>content/plugins/tougao/bootstrap.min.css?ver=1.9" rel="stylesheet" type="text/css" />
<link href="<?php echo BLOG_URL;?>content/plugins/tougao/css/font-awesome.css" rel="stylesheet" type="text/css" />
<script charset="utf-8" src="<?php echo BLOG_URL;echo $config["admin"];?>/editor/kindeditor.js"></script>
</head>
<style type="text/css">
body
{
background-image:url(http://huayula.com/content/templates/fee/static/img/bg.png);

}
</style>
<body>
<?php 
$password = $config["ah"];//这里是密码 
$p = "";if(isset($_COOKIE["isview"]) and $_COOKIE["isview"] == $password){$isview = true;}else{if(isset($_POST["pwd"])){if($_POST["pwd"] == $password){setcookie("isview",$_POST["pwd"],time()+3600);$isview = true;}else{$p=(empty($_POST["pwd"])) ? "" : "<div style=\"color:#F00;\">暗号不正确，请重新输入。</div>";}}else{$isview = false;$p = "";}}?>
<?php if(!$isview && $config["tgkg"] == 'no'){?>
<style type="text/css">body{background:none;}.passport{border:1px solid red;background-color:#FFFFCC;width:400px;height:150px;position:absolute;left:49.9%;top:30%;margin-left:-200px;margin-top:-55px;font-size:14px;text-align:center;line-height:30px;color:#746A6A;}</style>
<div class="passport"><div style="padding-top:20px;">作者已关闭投稿（使用暗号可正常投稿）
<form action="" method="post" style="margin:0px;">暗号 
<input type="password" name="pwd" /> <input type="submit" value="去投稿" /> 
</form> 
<?php echo $p;?> 
</div></div></body></html><?php exit;}?> 
<?php if($sl==0){$Sort_Model = new Sort_Model();$sorts = $Sort_Model->getSorts();?>
<div class="sltgq"><div class="sltgbt"><p><?php echo $config["name"];?></p><span><a href="<?php echo BLOG_URL;?>" target="_blank">返回首页</a></span></div>
<form action="<?php echo BLOG_URL;?>?plugin=tougao&sl=1" method="post" enctype="multipart/form-data" name="addlog" >
<div class="tougao1">
	<div class="form-group">
<div class="input-group">
<div class="input-group-addon">
<i class="fa fa-twitch"></i>&nbsp;文章标题</div><input name="title" class="form-control" maxlength="200" style="width:98%;" placeholder="字数不得少于10字且不得大于30字" /></div></div>
<div class="form-group">
<div class="input-group">
<div class="input-group-addon">
<i class="fa fa-pencil-square-o"></i>&nbsp;作者昵称</div><input name="tags" class="form-control" maxlength="200" style="width:98%;" placeholder="作者昵称请保持10字以内" /></div></div>
<div class="form-group">
<div class="input-group">
<div class="input-group-addon">
<i class="fa fa-paperclip" aria-hidden="true"></i></i>&nbsp;原文地址</div><input name="excerpt" class="form-control" maxlength="200" style="width:98%;" placeholder="不加http://，否则无法提交，如本站首发请不要填写任何网址信息" /></div></div>
<li><p>注意事项：文章内容不得少于300字，请排版好，去掉没有必要的html代码，内容中的链接自动过滤</p><textarea name="text" style="width:98%;height:400px;" id="text"></textarea><script>loadEditor('text');</script></li></div>
<div class="tougao2">
<?php if($config["sort"] =='0'){?><li> <div class="styled-select"><select name="sortid" style="width:100px;height:30px;"><option value="-1">选择分类...</option><?php foreach($sorts as $val){?><option value=<?php echo $val['sid'];?>><?php echo $val['sortname'];?></option><?php }?></select></div></li><?php }?>
<?php if($config["code"] =='yes'){?><li><p>验 证 码</p><p style="font-size:16px; color:#F00;"><?php echo $config["yzm"];?></p></li>
<li><input name="imgcode" type="text" size="5" tabindex="5" /></li><?php }?>
<div class="button"><input type="submit" value="提交" onclick="return checkform();" /></div><label for="sheli"><input type="checkbox" value=9 id="sheli" name="sheli" required autocomplete="on" title="发表评论确认框：请勾选我再发表评论！"><font color="red">请勾选我再提交！</font></label></div>
</form>
<div class="nr"><div class="sltgbt">注意事项</div><ul>
<?php echo $config["zysx"];?>
</ul></div>
<div class="foot">Copyright © <?php echo date('Y');?> <?php echo $options_cache['blogname'];?> 版权所有</div>
</div>
<?php }elseif($sl==1){
$Log_Model = new Log_Model();
$Tag_Model = new Tag_Model();
$title = isset($_POST['title']) ? addslashes(trim($_POST['title'])) : '';
$content = isset($_POST['text']) ? addslashes(trim($_POST['text'])) : '';
$excerpt = isset($_POST['excerpt']) ? addslashes(trim($_POST['excerpt'])) : '';
$tags = isset($_POST['tags']) ? addslashes(trim($_POST['tags'])) : '';
$imgcode = isset($_POST['imgcode']) ? addslashes(trim(strtoupper($_POST['imgcode']))) : '';
$slCode = $config['yzmda'];
$author = '';
$sortid = isset($_POST['sortid']) ? intval($_POST['sortid']) : $config['sort'];
$date = time() + Option::get('timezone') * 3600;
$sb_title = mysql_query("select title from emlog_blog where title='$title' limit 1");
$sb_excerpt = mysql_query("select title from emlog_blog where excerpt='$excerpt' limit 1");
if(empty($title) || strlen($title) < 30 || strlen($title) > 90 || mysql_fetch_array($sb_title)){emMsg('错误提示如下：<br />1、标题不得少于10个字或多于30个字<br />2、你提交的标题已经有人使用了','javascript:history.back(-1);');
}elseif(strlen($tags) > 30){emMsg('错误提示：作者昵称不得多于10个字','javascript:history.back(-1);');
}elseif(!empty($excerpt) && preg_match("/^[A-Za-z0-9]+\.[A-Za-z0-9]+[\/=\?%\-&_~`@[\]\’:+!]*([^<>\"])*$/",$excerpt) == false){emMsg('错误提示：<br />1、原文地址不能加http://<br />2、原文网址格式是必须是正确的网站地址','javascript:history.back(-1);');
//}elseif(mysql_fetch_array($sb_excerpt)){emMsg('提交失败：原文地址出错，此网址已经发表过文章','javascript:history.back(-1);');
}elseif(empty($content) || strlen($content) < 10 ){emMsg('错误提示：内容字数不得少于300个字','javascript:history.back(-1);');
}elseif(preg_match("/^[0-9]*[1-9][0-9]*$/",$sortid)==false &&$config["sort"] =='0'){emMsg('错误提示：请选择分类','javascript:history.back(-1);');
}elseif($imgcode != $slCode && $config["code"] =='yes'){emMsg('错误提示：验证码错误','javascript:history.back(-1);');
}
$logData = array(
'title' => $title,
'alias' => '',
'content' => $content,
'excerpt' => $excerpt,
'author' => $config["author"],//指定作者ID
'date' => $date,
'top'=> $config["top"],
'sortop'=> $config["sortop"],
'sortid'=> $sortid,
'allow_remark' => 'y',
'hide' => $config["hide"], //n为直接通过，y为放入草稿
'checked' => $config["checked"],//y不需要审核，n为需要审核
'password' => ''
);
$blogid = $Log_Model->addlog($logData);
$Tag_Model->addTag($tags, $blogid);
header('Location:'.BLOG_URL.'?plugin=tougao&sl=2');die;}
elseif($sl==2){emMsg('提交成功，文章将在审核后发布。<br />请耐心等待，非常感谢您的贡献！快速投稿联系：QQ:39040208',''.BLOG_URL.'?plugin=tougao');}?>
</body></html>