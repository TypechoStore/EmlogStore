<?php
/*
Plugin Name: 蓝叶文章关键词描述插件
Version: 1.0
Plugin URL: http://www.oubly.cn
Description: 使用此插件可以自定义设置每篇文章的关键词和描述，使用方法：1、在模板header.php中head标签中第一行加入代码：&lt;?php if(isset($logid)){$site_key = lanye_logkey_getkey($logid);$site_description = lanye_logkey_getdesc($logid);}?>；2、再把插件目录page.php文件覆盖到admin文件夹下即可。有任何问题请联系QQ734103205,免费帮解决。
Author: 蓝叶
Author Email: 734103205@qq.com
Author URL: http://www.oubly.cn
*/
!defined('EMLOG_ROOT') && exit('access deined!');
function lanye_logkey(){?>
<link href="<?php echo BLOG_URL;?>content/plugins/lanye_logkey/main.css" type="text/css" rel="stylesheet" />
<?php 
$db = Database::getInstance();
$type = isset($_GET['action']) ? addslashes(trim($_GET['action'])) : '';
$gid = isset($_GET['gid']) ? addslashes(trim($_GET['gid'])) : '';
$pageid = isset($_GET['id']) ? addslashes(trim($_GET['id'])) : '';
if($type=='edit' || $type=='mod'):?>
<?php 
if($type=='mod'){
$sql = "SELECT `logkeyword`,`logdesc` FROM `".DB_PREFIX."blog` WHERE `gid`=".$pageid.";";
}else{
$sql = "SELECT `logkeyword`,`logdesc` FROM `".DB_PREFIX."blog` WHERE `gid`=".$gid.";";
}
$result = $db->query($sql);
$logkey = $db->fetch_array($result);
?>
<div class="lylogkey"><label>关键词</label><input name="logkey" id="logkey" type="text" value="<?php echo $logkey['logkeyword'];?>" placeholder="关键词填写处，多个英文逗号隔开，结尾无逗号..." /></div>
<div class="lylogkey"><label>页面描述</label><input name="logdesc" id="logdesc" type="text" value="<?php echo $logkey['logdesc'];?>" placeholder="描述填写处，句号结尾。" /></div>
<?php else:?>
<div class="lylogkey"><label>关键词</label><input name="logkey" id="logkey" type="text" value="" placeholder="关键词填写处，多个英文逗号隔开，结尾无逗号..." /></div>
<div class="lylogkey"><label>页面描述</label><input name="logdesc" id="logdesc" type="text" value="" placeholder="描述填写处，句号结尾。" /></div>
<?php endif;?>
<?php }
addAction('adm_writelog_head', 'lanye_logkey');
function lanye_logkey_add($logid){
$logkey = isset($_POST['logkey']) ? addslashes(trim($_POST['logkey'])) : '';
$logdesc = isset($_POST['logdesc']) ? addslashes(trim($_POST['logdesc'])) : '';
$db = Database::getInstance();
$db->query("UPDATE `".DB_PREFIX."blog` SET  `logkeyword` =  '".$logkey."',`logdesc` = '".$logdesc."' WHERE  `gid` = ".$logid.";");	
}
addAction('save_log','lanye_logkey_add');
function lanye_logkey_trimall($str)
{$qian=array(" ","　","&nbsp;","\t","\n","\r");$hou=array("","","","","");
return str_replace($qian,$hou,$str);    
}
function lanye_logkey_tag($logid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$logid])){
		foreach ($log_cache_tags[$logid] as $value){
			$tag .= $value['tagname'].',';
		}
		return substr($tag,0,-1);
	}
}
function lanye_logkey_cont($logid){
	$db = Database::getInstance();
	$sql = "SELECT `content` FROM `".DB_PREFIX."blog` WHERE `gid`=".$logid."";
	$result = $db->query($sql);
	$logcont = $db->fetch_array($result);
	$content = strip_tags($logcont['content']);
 $content = lanye_logkey_trimall($content);
 return mb_substr($content,0,100,'utf-8').'...';
}
function lanye_logkey_getkey($logid){
 if(!empty($logid)){
	$db = Database::getInstance();
	$sql = "SELECT `logkeyword` FROM `".DB_PREFIX."blog` WHERE `gid`=".$logid."";
	$result = $db->query($sql);
	$logkey = $db->fetch_array($result);
	if(empty($logkey['logkeyword'])){
	return lanye_logkey_tag($logid);
 }else{
 return $logkey['logkeyword'];
 }
 }
}
function lanye_logkey_getdesc($logid){
 if(!empty($logid)){
	$db = Database::getInstance();
	$sql = "SELECT `logdesc` FROM `".DB_PREFIX."blog` WHERE `gid`=".$logid."";
	$result = $db->query($sql);
	$logkey = $db->fetch_array($result);
	if(empty($logkey['logdesc'])){
	return lanye_logkey_cont($logid);
 }else{
 return $logkey['logdesc'];
 } 
 }
}
