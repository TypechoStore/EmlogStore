<?php
function callback_init()
{
 $db = Database::getInstance();
	$sql = "ALTER TABLE  `".DB_PREFIX."blog` ADD (`logkeyword` varchar(255) NOT NULL default '',`logdesc` varchar(255) NOT NULL default '');";
 if(!array_key_exists('logdesc',$db->fetch_array($db->query("SELECT * FROM `".DB_PREFIX."blog`;")))){
 $db->query($sql);}
}

function callback_rm()
{
 
}

