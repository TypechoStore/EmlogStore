<?php
/*
Plugin Name: Lytebox
Version: 1.0
Plugin URL: http://lanyes.org/zuopin/emlog-lytebox.html
Description: 给网站文章中的图片添加Lytebox浮动透明层特效。
Author: 蓝叶
Author Email: w@lanyes.org
Author URL: http://lanyes.org
*/
!defined('EMLOG_ROOT') && exit('access deined!');
function Lanye_lytebox(){
$active_plugins = Option::get('active_plugins');
echo '<link href="'.BLOG_URL.'content/plugins/Lanye_lytebox/images/lytebox.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="'.BLOG_URL.'content/plugins/Lanye_lytebox/images/lytebox.js"></script>
<script type="text/javascript">
$(document).ready(function(){
$("a[href$=jpg],a[href$=png],a[href$=gif],a[href$=jpeg]").attr("rel","lytebox[vacation]");
});
</script>'."\r\n";
}

addAction('index_footer', 'Lanye_lytebox');