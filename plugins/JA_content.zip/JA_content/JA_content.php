<?php
/*
Plugin Name: 文章版权(QRCode)
Version: 1.3
Plugin URL: http://www.gouji.org/?post=61
Description: 在文章底部添加版权
Author: 简爱
Author Email: sc.419@qq.com
Author URL: http://www.gouji.org/
时间: 201302052108
*/

!defined('EMLOG_ROOT') && exit('access deined!');
addAction('log_related', 'JA_content_f');

// 文章底部显示版权
function JA_content_f($arr){
  $blogname = Option::get('blogname');
  //$url = BLOG_URL."?post=".$arr['logid'];
  $url = Url::log($arr['logid']);
  $name = "<a style=\"color:red;\" href=\"".BLOG_URL."\">".$blogname."</a>";
  ?>
  <p>
  <img src ="http://chart.apis.google.com/chart?chs=80x80&cht=qr&chld=L|0&chl=<?php echo $url; ?>" align ="left" />
  版权所有：《<?php echo $name; ?>》 => 《<a href="<?php echo $url; ?>"><?php echo $arr['log_title'];  ?></a>》<br />
  本文地址：<a href="<?php echo $url; ?>"><?php echo $url; ?></a><br />
  除非注明，文章均为 《<?php echo $name; ?>》 原创，欢迎转载！转载请注明本文地址，谢谢。<br />
  </p>
  <?php
}
