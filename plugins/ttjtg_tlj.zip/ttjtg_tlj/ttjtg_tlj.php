<?php
/*
Plugin Name: 外链本地化
Version: 1.0
Plugin URL: http://www.te13.com/
Description: 外链本地化  除本地url外的所有外链均会自动在前面加上字符串，iframe的形式打开改url地址，保护权重不流失
Author: 团团说
Author Email: ttjtg@139.com
Author URL: http://www.te13.com/
*/
!defined('EMLOG_ROOT') && exit('access deined!');

function ttjtg_tlj_open()
{
echo '
<script>
window.onload=function(){
  var a = document.getElementsByTagName("a");
  for(var i=0;i<a.length;i++) a[i].onclick = function(){
    if(this.href.indexOf("javascript:;")==-1&&this.href.indexOf("'.$_SERVER['HTTP_HOST'].'")==-1)this.href="'.BLOG_URL.'?plugin=ttjtg_tlj&url=" + encodeURIComponent(this.href);}
}
</script>';
}
addAction('index_footer', 'ttjtg_tlj_open');
?>
