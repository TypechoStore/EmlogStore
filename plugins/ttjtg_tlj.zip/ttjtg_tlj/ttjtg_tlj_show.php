<?php

!defined('EMLOG_ROOT') && exit('access deined!');

$url =addslashes($_GET['url']);//解密：base64_decode

function get_hitcount($counter_file) 
{ 
$count=0; 
if ( file_exists($counter_file) ) 
{ 
$fp=fopen($counter_file,"r"); 
$count=0+fgets($fp,4);  //4表示数字的最大位数，0是初始数据
fclose($fp); 
} 
$count++; 
$fp=fopen($counter_file,"w"); 
fputs($fp,$count); 
fclose($fp); 
return ($count); 
} 
$count=get_hitcount("content/plugins/ttjtg_tlj/counter.txt");

?>
<title>外链浏览 - <?=Option::get('blogname')?></title>

<style type="text/css">

body{cursor:default;margin:0;padding:0;font-size:12px;}
.cbox{ border:1px solid #abc;overflow:hidden;word-break:break-all;height:28px;line-height:28px; }
.cbox .head{background:#def; overflow:hidden; padding:0 12px;}
.cbox .head a{color:#464646;text-decoration:none; font-size:12px;}
.cbox .head SPAN{color:#00BFE1;}
.cbox .head tt{color:#ff0000;}
</style>
</head>

<body>

<div class="cbox">
<div class="head"><a href="./" title="<?=Option::get('blogname')?>" ><?=Option::get('blogname')?></a>&nbsp;<span>|</span>&nbsp;
<a href="<?= $_SERVER['HTTP_REFERER'] ?>" >返回上一页</a>&nbsp;<span>|</span>&nbsp;<a onclick="AddFavorite(window.location,document.title)">加入收藏</a>&nbsp;<span>|</span>&nbsp;[<a href="javascript:void(0);" onclick="window.opener=null; window.open('','_self');window.close();">关闭窗口</a>]&nbsp;<span>|</span>&nbsp;您是今日 本页第  <tt><?= $count ?></tt> 个访问者


<!-- JiaThis Button BEGIN -->
<div class="jiathis_style"  style="padding-top:4px;float:right">
<a href="http://www.jiathis.com/share?uid=1535541" class="jiathis jiathis_txt" rel="nofollow"  target="_blank">分享给朋友们^_^<img src="http://v3.jiathis.com/code_mini/images/btn/v1/jiathis3.gif" border="0" /></a>
</div>
<script type="text/javascript">
var jiathis_config = {data_track_clickback:'true'};
</script>
<script src="http://v3.jiathis.com/code_mini/jia.js?uid=1535541" type="text/javascript" charset="utf-8"></script>
<!-- JiaThis Button END -->

</div></div>

		
<script type="text/javascript" charset="utf-8">
document.write('<iframe   id="url_mainframe" frameborder="0" scrolling="yes" name="main" src="<?= $url?>" style="height:100%; visibility: inherit; width: 100%; z-index: 1;overflow: visible;"></iframe>');
</script>	


<script type="text/javascript">
function AddFavorite(sURL, sTitle){
    try{ window.external.addFavorite(sURL, sTitle); }
    catch (e){
        try{  window.sidebar.addPanel(sTitle, sURL, "");  }
        catch (e){alert("加入收藏失败，请使用Ctrl+D进行添加"); }
    }
}
</script>

<!-- Baidu Button BEGIN -->
<script type="text/javascript" id="bdshare_js" data="type=slide&img=8&pos=&uid=765525" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
var bds_config={"bdTop":240};
document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000);
</script>
<!-- Baidu Button END -->

</body>
</html>
