emlog 日志归档插件
====================

为你的博客添加一个归档页面，展示全部的文章，访客可选择按时间或者分类显示。与博客内置的归档相比，这个就多了一个统计功能，用户可自行选择。

[插件主页](http://xiaosong.org/share/emlog-log-archiving-plug-in-released)