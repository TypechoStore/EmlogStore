<?php
$config = array(
	"qrcode" => "1",
    "width" => "128",
    "height" => "128",
	"colorDark" => "#000000",
    "colorLight" => "#FFFFFF"
);