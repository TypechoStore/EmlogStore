<?php
/*
Plugin Name: 生成二维码
Version: 1.0
Plugin URL: 
Description: 第一个用于学习之用的简易生成二维码插件
ForEmlog:5.2.0+
Author:	二呆
Author Email: diamond0422@qq.com
Author URL: https://www.tongleer.com
 */
!defined('EMLOG_ROOT') && exit('access deined!');

function qrcode() {//写入插件导航
    echo '<div class="sidebarsubmenu"><a href="./plugin.php?plugin=qrcode">二维码</a></div>';
}
addAction('adm_sidebar_ext', 'qrcode');
function qrcode_out(){
	$qrcode='qrcode.png';
	echo '<img src="'.BLOG_URL.$qrcode.'">'; 
}
addAction('qrcode_ext', 'qrcode_out');
?>