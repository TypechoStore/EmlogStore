<?php
/*
Plugin Name:小洋文章版权
Version: 2.1
Plugin URL: http://wuiso.com/891.html
Description: 文章版权美化版，将&lt;?php doAction('log_wuiso', $logData); ?>放在echo_log.php文章底部合适位置即可。
Author: 小洋vier
ForEmlog:6.1.1
Author Email: 1162771270@qq.com
Author URL: http://www.wuiso.com
*/

!defined('EMLOG_ROOT') && exit('access deined!');
addAction('log_wuiso', 'wuiso_com_f');

// 文章底部显示短链接版权
function wuiso_com_f($arr){
  include 'wuiso_config.php';
  $w = $config["width"];
  $h = $config["height"];
  $D = $config["colorDark"];
  $L = $config["colorLight"];
  $blogname = Option::get('blogname');
  $blogauthor = Option::get('blogauthor');
  //$url = BLOG_URL."?post=".$arr['logid'];
  $url = Url::log($arr['logid']);
  $nameurl=BLOG_URL;
  //$namedwz=$return=file_get_contents("http://eps.gs/api/make.php?url=$nameurl");
  //$resulta=json_decode($namedwz);
  //$nameurla=$resulta->url_short;
$name = "<a style=\"color:red;\" href=\"".$nameurl."\">".$blogname."</a>";
  ?>
 <style>
*{
  margin:0;
  padding:0;
}
.wrap{
  margin: 100px auto;
  width: 500px;
}
/* 方法一 start */
.method-1-wrap{
 width:100%;border:5px  solid #337FE5; margin:10px 0px 15px 0px;padding:10px;border-radius:8px;font-size:14px;border-collapse:collapse;
position: relative;
  box-sizing: border-box;
}
.method-1-wrap .title{
    color:#FFFFFF;width:50%;padding:2px;font-size:15px;text-align:center;border-radius:8px;background-color:#337FE5;border-collapse:collapse;
   position: absolute;
    top: -15px;
    left: 25%;
    line-height: 1.2em;
}.btn-xs {
    padding: 1px 3px;
    font-size: 12px;
    line-height: 1.5;
    border-radius: 3px;
}
.btn-info {
    color: #fff;
    background-color: #5bc0de;
    border-color: #46b8da;
}
.btn {
    display: inline-block;
    padding: 2px 3px;
    margin-bottom: 0;
    font-size: 12px;
    font-weight: normal;
    line-height: 1.428571429;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    cursor: pointer;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 3px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    -o-user-select: none;
    user-select: none;
}
.btn-danger {
    color: #fff;
    background-color: #d9534f;
    border-color: #d43f3a;
}
.btn-warning {
    color: #fff;
    background-color: #f0ad4e;
    border-color: #eea236;
}
.btn-success {
    color: #fff;
    background-color: #5cb85c;
    border-color: #4cae4c;
}

</style>
 <div class="method-1-wrap wrap">
<span class="title"><?php echo $blogname; ?>-版权声明</span> <div class="content">
<p><span class="btn btn-info btn-xs">1</span>&nbsp&nbsp除非特别注明，文章均为<c style="color:#F00078;">【<?php echo $name; ?>】</c>原创，转载时请注明来源</p> 
<span class="btn btn-danger btn-xs">2</span>&nbsp<b target="_blank"  class="border:2px  solid #337FE5;"><本站资源来自互联网搜集，如有侵权请联系我们删除></b>
<p> <span style="float:right;">百度已收录<a style="color:red;" rel="external nofollow" title="点击提交收录！" target="_blank" href="http://zhanzhang.baidu.com/sitesubmit/index?sitename=<?php echo $url; ?>">[点击提交]</a></span></p> 
     <form action="" id="mfp-form" style="height:0.1px;overflow:hidden"><input name="url" value="<?php echo $url ?>" id="url2" type="text"/></form>
	 
  <span class="btn btn-success btn-xs">3</span>&nbsp&nbsp<span style="color:info;"><b>本文标题：</b><a href="<?php echo $url; ?>">【<?php echo $arr['log_title'];  ?>】</a></span><br>
  <span class="btn btn-warning btn-xs">4</span>&nbsp&nbsp<b>本文衔接：</b><a href="<?php echo $url; ?>" id="urllink" style="color:#F75000;"><?php echo $url; ?></a>&nbsp;&nbsp;<a href="https://jq.qq.com/?_wv=1027&k=5IjKwDf" style="color:red" onclick="get_duanwangzhi()" class="makeurl">[点击加站长交流群]</a><br>
	<style>#qrcodeaa img{width:<?php echo $w.'px';?>;height:<?php echo $h.'px';?>;margin:0 auto;}</style>
<script type="text/jscript" src="http://eps.gs/api/js/qrcode.js"></script>
	<div id="qrcodeaa"></div></div></div>
    <script>
      
    function get_duanwangzhi(){
        $(".makeurl").text("[Loading...]");
    	$.post("<?php echo $nameurl ?>content/plugins/wuiso_com/ajax.php",
    		{
    		"url":$("input[name='url']").val(),
    		},
    		function(data){
    			var s =data;
    			if(s)
    			{
    				$("#urllink").text(s);
    				$("#urllink").attr("href",s); 
    				$("#url2").attr("value",s); 
    				$(".makeurl").attr("onclick",'fuzhi()'); 
    				$(".makeurl").text("[复制短网址]");
                  	<?php if($config['qrcode']){echo "var qrcode = new QRCode(\"qrcodeaa\", {text: s,width: $w,height: $h,colorDark : \"$D\",colorLight : \"$L\",correctLevel : QRCode.CorrectLevel.H});";}?>
    			}
    		}
    	);
		
        return false;
    }
    function fuzhi(){
        var e=document.getElementById("url2");
        e.select();
        document.execCommand("Copy");
        alert("复制成功");  
    }
    </script>
  <?php
}

function wuiso_menu()
{
	echo '<div class="sidebarsubmenu" id="wxts"><a href="./plugin.php?plugin=wuiso_com">小洋文章版权</a></div>';
}
addAction('adm_sidebar_ext', 'wuiso_menu');