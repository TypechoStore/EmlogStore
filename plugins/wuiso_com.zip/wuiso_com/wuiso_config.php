<?php
$config = array(
	"qrcode" => "1",
    "width" => "128",
    "height" => "128",
	"colorDark" => "#FF0000",
    "colorLight" => "#FFFFFF"
);