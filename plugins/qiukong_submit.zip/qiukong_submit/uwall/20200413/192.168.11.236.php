<?php $uwarr=array (
  'time' => 1586766000,
  'post' => 1,
); ?>