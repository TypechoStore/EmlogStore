<?php if(!defined('EMLOG_ROOT')){die('err');} ?>
<?php 
include View::getView('header');
include View::getView('page');
die;
?>