<?php
/*
Plugin Name: 蓝叶火箭特效返回顶部
Version: 1.0
Plugin URL: http://lanyes.org
Description: 在网站右侧显示火箭向上飞的返回顶部特效，下拉显示，返回顶部后消失。
Author: 蓝叶
Author Email: w@lanyes.org
Author URL: http://lanyes.org
*/
!defined('EMLOG_ROOT') && exit('access deined!');

function lanye_hjup(){
echo '
<link href="'.BLOG_URL.'content/plugins/lanye_hjup/uptop.css" rel="stylesheet" type="text/css" />
<script src="http://libs.baidu.com/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script src="'.BLOG_URL.'content/plugins/lanye_hjup/uptop.js"></script>
<div id="uptop">
<div style="opacity:0;display:block;" class="level-2"></div>
<div class="level-3"></div>
</div>
'."\r\n";
}
addAction('index_footer', 'lanye_hjup');