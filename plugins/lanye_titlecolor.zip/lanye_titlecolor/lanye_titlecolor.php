<?php
/*
Plugin Name: 标题颜色插件
Version: 1.0
Plugin URL: http://lanyes.org
Description: 蓝叶自定义文章标题颜色插件，可设置每个文章标题不同颜色。使用方法一、在模板目录log_list.php或echo_log.php的输出标题处，所包裹的标签中加入style样式，如：style='color:&lt;?=lanye_titlecolor_get($value['logid']);?>;'；使用方法二、在模板目录log_list.php或echo_log.php的输出标题处，用&lt;font color='&lt;?=lanye_titlecolor_get($value['logid']);?>'>……&lt;/font>包裹起标题即可（备注：$value['logid']要和自身模板log_list.php或echo_log.php中的id一致。）。
Author: 蓝叶
Author Email: w@lanyes.org
Author URL: http://lanyes.org
*/
!defined('EMLOG_ROOT') && exit('access deined!');

function lanye_titlecolor(){
	?>
	<link href="<?php echo BLOG_URL;?>content/plugins/lanye_titlecolor/main.css" type="text/css" rel="stylesheet" />
	<script type="text/javascript" src="<?php echo BLOG_URL;?>content/plugins/lanye_titlecolor/main.js"></script>
	<?php 
	$db = Database::getInstance();
	$type = isset($_GET['action']) ? addslashes(trim($_GET['action'])) : '';
	$gid = isset($_GET['gid']) ? addslashes(trim($_GET['gid'])) : '';
	if($type=='edit' AND isset($gid)):?>
	<?php 
	$sql = "SELECT `titlecolor` FROM `".DB_PREFIX."blog` WHERE `gid`=".$gid.";";
	$result = $db->query($sql);
	$titlecolor = $db->fetch_array($result);
	?>
	<div class="lytitlecolor"><label><a title="使用方法详见插件列表中此插件的描述" href="javascript:;" onClick="return false;" style="color:red;">标题颜色</a></label><input name="titlecolor" id="titlecolor" type="text" value="<?php echo $titlecolor['titlecolor'];?>" hx="" placeholder="请点击输入框选择颜色..." /><div class="incolor" style="background:<?php echo $titlecolor['titlecolor'];?>"></div></div>
	<?php else:?>
	<div class="lytitlecolor"><label><a title="使用方法详见插件列表中此插件的描述" href="javascript:;" onClick="return false;" style="color:red;">标题颜色</a></label><input name="titlecolor" id="titlecolor" type="text" value="" hx="" placeholder="请点击输入框选择颜色..." /><div class="incolor"></div></div>
	<?php endif;?>
	<?php
}
addAction('adm_writelog_head', 'lanye_titlecolor');

function lanye_titlecolor_add($logid){
	$titlecolor = isset($_POST['titlecolor']) ? addslashes(trim($_POST['titlecolor'])) : '';
	$db = Database::getInstance();
	$db->query("UPDATE `".DB_PREFIX."blog` SET  `titlecolor` =  '".$titlecolor."' WHERE  `gid` = ".$logid.";");	
}
addAction('save_log','lanye_titlecolor_add');

function lanye_titlecolor_get($logid){
	$db = Database::getInstance();
	$sql = "SELECT `titlecolor` FROM `".DB_PREFIX."blog` WHERE `gid`=".$logid."";
	$result = $db->query($sql);
	$titlecolor = $db->fetch_array($result);
	if(empty($titlecolor['titlecolor'])){
		return;
	}else{
		return $titlecolor['titlecolor'];
	}
}
