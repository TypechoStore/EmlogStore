<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
	<div class="content">
		<div class="min_box">
			<div class="min_title">
				<h2><?php if ($params[1]=='sort'){echo $sortName;}else{echo '任何足够先进的技术,初看都与魔法无异!';}?></h2>
			</div>
			<ul class="min_comnet">
			<?php if (!empty($logs)): foreach($logs as $value): ?>
			<?php  preg_match_all("/<img.*src=[\"'](.*)[\"']/Ui", $value['content'], $imgs); $imgNum = count($imgs[1]); if($imgNum >= 0) { ?>
				<li class="min_list">
				<section class="box_comnet">
				<article class="div_comnet">
				<a class="box_img"><img class="avatar" alt="" width="50" height="50" src="//q2.qlogo.cn/headimg_dl?dst_uin=<?php echo _g('qq'); ?>&spec=100" style="display: block;"> </a>
				<div class="box_div">
					<div class="box_text">
					<div class="div_title"><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>"><?php echo $value['log_title']; ?></a><?php if($imgNum > 0){echo '<i class="fa fa-picture-o"></i>';}?></div>
					<p class="div_logdes"><?php echo $logdes = geshihua($value['content'], 130); ?></p>
					<p class="div_info">
					<span class="div_date"> <?php echo gmdate('n月j日', $value['date']); ?></span>
					<time class="div_views"><?php echo $value['views']; ?>℃</time>
					<span class="div_sort"> <?php blog_sort($value['logid']); ?></span>
					</p>
					</div>
				</div>
				</article>
				</section>
				</li>
			<?php } ?>		
			<?php  endforeach; else: ?>	
			<p>抱歉，没有符合您查询条件的结果。</p>
			<?php endif;?>
			<!--[注释]><div class="div_cut"><span>列表结束</span></div><![endif]-->			
			<div class="pagination"><?php echo lanyoupage($lognum,$index_lognum,$page,$pageurl);?></div>			
			</ul>
		</div>
	</div>
</div>
<?php include View::getView('footer'); ?>