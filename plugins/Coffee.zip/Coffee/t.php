<?php 
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content" style="position:absolute;left:50%;transform: translateX(-50%);top: 20%;">
	<div class="content">
	<div class="title">
    <h3><?php echo $blogname; ?> - 2018</h3>
    <h1>非法访问</h1>
    <h3><?php echo BLOG_URL; ?></h3>
	</div>
	</div>
</div>
<style>
.more-pens{position:fixed;bottom:20px;left:20px;z-index:10;font-size:12px;font-family:Montserrat;}
a.white-mode,a.white-mode:active,a.white-mode:link,a.white-mode:visited{padding:4px 8px;background:#212121;color:#f7f7f7;text-decoration:none;font-size:12px;font-family:Montserrat;}
a.white-mode:active:hover,a.white-mode:hover,a.white-mode:link:hover,a.white-mode:visited:hover{background:#edf3f8;color:#212121;}
body{overflow:hidden;margin:0;padding:0;width:100%;height:100%;background:#000;}
.title{position:absolute;top:50%;left:50%;z-index:10;width:100%;text-align:center;font-family:Montserrat;transform:translateX(-50%) translateY(-50%);}
.title h1{position:relative;margin:0;padding:50px;color:#FFF;text-shadow:0 0 10px#ff006c,0 0 20px#ff006c,0 0 30px#ff006c,0 0 40px#ff417d,0 0 70px#ff417d,0 0 80px#ff417d,0 0 100px#ff417d,0 0 150px#ff417d;font-weight:100;font-size:90px;line-height:1;}
.title h1 span{margin:0;padding:0;color:#FFF;font-weight:600;}
.title h3{margin:0;padding:0;color:#FFF;letter-spacing:2px;font-weight:200;font-size:20px;line-height:1;}
#page,.footer{display:none;}
</style>
<?php include View::getView('footer'); ?>