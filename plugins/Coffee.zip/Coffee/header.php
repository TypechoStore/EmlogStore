<?php
/*
Template Name:苦咖啡
Description:心情日志，简洁优雅
Version:2.0
Author:蓝优
Author Url:http://lanyou.vip
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
if(function_exists('emLoadJQuery')) {
    emLoadJQuery();
}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?php echo $site_title; ?></title>
<meta name="description" content="<?php echo $site_description; ?>">
<meta name="keywords" content="<?php echo $site_key; ?>">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,minimum-scale=1,maximum-scale=1,user-scalable=no">
<meta name="generator" content="蓝优" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<!--CSS-->
<link rel="shortcut icon" href="<?php echo TEMPLATE_URL; ?>favicon.ico">
<link href="//cdn.bootcss.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>style/new.css">
<link rel="stylesheet" type="text/css" href="<?php echo TEMPLATE_URL; ?>style/swipebox.css">
<!--JS-->
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>jquery/jquery.min.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>jquery/lanyou.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>jquery/prettify.js"></script>
<?php if(_g('xzh_radio')=='open'){?>
<script src="//msite.baidu.com/sdk/c.js?appid=<?php echo _g('xzh_id'); ?>"></script>
<?php }?>
</head>
<body>
<div id="page">
	<div id="nav">
		<div class="nav-item">
			<h1 class="nav-logo"><a href="<?php echo BLOG_URL; ?>"  title="<?php echo $bloginfo; ?>" style="background-image:url(<?php echo _g('logo'); ?>)"><?php echo $blogname; ?></a></h1>
			<span class="nav-switch btn hide slow">导航菜单</span>
			<div class="nav-menu">
				<div class="nav-menu-list">
				<?php blog_navi();?>					
				</div>
			</div>
			<div class="nav-icon">
				<a class="nav-rss fa fa-rss" href="<?php echo BLOG_URL;?>rss.php" rel="external nofollow"></a>
				<a class="nav-qq fa fa-qq" href="tencent://message/?uin=<?php echo _g('qq'); ?>" rel="external"></a>
				<a class="nav-search fa fa-search hide" href="javascript:;" style="display:block"></a>
			</div>
			<div class="nav-search-bar hide" style="display: none;">
				<form method="get" action="<?php echo BLOG_URL;?>">
					<input type="search" placeholder="输入关键词搜索..." value="" name="keyword">
				</form>
			</div>
		</div>
	</div>
</div>