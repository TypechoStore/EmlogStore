<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php if(_g('xzh_radio')=='open'){?>
<script type="application/ld+json">
{
   "@context": "https://ziyuan.baidu.com/contexts/cambrian.jsonld",
    "@id": "<?php echo Url::log($logid);?>",
    "appid": "<?php echo _g('xzh_id'); ?>",
    "title": "<?php echo $log_title; ?>",
    "images": [ "<?php if(picthumb($logid)){echo picthumb($logid);}else{ ?> <?php echo _g('xzh_img');  }?>" ], 
    "description": "<?php echo $site_description; ?>",
    "pubDate": "<?php echo gmdate('Y-m-d\TH:i:s', $date);?>",
    "upDate": "<?php echo gmdate('Y-m-d\TH:i:s', $date);?>",
    "lrDate": "<?php echo gmdate('Y-m-d\TH:i:s', $date);?>"
    }
</script>
<?php }?>
<div id="content">
	<div class="content">
		<div class="div_contentbox">
			<header class="Inner_header">
			<div class="Inner_meta">
				<div class="Inner_avatar"><?php blog_author($author); ?></div>
				<h1><?php echo $log_title; ?></h1>
				<p class="Inner_mtop"><span> 分类栏目：<?php blog_sort($logid); ?></span></p>
			</div>
			<div class="Inner_data">
				<p class="Inner_views"><?php echo $views; ?>℃</p>
				<p>
					<span><?php zuozhe($author); ?> 发布于 <time><?php echo gmdate('n月j日', $date); ?></time></span>
					<span class="Inner_comments"><a href="#comments">发表评论</a></span>
				</p>
			</div>
			</header>
			<div class="Inner_content"><?php echo unCompress($log_content,$logid); ?></div>
			<div class="Inner_dashang">
			<a href="javascript:;" id="boxBtn"><i class="fa fa-credit-card"></i>打赏</a>
			<a href="javascript:;" id="fxbox"><i class="fa fa-external-link"></i>分享</a>
			</div>
			<div class="demo_box" id="boxModal">
			<div class="dashang">
			<a href="javascript:void(0)" id="demo_close"><i class="fa fa-times"></i></a>
			<div class="das_title"> <i class="fa fa-qrcode"></i>&nbsp;&nbsp;友情赞助 </div>
			<div class="das_content">
			<div class="demo_left"> <img src="<?php echo _g('ds_weixin');?>" alt="微信二维码"> </div>
			<div class="demo_right"> <img src="<?php echo _g('ds_zfb');?>" alt="支付宝二维码"></div>
			</div>
			</div>
			</div>
			<div class="demo_fxbox" id="boxfx">
			<div class="fenxiang">
			<a href="javascript:void(0)" id="fenxiang_close"><i class="fa fa-times"></i></a>
			<div class="fenxiang_title"><i class="fa fa-external-link"></i>&nbsp;&nbsp;选择分享方式</div>
			<div class="fenxiang_content">
			<div class="fenxiang_box">
			<div class="box_weixin"><span class="fx_ys weixin" title="分享到微信"><i class="fa fa-weixin"></i></span><img src="http://www.liantu.com/api.php?text=<?php echo Url::log($logid);?>" /></div>								
			<span class="fx_ys qqkj" title="分享到QQ空间" onclick="shareToQzone('<?php echo Url::log($logid);?>','<?php echo $log_title;?>','<?php echo picthumb($logid); ?>','')"><i class="fa fa-star-half-full"></i></span>
			<span class="fx_ys txqq" title="分享到QQ好友" onclick="shareToQQ('<?php echo Url::log($logid);?>','<?php echo $log_title;?>','<?php echo picthumb($logid); ?>')"><i class="fa fa-qq"></i></span>
			<span class="fx_ys weibo" title="分享到新浪微博" onclick="shareToWeibo('<?php echo Url::log($logid);?>','<?php echo $log_title;?>','<?php echo picthumb($logid); ?>')"><i class="fa fa-weibo"></i></span>
			</div>
			</div>
			</div>
			</div>
		<div class="sxp_yes"><?php neighbor_log($neighborLog); ?></div>			
		</div>
		<div class="banquan_cop">
		<p class="banquan_tags"><?php blog_tag($logid); ?></p>
		<p><i class="fa fa-bullhorn"></i>版权：若无特殊注明，本文皆为<?php zuozhe($author); ?>原创，转载请保留文章出处。</p>
		<p><i class="fa fa-share-alt-square"></i>链接：<?php echo $log_title; ?> - <?php echo Url::log($logid); ?></p>
		</div>
		<?php if($allow_remark == 'y'): ?> 	
		<div class="div_contentbox">		
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>			
		<ul class="commentList">
		<div id="pl-title"><span>已评论（<?php echo $comnum; ?>）</span></div>
		<?php blog_comments($comments); ?>
		</ul>
		</div>
		<?php endif;?>	
	</div>
</div>
<script src="<?php echo TEMPLATE_URL; ?>jquery/cof.js"></script>
<?php include View::getView('footer'); ?>