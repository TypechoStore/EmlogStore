<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php if (blog_tool_ishome()) {?>
<div class="links">
	<div class="links_title">
		<div class="links_left"> <a href="javascript:;">友情链接</a> </div>
		<div class="links_right"> <a href="<?php echo _g('sq_links');?>">更多</a> </div>
	</div>
	<div class="links_div">
		<ul>
		<?php 
			global $CACHE;
			$link_cache = $CACHE->readCache('link');
			foreach($link_cache as $value): 
			if (Option::EMLOG_VERSION == '6.0.1'){
			if ($value['linksortid'] != 1){continue;}} 
		?>
			<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
		<?php endforeach; ?>	
		</ul>
	</div>
</div>
<?php }?>
<div class="footer">
	<p>Copyright © 2018&nbsp; <a href="<?php echo BLOG_URL; ?>" target="_blank" title="<?php echo $blogname; ?>" ><?php echo $blogname; ?></a> &nbsp; 
	Powered by <a href="http://www.miibeian.gov.cn" rel="nofollow" target="_blank"  title="<?php echo $icp; ?>"><?php echo $icp; ?></a>&nbsp;<?php echo $footer_info; ?>
	</p>
</div>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>jquery/jquery.swipebox.js"></script>
</body>
</html>
<?php
if(_g('compress_html')=='open'){
        $html=ob_get_contents();
        ob_get_clean();
        echo em_compress_html_main($html);
}
?>