<?php
/*
 * Coffee
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
	'logo' => array(
        'type' => 'image',
        'name' => '上传LOGO图片',
        'values' => array( TEMPLATE_URL . 'images/logo.png', ),
		'description' => '默认尺寸为168X40像素透明PNG图片',
    ),
	'qq' => array(
		'type' => 'text',
		'name' => 'QQ号',
		'default' => '1410469560',
	),	
	'compress_html' => array(
        'type' => 'radio',
        'name' => '网站源码压缩',
        'description' => '',
        'values' => array('open' => '压缩','close' => '关闭'),
        'default' => 'open'
    ),
	'xzh_radio' => array(
        'type' => 'radio',
        'name' => '熊掌号开关',
        'description' => '',
        'values' => array('open' => '开启','close' => '关闭'),
        'default' => 'open'
    ),
	'xzh_id' => array(
		'type' => 'text',
		'name' => '熊掌号ID',
		'default' => '1586759269185909',
	),
	'xzh_img' => array(
		'type' => 'text',
		'name' => '熊掌号图片',
		'default' => '/content/templates/Coffee/images/a.jpg',
	),
	'sq_links' => array(
		'type' => 'text',
		'name' => '友情申请地址',
		'default' => '#',
	),
	'ds_weixin' => array(
        'type' => 'image',
        'name' => '微信二维码',
        'values' => array( TEMPLATE_URL . 'images/weixin.jpg', ),
    ),
	'ds_zfb' => array(
        'type' => 'image',
        'name' => '支付宝二维码',
        'values' => array( TEMPLATE_URL . 'images/zfb.jpg', ),
    ),
);
?>	  
