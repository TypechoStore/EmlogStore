<?php 
/**
 * 自定义404页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
?>
<script>
document.title = "404 抱歉页面不存在或被删除"
</script>
<style>
#page{display: none;}
.footer{display: none;}
.box404{margin:120px 0 250px 0;text-align:center;}
.page404-title{display:block;}
.page404-title h4{word-wrap:break-word;font-size:148px;line-height:150px;-ms-word-wrap:break-word;}
.box404 .pull2-left{padding:30px;}
.box404 .pull2-left a{display:inline-block;padding:12px 18px;border-radius:999px;background-color:#19B5FE;color:#FFF;color:#fff;font-size:14px;}
.box404 .pull2-left a:hover{background:#282828;color:#fff;}
</style>
<div class="box404">
    <div class="page404-title">
	<h4>404</h4>
	<h5>抱歉，没有你要找的文章...</h5>
	</div>
	<div class="buttons">
	<div class="pull2-left"><a title="Back" home"="" href="<?php echo BLOG_URL; ?>" class="btn btn-primary">返回首页</a></div>
	</div>
</div>
<?php include View::getView('footer'); ?>