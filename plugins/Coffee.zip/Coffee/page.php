<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content">
	<div class="content">
		<div class="div_contentbox">
			<header class="Inner_header">
			<div class="Inner_meta">
				<div class="Inner_avatar"><?php blog_author($author); ?></div>
				<h1><?php echo $log_title; ?></h1>
				<p class="Inner_mtop"><span>我只是个菜鸟</span></p>
			</div>
			<div class="Inner_data">
				<p class="Inner_views"><?php echo $views; ?>℃</p>
				<p>
					<span><?php zuozhe($author); ?> 发布于 <time><?php echo gmdate('n月j日', $date); ?></time></span>
					<span class="Inner_comments"><a href="#comments">发表评论</a></span>
				</p>
			</div>
			</header>
			<div class="Inner_content"><?php echo unCompress($log_content,$logid); ?></div>						
		</div>
		<?php if($allow_remark == 'y'): ?> 	
		<div class="div_contentbox">		
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>			
		<ul class="commentList">
		<div id="pl-title"><span>已评论（<?php echo $comnum; ?>）</span></div>
		<?php blog_comments($comments); ?>
		</ul>
		</div>
		<?php endif;?>	
	</div>
</div>
<?php include View::getView('footer'); ?>
