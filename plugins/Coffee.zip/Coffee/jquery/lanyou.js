jQuery(document).ready(function ($){
//顶部导航菜单
$('.nav-search').click(function (){
	$('.nav-search-bar').toggle('fast');
	$('body').one('click', function (){$('.nav-search-bar').hide('fast');});
	return false;
});
$('.nav-search-bar').click(function(){return false;});
$('.nav-switch').click(function(){$('.nav-menu').slideToggle('fast');});
$('.nav-switch').toggle(function(){$(this).css('background', '#6400A6').text('收起菜单');},
function(){$(this).removeAttr("style").text('导航菜单');});
$('.nav-menu ul li').hover(function (){
	var e = $(this);
	t = setTimeout(function (){
		e.children('ul').slideDown('fast');
		}, 300); 
},
function (){clearTimeout(t);$(this).children('ul').slideUp('fast');});
$(window).resize(function(){widthJudge();})
function widthJudge(){var winWidth = $(window).width();if (winWidth>750){ $('.nav-menu').fadeIn('normal'); }}
//external 新窗口打开
$('a[rel*=external]').click(function(){return window.open(this.href),!1});
$("a[href$=jpg],a[href$=jpeg],a[href$=gif],a[href$=png]").addClass("swipebox").attr('rel','');
});
//分享
function openShare($url) {
	return window.open($url, "newwindow")
}
function shareToWeibo(url, title, cover) {
	var re = /http:[/]{2}[a-zA-Z0-9.%=/]{1,}[.](jpg|png)/g;
	var content = $(".context").html();
	if(re.test(content)){
		cover = content.match(re)[0];
	}
	var url = "http://v.t.sina.com.cn/share/share.php?url=" + url + "&appkey=1148356070&title=" + title + "&searchPic=true&pic=" + cover + "&rnd=" + ((new Date()) * 1) + "";
	openShare(url)
}
function shareToQzone(url, title, cover, desc, summary) {
	var re = /http:[/]{2}[a-zA-Z0-9.%=/]{1,}[.](jpg|png)/g;
	var content = $(".context").html();
	if(re.test(content)){
		cover = content.match(re)[0];
	}
	var url = "http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=" + url + "&title=" + title + "&desc=" + desc + "&pics=" + cover + "&summary=&site=蓝优小栈";
	openShare(url)
}
function shareToQQ(url, title, cover, desc, summary) {
	var re = /http:[/]{2}[a-zA-Z0-9.%=/]{1,}[.](jpg|png)/g;
	var content = $(".context").html();
	if(re.test(content)){
		cover = content.match(re)[0];
	}
	var url = "http://connect.qq.com/widget/shareqq/index.html?url=" + url + "&title=" + title + "&desc=&summary=&site=蓝优小栈";
	openShare(url)
}
/*高亮*/
$( document ).ready(function() {
	$("pre").addClass("prettyprint linenums");
	prettyPrint();
});
function addNumber(a) {
	document.getElementById("comment").value += a
}
/*提示*/
var sweetTitles={x:10,y:20,tipElements:"a,span,img,div ",noTitle:false,init:function(){var b=this.noTitle;$(this.tipElements).each(function(){$(this).mouseover(function(e){if(b){isTitle=true}else{isTitle=$.trim(this.title)!=''}if(isTitle){this.myTitle=this.title;this.title="";var a="<div class='tooltip'><div class='tipsy-arrow tipsy-arrow-n'></div><div class='tipsy-inner'>"+this.myTitle+"</div></div>";$('body').append(a);$('.tooltip').css({"top":(e.pageY+20)+"px","left":(e.pageX-20)+"px"}).show('fast')}}).mouseout(function(){if(this.myTitle!=null){this.title=this.myTitle;$('.tooltip').remove()}}).mousemove(function(e){$('.tooltip').css({"top":(e.pageY+20)+"px","left":(e.pageX-20)+"px"})})})}};$(function(){sweetTitles.init()});
/*swipebox插件*/
$( document ).ready(function() {$('.swipebox' ).swipebox();});
