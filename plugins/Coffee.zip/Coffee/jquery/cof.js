jQuery(document).ready(function ($){
//打赏
var modal = document.getElementById('boxModal');
var btn = document.getElementById("boxBtn");
var span = document.querySelector('#demo_close');
btn.onclick = function() {
    modal.style.display = "block";
}
span.onclick = function() {
    modal.style.display = "none";
}
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}		
});
//分享
jQuery(document).ready(function ($){
var modal = document.getElementById('boxfx');
var btn = document.getElementById("fxbox");
var span = document.querySelector('#fenxiang_close');
btn.onclick = function() {
    modal.style.display = "block";
}
span.onclick = function() {
    modal.style.display = "none";
}
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}	
});	
 