<?php
/**
Plugin Name: 毛成勇文章草泥马表情
Version: 1.0
Plugin URL: http://zwdtv.com
Description: 在文章页添加草泥马表情。
Author: 毛成勇
Author Email: haiyu89@126.com
Author URL: http://zwdtv.com
*/
!defined('EMLOG_ROOT') && exit('access deined!');
function mcy_ganxiangemo(){
	$active_plugins = Option::get('active_plugins');
	$mcy_ganxiangemo_html = '<div id="cyEmoji" role="cylabs" data-use="emoji" sid="'.$logid.'"></div>
    <script type="text/javascript" charset="utf-8" src="http://changyan.itc.cn/js/??lib/jquery.js,changyan.labs.js?appid=cyqIl0VkO"></script>'."\r\n";
	echo $mcy_ganxiangemo_html;
}

addAction('log_related', 'mcy_ganxiangemo');
?>