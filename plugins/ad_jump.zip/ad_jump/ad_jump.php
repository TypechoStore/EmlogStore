<?php
/*
Plugin Name: 文章页跳转
Version: 1.0
Plugin URL: https://www.12580sky.com
Description: 指定文章的id和跳转URL，在用户打开文章的时候直接跳转到目标URL,echo_log.php中添加挂载点：&lt;?php doAction('ad_jump_echo',$logid); ?&gt;
Author: 小高教学网
Author URL: https://www.12580sky.com
*/
!defined('EMLOG_ROOT') && exit('error');


function ad_jump_menu(){	//插入后台导航侧边栏
	echo '<div class="sidebarsubmenu"><a href="./plugin.php?plugin=ad_jump">文章页跳转</a></div>';
}

function ad_jump_start($logid){	//在文章页插入
	include 'ad_jump_config.php';
	foreach($config as $log_id=>$jump_url) {
	  if($log_id == $logid){
	  	echo '<script type="javascript/text">window.location.href="'.BLOG_URL.'content/plugins/ad_jump/go.php?url='.$jump_url.';</script>';
	  	header("Location:".BLOG_URL."content/plugins/ad_jump/go.php?url=".$jump_url);
	  	break;
	  }
	}

}


addAction('adm_sidebar_ext', 'ad_jump_menu');		//插入导航侧边栏
addAction('ad_jump_echo', 'ad_jump_start');		//插入文章页

?>