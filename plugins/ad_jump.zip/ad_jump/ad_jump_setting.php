<?php
//设置页面

!defined('EMLOG_ROOT') && exit('error');

function plugin_setting_view() {	//设置页面加载配置文件 默认调用
	include(EMLOG_ROOT.'/content/plugins/ad_jump/ad_jump_config.php');
}

echo '<div class=containertitle><b>插件设置</b>';
if (isset($_GET['setting'])) echo '<span class="actived">插件设置完成</span>';
echo '</div>';


?>
<style type="text/css">
	.disable_click{
		cursor: not-allowed;
	}
</style>
<!-- HTML view -->
<script type="text/javascript">
	var input_id = 0;
	function add_new_ad($count_id){
		$("#input_form").append('<p>文章id</p> <input type="text" name="article_id'+$count_id+'" value="" placeholder="exp:123"> <p>广告跳转URL</p> <input type="text" name="jump_url'+$count_id+'" value="" placeholder="exp:https://www.12580sky.com">');
		$("#click_add").removeAttr('onclick').addClass("disable_click");
	}
	
</script>


<form action="plugin.php?plugin=ad_jump&action=setting" method="post">
	<div style="margin-left:10px;">
		
		<h4>1.使用说明：</h4>
		<p>填写文章的 id 值，以及该文章跳转的目标 URL ，例如文章的网址是：http://www.12580sky.com/?post=1502 ，想把这个文章跳转到网址<a href="http://www.weifenshi.com/" target="_blank">http://www.weifenshi.com/</a> ，那么下面表单中id就是1502，URL就是 <a href="http://www.weifenshi.com/" target="_blank">http://www.weifenshi.com/</a></p>

		<h4>2.删除：</h4>
		<p>直接清空id和URL，然后点击保存设置按钮即可</p>

		<h4>3.添加：</h4>
		<p>点击添加跳转按钮，输入对应的id和URL，然后点击保存按钮即可</p>
    
    <?php
    include 'ad_jump_config.php';
    $arr_length = count($config);
    $count = 0;
    foreach($config as $log_id=>$jump_url) {
    	$count+=1;
		echo '<p>文章id</p> <input type="text" name="article_id'.$count.'" value="'.$log_id.'"> <p>广告跳转URL</p> <input type="text" name="jump_url2'.$count.'" value="'.$jump_url.'">';
	}
	?>
	<div id="input_form">
		
	</div>
	<p><div style="padding:5px 8px;background-color: #28a4ff; color:#fff;width:100px;border-radius: 3px;text-align: center;" id="click_add" onclick="add_new_ad(<?php echo $count+=1; ?>);">添加跳转</div></p>
	<p><input style="background-color: red;color: #fff;border:none; width: 100px; padding: 5px 8px;border-radius: 3px;text-align: center;" type="submit" value="保存设置"  class="button"/></p>
	</div>
</form>

<?php
function plugin_setting() {

	$newConfig = '<?php  $config = [';

	foreach ($_POST as $key => $value) 
	{
		if($value){
			if($value == intval($value) && intval($value)) {
				$newConfig = $newConfig."'".$value."'=>'";
			}
			else{
				$newConfig = $newConfig.$value."',";
			}
		}
	}

	$newConfig = $newConfig."]; ?>";
	
	@file_put_contents(EMLOG_ROOT.'/content/plugins/ad_jump/ad_jump_config.php', $newConfig);
}