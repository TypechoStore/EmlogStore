<?php
/*
 Plugin Name: 蓝叶下载引用样式插入工具
 Version: 2.0
 Plugin URL: http://lanyes.org/zuopin/591.html
 Description: 这是一个编辑器加强插件，激活后在发布文章页面编辑器上方会看到按钮，点击就会显示了；更新2.0版本加入更多样式。
 ForEmlog:5.3.0
 Author: 蓝叶
 Author Email: w@lanyes.org
 Author URL: http://lanyes.org
*/
!defined('EMLOG_ROOT') && exit('access deined!');
function lanyefujian(){?>
<!--如果你不懂代码请勿修改以下代码，错一个符号就全乱了。-->
<script>
$(document).ready(function(){
	$("#fjbox #fjcharu").click(function(){
		if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
			layedit.setContent(contentLayUIEditor,layedit.getContent(contentLayUIEditor)+"<p class='fujian'><strong>"+($('#mingzi').val())+"：</strong><a href='"+($('#dizhi').val())+"' target='_blank' rel='nofollow'>"+($('#namee').val())+"</a> &nbsp;&nbsp;大小："+($('#daxiao').val())+"</p>",false);
		}else{
			$($(".ke-edit-iframe:first").contents().find(".ke-content")).append("<p class='fujian'><strong>"+($('#mingzi').val())+"：</strong><a href='"+($('#dizhi').val())+"' target='_blank' rel='nofollow'>"+($('#namee').val())+"</a> &nbsp;&nbsp;大小："+($('#daxiao').val())+"</p>");
		}
	});
	//下载样式二插入
    $("#fjbox_b #fjcharu").click(function(){
		if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
			layedit.setContent(contentLayUIEditor,layedit.getContent(contentLayUIEditor)+"<p><a title='"+($('#namee_b').val())+"' href='"+($('#dizhi_b').val())+"' target='_blank' rel='nofollow'><img src='<?php echo BLOG_URL;?>content/plugins/Lanye_downstyle/down_02.gif' width='164' height='46' alt='"+($('#namee_b').val())+"' /></a></p>",false);
		}else{
			$($(".ke-edit-iframe:first").contents().find(".ke-content")).append("<p><a title='"+($('#namee_b').val())+"' href='"+($('#dizhi_b').val())+"' target='_blank' rel='nofollow'><img src='<?php echo BLOG_URL;?>content/plugins/Lanye_downstyle/down_02.gif' width='164' height='46' alt='"+($('#namee_b').val())+"' /></a></p>");
		}
    
	});
	//下载样式三插入
    $("#fjbox_c #fjcharu").click(function(){
		if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
			layedit.setContent(contentLayUIEditor,layedit.getContent(contentLayUIEditor)+"<p><a title='"+($('#namee_c').val())+"' href='"+($('#dizhi_c').val())+"' target='_blank' rel='nofollow'><img src='<?php echo BLOG_URL;?>content/plugins/Lanye_downstyle/down_03.gif' width='120' height='35' alt='"+($('#namee_c').val())+"' /></a></p>",false);
		}else{
			$($(".ke-edit-iframe:first").contents().find(".ke-content")).append("<p><a title='"+($('#namee_c').val())+"' href='"+($('#dizhi_c').val())+"' target='_blank' rel='nofollow'><img src='<?php echo BLOG_URL;?>content/plugins/Lanye_downstyle/down_03.gif' width='120' height='35' alt='"+($('#namee_c').val())+"' /></a></p>");
		}
	});
	//自定义下载插入
    $("#fjbox_d #fjcharu").click(function(){
		if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
			layedit.setContent(contentLayUIEditor,layedit.getContent(contentLayUIEditor)+"<p><a title='"+($('#namee_d').val())+"' href='"+($('#dizhi_d').val())+"' target='_blank' rel='nofollow'><img src='"+($('#tupian_d').val())+"' width='"+($('#kuandu_d').val())+"' height='"+($('#gaodu_d').val())+"' alt='"+($('#namee_d').val())+"' /></a></p>",false);
		}else{
			$($(".ke-edit-iframe:first").contents().find(".ke-content")).append("<p><a title='"+($('#namee_d').val())+"' href='"+($('#dizhi_d').val())+"' target='_blank' rel='nofollow'><img src='"+($('#tupian_d').val())+"' width='"+($('#kuandu_d').val())+"' height='"+($('#gaodu_d').val())+"' alt='"+($('#namee_d').val())+"' /></a></p>");
		}
	});
	//引用样式一插入
	$("#flashbox #flcharu").click(function(){
		if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
			layedit.setContent(contentLayUIEditor,layedit.getContent(contentLayUIEditor)+"<p class='yinyong'>"+($('#daima').val())+"</p>",false);
		}else{
			$($(".ke-edit-iframe:first").contents().find(".ke-content")).append("<p class='yinyong'>"+($('#daima').val())+"</p>");
		}
	});
	//引用样式二插入
	$("#flashbox_b #flcharu").click(function(){
		if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
			layedit.setContent(contentLayUIEditor,layedit.getContent(contentLayUIEditor)+"<p class='gray'>"+($('#daima_b').val())+"</p>",false);
		}else{
			$($(".ke-edit-iframe:first").contents().find(".ke-content")).append("<p class='gray'>"+($('#daima_b').val())+"</p>");
		}
	});
	//引用样式三插入
	$("#flashbox_c #flcharu").click(function(){
		if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
			layedit.setContent(contentLayUIEditor,layedit.getContent(contentLayUIEditor)+"<p class='yellow'>"+($('#daima_c').val())+"</p>",false);
		}else{
			$($(".ke-edit-iframe:first").contents().find(".ke-content")).append("<p class='yellow'>"+($('#daima_c').val())+"</p>");
		}
	});
	//引用样式四插入
	$("#flashbox_d #flcharu").click(function(){
		if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
			layedit.setContent(contentLayUIEditor,layedit.getContent(contentLayUIEditor)+"<p class='red'>"+($('#daima_d').val())+"</p>",false);
		}else{
			$($(".ke-edit-iframe:first").contents().find(".ke-content")).append("<p class='red'>"+($('#daima_d').val())+"</p>");
		}
	});
	//引用样式五插入
	$("#flashbox_e #flcharu").click(function(){
		if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
			layedit.setContent(contentLayUIEditor,layedit.getContent(contentLayUIEditor)+"<p class='blue'>"+($('#daima_e').val())+"</p>",false);
		}else{
			$($(".ke-edit-iframe:first").contents().find(".ke-content")).append("<p class='blue'>"+($('#daima_e').val())+"</p>");
		}
	});
	//引用样式六插入
	$("#flashbox_f #flcharu").click(function(){
		if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
			layedit.setContent(contentLayUIEditor,layedit.getContent(contentLayUIEditor)+"<p class='green'>"+($('#daima_f').val())+"</p>",false);
		}else{
			$($(".ke-edit-iframe:first").contents().find(".ke-content")).append("<p class='green'>"+($('#daima_f').val())+"</p>");
		}
	});
  //下载样式一标题点击效果
  $("#crfj").click(function(){
  $(this).css({"background":"#9c3","color":"#fff"});
  $("#crfj_b,#crfj_c,#crfj_d,#crflash,#crflash_b,#crflash_c,#crflash_d,#crflash_f,#crflash_e").css({"background":"#fff","color":"#000"});
  $("#flashbox,#flashbox_b,#flashbox_c,#flashbox_d,#flashbox_e,#flashbox_f,#fjbox_b,#fjbox_c,#fjbox_d").css("display","none");
  $("#fjbox").css("display","block");
  }); 
  //下载样式二标题点击效果
  $("#crfj_b").click(function(){
  $(this).css({"background":"#9c3","color":"#fff"});
  $("#crfj,#crfj_c,#crfj_d,#crflash,#crflash_b,#crflash_c,#crflash_d,#crflash_f,#crflash_e").css({"background":"#fff","color":"#000"});
  $("#flashbox,#flashbox_b,#flashbox_c,#flashbox_d,#flashbox_e,#flashbox_f,#fjbox,#fjbox_c,#fjbox_d").css("display","none");
  $("#fjbox_b").css("display","block");
  }); 
  //下载样式三标题点击效果
  $("#crfj_c").click(function(){
  $(this).css({"background":"#9c3","color":"#fff"});
  $("#crfj,#crfj_b,#crfj_d,#crflash,#crflash_b,#crflash_c,#crflash_d,#crflash_f,#crflash_e").css({"background":"#fff","color":"#000"});
  $("#flashbox,#flashbox_b,#flashbox_c,#flashbox_d,#flashbox_e,#flashbox_f,#fjbox_b,#fjbox,#fjbox_d").css("display","none");
  $("#fjbox_c").css("display","block");
  }); 
  //下载样式四标题点击效果
  $("#crfj_d").click(function(){
  $(this).css({"background":"#9c3","color":"#fff"});
  $("#crfj,#crfj_c,#crfj_b,#crflash,#crflash_b,#crflash_c,#crflash_d,#crflash_f,#crflash_e").css({"background":"#fff","color":"#000"});
  $("#flashbox,#flashbox_b,#flashbox_c,#flashbox_d,#flashbox_e,#flashbox_f,#fjbox_b,#fjbox,#fjbox_c").css("display","none");
  $("#fjbox_d").css("display","block");
  }); 
  //引用样式一标题点击效果
  $("#crflash").click(function(){
  $(this).css({"background":"#9c3","color":"#fff"});
  $("#crfj,#crfj_b,#crfj_c,#crfj_d,#crflash_b,#crflash_c,#crflash_d,#crflash_f,#crflash_e").css({"background":"#fff","color":"#000"});
  $("#flashbox_b,#flashbox_c,#flashbox_d,#flashbox_e,#flashbox_f,#fjbox,#fjbox_b,#fjbox_c,#fjbox_d").css("display","none");
  $("#flashbox").css("display","block");
  });   
  //引用样式二标题点击效果
  $("#crflash_b").click(function(){
  $(this).css({"background":"#9c3","color":"#fff"});
  $("#crfj,#crfj_b,#crfj_c,#crfj_d,#crflash,#crflash_c,#crflash_d,#crflash_f,#crflash_e").css({"background":"#fff","color":"#000"});
  $("#flashbox,#flashbox_c,#flashbox_d,#flashbox_e,#flashbox_f,#flashbox_c,#flashbox_d,#flashbox_e,#flashbox_f,#fjbox,#fjbox_b,#fjbox_c,#fjbox_d").css("display","none");
  $("#flashbox_b").css("display","block");
  });
  //引用样式三标题点击效果
  $("#crflash_c").click(function(){
  $(this).css({"background":"#9c3","color":"#fff"});
  $("#crfj,#crfj_b,#crfj_c,#crfj_d,#crflash,#crflash_b,#crflash_d,#crflash_f,#crflash_e").css({"background":"#fff","color":"#000"});
  $("#flashbox,#flashbox_b,#flashbox_d,#flashbox_e,#flashbox_f,#flashbox_b,#flashbox_d,#flashbox_e,#flashbox_f,#fjbox,#fjbox_b,#fjbox_c,#fjbox_d").css("display","none");
  $("#flashbox_c").css("display","block");
  });
  ////引用样式四标题点击效果
  $("#crflash_d").click(function(){
  $(this).css({"background":"#9c3","color":"#fff"});
  $("#crfj,#crfj_b,#crfj_c,#crfj_d,#crflash,#crflash_c,#crflash_b,#crflash_f,#crflash_e").css({"background":"#fff","color":"#000"});
  $("#flashbox,#flashbox_b,#flashbox_c,#flashbox_e,#flashbox_f,#flashbox_c,#flashbox_b,#flashbox_e,#flashbox_f,#fjbox,#fjbox_b,#fjbox_c,#fjbox_d").css("display","none");
  $("#flashbox_d").css("display","block");
  });
  //引用样式五标题点击效果
  $("#crflash_e").click(function(){
  $(this).css({"background":"#9c3","color":"#fff"});
  $("#crfj,#crfj_b,#crfj_c,#crfj_d,#crflash,#crflash_c,#crflash_d,#crflash_f,#crflash_b").css({"background":"#fff","color":"#000"});
  $("#flashbox,#flashbox_b,#flashbox_c,#flashbox_d,#flashbox_f,#flashbox_c,#flashbox_d,#flashbox_b,#flashbox_f,#fjbox,#fjbox_b,#fjbox_c,#fjbox_d").css("display","none");
  $("#flashbox_e").css("display","block");
  });
  //引用样式五标题点击效果
  $("#crflash_f").click(function(){
  $(this).css({"background":"#9c3","color":"#fff"});
  $("#crfj,#crfj_b,#crfj_c,#crfj_d,#crflash,#crflash_c,#crflash_d,#crflash_b,#crflash_e").css({"background":"#fff","color":"#000"});
  $("#flashbox,#flashbox_b,#flashbox_c,#flashbox_d,#flashbox_e,#flashbox_c,#flashbox_d,#flashbox_e,#flashbox_b,#fjbox,#fjbox_b,#fjbox_c,#fjbox_d").css("display","none");
  $("#flashbox_f").css("display","block");
  });
  //关闭按钮
  $("#fjbox #close,#fjbox_b #close,#fjbox_c #close,#fjbox_d #close").click(function(){
  $("#lycon").css("display","none");}); 
  $("#flashbox #close,#flashbox_b #close,#flashbox_c #close,#flashbox_d #close,#flashbox_e #close,#flashbox_f #close").click(function(){
  $("#lycon").css("display","none");}); 
  $("#lytitle").click(function(){
  $("#lycon").css("display","block");}); 

});
</script>
<style>
#lybox{font-weight:bold; font-family:Arial;font-size:12px;margin:5px 0; cursor:pointer;}
#lybox #lytitle{background: url(<?php echo BLOG_URL;?>content/plugins/Lanye_downstyle/2000.png) no-repeat -5px 3px;
padding-left: 8px;}
#lybox #lycon{font-weight:normal;margin:5px 0 10px 0;display:none;border: 1px solid #ccc;padding: 10px;width:450px;}
#lybox #lycon p{margin:0 0 5px 0;font-size:14px;}
#lybox #lycon input{width:225px;font-size:12px;}
#lybox #lycon span{cursor: pointer;border: 1px solid #ccc;padding: 5px 10px;font-size: 12px;margin: 0 10px 0 0;}
#lybox #lycon span:hover{background:#00aff0 !important;color:#fff !important;}
#lybox #lycon #crfj{background:#9c3;color:#fff;}
</style>
<div id="lybox">
<div id="lytitle">蓝叶下载引用样式</div> 
<div id="lycon">
<p style="margin-bottom:15px;"><span id="crfj">下载样式一</span><span id="crfj_b">下载样式二</span><span id="crfj_c">下载样式三</span><span id="crfj_d">自定义下载</span><span id="crflash">引用样式一</span></p><p style="margin-bottom:10px;"><span id="crflash_b">引用样式二</span><span id="crflash_c">引用样式三</span><span id="crflash_d">引用样式四</span><span id="crflash_f">引用样式五</span><span id="crflash_e">引用样式六</span></p>
<div id="fjbox">
<p>下载来源：<input name="mingzi" id="mingzi" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例如：百度网盘</b></p>
<p>文件名称：<input name="namee" id="namee" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例子：网页素材下载</b></p>
<p>下载地址：<input name="dizhi" id="dizhi" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例子：http://baidu.com</b></p>
<p>文件大小：<input name="daxiao" id="daxiao" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例子：10MB</b></p>
<p style="margin: 10px 0 0 70px;"><span id="fjcharu" style="cursor:pointer;">插入</span> <span id="close" style="cursor:pointer;">关闭</span></p></div>
<!--下载样式二编辑框-->
<div id="fjbox_b" style="display:none">
<p>文件名称：<input name="namee_b" id="namee_b" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例子：网页素材下载</b></p>
<p>下载地址：<input name="dizhi_b" id="dizhi_b" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例子：http://baidu.com</b></p>
<p style="margin: 10px 0 0 70px;"><span id="fjcharu" style="cursor:pointer;">插入</span> <span id="close" style="cursor:pointer;">关闭</span></p></div>
<!--下载样式三编辑框-->
<div id="fjbox_c" style="display:none">
<p>文件名称：<input name="namee_c" id="namee_c" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例子：网页素材下载</b></p>
<p>下载地址：<input name="dizhi_c" id="dizhi_c" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例子：http://baidu.com</b></p>
<p style="margin: 10px 0 0 70px;"><span id="fjcharu" style="cursor:pointer;">插入</span> <span id="close" style="cursor:pointer;">关闭</span></p></div>
<!--下载样式四编辑框-->
<div id="fjbox_d" style="display:none">
<p>图片宽度：<input name="kuandu_d" id="kuandu_d" value="" style="width:50px" /> 图片高度：<input style="width:50px" name="gaodu_d" id="gaodu_d" value="" /></p>
<p>图片地址：<input name="tupian_d" id="tupian_d" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">说明：自定义图片地址</b></p>
<p>文件名称：<input name="namee_d" id="namee_d" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例子：网页素材下载</b></p>
<p>下载地址：<input name="dizhi_d" id="dizhi_d" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例子：http://baidu.com</b></p>
<p style="margin: 10px 0 0 70px;"><span id="fjcharu" style="cursor:pointer;">插入</span> <span id="close" style="cursor:pointer;">关闭</span></p></div>
<!--引用一编辑框-->
<div id="flashbox" style="display:none">
<p><textarea name="daima" id="daima" value="" style="width:375px;height:150px" /></textarea></p>
<p style="margin: 10px 0 0 70px;"><span id="flcharu" style="cursor:pointer;">插入</span> <span id="close" style="cursor:pointer;">关闭</span></p></div>
<!--引用二编辑框-->
<div id="flashbox_b" style="display:none">
<p><textarea name="daima_b" id="daima_b" value="" style="width:375px;height:150px" /></textarea></p>
<p style="margin: 10px 0 0 70px;"><span id="flcharu" style="cursor:pointer;">插入</span> <span id="close" style="cursor:pointer;">关闭</span></p></div>
<!--引用三编辑框-->
<div id="flashbox_c" style="display:none">
<p><textarea name="daima_c" id="daima_c" value="" style="width:375px;height:150px" /></textarea></p>
<p style="margin: 10px 0 0 70px;"><span id="flcharu" style="cursor:pointer;">插入</span> <span id="close" style="cursor:pointer;">关闭</span></p></div>
<!--引用四编辑框-->
<div id="flashbox_d" style="display:none">
<p><textarea name="daima_d" id="daima_d" value="" style="width:375px;height:150px" /></textarea></p>
<p style="margin: 10px 0 0 70px;"><span id="flcharu" style="cursor:pointer;">插入</span> <span id="close" style="cursor:pointer;">关闭</span></p></div>
<!--引用五编辑框-->
<div id="flashbox_e" style="display:none">
<p><textarea name="daima_e" id="daima_e" value="" style="width:375px;height:150px" /></textarea></p>
<p style="margin: 10px 0 0 70px;"><span id="flcharu" style="cursor:pointer;">插入</span> <span id="close" style="cursor:pointer;">关闭</span></p></div>
<!--引用六编辑框-->
<div id="flashbox_f" style="display:none">
<p><textarea name="daima_f" id="daima_f" value="" style="width:375px;height:150px" /></textarea></p>
<p style="margin: 10px 0 0 70px;"><span id="flcharu" style="cursor:pointer;">插入</span> <span id="close" style="cursor:pointer;">关闭</span></p></div>
</div></div>
<?php }
addAction('adm_writelog_head', 'lanyefujian');

function lanyefj_css(){?>
<style>.yinyong {text-align:left !important;text-indent:2em !important;margin:10px 0 1em 0 !important;padding: 5px 10px!important;border: 1px dashed #CCC!important;background: #f7f7f7 url(<?php echo BLOG_URL;?>content/plugins/Lanye_downstyle/yinyongbg.png) right top no-repeat !important;color: #000 !important;font-size: 13px !important;line-height:22px !important;}
.fujian {text-align:left !important;text-indent:0 !important;padding:0 0 0 32px !important;width: auto !important;background-image: url(<?php echo BLOG_URL;?>content/plugins/Lanye_downstyle/down_01.png) !important;background-position: left top !important;
background-repeat: no-repeat !important;color: white !important;font-weight: bold !important;font-size: 15px !important;height: 32px !important;line-height: 32px !important;background-color: #F90 !important;margin: 10px 0 !important;box-shadow: 1px 2px 1px #999 !important;}
.fujian a{color:#fff !important; font-family:"Microsoft Yahei" !important;}
.fujian:hover{background-color:#00aff0 !important}
.gray{margin:20px 0px !important;padding:15px 15px 15px 70px !important;font-size:12px !important;background:url(<?php echo BLOG_URL;?>content/plugins/Lanye_downstyle/checklist.png) no-repeat 20px 20px #f6f5f5;border:1px solid #cccccc !important;color:#555 !important;border-radius:8px} 
.yellow {margin:20px 0px !important;padding:15px 15px 15px 70px !important;font-size:12px !important;background:url(<?php echo BLOG_URL;?>content/plugins/Lanye_downstyle/warning.png) no-repeat 20px 20px #fff9c6;border:1px solid #fbe951 !important;color:#cba200 !important;border-radius:8px} 
.green {margin:20px 0px !important;padding:15px 15px 15px 70px !important;font-size:12px !important;background:url(<?php echo BLOG_URL;?>content/plugins/Lanye_downstyle/yes.png) no-repeat 20px 20px #EBF6E0;border:1px solid #b7ec82 !important;color:#649505 !important;border-radius:8px} 
.blue {margin:20px 0px !important;padding:15px 15px 15px 70px !important;font-size:12px !important;background:url(<?php echo BLOG_URL;?>content/plugins/Lanye_downstyle/info.png) no-repeat 20px 20px #c3e5ff;border:1px solid #8accff !important;color:#0d70bb !important;border-radius:8px} 
.red {margin:20px 0px !important;padding:15px 15px 15px 70px !important;font-size:12px !important;background:url(<?php echo BLOG_URL;?>content/plugins/Lanye_downstyle/noway.png) no-repeat 20px 20px #FFE9E9;border:1px solid #ffacac !important;color:#bd0000 !important;border-radius:8px} 
</style>
<?php }
addAction('index_footer', 'lanyefj_css');