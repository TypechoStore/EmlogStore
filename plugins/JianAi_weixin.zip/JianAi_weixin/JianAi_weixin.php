<?php
/**
 * Plugin Name: 微信简易测试插件
 * Version: 1.0.2
 * Plugin URL: http://www.gouji.org/?post=263
 * Description: 以用户所发送的内容为 搜索 关键词 返回相关文章
 * Author: 简爱
 * Author Email: sc.419@qq.com
 * Author URL: http://www.gouji.org/
 * Date: 20140412
 * 使用方法:
 *   1. 安装本插件, 启用本插件
 *
 *   2. 登录微信公众平台 后端  功能 》高级功能 》 开发者模式
 *        填写 URL 为 http://你的博客地址/content/plugins/JianAi_weixin/JianAi_weixin.php
 *        填写 Token 为 GouJi_org
 *
 *   3. 不要再等了 估计已经对接成功了  ^_^
 *
 *   插件地址 http://www.gouji.org/?post=263
***/



if(!defined('EMLOG_ROOT')){
  require_once dirname(__FILE__) . '/../../../init.php';
  define("TOKEN", "GouJi_org");
  new JianAi_weixin();
  die;
}


class JianAi_weixin{

  public function __construct(){

    if(!($this->checkSignature())) die;
    if(isset($_GET["echostr"])){
      die($_GET["echostr"]);
    }

    $postStr = isset($GLOBALS["HTTP_RAW_POST_DATA"]) ? trim($GLOBALS["HTTP_RAW_POST_DATA"]) : '';

    if(empty($postStr)) die;
    $postObj  = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
    $fromUser = $postObj->FromUserName;
    $toUser   = $postObj->ToUserName;

    $keyword  = addslashes(htmlspecialchars(trim($postObj->Content)));
    $keyword  = str_replace(array('%', '_'), array('\%', '\_'), $keyword);
    $db = Database::getInstance();

    $sqlQueryStr = "SELECT *
FROM " . DB_PREFIX . "blog
WHERE (title LIKE '%$keyword%'
    OR content LIKE '%$keyword%')
  AND hide = 'n'
ORDER BY date DESC
LIMIT 6";
//  AND type = 'blog'

    $sql = $db->query($sqlQueryStr);

    $n=0;
    while ($row = $db->fetch_array($sql)) {
      $text = iconv_substr(strip_tags($row['content'],""),0,50,'utf-8');
      $logs[$n][] = $row['title'];
      $logs[$n][] = Url::log($row['gid']);
      $logs[$n][] = $text;

      @ preg_match_all('/<img.*?(?: |\\t|\\r|\\n)?src=[\'"]?(.+?)[\'"]?(?:(?: |\\t|\\r|\\n)+.*?)?>/sim', $row['content'], $match, PREG_PATTERN_ORDER);

      $img = !empty($match[1][0]) ? $match[1][0] : 'http://gouji.org/gravatar/?md5=21c5ced0727c0761757e980c75388f72&s=200';
      $logs[$n][] = $img;
      $n++;
    }
    if(!isset($logs) || empty($logs)){
      $logs = array(
        array('没有找到相关文章', BLOG_URL, '没有找到相关文章', BLOG_URL .'content/plugins/JianAi_weixin/no.png'),
        array('微信测试插件 For EMLOG','http://gouji.org/%E5%BE%AE%E4%BF%A1%E7%AE%80%E6%98%93%E6%B5%8B%E8%AF%95%E6%8F%92%E4%BB%B6-for-emlog/','微信测试插件 For EMLOG','http://www.gouji.org/gravatar/?s=300&md5=21c5ced0727c0761757e980c75388f72')
      );
    }

    $textTpl = "<xml>
<ToUserName><![CDATA[%s]]></ToUserName>
<FromUserName><![CDATA[%s]]></FromUserName>
<CreateTime>%s</CreateTime>
<MsgType><![CDATA[%s]]></MsgType>
<ArticleCount>%s</ArticleCount>
<Articles>
";
    $resultStr = sprintf($textTpl, $fromUser, $toUser, time(), "news", count($logs));

    foreach($logs as $k => $v){
      $textTpl = "<item>
<Title><![CDATA[%s]]></Title>
<Description><![CDATA[%s]]></Description>
<PicUrl><![CDATA[%s]]></PicUrl>
<Url><![CDATA[%s]]></Url>
</item>
";
      list($title, $url, $description, $pic) = $v;
      $resultStr .= sprintf($textTpl, $title, $description, $pic, $url);
    }

    $resultStr .= "</Articles>
</xml>";

    echo $resultStr;
    die;
  }

  private function checkSignature(){
    $signature = $_GET["signature"];
    $timestamp = $_GET["timestamp"];
    $nonce = $_GET["nonce"];

    $token = TOKEN;
    $tmpArr = array($token, $timestamp, $nonce);
    sort($tmpArr, SORT_STRING);
    $tmpStr = implode( $tmpArr );
    $tmpStr = sha1( $tmpStr );

    if( $tmpStr == $signature ){
      return true;
    }else{
      return false;
    }
  }
}

?>