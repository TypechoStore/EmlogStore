<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	  </div>
	  <!-- main-central -->
	  <aside class="main-right main-mod">

<?php echo widget_hotlog($title); ?>
		<div class="style img-item">
		  <img alt="" src="<?php echo _g("bg");?>" class="">
		</div>
<?php echo widget_link($title); ?>
	  </aside>
	  <!-- main-right -->
	</div>
	<!-- main -->
  </div>
</div>
<!-- container -->
<footer class="footer">
  <div class="width">
    <div class="footer-content">
      <p>版权所有 © 2019 <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a>
	  <br>Theme <a href="" target="_blank">Null_origin</a> By <a href="https://www.qiuzq.com" target="_blank">自醉</a> With <i class="giligili giligili-heart-o throb"></i> | All Rights Reserved
	  <br><?php echo $footer_info; ?>
    </div>
  </div>
</footer>
<!-- footer -->
</section>
<form class="js-search search-form search-form--modal" method="get" action="<?php echo BLOG_URL; ?>" role="search">
	<div class="search-form__inner">
		<div>
			<p class="micro mb-">
				输入后按回车搜索 ...
			</p>
			<i class="czs-search-l"></i>
			<input class="text-input" type="search" name="keyword" placeholder="Search" required="">
		</div>
	</div>
	<div class="search_close">
	<i class="czs-close-l"></i>
	</div>
</form>
<!-- #main -->
<script src="<?php echo TEMPLATE_URL; ?>js/main.js"></script>
<?php doAction('index_footer'); ?>
</body>
</html>