<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	    <div class="main-list">
	<?php 
    foreach($tws as $val):
    $img = empty($val['img']) ? "" : '<img src="'.BLOG_URL.$val['img'].'" class="img"/>';
    ?>
		  <article class="post style">
		    <div class="f-head">
	         <div class="f-img">
			    <img src="<?php echo _g("tx");?>">
	         </div>
		     <div class="f-info">
			         <div class="f-title nowrap">
				         <?php echo _g("name");?>
			         </div>
			         <div class="f-info-v">
				         <span class="time"><?php echo $val['date'];?></span>
			         </div>
		     </div>
		    </div>
			<div class="f-content">
			     <?php echo '<p>'.$val['t'].'</p>'.$img;?>
			</div>
		  </article>
		  <!-- main-list post -->
		  <?php endforeach;?>
		</div>
		<div class="pagenavi style">
		  <div id="pagenavi">
		    <?php echo $page_url;?>
		  </div>
		</div>
<?php include View::getView('footer');?>