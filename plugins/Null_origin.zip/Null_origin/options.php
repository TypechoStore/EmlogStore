<?php
/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
	'bg' => array(
		'type' => 'image',
		'name' => '默认头图',
		'description' => '背景图也是它',
		'values' => array(
            TEMPLATE_URL . 'images/post.jpg',
        ),
    ),
	'tx' => array(
		'type' => 'image',
		'name' => '头像',
		'values' => array(
            TEMPLATE_URL . 'images/tx.jpg',
        ),
    ),
	'name' =>array(
		'type' => 'text',
		'name' => '昵称',
		'description' => '',
		'values' => array(
			'瑾忆',
		),
	),
	'qm' => array(
		'type' => 'text',
		'name' => '个性签名',
		'description' => '建议不超过十个字',
		'default' => '突如其来的装逼让我无法呼吸',
    ),
	'grd' => array(
		'type' => 'text',
		'name' => '个人档',
		'multi' => 'true',
		'rich'=>true,
		'values' => array(
			'<li class="nowrap"><i class="iconfont czs-qq" style="color: #16c0e8;"></i>&nbsp;&nbsp;<a href="tencent://message/?uin=837233287" rel="nofollow">837233287</a></li>
              <li class="nowrap"><i class="iconfont czs-weixin" style="color: #24ef3f;"></i>&nbsp;&nbsp;qiu837233287</li>
			  <li class="nowrap"><i class="iconfont czs-home" style="color: #16c0e8;"></i>&nbsp;&nbsp;www.qiuzq.cn</li>
			  <li class="nowrap"><i class="iconfont czs-message-l" style="color: #f8c774;"></i>&nbsp;&nbsp;<a href="mailto:837233287@qq.com" rel="nofollow">837233287@qq.com</a></li>
			  <li class="nowrap"><i class="iconfont czs-caomei" style="color: #f55;"></i>&nbsp;&nbsp;草莓图标库</li>',
		),
		'description' => '在此处填写个人档的HTML。',
	),



);