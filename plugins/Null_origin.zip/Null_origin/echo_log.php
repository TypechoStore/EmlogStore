<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
	    <section class="style books">
		<header class="entry-header">
					<h1 class="title" itemprop="name"><?php echo $log_title; ?></h1>
					<div class="meta">发布于 <time itemprop="datePublished" datetime="<?php echo date('c', $date);?>"><?php echo date('Y年m月d日', $date);?></time> / <?php echo $views; ?> 次围观 / <?php echo $comnum; ?> 条评论 / <?php blog_author($author); ?></div>
		</header>
			<div class="single">
<?php echo $log_content; ?>
<?php doAction('log_related', $logData); ?>
<?php doAction('echo_log', $logData); ?>
<?php blog_tag($logid) ?>
            </div>
        </section>

<?php if($allow_remark == 'y'): ?>
        <div class="comment-container">
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<?php blog_comments($comments,$params); ?>
		</div>
<?php endif;?>
<?php
 include View::getView('footer');
?>