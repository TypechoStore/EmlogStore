<?php
/*
Template Name:Null_origin
Description:空值起源，雏形模板。
Version:1.0
ForEmlog:5.3.1
Author:瑾忆
Author Url:https://www.qiuzq.cn
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link type="<?php echo _g("tx");?>" href="<?php echo _g("tx");?>" rel="shortcut icon">
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>caomei/style.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>js/prism.css" rel="stylesheet" type="text/css" />
<script src="<?php echo TEMPLATE_URL; ?>js/prism.js"></script>
<script src="//cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/jquery.pjax.min.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/view-image.min.js"></script>
<!--[if lt IE 9]>
<script src="//cdn.bootcss.com/html5shiv/r29/html5.min.js"></script>
<script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<?php doAction('index_head'); ?>
</head>
<body>
<div id="mo-nav" class="">
	<div class="m-avatar">
		<img src="<?php echo _g("bg");?>">
	</div>
	<ul>
<?php blog_navi();?>
	</ul>
</div>
<a href="javascript:(0);" class="header-off off-overlay"></a>
<section id="main">
<header class="header">
  <section id="mobilebar">
	<div class="inner">
		<div class="col back"><a href="javascript:void(0);" class="header-btn"><span><i class="iconfont czs-menu-l"></i></span></a></div>
		<div class="col title"><?php echo $blogname; ?></div>
		<div class="col switch"><a href="javascript:;" class="js-toggle-search"><span><i class="iconfont czs-search-l"></i></span></a></div>
	</div>
  </section>
  <div class="width">
    <div class="menu">
	  <h1 class="logo"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a></h1>
      <nav class="nav">
	    <ul>
	      <?php blog_navi();?>
	    </ul>
	  </nav>
	</div>
  </div>

</header>
<!-- header -->
<div class="container">
  <div class="width">
    <div class="main">
      <aside class="main-left main-mod">
<?php echo widget_blogger($title); ?>
		<div class="style about-item">
		  <h3 class="section-title"><i class="iconfont czs-hacker"></i>&nbsp;&nbsp;个人档</h3>
		    <ul class="about_me">
              <?php echo _g("grd");?>
            </ul>
		</div>


	  </aside>
	  <!-- main-left -->
	  <div class="main-central main-mod" id="pjax">