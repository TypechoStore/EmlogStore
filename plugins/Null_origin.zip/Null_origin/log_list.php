<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php doAction('index_loglist_top'); ?>
	    <div class="main-list">
<?php 
if (!empty($logs)):
foreach($logs as $value):
$logdes = blog_tool_purecontent($value['content'],200);
$imgsrc = preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);$imgsrc = !empty($img[1]) ? $img[1][0] : '';
preg_match_all("/<img.*src=[\"'](.*)[\"']/Ui", $value['content'], $imgs);
$imgNum = count($imgs[1]);
?>
		  <article class="post style">
		  <!--div class="vipcover" style="background-image:url(<?php echo TEMPLATE_URL; ?>images/vip/star_<?php echo mt_rand(1,22);?>_pc_x2.png)"></div-->
		    <div class="f-head">
	         <div class="f-img">
			    <img src="<?php blog_photo($value['author']); ?>">
	         </div>
		     <div class="f-info">
			         <div class="f-title nowrap">
				         <a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a>
			         </div>
			         <div class="f-info-v">
				         <span class="name">@<?php blog_author($value['author']); ?></span>
			         </div>
		     </div>
		    </div>
			<div class="f-content">
			     <p><?php echo preg_replace("#\[smilies(\d+)\]#i",'',$logdes); ?></p>
				 <?php if($value['thumbs'] != ''||$imgsrc){ ?><img alt="" src="<?php if($value['thumbs'] != ''){ echo $value['thumbs']; }else{ if($imgsrc){ echo $imgsrc; }else{ echo _g('bg'); }; }; ?>" class="img"><?php } ?>
			</div>
			<div class="f-footer">
			     <i class="czs-time-l"></i> <?php echo date('Y,m,d', $value['date']); ?>&nbsp;&nbsp;<i class="czs-talk-l"></i> <?php echo $value['comnum']; ?>&nbsp;&nbsp;<i class="czs-eye-l"></i> <?php echo $value['views'];?>&nbsp;&nbsp;<i class="czs-image-l"></i> <?php echo $imgNum;?>
			</div>
		  </article>
		  <!-- main-list post -->
<?php 
endforeach;
else:
?>
<div class="no_result">
      <img src="<?php echo TEMPLATE_URL; ?>images/no_serch_box.png">
      <p class="no_res_text">你要找的被大老虎吃掉了</p>
</div>
<?php endif;?>
		</div>
		<div class="pagenavi style">
		  <div id="pagenavi">
		    <?php echo $page_url;?>
		  </div>
		</div>
<?php include View::getView('footer'); ?>