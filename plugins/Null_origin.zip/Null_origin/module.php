<?php 
/**
 * 侧边栏组件、页面模块
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
if (!function_exists('_g')) {
	emMsg('请先安装 <a href="http://www.emlog.net/plugin/144" target="_blank">模板设置插件</a>,如果已经安装请先启动。', BLOG_URL . 'admin/plugin.php');
}
?>
<?php
//统计文章总数
function count_log_all(){
$db = MySql::getInstance();
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "blog WHERE type = 'blog'");
return $data['total'];
}

//统计评论总数
function count_com_all(){
$db = MySql::getInstance();
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "comment");
return $data['total'];
}

//统计微语总数
function count_tw_all(){
$db = MySql::getInstance();
$data = $db->once_fetch_array("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "twitter");
return $data['total'];
}
//获取blog表的一条内容,$content填写表名
function blog_content($gid,$content){
    $db = MySql::getInstance();
    $sql = 'SELECT * FROM ' . DB_PREFIX . "blog WHERE gid='".$gid."'";
    $sql = $db->query($sql);
    while ($row = $db->fetch_array($sql)) {
        $content = $row[$content];
	}
    return $content;
}
?>
<?php
//获取文章首张图片 内容用
function getpostimagetop($gid){
$db = MySql::getInstance();
$sql = "SELECT * FROM ".DB_PREFIX."blog WHERE gid=".$gid."";
//die($sql);
$imgs = $db->query($sql);
$img_path = "";
while($row = $db->fetch_array($imgs)){
preg_match('|<img.*src=[\"](.*?)[\"]|', $row['content'], $img);
$rand_img = _g('bg');
$imgsrc = !empty($img[0]) ? $img[1] : $rand_img;
    }
    return $imgsrc;
}
?>
<?php

//格式化內容工具
function blog_tool_purecontent($content, $strlen = null){
        $content = str_replace('繼續閱讀>>', '', strip_tags($content));
        if ($strlen) {
            $content = subString($content, 0, $strlen);
        }
        return $content;
}
?>

<?php
//blog：导航
function blog_navi(){
    global $CACHE; 
    $navi_cache = $CACHE->readCache('navi');
    ?>
            <?php
            foreach($navi_cache as $value):
            if ($value['pid'] != 0) {
                continue;
            }
            if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):
            ?>
               <li><a href="<?php echo BLOG_URL; ?>admin/"><i class="iconfont czs-setting"></i>管理</a></li>
               <li><a href="<?php echo BLOG_URL; ?>admin/?action=logout"><i class="iconfont czs-airplane"></i>退出</a></li>
            <?php 
                continue;
            endif;
            $newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
            $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
            $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'active' : 'common';
            ?>
            <?php if (!empty($value['children']) || !empty($value['childnavi'])) :?>
            <li class="dropdown">
                <?php if (!empty($value['children'])):?>
                <a href="<?php echo $value['url']; ?>"<?php echo $newtab;?>><?php echo $value['naviname']; ?></a>
                <ul class="dropdown-menu">
                    <?php foreach ($value['children'] as $row){
                            echo '<li><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></li>';
                    }?>
                </ul>
                <?php endif;?>
                <?php if (!empty($value['childnavi'])) :?>
                <a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a>
                <ul class="dropdown-menu">
                    <?php foreach ($value['childnavi'] as $row){
                            $newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';
                            echo '<li><a href="' . $row['url'] . "\" $newtab >" . $row['naviname'].'</a></li>';
                    }?>
                </ul>
                <?php endif;?>
            </li>
            <?php else: ?>
            <li>
            <a href="<?php echo $value['url']; ?>" <?php echo $newtab;?> />
            <?php if($value['naviname']=="首页"){  ?><i class="iconfont czs-home"></i> 
             <?php }elseif($value['naviname']=="微语"){  ?><i class="iconfont czs-cup"></i>
			 <?php }elseif($value['naviname']=="留言"){  ?><i class="iconfont czs-talk"></i>  
             <?php }elseif($value['naviname']=="关于"){  ?><i class="iconfont czs-hacker"></i> 
             <?php }elseif($value['naviname']=="归档"){  ?><i class="iconfont czs-read"></i>  
             <?php }elseif($value['naviname']=="相册" || $value['naviname']=="微图册" ){  ?><i class="iconfont czs-image"></i> 
             <?php }elseif($value['naviname']=="友链"){  ?><i class="iconfont czs-link-l"></i>   
             <?php }elseif($value['naviname']=="登录"){  ?><i class="iconfont czs-lock"></i>
             <?php }else{  ?><i class="iconfont czs-doc-file"></i> 
            <?php } ?>
			 <?php echo $value['naviname']; ?>
			 </a>
            </li>
 <?php endif;?>
<?php endforeach; ?>
<?php }?>

<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
	<span class="h-categories"><a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>" rel="category tag"><?php echo $log_cache_sort[$blogid]['name']; ?></a></span>
	<?php endif;?>
<?php }?>
<?php
//blog：文章标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "#<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
		}
		echo '<div class="hr-short"></div><div class="post-tags">'.$tag.'</div>';
	}
}
?>

<?php
//blog：文章作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<a href="'.Url::author($uid)."\" $title>$author</a>";
}
?>
<?php
//blog：文章作者头像
function blog_photo($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$photo = BLOG_URL.$user_cache[$uid]['avatar'];
	echo $photo;
}
?>
<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>
<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
?>
	    <div class="style user-item">
	      <div class="user-bg" style="background-image: url(<?php echo _g("bg");?>);"></div>
	      <a class="user-name" href="<?php echo BLOG_URL; ?>"><i class="iconfont czs-hacker"></i>&nbsp;<?php echo $user_cache[1]['name']; ?></a>
		  <img alt="" src="<?php if($user_cache[1]['photo']['src']){echo BLOG_URL.$user_cache[1]['photo']['src'];}else{echo _g("tx");}?>" class="user-avatar" height="60" width="60">
	      <p class="user_des"><?php if($user_cache[1]['des']){echo $user_cache[1]['des'];}else{echo _g("qm");}?></p>
	      <div class="user_info">
		    <li class="ptnum"><?php echo count_log_all();?><span>文章</span></li>
		    <li class="frinum"><?php echo count_com_all();?><span>评论</span></li>
		    <li class="vitnum"><?php echo count_tw_all();?><span>微语</span></li>
	      </div>
        </div>
<?php }?>
<?php
//widget：热门文章
function widget_hotlog($title){
    $index_hotlognum = Option::get('index_hotlognum');
    $Log_Model = new Log_Model();
    $hotLogs = $Log_Model->getHotLog($index_hotlognum);?> 
		<div class="style hot-item">
		  <h3 class="section-title"><i class="iconfont czs-bar-chart"></i>&nbsp;&nbsp;热门文章</h3>
		  <ul class="hot-views">
		    <?php foreach($hotLogs as $value): ?>
		    <li class="views-list"><h4 class="title nowrap"><a href="<?php echo Url::log($value['gid']); ?>">#&nbsp;<?php echo $value['title']; ?></a></h4><div class="meta"><?php echo blog_content($value['gid'],'views');?> 次围观</div></li>
		    <?php endforeach; ?>
		  </ul>
		</div>   
<?php }?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
	shuffle($link_cache);$link_cache = array_slice($link_cache,0,100);
	?>
		<div class="style links-item">
		  <h3 class="section-title"><i class="iconfont czs-link-l"></i>&nbsp;&nbsp;友情链接</h3>
		  <div class="links">
<?php foreach($link_cache as $value): ?>
<a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a>
<?php endforeach; ?>
		  </div>
		</div>
<!-- #link -->
<?php }?>





<?php
//blog-tool:获取qq头像
function eflyGravatar($email) {
	$hash = md5(strtolower($email));
	$avatar = 'https://secure.gravatar.com/avatar/' . $hash . '?s=100&d=monsterid';
	if(empty($email)){
		$eflyGravatar = TEMPLATE_URL.'images/avatar.jpg';
	}
	else if(strpos($email,'@qq.com')){
		$qq = str_replace("@qq.com","",$email);
		if(is_numeric($qq) && strlen($qq) > 4 && strlen($qq) < 13){
			$eflyGravatar = 'https://q2.qlogo.cn/headimg_dl?dst_uin='.$qq.'&spec=100';
		}
		else{
			$eflyGravatar = $avatar;
		}
	}
	else{
		$eflyGravatar = $avatar;
	}
	return $eflyGravatar;
}
?>
<?php
//blog：评论列表
function blog_comments($comments,$params){
    extract($comments);
    if($commentStacks): ?>

	<?php endif; ?>
		  <ol class="comment-lists">
	<?php
	$isGravatar = Option::get('isgravatar');
	$comnum = count($comments);  
   foreach($comments as $value){  
   if($value['pid'] != 0){$comnum--;}}  
   $page = isset($params[5])?intval($params[5]):1;  
   $i= $comnum - ($page - 1)*Option::get('comment_pnum'); 
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
		    <li class="comment-list style" id="comment-<?php echo $comment['cid']; ?>">
			  <div class="comment-body">
		    <div class="f-head">
	         <div class="f-img">
			    <img src="<?php echo eflyGravatar($comment['mail']); ?>">
	         </div>
		     <div class="f-info">
			         <div class="f-title nowrap">
				         <?php echo $comment['poster']; ?>
						 <a rel="nofollow" class="comment-reply" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>)">@TA</a>
			         </div>
			         <div class="f-info-v">
				         <span class="time"><?php echo $comment['date']; ?></span>
			         </div>
		     </div>
		    </div>
			    <div class="comment-content">
				  <p><?php echo preg_replace("#\[smilies(\d+)\]#i",'<img src="'.TEMPLATE_URL.'images/face/$1.png" id="smilies$1" alt="表情$1"/>',$comment['content']); ?></p>
				</div>
			  </div>
			  <div class="review_form" id="content-<?php echo $comment['cid']; ?>">
			  </div>
		      <ul id="comment-ul-<?php echo $comment['cid']; ?>">
			    <?php blog_comments_children($comments, $comment['children'],$i,0); ?>
			  </ul>
		    </li>
	<?php $i--;endforeach;?>
    <div id="pagenavi">
	    <?php echo $commentPageUrl;?>
    </div>
		  </ol>
<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children,$i,$x){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	$x=$x+1; 
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	$bicomment = preg_replace("#\@瑾忆:#",'<span class="vip" style="background-color: #FFC107;">@博主:</span>',$comment['content']);
	?>
			    <li class="comment-list" id="comment-<?php echo $comment['cid']; ?>">
			  <div class="comment-body">
		    <div class="f-head">
	         <div class="f-img">
			    <img src="<?php echo eflyGravatar($comment['mail']); ?>">
	         </div>
		     <div class="f-info">
			         <div class="f-title nowrap">
				         <?php echo $comment['poster']; ?>
						 <a rel="nofollow" class="comment-reply" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>)">@TA</a>
			         </div>
			         <div class="f-info-v">
				         <span class="time"><?php echo $comment['date']; ?></span>
			         </div>
		     </div>
		    </div>
			    <div class="comment-content">
				  <p><?php echo preg_replace("#\[smilies(\d+)\]#i",'<img src="'.TEMPLATE_URL.'images/face/$1.png" id="smilies$1" alt="表情$1"/>',$comment['content']); ?></p>
				</div>
			  </div>
			  <div class="review_form" id="content-<?php echo $comment['cid']; ?>">
			  </div>
			      <ul id="comment-ul-<?php echo $comment['cid']; ?>">
			      <?php blog_comments_children($comments, $comment['children'],$i,$x); ?>
				  </ul>
				</li>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
<div id="comment-place" class="style">
	<div id="comment-post" class="comment-respond">
		<form action="<?php echo BLOG_URL; ?>index.php?action=addcom" method="post" id="commentform" class="comment-form">
			<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
			<div class="comment-main">
				<?php if(ROLE == ROLE_VISITOR): ?>
				<div class="bbbb">
					<input id="author" name="comname" type="text" value="<?php echo $ckname; ?>" size="30" maxlength="245" aria-required="true" required="required" placeholder="昵称 (必填)">
					<input id="email" name="commail" type="email" value="<?php echo $ckmail; ?>" size="30" maxlength="100" aria-describedby="email-notes" aria-required="true" required="required" placeholder="邮件地址 (必填)">
					<input id="url" name="comurl" type="url" value="<?php echo $ckurl; ?>" size="30" maxlength="200" placeholder="个人主页 (选填)">
				</div>
				<?php endif; ?>
				<div class="bbq">
					<div class="fload-left">
						<img src="<?php if(ROLE == ROLE_VISITOR){ echo TEMPLATE_URL.'/images/avatar.jpg'; }else{ echo _g("tx"); }; ?>" class="ajaxurl">
					</div>
					<div class="fload-right">
						<textarea id="comment" name="comment" cols="45" rows="8" maxlength="6666" aria-required="true" required="required" placeholder="既然来了就说点什么吧..."></textarea>
					</div>
				</div>
				<div class="bbbb">
					<?php if(SEND_MAIL == 'Y' || REPLY_MAIL == 'Y'){ ?>
					<label class="demo--label">
					<input class="demo--radio" value="y" type="checkbox" name="send" checked>
					<span class="demo--checkbox demo--radioInput"></span>允许邮件通知
					</label>
					<?php } ?>
					<span class="OwO">
					<div class="OwO-logo">
						<span>OwO</span>
					</div>
					<div class="OwO-body">
						<ul class="OwO-items OwO-items-biaoqing OwO-items-show" style="max-height: 100px;">
							<?php for($i = 1; $i <= 39; $i++): ?>
							<a class="OwO-item" data-action="addSmily" data-smilies="smilies<?php echo $i; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/face/<?php echo $i; ?>.png"></a>
							<?php endfor; ?>
						</ul>
					</div>
					</span>
				</div>
				<div class="wantcom" style="text-align: center;"></div>
				<div class="bbbb">
					<a rel="nofollow" class="btn" id="cancel-reply" href="javascript:void(0);" onclick="cancelReply()" style="display:none;"> 取消回复</a>
					<button class="btn" name="submit" type="submit" id="submit">提交评论</button>
					<input type="hidden" name="pid" id="comment-pid" value="0"/>
				</div>
			</div>
		</form>
	</div>
</div>
	<?php endif; ?>
<?php }?>