<?php defined('EMLOG_ROOT') or die('本页面禁止直接访问!');
	define('CDN_HOST','http://your-bucket.qiniudn.com');
	define('LOCAL_HOST','http://your-domain.com');
	define('CDN_EXTS','js|css|png|jpg|jpeg|gif|ico');
	define('COMPRESSED','1');
?>