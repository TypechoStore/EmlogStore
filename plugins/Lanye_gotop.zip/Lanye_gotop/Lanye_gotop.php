<?php
/*
Plugin Name: 丫头返回顶部
Version: 1.0
Plugin URL: http://lanyes.org
Description: 网站页面添加小丫头返回顶部按钮
Author: 蓝叶
Author Email: w@lanyes.org
Author URL: http://lanyes.org
*/
!defined('EMLOG_ROOT') && exit('access deined!');
emLoadJQuery();
function Lanye_gotop(){
$active_plugins = Option::get('active_plugins');
echo '<script type="text/javascript" src="'.BLOG_URL.'content/plugins/Lanye_gotop/images/seajs.js"></script>
<link href="'.BLOG_URL.'content/plugins/Lanye_gotop/images/css.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">seajs.use("goback.js",function(goback){goback.F_backToTop();});</script>'."\r\n";
}
addAction('index_footer', 'Lanye_gotop');