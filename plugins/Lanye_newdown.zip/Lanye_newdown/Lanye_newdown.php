<?php
/*
 Plugin Name: 新版蓝叶下载样式插入工具
 Version: 1.2
 Plugin URL: http://lanyes.org
 Description: 这是一个编辑器加强插件，激活后在发布文章页面编辑器上方会看到按钮，点击就会显示了，已支持Emlog6.1.1。
 ForEmlog:5.3.x
 Author: 蓝叶
 Author Email: w@lanyes.org
 Author URL: http://lanyes.org
*/
!defined('EMLOG_ROOT') && exit('access deined!');
function lanyenewfujian(){?>
<!--如果你不懂代码请勿修改以下代码，错一个符号就全乱了。-->
<script>
$(document).ready(function(){
	$("#fjbox #fjcharu").click(function(){
		if(typeof($('#markdownEditor_content'))!='undefined'){
			$('#markdownEditor_content').val($('#markdownEditor_content').val()+"<div class='newfujian'><div class='fileico "+($('#file_type').val())+"'></div><div class='filecont'><div class='filetit'><a href='"+($('#dizhi').val())+"' target='_blank' rel='nofollow' title='点击下载'>"+($('#namee').val())+"</a><span>大小："+($('#daxiao').val())+" | 来源："+($('#mingzi').val())+"</span>	</div><div class='fileaq'>已经过安全软件检测无毒，请您放心下载。</div></div><div class='down_2'><a href='"+($('#dizhi').val())+"' target='_blank' rel='nofollow' title='点击下载'></a></div></div>");
		}else if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
			layedit.setContent(contentLayUIEditor,"<div class='newfujian'><div class='fileico "+($('#file_type').val())+"'></div><div class='filecont'><div class='filetit'><a href='"+($('#dizhi').val())+"' target='_blank' rel='nofollow' title='点击下载'>"+($('#namee').val())+"</a><span>大小："+($('#daxiao').val())+" | 来源："+($('#mingzi').val())+"</span>	</div><div class='fileaq'>已经过安全软件检测无毒，请您放心下载。</div></div><div class='down_2'><a href='"+($('#dizhi').val())+"' target='_blank' rel='nofollow' title='点击下载'></a></div></div>",true);
		}else{
			$($(".ke-edit-iframe:first").contents().find(".ke-content")).append("<div class='newfujian'><div class='fileico "+($('#file_type').val())+"'></div><div class='filecont'><div class='filetit'><a href='"+($('#dizhi').val())+"' target='_blank' rel='nofollow' title='点击下载'>"+($('#namee').val())+"</a><span>大小："+($('#daxiao').val())+" | 来源："+($('#mingzi').val())+"</span>	</div><div class='fileaq'>已经过安全软件检测无毒，请您放心下载。</div></div><div class='down_2'><a href='"+($('#dizhi').val())+"' target='_blank' rel='nofollow' title='点击下载'></a></div></div>");
		}
	});
	$("#close_tools").click(function(){
		$("#qx_con").slideUp(200);
	}); 
	$("#qx_title").click(function(){
		$("#qx_con").slideDown(200);
	}); 
	$("#clear_shuru").click(function(){
		$("#qx_con input").attr("value","");
	});
});
</script>
<style>
#qx_box{font-weight:bold; font-family:Arial;font-size:12px;margin:5px 0; cursor:pointer;clear:both;}
#qx_box #qx_title{background:#5bc0de;float:left;padding:5px 10px;margin-bottom:5px;float:left;clear:both;color:#fff;border-radius:4px;font-weight:normal;font-family:"Microsoft Yahei";font-size:14px;background-image: linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-size: 30px 30px;box-shadow: 0 0 4px 1px rgba(16, 160, 249, 0.3);}
#qx_box #qx_con{clear:both;float:left;font-weight:normal;margin:5px 0 10px 0;display:none;border: 1px solid #ccc;padding: 10px;width:450px;border-radius: 4px;}
#qx_box #qx_con p{margin:0 0 10px 0;font-size:14px;}
#qx_box #qx_con input{width:210px;font-size:12px;padding:5px;border-radius:4px;outline:none;border: 1px solid #ccc;}
#qx_box #qx_con input:-webkit-autofill{background:#fff;}
#qx_box #qx_con span{float:left;cursor:pointer;border:0;padding:10px 15px;font-size: 12px;margin: 0 10px 0 0;border-radius:4px;color:#fff;background-image: linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-size: 30px 30px;box-shadow: 0 0 4px 1px rgba(16, 160, 249, 0.3);}
#qx_box #qx_con span:hover{background:#00aff0 !important;color:#fff !important;}
#qx_box #qx_con #crfj{background:#9c3;color:#fff;}
#qx_box #qx_con select{padding:5px;border-radius:4px;outline:none;border: 1px solid #ccc;}
input:focus,select:focus{border-color:#66afe9;outline:0;-webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);background:#fff;}
</style>
<div id="qx_box">
<div id="qx_title">蓝叶下载样式</div> 
<div id="qx_con">
<div id="fjbox">
<p>文件类型：<select name="file_type" id="file_type"><option value="rar">压缩包</option><option value="img">图片</option><option value="pdf">PDF文档</option><option value="doc">Word文档</option><option value="xls">Xls文档</option><option value="txt">文本文件</option><option value="audio">音乐文件</option><option value="video">视频文件</option><option value="ppt">PPT文件</option><option value="exe">执行文件</option><option value="apk">APK文件</option><option value="bt">BT种子</option></select>&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">选择文件类型将调用对应的图标</b></p>
<p>下载来源：<input name="mingzi" id="mingzi" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例如：百度网盘</b></p>
<p>文件名称：<input name="namee" id="namee" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例子：网页素材下载</b></p>
<p>下载地址：<input name="dizhi" id="dizhi" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例子：http://baidu.com</b></p>
<p>文件大小：<input name="daxiao" id="daxiao" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例子：10MB</b></p>
<p style="margin: 10px 0 0 70px;"><span id="fjcharu" style="background-color:#337ab7;">插入代码</span> <span id="close_tools" style="background-color:#5cb85c">关闭工具</span> <span id="clear_shuru" style="background-color:#f0ad4e">清楚内容</span></p></div>
</div></div>
<?php }
addAction('adm_writelog_head', 'lanyenewfujian');
function lanyenewfj_related($logData){
	$active_plugins = Option::get('active_plugins');
	if(in_array('markdownEditor/markdownEditor.php', $active_plugins)){
		include(EMLOG_ROOT.'/content/plugins/markdownEditor/easyeditor/libs/markdown.php');
		$db = Database::getInstance();
		$Markdown = new Markdown();
		$data=ob_get_clean();
		$rowBlog = $db->fetch_array($db->query("SELECT * FROM ".DB_PREFIX."blog WHERE gid ='".$logData["logid"]."'"));
		$content=$Markdown->convert($rowBlog["content"]);
		$data=str_replace($rowBlog['content'],$content,$data);
		ob_start();
		echo $data;
	}
}
addAction("log_related","lanyenewfj_related");
function lanyenewfj_css(){?>
<style>.newfujian{margin:10px auto;border:1px solid #cedebd;background:#fdfefb;height:44px;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px;padding:10px;overflow:hidden;}.newfujian .img{background-position: 0 0;}.newfujian .pdf{background-position: -40px 0;}.newfujian .doc{background-position: -80px 0;}.newfujian .xls{background-position: -120px 0;}.newfujian .txt{background-position: -160px 0;}.newfujian .audio{background-position: -200px 0;}.newfujian .video{background-position: -240px 0;}.newfujian .ppt{background-position: -280px 0;}.newfujian .exe{background-position: -360px 0;}.newfujian .apk{background-position: -520px 0;}.newfujian .bt{background-position:-440px 0;}.fileico{width:35px;height:44px;background: url(<?php echo BLOG_URL;?>content/plugins/Lanye_newdown/fileico.png) -400px 0;float:left;}.filecont{float:left;padding:0 0 0 10px; text-indent:0 !important;}.filecont .filetit{height:27px;font-size:14px;line-height:25px;letter-spacing:1px;font-family:"Microsoft Yahei";}.filecont .filetit span{font-size:12px;color:#999;margin-left:10px;float:left;font-family:arial;letter-spacing:0;}.filecont .filetit a{color:#666;text-decoration:none;display:block;max-width:290px;overflow:hidden;white-space:nowrap;float:left;text-overflow: ellipsis;}.filecont .filetit a:hover{text-decoration:underline;}.filecont .fileaq{height:15px;background:url(<?php echo BLOG_URL;?>content/plugins/Lanye_newdown/fileaq.png) no-repeat;padding-left:18px;font-size:12px;color:#73B010;letter-spacing:0;line-height:14px;font-family:arial;}.down_2{float:right;}.down_2 a{width:130px;height:42px;display:block;background:url(<?php echo BLOG_URL;?>content/plugins/Lanye_newdown/down_2.jpg) no-repeat -2px -1px;overflow:hidden;}.down_2 a:hover{background:url(<?php echo BLOG_URL;?>content/plugins/Lanye_newdown/down_2.jpg) no-repeat -2px -46px;}</style>
<?php }
addAction('index_footer', 'lanyenewfj_css');