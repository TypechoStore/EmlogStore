<?php
!defined('EMLOG_ROOT') && exit('access deined!');

	include_once(EMLOG_ROOT.'/content/plugins/em_comment_code/em_comment_code_config.php');
	
function plugin_setting_view()
 {
?>
<script type='text/javascript'>
$(document).ready(function(){
	$("#em_comment_code").addClass('sidebarsubmenu1');
});
setTimeout(hideActived,2600);
</script>
<div class=containertitle>
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
	  <legend>
		<b>评论扩展管理</b>
	  </legend>
	</fieldset>
</div>
<?php if(isset($_GET['setting'])):?><blockquote class="actived layui-elem-quote">插件设置完成</blockquote><?php endif;?>    
<style>
.body{padding:20px 0px;}
.body div{border:1px solid #6C6;background:#E1F8E0;padding:50px 100px;margin-top:50px;color:#000;}
.button{line-height:30px;height:30px;width:150px;margin-right:30px;}
</style>
<div class=line></div>
<div class="body">
<div>
<form id="form" name="form" method="post" action="plugin.php?plugin=em_comment_code&action=setting" >
插入代码:<label><input name="code" type="radio" value="1"  <?php if(em_comment_code==1) echo "checked=\"checked\"" ?> />开启</label><label><input name="code" type="radio" value="0"  <?php if(em_comment_code==0) echo "checked=\"checked\"" ?> />关闭</label><br />
插入链接:<label><input name="url" type="radio" value="1"  <?php if(em_comment_url==1) echo "checked=\"checked\"" ?> />开启</label><label><input name="url" type="radio" value="0"  <?php if(em_comment_url==0) echo "checked=\"checked\"" ?> />关闭</label><br />
插入图片:<label><input name="img" type="radio" value="1"  <?php if(em_comment_img==1) echo "checked=\"checked\"" ?> />开启</label><label><input name="img" type="radio" value="0"  <?php if(em_comment_img==0) echo "checked=\"checked\"" ?> />关闭</label><br />
插入附件:<label><input name="file" type="radio" value="1"  <?php if(em_comment_file==1) echo "checked=\"checked\"" ?> />开启</label><label><input name="file" type="radio" value="0"  <?php if(em_comment_file==0) echo "checked=\"checked\"" ?> />关闭</label><br />
插入视频:<label><input name="movie" type="radio" value="1"  <?php if(em_comment_movie==1) echo "checked=\"checked\"" ?> />开启</label><label><input name="movie" type="radio" value="0"  <?php if(em_comment_movie==0) echo "checked=\"checked\"" ?> />关闭</label><br />
插入QQ:<label><input name="qq" type="radio" value="1"  <?php if(em_comment_qq==1) echo "checked=\"checked\"" ?> />开启</label><label><input name="qq" type="radio" value="0"  <?php if(em_comment_qq==0) echo "checked=\"checked\"" ?> />关闭</label><br />
<!--
新浪短链接:<label><input name="sina" type="radio" value="1"  <?php if(em_comment_sianurl==1) echo "checked=\"checked\"" ?> />开启</label><label><input name="sina" type="radio" value="0"  <?php if(em_comment_sianurl==0) echo "checked=\"checked\"" ?> />关闭</label><br />
千脑帐号:<input type="text" name="qiannao" value="<?php echo em_comment_qiannao; ?>" />
<br />
-->
<br /><input type="submit" class="button" name="submit" value="保存设置" />
</form>
</div>
</div>
<div class=line></div>
<?php
 }
 
function plugin_setting()
{
	if(isset($_POST["submit"])){
	    $em_comment_code_fp = fopen(EMLOG_ROOT.'/content/plugins/em_comment_code/em_comment_code_config.php','r');
		$em_comment_code_config = fread($em_comment_code_fp,filesize(EMLOG_ROOT.'/content/plugins/em_comment_code/em_comment_code_config.php'));
		fclose($em_comment_code_fp);  
		$code= isset($_POST['code']) ? $_POST['code'] : 0;
		$url= isset($_POST['url']) ? $_POST['url'] : 0;
		$img= isset($_POST['img']) ? $_POST['img'] : 0;
		$file= isset($_POST['file']) ? $_POST['file'] : 0;
		$movie= isset($_POST['movie']) ? $_POST['movie'] : 0;
		$qq= isset($_POST['qq']) ? $_POST['qq'] : 0;
		$sina= isset($_POST['sina']) ? $_POST['sina'] : 0;
		$qiannao=isset($_POST['qiannao']) ? $_POST['qiannao'] : "qiannao";
		if($qiannao==""){
			$qiannao="qiannao";
		}
		
		$em_comment_code_patt = array(
							      "/define\('em_comment_code',(.*)\)/",
							      "/define\('em_comment_url',(.*)\)/",
								  "/define\('em_comment_img',(.*)\)/",
								  "/define\('em_comment_file',(.*)\)/",
								  "/define\('em_comment_movie',(.*)\)/",
								  "/define\('em_comment_qq',(.*)\)/",
								  "/define\('em_comment_sianurl',(.*)\)/",
								  "/define\('em_comment_qiannao',(.*)\)/"
	                             );
		$em_comment_code_replace = array(
								  "define('em_comment_code',".$code.")",
								  "define('em_comment_url',".$url.")",
								  "define('em_comment_img',".$img.")",
								  "define('em_comment_file',".$file.")",
								  "define('em_comment_movie',".$movie.")",
								  "define('em_comment_qq',".$qq.")",
								  "define('em_comment_sianurl',".$sina.")",
								  "define('em_comment_qiannao','".$qiannao."')"
								 );
		$em_comment_code_new_config = preg_replace($em_comment_code_patt, $em_comment_code_replace, $em_comment_code_config);
		$em_comment_code_new_config = iconv('gb2312', 'utf-8', $em_comment_code_new_config);   
		$em_comment_code_fp = @fopen(EMLOG_ROOT.'/content/plugins/em_comment_code/em_comment_code_config.php','w');
		@fwrite($em_comment_code_fp,$em_comment_code_new_config);
		@fclose($em_comment_code_fp);
	
}
}
?>