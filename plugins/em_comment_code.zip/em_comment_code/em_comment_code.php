<?php
/*
Plugin Name: 评论编辑扩展修改版
Version: 1.0
Plugin URL: http://www.zc520.cc/php/108.html
Description: 评论编辑扩展，基于代码高亮插件的插入代码高亮，均采用ajax方式发送请求。经二呆于2020-06-06修改，修改内容：1、因为新浪官方短址关闭，删除了此功能；2、因为千脑官方无法访问，删除了次功能，但上传图片换成了图床实现；3、插入视频支持了mp4格式；4、手机端缩小了宽度。修改备注：此次修改仅为了让功能重新实现而已，仅用Emlog资源吧模板做了测试，如有其它问题请自行解决，或前往club.tongleer.com与网友反馈。
Author: 小贤看世界
Author Email: zc@zc520.cc
Author URL: http://zc520.cc
*/

!defined('EMLOG_ROOT') && exit('access deined!');

require_once('em_comment_code_config.php');

function em_comment_code_menu()
{ 
	echo '<div class="sidebarsubmenu" id="em_comment_code"><a href="./plugin.php?plugin=em_comment_code">评论扩展</a></div>';
}
addAction('adm_sidebar_ext', 'em_comment_code_menu');//将扩展管理添加到后台菜单中

function em_comment_code(){
echo '<link rel="stylesheet" type="text/css" href ="'.BLOG_URL.'content/plugins/em_comment_code/style.css" />';
}
addAction('index_head','em_comment_code');
function em_comment_code2(){
echo "\n";
echo '<script language="javascript">';
echo 'var imagepath = "'.BLOG_URL.'content/plugins/em_comment_code/open.js/";';
echo "\n";
echo 'var em_comment_button=\'<br><span id="comment_plugins" style="margin-bottom:10px;">\';';
echo "\n";
if(em_comment_code==1){
echo "em_comment_button+='<a href=\"javascript:void(0);\" title=\"code\">插入代码</a>&nbsp;|&nbsp;';";
echo "\n";
}
if(em_comment_url==1){
echo "em_comment_button+='<a href=\"javascript:void(0);\" title=\"url\">插入链接</a>&nbsp;|&nbsp;';";
echo "\n";
}
if(em_comment_img==1){
echo "em_comment_button+='<a href=\"javascript:void(0);\" title=\"img\">插入图片</a>&nbsp;|&nbsp;';";
echo "\n";
}
if(em_comment_file==1){
echo "em_comment_button+='<a href=\"javascript:void(0);\" title=\"file\">插入附件</a>&nbsp;|&nbsp;';";
echo "\n";
}
if(em_comment_movie==1){
echo "em_comment_button+='<a href=\"javascript:void(0);\" title=\"movie\">插入视频</a>&nbsp;|&nbsp;';";
echo "\n";
}
if(em_comment_qq==1){
echo "em_comment_button+='<a href=\"javascript:void(0);\" title=\"qq\">插入QQ</a>';";
echo "\n";
}
echo 'em_comment_button+=\'</span>\';';
echo "\n";
echo '$(document).ready(function(){';
echo "\n";
echo '$("textarea[name=comment],textarea[name=reply]").after(em_comment_button);';
echo '$("#comment_plugins a").click(function(){em_comment_code(this,this.title);});';
echo "\n";
echo '});';
echo "\n";
echo '</script>';
echo "\n";
echo '<script>var BLOG_URL="'.BLOG_URL.'";</script>';
echo "\n";
echo '<script language="javascript" src="'.BLOG_URL.'content/plugins/em_comment_code/open.js/open.jquery.js" /></script>';
echo "\n";
}
addAction('index_footer','em_comment_code2');

function sinaurl($url, $key = '1335371408') {
    $opts['http'] = array('method' => "GET", 'timeout'=>60,);
    $context = stream_context_create($opts);
    $url = "http://api.t.sina.com.cn/short_url/shorten.json?source=$key&url_long=$url";
    $html =  @file_get_contents($url,false,$context);
    $url = json_decode($html,true);
    if (!empty($url[0]['url_short'])) {
        return $url[0]['url_short'];
    }
}
$sinaurl_no=em_comment_sianurl;
function urlrep($url,$type=1,$name=""){
	global $sinaurl_no;
	if(false){//$sinaurl_no==1
		  $sinaurl=sinaurl("http://".$url);
		  $text='<a href="'.$sinaurl.'" target="_blank" title="http://'.$url.'">'.$sinaurl.'</a>';
		  if($type==1){
		  return $text;
		  }else{
		  return '<span style="color:green;">附件:'.'<a href="'.$sinaurl.'" target="_blank" title="http://'.$url.'">'.$name.'</a></span>';
		  }
	}else{
		  $text='<a href="http://'.$url.'" title="http://'.$url.'" target="_blank">http://'.$url.'</a>';
		  if($type==1){
			return $text;
		  }else{
			return '<span style="color:green;">附件:<a href="http://'.$url.'" target="_blank" title="http://'.$url.'">'.$name.'</a></span>';
		  }	
	}
}

function em_comment_code_rep($str){//将代码替换成高亮代码
$code=$str;
$pat="/\[code(.*)\](.*)\[\/code\]/U";
preg_match_all($pat,$code,$arr);
$arr2=$arr[0];
$str3=preg_replace("/<br \/>/","",$arr2);
$str3=str_replace($arr2,$str3, $code);
$pat2="/\[code(.*)\](.*)\[\/code\]/";
$str=$str3;//去掉[code=*][/code]之间的br

$patterns = array ("/\[code=(java|cpp|c#|js|php|perl|python|ruby|html|xml|css|vb|pascal|scala|groovy|lua|sql|cpp|as3|sliverlight|shell)\](.*?)\[\/code\]/","/\[url\](http|https)\:\/\/(.*?)\[\/url\]/ie","/\[qq\]([0-9]+)\[\/qq\]/","/\[img\](.*?)(\.jpg|\.png|\.bmp|\.jpeg|\.gif)\[\/img\]/","/\[movie\](.*?)((\.swf|\.SWF)||(\.mp4|\.MP4))\[\/movie\]/","/\[file=(http|https)\:\/\/(.*?)\](.*?)\[\/file\]/ie"); 
$replace = array ("<pre class=\"brush:$1; toolbar: true; auto-links: true;\">$2</pre>","urlrep('\\2')",'<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=$1&site=qq&menu=yes"><img border="0" src="http://wpa.qq.com/pa?p=2:$1:46" alt="点击这里给我发消息" title="点击这里给我发消息"></a>','<a class="highslide" href="$1$2" target="_blank"><img src="'.BLOG_URL.'content/plugins/em_comment_code/img.gif" border="0"></a>','<span class="movie" title="$1$2">[点击播放]</span>',"urlrep('\\2',2,'\\3')"); 
$str=preg_replace ($patterns, $replace, $str);
return $str;
}
function em_comment_code_replace() {
	$output = ob_get_clean();
	$output = em_comment_code_rep($output);
	ob_start();
	echo $output;
}
addAction('index_footer','em_comment_code_replace');
?>