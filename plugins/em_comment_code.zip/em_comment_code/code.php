﻿<?php
include_once('../../../init.php');

if(isset($_GET["type"])){
	$type=$_GET["type"];
	$json=array();
	if($type=="code"){
	$json["msg"]=<<<EOT
<script language="javascript">
function codeinsert(){
if($("#ic_lang").val()==""){
alert("请选择编程语言");	
}else if($("#ic_source").val()==""){
alert("插入的代码不能为空");	
}else{
text=$("textarea[name=comment],textarea[name=reply]").val()+"[code="+$("#ic_lang").val()+"]"+$("#ic_source").val()+"[/code]";
$("textarea[name=comment],textarea[name=reply]").val(text);
$('.open-tit a').trigger('click');
}
}
</script>
<table border="0" cellpadding="0" cellspacing="0">
    <tr>
        <td style='padding-bottom:10px;'>
            <select id='ic_lang' name='lang' style="border:1px solid #CCC;">
                <option value=''>[请选择编程语言]</option>    		
                <option value='java'>Java</option>
                <option value='cpp'>C/C++/Objective-C</option>
                <option value='c#'>C#</option>
                <option value='js'>JavaScript</option>
                <option value='php'>PHP</option>
                <option value='perl'>Perl</option>
                <option value='python'>Python</option>
                <option value='ruby'>Ruby</option>
                <option value='html'>HTML</option>
                <option value='xml'>XML</option>
                <option value='css'>CSS</option>
                <option value='vb'>ASP/Basic</option>
                <option value='pascal'>Delphi/Pascal</option>
                <option value='scala'>Scala</option>
                <option value='groovy'>Groovy</option>
                <option value='lua'>Lua</option>
                <option value='sql'>SQL</option>
                <option value='cpp'>Google Go</option>
                <option value='as3'>Flash/ActionScript/Flex</option>
                <option value='sliverlight'>WPF/SliverLight</option>
                <option value='shell'>Shell/批处理</option>
            </select>
            以便系统进行正确的语法着色
        </td>
    </tr>
    <tr>
        <td>
            <textarea name='source' id='ic_source' style='width:300px;height:200px;border:1px solid #CCC;font-size:9pt;font-family:Courier New,Arial'></textarea>
        </td>
    </tr>
        <tr>
        <td>
        <p style="padding-left:0px;margin-left:0px;">
           <a class="button orange" style="color:#fff;" href="javascript:codeinsert();">插入代码</a></p>
        </td>
    </tr>
</table>
EOT;
	}else if($type=="qq"){
$json["msg"]=<<<EOT
<script language="javascript">
function qqinsert(){
comment=$("#comment_url").val();
if(comment=="" || isNaN(comment) || comment.length>10){
alert("请输入正确的qq号,或qq号不能为空！");	
}else{
text=$("textarea[name=comment],textarea[name=reply]").val()+"[qq]"+$("#comment_url").val()+"[/qq]";
$("textarea[name=comment],textarea[name=reply]").val(text);
$('.open-tit a').trigger('click');
}
}
</script>

<div style="padding:20px 10px;">
<input type="text" id="comment_url" value=""  style="height:30px;line-height:30px;width:300px;border:1px solid #CCC;" ondblclick="this.select()"/>
<p style="padding-left:0px;margin-left:0px;"><a class="button orange" style="color:#fff;" href="javascript:qqinsert();">插入QQ</a></p></div>
EOT;
	}else if($type=="url"){
$json["msg"]=<<<EOT
<script language="javascript">
function urlinsert(){
comment=$("#comment_url").val();
if(comment=="" || comment=="http://"){
alert("请输入超链接地址");	
}else{
text=$("textarea[name=comment],textarea[name=reply]").val()+"[url]"+$("#comment_url").val()+"[/url]";
$("textarea[name=comment],textarea[name=reply]").val(text);
$('.open-tit a').trigger('click');
}
}
function imgupload(){
$('.open-tit a').trigger('click');
}
</script>

<div style="padding:20px 10px;">
<input type="text" id="comment_url" value="http://"  style="height:30px;line-height:30px;width:300px;border:1px solid #CCC;" ondblclick="this.select()"/>
<p style="padding-left:0px;margin-left:0px;"><a class="button orange" style="color:#fff;" href="javascript:urlinsert();">插入链接</a></p></div>
EOT;
	}else if($type=="img"){
		$picbedurl=BLOG_URL."content/plugins/em_comment_code/picbed.php";
$json["msg"]=<<<EOT
<script language="javascript">
function imginsert(){
comment=$("#comment_url").val();
if(comment=="" || comment=="http://"){
alert("请输入图片的地址");	
}else{
text=$("textarea[name=comment],textarea[name=reply]").val()+"[img]"+$("#comment_url").val()+"[/img]";
$("textarea[name=comment],textarea[name=reply]").val(text);
$('.open-tit a').trigger('click');
}
}
function imgupd(id){
if(document.getElementById("uploadimg").style.display=="none"){
$('#uploadimg').slideDown();
id.innerHTML="取消上传";
}else{
$('#uploadimg').slideUp();
id.innerHTML="上传图片";
}
}
</script>

<div style="padding:20px 10px;">
<div style="font-size:14px;color:#999;padding:3px 0;">支持:jpg,png,gif,bmp,jpeg等图片</div>
<input type="text" id="comment_url" value="http://"  style="height:30px;line-height:30px;width:300px;border:1px solid #CCC;" ondblclick="this.select()"/>
<div id="uploadimg" style="display:none;margin:5px 0;">
<iframe src="$picbedurl" scrolling="no" frameborder="0"  align="center" width="300" height="50"></iframe>
</div>
<p style="padding-left:0px;margin-left:0px;"><a class="button orange" style="color:#fff;" href="javascript:imginsert();">插入图片</a>&nbsp;&nbsp;<a class="button blue" style="color:#fff;" id="updimg" href="javascript:;" onclick="imgupd(this)">上传图片</a></p>
</div>
EOT;
	}else if($type=="movie"){
$json["msg"]=<<<EOT
<script language="javascript">
function movieinsert(){
comment=$("#comment_url").val();
if(comment=="" || comment=="http://"){
alert("请输入视频的地址");	
}else if(comment.length<=14){
alert("我还没有见过这么短的视频网址呢！");	
}else if(comment.substring(comment.length-4,comment.length).toLowerCase()!=".swf"&&comment.substring(comment.length-4,comment.length).toLowerCase()!=".mp4"){
alert("请输入正确的视频地址,只支持swf和mp4格式！");
//alert(comment.substring(comment.length-4,comment.length).toLowerCase());
}else{
text=$("textarea[name=comment],textarea[name=reply]").val()+"[movie]"+$("#comment_url").val()+"[/movie]";
$("textarea[name=comment],textarea[name=reply]").val(text);
$('.open-tit a').trigger('click');
}
}
</script>

<div style="padding:20px 10px;">
<div style="font-size:14px;color:#999;padding:3px 0;">支持:.swf、.mp4</div>
<input type="text" id="comment_url" value="http://"  style="height:30px;line-height:30px;width:300px;border:1px solid #CCC;" ondblclick="this.select()"/>
<p style="padding-left:0px;margin-left:0px;"><a class="button orange" style="color:#fff;" href="javascript:movieinsert();">插入视频</a></p></div>
EOT;
	}else if($type=="file"){
$json["msg"]=<<<EOT
<script language="javascript">
function imginsert(){
comment=$("#comment_url").val();
comment2=$("#comment_name").val();
if(comment=="" || comment=="http://"){
alert("请输入附件url地址或者请选择要上传的附件！");	
}else if(comment2==""){
alert("请输入附件的名称！");	
}else{
text=$("textarea[name=comment],textarea[name=reply]").val()+"[file="+$("#comment_url").val()+"]"+$("#comment_name").val()+"[/file]";
$("textarea[name=comment],textarea[name=reply]").val(text);
$('.open-tit a').trigger('click');
}
}
function imgupd(id){
if(document.getElementById("uploadimg").style.display=="none"){
$('#uploadimg').slideDown();
id.innerHTML="取消上传";
}else{
$('#uploadimg').slideUp();
id.innerHTML="上传文件";
}
}
</script>

<div style="padding:20px 10px;">
<div style="font-size:14px;color:#999;padding:3px 0;"><!--支持千脑在线上传--></div>
<p>名称：<input type="text" id="comment_name" value=""  style="height:30px;line-height:30px;width:300px;border:1px solid #CCC;" ondblclick="this.select()"/></p>
<p>地址：<input type="text" id="comment_url" value="http://"  style="height:30px;line-height:30px;width:300px;border:1px solid #CCC;" ondblclick="this.select()"/></p>
<div id="uploadimg" style="display:none;margin:5px 0;">
<iframe src="'.BLOG_URL.'content/plugins/em_comment_code/qiannao.php" scrolling="no" frameborder="0"  align="center" width="300" height="170"></iframe>
</div>
<p style="padding-left:0px;margin-left:0px;"><a class="button orange" style="color:#fff;" href="javascript:imginsert();">插入附件</a><!--&nbsp;&nbsp;<a class="button blue" style="color:#fff;" id="updimg" href="javascript:;" onclick="imgupd(this)">上传附件</a>--></p>
</div>
EOT;
	}else{
	$json["msg"]="";	
	}
}
echo json_encode($json);
?>