﻿var css = "",
html = "";
css += '<style>';
css += 'html{height:100%;width:100%;}';
css += '.zhezhao{z-index:9997;display:none;position:fixed;_position:absolute;width:100%;height:100%;top:0px;_top:0px;_top:expression(eval(document.documentElement.scrollTop+ (parseInt(this.currentStyle.marginTop,10)||0)));left:0px;background:#CCC;filter:alpha(opacity=10);opacity:0.1;}';
css += '.openjs{position:fixed;position:fixed !important;_position:absolute;top:20%;left:expression((this.parentElement.offsetWidth-this.offsetWidth)/2);z-index:9999;display:none;overflow:hidden;padding:10px;}';
css += '.openjs:after {contentjs:".";display:block;height:0;clear:both;visibility:hidden;}';
css += ".openjs b.alphaBg2{opacity:0.2;background:#000;height:100%;position:absolute;left:0;top:0;width:100%;z-index:1;text-indent:-999em;border-radius:10px;-webkit-border-radius:10px;-moz-border-radius:10px;box-shadow:0 0 4px  rgba(0,0,0,.3);-webkit-box-shadow:0 0 4px rgba(0,0,0,.3);-moz-box-shadow:0 0 4px rgba(0,0,0,.3);}";
css += '.openjs .contentjs{position:relative;z-index:2;background:#fff;float:left;min-width:200px;max-width:1024px;width:auto;}';
css += '.openjs .open-tit{height:35px;line-height:35px;background:url(' + imagepath + 'images/tbj.gif) repeat-x;color:#000;font-size:14px;font-weight:bold;}';
css += '.openjs .open-tit div{padding-left:10px;width:100%;height:100%;cursor:move;}';
css += '.openjs .open-tit a{position:absolute;top:0px;right:5px;text-decoration:none;line-height:19px;width:19px;height:19px;display:block;text-align:center;font-size:16px;color:#000;margin:8px;}';
css += '.openjs .open-tit a:hover{background:#999;color:#fff;}';
css += '.openjs .contentjs div,.openjs .contentjs p,.openjs .contentjs span{word-wrap:break-word;}';
css += '.openjs .contentjs p{line-height:23px;display:inline-block;margin:10px;}';
css += '.openjs .contentjs p.error{padding-left:60px;background:url(' + imagepath + 'images/error.gif) no-repeat 10px 5px;padding-top:10px;padding-bottom:10px;}';
css += '.openjs .contentjs p.yes{padding-left:60px;background:url(' + imagepath + 'images/yes.gif) no-repeat 10px 5px;padding-top:10px;padding-bottom:10px;}';
css += '.openjs .contentjs p.info{padding-left:60px;background:url(' + imagepath + 'images/info.gif) no-repeat 10px 5px;padding-top:10px;padding-bottom:10px;}';
css += '.openjs .contentjs p.conversation{padding-left:60px;background:url(' + imagepath + 'images/conversation.gif) no-repeat 10px 5px;padding-top:10px;padding-bottom:10px;}';
css += '.openjs .buttonjs{color:#666;cursor:pointer;width:114px;height:32px;margin:auto;font:15px arial,sans-serif;line-height:32px;background:url(' + imagepath + 'images/pro_a_bj2.gif) no-repeat;}';
css += '.openjs .buttonjs:hover{color:#333;background:url(' + imagepath + 'images/pro_a_bj3.gif) no-repeat;}';
css += '</style>';
css += '<!--[if IE]><style type="text/css">.alphaContainer{zoom:1;}b.alphaBg2{filter:alpha(opacity=20);zoom:1;}</style><![endif]-->';
css += '<!--[if IE 6]><style type="text/css">b.alphaBg2{padding-right:40px;} .openjs{position:absolute;}/*注意：如果.alphaContainer{padding:10px;}那么这里padding-right:20px;*/</style><![endif]-->';
html += '<div class="zhezhao"></div>';
html += '<div class="openjs">';
html += '<b class="alphaBg2">这个层显示透明</b>';
html += '<div class="contentjs">';
html += '<div class="open-tit" title="点击可以移动层"><div>系统提示：</div><a href="javascript:;" title="关闭,close">×</a></div>';
html += '<p>';
html += 'Erro!';
html += '</p><div id="buttondiv" style="text-align:center;margin-bottom:15px;width:100%;"><div class="buttonjs"  >确&nbsp;&nbsp;定</div></div>';
html += '</div></div>';
$("body").append(css);
$("body").append(html);

function ajaxget(id,_type,title,width){
$.get(BLOG_URL+"content/plugins/em_comment_code/code.php",{type:_type},function(data){
	if(data.msg!=""){
	id.innerHTML=title;
	output(width,"other",title,data.msg,true,0);
	}
},"json");	
}

function em_comment_code(id,type){
id.innerHTML="Loading....";
if(type=="code"){
   ajaxget(id,"code","插入代码","100%");
}else if(type=="url"){
   ajaxget(id,"url","插入链接","100%");
}else if(type=="qq"){
   ajaxget(id,"qq","插入QQ","100%");
}else if(type=="img"){
   ajaxget(id,"img","插入图片","100%");
}else if(type=="movie"){
   ajaxget(id,"movie","插入视频","100%");
}else if(type=="file"){
   ajaxget(id,"file","插入附件","100%");
}
}
$(document).ready(function(){
	$(".movie").click(function(){
	text='<div style="padding:20px;" align="center">';
	if(em_comment_code_confirmEnding($(this).attr("title"),".mp4")){
		text+='<video src="'+$(this).attr("title")+'" width="100%" height="320" controls="controls"></video>';
	}else{
		text+='<embed src="'+$(this).attr("title")+'" allowFullScreen="true" quality="high" width="480" height="400" align="middle" allowScriptAccess="always" type="application/x-shockwave-flash"></embed>';
	}
    text+='</div>';
	output("100%","other","视频播放",text,true,0);	
	});
});

function em_comment_code_confirmEnding(str, target) {
	var start = str.length-target.length;
	var arr = str.substr(start,target.length);
	if(arr == target){
	  return true;
	}
	return false;
}

function output(open_width, open_type, open_title, open_html, zhezhao, url) {
	var _x,_y;
	if (open_width == "" || open_width == 0) {
		open_width = "auto";
	} else if (open_type == "" || open_type == 0) {
		open_type = "other"
	} else if (open_title == "" || open_title == 0) {
		alert("Erro : output(open_title) is Null !\n弹窗的标题不能为空，参数错误!")
	} else if (open_html == null || open_html == 0) {
		alert("Erro : output(open_html) is Null !\n弹窗的内容不能为空，参数错误!")
	} else {
		if (zhezhao) {
			$(".zhezhao").show();
			$(".zhezhao").fadeTo(500, 0.5)
		}
		$(".contentjs").css({
			"width": open_width
		});
		$(".openjs .open-tit div").html(open_title);
		if (open_type == "other") {
			$(".openjs .contentjs p").html(open_html);
			$(".openjs #buttondiv").hide()
		} else if (open_type == "error") {
			$(".openjs .contentjs p").html("<p class='error'>" + open_html + "</p>");
			$(".openjs #buttondiv").fadeIn()
		} else if (open_type == "yes") {
			$(".openjs .contentjs p").html("<p class='yes'>" + open_html + "</p>");
			$(".openjs #buttondiv").fadeIn()
		} else if (open_type == "info") {
			$(".openjs .contentjs p").html("<p class='info'>" + open_html + "</p>");
			$(".openjs #buttondiv").fadeIn()
		} else {
			$(".openjs .contentjs p").html("<p class='conversation'>" + open_html + "</p>");
			$(".openjs #buttondiv").fadeIn()
		}
		oheight=($("html").height()-($(".openjs").height()+40))/3;
		if($("body").scrollTop()<$("html").scrollTop()){
		     _x = parseInt($("html").scrollLeft());
		     _y = parseInt($("html").scrollTop());
		     }else{
		     _x =parseInt($("body").scrollLeft());
		     _y =parseInt($("body").scrollTop());	
		}
		if(!+[1,]){
		  var ua = navigator.userAgent.toLowerCase(); 
		  ie =parseInt(ua.match(/msie ([\d.]+)/)[1]);
		  if(ie<8){
		 //得到吸附处理后的层坐标
         oheight=oheight+_y;
		 $(".zhezhao").css({"height":$("html").height()+"px"});  
		  }
		 }
		$(".openjs").css({
			"left": (($("body").width() - $(".openjs").width() - 20) / 2),
			//"top": "20"
			"top": oheight
		});
		 

		//alert(oheight);
		$(".openjs").fadeIn();
		//$(".openjs").animate({
			//top: oheight
		//});
		if (url != "" && url != 0) {
			if (url == "back") {
				$(".open-tit a,.openjs .buttonjs").click(function() {
					history.back()
				})
			} else {
				$(".open-tit a,.openjs .buttonjs").click(function() {
					window.location = url
				})
			}
		}
	}
}
function clearhtml(){
		$(".openjs .contentjs p").html("");	
}
$(document).ready(function() {
	$(".open-tit a,.openjs .buttonjs").click(function() {	
		$(".openjs").fadeOut();
		$(".zhezhao").fadeTo(500, 0);
		$(".zhezhao").hide();
        window.setTimeout("clearhtml()",500)
	})
});

    //页面加载为层绑定插件
    $(function(){ 
        divMove($(".open-tit div"),$(".openjs"));
    });
    //参数1：触发移动的层
    //参数2：要移动的层
    function divMove(layer,movelayer){
        //在页面创建2个隐藏域。
        $(layer).append('<input type="hidden" id="div_x" value="0" /><input type="hidden" id="div_y" value="0" />');
        var mclick=false;//记录鼠标是否已经被点击
        var currenMouse= null;//用来存储点击鼠标时移动层的对象
        //取得上一次鼠标释放后层的位置
        var x=$("#x").attr("value");
        var y=$("#y").attr("value");
        //初始化div的offset属性
        var offsetX=0;
        var offsetY=0;
		var _x=0,_y=0;
        //鼠标点击事件
        $(layer).mousedown(function(e)
        { 
		     
			 
             mclick=true;
             currenMouse=this;
			 //$(layer).css({cursor: "move"});
			 var e=window.event || e;
			 if($("body").scrollTop()<$("html").scrollTop()){
		     _x = parseInt($("html").scrollLeft());
		     _y = parseInt($("html").scrollTop());
		     }else{
		     _x =parseInt($("body").scrollLeft());
		     _y =parseInt($("body").scrollTop());	
		     }
             offsetX=(e.offsetX==undefined) ? getOffset(e).offsetX-_x : e.offsetX ;
             offsetY=(e.offsetY==undefined) ? getOffset(e).offsetY-_y : e.offsetY ;
			 
        }).mouseup(function()
        //鼠标点击对象释放事件
        {
            //把对象存储在x,y中
            $("#x").attr("value",x);
            $("#y").attr("value",y);
             mclick=false;
			 //$(layer).css({cursor: "default"});
        });
        //在层里面移动的事件
        $(document).mousemove(function(e){
         //如果鼠标没有处于点击状态
         if(!mclick){
          return;
         }
		 //得到吸附处理后的层坐标
         x=e.clientX-offsetX-10;
         y=e.clientY-offsetY-10; 
		 if($("body").scrollTop()<$("html").scrollTop()){
		     _x = parseInt($("html").scrollLeft());
		     _y = parseInt($("html").scrollTop());
		     }else{
		     _x =parseInt($("body").scrollLeft());
		     _y =parseInt($("body").scrollTop());	
		 }
		 if(!+[1,]){
		  var ua = navigator.userAgent.toLowerCase(); 
		  ie =parseInt(ua.match(/msie ([\d.]+)/)[1]);
		  if(ie<8){
		 //得到吸附处理后的层坐标
         y=y+_y;
		  }
		 }
		 //$(".openjs .contentjs p").html(x+":"+e.clientY+":"+offsetY);
         //修改层的样式
		 //$(layer).css({cursor: "move"});
         $(movelayer).css("left",x);
         $(movelayer).css("top",y);
        });
    }

function getOffset(e)
{
  var target = e.target;
  if (target.offsetLeft == undefined)
  {
    target = target.parentNode;
  }
  var pageCoord = getPageCoord(target);
  var eventCoord =
  {     //计算鼠标位置（触发元素与窗口的距离）
    x: window.pageXOffset + e.clientX,
    y: window.pageYOffset + e.clientY
  };
  var offset =
  {
    offsetX: eventCoord.x - pageCoord.x,
    offsetY: eventCoord.y - pageCoord.y
  };
  return offset;
}
function getPageCoord(element)    //计算从触发到root间所有元素的offsetLeft值之和。
{
  var coord = {x: 0, y: 0};
  while (element)
  {
    coord.x += element.offsetLeft;
    coord.y += element.offsetTop;
    element = element.offsetParent;
  }
  return coord;
}