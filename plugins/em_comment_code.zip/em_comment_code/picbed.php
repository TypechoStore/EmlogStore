<?php
include_once('em_comment_code_config.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>上传图片</title>
<script src="https://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
</head>
<body>
<div style="margin-left: 0px;">
	<form id="myForm" method="post">
		<input type="file" name="file" />
	</form>
</div>
<script type="text/javascript">
	$("input[type='file']").change(function(e) {
		parent.document.getElementById("comment_url").value = "正在上传请稍等……";
		var imageData = new FormData();
		imageData.append("file", this.files[0]);
		$.ajax({
			url: "https://www.tongleer.com/api/web/?action=weiboimg",
			type: 'POST',
			data: imageData,
			cache: false,
			contentType: false,
			processData: false,
			dataType: 'json',
			success: function (data) {
				parent.document.getElementById("comment_url").value = data.data.src;
				parent.document.getElementById("uploadimg").style.display="none";
				parent.document.getElementById("updimg").innerHTML="上传图片";
			},
			error: function (data) {
				alert('图片上传失败:'+objToArray(data));
			}
		});
	});
</script>
</body>
</html>