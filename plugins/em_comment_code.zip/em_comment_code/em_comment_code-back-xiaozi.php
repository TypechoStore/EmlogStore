<?php
/*
Plugin Name: 评论中插入代码
Version: 1.0
Plugin URL: http://www.zc520.cc
Description: 基于代码高亮的评论中插入代码。
Author: 小贤看世界
Author Email: zc@zc520.cc
Author URL: http://zc520.cc
*/

!defined('EMLOG_ROOT') && exit('access deined!');

$pcode = array();
$pcount = 0;

function codedisp($lang, $code) {
	global $pcode, $pcount;
	$pcode[$pcount] = sprintf('<pre class="brush:%s; toolbar: true; auto-links: true;">%s</pre>', $lang, $code);
	$count = $pcount++;
	return "[\tMYCODE_$count\t]";
}

function em_comment_code_rep($str){//将代码替换成高亮代码
global $pcode;
$code=$str;
$pat="/\[code(.*)\](.*)\[\/code\]/U";
preg_match_all($pat,$code,$arr);
$arr2=$arr[0];
$str3=preg_replace("/<br \/>/","",$arr2);
$str3=str_replace($arr2,$str3, $code);
$pat2="/\[code(.*)\](.*)\[\/code\]/";
$str=$str3;

$patterns = array ("/\[url\](.*?)\[\/url\]/","/\[qq\]([0-9]+)\[\/qq\]/","/\[img\](.*?)(\.jpg|\.png|\.bmp|\.jpeg|\.gif)\[\/img\]/","/\[movie\](.*?)(\.swf|\.SWF)\[\/movie\]/"); 
$replace = array ('<a href="/url/$1">$1</a>','<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=$1&site=qq&menu=yes"><img border="0" src="http://wpa.qq.com/pa?p=2:$1:46" alt="点击这里给我发消息" title="点击这里给我发消息"></a>','<a class="highslide" href="$1$2" target="_blank"><img src="'.BLOG_URL.'content/plugins/em_comment_code/img.gif" border="0"></a>','<span class="movie" title="$1$2"><img src="'.BLOG_URL.'content/plugins/em_comment_code/movie.png" alt="视频" title="点击播放">[点击播放]</span>'); 
// preg_replace调用codedisp
$str=preg_replace("/\[code=(.*)\](.*)\[\/code\]/ie","codedisp('\\1', '\\2')",$str);
foreach($pcode as $i=>$value){
$str=str_replace("[\tMYCODE_$i\t]",$value,$str);
}
$str=preg_replace($patterns, $replace, $str);
echo $str;
}
/*function em_comment_code_replace() {
	$output = ob_get_clean();
	$output = em_comment_code_rep($output);
	ob_start();
	echo $output;
}
addAction('index_footer','em_comment_code_replace');
*/
?>