<?php
include_once('em_comment_code_config.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>千脑上传图片</title>
</head>
<body>
<div id="noflash_div" class="content" style="background-color: #FFFF66; border: solid 4px #FF9966; margin: 10px 25px; padding: 10px 15px; 
display: none;">  
批量文件上传需要Flash9及以上版本，请安装或者升级您的Flash插件。   
请访问： <a href="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" 
target="_blank">Adobe网站</a> 获取最新的Flash插件。   
</div>  
<div style="margin-left: 0px;">
			<table style="border-collapse: collapse;" border=0 width=472px>
				<tr>
					<td width=1%>
						<span id="spanButtonPlaceHolder" style="width: 90px">&nbsp;</span>
					</td>
					<td><div style="height: 5px;"></div>
						<a id="btnCancel" href="javascript:qnupload.cancelQueue();">停止上传</a>
					</td>
					<td align=right><div style="height: 5px;"></div>
						<span id="divStatus"></span>
					</td>
				</tr>
			</table>
<br>
<div class="fieldset flash" id="fsUploadProgress" style="width: 450px; margin-left: 0px;">
</div>
</div>
<link href="http://upload.qiannao.com/tomos/upload/css/default.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="http://upload.qiannao.com/tomos/upload/js/qnupload.js"></script>
<script type="text/javascript">
	var editor_id = "justupload_editor";
	var qn_userid = "<?php echo em_comment_qiannao; ?>";
	var bbs_userid = "justupload";
	uploadSettings.button_text =  '<span class="theFont">选择文件</span>';
	init_qnupload();

function buildCodeForOther(editor_id, filename, url, url_utf8){
	//document.getElementById("comment_url").value=getUbbURL(filename, url) + "\r\n";
	//document.getElementById("comment_url").value = getHtmlURL(filename, url_utf8) + "\r\n";
	parent.document.getElementById("comment_url").value = getHtmlURL(filename, url);
	parent.document.getElementById("uploadimg").style.display="none";
    parent.document.getElementById("updimg").innerHTML="上传图片";
}
</script>
<!--千脑上传插件结束-->	
</body>
</html>