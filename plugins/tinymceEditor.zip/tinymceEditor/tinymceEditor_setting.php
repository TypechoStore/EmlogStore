<?php
!defined('EMLOG_ROOT') && exit('access deined!');

function plugin_setting_view(){
	?>
	<fieldset class="layui-elem-field layui-field-title">
	  <legend>版本检测</legend>
	</fieldset>
	<span id="tinymceEditorUpdateInfo"></span><script>tinymceEditorXmlHttp=new XMLHttpRequest();tinymceEditorXmlHttp.open("GET","https://www.tongleer.com/api/interface/tinymceEditor.php?action=update&version=<?=TINYMCEEDITOR_VERSION;?>",true);tinymceEditorXmlHttp.send(null);tinymceEditorXmlHttp.onreadystatechange=function () {if (tinymceEditorXmlHttp.readyState ==4 && tinymceEditorXmlHttp.status ==200){document.getElementById("tinymceEditorUpdateInfo").innerHTML=tinymceEditorXmlHttp.responseText;}}</script>
	<?php
}
?>