<?php
$query = $_SERVER["QUERY_STRING"];
$logid = preg_replace('/action=edit&gid=/','',$query);
$db = Database::getInstance();
$data = $db->query("SELECT * FROM ".DB_PREFIX."tinymce WHERE logid ='".@$logid."'");
$row = $db->fetch_array($data);
if($row != ""){
    $content = $row["content"];
    echo '<textarea id="tinymceEditor_text" style="display:none;">'.htmlspecialchars($content).'</textarea>';
}
?>
<?php if(Option::EMLOG_VERSION<"6.1.1"){?>
<script src="<?php echo BLOG_URL; ?>content/plugins/tinymceEditor/layui/layui.js"></script>
<link rel="stylesheet" href="<?php echo BLOG_URL; ?>content/plugins/tinymceEditor/layui/css/layui.css">
<?php }?>
<textarea id="tinymceEditor_content" name="tinymceEditor_content" style="" lay-verify="required" placeholder="请输入发表内容" class="layui-textarea tinymceEditor"></textarea>
<script type="text/javascript">
	$(function(){
		layui.extend({
			tinymce: '{/}<?php echo BLOG_URL; ?>content/plugins/tinymceEditor/tinymce/tinymce'
		}).use(['layedit','tinymce', 'util', 'layer'], function () {
			var t = layui.tinymce
			, util = layui.util
			, layer = layui.layer
			, $ = layui.$;
			var layedit = layui.layedit;
			t.render({
				elem: "#tinymceEditor_content"
				, height: 400
				, width:'100%'
				,menubar: 'file edit insert view format table tools'
				, menu: {
					file: {title: '文件', items: 'newdocument'},
					edit: {title: '编辑', items: 'undo redo | cut copy paste pastetext | selectall'},
					insert: {title: '插入', items: 'link media | image template hr'},
					view: {title: '查看', items: 'preview'},
					format: {title: '格式', items: 'bold italic underline strikethrough superscript subscript | formats | removeformat'},
					table: {title: '表格', items: 'inserttable tableprops deletetable | cell row column'},
					tools: {title: '工具', items: 'spellchecker code'}
				}
				/*
				, toolbar: 'code undo redo | forecolor backcolor bold italic underline strikethrough link | table preview | \ styleselect formatselect fontselect fontsizeselect | bullist numlist | \ indent alignleft aligncenter alignright alignjustify outdent indent | \ blockquote subscript superscript removeformat | \ image media charmap hr print'
				*/
				,images_upload_url:'<?php echo TLE_SERVICE_HOST;?>api/web/?action=weiboimage'
				,form:{
					name:'file'
				}
			},function(opt,edit){
				/*
				if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
					layedit.setContent(contentLayUIEditor,edit.getContent(),false);
				}else{
					$('form[name="addlog"] textarea[name="content"]').val(edit.getContent());
				}
				*/
				$('#tinymceEditor_content').keyup(function(){
					if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
						layedit.setContent(contentLayUIEditor,edit.getContent(),false);
					}else{
						$('form[name="addlog"] textarea[name="content"]').val(edit.getContent());
					}
				});
				var context = $('#tinymceEditor_text').val()?$('#tinymceEditor_text').val():$('form[name="addlog"] textarea[name="content"]').val();
				$('form[name="addlog"] textarea[name="content"]').parent().hide();
				$('#FrameUpload').hide();
				edit.setContent(context);
			});
		});
	});
</script>