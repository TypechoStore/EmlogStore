<?php
/*
Plugin Name: tinymceEditorForEmlog编辑器
Version: 1.0.1
Plugin URL: 
Description: 一款将Emlog6.1.1编辑器替换为tinymce编辑器的插件，使用注意：若有插件需要插入编辑器操作，则需要手动参考tinymceEditor_html.php中的代码进行修改，才可使该插件正常使用，如需协助修改，可发送邮件至diamond0422@qq.com。
Author: 二呆
Author Email: diamond0422@qq.com
Author URL: https://www.tongleer.com
ForEmlog: 6.1.1
*/
!defined('EMLOG_ROOT') && exit('access deined!');
define('TINYMCEEDITOR_VERSION', '1');

addAction('adm_writelog_head', 'tinymceEditor_html');
function tinymceEditor_html() {
	if(Option::EMLOG_VERSION!="6.0.1"){
		require 'tinymceEditor_html.php';
	}
}
/**
 * 添加
 * @param array $logData
 * @return int
 */
function tinymceEditor_add($logData) {
    $db = Database::getInstance();
    $kItem = array();
    $dItem = array();
    foreach ($logData as $key => $data) {
        $kItem[] = $key;
        $dItem[] = $data;
    }
    $field = implode(',', $kItem);
    $values = "'" . implode("','", $dItem) . "'";
    $db->query("INSERT INTO " . DB_PREFIX . "tinymce ($field) VALUES ($values)");
    $logid = $db->insert_id();
    return $logid;
}
/**
 * 更新
 * @param array $logData
 * @param int $blogId
 */
function tinymceEditor_update($logData, $blogId) {
    $db = Database::getInstance();
    $Item = array();
    foreach ($logData as $key => $data) {
        $Item[] = "$key='$data'";
    }
    $upStr = implode(',', $Item);
    $db->query("UPDATE " . DB_PREFIX . "tinymce SET $upStr WHERE logid=$blogId");
}

function tinymceEditor_save_log($logid){
	$tinymceEditor_content = isset($_POST['tinymceEditor_content']) ? addslashes(trim($_POST['tinymceEditor_content'])) : '';
	$content = isset($_POST['content']) ? addslashes(trim($_POST['content'])) : '';
	
	$db = Database::getInstance();
	
	$Log_Model = new Log_Model();
	$Log_Model->updateLog(array("content"=>$tinymceEditor_content), $logid);
	
    $db = Database::getInstance();
    $data = $db->query("SELECT * FROM ".DB_PREFIX."tinymce WHERE logid ='$logid'");
    if($db->fetch_array($data) == ""){
        $logData = array('logid' => $logid,'content' => $tinymceEditor_content);
        tinymceEditor_add($logData);
    }else{
        $UplogData = array('content' => $tinymceEditor_content);
        tinymceEditor_update($UplogData, $logid);
    }
}
addAction('save_log', 'tinymceEditor_save_log');