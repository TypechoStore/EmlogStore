<?php
define('LOG_TOTAL','y');
define('LOG_TOP','y');
define('LOG_HIDE','y');
define('LOG_CHECK','y');
define('LOG_PASS','y');
define('LOG_PAGE','y');
define('LOG_COM','y');
define('LOG_TW','y');
define('LOG_REPLY','y');
define('LOG_LINK','y');
define('LOG_SORT','y');
define('LOG_SORT_MOD','y');
define('LOG_SORT_BOD','y');
define('LOG_TAG','y');
define('COUNT_USER','y');
define('LOG_USER_ADMIN','y');
define('LOG_USER_WRITER','y');
define('LOG_ATT','y');
define('BLOG_BUILD','y');
define('LOG_PTIME','y');
define('BLOG_RUN','y');
define('LIE_COUNT_CSS','<style type="text/css">
.lie_count{
	
}
.lie_count_title {

}
.lie_count_ul{
	
}
.lie_count_li{
}
</style>');
?>