<?php
!defined('EMLOG_ROOT') && exit('access deined!');
ini_set("error_reporting","E_ALL & ~E_NOTICE");
function  plugin_setting_view(){
	include(EMLOG_ROOT.'/content/plugins/bd_fast/bd_fast_config.php');
?>
<?php if(isset($_GET['setting'])):?><span class="actived">设置成功</span><?php endif;?>
<h2 style="margin:20px 0 40px;">百度快速收录设置</h2>
<form action="./plugin.php?plugin=bd_fast&action=setting" method="POST">
  <p>API推送接口:<input style="margin-left:10px;width:48%" name="api" type="text" value="<?php echo $config['api'];?>" /></p>
  <p>显示记录前N条(0为全部显示):<input style="width:125px;margin-left:10px" type="text" name="fast_display" value="<?php echo $config['fast_display'];?>"></p>
  <p>清除提交记录(勾选后修改设置会清理所有记录):<input type="checkbox" name="clean_log"></p>
  <p><input class="shezhi" type="submit" value="保存配置"></p>
  <h4 style="margin-top:40px">温馨提示：</h4>
  <P>API快速推送接口请到 <a href="https://ziyuan.baidu.com/dailysubmit/index" target="_blank">https://ziyuan.baidu.com/dailysubmit/index</a> 获取</P>
  <p style="margin-bottom:20px">勾选清除提交记录，将导致保存文章的时候会再次提交该文章.  请慎重！慎重！慎重！重要的事情说三遍</p>
</form>
<?php 
  $bd_fast_file = dirname(__FILE__).'/fastdaily_log.txt';	
  $bd_fast_logs = file_get_contents($bd_fast_file);
  $bd_fast_logs_info = explode("\r\n",$bd_fast_logs);
  array_pop($bd_fast_logs_info);
?>
<style type="text/css">td{padding-right: 5px;}</style>
<table>
  <tbody>
    <tr class="meihua">
      <th>提交网址</th>
      <th>提交状态</th>
      <th>提交时间</th>
      <th>错误原因</th>
      <th>收录情况</th>
    </tr>
    <?php
  $i = ($config['fast_display'] == 0) ? 0 : ($config['fast_display'] + 1);
  foreach (array_reverse($bd_fast_logs_info) as $bd_fast_log) {
    $i--;
    if($i == 0) break;
    $bd_fast_logs_info = explode("||",$bd_fast_log);
    if($bd_fast_logs_info[0] == 0)
      echo "<tr class='meihua'><td>".$bd_fast_logs_info[3]."</td><td>提交失败</td><td>".$bd_fast_logs_info[2]."</td><td>".$bd_fast_logs_info[1]."</td></tr>";
    else
      echo "<tr class=\'meihua\'><td>".$bd_fast_logs_info[2]."</td><td>提交成功</td><td>".$bd_fast_logs_info[1]."</td><td>-</td><td><a href='https://www.baidu.com/s?wd=".$bd_fast_logs_info[2]."' target='_blank'>收录查询</a></td></tr>";
  }
    ?>
  </tbody>
</table>	
<?php
}

function plugin_setting(){
	if($_POST['clean_log'] == true){
		@file_put_contents(EMLOG_ROOT.'/content/plugins/bd_fast/fastdaily_log.txt', "");
		@file_put_contents(EMLOG_ROOT.'/content/plugins/bd_fast/logid_log.txt', "");
	}
	$newconfig = '<?php
					$config =  array(
						"api" => "'.$_POST['api'].'",
						"fast_display" => "'.$_POST['fast_display'].'" 
					);';
	@file_put_contents(EMLOG_ROOT.'/content/plugins/bd_fast/bd_fast_config.php', $newconfig);
}
?>