<?php
					$config =  array(
						"api" => "http://data.zz.baidu.com/urls?site=http://uqseo.com/&token=DXIL1vZKSq3Rrko2&type=daily",
						"fast_display" => "20" 
					);