<?php
/*
Plugin Name: 评论排行榜
Version: 1.1
Plugin URL: http://www.shuyong.net/
Description:给博客指定的页面加入评论排行榜，更多内容请打开插件查看！
ForEmlog:5.3.x
Author: 舍力
Author URL: http://www.shuyong.net/
*/

!defined('EMLOG_ROOT') && exit('access deined!');
function comtop($logid){
	require_once 'comtop_config.php';
	if($logid['logid']==$config['wzid'] || $logid['logid']==$config['wzid1'] || $logid['logid']==$config['wzid2']|| $logid['logid']==$config['wzid3'] || $logid['logid']==$config['wzid4']){
		?>
		<link href="<?php echo BLOG_URL;?>content/plugins/comtop/comtop.css" rel="stylesheet" type="text/css" />
		<div class="comtop">
		<div class="comtop-tt"><?php echo $config['mz'];?></div>
		<ul style="max-width:<?php echo $config['kd'];?>px;"<?php if($config["off"] == 'img'){echo ' class="img"';}else{echo ' class="wz"';}?>><?php global $CACHE;
		$time = time();
		$user_cache = $CACHE->readCache('user');
		$name = $user_cache[1]['name'];
		$rq =$config['rq'];
		$num =$config['num'];
		$url .=BLOG_URL.'';
		$DB = Database ::getInstance();
		$sql = "SELECT count(*) AS comment_nums,poster,mail,url FROM ".DB_PREFIX."comment where date > $time - $rq*24*60*60 and poster!='$name' and url!='$url' and url!='' and hide ='n' group by poster order by comment_nums DESC limit 0,$num";
		$result = $DB -> query($sql );$i=1;while($row = $DB -> fetch_array($result)){
			?>
			<?php if($config["off"] == 'img'){?>
			<li><a href="<?php echo $row['url'];?>" title="<?php echo $row['poster'];?>" target="_blank"><img src="<?php echo comtop_tx($row['mail']);?>" alt="<?php echo $row['poster'];?>" /></a></li>
			<?php }else{?>
			<li<?php if($i<=1){echo ' class="comtop_i"';$i++;}?>><a href="<?php echo $row['url'];?>" title="<?php echo $row['poster'];?>" target="_blank"><?php echo $row['poster'];?></a></li>
			<?php }
		}
		?>
		</ul>
		</div>
		<?php
	}
}
?>
<?php 
function comtop_menu(){
	echo '<div class="sidebarsubmenu"><a href="./plugin.php?plugin=comtop">评论排行榜</a></div>';
}?>

<?php 
addAction('log_related','comtop');
addAction('adm_sidebar_ext', 'comtop_menu');
//获取Gravatar头像
function comtop_tx($email, $s = 40, $d = 'mm', $g = 'g') {
$hash = md5($email);
$avatar = "http://cn.gravatar.com/avatar/$hash?s=$s&d=$d&r=$g";
return $avatar;
}
?>
