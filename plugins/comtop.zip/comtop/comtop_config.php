<?php
$config = array(
    "kd" => "600",
	"wzid" => "116",
	"wzid1" => "11",
	"wzid2" => "3",
	"wzid3" => "4",
	"wzid4" => "5",
	"rq" => "1000000",
	"num" => "30",
	"mz" => "评论排行榜",
	"off" => "wz",
);