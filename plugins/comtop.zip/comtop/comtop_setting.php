<?php
!defined('EMLOG_ROOT') && exit('出错了！！！!');

function plugin_setting_view(){
require_once 'comtop_config.php';
?>
<span style=" font-size:18px; font-weight:bold;">配置文件</span><?php if(isset($_GET['setting'])){echo "<span class='actived'>设置保存成功!</span>";}?><br />
<br />
<link href="<?php echo BLOG_URL;?>content/plugins/comtop/comtop.css" rel="stylesheet" type="text/css" />
<form action="plugin.php?plugin=comtop&action=setting" method="post">
<table width="100%" border="0" cellspacing="1" cellpadding="0" style="background:#bbb;height:30px;">
<tbody style="border:#ccc 1px solid; background:#fff;">
  <tr>
    <td class="comtop-h"> 显示宽度</td>
    <td><input type="text" class="txt" name="kd" value="<?php echo $config["kd"];?>" size="33"/></td>
    <td class="comtop-l">图像宽度50px，昵称宽度100px，自己去换算每行显示几个</td>
  </tr>
  <tr>
    <td width="120" class="comtop-h"> 需要显示的文章ID</td>
    <td width="240"><input type="text" class="wzid" name="wzid" value="<?php echo $config["wzid"];?>" size="1"/>
    <input type="text" class="wzid" name="wzid1" value="<?php echo $config["wzid1"];?>" size="1"/>
    <input type="text" class="wzid" name="wzid2" value="<?php echo $config["wzid2"];?>" size="1"/>
    <input type="text" class="wzid" name="wzid3" value="<?php echo $config["wzid3"];?>" size="1"/>
    <input type="text" class="wzid" name="wzid4" value="<?php echo $config["wzid4"];?>" size="1"/>
    </td>
    <td class="comtop-l">每框仅限一个，填写不存在的id将不显示</td>
  </tr>
  <tr>
    <td class="comtop-h">时间(天)</td>
    <td><input type="text" class="txt" name="rq" value="<?php echo $config["rq"];?>" size="33"/></td>
    <td class="comtop-l">即显示多长时间内的评论排行</td>
  </tr>
  <tr>
    <td class="comtop-h"> 需要显示的数量</td>
    <td><input type="text" class="txt" name="num" value="<?php echo $config["num"];?>" size="33"/></td>
    <td class="comtop-l">显示在设置的时间内的前多少名</td>
  </tr>
  <tr>
    <td class="comtop-h">前台显示名字</td>
    <td><input type="text" class="txt" name="mz" value="<?php echo $config["mz"];?>" size="33"/></td>
    <td class="comtop-l">在文章页显示</td>
  </tr>
  <tr>
    <td class="comtop-h">显示方式</td>
    <td colspan="2">
  <input type="radio" name="off" value="img" <?php if($config["off"] == 'img'){echo 'checked="checked"';} ?> />Gravatar图像
  <input type="radio" name="off" value="wz" <?php if($config["off"]=='wz'){echo 'checked="checked"';} ?> />评论者昵称
    </td>
    </tr>
  <tr>
    <td colspan="4" class="comtop-l">
注意事项：<br />
1、模板必须含有挂载点(没有请自行加上)：&lt;?php doAction('log_related',$logData);?&gt;<br />
2、插件问题反馈地址(其他途径反馈将不受理)：<a href="http://www.shuyong.net/803.html" target="_blank">http://www.shuyong.net/803.html</a>
    </td>
    </tr>
</tbody> 
</table>
<input type="submit" class="button" name="submit" value="保存设置" />
</form>
<?php }?>
<?php 
function plugin_setting(){
	require_once 'comtop_config.php';
	$kd = $_POST["kd"]==""?"600":$_POST["kd"];
	$wzid = $_POST["wzid"]==""?"1":$_POST["wzid"];
	$wzid1 = $_POST["wzid1"]==""?"2":$_POST["wzid1"];
	$wzid2 = $_POST["wzid2"]==""?"3":$_POST["wzid2"];
	$wzid3 = $_POST["wzid3"]==""?"4":$_POST["wzid3"];
	$wzid4 = $_POST["wzid4"]==""?"5":$_POST["wzid4"];
	$rq = $_POST["rq"]==""?"30":$_POST["rq"];
	$num = $_POST["num"]==""?"30":$_POST["num"];
	$mz = $_POST["mz"]==""?"评论排行榜":$_POST["mz"];
	$off = $_POST["off"]==""?"wz":$_POST["off"];
	$newConfig = '<?php
$config = array(
    "kd" => "'.$kd.'",
	"wzid" => "'.$wzid.'",
	"wzid1" => "'.$wzid1.'",
	"wzid2" => "'.$wzid2.'",
	"wzid3" => "'.$wzid3.'",
	"wzid4" => "'.$wzid4.'",
	"rq" => "'.$rq.'",
	"num" => "'.$num.'",
	"mz" => "'.$mz.'",
	"off" => "'.$off.'",
);';
	echo $newConfig;
	@file_put_contents(EMLOG_ROOT.'/content/plugins/comtop/comtop_config.php', $newConfig);
}
?>