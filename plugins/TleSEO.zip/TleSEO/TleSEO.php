<?php
/*
Plugin Name: SEO
Version: 1.0.1
Description: SEO插件暂仅支持给图片加alt属性
Plugin URL: https://www.tongleer.com
ForEmlog: 6.1.1
Author: 二呆
Author URL: https://www.tongleer.com
*/
if(!defined('EMLOG_ROOT')){die('err');}
function TleSEO_Related($logData){
	$db = Database::getInstance();
	$data=ob_get_clean();
	/*
	$pattern ="/<[img|IMG].*?src=[\'|\"](.*?)[\'|\"].*?[\/]?>/i";
	//$logData["log_content"]=$data;
	preg_match_all($pattern,$logData["log_content"],$mathches);
	$content=$logData["log_content"];
	for($i=0;$i<count($mathches[0]);$i++){
		$replacement ='<img src="'.$mathches[1][$i].'" alt="'.$logData["log_title"].'" title="'.$logData["log_title"].'" />';
		$logData["log_content"] = str_replace($mathches[0][$i], $replacement, $logData["log_content"]);
	}
	$data = str_replace($content, $logData["log_content"], $data);
	*/
	//替换a title
	$pattern ="/<a(.*?)href=('|\")(.*?).(bmp|gif|jpeg|jpg|png)('|\")(.*?)>/i";
	$replacement = '<a$1href=$2$3.$4$5 alt="'.$logData["log_title"].'" title="'.$logData["log_title"].'"$6>';
	$data = preg_replace($pattern, $replacement, $data);
	//替换img alt
	$pattern ="/<img(.*?)src=('|\")(.*?)('|\")(.*?)>/i";
	$replacement = '<img$1src=$2$3.$4$5 alt="'.$logData["log_title"].'"$6>';
	$data = preg_replace($pattern, $replacement, $data);
	ob_start();
	echo $data;
}
addAction("log_related","TleSEO_Related");
?>