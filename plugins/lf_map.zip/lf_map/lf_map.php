<?php
/*
Plugin Name: Emlog网站地图美化详细版
Version: 2.0
Plugin URL: http://dcqzz.cn
Description: 初次安装需要访问"你的网站/map.html"，然后等待几分钟会在网站更目录生成一个map.html文件即可。
Author: lonewolf
Author Email:945203919@qq.com
Author URL: http://dcqzz.cn
*/
!defined('EMLOG_ROOT') && exit('access deined!');

function lf_map_footer(){
	$filename = EMLOG_ROOT.'/map.html';
	$url = BLOG_URL.'?plugin=lf_map';
	$time = 1*60*60*24; //设定1天, 单位:秒		
    if ( !is_file($filename) || (time() - filemtime($filename)) > $time ){	//当文件不存在或者文件超过1天才更新		
	    $comurl = @file_get_contents($url);	
		@file_put_contents($filename,$comurl);
	}
	if(is_file($filename)) echo '';
}
addAction('index_footer', 'lf_map_footer');
?>
