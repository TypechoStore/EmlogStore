<?php
!defined('EMLOG_ROOT') && exit('access deined!');
global $CACHE;
$db = Database::getInstance();
$options_cache = $CACHE->readCache('options');
$blogname = Option::get('blogname');
$site_title = '网站地图 - '.$blogname;
function rcolor(){$rand = rand(0,255);return sprintf("%02X","$rand");}
function rand_color(){return '#'.rcolor().rcolor().rcolor();}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo $site_title ?></title>
<link href="//cdn.bootcss.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet">
<link href="//cdn.bootcss.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
<link href="<?php echo BLOG_URL; ?>content/plugins/lf_map/style.css" rel="stylesheet" type="text/css" />
<!--[if lt IE 9]>
	<script src="//cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body>
<div class="title" >
<h1>网站地图
<?php/**首页头部显示网站名
 - <?php echo Option::get('blogname'); ?>
 **/?>
</h1>
</div>
<div class="top-container">现在位置：<a title="返回首页" href="<?php echo BLOG_URL;?>"><?php echo Option::get('blogname'); ?>首页</a> &raquo;&nbsp; 网站地图</div>

<div class="container-fluid main-content">
	<div class="row map-b">
		<div class="col-md-6">
			<div class="widget-container fluid-height">
				<div class="heading">
					<div class="actions">
						<a class="fasorts"><i class="fa fa-chevron-down"></i></a>
					</div>
					<i class="fa fa-flag"></i>|分类:
				</div>
				<div class="widget-content padded widget_sorts">
					<?php
						$sort_cache = $CACHE->readCache('sort');
						foreach($sort_cache as $value):
					?>
					<div class="col-md-4 col-sm-3"><a href="<?php echo Url::sort($value['sid']); ?>"><i class="fa fa-list-alt"></i> <?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a></div>
					<?php endforeach;?>
				</div>
			</div>
		</div>
		<div class="col-md-6">
			<div class="widget-container fluid-height">
				<div class="heading">
					<div class="actions">
						<a class="farchive"><i class="fa fa-chevron-down"></i></a>
					</div>
					<i class="fa fa-database"></i>|日期归档:
				</div>
				<div class="widget-content padded widget_archive">
					<?php
						$record_cache = $CACHE->readCache('record');
						foreach($record_cache as $value):
					?>
					<div class="col-md-4 col-sm-3"><a href="<?php echo Url::record($value['date']); ?>"><i class="fa fa-calendar"></i> <?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></div>
					<?php endforeach;?>
				</div>
			</div>
		</div>
	</div>
	<div class="row map-top">
		<div class="col-lg-4">
			<div class="widget-container fluid-height">
				<div class="heading">
					<div class="actions">
						<a class="faltags"><i class="fa fa-chevron-down"></i></a>
					</div>
					<i class="fa fa-tags"></i>|标签:
				</div>
				<div class="widget-content padded widget_tags">
					<?php
						$tag_cache = $CACHE->readCache('tags');
						shuffle($tag_cache);
						$tag_cache = array_slice($tag_cache,0,500);
						foreach($tag_cache as $value):
					?>
					<a href="<?php echo Url::tag($value['tagurl']); ?>" style="background-color:<?php echo rand_color(); ?>;"><?php echo $value['tagname']; ?><?php if($value['usenum']<=0):?><?php else:?><small>(<?php echo $value['usenum']; ?>)</small><?php endif;?></a>
					<?php endforeach; ?>
				</div>
			</div>
			
		</div>
		<div class="col-lg-8">
			<div class="warp-container fluid-height">
				<div class="heading">
					<div class="actions">
						<a class="falist"><i class="fa fa-chevron-down"></i></a>
					</div>
					<i class="fa fa-list-ul"></i>|最新文章列表:
				</div>
				<div class="widget-content padded falist-content">
					<table class="table table-hover">
						<thead>
							<tr>
								<th style="width:60%;">标题</th>
								<th>发布时间</th>
								<th>阅读</th>
								<th>评论</th>
							</tr>
						</thead>
						<tbody>
						<?php
							
							$sql2 = "SELECT * FROM ".DB_PREFIX."blog WHERE hide='n' ORDER BY `date` DESC LIMIT 0,500";
							$list = $db->query($sql2);
							while($row = $db->fetch_array($list)){
							$row['date'] += $timezone * 3600;
						?>
						<tr>
							<td><a href="<?php echo Url::log($row['gid']);?>" rel="content" title="<?php echo $row['title'];?>"><?php echo $row['title'];?></a></td>
							<td><?php echo gmdate('Y-m-d', $row['date']);?></td>
							<td><?php echo $row['views'];?></td>
							<td><?php echo $row['comnum'];?></td>
						<?php
							}
						?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="top-container">
<div class="footer">
<p> Powered by <strong><a href="http://dcqzz.cn" target="_blank">Dream city</a></strong> &nbsp;&copy; 2016 <a href="<?php echo BLOG_URL; ?>" target="_blank" title="<?php echo Option::get('blogname'); ?>的博客"><?php echo Option::get('blogname'); ?></a></p>
</div>
</div>
<script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script>
<script src="//cdn.bootcss.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script>
$(document).ready(function(){
	$("body a").tooltip({
        container: 'body',
        placement: 'bottom'
    });
	$(".fasorts").click(function() {
		$(".widget_sorts").slideToggle("normal");
	});
	$(".farchive").click(function() {
		$(".widget_archive").slideToggle("normal");
	});
	$(".faltags").click(function() {
		$(".widget_tags").slideToggle("normal");
	});
	$(".falist").click(function() {
		$(".falist-content").slideToggle("normal");
	});
});
</script>
</body>
</html>
