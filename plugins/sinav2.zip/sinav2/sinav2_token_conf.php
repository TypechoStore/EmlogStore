<?php
define('SINAV2_ACCESS_TOKEN','');
define('SINAV2_REMIND_IN','');
define('SINAV2_EXPIRES_IN','');
define('SINAV2_UID','');
