<?php
define('SINAV2_APP_NAME','sinav2');
define('SINAV2_AKEY','');
define('SINAV2_SKEY','');
define('SINAV2_CALLBACK_URL','');
