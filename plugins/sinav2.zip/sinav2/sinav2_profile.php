<?php
define('SINAV2_SYNC','1');
define('SINAV2_TFROM','4');
