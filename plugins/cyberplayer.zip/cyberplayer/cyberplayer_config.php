<?php
$config = array(
	"ak" => "cc94de6803904f2ca7159eedeaced55d"
);