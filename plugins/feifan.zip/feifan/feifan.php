<?php
/*
Plugin Name: 插入网盘下载、回复可见双功能插件
Version: 美化、优化兼容性版
Plugin URL:https://www.artzd.cn/
Description: 插件挂载代码&lt;?php doAction('down_log',$logid);?&gt;最好加在echo_log.php文件！META模板大概22行，其他的自行添加，支持Emlog6.1.1。
Author: 优化兼容性版   @Finally版权
Author URL:https://www.artzd.cn/
*/
define('CSS_URL', BLOG_URL .'content/plugins/feifan/');
/**
 * 添加
 *
 * @param array $logData
 * @return int
 */
function Cp_feifan_Down_addlog($logData) {
    $db = Database::getInstance();
    $kItem = array();
    $dItem = array();
    foreach ($logData as $key => $data) {
        $kItem[] = $key;
        $dItem[] = $data;
    }
    $field = implode(',', $kItem);
    $values = "'" . implode("','", $dItem) . "'";
    $db->query("INSERT INTO " . DB_PREFIX . "feifan ($field) VALUES ($values)");
    $logid = $db->insert_id();
    return $logid;
}
/**
 * 更新
 *
 * @param array $logData
 * @param int $blogId
 */
function Cp_feifan_Down_updateLog($logData, $blogId) {
    $db = Database::getInstance();
    $Item = array();
    foreach ($logData as $key => $data) {
        $Item[] = "$key='$data'";
    }
    $upStr = implode(',', $Item);
    $db->query("UPDATE " . DB_PREFIX . "feifan SET $upStr WHERE logid=$blogId");
}
function Cp_feifan_setting_create($logid){
    $db = Database::getInstance();
    $data = $db->query("SELECT * FROM ".DB_PREFIX."feifan WHERE logid ='$logid'");
    $start = isset($_POST['start']) ? addslashes(trim($_POST['start'])) : 'n';
    $hide = isset($_POST['hide']) ? addslashes(trim($_POST['hide'])) : 'n';
    $version = isset($_POST['version']) ? addslashes(trim($_POST['version'])) : '';
    $dizhi = isset($_POST['dizhi']) ? addslashes(trim($_POST['dizhi'])) : '';
	$wangpan = isset($_POST['wangpan']) ? addslashes(trim($_POST['wangpan'])) : '';
    $logData = array('start' => $start,'logid' => $logid,'hide' => $hide,'version' => $version,'dizhi' => $dizhi,'wangpan' => $wangpan);
	$UplogData = array('start' => $start,'hide' => $hide,'version' => $version,'dizhi' => $dizhi,'wangpan' => $wangpan);
	if($db->fetch_array($data) == ""){
        Cp_feifan_Down_addlog($logData);
    }else{
        Cp_feifan_Down_updateLog($UplogData, $logid);
    }
}

addAction('save_log', 'Cp_feifan_setting_create');

function CP_donw_option(){
    $query = $_SERVER["QUERY_STRING"];
    $string = preg_replace('/action=edit&gid=/','',$query);
    $db = Database::getInstance();
    $data = $db->query("SELECT * FROM ".DB_PREFIX."feifan WHERE logid ='".$string."'");
    $row = $db->fetch_array($data);
    if( $row == ''){
        $logData = array('start' => '','hide' => '','version' => '','dizhi' => '','wangpan' => '');
    }else{
        $logData = array(
            'start' => htmlspecialchars($row['start']),
            'hide' => htmlspecialchars($row['hide']),
            'version' => htmlspecialchars($row['version']),
            'dizhi' => htmlspecialchars($row['dizhi']),
			'wangpan' => htmlspecialchars($row['wangpan'])
        );
    }
    
?>
<link href="<?php echo CSS_URL; ?>bootstrap.css" type="text/css" rel="stylesheet">
<div class="row">
    <div class="col-lg-12">
        <table class="table">
            <tbody>
                <tr>
                    <th style="width:10%;"><label>启用下载</label></th>
                    <th>
                        <input type="checkbox" name="start" title="启用" id="statr" value="y"<?php if($logData['start']=='y'){echo ' checked';}else{echo '';}?> ><span></span>
                    </th>
                </tr>
                <tr>
                    <th style="width:10%;"><label>回复下载</label></th>
                    <th>
                        <input type="checkbox" name="hide" title="启用" id="hide" value="y"<?php if($logData['hide']=='y'){echo ' checked';}else{echo '';}?> ><span></span>
                    </th>
                </tr>
               <tr>
                    <th style="width:10%;"><label></i>网盘密码</label></th>
                    <th><input type="text" class="form-control" name="version" id="version" value="<?php echo $logData['version']; ?>" size="30" tabindex="30" style="width: 80%;"></th>
                </tr>
                <tr>
                    <th style="width:10%;"><label><i class="fa fa-cloud-upload"></i>百度网盘地址</label></th>
                    <th><input type="text" class="form-control" name="dizhi" id="dizhi" value="<?php echo $logData['dizhi']; ?>" size="30" tabindex="30" style="width: 80%;"></th>
                </tr>
                <tr>
                    <th style="width:10%;"><label><i class="fa fa-cloud-upload"></i>蓝奏网盘地址</label></th>
                    <th><input type="text" class="form-control" name="wangpan" id="wangpan" value="<?php echo $logData['wangpan']; ?>" size="30" tabindex="30" style="width: 80%;"></th>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php
}

addAction('adm_writelog_head', 'CP_donw_option');


function show_feifan($logid){
    $db = Database::getInstance();
	$data = $db->query("SELECT * FROM ".DB_PREFIX."feifan WHERE logid ='$logid'");
	$row = $db->fetch_array($data);
	$logData = array(
		'start' => htmlspecialchars($row['start']),
		'hide' => htmlspecialchars($row['hide']),
		'version' => htmlspecialchars($row['version']),
		'dizhi' => htmlspecialchars($row['dizhi']),
		'wangpan' => htmlspecialchars($row['wangpan']),
	);
	$content = '<script src="http://apps.bdimg.com/libs/jquery/2.1.4/jquery.js"></script>
<script type="text/javascript">
$(function(){
$(".lan").click(function(){
    $(".you").slideToggle("slow");
    $(".xs1").toggle();
    $(".xs2").toggle();
  });});
</script>
<style>
.lan {
	border-radius: 20px;
	padding: 10px;	
	position: relative;
	margin: 5px;
 	box-shadow: 0px 0px 5px 5px rgba(161, 159, 159, 0.1);
	text-align: center;
	background: #03A9F4;
	border: solid 1px #c3c3c3;
}

.you {
	border-radius: 20px;
	padding: 20px;	
	position: relative;
	margin: 5px;
 	box-shadow: 0px 0px 10px 2px #03A9F4;
	text-align: center;
	display: none;
}
.you .border-green {
	width: 300px;
	margin: 20px auto;
	text-align: center;
	padding: 10px;
	border-radius: 5px;
	border: 2px solid #4b9814;
	background-color: #fff
}

.lanyou {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
    -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
}

.button1:hover {
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
}

.button2:hover {
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
}
</style>';
	$content .= ' 下载地址<br />
 <div class= id="paydown" >
 <div class="border-green">
</div>
<span><a href="'.$logData['dizhi'].'"  class="lanyou button1" rel="external nofollow" target="_blank"></i>&nbsp;百度网盘</a><span>
<span><a href="'.$logData['wangpan'].'"  class="lanyou button2" rel="external nofollow" target="_blank"></i>&nbsp;蓝奏网盘</a><span><br />
<span></i>提取密码：</span><span class="text-danger">'.$logData['version'].'</span><br>
</div>';

	if($logData['start']=='y'){
		if($logData['hide']=='y'){
				if($_COOKIE['postermail'] && $_COOKIE['postermail'] != ''){
					$r = Database::getInstance();
					$row=$r->once_fetch_array("SELECT * FROM  `".DB_NAME."`.`".DB_PREFIX."comment` WHERE `mail` =  '".$_COOKIE['postermail']."' and `gid` = '".$logid."' ORDER BY `date` DESC");
				}else if($_COOKIE['posterurl'] && $_COOKIE['posterurl'] != ''){
					$r = Database::getInstance();
					$row=$r->once_fetch_array("SELECT * FROM  `".DB_NAME."`.`".DB_PREFIX."comment` WHERE `url` =  '".$_COOKIE['posterurl']."' and `gid` = '".$logid."' ORDER BY `date` DESC");
				}
				if($row && (time()-$row['date']) <= 3600*24 && $row['hide'] == 'n' || ROLE == "admin"){ //通过的评论在24小时之内
					echo $content;
				}else{
					echo '<div style="text-align:center;border:1px dashed #5db8f8;padding:8px;margin:10px auto;color:#5db8f8;"><i class="fa fa-lock"></i> 管理员设置<a href="#comment">回复</a>可下载</div>';
				}
		}else{
		    echo $content;
		}
	}else{
		echo '';
	}
}

addAction('down_log', 'show_feifan');