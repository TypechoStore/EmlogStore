<?php
if(!defined('EMLOG_ROOT')) {exit('error!');}
function callback_init(){
    $db = Database::getInstance();
    $db->query("CREATE TABLE IF NOT EXISTS `".DB_PREFIX."feifan` (
        `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
        `logid` int(10) unsigned NOT NULL,
        `start` enum('n','y') NOT NULL DEFAULT 'n',
        `hide` enum('n','y') NOT NULL DEFAULT 'n',
        `version` varchar(255) NOT NULL,
        `dizhi` varchar(255) NOT NULL,
		`wangpan` varchar(255) NOT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;");
}