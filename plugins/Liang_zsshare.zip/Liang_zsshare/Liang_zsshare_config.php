<?php
$Liang_zsshare_config = array(
	"zfbskr" => "cnaliang@qq.com",
	"zfbpr" => "http://i3.tietuku.com/c6ba22a85c144c20s.png",
	"wxpr" => "http://i3.tietuku.com/ba01419ad407f812s.png",
);