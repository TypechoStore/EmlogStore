<?php
	$imgnum_week = 20;
	$imgsize_week = 32;
	$imgnum_month = 30;
	$imgsize_month = 32;
	$imgnum_all = 40;
	$imgsize_all = 32;
	$imgnum_side = 8;
	$imgsize_side = 32;
	$type_wall = 'all';
	$tip = '墙上还没人，快抢沙发啦~';
?>