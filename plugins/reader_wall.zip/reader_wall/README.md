emlog 读者墙插件
====================

貌似没什么好介绍的了，最初模仿的是wordpress的读者墙（其实就是模仿wordpress的），根据emlog的特殊性移植过来。有周读者墙，月读者墙，总读者墙，取决于你怎么调用。

[插件主页](http://xiaosong.org/share/emlog-readers-wall-plug-reloaded)