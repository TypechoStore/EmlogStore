﻿<?php
/*
 Plugin Name: 糊涂分类信息
 Version: 1.1
 Plugin URL: http://www.xieyuba.net
 Description: 这是一个非常方便,非常简介的一个分类信息插件。
 ForEmlog:5.3.x
 Author: Z.Howe
 Author Email: admin@xieyuba.net
 Author URL: http://www.xieyuba.net
*/
!defined('EMLOG_ROOT') && exit('access deined!');
function hutufenlei(){?>
<!--如果你不懂代码请勿修改以下代码，错一个符号就全乱了。-->
<script>
$(document).ready(function(){
	$("#fjbox #fjcharu").click(function(){
		if(typeof($('#markdownEditor_content').val())!='undefined'){
			$('#markdownEditor_content').val($('#markdownEditor_content').val()+"<div class='htfl'><div class='flxxnr'><ul><icon>文件名称: "+($('#wjmc').val())+"</icon><icon>程序类型: "+($('#cxlx').val())+"</icon><icon>程序大小: "+($('#cxdx').val())+"</icon><icon>程序作者: "+($('#cxzz').val())+"</icon><icon>程序演示 <a href='"+($('#ccll').val())+"' target='_blank' rel='nofollow' title='查看演示'>点我查看</a></icon><div class='wztp'><img src="+($('#wztp').val())+" ></ul></div></div></div></div>");
		}else if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
			layedit.setContent(contentLayUIEditor,"<div class='htfl'><div class='flxxnr'><ul><icon>文件名称: "+($('#wjmc').val())+"</icon><icon>程序类型: "+($('#cxlx').val())+"</icon><icon>程序大小: "+($('#cxdx').val())+"</icon><icon>程序作者: "+($('#cxzz').val())+"</icon><icon>程序演示 <a href='"+($('#ccll').val())+"' target='_blank' rel='nofollow' title='查看演示'>点我查看</a></icon><div class='wztp'><img src="+($('#wztp').val())+" ></ul></div></div></div></div>",true);
		}else{
			$($(".ke-edit-iframe:first").contents().find(".ke-content")).append("<div class='htfl'><div class='flxxnr'><ul><icon>文件名称: "+($('#wjmc').val())+"</icon><icon>程序类型: "+($('#cxlx').val())+"</icon><icon>程序大小: "+($('#cxdx').val())+"</icon><icon>程序作者: "+($('#cxzz').val())+"</icon><icon>程序演示 <a href='"+($('#ccll').val())+"' target='_blank' rel='nofollow' title='查看演示'>点我查看</a></icon><div class='wztp'><img src="+($('#wztp').val())+" ></ul></div></div></div></div>");
		}
	});
	$("#close_tools").click(function(){
		$("#ht_con").slideUp(200);
	}); 
	$("#ht_title").click(function(){
		$("#ht_con").slideDown(200);
	}); 
	$("#clear_shuru").click(function(){
		$("#ht_con input").attr("value","");
	});
});
</script>
<style>
#ht_box{font-weight:bold; font-family:Arial;font-size:12px;margin:5px 0; cursor:pointer;clear:both;}
#ht_box #ht_title{background:#5bc0de;float:left;padding:5px 10px;margin-bottom:5px;float:left;clear:both;color:#fff;border-radius:4px;font-weight:normal;font-family:"Microsoft Yahei";font-size:14px;background-image: linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-size: 30px 30px;box-shadow: 0 0 4px 1px rgba(16, 160, 249, 0.3);}
#ht_box #ht_con{clear:both;float:left;font-weight:normal;margin:5px 0 10px 0;display:none;border: 1px solid #ccc;padding: 10px;width:450px;border-radius: 4px;}
#ht_box #ht_con p{margin:0 0 10px 0;font-size:14px;}
#ht_box #ht_con input{width:210px;font-size:12px;padding:5px;border-radius:4px;outline:none;border: 1px solid #ccc;}
#ht_box #ht_con input:-webkit-autofill{background:#fff;}
#ht_box #ht_con span{float:left;cursor:pointer;border:0;padding:10px 15px;font-size: 12px;margin: 0 10px 0 0;border-radius:4px;color:#fff;background-image: linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-size: 30px 30px;box-shadow: 0 0 4px 1px rgba(16, 160, 249, 0.3);}
#ht_box #ht_con span:hover{background:#00aff0 !important;color:#fff !important;}
#ht_box #ht_con #crfj{background:#9c3;color:#fff;}
#ht_box #ht_con select{padding:5px;border-radius:4px;outline:none;border: 1px solid #ccc;}
input:focus,select:focus{border-color:#66afe9;outline:0;-webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);background:#fff;}
</style>
<div id="ht_box">
<div id="ht_title">糊涂分类信息</div> 
<div id="ht_con">
<div id="fjbox">
<p>文件名称：<input name="wjmc" id="wjmc" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例如：wild模版</b></p>
<p>程序类型：<input name="cxlx" id="cxlx" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例如：模版,插件</b></p>
<p>程序大小：<input name="cxdx" id="cxdx" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例子：50G</b></p>
<p>程序作者：<input name="cxzz" id="cxzz" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例子：Z.Howe</b></p>
<p>文章图片：<input name="wztp" id="wztp" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例如:插入图片链接</b></p>
<p>程序预览：<input name="ccll" id="ccll" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">如:http://www.xieyuba.net</b></p>
<p style="margin: 10px 0 0 70px;"><span id="fjcharu" style="background-color:#337ab7;">插入代码</span> <span id="close_tools" style="background-color:#5cb85c">关闭工具</span> <span id="clear_shuru" style="background-color:#f0ad4e">清除内容</span></p></div>
</div></div>
<?php }
addAction('adm_writelog_head', 'hutufenlei');
function hutufenlei_css(){?>
<style>.htfl{padding:15px 20px 5px;border:1px solid rgb(225, 225, 225);border-image-source:initial;border-image-slice:initial;border-image-width:initial;border-image-outset:initial;
border-image-repeat:initial;border-radius:8px;margin-bottom:10px;font-family:'Microsoft Yahei';font-size:12px;}.htfl:hover {border:1px solid rgb(62, 143, 239);}.flxxnr icon {background-image:url(/content/plugins/hutu_Flxx/images/fl-ico.gif);color:#8D9095;background-position:0 center;background-repeat:no-repeat;display:block;padding-left:25px;height:34px;line-height:34px;border-bottom:1px solid #e1e1e1;}.flxxnr a {background:#00aff0;color:#fff;padding:2px 5px;border-radius:4px;text-shadow:0px 0px;}.flxxnr a:hover {background:#60C4E8;}.wztp {float:right;width:208px;height: 205px;margin:-204px 0px;padding:2px;border-radius: 4px;overflow:hidden;}</style>
<?php }
addAction('index_footer', 'hutufenlei_css');