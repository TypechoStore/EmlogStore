<?php
/*
 Plugin Name: 网易音乐调用工具
 Version: 1.0
 Plugin URL: http://lanyes.org
 Description: 这是一个编辑器加强插件，使用它你可轻松的插入网易音乐的调用。
 ForEmlog:5.3.x&6.1.1
 Author: 蓝叶
 Author Email: w@lanyes.org
 Author URL: http://lanyes.org
*/
!defined('EMLOG_ROOT') && exit('access deined!');

function lanye_163music(){
	if(Option::EMLOG_VERSION<"6.0.1"){
	?>
	<script type="text/javascript">
	$(document).ready(function(){
		$('.ke-toolbar span[data-name="about"]').before('<div class="ke-wymusic" title="蓝叶网易音乐调用工具" id="open_lanyewymusic"><span></span></div>');
		$('.ke-toolbar span[data-name="about"]').hide();
		$("#wymusic_charu").click(function(){
			$($(".ke-edit-iframe:first").contents().find(".ke-content")).append("<p><iframe frameborder='no' border='0' marginwidth='0' marginheight='0' width='"+($('#wymusic_w').val())+"' height='86' src='http://music.163.com/outchain/player?type=2&id="+($('#wymusic_id').val())+"&auto="+($('#wymusic_auto').val())+"&height=66'></iframe></p>");
		});
		$("#wymusic_close,#wymusic_charu").click(function(){
			$("#wymusicbox").slideUp(200);
		}); 
		$("#open_lanyewymusic").click(function(){
			$("#wymusicbox").toggle();
		});
	});
	</script>
	<?php
	}else{
	?>
	<span id="open_lanyewymusic2"><a href="javascript:;" class="layui-btn layui-btn-primary layui-btn-xs">蓝叶网易音乐调用工具</a></span>
	<?php
	}
	?>
	<style>
	#wymusicbox{clear:both;float:left;font-weight:normal;margin:5px auto 10px;display:none;border: 1px solid #ccc;padding: 10px;width:353px;border-radius:4px;left:0;right:0;position:absolute;background-color:#fff;box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(118, 120, 121, 0.6);z-index:1;}
	.wymusic{padding: 5px 0;}
	.wymusic label{padding:8px;font-size:14px;font-weight:400;line-height:1;color:#555;text-align:center;background-color:#eee;border:1px solid #ccc;border-radius: 4px;float:left;border-bottom-right-radius: 0;border-top-right-radius:0;}
	.wymusic input{width:200px;outline:none;height:20px;padding:5px 10px;font-size:14px;line-height:1.42857143;color:#555;background-color:#fff;background-image:none;border:1px solid #ccc;border-radius:4px;border-bottom-left-radius:0;border-top-left-radius:0;border-left:0;}
	.wymusic select{padding:0 10px;height:32px;outline:none;border:1px solid #ccc;border-radius:4px;border-bottom-left-radius:0;border-top-left-radius:0;border-left:0;}
	#wymusic_charu,#wymusic_close{cursor:pointer;background:#337ab7;padding:5px 10px;margin-top:5px;margin-bottom:5px;float:left;margin-right:15px;color:#fff;border-radius:4px;font-weight:normal;font-family:"Microsoft Yahei";font-size:14px;background-image: linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-size: 30px 30px;box-shadow: 0 0 4px 1px rgba(16, 160, 249, 0.3);}
	#wymusic_charu:hover,#wymusic_close:hover{background-color:#00aff0;}
	#wymusic_close{background-color:#3C6;}
	.ke-wymusic{margin:1px;padding:1px 2px;font-size:0;line-height:0;overflow:hidden;cursor:pointer;display:block;float:left;}
	.ke-wymusic span{background:url(<?php echo BLOG_URL;?>content/plugins/lanye_163music/163.png) no-repeat;width:16px;height:16px;background-repeat:no-repeat;font-size: 0;line-height: 0;overflow: hidden;display: block;}
	.ke-wymusic:hover{background-color:#80c4f5;}
	</style>
	<div class="clear"></div>
	<div id="wymusicbox">
	<div class="wymusic"><label>输入网易音乐ID号</label> <input type="text" name="wymusic_id" id="wymusic_id" value="" placeholder="输入网易云音乐ID" /></div>
	<div class="wymusic"><label>填写播放器的宽度</label><input type="text" name="wymusic_w" id="wymusic_w" value="310" /></div>
	<div class="wymusic"><label>是否自动播放音乐</label><select name="wymusic_auto" id="wymusic_auto"><option value="1">自动播放</option><option value="0">暂停播放</option></select></div>
	<div class="wymusic" style="float:left"><span id="wymusic_charu">插入代码</span><span id="wymusic_close">关闭工具</span></div>
	</div>
	<div class="clear"></div>
	<?php
}
addAction('adm_writelog_head', 'lanye_163music');

function lanye_163music_adm_footer(){
	if(Option::EMLOG_VERSION>"6.0.1"){
	?>
	<script>
	$(function(){
		layui.use(['layedit',"laypage"], function(){
			$(".layui-form .layui-layedit .layui-unselect.layui-layedit-tool").append('<div class="ke-wymusic" title="蓝叶网易音乐调用工具" id="open_lanyewymusic1"><span></span></div>');
			$("#wymusic_charu").click(function(){
				layedit.setContent(contentLayUIEditor,"<p><iframe frameborder='no' border='0' marginwidth='0' marginheight='0' width='"+($('#wymusic_w').val())+"' height='86' src='http://music.163.com/outchain/player?type=2&id="+($('#wymusic_id').val())+"&auto="+($('#wymusic_auto').val())+"&height=66'></iframe></p>",true);
			});
			$("#wymusic_close,#wymusic_charu").click(function(){
				$("#wymusicbox").slideUp(200);
			}); 
			$("#open_lanyewymusic1").click(function(){
				$("#wymusicbox").toggle();
			});
			$("#open_lanyewymusic2").click(function(){
				$("#wymusicbox").toggle();
			});
		});
	});
	</script>
	<?php
	}
}
addAction('adm_footer', 'lanye_163music_adm_footer');
?>