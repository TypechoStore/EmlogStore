<?php
/*
Plugin Name: 批量关闭评论
Version: 1.0
Plugin URL:
Description: 关闭旧日志评论，防止垃圾评论者入侵……
ForEmlog:5.X
Author: GW
Author Email: czczgw@gmail.com
Author URL: http://www.gw269.com


*/
!defined('EMLOG_ROOT') && exit('access deined!');

$DB = Database::getInstance();
$is_exist_id_query = $DB->query('describe `'.DB_PREFIX.'blog` `allow_tb`');
$is_exist_id = $DB->num_rows($is_exist_id_query);
if(!$is_exist_id){
	$DB->query("ALTER TABLE  `".DB_PREFIX."blog` ADD  `allow_tb` enum('y','n')  DEFAULT 'n'");
}

function close_comment()//写入插件导航
{
	echo '<div class="sidebarsubmenu" id="close_comment"><a href="./plugin.php?plugin=close_comment">关闭评论</a></div>';
}
addAction('adm_sidebar_ext', 'close_comment');


?>
