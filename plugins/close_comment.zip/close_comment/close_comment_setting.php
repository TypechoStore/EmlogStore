<?php 
/**
 * 批量关闭评论插件
 * @copyright (c) Emlog All Rights Reserved
 */
!defined('EMLOG_ROOT') && exit('access deined!');
function plugin_setting_view()
{
	$DB = Database::getInstance();
	echo '<div class=containertitle><b>批量关闭评论</b>';
?>
<?php if(isset($_GET['setting'])):?><span class="actived">关闭成功</span><?php endif;?>
<?php if(isset($_GET['error'])):?><span class="actived">未成功关闭</span><?php endif;?>
</div>
</div><div class=line></div>
<?php
$act = isset($_GET['act']) ? trim($_GET['act']) : '';
if($act):
	global $CACHE;
	switch ($act) {
		case 'shieldname':
			$id = isset($_GET['id']) ? intval($_GET['id']) : '';
			$DB->query("UPDATE ".DB_PREFIX."blog SET allow_remark='n' WHERE gid={$id}");
			$CACHE->updateCache(array('sta','blog'));
			header("Location: ./plugin.php?plugin=close_comment&advance=true&setting=true");
			break;
		case 'delurl':
			$id = isset($_GET['id']) ? intval($_GET['id']) : '';
			$DB->query("UPDATE ".DB_PREFIX."blog SET allow_tb='n' WHERE gid={$id}");
			$CACHE->updateCache(array('sta','blog'));
			header("Location: ./plugin.php?plugin=close_comment&advance=true&setting=true");
			break;
		case 'admin_all_coms':
			$operate = isset($_POST['operate']) ? $_POST['operate'] : '';
			$comments = isset($_POST['com']) ? array_map('intval', $_POST['com']) : array();
			$commentsId = '('.implode(',',$comments).')';
			switch ($operate) {
				case 'shieldname':
					$DB->query("UPDATE ".DB_PREFIX."blog SET allow_remark='n' WHERE gid IN{$commentsId}");
					$CACHE->updateCache(array('sta','blog'));
					header("Location: ./plugin.php?plugin=close_comment&advance=true&setting=true");
					break;
				case 'delurl':
					$DB->query("UPDATE ".DB_PREFIX."blog SET allow_tb='n' WHERE gid IN{$commentsId}");
					$CACHE->updateCache(array('sta','blog'));
					header("Location: ./plugin.php?plugin=close_comment&advance=true&setting=true");
					break;
			}
			break;
		

	}
else:
$blogid = isset($_GET['gid']) ? intval($_GET['gid']) : null;
$hide = isset($_GET['hide']) ? addslashes($_GET['hide']) : '';
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$ip = isset($_GET['ip']) ? addslashes($_GET['ip']) : '';
$poster = isset($_GET['poster']) ? addslashes($_GET['poster']) : '';
$addUrl_1 = $addUrl_2 = $addUrl_3 = $addUrl_4 = '';
if($blogid) {
	$addUrl_1 = "gid={$blogid}&";
	$blogid = "AND a.gid=$blogid";
}
if($hide) {
	$addUrl_2 = "hide=$hide&";
	$hide = "AND a.hide='$hide'";
}
if($ip) {
	$addUrl_3 = "ip=$ip&";
	$ip = "AND a.ip='$ip'";
}
if($poster) {
	$addUrl_4 = "poster=$poster&";
	$poster = "AND a.poster='$poster'";
}
$addUrl = $addUrl_1.$addUrl_2.$addUrl_3.$addUrl_4;
$perpage_num = Option::get('admin_perpage_num');
if($page)
{
	$startId = ($page - 1) * $perpage_num;
	$limit = " LIMIT $startId, ".$perpage_num;
}
$sql = "SELECT a.gid,a.title,a.date,a.comnum,a.allow_tb,a.excerpt,a.allow_remark,a.alias,b.sortid FROM ".DB_PREFIX."blog as a, ".DB_PREFIX."blog as b where 1=1 $blogid $hide $ip $poster AND a.gid=b.gid ORDER BY a.gid DESC";
$query = $DB->query($sql);
$cmnum = $DB->num_rows($query);
$query = $DB->query($sql.$limit);
$pageurl =  pagination($cmnum, $perpage_num, $page, "./plugin.php?plugin=close_comment&advance=true&{$addUrl}page=");
$sql = "SELECT a.gid,a.title,a.date,a.comnum,a.allow_tb,a.excerpt,a.allow_remark,a.alias,b.sortid FROM ".DB_PREFIX."blog as a, ".DB_PREFIX."blog as b where 1=1 $blogid AND a.hide='y' $ip AND a.gid=b.gid ORDER BY a.gid DESC";
$hideCommNum = $DB->num_rows($DB->query($sql));
?>
<form action="./plugin.php?plugin=close_comment&advance=true&act=admin_all_coms" method="post" name="form_com" id="form_com">
	<table width="100%" id="adm_comment_list" class="item_list">
		<thead>
			<tr>
				<th width="19"><a href="javascript:void(0);" id="select_all">全选</a></th>
				<th width="400"><b>标题</b></th>
				<th width="100"><b>日期</b></th>
				<th width="50"><b>评论数量</b></th>
				<th width="20"><b>评论</b></th>
				<th width="20"><b>引用</b></th>
			</tr>
		</thead>
		<tbody>
		<?php
		while($res = $DB->fetch_array($query)):
		$ishide = $res['hide']=='y'?'<font color="red">[待审]</font>':'';
		$mail = !empty($res['mail']) ? "({$res['mail']})" : '';
		$ip = !empty($res['ip']) ? "<br />IP：<a href=\"./plugin.php?plugin=close_comment&advance=true&ip={$res['ip']}\">{$res['ip']}</a>" : '';
		$url = !empty($res['url']) ? "({$res['url']})" : '';
		$res['content'] = str_replace('<br>',' ',$res['comment']);
		$sub_content = subString($res['content'], 0, 50);
		$res['title'] = subString($res['title'], 0, 42);
		?>
			<tr>
				<td><input type="checkbox" value="<?php echo $res['gid']; ?>" name="com[]" class="ids" /></td>
				<td>
				<a href="<?php echo BLOG_URL; ?>?post=<?php echo $res['gid']; ?>"  target="_blank" ><?php echo $res['title']; ?></a>
				
				
				<span style="display:none; margin-left:8px;">
				<a href="javascript: asc_confirm(<?php echo $res['gid']; ?>, 'name');">关闭评论</a>
				<a href="javascript: asc_confirm(<?php echo $res['gid']; ?>, 'url');">关闭引用</a>
				</span>
				
				
				</td>
				<td><?php echo smartDate($res['date']); ?></td>
						
					<td><a href="<?php echo BLOG_URL; ?>?post=<?php echo $res['gid']; ?>#comments"  target="_blank" ><?php echo $res['comnum']; ?></a></td><td>
				<?php if($res['allow_remark'] == "y" ): ?><img src="./views/images/plugin_active.gif" title="已开启评论" align="absmiddle" border="0"><?php else: ?><img src="./views/images/plugin_inactive.gif" title="已关闭评论" align="absmiddle" border="0"><?php endif; ?>
				</td><td>
				<?php if( $res['allow_tb'] == "y") : ?><img src="./views/images/plugin_active.gif" title="已开启引用" align="absmiddle" border="0"><?php else: ?><img src="./views/images/plugin_inactive.gif" title="已关闭引用" align="absmiddle" border="0"><?php endif; ?>
				
				
				</td>
			</tr>
		<?php endwhile; ?>
		</tbody>
	</table>
	<div class="list_footer">
	选中项：
	<a href="javascript:asc_commentact('shieldname');">关闭评论</a>
	<a href="javascript:asc_commentact('delurl');">关闭引用</a>
	<input name="operate" id="operate" res="" type="hidden" />
	</div>
	<div class="page"><?php echo $pageurl; ?> (有<?php echo $cmnum; ?>篇日志)</div> 
</form>
<p class="des">这个插件是为了方便批量关闭评论而设计的，可以使一些人不再回复很久以前的日志。实际上我在2010年就想设计这个插件，但一直没有定下计划。感谢奇遇的反垃圾评论插件提供灵感和有关代码。</p>
<script>
$(document).ready(function(){
	$("#adm_comment_list tbody tr:odd").addClass("tralt_b");
	$("#adm_comment_list tbody tr")
		.mouseover(function(){$(this).addClass("trover");$(this).find("span").show();})
		.mouseout(function(){$(this).removeClass("trover");$(this).find("span").hide();})
	$("#select_all").toggle(function () {$(".ids").attr("checked", "checked");},function () {$(".ids").removeAttr("checked");});
});
setTimeout(hideActived,2600);
function asc_commentact(act){
	if (getChecked('ids') == false) {
		alert('请选择要操作的日志');
		return;
	}
	if(act == 'shieldname' && !confirm('你确定要禁止评论本日志？')){return;}
	if(act == 'delurl' && !confirm('你确定要禁止向本日志发送引用通告？')){return;}
	$("#operate").val(act);
	$("#form_com").submit();
}
function asc_confirm (id, property) {
	switch (property){
		case 'name':
		var urlreturn="./plugin.php?plugin=close_comment&advance=true&act=shieldname&id="+id;
		var msg = "你确定要禁止评论本日志？";break;
		case 'url':
		var urlreturn="./plugin.php?plugin=close_comment&advance=true&act=delurl&id="+id;
		var msg = "你确定要禁止向本日志发送引用通告？";break;
	}
	if(confirm(msg)){window.location = urlreturn;}else {return;}
}
</script>
<?php endif; ?>
<script>
$("#close_comment").addClass('sidebarsubmenu1');
</script>
<?php 
}
function plugin_setting()
{
	$time_limit = isset($_POST['time_limit']) ? intval(trim($_POST['time_limit'])) : 0;
	$need_chinese = isset($_POST['need_chinese']) ? intval($_POST['need_chinese']) : 0;
	$blacklist = isset($_POST['blacklist']) ? trim($_POST['blacklist']) : '';
	$auto_blacklist = isset($_POST['auto_blacklist']) ? intval($_POST['auto_blacklist']) : 0;
	$max_attempt = isset($_POST['max_attempt']) ? intval(trim($_POST['max_attempt'])) : 0;
	$keywords = isset($_POST['keywords']) ? trim($_POST['keywords']) : '';
	$name_keywords = isset($_POST['name_keywords']) ? trim($_POST['name_keywords']) : '';
	$url_keywords = isset($_POST['url_keywords']) ? trim($_POST['url_keywords']) : '';
	$data = serialize(array(
		'time_limit' => $time_limit,
		'need_chinese' => $need_chinese,
		'blacklist' => preg_split("/[\r\n]+/", $blacklist),
		'auto_blacklist' => $auto_blacklist,
		'max_attempt' => $max_attempt,
		'keywords' => $keywords,
		'name_keywords' => $name_keywords,
		'url_keywords' => preg_split("/[\r\n]+/", $url_keywords)
		));
	$file = EMLOG_ROOT.'/content/plugins/close_comment/data';
	@ $fp = fopen($file, 'wb') OR emMsg('读取文件失败，如果您使用的是Unix/Linux主机，请修改文件/content/plugins/close_comment/data的权限为777。如果您使用的是Windows主机，请联系管理员，将该文件设为everyone可写');
	@ $fw =	fwrite($fp,$data) OR emMsg('写入文件失败，如果您使用的是Unix/Linux主机，请修改文件/content/plugins/close_comment/data的权限为777。如果您使用的是Windows主机，请联系管理员，将该文件设为everyone可写');
	fclose($fp);
	return TRUE;
}
?>