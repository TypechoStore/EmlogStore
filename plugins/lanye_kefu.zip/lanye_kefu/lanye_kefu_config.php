<?php
$config = array(
 "ly_div_weizhi" => "right",
 "ly_div_top" => "120px",
 "ly_div_color" => "#666",
 "ly_div_qq" => "84953409",
	"ly_div_daima" => "<div class='kf_diy'><a href='http://music.lanyes.org' target='_blank' rel='nofollow'>音乐欣赏</a></div> <div class='kf_diy'><a href='http://lanyes.org/liuyanben.html' target='_blank'>给我留言</a></div>"
);