<?php
	$related_log_type = 'sort';
	$related_log_sort = 'views_asc';
	$related_log_num = '5';
	$related_inrss = 'y';
?>