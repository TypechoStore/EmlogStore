<?php
define('QZONE_SYNC','1');
define('QZONE_TFROM','4');
define('QZONE_BLOG','6');
