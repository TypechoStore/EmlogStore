<div class="em_ad_button_window">
	<?php echo $ad_html ?>
</div>