<?php defined('EMLOG_ROOT') or die('本页面禁止直接访问!'); ?>
<?php echo $ad_style?>
<?php echo $ad_html?>