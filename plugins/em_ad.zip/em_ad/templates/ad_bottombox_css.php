<style type="text/css">
.em_ad_button_window {
	width: <?php echo $width ?>px;
	height: <?php echo $height ?>px;
	position: fixed;
	<?php if ($ad_position == 'right'):?>
	right: 0;
	<?php else:?>
	left: 0;
	<?php endif;?>
	bottom: 0;
	
}
</style>