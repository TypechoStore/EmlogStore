<?php
/*
Plugin Name: 全站开启SSL插件
Version: 1.0
Plugin URL: http://tv1314.com
Description: 全站开启ssl插件，无需操作数据库，关闭插件即可还原，需index_footer挂载点
Author: 鬼少
Author Email: 594483473@qq.com
Author URL: http://tv1314.com
*/
function gs_ssl_ext() {
	$content = ob_get_clean();
	ob_start();
	$https = strtr(BLOG_URL,array("http://"=>"https://"));
    $http = strtr(BLOG_URL,array("https://"=>"http://"));
	echo strtr($content,array($http=>$https,BLOG_URL=>$https));
}
addAction('index_footer','gs_ssl_ext');