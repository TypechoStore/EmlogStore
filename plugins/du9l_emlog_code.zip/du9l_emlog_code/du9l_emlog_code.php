<?php
/*
Plugin Name: 自定义代码
Version: 0.4.512
Plugin URL: http://du9l.com
Description: 本插件允许你在系统特定位置插入自定义 HTML 代码，或输出纯文本内容。 -- 版权所有 (C) 2012-2013  Xiaodu @ Du9L.com 使用 GNU GPLv2（或更新版本）协议授权, 查看 COPYING 文件了解详情.
ForEmlog: 5.0.0 - 5.1.2
Author: Xiaodu @ Du9L.com
Author URL: http://du9l.com
*/

/*

	This file is part of Du9L_emlog_code, a plug-in of emlog <http://emlog.net>
	Copyright (C) 2012-2013	Xiaodu @ <http://du9l.com> <dujiulun2006@126.com>

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
		
*/

	require_once('du9l_emlog_code_config.php');
	
	function du9l_emlog_code() {
		global $du9l_emlog_code_list;
	
		foreach( $du9l_emlog_code_list as $k => $v )
			foreach( $v as $kk => $vv ) {
				if ($kk === 0) continue;
				$f = du9l_emlog_code_file($kk);
				if (!@file_exists($f)) continue;
				$c = @file_get_contents($f);
				if($c) {
					$p = 'echo \'' .($c). '\';';
					$h = create_function('', $p);
					addAction($kk, $h);
				}
			}
	}
	
	function du9l_emlog_code_menu() {
		echo '<div class="sidebarsubmenu" id="du9l_emlog_code"><a href="./plugin.php?plugin=du9l_emlog_code">自定义代码</a></div>';
	}
	
	addAction('adm_sidebar_ext', 'du9l_emlog_code_menu');
	du9l_emlog_code();
?>
