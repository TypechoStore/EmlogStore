<?php

/*

	This file is part of Du9L_emlog_code, a plug-in of emlog <http://emlog.net>
	Copyright (C) 2012-2013	Xiaodu @ <http://du9l.com> <dujiulun2006@126.com>

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
		
*/

	!defined('EMLOG_ROOT') && exit('access denied!');
	
	$du9l_emlog_code_ver  = '0.4.512';
	$du9l_emlog_code_path = EMLOG_ROOT . '/content/plugins/du9l_emlog_code/';
	$du9l_emlog_code_data = $du9l_emlog_code_path . 'data/';
	$du9l_emlog_code_url  = BLOG_URL . 'admin/plugin.php?plugin=du9l_emlog_code';
	$du9l_emlog_code_list = array(
		array( 0 => '直接显示的接口，适合插入各页面通用的HTML',
			'index_head'		=> '前台&lt;head&gt;代码扩展：可以用于增加前台css样式、加载js等',
			'index_footer'		=> '首页底部扩展点',
			'index_loglist_top' => '日志列表顶部扩展点，如显示公告等',
			'navbar'			=> '用于扩展导航条，例如相册插件会利用这个挂载点生成一个相册的导航链接',
			'log_related'		=> '阅读日志页面扩展点，用于增加日志相关内容（暂不支持参数）',
			'rss_display'		=> 'Rss输出扩展（建议不要输出HTML，而是输出RSS格式 <!-- Du9L.com --> ）',
			'diff_side'			=> '侧边栏控制扩展点',
			'comment_reply'		=> '回复评论扩展点'
		),
		array( 0 => '特定操作的接口，适合插入特定操作触发的HTML',
			'comment_post'			=> '发表评论扩展点（写入评论前）。可用于垃圾评论防范',
			'comment_saved'			=> '发表评论扩展点（写入评论后）。用于发布评论成功的后续操作，如发通知邮件'
			//,'reply_twitter'			=> '回复碎语扩展点，用于回复邮件提醒等',
			// 'post_twitter'			=> '发布碎语扩展点，用于碎语和其他微博类产品同步等'
			// 注释这两行，因为有t**r的字样，如果有需要请自行打开使用
		),
		array( 0 => '后台显示的接口，用于后台显示的HTML，包括通用和特定操作型。' . 
					'<b><font color="red">请谨慎修改，否则可能无法进入后台！如果不是很明白请不要修改！！</font></b>' . 
					'如果真的无法进入后台，到插件目录的data下删除对应代码文件即可。',
			'adm_main_top'			=> '后台顶部区域扩展',
			'adm_head'				=> '后台&lt;head&gt;代码扩展：可以用于增加后台css样式、加载js等',
			'adm_footer'			=> '后台底部扩展：可以用于增加后台js等',
			'adm_siderbar_ext'		=> '后台侧边栏 功能扩展 子菜单扩展，用于插件单独页面。',
			'save_log'				=> '新增日志、修改日志扩展点',
			'del_log'				=> '删除日志操作扩展点',
			'adm_writelog_head' 	=> '在后台日志编辑页面显示扩展内容，如插入网络相册照片的插件。',
			'data_prebakup'			=> '扩展备份数据库页面，可以对插件增加的表进行备份',
			'adm_comment_display'	=> '后台评论显示扩展，可以用于查询评论人ip所在地域'
		)
	);
	
	function du9l_emlog_code_file( $n ) {
		//global $du9l_emlog_code_list, $du9l_emlog_code_data;
		//if( !isset($du9l_emlog_code_list[$n]) ) return false;
		global $du9l_emlog_code_data;
		return $du9l_emlog_code_data . $n;
	}
	
	function du9l_emlog_code_encode( $s ) {
		$s = str_replace('\\', '\\\\', $s);
		$s = str_replace('\'', '\\\'', $s);
		return $s;
	}
	
	function du9l_emlog_code_decode( $s ) {
		$s = str_replace('\\\'', '\'', $s);
		$s = str_replace('\\\\', '\\', $s);
		return $s;
	}
	
	function du9l_emlog_code_writable( ) {
		global $du9l_emlog_code_path;
		$r = @is_writable($du9l_emlog_code_path);
		return ($r !== false);
	}
	
	function du9l_emlog_code_exists( $n ) {
		$f = du9l_emlog_code_file($n);
		$r = @file_exists($f);
		return (!!$r);
	}
?>
