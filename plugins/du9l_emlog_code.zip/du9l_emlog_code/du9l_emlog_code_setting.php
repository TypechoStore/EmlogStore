<?php

/*

	This file is part of Du9L_emlog_code, a plug-in of emlog <http://emlog.net>
	Copyright (C) 2012-2013	Xiaodu @ <http://du9l.com> <dujiulun2006@126.com>

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
		
*/

	require_once('du9l_emlog_code_config.php');
	
	function plugin_setting_view() {
		global $du9l_emlog_code_list, $du9l_emlog_code_url, $du9l_emlog_code_ver;
	
		// 检查 n 的值是否存在并合法
		$n = $_GET['n'];
		if (!$n || $n === 0 || $n === '0') {
			$f = $n = null;
		} else {
			$nb = false;
			foreach( $du9l_emlog_code_list as $k => $v )
				if (isset($v[$n])) {
					$nb = true;
					$f = du9l_emlog_code_file($n);
					$nd = $v[$n];
					break;
				}
			if (!$nb) $f = $n = null;
		}

		
		if( ($_SERVER['REQUEST_METHOD'] == 'POST') && $n ) {
		
			// 保存模式
			$content = trim($_POST['d']);
			if($content) {
				$d = du9l_emlog_code_encode($_POST['d']);
				$r = @file_put_contents($f, $d);
				$u = $du9l_emlog_code_url . '&result=' . ( ($r===false) ? 'false' : 'true');
			} else {
				$r = @unlink($f);
				$u = $du9l_emlog_code_url . '&result=' . ( ($r===false) ? 'delfalse' : 'deltrue');
			}
			header('Location: ' . $u, true, 302);
			
		} else {
		
			if (!du9l_emlog_code_writable()) {
				echo '<div class="error">警告：插件目录<i>可能</i>不可写，您将无法正常使用插件。' . 
					 '请将插件目录（博客目录/content/plugins/du9l_emlog_code/）下的data文件夹设置为可写（777）权限。</div>';
			}
		
			if( $n ) {
				// 修改模式
				$c = @file_get_contents($f);
				if($c) $c = du9l_emlog_code_decode($c);
				echo '<p>当前修改的是： ' . $n . ' -- ' . $nd . '。</p>
							<form action="'.$du9l_emlog_code_url.'&n='.$n.'" method="post">输入要显示的代码：（支持 HTML 或纯文本，<b>不运行</b>PHP）
							<b>注意：不想使用某项时请清空，可以提高一点效率。</b><br />
							<textarea rows="30" cols="100" name="d">' . htmlspecialchars($c) . '</textarea>
							<input type="submit" value="保存" /></form>';
			} else {
			
				// 获取上次结果
				switch($_GET['result']) {
					case 'true':
						echo '<p><span class="actived">修改成功！</span></p>';
					break;
					case 'false':
						echo '<p><span class="error">修改失败！TOT</span></p>';
					break;
					case 'deltrue':
						echo '<p><span class="actived"><b>删除</b>成功！</span></p>';
					break;
					case 'delfalse':
						echo '<p><span class="error"><b>删除</b>失败！TOT</span></p>';
					break;
				}
				
				// 显示列表
				echo '<div class="des">本插件允许你在系统特定位置<b>插入自定义 HTML 代码，或输出纯文本内容</b></div>';
				echo '<p>点击相应条目进入修改代码：（加粗为已经使用的代码）</p><ol>';
				
				foreach( $du9l_emlog_code_list as $k => $v ) {
					echo '<li style="list-style-type: decimal">' . $v[0] . '<ul>';
					foreach( $v as $kk => $vv ) {
						if ($kk === 0) continue;
						$ne = du9l_emlog_code_exists($kk);
						echo $ne ?
							'<li style="list-style-type: square"><b><a href="' . $du9l_emlog_code_url . '&n=' . $kk . '">'
								. $kk . '</a></b>：' . $vv . '</li>' :
							'<li style="list-style-type: square"><a href="' . $du9l_emlog_code_url . '&n=' . $kk . '">'
								. $kk . '</a>：' . $vv . '</li>';
					}
					echo '</ul></li>';
				}
				
				echo '</ol><p>du9l_emlog_code 插件当前运行版本：'. htmlspecialchars($du9l_emlog_code_ver) .
					 ' <a href="http://www.emlog.net/plugin/97" target="_blank">插件官网地址</a></p>';
				echo '<p>Powered by <a href="http://du9l.com/" target="_blank">Xiaodu @ Du9L.com</a>' .
					 ' 如果希望支持作者，欢迎 <a href="https://me.alipay.com/dujiulun/" target="_blank">捐助开发</a></p>';
			}
			
			echo '<script>$("#du9l_emlog_code").addClass("sidebarsubmenu1");setTimeout(hideActived,2600);</script>';
			
		}
	}
?>
