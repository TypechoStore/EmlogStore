<?php
$config = array(
	"xl" => "player",
	"jq" => "close",
	"mb" => "open",
	"id" => "demo"
);