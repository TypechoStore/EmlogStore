<?php
/*
Plugin Name: LYplayer
Version: 1.0
Plugin URL: http://lanyes.org
Description: 蓝叶音乐播放器,LYplayer播放器。
Author: 蓝叶
Author Email: w@lanyes.org
Author URL: http://lanyes.org
*/
!defined('EMLOG_ROOT') && exit('access deined!');
function lyplayer_tool(){?>
<script>
$(document).ready(function(){
	$(".lyplayer_charu").click(function(){
		if(typeof($('#markdownEditor_content').val())!='undefined'){
			$('#markdownEditor_content').val($('#markdownEditor_content').val()+"<p><embed src='<?php echo BLOG_URL;?>content/plugins/lanye_lyplayer/Lyplayer.swf?path="+($('#mediaurl').val())+"&type="+($('#mediatype').val())+"&autoplay="+($('#mediaauto').val())+"&fullscreen="+($('#mediafull').val())+"&thumbnail="+($('#mediaimg').val())+"' type='application/x-shockwave-flash' width='"+($('#mediawidth').val())+"' height='"+($('#mediaheight').val())+"' quality='high' /></p>");
		}else if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
			layedit.setContent(contentLayUIEditor,"<p><embed src='<?php echo BLOG_URL;?>content/plugins/lanye_lyplayer/Lyplayer.swf?path="+($('#mediaurl').val())+"&type="+($('#mediatype').val())+"&autoplay="+($('#mediaauto').val())+"&fullscreen="+($('#mediafull').val())+"&thumbnail="+($('#mediaimg').val())+"' type='application/x-shockwave-flash' width='"+($('#mediawidth').val())+"' height='"+($('#mediaheight').val())+"' quality='high' /></p>",true);
		}else{
			$($(".ke-edit-iframe:first").contents().find(".ke-content")).append("<p><embed src='<?php echo BLOG_URL;?>content/plugins/lanye_lyplayer/Lyplayer.swf?path="+($('#mediaurl').val())+"&type="+($('#mediatype').val())+"&autoplay="+($('#mediaauto').val())+"&fullscreen="+($('#mediafull').val())+"&thumbnail="+($('#mediaimg').val())+"' type='application/x-shockwave-flash' width='"+($('#mediawidth').val())+"' height='"+($('#mediaheight').val())+"' quality='high' /></p>");
		}
	});
	/*关闭按钮*/
	$(".lyplayer_close").click(function(){
	$("#lyplayer_con").css("display","none");}); 
	$("#lyplayer_title").click(function(){
	$("#lyplayer_con").css("display","block");}); 
	$('#mediatype').change(function(){
		if($(this).val()=="flv" || $(this).val()=="mp4"){
			$("#mediaheight").val("400");
			$(".medimg,.medfull").css("display","block");
		}else if($(this).val()=="mp3" || $(this).val()=="xml"){
			$("#mediaheight").val("27");
			$(".medimg,.medfull").css("display","none");
		}
	});
});
</script>
<style>
#lyplayer_box{font-weight:bold;font-size:12px;margin:5px 0; cursor:pointer;}
#lyplayer_con{font-weight:normal;margin:5px 0 10px 0;display:none;border: 1px solid #ccc;padding: 10px;width:500px;float:left}
#lyplayer_con p{margin:0 0 10px 0;font-size:14px;}
#lyplayer_con input[type="text"]{width:400px;font-size:12px;}
#lyplayer_con span{cursor:pointer;padding:10px 10px;float:left;font-size: 14px;margin: 0 10px 0 0;background: #5cb85c;color:#fff;font-weight:bold;}
#lyplayer_con span:hover{background:#00aff0 !important;color:#fff !important;}
#mediawidth,#mediaheight{width:55px !important;}
.medimg,.medfull{display:none;}
</style>
<div id="lyplayer_box">
<div id="lyplayer_title">Lyplayer</div> 
<div id="lyplayer_con">
<p>设置类型：<select name="mediatype" id="mediatype"><option value="mp3">mp3模式</option><option value="flv">flv模式</option><option value="mp4">mp4模式</option><option value="xml">xml模式</option></select></p>
<p>文件地址：<input type="text" name="mediaurl" id="mediaurl" value="" /></p>
<p class="medimg">图片地址：<input type="text" name="mediaimg" id="mediaimg" value="" /></p>
<p>设置宽度：<input type="text" name="mediawidth" id="mediawidth" value="100%" /></p>
<p>设置高度：<input type="text" name="mediaheight" id="mediaheight" value="27" /></p>
<p>自动播放：<select name="mediaauto" id="mediaauto"><option value="true">自动</option><option value="false">禁止</option></select></p>
<p class="medfull">是否全屏：<select name="mediafull" id="mediafull"><option value="true">全屏</option><option value="false">禁止</option></select></p>
<p style="margin:10px 0 10px 0px;"><span class="lyplayer_charu">插入代码</span> <span class="lyplayer_close">关闭工具</span></p></div>
</div><div style="clear:both"></div>
<?php }
addAction('adm_writelog_head', 'lyplayer_tool');