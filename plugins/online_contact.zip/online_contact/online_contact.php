<?php
/**
 * Plugin Name: 在线QQ悬浮插件
 * Version: 1.0
 * Plugin URL: http://www.liuzp.com/plug/8.html
 * Description: 可以在网站悬浮显示在线客服QQ，支持多种风格。<br />
 * Author: Liuzp
 * Author Email: root@liuzp.com
 * Author URL: http://www.liuzp.com
 */
 
!defined('EMLOG_ROOT') && exit('access deined!');

function online_contact(){
	require_once 'online_contact_config.php';
	echo '<link rel="stylesheet" type="text/css" href="'.BLOG_URL.'content/plugins/online_contact/style/'.$config["css"].'.css"/>';
	echo '<script language="javascript" src="'.BLOG_URL.'include/lib/js/jquery/jquery-1.7.1.js"></script>';
	echo '<script language="javascript" src="'.BLOG_URL.'content/plugins/online_contact/js/jquery.Sonline.js"></script>';
	?>
	<script type="text/javascript">
	$(function(){
		$().Sonline({
			Position:"<?php echo $config["position"]; ?>",
			Top:<?php echo $config["top"]; ?>,
			Width:<?php echo $config["width"]; ?>,
			Style:<?php echo $config["icoStyle"]; ?>,
			Effect:<?php echo $config["effect"]; ?>,
			DefaultsOpen:<?php echo $config["orOpen"]; ?>,
			Tel:"<?php echo $config["tel"]; ?>",
			Qqlist:"<?php echo $config["qqlist"]; ?>"
		});
	})	
	</script>
	<?php
}

function online_contact_menu() {
	echo '<div class="sidebarsubmenu" id="online_contact"><a href="./plugin.php?plugin=online_contact">在线QQ悬浮</a></div>';
}
addAction('index_head', 'online_contact');
addAction('adm_sidebar_ext', 'online_contact_menu');