<?php
$config = array(
	"position" => "right",
	"top" => "100",
	"width" => "100",
	"icoStyle" => "1",
	"css" => "green",
	"effect" => "true",
	"orOpen" => "true",
	"tel" => "400-888-8888",
	"qqlist" => "3299152|售前咨询1,3299152|售前咨询2,3299152|售后咨询1"
);