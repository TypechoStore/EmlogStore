<?php
/**
 * Plugin Name: 在线QQ悬浮插件
 * Version: 1.0
 * Plugin URL: http://www.liuzp.com/plug/8.html
 * Description: 可以在网站悬浮显示在线客服QQ，支持多种风格。<br />
 * Author: Liuzp
 * Author Email: root@liuzp.com
 * Author URL: http://www.liuzp.com
 */

!defined('EMLOG_ROOT') && exit('access deined!');
function plugin_setting_view(){
	require_once 'online_contact_config.php';
	?>
	<link href="/content/plugins/online_contact/style.css" type="text/css" rel="stylesheet" />
	<div class="com-hd">
		<b>在线QQ悬浮设置</b>
		<?php
		if(isset($_GET['setting'])){
			echo "<span class='actived'>设置保存成功!</span>";
		}
		?>
	</div>
	<form action="plugin.php?plugin=online_contact&action=setting" method="post">
		<table class="tb-set">
			<tr>
				<td align="right" width="25%"><b>悬浮位置：</b></td>
				<td width="75%"><span class="sel"><select name="position"><option value="left" <?php if($config["position"]=="left") echo "selected"; ?>>居左</option><option value="right" <?php if($config["position"]=="right") echo "selected"; ?>>居右</option></select></span></td>
			</tr>
			<tr>
				<td align="right"><b>顶部距离：</b></td>
				<td><input type="text" class="txt txt-sho" name="top" value="<?php echo $config["top"]; ?>" /> px</td>
			</tr>
			<tr>
				<td align="right"><b>悬浮框宽度：</b></td>
				<td><input type="text" class="txt txt-sho" name="width" value="<?php echo $config["width"]; ?>" /> px</td>
			</tr>
            <tr>
				<td align="right" width="25%"><b>颜色风格：</b></td>
				<td width="75%"><span class="sel">
					<select name="css">
						<option value="default_blue" <?php if($config["css"]=="default_blue") echo "selected"; ?>>蓝色</option>
						<option value="gray" <?php if($config["css"]=="gray") echo "selected"; ?>>灰色</option>
						<option value="green" <?php if($config["css"]=="green") echo "selected"; ?>>绿色</option>
						<option value="red" <?php if($config["css"]=="red") echo "selected"; ?>>红色</option>
					</select></span>
				</td>
			</tr>
            <tr>
				<td align="right" width="25%"><b>QQ图标风格：</b></td>
				<td width="75%"><span class="sel">
					<select name="icoStyle" id="icoStyle">
						<option value="1" data-real="41" <?php if($config["icoStyle"]=="1") echo "selected"; ?>>1</option>
						<option value="2" data-real="42" <?php if($config["icoStyle"]=="2") echo "selected"; ?>>2</option>
						<option value="3" data-real="44" <?php if($config["icoStyle"]=="3") echo "selected"; ?>>3</option>
						<option value="4" data-real="45" <?php if($config["icoStyle"]=="4") echo "selected"; ?>>4</option>
						<option value="5" data-real="46" <?php if($config["icoStyle"]=="5") echo "selected"; ?>>5</option>
						<option value="6" data-real="47" <?php if($config["icoStyle"]=="6") echo "selected"; ?>>6</option>
					</select></span>&nbsp;&nbsp;<img id="icoStyleImg" border="0" src="http://wpa.qq.com/pa?p=2:3299152:41">
				</td>
			</tr>
			<tr>
				<td align="right"><b>服务电话：</b></td>
				<td><input type="text" class="txt" name="tel" value="<?php echo $config["tel"]; ?>" /></td>
			</tr>
			<tr>
				<td align="right"><b>其他：</b></td>
				<td><input type="checkbox" name="effect" value="true" <?php if($config["effect"]=="true") echo "checked"; ?> />&nbsp;是否滚动&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" name="orOpen" value="true" <?php if($config["orOpen"]=="true") echo "checked"; ?> />&nbsp;是否展开</td>
			</tr>
			<tr>
				<td align="right"><b>QQ列表：</b><br />(格式：QQ号|显示名称，多个用“,”分隔。如：3299152|客服1,123456|客服2。)</td>
				<td><textarea class="txt txt-lar" name="qqlist"><?php echo $config["qqlist"]; ?></textarea></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><input type="submit" name="submit" value="保存" /></td>
			</tr>
		</table>
	</form>
	<script>
		$(function(){
			$("#icoStyleImg").attr("src", "http://wpa.qq.com/pa?p=2:3299152:"+$("#icoStyle option:selected").attr("data-real"));
			$("#icoStyle").change(function(){$("#icoStyleImg").attr("src", "http://wpa.qq.com/pa?p=2:3299152:"+$(this).children("option:selected").attr("data-real"));});
		});
	</script>
	<?php
}

function plugin_setting(){
	require_once 'online_contact_config.php';
	$top = $_POST["top"]==""?"100":$_POST["top"];
	$width = $_POST["width"]==""?"165":$_POST["width"];
	$effect = $_POST["effect"]=="true"?"true":"false";
	$orOpen = $_POST["orOpen"]=="true"?"true":"false";
	$newConfig = '<?php
$config = array(
	"position" => "'.$_POST["position"].'",
	"top" => "'.$top.'",
	"width" => "'.$width.'",
	"icoStyle" => "'.$_POST["icoStyle"].'",
	"css" => "'.$_POST["css"].'",
	"effect" => "'.$effect.'",
	"orOpen" => "'.$orOpen.'",
	"tel" => "'.$_POST["tel"].'",
	"qqlist" => "'.str_replace("\r\n", "", $_POST["qqlist"]).'"
);';
	echo $newConfig;
	@file_put_contents(EMLOG_ROOT.'/content/plugins/online_contact/online_contact_config.php', $newConfig);
}
?>