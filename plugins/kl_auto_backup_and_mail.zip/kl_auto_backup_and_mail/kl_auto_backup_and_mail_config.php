<?php
define('KL_AUTO_BACKUP_AND_MAIL_SMTP','smtp.126.com'); //smtp服务器

define('KL_AUTO_BACKUP_AND_MAIL_PORT','25'); //smtp端口

define('KL_AUTO_BACKUP_AND_MAIL_SENDEMAIL','xxx@126.com'); //发信邮箱

define('KL_AUTO_BACKUP_AND_MAIL_PASSWORD','xxxxxx'); //发信密码

define('KL_AUTO_BACKUP_AND_MAIL_TOEMAIL','xxx@qq.com'); //收信邮箱

define('KL_AUTO_BACKUP_AND_MAIL_THE_TIME','120');

define('KL_AUTO_BACKUP_AND_MAIL_SENDTYPE','1');

define('KL_AUTO_BACKUP_AND_MAIL_ISZIP','1');

define('KL_AUTO_BACKUP_AND_MAIL_LAST_BACKUP_FILE','');
?>