<?php
if(!defined('EMLOG_ROOT')) {exit('error!');}
function callback_init(){
    $db = Database::getInstance();
    $db->query("CREATE TABLE IF NOT EXISTS `".DB_PREFIX."tedown` (
        `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
        `logid` int(10) unsigned NOT NULL,
        `TD_start` enum('n','y') NOT NULL DEFAULT 'n',
		`TD_type` varchar(10) NOT NULL DEFAULT '0',
        `TD_name` varchar(255) NOT NULL,
        `TD_size` varchar(10) NOT NULL,
        `TD_date` varchar(20) NOT NULL,
        `TD_down1` varchar(150) NOT NULL,
        `TD_down2` varchar(150) NOT NULL,
        `TD_pass` varchar(150) NOT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;");
}
?>