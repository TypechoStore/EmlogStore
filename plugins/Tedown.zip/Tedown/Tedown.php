<?php
/*
Plugin Name: Telib主题下载插件
Version: 1.0
Plugin URL:http://www.cainly.cn
Description: Bird主题专用下载插件，使用：要在模板的echo_log.php合适位置加上挂载点&lt;?php doAction('down_log',$logid);?>
Author: 小李哥
Author URL:http://www.cainly.cn
*/
define('TELIB_URL', BLOG_URL . 'content/plugins/Tedown/');
?>
<?php
/* 添加 */
function TD_addlog($logData) {
    $db = Database::getInstance();
    $kItem = array();
    $dItem = array();
    foreach ($logData as $key => $data) {
        $kItem[] = $key;
        $dItem[] = $data;
    }
    $field = implode(',', $kItem);
    $values = "'" . implode("','", $dItem) . "'";
    $db->query("INSERT INTO " . DB_PREFIX . "tedown ($field) VALUES ($values)");
    $logid = $db->insert_id();
    return $logid;
}
/* 更新 */
function TD_upLog($logData, $blogId) {
    $db = Database::getInstance();
    $Item = array();
    foreach ($logData as $key => $data) {
        $Item[] = "$key='$data'";
    }
    $upStr = implode(',', $Item);
    $db->query("UPDATE " . DB_PREFIX . "tedown SET $upStr WHERE logid=$blogId");
}
function Tedown_setting_add($logid){
    $db = Database::getInstance();
    $data = $db->query("SELECT * FROM ".DB_PREFIX."tedown WHERE logid ='$logid'");
    $TD_start = isset($_POST['TD_start']) ? addslashes(trim($_POST['TD_start'])) : 'n';
    $TD_name = isset($_POST['TD_name']) ? addslashes(trim($_POST['TD_name'])) : '';
	$TD_type = isset($_POST['TD_type']) ? addslashes(trim($_POST['TD_type'])) : '';
    $TD_size = isset($_POST['TD_size']) ? addslashes(trim($_POST['TD_size'])) : '';
    $TD_date = isset($_POST['TD_date']) ? addslashes(trim($_POST['TD_date'])) : '';
    $TD_down1 = isset($_POST['TD_down1']) ? addslashes(trim($_POST['TD_down1'])) : '';
    $TD_down2 = isset($_POST['TD_down2']) ? addslashes(trim($_POST['TD_down2'])) : '';
    $TD_pass = isset($_POST['TD_pass']) ? addslashes(trim($_POST['TD_pass'])) : '';
    
    $logData = array('logid' => $logid,'TD_start' => $TD_start,'TD_type' => $TD_type,'TD_name' => $TD_name,'TD_size' => $TD_size,'TD_date' => $TD_date,'TD_down1' => $TD_down1,'TD_down2' => $TD_down2,'TD_pass' => $TD_pass,);
    $UplogData = array('TD_start' => $TD_start,'TD_type' => $TD_type,'TD_name' => $TD_name,'TD_size' => $TD_size,'TD_date' => $TD_date,'TD_down1' => $TD_down1,'TD_down2' => $TD_down2,'TD_pass' => $TD_pass,);
    if($db->fetch_array($data) == ""){
        TD_addlog($logData);
    }else{
        TD_upLog($UplogData, $logid);
    }
}
addAction('save_log', 'Tedown_setting_add');
function Tedown_option(){
    $query = $_SERVER["QUERY_STRING"];
    $string = preg_replace('/action=edit&gid=/','',$query);
    $db = Database::getInstance();
    $data = $db->query("SELECT * FROM ".DB_PREFIX."tedown WHERE logid ='".$string."'");
    $row = $db->fetch_array($data);
    if($row == ''){
        $logData = array('TD_start' => '','TD_type' => '','TD_name' => '','TD_size' => '','TD_date' => '','TD_down1' => '','TD_down2' => '','TD_pass' => '');
    }else{
        $logData = array(
            'TD_start' => htmlspecialchars($row['TD_start']),
			'TD_type' => htmlspecialchars($row['TD_type']),
            'TD_name' => htmlspecialchars($row['TD_name']),
            'TD_size' => htmlspecialchars($row['TD_size']),
            'TD_date' => htmlspecialchars($row['TD_date']),
            'TD_down1' => htmlspecialchars($row['TD_down1']),
            'TD_down2' => htmlspecialchars($row['TD_down2']),
            'TD_pass' => htmlspecialchars($row['TD_pass'])
        );
    }
    
?>
<link href="<?php echo TELIB_URL;?>Class/css/bootstrap.css" type="text/css" rel="stylesheet">
<a href="#Tedown" data-toggle="modal" class="btn btn-default">附件下载</a>
<div class="modal fade" id="Tedown" tabindex="-1" role="dialog" aria-labelledby="TedownLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button aria-hidden="true" data-dismiss="modal" class="close" type="button"> <i class="zmdi zmdi-close"></i> </button>
				<h4 class="modal-title" id="TedownLabel">下载配置 </h4>
			</div>
			<div class="modal-body">
				<table class="table">
					<tbody>
						<tr>
							<th style="width:10%;"><label>启用下载</label></th>
							<th>
									<input type="checkbox" name="TD_start" id="TD_start" title="启用" value="y" <?php if($logData['TD_start'] == 'y'){echo ' checked';}?>>
									<span></span>
							</th>
							<th style="width:10%;"><label>下载方式</label></th>
							<th>
								<select id="TD_type" class="form-control" name="TD_type" style="width: 85%;">
									<option value="0" <?php if($logData['TD_type'] == '0'){?>selected="selected"<?php }?>>默认下载</option>
									<option value="1" <?php if($logData['TD_type']=='1'){?>selected="selected"<?php }?>>回复下载</option>
								</select>
							</th>
						</tr>
						<tr>
							<th style="width:15%;"><label>资源名称</label></th>
							<th><input type="text" class="form-control" name="TD_name" id="TD_name" value="<?php echo $logData['TD_name'];?>" size="30" tabindex="30" style="width:85%;"></th>
							<th style="width:15%;"><label>购买价格</label></th>
							<th><input type="text" class="form-control" name="TD_size" id="TD_size" value="<?php echo $logData['TD_size'];?>" size="30" tabindex="30" style="width: 85%;"></th>
						</tr>
						<tr>
							<th style="width:15%;"><label>作者昵称</label></th>
							<th><input type="text" class="form-control" name="TD_date" id="TD_date" value="<?php echo $logData['TD_date'];?>" size="30" tabindex="30" style="width: 85%;"></th>
							<th style="width:15%;"><label>下载密码</label></th>
							<th><input type="text" class="form-control" name="TD_pass" id="TD_pass" value="<?php echo $logData['TD_pass']; ?>" size="30" tabindex="30" style="width: 85%;"></th>
						</tr>
						<tr>
							<th style="width:15%;"><label>下载地址</label></th>
							<th><input type="text" class="form-control" name="TD_down1" id="TD_down1" value="<?php echo $logData['TD_down1']; ?>" size="30" tabindex="30" style="width: 85%;"></th>
							<th style="width:15%;"><label>收费地址</label></th>
							<th><input type="text" class="form-control" name="TD_down2" id="TD_down2" value="<?php echo $logData['TD_down2']; ?>" size="30" tabindex="30" style="width: 85%;"></th>
						</tr>
					</tbody>
				</table>
				<button type="button" class="btn btn-success" data-dismiss="modal">确定</button>
			</div>
		</div>
	</div>
</div>
<?php 
}addAction('adm_writelog_head', 'Tedown_option');
/* 前台显示部分 */
function show_down($logid){
    $db = Database::getInstance();
	$data = $db->query("SELECT * FROM ".DB_PREFIX."tedown WHERE logid ='$logid'");
	$row = $db->fetch_array($data);
	$logData = array(
		'TD_start' => htmlspecialchars($row['TD_start']),
		'TD_type' => htmlspecialchars($row['TD_type']),
		'TD_name' => htmlspecialchars($row['TD_name']),
		'TD_size' => htmlspecialchars($row['TD_size']),
		'TD_date' => htmlspecialchars($row['TD_date']),
		'TD_down1' => htmlspecialchars($row['TD_down1']),
		'TD_down2' => htmlspecialchars($row['TD_down2']),
		'TD_pass' => htmlspecialchars($row['TD_pass']),
	);
	$TD_down1_1 = $logData['TD_down1'] ? $logData['TD_down1'] : "javascript:alert('此下载地址不见啦！！！');";
	$TD_down1_2 = $logData['TD_down2'] ? '<a href="javascript:" id="shoufei" target="_blank" class="TDdefault2">立即购买</a>' : '';
	$TD_pass_1 = $logData['TD_pass'] ? '下载密码：' . $logData['TD_pass'] : '';
	$content = '<link href="https://cdn.staticfile.org/font-awesome/4.7.0/css/font-awesome.css" rel="stylesheet">
					<link href="'.TELIB_URL.'Class/css/Tedown.css" rel="stylesheet">
					<div class="Tedown ClearFix">
						<div class="Tedown1">
							<div class="Tedown1-box">
								<div class="Tedown1-name">
									<p>附件名：<span>'.$logData['TD_name'].'</span></p>
								</div>
								<div class="Tedown1-other">
									<p>下载说明：'.$logData['TD_size'].'&nbsp;&nbsp;&nbsp;'.$TD_pass_1.'</p>
									<p>作者昵称：'.$logData['TD_date'].'</p>
								</div>  
								<div class="Tedown1-down">
								<a href="'.$TD_down1_1.'" target="_blank" class="TDdefault1"><i class="fa fa-cloud-download"></i> 立即下载</a>
								'.$TD_down1_2.'
								</div>
							</div>
							<div class="Tedown1-gg"><p><a href="'.BLOG_URL.'" target="_blank"><img src="'.TELIB_URL.'Class/img/gg.png"></a></p></div>
						</div>
					</div>';
	if($logData['TD_start']=='y'){
		if($logData['TD_type'] == '1'){
			if($_COOKIE['postermail'] && $_COOKIE['postermail'] != ''){
					$r = Database::getInstance();
					$row=$r->once_fetch_array("SELECT * FROM  `".DB_NAME."`.`".DB_PREFIX."comment` WHERE `mail` =  '".$_COOKIE['postermail']."' and `gid` = '".$logid."' ORDER BY `date` DESC");
			}else if($_COOKIE['posterurl'] && $_COOKIE['posterurl'] != ''){
					$r = Database::getInstance();
					$row=$r->once_fetch_array("SELECT * FROM  `".DB_NAME."`.`".DB_PREFIX."comment` WHERE `url` =  '".$_COOKIE['posterurl']."' and `gid` = '".$logid."' ORDER BY `date` DESC");
			}
			if($row && (time()-$row['date']) <= 3600*24 && $row['hide'] == 'n' || ROLE == "admin"){
					echo $content;
			}else{
					echo '<link href="'.TELIB_URL.'Class/css/Tedown.css" rel="stylesheet">
					<div class="Tedown-title">
						<i class="fa fa-lock"></i>  管理员设置  <a href="#comment">回复</a>  既可下载
					</div>';
			}
		}else{
			echo $content;
		}
	}
}
addAction('down_log', 'show_down');
?>