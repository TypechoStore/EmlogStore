<?php
/*
Plugin Name: 印象码（验证码）
Version: 20130716
Plugin URL:
Description: 结合图片和广告的验证码
Author: qiweiyu
Author URL: http://blog.weiyu.me
*/

!defined('EMLOG_ROOT') && exit('access deined!');
require_once(dirname(__FILE__).'/qwy_yxm_config.php');

function qwy_yxm_menu()

{

	echo '<div class="sidebarsubmenu" id="qwy_yxm"><a href="./plugin.php?plugin=qwy_yxm">印象码</a></div>';

}

addAction('adm_sidebar_ext', 'qwy_yxm_menu');

function qwy_yxm_main() {
	if(Option::get('comment_code') != 'y') return;
	$data = ob_get_clean();
	$str =  "
<script type=\"text/javascript\" charset=\"gbk\">
	var YXM_PUBLIC_KEY = \"".QWY_YXM_PUBLIC."\";
	var YXM_localsec_url = \"".BLOG_URL."content/plugins/qwy_yxm/localsec/\";
	function YXM_local_check() {
		if(typeof(YinXiangMaDataString)!='undefined')return;
		YXM_oldtag = document.getElementById('YXM_script');
		var YXM_local=document.createElement('script');
		YXM_local.setAttribute(\"type\",\"text/javascript\");
		YXM_local.setAttribute(\"id\",\"YXM_script\");
		YXM_local.setAttribute(\"charset\", \"gbk\");
		YXM_local.setAttribute(\"src\",YXM_localsec_url+'yinxiangma.js?pk='+YXM_PUBLIC_KEY+'&v=YinXiangMa_PHPSDK_4.0');
		YXM_oldtag.parentNode.replaceChild(YXM_local,YXM_oldtag);  
	}
	setTimeout(\"YXM_local_check()\",3000);
	document.write(\"<input type='hidden' id='YXM_here' /><script type='text/javascript' charset='gbk' id='YXM_script' src='http://api.yinxiangma.com/api3/yzm.yinxiangma.php?pk=\"+YXM_PUBLIC_KEY+\"&v=YinXiangMaPHPSDK_4.0'><\"+\"/script>\");
</script>";
	$data = preg_replace( "/<[img|IMG].*?src=[\'|\"](.*?)checkcode.php[\'|\"].*?[\/]?><input.*?name=[\'|\"]imgcode[\'|\"].*?[\/]?>/", $str.'<input name="imgcode" type="hidden" value="imgcode" />', $data);
	//$data = str_replace('<img src="'.BLOG_URL.'include/lib/checkcode.php" align="absmiddle" /><input name="imgcode" type="text" class="input" size="5" tabindex="5" />', $str, $data);
	ob_start();
	echo $data;
}
addAction('index_footer', 'qwy_yxm_main');
function qwy_yxm_check() {
	if((Option::get('comment_code') != 'y')||(ISLOGIN == true)) return;
	session_start();
	$_SESSION['code']="IMGCODE";
	$YinXiangMa_response = YinXiangMa_ValidResult(@$_POST['YinXiangMa_challenge'], @$_POST['YXM_level'][0], @$_POST['YXM_input_result']);
	if($YinXiangMa_response != 'true') {
		emMsg('评论失败：验证码不正确');
	}
}
addAction('comment_post', 'qwy_yxm_check');

//Copy From YinXiangMa PHP SDK
function YinXiangMa_ValidResult($YinXiangMaToken,$level,$YXM_input_result){	
	if($YXM_input_result==md5("true".QWY_YXM_PRIVATE.$YinXiangMaToken)) { $result= "true"; }
	else { $result= "false"; }
	return $result;
}

