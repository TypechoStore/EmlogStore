<?php 


if(!defined('EMLOG_ROOT')) {exit('error!');}
function plugin_setting_view() {

require_once(dirname(__FILE__).'/qwy_yxm_config.php');

?>

<div class=containertitle><b>印象码设置</b>

<?php if(isset($_GET['setting'])):?><span class="actived">插件设置完成</span><?php endif;?>

</div>

<div style="margin-top:20px; padding:5px; width:600px; border:1px dashed #CCC">
<p><font color="red">获取站点KEY的方法</font><br />
1、访问<a href="http://www.yinxiangma.com">www.yinxiangma.com</a>注册账户。<br />
2、访问印象码广告平台，点击导航栏 站点管理->新建站点，根据提示完成站点创建，然后创建验证码广告位。<br />
3、创建验证码广告位后，点击 站点KEY， 即可查看自己的站点KEY。
</p>
</div>

<div class=line></div>

<form action="plugin.php?plugin=qwy_yxm&action=setting" method="post">

<div>

    <p>PRIVATE_KEY:

	<input size="40" name="qwy_yxm_private" type="text" value="<?php echo QWY_YXM_PRIVATE; ?>" /></p>

	<p>PUBLIC_KEY:

	<input size="40" name="qwy_yxm_public" type="text" value="<?php echo QWY_YXM_PUBLIC; ?>" /></p>

	<p><input type="submit" value="保 存" class="submit" /></p>

</div>

</form>

<script>

$("#qwy_yxm").addClass('sidebarsubmenu1');

</script>

<?php 

}

function plugin_setting()

{

	$qwy_yxm_private = isset($_POST['qwy_yxm_private']) ? trim($_POST['qwy_yxm_private']) : '';

	$qwy_yxm_public = isset($_POST['qwy_yxm_public']) ? trim($_POST['qwy_yxm_public']) : '';

	$data = "<?php
	define('QWY_YXM_PRIVATE', '".$qwy_yxm_private."');
	define('QWY_YXM_PUBLIC', '".$qwy_yxm_public."');
?>";

	if($qwy_yxm_private != '' && $qwy_yxm_public != '')

	{

		$file = EMLOG_ROOT.'/content/plugins/qwy_yxm/qwy_yxm_config.php';

		@ $fp = fopen($file, 'wb') OR emMsg('读取文件失败，如果您使用的是Unix/Linux主机，请修改文件/content/plugins/qwy_yxm/qwy_yxm_config.php的权限为777。如果您使用的是Windows主机，请联系管理员，将该文件设为everyone可写');

		@ $fw =	fwrite($fp,$data) OR emMsg('写入文件失败，如果您使用的是Unix/Linux主机，请修改文件/content/plugins/qwy_yxm/qwy_yxm_config.php的权限为777。如果您使用的是Windows主机，请联系管理员，将该文件设为everyone可写');

		fclose($fp);

	}

}



?>
