<?php
	define('QWY_YXM_PRIVATE', '30d3b54c16b013707e167a71089450b3');
	define('QWY_YXM_PUBLIC', '86472fa7d84d1cc843fcef7d17afbd46');
?>