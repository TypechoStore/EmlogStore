<?php
function callback_init(){
	multiAuthorMailTo_callback_do('y');
}

function callback_rm(){
	multiAuthorMailTo_callback_do('n');
}

function multiAuthorMailTo_callback_do($enable){
	global $CACHE;
	$DB = Database::getInstance();
	if($enable=="y"){
		$get_option = $DB -> query("SELECT * FROM `".DB_PREFIX."options` WHERE `option_name` = 'multiAuthorMailTo_option' ");
		$num = $DB -> num_rows($get_option);
		if($num == 0){
			$multiAuthorMailTo_option=addslashes(serialize(array()));
			$DB -> query("INSERT INTO `".DB_PREFIX."options`  (`option_name`, `option_value`) VALUES('multiAuthorMailTo_option', '".$multiAuthorMailTo_option."') ");
		}
	}else{
		$get_option = $DB -> query("SELECT * FROM `".DB_PREFIX."options` WHERE `option_name` = 'multiAuthorMailTo_option' ");
		$num = $DB -> num_rows($get_option);
		if($num > 0){
			//$DB -> query("DELETE FROM `".DB_PREFIX."options` WHERE option_name='multiAuthorMailTo_option'");
		}
	}
	$CACHE->updateCache('options');
}
?>