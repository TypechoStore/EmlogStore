<?php if(!defined('EMLOG_ROOT')){die('err');}?>
<?php
$action=empty($_POST['action'])?'':trim($_POST['action']);
if(!empty($_POST)&&$action=="submitMultiAuthorMailTo"){
	$DB = Database::getInstance();
	
	$isVisitor=empty($_POST['isVisitor'])?'y':trim($_POST['isVisitor']);
	
	if(get_magic_quotes_gpc()){
		$isVisitor=stripslashes($isVisitor);
	}
	
	$get_option = $DB -> once_fetch_array("SELECT * FROM `".DB_PREFIX."options` WHERE `option_name` = 'multiAuthorMailTo_option' ");
	$config_app=unserialize($get_option["option_value"]);
	
	$config_app["isVisitor"]=$isVisitor;
	
	$DB -> query("UPDATE `".DB_PREFIX."options`  SET `option_value` = '".addslashes(serialize($config_app))."' WHERE `option_name` = 'multiAuthorMailTo_option' ");
	header('Location:./plugin.php?plugin=multiAuthorMailTo');
}
function plugin_setting_view(){
	$DB = Database::getInstance();
	$get_option = $DB -> once_fetch_array("SELECT * FROM `".DB_PREFIX."options` WHERE `option_name` = 'multiAuthorMailTo_option' ");
	$config_app=unserialize($get_option["option_value"]);
	?>
	<div>
		<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
		  <legend>
			多作者邮件通知
		  </legend>
		</fieldset>
		<form id="multiAuthorMailToSetForm" method="post" action="">
			<p style="margin-top:10px;">
				仅游客通知作者：
				<input type="radio" name="isVisitor" value="n" <?=isset($config_app['isVisitor'])?($config_app['isVisitor']=="n"?"checked":""):"";?> />否
				<input type="radio" name="isVisitor" value="y" <?=isset($config_app['isVisitor'])?($config_app['isVisitor']!="n"?"checked":""):"checked";?> />是
			</p>
			<p style="margin-top:10px;">
				<input type="hidden" name="action" value="submitMultiAuthorMailTo" />
				<input type="submit" style="background-color: #4CAF50;border: none;color: white;padding:5px 5px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;border-radius: 5%;" value="保存设置" />
			</p>
		</form>
	</div>
	<script>
		<?php if(Option::EMLOG_VERSION>="6.1.1"){?>
		$("#multiAuthorMailTo").addClass('layui-this');
		$("#multiAuthorMailTo").parent().parent().addClass('layui-nav-itemed');
		<?php }else if(Option::EMLOG_VERSION=="6.0.0"){?>
		$("#multiAuthorMailTo a").addClass('active');
		<?php }else if(Option::EMLOG_VERSION=="6.0.1"){?>
		$("#multiAuthorMailTo").addClass('active');
		<?php }else if(Option::EMLOG_VERSION=="5.3.1"){?>
		$("#multiAuthorMailTo").addClass('sidebarsubmenu1');
		<?php }?>
	</script>
	<?php
}
?>