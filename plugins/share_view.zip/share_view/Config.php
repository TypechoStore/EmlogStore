<?php
//填写自己的appid
$client_id = '801002154';
//填写自己的appkey
$client_secret = 'b91ce1126e3ac11c9f3e587ad03137ae';
//调试模式
$debug = false;