<?php die; ?>a:7:{s:2:"ak";s:9:"AccessKey";s:2:"sk";s:9:"SecretKey";s:2:"bk";s:4:"test";s:2:"up";s:20:"http://up.qiniu.com/";s:2:"dn";s:28:"http://test.bkt.clouddn.com/";s:2:"th";s:3:"800";s:8:"callback";s:774:"if(typeof($('#markdownEditor_content').val())!='undefined'){
	$('#markdownEditor_content').val($('#markdownEditor_content').val()+'<a href="'+qiniu_dnurl+qiniu_skep[numb]+'" target="_blank"><img src="'+qiniu_dnurl+qiniu_skep[numb]+'?imageView/2/w/'+qiniu_thumb+'" alt="" /></a><br />');
}else if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
	layedit.setContent(contentLayUIEditor,'<a href="'+qiniu_dnurl+qiniu_skep[numb]+'" target="_blank"><img src="'+qiniu_dnurl+qiniu_skep[numb]+'?imageView/2/w/'+qiniu_thumb+'" alt="" /></a><br />',true);
}else{
	KindEditor.insertHtml('#content','<a href="'+qiniu_dnurl+qiniu_skep[numb]+'" target="_blank"><img src="'+qiniu_dnurl+qiniu_skep[numb]+'?imageView/2/w/'+qiniu_thumb+'" alt="" /></a><br />');
}";}