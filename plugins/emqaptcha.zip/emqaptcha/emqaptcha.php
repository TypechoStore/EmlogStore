<?php
/*
Plugin Name: EmQapTcha
Version: 1.3
Plugin URL: http://wenlu.me/post/qaptcha_for_emlog
Description: 在评论处添加滑动解锁，防止垃圾评论和机器人。
Author: loekman
Author Email: loekman@163.com
Author URL: http://wenlu.me
*/
!defined('EMLOG_ROOT') && exit('access deined!');
emLoadJQuery();
function emqaptcha_head() {
echo '
<script type="text/javascript" src="'.BLOG_URL.'content/plugins/emqaptcha/jquery/jquery.min.js"></script>
<script type="text/javascript" src="'.BLOG_URL.'content/plugins/emqaptcha/jquery/jquery-ui.min.js"></script>
'."\n";
}

function emqaptcha_footer() {
echo '
<script type="text/javascript" src="'.BLOG_URL.'content/plugins/emqaptcha/jquery/jquery.ui.touch.js"></script>
<script type="text/javascript" src="'.BLOG_URL.'content/plugins/emqaptcha/jquery/QapTcha.jquery.js"></script>
<link rel="stylesheet" href="'.BLOG_URL.'content/plugins/emqaptcha/css/qaptcha.css" type="text/css" />
'."\n";
echo '
<script type="text/javascript">jQuery(document).ready(function(){if(jQuery("p:has(\'textarea\')").length>0) jQuery("p:has(\'textarea\')").after(\'<div id="QapTcha"></div>\'); else jQuery("#comment").after(\'<div class="QapTcha"></div>\');jQuery(\'#QapTcha\').QapTcha({disabledSubmit:true,autoRevert:true});});</script>'."\n";
}

addAction('index_head', 'emqaptcha_head');
addAction('index_footer', 'emqaptcha_footer');
?>