﻿<?php
/*
Plugin Name:EPS短网址
Version:1.2
Plugin URL:https://bk.likinming.com/dwz.html
Description:在文章页面添加短链接转换工具,利用EPS短网址API将长链接转成短链接,需要在模板中加入挂载点：&lt;?php doAction('log_eps_gs_dwz');?>
ForEmlog:5.0+
Author:EPS短网址
Author URL:https://eps.gs/
 */

!defined('EMLOG_ROOT') && exit('access deined!');

addAction('log_eps_gs_dwz', 'eps_gs_dwz_load');

function eps_gs_dwz_load() {
echo <<<epsSURLLOAD

<iframe width="100%" height="250" frameborder="no" scrolling="no" src="https://apis.eps.gs/dwz.php">;</iframe>

epsSURLLOAD;

}
