<?php
/*
Plugin Name: API扩展插件
Version: 1.0.1
Plugin URL：https://www.tongleer.com
Description: 为API扩展提供辅助性API功能的插件，$getRouteList为get传输route路由参数，$postRouteList为post传输route路由参数，$params为接收参数，APIExtendsFunctions中调用自定义函数可设计多个api接口。
Author: 二呆
Author URL: https://www.tongleer.com
*/
/*
以下为默认参数
$getRouteList = array('article','articleInfo','comments','newComments','twitter','replyTwitter','sorts','attachment','options','page');
$postRouteList = array('addComment');
API访问地址为：http(s)://域名/extends/API/?route=自定义路由参数
返回数据方法：ajaxReturn(1, 'customFunction', $params);
*/
/*
 * TODO自定义函数
 */
function customFunction($params){
	
	ajaxReturn(1, 'customFunction', $params);
}

function APIExtendsFunctions($getRouteList,$postRouteList,$route,$params) {
	global $getRouteList;
	global $postRouteList;
	global $route;
	global $params;
	
	//TODO 自定义路由参数
    array_push($getRouteList,"customFunction");
	
	if (in_array($route, $postRouteList)) {
    $params = $_POST;
		if (empty($params)) {
			ajaxReturn(0, 'post数据为空');
		}
	} else {
		$params = $_GET;
	}
	
	//TODO 自定义API函数
	customFunction($params);
}
addAction('APIExtends', 'APIExtendsFunctions');