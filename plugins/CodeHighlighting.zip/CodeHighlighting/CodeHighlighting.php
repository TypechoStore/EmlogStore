<?php
/*
Plugin Name: CH代码高亮
Version: 1.0.1
Plugin URL: https://www.tongleer.com
Description: 使用prettify.js超简单生成代码高亮的插件
Author: 二呆&vxia.net
Author Email: diamond0422@qq.com
ForEmlog:6.1.1
Author URL: https://www.tongleer.com
*/
!defined('EMLOG_ROOT') && exit('access deined!');

function CodeHighlighting_adm_writelog_head(){
	
}
addAction('adm_writelog_head', 'CodeHighlighting_adm_writelog_head');

function CodeHighlighting_index_head(){
	echo '<link rel="stylesheet" type="text/css" href ="'.BLOG_URL.'content/plugins/CodeHighlighting/prettify.css" />';
}
addAction('index_head','CodeHighlighting_index_head');

function CodeHighlighting_index_footer(){
	echo '
		<script type="text/javascript" src="'.BLOG_URL.'content/plugins/CodeHighlighting/prettify.js"></script>
		<script type="text/javascript">
		$(function() {
			$("pre").addClass("prettyprint linenums").attr("style", "overflow:auto");
			window.prettyPrint && prettyPrint();
		});
		</script>
	';
}
addAction('index_footer','CodeHighlighting_index_footer');