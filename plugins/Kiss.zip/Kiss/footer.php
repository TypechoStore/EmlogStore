<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

</div><!-- #wrapper -->
</div>
<?php doAction('index_footer'); ?>
<div class="setting_tool iconfont">
    <a class="back2top" style="display: none;"><i class="iconfont czs-angle-up-l" style="color: #f8c774;"></i></a>
    <a class="sosearch"><i class="iconfont czs-search-l" style="color: #f55;"></i></a>
	<a class="qq" href="https://wpa.qq.com/msgrd?v=3&uin=2107228359&site=qq&menu=yes"><i class="iconfont czs-qq" style="color: #16c0e8;"></i></a>
    <div class="s">
        <form method="get" name="keyform" action="<?php echo BLOG_URL; ?>index.php" role="search" class="form-group">
            <input class="search-key" name="keyword" autocomplete="off" placeholder="输入关键词..." type="text" value="" required="required">
        </form>
    </div>
</div>
    <!-- page loading -->
	<div id="loading">
		<div id="loading-center">
 			<div class="dot"></div>
			<div class="dot"></div>
			<div class="dot"></div>
			<div class="dot"></div>			
		</div>
	</div> 
</div><!-- .content -->
<script src="<?php echo TEMPLATE_URL; ?>js/prism.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/view-image.min.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/main.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/lazyload.min.js" type="text/javascript"></script>
</body>
</html>
