<?php 
/*
Custom:page_links
Description:友情链接
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<style>
.page {
    margin: 0;
}
</style>
<!--style>
#header .post-bg{-webkit-filter: blur(10px);filter: blur(10px);}
#header .inner {display: none;}
@media(max-width:650px){#header {display: none;}}
</style-->
<div class="echo_log">
<main class="page">
<!--div class="h">
<div class="h-inner h-bg" style="background-image: url(<?php if($thumbs != ''){ echo $thumbs; }else{ echo getpostimagetop($logid); }; ?>);"></div>
<div class="h-content">
<h1><?php echo $log_title; ?></h1>
</div>
<div class="post-data">
  <div class="author-name">
    <a href="<?php echo BLOG_URL; ?>">
     <img src="<?php echo _g("tx");?>" class="avatar avatar-30 photo" height="30" width="30">
     瑾忆
    </a>
  </div>
 <span class="u-time"><i class="czs-time-l"></i> <?php echo date('Y-n-j', $date);?></span>
 <span class="u-comment"><i class="czs-talk-l"></i> <?php echo $comnum; ?></span>
</div>
</div-->
<section class="books">
<div class="links">
<?php global $CACHE;$link_cache = $CACHE->readCache('link');foreach($link_cache as $value): ?>
<div class="links-list">
			<div class="links-item">
			<div class="links-bg" style="background-image: url(<?php if ($value['sitepic']==''){ echo _g("tx");}else{ echo $value['sitepic'];}; ?>);"></div>
			<span class="links-name"><a href="<?php echo $value['url']; ?>" target="_blank"><?php echo $value['link']; ?></a></span>
			<img src="<?php if ($value['sitepic']==''){ echo _g("tx");}else{ echo $value['sitepic'];}; ?>" class="avatar avatar-56 photo links-avatar" height="56" width="56">
			<div class="desc"><?php if(empty($value['des'])){ echo '这个人没什么好介绍的，简介都没写，就是个基佬而已。';}else{echo $value['des'];} ?></div>
			</div>
</div>
<?php endforeach; ?>
</div>
			<article class="post single">
<?php echo preg_replace("#\[smilies(\d+)\]#i",'<img src="'.TEMPLATE_URL.'images/face/$1.png" id="smilies$1" alt="表情$1"/>',article_index($log_content)); ?>
<?php doAction('log_related', $logData); ?>
<?php doAction('echo_log', $logData); ?>
			</article>
<?php if($allow_remark == 'y'): ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<?php blog_comments($comments,$params); ?>
<?php endif;?>
</section>
</main>
</div>
<?php include View::getView('footer');?>