<?php
header("Content-type: application/json; charset=utf-8"); 
$email = $_GET['email'];
if ($email){
	$hash = md5(strtolower($email));
	$avatar = 'https://secure.gravatar.com/avatar/' . $hash . '?s=100&d=monsterid';
    $host = 'https://q2.qlogo.cn/headimg_dl?dst_uin=';
    $qq = str_replace("@qq.com","",$email);
	if(strpos($email,'@qq.com')){
		if(is_numeric($qq) && strlen($qq) > 4 && strlen($qq) < 13){
			$qqtx = $host . $qq . '&spec=100';
            echo '{"pic":"'.$qqtx.'"}';
		}else{
			echo '{"pic":"'.$avatar.'"}';
		}
	}else{
			echo '{"pic":"'.$avatar.'"}';
	}
}
?>