<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<style>
.h {margin-bottom: 0px; margin:0;margin-top: 0px;}
@media(max-width:650px){#header {display: none;}}
.comment .comment-body:before {background: #FFF;}
</style>
<div class="echo_log">
<main>
<div class="h">
<div class="h-inner h-bg" style="background-image: url(<?php echo TEMPLATE_URL; ?>images/t.png);"></div>
<div class="h-content">
<h1>微语</h1>
</div>
</div>
<section class="books">
			<article class="post single">
    <?php foreach ($tws as $val) : $author = $user_cache[$val['author']]['name'];$avatar = empty($user_cache[$val['author']]['avatar']) ? BLOG_URL . 'admin/views/images/avatar.jpg' : BLOG_URL . $user_cache[$val['author']]['avatar'];$tid = (int)$val['id'];$img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img src="'.BLOG_URL.$val['img'].'"></a>'; ?>
<div class="commentlist" id="comment_list">
		<div class="comment even thread-even depth-8 parent plt" >
	<div id="div-comment-8" class="comment-body">
		<div class="comment-author vcard">
			<img src="<?php echo $avatar; ?>" class="avatar">
			<cite class="fn"><?php echo $author; ?></cite>
			<span class="commentmetadata"><?php echo $val['date']; ?></span>
			<cite class="vip" style="background-color:#FFEB3B;">性感博主</cite>	
		</div>
		<p><?php echo $val['t'].'<br/>'.$img; ?></p>

	</div>
		</div>
</div>
	<?php endforeach;?>
	<div id="pagenavi"><?php echo $pageurl;?></div>
			</article>

</section>
</main>
</div>
<?php include View::getView('footer');?>