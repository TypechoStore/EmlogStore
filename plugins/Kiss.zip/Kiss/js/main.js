//侧边栏导航
$(function(){
    $('.iconflat').on('click', function () {
        $('#mo-nav,.openNav').toggleClass('open');
    });
});
$(function(){
    $('#mo-nav ul li a').on('click', function () {
        $('#mo-nav,.openNav').toggleClass('open');
    });
});
//导航
	$(document).on('click', 'a.header-btn,a.header-off,#mo-nav ul li a', function() {
		if ($('body').is('.header-show')) {
			$('body').removeClass('header-show');
			} else {
				$('body').addClass('header-show');
			}
	});
//返回顶部
$('.back2top').click(function(){$('html,body').animate({scrollTop: '0px'}, 1000);});
    $(window).scroll(function(){
        $(window).scrollTop()>10?$('.back2top').css('display','block'):$('.back2top').css('display','none');
    });
//搜索
$('.sosearch').on('click', function () {
    $('.setting_tool').toggleClass('search');
});
		//reward-click
		$(".zanzhu").click(function () {
			if ($(".reward").hasClass('open')) {
				$(".reward").removeClass('open');
			} else {
				$(".reward").addClass('open');
			}
		});
/* jQuery Ajax 提交、刷新 评论   本插件由 简爱 http://www.gouji.org/ 提取完善、移植 至 EMLOG */
plpl();
function plpl(){
// JS 仿 PHP 获取 GET 数据
var $_GET=(function(){
  var js=document.scripts;
  var url=js[js.length-1].src;
  var u=url.split("?");
  if(typeof(u[1])=="string"){
    u=u[1].split("&");
    var get={};
    for(var i in u){
      var j=u[i].split("=");
      get[j[0]]=decodeURIComponent(j[1]);
    }
    return get;
  }
  else{
    return {};
  }
})();


$(function(){
  JA_comment_($_GET['list'], $_GET['form'], $_GET['css'], $_GET['msg']);
});


function JA_comment_(JA_commentList, JA_commentForm, JA_commentCss, JA_comment) {
    if (!JA_commentList) var JA_commentList = "#comment_list";
    if (!JA_commentForm) var JA_commentForm = "#commentform";
    var JA_commentFormSubmit = $(JA_commentForm).find("input[type=submit]");
    var JA_commentFormT = $(JA_commentForm + ' textarea');
    var JA_commentForm = $(JA_commentForm);
    JA_commentForm.submit(function () {
        var q = JA_commentForm.serialize();
        JA_commentFormT.attr("disabled", true);
        JA_commentFormSubmit.attr("disabled", true);
        $("#JA_commenError").text('');
        $("#JA_commenLoading").show();
        $.post(JA_commentForm.attr("action"), q, function (d) {
            var reg = /<div class=\"main\">[\r\n]*<p>(.*?)<\/p>/i;
            if (reg.test(d)) {
                $("#JA_commenError").html(d.match(reg)[1]);
                $("#JA_commenLoading").hide()
            } else {
                var p = $("input[name=pid]").val();
                cancelReply();
                $("[name=comment]").val("");
                $("#JA_commenError").text('');
                u = JA_commentList.split(",");
                for (var i in u) {
                    $(u[i]).html($(d).find(u[i]).html())
                };
                var body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body');
                if (p != 0) {
                    var body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body');
                    body.animate({
                        scrollTop: $("#comment-" + p).offset().top - 20
                    }, "normal", function () {
                        $("#JA_commenLoading").hide()
                    })
                } else {
                    var body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body');
                    body.animate({
                        scrollTop: $(JA_commentList).offset().top - 20
                    }, "normal", function () {
                        $("#JA_commenLoading").hide()
                    })
                }
            };
            JA_commentFormT.attr("disabled", false);
            JA_commentFormSubmit.attr("disabled", false)
        });
        return false
    });
    JA_commentForm.keypress(function (e) {
        if (e.ctrlKey && e.which == 13 || e.which == 10) {
            JA_commentForm.submit()
        } else if (e.shiftKey && e.which == 13 || e.which == 10) {
            JA_commentForm.submit()
        }
    });
    msg = ' jQuery Ajax 提交、刷新 评论';
    JA_comment = JA_comment ? JA_comment : 'Loading……';
    if (JA_commentCss) {
        css = '<link type="text/css" rel="stylesheet" href="' + JA_commentCss + '" /><!--' + msg + '-->'
    } else {
        css = '<style type="text/css">/*' + msg + '*/#JA_commenLoading{font-size:12px;margin-bottom:5px}#JA_commenError{font-size:12px;margin-top:5px;color:red}</style>'
    };
    JA_commentFormSubmit.before(css + '<div id="JA_commenLoading" style="display:none;">' + JA_comment + '</div><div id="JA_commenError"></div>')
}
};//end  plpl
//重载函数
czcz();
function czcz(){
//灯箱
	jQuery(document).ready(function () {
        jQuery.viewImage({
            'target' : '.single img,#pic-wall .pici a', //需要使用ViewImage的图片
            'exclude': '#pic-wall .pici a img,.guanggao a img',    //要排除的图片
            'delay'  : 300                //延迟时间
        });
    });
plpl();
//表情
$(function owo() {
   var aluContainer = document.querySelector('.OwO-items');
    if ( !aluContainer ) return;
    $('.OwO-item').on('click',function(e){
    var myField,
        _self = e.target.dataset.smilies ? e.target : e.target.parentNode,
        tag = '[' + _self.dataset.smilies + ']';
        if (document.getElementById('comment') && document.getElementById('comment').type == 'textarea') {
            myField = document.getElementById('comment')
        } else {
            return false
        }
        if (document.selection) {
            myField.focus();
            sel = document.selection.createRange();
            sel.text = tag;
            myField.focus()
        } else if (myField.selectionStart || myField.selectionStart == '0') {
            var startPos = myField.selectionStart;
            var endPos = myField.selectionEnd;
            var cursorPos = endPos;
            myField.value = myField.value.substring(0, startPos) + tag + myField.value.substring(endPos, myField.value.length);
            cursorPos += tag.length;
            myField.focus();
            myField.selectionStart = cursorPos;
            myField.selectionEnd = cursorPos
        } else {
            myField.value += tag;
            myField.focus()
        }
    });
 });
$(function(){
        $('.OwO-logo').on('click', function () {
            $('.OwO').toggleClass('OwO-open');
        }); 
});
		//reward-click
		$(".zanzhu").click(function () {
			if ($(".reward").hasClass('open')) {
				$(".reward").removeClass('open');
			} else {
				$(".reward").addClass('open');
			}
		});
Prism.highlightAll();//代码高亮
};//end  czcz

//pjax参数配置
            var pjax = new Pjax({
                elements: 'a[href]:not([href^="#"])', // default is "a[href], form[action]"   a:not([href^="#"])      #main a,#mo-nav a,.echo_log a
                cacheBust: false,
                debug: false,
                selectors: [
                    'title',
                    //'#header',
                    '#wrapper'
                ]
            });

            //在Pjax请求开始后触发
            document.addEventListener('pjax:send', function () {
				//加载动画
				$("#loading,#loading-center").css("display", "block");//参考的loading动画代码
            });

            //在Pjax请求完成后触发
            document.addEventListener('pjax:complete', function () {
				//加载动画
				$('html').toggleClass('#loading,#loading-center');
				 $("#loading,#loading-center").css("display", "none");//参考的loading动画代码
                //重载函数
				czcz();
				jQuery(".lazy").lazyload({ effect: "fadeIn",});
            });

            //在Pjax请求成功后触发
            document.addEventListener('pjax:success', function() {

            });

            //Pjax请求失败后触发，请求对象将作为一起传递event.options.request
            document.addEventListener('pjax:error', function() {
                bar('系统出现问题，请手动刷新一次','3000');
            });
            //搜索事件处理
            $(document).on('submit', '.form-group', function (e) {
                e.preventDefault(); // 去除搜索框默认事件
                var site = document.location.origin,
                    val = $('.search-key').val(),
                    search = site + '/?keyword=' + val;
                pjax.loadUrl(search);
            });
