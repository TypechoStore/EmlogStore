<?php 
/*
Custom:page_archivers
Description:文章归档
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>


<?php
function displayRecord(){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	$output = '';
	foreach($record_cache as $value){
		$output .= '<div class="archive-title"><h3>'.$value['record'].'('.$value['lognum'].'篇文章)</h3>'.displayRecordItem($value['date']).'';
	}
	$output = '<div id="archives-temp">'.$output.'</div>';
	return $output;
}
function displayRecordItem($record){
	if (preg_match("/^([\d]{4})([\d]{2})$/", $record, $match)) {
		$days = getMonthDayNum($match[2], $match[1]);
		$record_stime = Strtotime($record . '01');
		$record_etime = $record_stime + 3600 * 24 * $days;
	} else {
		$record_stime = Strtotime($record);
		$record_etime = $record_stime + 3600 * 24;
	}
	$sql = "and date>=$record_stime and date<$record_etime order by top desc ,date desc";
	$result = archiver_db($sql);
	return $result;
}
function archiver_db($condition = ''){
	$DB = MySql::getInstance();
	$sql = "SELECT gid, title, date, views FROM " . DB_PREFIX . "blog WHERE type='blog' and hide='n' $condition";
	$result = $DB->query($sql);
	$output = '';
	while ($row = $DB->fetch_array($result)) {
		$log_url = Url::log($row['gid']);
		$output .= '<div class="brick"><div class="list-item"><div class="title"><a href="'.$log_url.'">'.$row['title'].'</a></div><div class="time">'.date('M,j,Y',$row['date']).'<span class="pid">ID：'.$row['gid'].'</span></div></div></div>';
	}
	$output = empty($output) ? '<span class="ar-circle"></span><div class="arrow-left-ar"></div><div class="brick">暂无文章</div>' : $output;
	$output = '<div class="archives" id="monlist">'.$output.'</div></div>';
	return $output;
}

?>
<style>
#header .post-bg{-webkit-filter: blur(10px);filter: blur(10px);}
#header .inner {display: none;}
@media(max-width:650px){#header {display: none;}}
</style>
<div class="echo_log">
<main class="page">
<div class="h">
<div class="h-inner h-bg" style="background-image: url(<?php if($thumbs != ''){ echo $thumbs; }else{ echo getpostimagetop($logid); }; ?>);"></div>
<div class="h-content">
<h1><?php echo $log_title; ?></h1>
</div>
<div class="post-data">
  <div class="author-name">
    <a href="<?php echo BLOG_URL; ?>">
     <img src="<?php echo _g("tx");?>" class="avatar avatar-30 photo" height="30" width="30">
     瑾忆
    </a>
  </div>
 <span class="u-time"><i class="czs-time-l"></i> <?php echo date('Y,m,d', $date);?></span>
 <span class="u-comment"><i class="czs-talk-l"></i> <?php echo $comnum; ?></span>
</div>
</div>
<section class="books">
<?php echo displayRecord(); ?>
			<article class="post single">
<?php echo preg_replace("#\[smilies(\d+)\]#i",'<img src="'.TEMPLATE_URL.'images/face/$1.png" id="smilies$1" alt="表情$1"/>',article_index($log_content)); ?>
<?php doAction('log_related', $logData); ?>
<?php doAction('echo_log', $logData); ?>
			</article>
<?php if($allow_remark == 'y'): ?>
<div id="comments"></div>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<?php blog_comments($comments,$params); ?>
<?php endif;?>
</section>
</main>
</div>
<?php include View::getView('footer');?>