﻿<?php
!defined('EMLOG_ROOT') && exit('access deined!');
define('GO_CONFIG','	baidu,https://www.baidu.com,百度');
?>