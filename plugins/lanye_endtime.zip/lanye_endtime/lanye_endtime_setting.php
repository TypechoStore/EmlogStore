<?php if(!defined('EMLOG_ROOT')){die('err');}?>
<?php
function plugin_setting_view(){
	?>
	<div>
		<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
		  <legend>
			使用说明
		  </legend>
		</fieldset>
		每篇文章开启了结束活动时间后，需要在echo_log.php中合适位置加上代码：
		<pre>
&lt;?php if(lanye_endtime_getopen($logid)=='1'):?>
&lt;?php if(lanye_endtime_gettime($logid)==''):?>
&lt;div class="lanye_endtime">本活动结束时间未知。&lt;/div>
&lt;?php else:?>
&lt;script>setInterval(showToEndTime("end_time","&lt;?php echo date('Y-m-d H:i:s',lanye_endtime_gettime($logid));?>"),1000);&lt;/script>
&lt;div class="lanye_endtime">本活动&lt;span id="end_time">&lt;/span>结束！&lt;/div>
&lt;?php endif;?>
&lt;?php endif;?>
		</pre>
	</div>
	<?php
}
?>