<?php
/*
Plugin Name: 蓝叶活动时间插件
Version: 1.0
Plugin URL: https://www.dcqzz.cn/
Description: 使用此插件可以设置活动时间，以倒计时方式提醒活动还剩多少天。需要在echo_log.php中合适位置加上代码：&lt;?php if(lanye_endtime_getopen($logid)=='1'):?>&lt;?php if(lanye_endtime_gettime($logid)==''):?>&lt;div class="lanye_endtime">本活动结束时间未知。&lt;/div>&lt;?php else:?>&lt;script>setInterval(showToEndTime("end_time","&lt;?php echo date('Y-m-d H:i:s',lanye_endtime_gettime($logid));?>"),1000);&lt;/script>&lt;div class="lanye_endtime">本活动&lt;span id="end_time">&lt;/span>结束！&lt;/div>&lt;?php endif;?>&lt;?php endif;?>
Author: 蓝叶
Author Email: w@lanyes.org
Author URL: https://www.dcqzz.cn/
*/
!defined('EMLOG_ROOT') && exit('access deined!');
function lanye_endtime(){?>
<link href="<?php echo BLOG_URL;?>content/plugins/lanye_endtime/main.css" type="text/css" rel="stylesheet" />
<?php 
$db = Database::getInstance();
$type = isset($_GET['action']) ? addslashes(trim($_GET['action'])) : '';
$gid = isset($_GET['gid']) ? addslashes(trim($_GET['gid'])) : '';
$pageid = isset($_GET['id']) ? addslashes(trim($_GET['id'])) : '';
if($type=='edit' || $type=='mod'):?>
<?php 
if($type=='mod'){
$sql = "SELECT `endtime`,`open_endtime` FROM `".DB_PREFIX."blog` WHERE `gid`=".$pageid.";";
}else{
$sql = "SELECT `endtime`,`open_endtime` FROM `".DB_PREFIX."blog` WHERE `gid`=".$gid.";";
}
$result = $db->query($sql);
$row = $db->fetch_array($result);
if(empty($row['endtime'])){
 $rowtime = '';
}else{
$rowtime = date('Y-m-d H:i:s',$row['endtime']);
}
?>
<div class="lyendtime"><label>活动时间</label><select name="open_endtime" id="open_endtime"><option value="0" <?php if($row["open_endtime"]=="0") echo "selected";?>>关闭</option><option value="1" <?php if($row["open_endtime"]=="1") echo "selected";?>>开启</option></select><input name="endtime" id="endtime" type="text" value="<?php echo $rowtime;?>" placeholder="鼠标点击选择时间..." /></div>
<?php else:?>
<div class="lyendtime"><label>活动时间</label><select name="open_endtime" id="open_endtime"><option value="0" selected>关闭</option><option value="1">开启</option></select><input name="endtime" id="endtime" type="text" value="" placeholder="鼠标点击选择时间..." /></div>
<?php endif;?>
<?php }
addAction('adm_writelog_head', 'lanye_endtime');
function lanye_endtime_js_adm_head(){
	if(Option::EMLOG_VERSION>="6.1.1"){
		echo '
			<link rel="stylesheet" type="text/css" href="'.BLOG_URL.'content/plugins/lanye_endtime/jquery.datetimepicker.css"/>
			<script src="'.BLOG_URL.'content/plugins/lanye_endtime/jquery.datetimepicker.js"></script>
		';
	}
}
addAction('adm_head', 'lanye_endtime_js_adm_head');
function lanye_endtime_js_adm_footer(){
	echo '
		<script type="text/javascript" src="'.BLOG_URL.'content/plugins/lanye_endtime/main.js"></script>
	';
	if(Option::EMLOG_VERSION>="6.1.1"){
		echo '
			<script>
				$("#endtime").datetimepicker({
					format: "Y-m-d H:i:s"
				});
			</script>
		';
	}
}
addAction('adm_footer', 'lanye_endtime_js_adm_footer');
function lanye_endtime_head(){
	echo '<script type="text/javascript" src="'.BLOG_URL.'content/plugins/lanye_endtime/time.js"></script><link href="'.BLOG_URL.'content/plugins/lanye_endtime/time.css" type="text/css" rel="stylesheet" />';
}
addAction('index_head', 'lanye_endtime_head');
function lanye_endtime_cache(){
$db = Database::getInstance();
	$query = $db->query("SELECT gid FROM " . DB_PREFIX . "blog");
		$endtime_cache = array();
		while ($row = $db->fetch_array($query)) {
			$logid = $row['gid'];
			$endtimes = array();
			$tquery = "SELECT endtime,open_endtime FROM " . DB_PREFIX . "blog WHERE gid=".$logid."" ;
			$result = $db->query($tquery);
			while ($trow = $db->fetch_array($result)) {
				$trow['endtime'] = htmlspecialchars($trow['endtime']);
				$trow['open_endtime'] = htmlspecialchars($trow['open_endtime']);
				$endtimes[] = $trow;
			}
			$endtime_cache[$logid] = $endtimes;
			unset($endtimes);
		}
		$cacheData = serialize($endtime_cache);
  global $CACHE;$CACHE->cacheWrite($cacheData, 'endtime');
}
function lanye_endtime_add($logid){
$logedntime = isset($_POST['endtime']) ? addslashes(trim($_POST['endtime'])) : '';
$logopenendtime = isset($_POST['open_endtime']) ? addslashes(trim($_POST['open_endtime'])) : '';
$db = Database::getInstance();
$db->query("UPDATE `".DB_PREFIX."blog` SET  `endtime` =  '".strtotime($logedntime)."',`open_endtime` = '".$logopenendtime."' WHERE  `gid` = ".$logid.";");	
lanye_endtime_cache();
}
addAction('save_log','lanye_endtime_add');
function lanye_endtime_gettime($logid){
global $CACHE;$endtime_cache = $CACHE->readCache('endtime');
foreach ($endtime_cache[$logid] as $value){
 return $value['endtime'];
 }
}
function lanye_endtime_getopen($logid){
	global $CACHE;$endtime_cache = $CACHE->readCache('endtime');
foreach ($endtime_cache[$logid] as $value){
 return $value['open_endtime'];
 }
}