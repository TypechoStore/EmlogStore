<?php
function callback_init(){
	$db = Database::getInstance();
	$sql = "ALTER TABLE  `".DB_PREFIX."blog` ADD (`endtime` bigint(20) NOT NULL,`open_endtime` int(10) not null default '0')";
	if(!array_key_exists('endtime',$db->fetch_array($db->query("SELECT * FROM `".DB_PREFIX."blog`;")))){
		$db->query($sql);
	}
}

function callback_rm(){
 
}

