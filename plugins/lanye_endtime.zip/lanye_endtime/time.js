function showToEndTime(id,endTime){
function formatTime(time){
if(time<0) return "已经";
if(time>(1825*1000*60*60*24)) return "结束时间未知,请留意活动页面观察活动是否";
var day =  Math.floor(time/(1000*60*60*24));
var hour = Math.floor((time%(1000*60*60*24))/(1000*60*60));
var minutes= Math.floor((time%(1000*60*60))/(1000*60));
var seconds = Math.floor((time%(1000*60))/(1000)); 
return "于"+day + "天" + hour + "小时" + minutes +"分" + seconds + "秒后";
}
return function(){
var time = endTime.split(/-| |:/); 
document.getElementById(id).innerHTML = formatTime(new Date(time[0],time[1]-1,time[2],time[3],time[4],time[5]) - new Date());
}
}

