<?php
define('KL_AUTO_EXCERPT_LENGTH','200');
?>