<?php
function callback_init(){
	home301_callback_do('y');
}

function callback_rm(){
	home301_callback_do('n');
}

function home301_callback_do($enable){
	global $CACHE;
	$DB = Database::getInstance();
	if($enable=="y"){
		$get_option = $DB -> query("SELECT * FROM `".DB_PREFIX."options` WHERE `option_name` = 'home301_option' ");
		$num = $DB -> num_rows($get_option);
		if($num == 0){
			$home301_option=addslashes(serialize(array()));
			$DB -> query("INSERT INTO `".DB_PREFIX."options`  (`option_name`, `option_value`) VALUES('home301_option', '".$home301_option."') ");
		}
	}else{
		$get_option = $DB -> query("SELECT * FROM `".DB_PREFIX."options` WHERE `option_name` = 'home301_option' ");
		$num = $DB -> num_rows($get_option);
		if($num > 0){
			//$DB -> query("DELETE FROM `".DB_PREFIX."options` WHERE option_name='home301_option'");
		}
	}
	$CACHE->updateCache('options');
}
?>