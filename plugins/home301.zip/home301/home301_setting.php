<?php if(!defined('EMLOG_ROOT')){die('err');}?>
<?php
$action=empty($_POST['action'])?'':trim($_POST['action']);
if(!empty($_POST)&&$action=="submitHome301"){
	$DB = Database::getInstance();
	
	$homepage = @!empty($_POST['homepage']) ? trim($_POST['homepage']) : '';
	
	if(get_magic_quotes_gpc()){
		$homepage=stripslashes($homepage);
	}
	$get_option = $DB -> once_fetch_array("SELECT * FROM `".DB_PREFIX."options` WHERE `option_name` = 'home301_option' ");
	$config_app=unserialize($get_option["option_value"]);
	
	$config_app["homepage"]=$homepage;
	
	$DB -> query("UPDATE `".DB_PREFIX."options`  SET `option_value` = '".addslashes(serialize($config_app))."' WHERE `option_name` = 'home301_option' ");
	header('Location:./plugin.php?plugin=home301');
}
function plugin_setting_view(){
	$DB = Database::getInstance();
	$get_option = $DB -> once_fetch_array("SELECT * FROM `".DB_PREFIX."options` WHERE `option_name` = 'home301_option' ");
	$config_app=unserialize($get_option["option_value"]);
	?>
	<div>
		<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
		  <legend>
			站点首页301插件
		  </legend>
		</fieldset>
		<form id="home301SetForm" method="post" action="">
			<p style="margin-top:10px;">
				站点首页：
				<select name="homepage">
					<option value="" <?php if($config_app["homepage"]==""){?>selected<?php }?>>文章列表</option>
					<option value="t" <?php if($config_app["homepage"]=="t"){?>selected<?php }?>>微语</option>
					<?php
					$res=$DB->query("SELECT * FROM ".DB_PREFIX."blog WHERE type='page' AND hide='n' AND checked='y'");
					$pages = array();
					while ($row = $DB->fetch_array($res)) {
							$pages[] = $row;
					}
					foreach($pages as $val){
					?>
					<option value="<?=$val["gid"];?>" <?php if($config_app["homepage"]==$val["gid"]){?>selected<?php }?>><?=$val["title"];?></option>
					<?php
					}
					?>
					<?php
					if(!is_dir(EMLOG_ROOT."/extends/")){
						mkdir(iconv("UTF-8", "GBK", EMLOG_ROOT."/extends/"),0777,true);
					}
					$extendsList=home301_scandir(EMLOG_ROOT."/extends/");
					foreach($extendsList as $val){
					?>
					<option value="<?=$val;?>" <?php if($config_app["homepage"]==$val){?>selected<?php }?>><?=$val;?>扩展</option>
					<?php
					}
					?>
				</select>
			</p>
			<p style="margin-top:10px;">
				<input type="hidden" name="action" value="submitHome301" />
				<input type="submit" style="background-color: #4CAF50;border: none;color: white;padding:5px 5px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;border-radius: 5%;" value="保存设置" />
			</p>
		</form>
	</div>
	<script>
		<?php if(Option::EMLOG_VERSION>="6.1.1"){?>
		$("#home301").addClass('layui-this');
		$("#home301").parent().parent().addClass('layui-nav-itemed');
		<?php }else if(Option::EMLOG_VERSION=="6.0.0"){?>
		$("#home301 a").addClass('active');
		<?php }else if(Option::EMLOG_VERSION=="6.0.1"){?>
		$("#home301").addClass('active');
		<?php }else if(Option::EMLOG_VERSION=="5.3.1"){?>
		$("#home301").addClass('sidebarsubmenu1');
		<?php }?>
	</script>
	<?php
}
?>