<?php
/*
Plugin Name: 站点首页301插件
Version: 1.0.1
Description: 站点首页301是一个为Emlog独立页面设置为首页的插件。
Plugin URL: https://www.tongleer.com
ForEmlog: 6.1.1
Author: 二呆
Author URL: https://www.tongleer.com
*/
if(!defined('EMLOG_ROOT')){die('err');}

function home301_menu(){
	echo '<li class="sidebarsubmenu layui-nav-item" id="home301"><a href="./plugin.php?plugin=home301" class="waves-effect">home301</a></li>';
}
addAction('adm_sidebar_ext', 'home301_menu');

function home301_head(){
	$DB = Database::getInstance();
	$get_option = $DB -> once_fetch_array("SELECT * FROM `".DB_PREFIX."options` WHERE `option_name` = 'home301_option' ");
	$config_app=unserialize($get_option["option_value"]);
	
	header('HTTP/1.1 301 Moved Permanently');
	if(home301_curPageURL() == BLOG_URL&&!$_SERVER['HTTP_REFERER']){
		switch($config_app["homepage"]){
			case "":break;
			case "t":
				header("Location: ".BLOG_URL."t");
				break;
			default:
				$row=$DB->once_fetch_array("SELECT * FROM ".DB_PREFIX."blog WHERE type='page' AND hide='n' AND checked='y' AND gid='".$config_app["homepage"]."'");
				if($row){
					header("Location: ".Url::log($config_app["homepage"]));
				}else{
					header("Location: ".BLOG_URL."extends/".$config_app["homepage"]);
				}
		}
	}
	
}
addAction('index_head', 'home301_head');

function home301_curPageURL(){
	$pageURL = 'http';
	if ($_SERVER["HTTPS"] == "on"){
		$pageURL .= "s";
	}
	$pageURL .= "://";
	if ($_SERVER["SERVER_PORT"] != "80"){
		$pageURL .= $_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"] . $_SERVER["REQUEST_URI"];
	}else{
		$pageURL .= $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];
	}
	return $pageURL;
}

function home301_scandir($path){
	if(!is_dir($path)){
		return false;
	}
	$arr = array();
	$data = scandir($path);
	foreach ($data as $value){
		if($value != '.' && $value != '..'){
			$arr[] = $value;
		}
	}
	return $arr;
}