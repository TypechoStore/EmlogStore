<?php
require "../../../../init.php";
date_default_timezone_set('Asia/Shanghai');
if(ROLE != ROLE_ADMIN)die("no");

$DB = Database::getInstance();
$time=time();

$action=empty($_POST['action'])?'':trim($_POST['action']);
if ($action== 'del_other') {
	$pic = isset($_POST['pic']) ? addslashes(trim($_POST['pic'])) : '';
	
	if (!isset($pic)) {
		echo("请选择要删除的图片");exit;
	}
	
	$picname=basename($pic);
	$dir=str_replace($picname,'',$pic);
	$thumpic='thum-'.$picname;
	$thum52pic='thum52-'.$picname;
	if (file_exists(dirname(__FILE__)."/../../../".$pic)) {
		@unlink(dirname(__FILE__)."/../../../".$pic);
	}
	if (file_exists(dirname(__FILE__)."/../../../".$dir.$thumpic)) {
		@unlink(dirname(__FILE__)."/../../../".$dir.$thumpic);
	}
	if (file_exists(dirname(__FILE__)."/../../../".$dir.$thum52pic)) {
		@unlink(dirname(__FILE__)."/../../../".$dir.$thum52pic);
	}
	$CACHE->updateCache('user');
	echo("删除图片成功");exit;
}
?>