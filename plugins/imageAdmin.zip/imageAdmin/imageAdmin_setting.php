<?php
!defined('EMLOG_ROOT') && exit('access deined!');

$DB = Database::getInstance();
$action = isset($_POST['action']) ? addslashes(trim($_POST['action'])) : '';
//批量删除标签
if ($action== 'dell_all_media') {
	$medias = isset($_POST['media']) ? $_POST['media'] : '';
	$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
	if (!$medias) {
		header("Location:./plugin.php?plugin=imageAdmin&page=".$page."&error_a=1");
	}

	foreach ($medias as $key=>$aid) {
		$query = $DB->query("SELECT * FROM " . DB_PREFIX . "attachment WHERE aid = $aid ");
		$attach = $DB->fetch_array($query);
		$logid = $attach['blogid'];
		if (file_exists($attach['filepath'])) {
			@unlink($attach['filepath']) or emMsg("删除附件失败!");
		}

		$query = $DB->query("SELECT * FROM ".DB_PREFIX."attachment WHERE thumfor = '".$attach['aid']."'");
		$thum_attach = $DB->fetch_array($query);
		if ($thum_attach) {
			if (file_exists($thum_attach['filepath'])) {
				@unlink($thum_attach['filepath']) or emMsg("删除附件失败!");
			}
			$DB->query("DELETE FROM " . DB_PREFIX . "attachment WHERE aid = '".$thum_attach['aid']."' ");
		}

		$DB->query("UPDATE " . DB_PREFIX . "blog SET attnum=attnum-1 WHERE gid = '".$attach['blogid']."'");
		$DB->query("DELETE FROM " . DB_PREFIX . "attachment WHERE aid = '".$attach['aid']."' ");
	}
	
	header("Location:./plugin.php?plugin=imageAdmin&page=".$page."&active_del=1");
}

function plugin_setting_view(){
	$DB = Database::getInstance();
	$admin = isset($_GET['admin']) ? addslashes(trim($_GET['admin'])) : '';
	if($admin==""){
		$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
		
		$medias = imageAdmin_getAllMediaList($page);
		$medianum = imageAdmin_getMediasNum();
		$pageurl =  pagination($medianum, Option::get('admin_perpage_num'), $page, "?page=");
		?>
		<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
		  <legend>
			文章图片管理&nbsp;&nbsp;<small><a href="./plugin.php?plugin=imageAdmin&admin=other"><b>其他图片管理</b></a></small>
		  </legend>
		</fieldset>
		<?php if(isset($_GET['active_del'])):?><span class="actived">删除图片成功</span><?php endif;?>
		<?php if(isset($_GET['error_a'])):?><span class="error">请选择要删除的图片</span><?php endif;?>
		<form action="./plugin.php?plugin=imageAdmin&page=<?=$page;?>" method="post" name="form_media" id="form_media">
			<input type="hidden" name="action" value="dell_all_media" />
			<div>
				<li>
				<?php 
				if($medias){
					foreach($medias as $key=>$value){
						?>
						<div style="float:left;margin-right:5px;">
							<img src="<?php echo $value['filepath']; ?>" width="100" height="100" title="<?php echo $value['title']; ?>" />
							<div>
								<input type="checkbox" name="media[]" value="<?php echo $value['aid']; ?>" class="ids" />
								<a href="write_log.php?action=edit&gid=<?php echo $value['gid']; ?>" title="<?php echo $value['title']; ?>"><?php echo mb_substr($value['title'],0,5,'utf-8'); ?></a>
							</div>
						</div>
						<?php
					}
					?>
					</li>
					<li style="margin:20px 0px;clear:left;">
					<input type="checkbox" title="全选" id="select_all">全选 选中项：
					<a href="javascript:delmedias();">删除</a>
					<div><?php echo $pageurl; ?> (有<?php echo $medianum; ?>张)</div>
					</li>
					<?php
				}else{
					?>
					<li style="margin:20px 30px">还没有媒体，写文章的时候可以给文章添加图片</li>
					<?php
				}
				?>
			</div>
		</form>
		<script>
		$(document).ready(function(){
			$("#select_all").click(function(){
				if($("#select_all").is(":checked")){
					$(".ids").prop("checked","true");
				}else{
					$(".ids").removeAttr("checked");
				}
			});
		});
		function delmedias(){
			var re = false;
			$('input.ids').each(function(i){
				if ($(this).is(":checked")) {
					re = true;
				}
			});
			if (re == false) {
				alert('请选择要删除的图片');
				return;
			}
			if(!confirm('你确定要删除所选图片吗？')){return;}
			$("#form_media").submit();
		}
		</script>
		<?php
	}else{
		?>
		<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
		  <legend>
			其他图片管理&nbsp;&nbsp;
			<a href="./plugin.php?plugin=imageAdmin"><b>文章图片管理</b></a>
			<small>备注：此处删除后不会关联删除，是直接删除图片文件，并且暂时只支持单个删除。</small>
		  </legend>
		</fieldset>
		<?php 
		$dir = '../content/uploadfile/';
		$imgs=imageAdmin_scanfiles($dir);
		if($imgs){
			$i=0;foreach($imgs as $key=>$pic){
				if(strpos(basename($pic), 'thum-')===false){
					if(
						imageAdmin_endwith($pic,'.jpg')||
						imageAdmin_endwith($pic,'.jpeg')||
						imageAdmin_endwith($pic,'.gif')||
						imageAdmin_endwith($pic,'.png')
					){
						$flat=false;
						$ret = $DB->query("SELECT * FROM ".DB_PREFIX."attachment");
						while ($row = $DB->fetch_array($ret)) {
							if(basename($row['filepath'])==basename($pic)){
								$flat=true;
								break;
							}
						}
						if($flat){
							continue;
						}
						?>
						<div style="float:left;margin-right:5px;">
							<a class="delOtherBtn" id="delOtherBtn<?=$i;?>" href="javascript:;" onClick="return false;" data-pic="<?php echo $pic; ?>">
								<img src="<?php echo $pic; ?>" width="50" height="50" title="<?php echo $pic; ?>" />
							</a>
						</div>
						<?php
					}
				}
				$i++;
			}
		}
		?>
		<script>
		$(".delOtherBtn").each(function(){
			var id=$(this).attr("id");
			$("#"+id).click( function () {
				if(confirm('确定要删除吗？')){
					$.ajax({
						type : "POST",
						url : "<?=BLOG_URL;?>content/plugins/imageAdmin/ajax/del_other.php",
						data : {"action":"del_other","pic":$(this).attr("data-pic")},
						dataType : 'text',
						success : function(data) {
							location.reload();
						},error:function(data){
							alert(data);
						}
					});
				}
			});
		});
		</script>
		<?php
	}
	?>
	<script>
	setTimeout(hideActived,2600);
	<?php if(Option::EMLOG_VERSION>="6.1.1"){?>
	$("#imageAdmin").addClass('layui-this');
	$("#imageAdmin").parent().parent().addClass('layui-nav-itemed');
	<?php }else if(Option::EMLOG_VERSION=="6.0.0"){?>
	$("#imageAdmin a").addClass('active');
	<?php }else if(Option::EMLOG_VERSION=="6.0.1"){?>
	$("#imageAdmin").addClass('active');
	<?php }else if(Option::EMLOG_VERSION=="5.3.1"){?>
	$("#imageAdmin").addClass('sidebarsubmenu1');
	<?php }?>
	</script>
	<?php
}
?>