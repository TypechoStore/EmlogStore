<?php
/*
Plugin Name: 图片管理
Version: 1.0.1
Plugin URL:
Description: 基于php5.6，为Emlog5.3.1及6.0.0增加管理图片、并为所有版本增加删除除文章图片之外uploadfile目录中图片的功能。
Author: 二呆
Author URL: https://www.tongleer.com
*/

!defined('EMLOG_ROOT') && exit('access deined!');

function imageAdmin_adm_sidebar_ext(){
	echo '
		<div class="sidebarsubmenu" id="imageAdmin">
			<a href="./plugin.php?plugin=imageAdmin">图片管理</a>
			<a href="./plugin.php?plugin=imageAdmin&admin=other">图片外部管理</a>
		</div>
	';
}
addAction('adm_sidebar_ext', 'imageAdmin_adm_sidebar_ext');
/**
 * 获取全部媒体列表
 *
 */
function imageAdmin_getAllMediaList($page = null) {
	$db = Database::getInstance();
	$andQuery = "1=1 and thumfor=0";
	$condition = '';
	if ($page) {
		$perpage_num = Option::get('admin_perpage_num');
		if ($page > PHP_INT_MAX) {
			$page = PHP_INT_MAX;
		}
		$startId = ($page - 1) * $perpage_num;
		$condition = "LIMIT $startId, ".$perpage_num;
	}
	$sql = "SELECT * FROM ".DB_PREFIX."blog as b, ".DB_PREFIX."attachment as a where $andQuery and b.gid=a.blogid ORDER BY b.date DESC $condition";
	$ret = $db->query($sql);
	$medias = array();
	$temi=0;
	while ($row = $db->fetch_array($ret)) {
		$medias[$temi]['aid'] = $row['aid'];
		$medias[$temi]['gid'] = $row['gid'];
		$medias[$temi]['title'] = $row['title'];
		$medias[$temi]['date'] = smartDate($row['date']);
		$medias[$temi]['filepath'] = $row['filepath'];
		$temi++;
	}
	return $medias;
}
/**
 * 获取全部媒体记录数
 *
 * @param int $page
 * @return array
 */
function imageAdmin_getMediasNum() {
	$db = Database::getInstance();
	$mediaNum = '';
	$andQuery = '1=1 and thumfor=0';
	$sql = "SELECT count(*) FROM ".DB_PREFIX."attachment as a where $andQuery";
	$res = $db->once_fetch_array($sql);
	$mediaNum = $res['count(*)'];
	return $mediaNum;
}
/**
* PHP 非递归实现查询该目录下所有文件
* @param unknown $dir
* @return multitype:|multitype:string
*/
function imageAdmin_scanfiles($dir) {
	if (! is_dir ( $dir ))
		return array ();
	// 兼容各操作系统
	$dir = rtrim ( str_replace ( '\\', '/', $dir ), '/' ) . '/';
	// 栈，默认值为传入的目录
	$dirs = array ( $dir );
	// 放置所有文件的容器
	$rt = array ();
	do {
		// 弹栈
		$dir = array_pop ( $dirs );
		// 扫描该目录
		$tmp = scandir ( $dir );
		foreach ( $tmp as $f ) {
			// 过滤. ..
			if ($f == '.' || $f == '..')
				continue;
			// 组合当前绝对路径
			$path = $dir . $f;
			// 如果是目录，压栈。
			if (is_dir ( $path )) {
				array_push ( $dirs, $path . '/' );
			} else if (is_file ( $path )) { // 如果是文件，放入容器中
				$rt [] = $path;
			}
		}
	} while ( $dirs ); // 直到栈中没有目录
	return $rt;
}
/**
* endwith()
* 判断是否以特定的字符串结束，查找文件后缀用
* @param string $haystack
* @param string $needle
* @return boolean $result
*/
function imageAdmin_endwith($haystack,$needle){
	if(!$needle) return false;
	$nlen = strlen($needle);
	$strend = substr($haystack,-$nlen);
	return ($strend==$needle)?true:false;
}