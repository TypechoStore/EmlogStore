<?php
!defined('EMLOG_ROOT') && exit('access deined!');
function plugin_setting_view()
{
include(EMLOG_ROOT.'/content/plugins/lanye_daziji/lanye_daziji_config.php');
?>
<div class="containertitle"><b>蓝叶打字机设置</b><?php if(isset($_GET['setting'])):?><span class="actived">设置成功</span><?php endif;?></div>
<div class=line></div>
<form action="./plugin.php?plugin=lanye_daziji&action=setting" method="POST">
<p style="padding-bottom:10px">加载Jquery库：<select name="loadjquery"><option value="y" <?php if($config["loadjquery"]=="y") echo "selected"; ?>>加载</option><option value="n" <?php if($config["loadjquery"]=="n") echo "selected"; ?>>禁止</option></select> <span style="fongt-family:宋体;color:#999;">如果你的网站里已经引用的jquery库，这里就可以禁止了。</span></p>
<p style="padding-bottom:10px">设置打字速度：<input type="text" name="dazisudu" value="<?php echo $config["dazisudu"];?>" /> <span style="fongt-family:宋体;color:#999;">这里设置打字效果的速度</span></p>
<p style="padding-bottom:10px">是否重复打字：<select name="chongfu"><option value="true" <?php if($config["chongfu"]=="true") echo "selected"; ?>>重复</option><option value="false" <?php if($config["chongfu"]=="false") echo "selected"; ?>>禁止</option></select> <span style="fongt-family:宋体;color:#999;">设置打字结束是否重复打字。</span></p>
<p style="padding-bottom:10px">是否倒叙返回：<select name="daoxu"><option value="true" <?php if($config["daoxu"]=="true") echo "selected"; ?>>倒叙</option><option value="false" <?php if($config["daoxu"]=="false") echo "selected"; ?>>禁止</option></select> <span style="fongt-family:宋体;color:#999;">当打字结束倒叙返回重头再打字。</span></p>
<p style="padding-bottom:10px">设置是否闪烁：<select name="shanshuo"><option value="true" <?php if($config["shanshuo"]=="true") echo "selected"; ?>>闪烁</option><option value="false" <?php if($config["shanshuo"]=="false") echo "selected"; ?>>不闪</option></select> <span style="fongt-family:宋体;color:#999;">打字结束时闪烁效果。</span></p>
<p style="padding-bottom:10px">设置打字效果的样式名：<input type="text" name="yangshi" value="<?php echo $config["yangshi"];?>" /> <span style="fongt-family:宋体;color:#999;">设置需要添加打字效果的层样式名，可以写多个，中间用英文逗号隔开，结尾无逗号。</span></p>
<p><input type="submit" value="保存设置" style="padding:10px;cursor:pointer;font-size:14px;" /></p>
</form>
<?php
}
function plugin_setting(){
	$newConfig = '<?php
$config = array(
 "loadjquery" => "'.addslashes($_POST["loadjquery"]).'",
 "dazisudu" => "'.addslashes($_POST["dazisudu"]).'",
 "chongfu" => "'.addslashes($_POST["chongfu"]).'",
 "daoxu" => "'.addslashes($_POST["daoxu"]).'",
 "shanshuo" => "'.addslashes($_POST["shanshuo"]).'",
 "yangshi" => "'.addslashes($_POST["yangshi"]).'"
);';
	@file_put_contents(EMLOG_ROOT.'/content/plugins/lanye_daziji/lanye_daziji_config.php', $newConfig);
}


?>