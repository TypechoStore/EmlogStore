<?php
/*
Plugin Name: 蓝叶打字机效果
Version: 1.0
Plugin URL: http://lanyes.org
Description: 一个打字机效果的插件。
Author: 蓝叶
Author Email: w@lanyes.org
Author URL: http://lanyes.org
*/
!defined('EMLOG_ROOT') && exit('access deined!');
function lanye_daziji_menu()//写入插件导航
{echo '<div class="sidebarsubmenu" id="lanye_daziji_menu"><a href="./plugin.php?plugin=lanye_daziji">打字机设置</a></div>';}
addAction('adm_sidebar_ext', 'lanye_daziji_menu');

function lanye_daziji(){
require_once 'lanye_daziji_config.php';?>
<?php if($config["loadjquery"] == 'y'){echo '<script type="text/javascript" src="http://apps.bdimg.com/libs/jquery/1.7.2/jquery.min.js"></script>';};?>
<script src="<?php echo BLOG_URL;?>content/plugins/lanye_daziji/daziji.js" type="text/javascript" ></script>
<script>$(document).ready(function(){$("<?php echo $config["yangshi"];?>").typing({speed:<?php echo $config["dazisudu"];?>,repeat:<?php echo $config["chongfu"];?>,flashback:<?php echo $config["daoxu"];?>,flicker:<?php echo $config["shanshuo"];?>});})</script>
<?php }
addAction('index_footer', 'lanye_daziji');