<?php
$config = array(
 "loadjquery" => "n",
 "dazisudu" => "100",
 "chongfu" => "true",
 "daoxu" => "false",
 "shanshuo" => "false",
 "yangshi" => ".yinyong,.text"
);