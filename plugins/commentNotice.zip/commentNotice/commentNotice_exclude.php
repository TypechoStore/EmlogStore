<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>取消评论邮件通知</title>
<style>
.main{ width:220px; height:130px; padding:15px; position:absolute; top:50%; left:50%; margin:-100px 0 0 -110px; font-size:12px; font-family:'Microsoft Yahei'; color:#666; line-height:180%; border:1px solid #f2f2f2; border-radius:5px; box-shadow:0 0 40px;}
.main p{ margin:0; padding:0;}
</style>
</head>
<body>
<div class="main">
	<p>Emlog评论邮件通知插件——取消</p>
	<p>作者：Liuzp</p>
	<p>主页：<a href="http://www.liuzp.com" target="_blank">www.liuzp.com</a></p>
	<p>取消之后就不能在邮件中及时收到别人的回复。再次开通需联系当前网站管理员。</p>
	<p><a href="javascript:void(0)" onclick="if(confirm('确定取消？')){location.href=document.URL+'&exclude=go'}">点击取消</a></p>
</div>
<?php
if(@$_GET["exclude"]=="go"){
	$email = safe_string($_GET["email"]);
	if(checkEmail($email)){
		require ('commentNotice_config.php');
		if(!in_array($email, $config["exclude"])){
			$config["exclude"][] = $email;
			foreach ($config["exclude"] as $exclude){
				$excludes = $excludes.',"'.$exclude.'"';
			}
			$excludes=ltrim($excludes, ",");
		
			$newConfig = '<?php
$config = array(
	"smtpHost" => "'.$config["smtpHost"].'", //smtp服务器
	"smtpUser" => "'.$config["smtpUser"].'", //发件邮箱
	"smtpPwd" => "'.$config["smtpPwd"].'", //发信邮箱密码
	"rule" => "'.$config["rule"].'", //0为所有人，1为仅自己
	"exclude" => array(
		'.$excludes.'
	)
);?>';
			@file_put_contents('commentNotice_config.php', $newConfig);
			echo '<script>alert("取消成功");location.href="http://'.$_SERVER['HTTP_HOST'].'";</script>';
		}else{
			echo '<script>alert("已取消");location.href="http://'.$_SERVER['HTTP_HOST'].'";</script>';
		}
	}else{
		echo '<script>alert("邮箱不正确");</script>';
	}
}

function safe_string($str){ //过滤安全字符
	$str=str_replace("'","",$str);
	$str=str_replace('"',"",$str);
	$str=str_replace(" ","$nbsp;",$str);
	$str=str_replace("\n;","<br/>",$str);
	$str=str_replace("<","<",$str);
	$str=str_replace(">",">",$str);
	$str=str_replace("\t"," ",$str);
	$str=str_replace("\r","",$str);
	$str=str_replace("/[\s\v]+/"," ",$str);
	return $str;
}

function checkEmail($email){
	$pregEmail = "/([a-z0-9]*[-_\.]?[a-z0-9]+)*@([a-z0-9]*[-_]?[a-z0-9]+)+[\.][a-z]{2,3}([\.][a-z]{2})?/i";
	return preg_match($pregEmail,$email);  
}
?>
</body>
</html>