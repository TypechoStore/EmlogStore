<?php
/**
 * Plugin Name: 评论邮件通知
 * Version: 1.0
 * Plugin URL: http://www.liuzp.com
 * Description: 在收到评论和回复时自动将评论内容发送到被评人邮箱
 * Author: Liuzp
 * Author Email: root@liuzp.com
 * Author URL: http://www.liuzp.com
 */

!defined('EMLOG_ROOT') && exit('access deined!');
function plugin_setting_view(){
	require (EMLOG_ROOT . '/content/plugins/commentNotice/commentNotice_config.php');
	foreach ($config["exclude"] as $exclude){
		$excludes = $excludes.",".$exclude;
	}
	$excludes=ltrim($excludes, ",");
	?>
	<link href="/content/plugins/commentNotice/style.css" type="text/css" rel="stylesheet" />
	<div class="com-hd">
		<b>评论邮件通知插件设置</b>
		<?php
		if(isset($_GET['setting'])){
			echo "<span class='actived'>设置保存成功!</span>";
		}
		if(@$_GET['test']=="go"){
			smtp_mail($config["smtpUser"], "插件测试", "恭喜您可以正常使用此插件<br /><a href='http://www.liuzp.com' target='_blank'>LBlog</a>", "liuzp.com", "test");
		}
		?>
	</div>
	<form action="plugin.php?plugin=commentNotice&action=setting" method="post">
		<table class="tb-set">
			<tr>
				<td align="right" width="25%"><b>smtp服务器：</b></td>
				<td width="75%"><input type="text" class="txt" name="host" value="<?php echo $config["smtpHost"]; ?>" /></td>
			</tr>
			<tr>
				<td align="right"><b>收发邮箱：</b></td>
				<td><input type="text" class="txt" name="user" value="<?php echo $config["smtpUser"]; ?>" /></td>
			</tr>
			<tr>
				<td align="right"><b>邮箱密码：</b></td>
				<td><input type="password" class="txt" name="pwd" value="<?php echo $config["smtpPwd"]; ?>" /></td>
			</tr>
			<tr>
				<td align="right"><b>收信规则：</b><br />(右边文本框内的邮箱不会接收系统发出的评论通知邮件，多个以“,”分隔。)</td>
				<td><input type="radio" name="rule" value="1" <?php if($config["rule"]==1){echo 'checked';} ?> />仅自己接收&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="rule" value="0" <?php if($config["rule"]==0){echo 'checked';} ?> />所有人接收，但以下邮箱除外：
				<p><textarea class="txt txt-lar" name="exclude"><?php echo $excludes; ?></textarea></p>
				</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><input type="submit" name="submit" value="保存" />&nbsp;&nbsp;<input type="button" onclick="location.href=document.URL+'&test=go'" value="测试" />&nbsp;&nbsp;<font color='red'>请先保存正确的设置后再测试，点测试后能收到邮件表示您可以正常使用该插件</font></td>
			</tr>
		</table>
	</form>
	<?php
}

function plugin_setting(){
	require (EMLOG_ROOT . '/content/plugins/commentNotice/commentNotice_config.php');
	foreach (explode(",",$_POST['exclude']) as $exclude){
		$excludes = $excludes.'"'.$exclude.'"'.",";
	}
	$excludes=rtrim($excludes, ",");
	$newConfig = '<?php
$config = array(
	"smtpHost" => "'.$_POST["host"].'", //smtp服务器
	"smtpUser" => "'.$_POST["user"].'", //发件邮箱
	"smtpPwd" => "'.$_POST["pwd"].'", //发信邮箱密码
	"rule" => "'.$_POST["rule"].'", //0为所有人，1为仅自己
	"exclude" => array(
		'.$excludes.'
	)
);?>';
	@file_put_contents(EMLOG_ROOT.'/content/plugins/commentNotice/commentNotice_config.php', $newConfig);
}
?>