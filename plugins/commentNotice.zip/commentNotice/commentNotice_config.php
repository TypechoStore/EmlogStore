<?php
$config = array(
	"smtpHost" => "smtp.exmail.qq.com", //smtp服务器
	"smtpUser" => "xx@xx.com", //发件邮箱
	"smtpPwd" => "xxx", //发信邮箱密码
	"rule" => "0", //0为所有人，1为仅自己
	"exclude" => array(
		""
	)
);?>