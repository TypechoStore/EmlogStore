<?php
/*
 Plugin Name: 左南下载样式插入工具
 Version: 1.0
 Plugin URL: http://www.kmiwz.com
 Description: 这是一个编辑器加强插件，激活后在发布文章页面编辑器上方会看到按钮，点击就会显示了。
 ForEmlog:5.3.x
 Author: 左南
 Author Email: 695223807@qq.com
 Author URL: http://www.kmiwz.com
*/
!defined('EMLOG_ROOT') && exit('access deined!');
function zl_sc_download(){?>
<script>
$(document).ready(function(){
	$("#fjbox #fjcharu").click(function(){
		if(typeof($('#markdownEditor_content').val())!='undefined'){
			$('#markdownEditor_content').val($('#markdownEditor_content').val()+"<p><a class='sc_download' href='"+($('#dizhi').val())+"' target='_blank' ><span class='file_title'>"+($('#namee').val())+"</span><span>"+($('#mingzi').val())+" – "+($('#daxiao').val())+"</span></a> </p>");
		}else if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
			layedit.setContent(contentLayUIEditor,"<p><a class='sc_download' href='"+($('#dizhi').val())+"' target='_blank' ><span class='file_title'>"+($('#namee').val())+"</span><span>"+($('#mingzi').val())+" – "+($('#daxiao').val())+"</span></a> </p>",true);
		}else{
			$($(".ke-edit-iframe:first").contents().find(".ke-content")).append("<p><a class='sc_download' href='"+($('#dizhi').val())+"' target='_blank' ><span class='file_title'>"+($('#namee').val())+"</span><span>"+($('#mingzi').val())+" – "+($('#daxiao').val())+"</span></a> </p>");
		}
	});
	$("#close_tools").click(function(){
	$("#qx_con").slideUp(200);
		}); 
	$("#qx_title").click(function(){
		$("#qx_con").slideDown(200);
	}); 
	$("#clear_shuru").click(function(){
		$("#qx_con input").attr("value","");
	});
});
</script>
<style>
#qx_box{font-weight:bold; font-family:Arial;font-size:12px;margin:5px 0; cursor:pointer;clear:both;}
#qx_box #qx_title{background:#5bc0de;float:left;padding:2px 5px;margin-bottom:5px;float:left;clear:both;color:#fff;border-radius:4px;font-weight:normal;font-family:"Microsoft Yahei";font-size:14px;background-size: 30px 30px;box-shadow: 0 0 4px 1px rgba(16, 160, 249, 0.3);}
#qx_box #qx_con{clear:both;float:left;font-weight:normal;margin:5px 0 10px 0;display:none;border: 1px solid #ccc;padding: 10px;width:450px;border-radius: 4px;}
#qx_box #qx_con p{margin:0 0 10px 0;font-size:14px;}
#qx_box #qx_con input{width:210px;font-size:12px;padding:5px;border-radius:4px;outline:none;border: 1px solid #ccc;}
#qx_box #qx_con input:-webkit-autofill{background:#fff;}
#qx_box #qx_con span{float:left;cursor:pointer;border:0;padding:2px 5px;font-size: 12px;margin: 0 10px 0 0;border-radius:4px;color:#fff;background-size: 30px 30px;box-shadow: 0 0 4px 1px rgba(16, 160, 249, 0.3);}
#qx_box #qx_con span:hover{background:#00aff0 !important;color:#fff !important;}
#qx_box #qx_con #crfj{background:#9c3;color:#fff;}
#qx_box #qx_con select{padding:5px;border-radius:4px;outline:none;border: 1px solid #ccc;}
input:focus,select:focus{border-color:#66afe9;outline:0;-webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);background:#fff;}
</style>
<div id="qx_box">
<div id="qx_title">左南下载样式插入工具</div> 
<div id="qx_con">
<div id="fjbox">
<p>下载来源：<input name="mingzi" id="mingzi" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例如：百度网盘</b></p>
<p>文件名称：<input name="namee" id="namee" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例子：网页素材下载</b></p>
<p>下载地址：<input name="dizhi" id="dizhi" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例子：http://baidu.com</b></p>
<p>文件大小：<input name="daxiao" id="daxiao" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例子：10MB</b></p>
<p style="margin: 10px 0 0 70px;"><span id="fjcharu" style="background-color:#337ab7;">插入代码</span> <span id="close_tools" style="background-color:#5cb85c">关闭工具</span> <span id="clear_shuru" style="background-color:#f0ad4e">清楚内容</span></p></div>
</div></div>
<?php }
addAction('adm_writelog_head', 'zl_sc_download');
function zl_css(){?>
<style>.sc_download { color: #3EA7D6; height: 50px; font-size: 12px; display: inline-block; padding: 0 15px 0 55px; margin: 10px 0; border-radius: 2px; border: 1px solid #e7e7e7; background: #f3f3f3 url("<?php echo BLOG_URL;?>content/plugins/zl_sc_download/zl_sc_download.png") 10px no-repeat; }.sc_download:hover { background-color: #f5f5f5; }.sc_download span { font-weight: bold; text-align: center; padding: 0 5px; }.sc_download .file_title { display: block; border-bottom: 1px solid #e7e7e7; line-height: 25px; }</style>
<?php }
addAction('index_footer', 'zl_css');