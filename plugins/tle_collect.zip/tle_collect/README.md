# TleCollect For Emlog采集插件

一个使用QueryList采集工具的Emlog采集插件，包含采集单篇、多篇文章或视频内容而采集结果未知的插件，已验证可采集优酷视频及网站网站，但由于免不了的bug，不保证每一个人使用过程中的问题。

# 使用方法
1、下载后需要把文件夹名改为：“tle_collect”。->启用->设置选择器->开始采集。

# 使用注意
此插件使用php5.6开发，如遇报错，只需调整php版本为php5.6即可。

# 下载地址
Github：https://github.com/muzishanshi/TleCollectForEmlog

# 版本记录
v1.0.1：第一个版本降世