<?php
/*
Plugin Name: 红尘梦网站导航插件
Version: 1.0
Plugin URL：https://www.vc99.cn/
Description: 网站导航插件，使用此插件请配合模板红尘梦使用，否则此插件无法正常使用。
Author: 红尘
Author URL: https://www.vc99.cn/
*/
define('CSS_URL', BLOG_URL .'content/plugins/daohang/');
/**
 * 添加
 *
 * @param array $logData
 * @return int
 */
function Down_addlog($logData) {
    $db = Database::getInstance();
    $kItem = array();
    $dItem = array();
    foreach ($logData as $key => $data) {
        $kItem[] = $key;
        $dItem[] = $data;
    }
    $field = implode(',', $kItem);
    $values = "'" . implode("','", $dItem) . "'";
    $db->query("INSERT INTO " . DB_PREFIX . "daohang ($field) VALUES ($values)");
    $logid = $db->insert_id();
    return $logid;
}
/**
 * 不懂请勿修改代码，以免造成插件无法使用
 *
 * @param array $logData
 * @param int $blogId
 */
function Down_updateLog($logData, $blogId) {
    $db = Database::getInstance();
    $Item = array();
    foreach ($logData as $key => $data) {
        $Item[] = "$key='$data'";
    }
    $upStr = implode(',', $Item);
    $db->query("UPDATE " . DB_PREFIX . "daohang SET $upStr WHERE logid=$blogId");
}
function Cp_down_setting_create($logid){
    $db = Database::getInstance();
    $data = $db->query("SELECT * FROM ".DB_PREFIX."daohang WHERE logid ='$logid'");
    $start = isset($_POST['start']) ? addslashes(trim($_POST['start'])) : 'n';
    $biaoti = isset($_POST['biaoti']) ? addslashes(trim($_POST['biaoti'])) : '';
    $tupian = isset($_POST['tupian']) ? addslashes(trim($_POST['tupian'])) : '';
    $shijian = isset($_POST['shijian']) ? addslashes(trim($_POST['shijian'])) : '';
    $sogoshoulu = isset($_POST['sogoshoulu']) ? addslashes(trim($_POST['sogoshoulu'])) : '';
    $zhanQQ = isset($_POST['dauthor']) ? addslashes(trim($_POST['dauthor'])) : '';
    $yuming = isset($_POST['yuming']) ? addslashes(trim($_POST['yuming'])) : '';
    $wangzhi = isset($_POST['wangzhi']) ? addslashes(trim($_POST['wangzhi'])) : '';
    $baiduquanzhong = isset($_POST['baiduquanzhong']) ? addslashes(trim($_POST['baiduquanzhong'])) : '';
    $sanquanzhong = isset($_POST['sanquanzhong']) ? addslashes(trim($_POST['sanquanzhong'])) : '';
    $sogoquanzhong = isset($_POST['sogoquanzhong']) ? addslashes(trim($_POST['sogoquanzhong'])) : '';
    $baidushoulu = isset($_POST['baidushoulu']) ? addslashes(trim($_POST['baidushoulu'])) : '';
    $guanjianci = isset($_POST['guanjianci']) ? addslashes(trim($_POST['guanjianci'])) : '';
    $jieshao = isset($_POST['jieshao']) ? addslashes(trim($_POST['jieshao'])) : '';
    $sanshoulu = isset($_POST['sanshoulu']) ? addslashes(trim($_POST['sanshoulu'])) : '';
    $bianjirenyuan = isset($_POST['bianjirenyuan']) ? addslashes(trim($_POST['bianjirenyuan'])) : '';
    $ico = isset($_POST['ico']) ? addslashes(trim($_POST['ico'])) : '';
    
    $logData = array('start' => $start,'logid' => $logid,'biaoti' => $biaoti,'tupian' => $tupian,'shijian' => $shijian,'sogoshoulu' => $sogoshoulu,'zhanQQ' => $zhanQQ,'yuming' => $yuming,'wangzhi' => $wangzhi,'baiduquanzhong' => $baiduquanzhong,'sanquanzhong' => $sanquanzhong,'sogoquanzhong' => $sogoquanzhong,'baidushoulu' => $baidushoulu,'guanjianci' => $guanjianci,'jieshao' => $jieshao,'sanshoulu' => $sanshoulu,'bianjirenyuan' => $bianjirenyuan,'ico' => $ico,);
    $UplogData = array('start' => $start,'biaoti' => $biaoti,'tupian' => $tupian,'shijian' => $shijian,'sogoshoulu' => $sogoshoulu,'zhanQQ' => $zhanQQ,'yuming' => $yuming,'wangzhi' => $wangzhi,'baiduquanzhong' => $baiduquanzhong,'sanquanzhong' => $sanquanzhong,'sogoquanzhong' => $sogoquanzhong,'baidushoulu' => $baidushoulu,'guanjianci' => $guanjianci,'jieshao' => $jieshao,'sanshoulu' => $sanshoulu,'bianjirenyuan' => $bianjirenyuan,'ico' => $ico,);
    if($db->fetch_array($data) == ""){
        Down_addlog($logData);
    }else{
        Down_updateLog($UplogData, $logid);
    }
}

addAction('save_log', 'Cp_down_setting_create');


function CP_donw_option(){
    $query = $_SERVER["QUERY_STRING"];
    $string = preg_replace('/action=edit&gid=/','',$query);
    $db = Database::getInstance();
    $data = $db->query("SELECT * FROM ".DB_PREFIX."daohang WHERE logid ='".$string."'");
    $row = $db->fetch_array($data);
    if( $row == ''){
        $logData = array('start' => '','biaoti' => '','tupian' => '','shijian' => '','bianjirenyuan' => '','sogoshoulu' => '','zhanQQ' => '','yuming' => '','wangzhi' => '','baiduquanzhong' => '','sanquanzhong' => '','sogoquanzhong' => '','baidushoulu' => '','guanjianci' => '','jieshao' => '','sanshoulu' => '');
    }else{
        $logData = array(
            'start' => htmlspecialchars($row['start']),
            'biaoti' => htmlspecialchars($row['biaoti']),
            'tupian' => htmlspecialchars($row['tupian']),
            'shijian' => htmlspecialchars($row['shijian']),
            'sogoshoulu' => htmlspecialchars($row['sogoshoulu']),
            'zhanQQ' => htmlspecialchars($row['zhanQQ']),
            'yuming' => htmlspecialchars($row['yuming']),
            'wangzhi' => htmlspecialchars($row['wangzhi']),
            'baiduquanzhong' => htmlspecialchars($row['baiduquanzhong']),
            'sanquanzhong' => htmlspecialchars($row['sanquanzhong']),
            'sogoquanzhong' => htmlspecialchars($row['sogoquanzhong']),
            'baidushoulu' => htmlspecialchars($row['baidushoulu']),
            'guanjianci' => htmlspecialchars($row['guanjianci']),
            'jieshao' => htmlspecialchars($row['jieshao']),
            'sanshoulu' => htmlspecialchars($row['sanshoulu']),
            'bianjirenyuan' => htmlspecialchars($row['bianjirenyuan']),
            'ico' => htmlspecialchars($row['ico']),
        );
    }
    
?>
<link href="<?php echo CSS_URL; ?>bootstrap.css" type="text/css" rel="stylesheet">
<div class="row">
    <div class="col-lg-12">
        <table class="table">
            <tbody>
                <tr>
                    <th style="width:10%;"><label>开启导航模板</label></th>
                    <th>
                        <input type="checkbox" name="start" id="statr" title="启用" value="y"<?php if($logData['start']=='y'){echo ' checked';}else{echo '';}?> ><span></span>
                    </th>
                </tr>
                <tr>
                    <th style="width:10%;"><label>网站标题</label></th>
                    <th><input type="text" placeholder="该网站的标题" class="form-control" name="biaoti" id="biaoti" value="<?php echo $logData['biaoti']; ?>" size="30" tabindex="30" style="width: 80%;"></th>
                </tr>
                <tr>
                    <th style="width:10%;"><label>收录时间</label></th>
                    <th><input type="text" placeholder="请输入收录该网站时的时间" class="form-control" name="shijian" id="shijian" value="<?php echo $logData['shijian']; ?>" size="30" tabindex="30" style="width: 80%;"></th>
                </tr>
                <tr>
                    <th style="width:10%;"><label>站长QQ</label></th>
                    <th><input type="text" placeholder="该网站站长的联系QQ" class="form-control" name="dauthor" id="dauthor" value="<?php echo $logData['zhanQQ']; ?>" size="30" tabindex="30" style="width: 80%;"></th>
                </tr>
                <tr>
                    <th style="width:10%;"><label>网站域名</label></th>
                    <th><input type="text" placeholder="该网站的域名，不加http" class="form-control" name="yuming" id="yuming" value="<?php echo $logData['yuming']; ?>" size="30" tabindex="30" style="width: 80%;"></th>
                </tr>
                <tr>
                <tr>
                    <th style="width:10%;"><label>百度权重</label></th>
                    <th><input type="text" placeholder="输入数字0-9即可" class="form-control" name="baiduquanzhong" id="baiduquanzhong" value="<?php echo $logData['baiduquanzhong']; ?>" size="30" tabindex="30" style="width: 80%;"></th>
                </tr>
                <tr>
                    <th style="width:10%;"><label>360权重</label></th>
                    <th><input type="text" placeholder="输入数字0-9即可" class="form-control" name="sanquanzhong" id="sanquanzhong" value="<?php echo $logData['sanquanzhong']; ?>" size="30" tabindex="30" style="width: 80%;"></th>
                </tr>
                <tr>
                    <th style="width:10%;"><label>搜狗权重</label></th>
                    <th><input type="text" placeholder="输入数字1-9即可" class="form-control" name="sogoquanzhong" id="sogoquanzhong" value="<?php echo $logData['sogoquanzhong']; ?>" size="30" tabindex="30" style="width: 80%;"></th>
                </tr>
                <tr>
                  <th style="width:10%;"><label>百度收录</label></th>
                    <th><input type="text" placeholder="该网站的收录量，填写数字即可" class="form-control" name="baidushoulu" id="baidushoulu" value="<?php echo $logData['baidushoulu']; ?>" size="30" tabindex="30" style="width: 80%;"></th>
                </tr>
                 <tr>
                    <th style="width:10%;"><label>搜狗收录</label></th>
                    <th><input type="text" placeholder="该网站的收录量，填写数字即可" class="form-control" name="sogoshoulu" id="sogoshoulu" value="<?php echo $logData['sogoshoulu']; ?>" size="30" tabindex="30" style="width: 80%;"></th>
                </tr>
                 <tr>
                    <th style="width:10%;"><label>360收录</label></th>
                    <th><input type="text" placeholder="该网站的收录量，填写数字即可"  class="form-control" name="sanshoulu" id="sanshoulu" value="<?php echo $logData['sanshoulu']; ?>" size="30" tabindex="30" style="width: 80%;"></th>
                </tr>
                <tr>
                    <th style="width:10%;"><label>网站关键词</label></th>
                    <th><input type="text" placeholder="该网站的关键词" class="form-control" name="guanjianci" id="guanjianci" value="<?php echo $logData['guanjianci']; ?>" size="30" tabindex="30" style="width: 80%;"></th>
                </tr>
                <tr>
                    <th style="width:10%;"><label>网站介绍</label></th>
                    <th><input type="text" placeholder="该网站的网站介绍" class="form-control" name="jieshao" id="jieshao" value="<?php echo $logData['jieshao']; ?>" size="30" tabindex="30" style="width: 80%;"></th>
                </tr>
                <tr>
            </tbody>
        </table>
    </div>
</div>
<?php
}
addAction('adm_writelog_head', 'CP_donw_option');
function show_down($logid){
    $db = Database::getInstance();
	$data = $db->query("SELECT * FROM ".DB_PREFIX."daohang WHERE logid ='$logid'");
	$row = $db->fetch_array($data);
	$logData = array(
		'start' => htmlspecialchars($row['start']),
		'biaoti' => htmlspecialchars($row['biaoti']),
		'tupian' => htmlspecialchars($row['tupian']),
		'shijian' => htmlspecialchars($row['shijian']),
		'sogoshoulu' => htmlspecialchars($row['sogoshoulu']),
		'zhanQQ' => htmlspecialchars($row['zhanQQ']),
		'yuming' => htmlspecialchars($row['yuming']),
         'start' => htmlspecialchars($row['start']),
	'biaoti' => htmlspecialchars($row['biaoti']),
	'tupian' => htmlspecialchars($row['tupian']),
	'shijian' => htmlspecialchars($row['shijian']),
	'sogoshoulu' => htmlspecialchars($row['sogoshoulu']),
	'zhanQQ' => htmlspecialchars($row['zhanQQ']),
	'yuming' => htmlspecialchars($row['yuming']),
    'bianjirenyuan' => htmlspecialchars($row['bianjirenyuan']),
	'wangzhi' => htmlspecialchars($row['wangzhi']),
	'baiduquanzhong' => htmlspecialchars($row['baiduquanzhong']),
	'sanquanzhong' => htmlspecialchars($row['sanquanzhong']),
	'sogoquanzhong' => htmlspecialchars($row['sogoquanzhong']),
	'baidushoulu' => htmlspecialchars($row['baidushoulu']),
	'guanjianci' => htmlspecialchars($row['guanjianci']),
	'jieshao' => htmlspecialchars($row['jieshao']),
	'sanshoulu' => htmlspecialchars($row['sanshoulu']),
	'ico' => htmlspecialchars($row['ico']),      
	);
	$content = '<br>';
	$content .= '<div class="daohang"><div class="zuobian"><img class="jianluetu" src="https://mini.s-shot.ru/?'.$logData['yuming'].'"><span class="fangwen"><a class="ljfw" rel="external nofollow" title="'.$logData['biaoti'].'" href="http://'.$logData['yuming'].'" target="_blank">立即访问</a><a class="lxzz" rel="external nofollow" title="联系站长" href="http://wpa.qq.com/msgrd?v=3&uin='.$logData['zhanQQ'].'&site=qq&menu=yes" target="_blank">联系站长</a></span></div><div class="youbian"><h3><span>'.$logData['biaoti'].'<img src="https://www.vc99.cn/get.php?url='.$logData['yuming'].'"></span></h3><ul class="dhlb"><li><span>网站域名：</span><a>'.$logData['yuming'].'</a></li><li><span>收录时间：</span><a>'.$logData['shijian'].'</a></li><li><span>站长QQ：</span><a>'.$logData['zhanQQ'].'</a></li><li><span>百度收录：</span><a>'.$logData['baidushoulu'].'</a></li><li><span>搜狗收录：</span><a>'.$logData['sogoshoulu'].'</a></li><li><span>360收录：</span><a>'.$logData['sanshoulu'].'</a></li><li><span>编辑人员：</span><a>管理员</a></li><li><span>网站语言：</span><a>简体中文</a></li><li class="djl"><script type="text/javascript"> if (localStorage.pagecount) { localStorage.pagecount=Number(localStorage.pagecount) +1; }else{ localStorage.pagecount=1; } document.write("本站总点击：" + localStorage.pagecount); </script></li><li><span>百度权重：</span><img src="'.BLOG_URL.'content/plugins/daohang/img/bai'.$logData['baiduquanzhong'].'.png"</li><li><span>搜狗权重：</span><img src="'.BLOG_URL.'content/plugins/daohang/img/so'.$logData['sogoquanzhong'].'.png"</li><li><span>360权重：</span><img style="width: 55px; height: 22px;" src="'.BLOG_URL.'content/plugins/daohang/img/360'.$logData['sanquanzhong'].'.png"</li></div></div> <div class="wzxx"><div class="wzgjc"><h3>网站关键词：</h3><p>'.$logData['guanjianci'].'</p></div><div class="wzjs"><h3>网站介绍：</h3><p>'.$logData['jieshao'].'</p></div></div>';
	if($logData['start']=='y'){
		echo $content;
	}else{
		echo '';
	}
}


addAction('down_log', 'show_down');
