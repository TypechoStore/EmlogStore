<?php
if(!defined('EMLOG_ROOT')) {exit('error!');}
function callback_init(){
    $db = Database::getInstance();
    $db->query("CREATE TABLE IF NOT EXISTS `".DB_PREFIX."daohang` (
        `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
        `logid` int(10) unsigned NOT NULL,
        `start` enum('n','y') NOT NULL DEFAULT 'n',
        `biaoti` varchar(255) NOT NULL,
        `tupian` varchar(150) NOT NULL,
        `shijian` varchar(150) NOT NULL,
        `sogoshoulu` varchar(150) NOT NULL,
        `zhanQQ` varchar(150) NOT NULL,
        `yuming` varchar(150) NOT NULL,
        `wangzhi` varchar(150) NOT NULL,
        `baiduquanzhong` varchar(150) NOT NULL,
        `sanquanzhong` varchar(150) NOT NULL,
        `sogoquanzhong` varchar(150) NOT NULL,
        `baidushoulu` varchar(150) NOT NULL,
        `guanjianci` varchar(150) NOT NULL,
        `jieshao` varchar(150) NOT NULL,
        `bianjirenyuan` varchar(150) NOT NULL,
        `sanshoulu` varchar(150) NOT NULL,
        `ico` varchar(150) NOT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;");
}