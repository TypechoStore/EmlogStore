<?php defined('EMLOG_ROOT') or die('本页面禁止直接访问!');
define('EM_STATIC_BLOG_PATH', EMLOG_ROOT);
define('EM_STATIC_CONFIG_FILE', EM_STATIC_ROOT.'/em_static_config.php');
define('EM_STATIC_TAG_CACHE_FILE', EM_STATIC_ROOT.'/em_static_tag_cache.php');
define('EM_STATIC_CONFIG_DATA_FILE', EM_STATIC_ROOT.'/em_static_data.php');