<?php
/*
Plugin Name: 晗枫下载插件
Version: 1.2
Plugin URL: http://www.woaif.cn
Description: <font color=blue>晗枫下载插件</font>，PS：已支持Emlog6.1.1。
Author: 晗枫
Author URL: http://www.woaif.cn
*/
!defined('EMLOG_ROOT') && exit('access deined!');
?>
<?php function Fengdown_setting(){ ?>
<?php if(Option::EMLOG_VERSION >= '6.1.1'){ ?>
<script>
$(document).ready(function(){
	$("#HFbox #CR").click(function(){
		if(typeof($('#markdownEditor_content').val())!='undefined'){
			$('#markdownEditor_content').val($('#markdownEditor_content').val()+"<div class=\"Fengdown_tit\"><i class=\"ico\"></i>下载地址&nbsp;"+($('#MM').val())+"</div><span onclick=\"window.open('"+($('#DZ').val())+"');\" class=\"Fengdown\"><i class=\"ico\"></i><i class=\"line\"></i>"+($('#LY').val())+"</span>&nbsp;");
		}else if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
			layedit.setContent(contentLayUIEditor,"<div class=\"Fengdown_tit\"><i class=\"ico\"></i>下载地址&nbsp;"+($('#MM').val())+"</div><span onclick=\"window.open('"+($('#DZ').val())+"');\" class=\"Fengdown\"><i class=\"ico\"></i><i class=\"line\"></i>"+($('#LY').val())+"</span>&nbsp;",true);
		}
	});
	$("#HFbox #CR1").click(function(){
		if(typeof($('#markdownEditor_content').val())!='undefined'){
			$('#markdownEditor_content').val($('#markdownEditor_content').val()+"<div class=\"Fengdown_tit\"><i class=\"ico\"></i>下载地址&nbsp;"+($('#MM').val())+"</div><span onclick=\"window.open('"+($('#DZ').val())+"');\" class=\"Fengdown\"><i class=\"ico\"></i><i class=\"line\"></i>"+($('#LY').val())+"</span>&nbsp;");
		}else if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
			layedit.setContent(contentLayUIEditor,"<div class=\"Fengdown_tit\"><i class=\"ico\"></i>下载地址&nbsp;"+($('#MM').val())+"</div><span onclick=\"window.open('"+($('#DZ').val())+"');\" class=\"Fengdown\"><i class=\"ico\"></i><i class=\"line\"></i>"+($('#LY').val())+"</span>&nbsp;",true);
		}
	});
	$("#GB").click(function(){$("#hf_con").slideUp(200);});
	$("#hf_title").click(function(){$("#hf_con").toggle();});
	$("#QC").click(function(){$("#hf_con input").attr("value","");});
});</script>
<style>#hf_con{z-index:999;margin:18px auto 10px;display:none;border:1px solid #ccc;padding:10px;width:450px;top: 70px;left:0px;right:0px; position:absolute;background-color:#fff;}#hf_con p{margin:0 0 10px 0;font-size:14px;}#hf_con input{width:210px;height:25px;font-size:12px;padding:5px;outline:none;border:1px solid #ccc;}#hf_con input:-webkit-autofill{background:#fff;}#hf_con #DZ{width: 83.6%;}#hf_con .MM{float: right;margin-left:10px;}#hf_con .MM input{width:100px;height:25px;font-size:12px;padding:1px;outline:none;border: 1px solid #ccc;}#hf_con select{padding:1px;outline:none;border:1px solid #ccc;}input:focus,select:focus{border-color:#66afe9;outline:0;-webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);background:#fff;}#hf_con .down span{width:20%;}</style>
<div class="uploads layui-btn layui-btn-primary layui-btn-xs" id="hf_title" title="点击打开或关闭功能界面">插入下载样式</div><div id="hf_con"><div id="HFbox"><!--<p>下载来源：<input name="LY" id="LY" value="蓝奏网盘" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例如：蓝奏网盘</b></p>-->
<p><select name="LY" id="LY"><option value="蓝奏网盘">蓝奏网盘</option><option value="百度网盘">百度网盘</option><option value="其它地址">其它地址</option><option value="本地下载">本地下载</option><option value="官网下载">官网下载</option></select></p>
<p><span class=""><input name="MM" id="MM" value="" placeholder="下载密码" /></span></p>
<p><input name="DZ" id="DZ" value="" placeholder="下载地址" /></p>
<div class="down"><span id="CR" class="uploads layui-btn layui-btn-primary layui-btn-xs">首先插入</span><span id="CR1" class="uploads layui-btn layui-btn-primary layui-btn-xs">循环插入</span><span id="GB" class="uploads layui-btn layui-btn-primary layui-btn-xs">关闭工具</span><span id="QC" class="uploads layui-btn layui-btn-primary layui-btn-xs">清除内容</span><br /><span class="uploads layui-btn layui-btn-primary layui-btn-xs"><a href="http://www.emlog.net/plugin/326" target="_black">使用方法</a></span></div></div></div>
<?php }elseif(Option::EMLOG_VERSION == '6.0.1'){ ?>
<script>/* 将其代码放在tinymce的配置文件中forced_root_block:'',valid_elements:'*[*]',*/
$(document).ready(function(){
	$("#HFbox #CR").click(function(){
		$($("#editor_content_ifr").contents().find("#tinymce")).append("<div class=\"Fengdown_tit\"><i class=\"ico\"></i>下载地址&nbsp;"+($('#MM').val())+"</div><span onclick=\"window.open('"+($('#DZ').val())+"');\" class=\"Fengdown\"><i class=\"ico\"></i><i class=\"line\"></i>"+($('#LY').val())+"</span>&nbsp;");
	});
	$("#HFbox #CR1").click(function(){
		$($("#editor_content_ifr").contents().find("#tinymce")).append("<span onclick=\"window.open('"+($('#DZ').val())+"');\" class=\"Fengdown\"><i class=\"ico\"></i><i class=\"line\"></i>"+($('#LY').val())+"</span>&nbsp;");
	});
	$("#GB").click(function(){$("#hf_con").slideUp(200);});
	$("#hf_title").click(function(){$("#hf_con").toggle();});
	$("#QC").click(function(){$("#hf_con input").attr("value","");});
});</script>
<style>#hf_con{z-index:999;margin:18px auto 10px;display:none;border:1px solid #ccc;padding:10px;width:450px;top: 70px;left:0px;right:0px; position:absolute;background-color:#fff;}#hf_con p{margin:0 0 10px 0;font-size:14px;}#hf_con input{width:210px;height:25px;font-size:12px;padding:5px;outline:none;border:1px solid #ccc;}#hf_con input:-webkit-autofill{background:#fff;}#hf_con #DZ{width: 83.6%;}#hf_con .MM{float: right;margin-left:10px;}#hf_con .MM input{width:100px;height:25px;font-size:12px;padding:1px;outline:none;border: 1px solid #ccc;}#hf_con select{padding:1px;outline:none;border:1px solid #ccc;}input:focus,select:focus{border-color:#66afe9;outline:0;-webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);background:#fff;}#hf_con .down span{width:20%;}</style>
<div class="uploads btn btn-default" id="hf_title" title="点击打开或关闭功能界面">插入下载样式</div><div id="hf_con"><div id="HFbox"><!--<p>下载来源：<input name="LY" id="LY" value="蓝奏网盘" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例如：蓝奏网盘</b></p>--><p>下载来源：<select name="LY" id="LY"><option value="蓝奏网盘">蓝奏网盘</option><option value="百度网盘">百度网盘</option><option value="其它地址">其它地址</option><option value="本地下载">本地下载</option><option value="官网下载">官网下载</option></select><span class="MM">下载密码：<input name="MM" id="MM" value="" /></span></p><p>下载地址：<input name="DZ" id="DZ" value="" /></p>
<div class="down"><span id="CR" class="uploads btn btn-default">首先插入</span><span id="CR1" class="uploads btn btn-default">循环插入</span><span id="GB" class="uploads btn btn-default">关闭工具</span><span id="QC" class="uploads btn btn-default">清除内容</span><span class="uploads btn btn-default"><a href="http://www.emlog.net/plugin/326" target="_black">使用方法</a></span></div></div></div>
<?php }elseif(Option::EMLOG_VERSION <= '6.0.0'){?>
<script>
$(document).ready(function(){
	$("#HFbox #CR").click(function(){
		$($(".ke-edit-iframe:first").contents().find(".ke-content")).append("<div class=\"Fengdown_tit\"><i class=\"ico\"></i>下载地址&nbsp;"+($('#MM').val())+"</div><span onclick=\"window.open('"+($('#DZ').val())+"');\" class=\"Fengdown\"><i class=\"ico\"></i><i class=\"line\"></i>"+($('#LY').val())+"</span>&nbsp;");
	});
	$("#HFbox #CR1").click(function(){
		$($(".ke-edit-iframe:first").contents().find(".ke-content")).append("<span onclick=\"window.open('"+($('#DZ').val())+"');\" class=\"Fengdown\"><i class=\"ico\"></i><i class=\"line\"></i>"+($('#LY').val())+"</span>&nbsp;");
	});
	$("#GB").click(function(){$("#hf_con").slideUp(200);}); $("#hf_title").click(function(){$("#hf_con").toggle();}); $("#QC").click(function(){$("#hf_con input").attr("value","");});
});
</script>
<style>#hf_box{font-weight:bold; font-family:Arial;font-size:12px;margin:5px 0; cursor:pointer;clear:both; position:relative}#hf_box #hf_title{background:#5bc0de;float:left;padding:5px 10px;margin-bottom:5px;float:left;clear:both;color:#fff;border-radius:4px;font-weight:normal;font-family:"Microsoft Yahei";font-size:14px;background-image: linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-size: 30px 30px;box-shadow: 0 0 4px 1px rgba(16, 160, 249, 0.3);}#hf_box #hf_title:hover{background-color:#00aff0;}#hf_box #hf_con{clear:both;float:left;font-weight:normal;margin:5px auto 10px;display:none;border: 1px solid #ccc;padding: 10px;width:450px;border-radius:4px;top: 70px;left:0px;right:0px; position:absolute;background-color:#fff;}#hf_box #hf_con p{margin:0 0 10px 0;font-size:14px;}#hf_box #hf_con input{width:210px;font-size:12px;padding:5px;border-radius:4px;outline:none;border: 1px solid #ccc;}#hf_box #hf_con input:-webkit-autofill{background:#fff;}#hf_box #hf_con span{float:left;cursor:pointer;border:0;padding:10px 15px;font-size: 12px;margin: 0 10px 0 0;border-radius:4px;color:#fff;background-image: linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-size: 30px 30px;box-shadow: 0 0 4px 1px rgba(16, 160, 249, 0.3);}#hf_box #hf_con span:hover{background:#00aff0 !important;color:#fff !important;}#hf_box #hf_con #crfj{background:#9c3;color:#fff;}#hf_box #hf_con select{padding:5px;border-radius:4px;outline:none;border: 1px solid #ccc;}input:focus,select:focus{border-color:#66afe9;outline:0;-webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);background:#fff;}</style>
<div class="clear"></div><div id="hf_box"><div id="hf_title" title="点击打开或关闭功能界面">插入下载样式</div> <div id="hf_con"><div id="HFbox"><!--<p>下载来源：<input name="LY" id="LY" value="蓝奏网盘" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例如：蓝奏网盘</b></p>--><p>下载来源：<select name="LY" id="LY"><option value="蓝奏网盘">蓝奏网盘</option><option value="百度网盘">百度网盘</option><option value="其它地址">其它地址</option><option value="本地下载">本地下载</option><option value="官网下载">官网下载</option>&nbsp;&nbsp;&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">选择网盘类型将调用对应的名字</b></select></p><p>下载地址：<input name="DZ" id="DZ" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例子：http://qq.com</b></p><p>下载密码：<input name="MM" id="MM" value="" />&nbsp;&nbsp;<b style="color:#ccc;font-weight:normal">例子：下载密码：1234</b></p><p>使用方法：</p><p>1、下载来源、下载地址、下载密码选择好以后先点击【首先插入】</p><p>2、更多资源下载来源请将前面三项设置好以后再点击【循环插入】</p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;切记，先点击【首先插入】再点击【循环插入】</p><p style="margin: 10px 0 0 70px;"><span id="CR" style="background-color:#337ab7;">首先插入</span><span id="CR1" style="background-color:#337ab7;">循环插入</span><span id="GB" style="background-color:#5cb85c">关闭工具</span><span id="QC" style="background-color:#f0ad4e">清除内容</span></p></div></div></div><div class="clear"></div>
<?php }}
addAction('adm_writelog_head', 'Fengdown_setting');
function Fengdown_css(){?>
<style>
div.Fengdown_tit{border-top:1px solid #ccc;margin:10px 0 5px;padding-top:10px;}
div.Fengdown_tit .ico{display:inline-block;margin-right:5px;width:15px;height:15px;background: url(<?php echo BLOG_URL;?>content/plugins/Fengdown/ico.png) no-repeat;background-position: 0 -36px;vertical-align:-2px;}
span.Fengdown{position:relative;z-index:1;display:inline-block;height:37px;line-height:37px;padding:0 20px 0 50px;margin:10px 10px 10px 0;border:1px solid #d7d7d7;border-width:1px 1px 4px;font-size:14px;font-weight:700;color:#0b588c; text-decoration:none;transition:none;border-radius:2px;cursor:pointer}
span.Fengdown:hover{background-color:#0b588c;border-color:#0b588c #0b588c #0b4972;color:#fff;}
span.Fengdown .ico{position:absolute;z-index:2;left:11px;top:14.5px;width:12px;height:8px;font-size:0;display:inline-block;margin-right:5px;background: url(<?php echo BLOG_URL;?>content/plugins/Fengdown/ico.png) no-repeat;background-position:-63px -166px;}
span.Fengdown:hover .ico{background-position:-80px -166px;}
span.Fengdown .line{position:absolute;z-index:2;left:32px;top:0;height:37px;width:1px;background-color:#d7d7d7;}
</style>
<?php }
addAction('index_footer', 'Fengdown_css');
?>