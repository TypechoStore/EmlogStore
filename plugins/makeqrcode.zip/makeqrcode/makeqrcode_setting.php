<?php
!defined('EMLOG_ROOT') && exit('access deined!');
include 'phpqrcode.php';

function plugin_setting_view(){}

$qrcode='qrcode.png';

$address=$_POST['address'];

if(isset($address)){
	QRcode::png($address, '../'.$qrcode, 'L', 6, 2);
}
?>
<style type="text/css">
.board{width:500px; padding:50px; line-height:30px;}
</style>

<div class="board">
	生成二维码：<br/>
	<form method="post">
	网址:<input type="text" name="address" value='' /><br/>
	<input type="submit" value='生成' />
	</form>
	<?php if(file_exists('../'.$qrcode)){?>
	<img src="<?php echo BLOG_URL.$qrcode;?>"><br />
	可使用doAction('qrcode_ext');自定义二维码显示的位置
	<?php
	}
	?>
</div>