<?php
/**
 * Plugin Name: live2d_L
 * Version: 1.0
 * Plugin URL: http://www.ianiu.cn
 * Description: 看板两兄妹，萌萌哒。233
 * Author: 瑾忆 
 * Author Email: 837233287@qq.com
 * Author URL: https://www.ianiu.cn
 */
!defined('EMLOG_ROOT') && exit('access deined!');
function live2d(){
	require_once 'live2d_L_config.php';
?>
<script type="text/javascript" src="<?php echo BLOG_URL;?>content/plugins/live2d_L/js/live2d.js"></script>
<style>
.live2d{position:fixed;bottom:0;left:0;z-index:10000;width:150px;height:300px;font-size:0;transition:all .3s ease-in-out;user-select:none;}
</style>
<canvas id="live2d" width="200" height="400" class="live2d"></canvas>
<script type="text/javascript">
    loadlive2d("live2d", "<?php echo BLOG_URL;?>content/plugins/live2d_L/model/<?php echo $live2d_xb;?>/<?php echo $live2d_xb;?>.model.json");
</script>
<?php }; 
function live2d_menu() { echo '<li><a href="./plugin.php?plugin=live2d_L">Live2d</a></li>';}
addAction('index_footer', 'live2d');
addAction('adm_sidebar_ext', 'live2d_menu');