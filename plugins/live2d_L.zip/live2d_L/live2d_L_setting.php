<?php
!defined('EMLOG_ROOT') && exit('access deined!');
function plugin_setting_view(){
	require_once 'live2d_L_config.php';
if(isset($_GET['setting'])){
	echo '<div class="actived alert alert-success alert-dismissable" style="">设置保存成功</div>';
} ?>

<div class="panel panel-default">
<div class="panel-heading">Live2d</div>
    <div class="panel-body"> 
	<form action="plugin.php?plugin=live2d_L&action=setting" method="post">
<div class="form-inline">
<input type="radio" name="live2d_xb" value="haruto" <?php if($live2d_xb == "haruto") echo 'checked'; ?> />
<label>Boy</label>
</div>
<div class="form-inline">
<input type="radio" name="live2d_xb" value="koharu" <?php if($live2d_xb == "koharu") echo 'checked'; ?> />
<label>Girl</label>
</div>
<div class="form-group"><input type="submit" name="submit" class="btn btn-success" value="保存" /></div>
	</form>
	</div>
</div>

<?php }
function plugin_setting(){
	$newConfig = "<?php
    \$live2d_xb = '".$_POST["live2d_xb"]."';
	?>";
	@file_put_contents(EMLOG_ROOT.'/content/plugins/live2d_L/live2d_L_config.php', $newConfig);
}
?>