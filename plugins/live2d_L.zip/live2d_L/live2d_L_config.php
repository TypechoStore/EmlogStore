<?php
    $live2d_xb = 'koharu';
	?>