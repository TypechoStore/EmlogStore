<?php
/**
 * Plugin Name: EMLOG 微博同步插件
 * Version: Beta
 * Plugin URL: http://blog.gouji.org/?post=278
 * Description: EMLOG 新浪微博同步插件，测试信息反馈地址 http://bbs.emlog.net/thread-37184-1-1.html
 * Author: 简爱
 * Author Email: sc.419@qq.com
 * Author URL: http://blog.gouji.org/
 * Date: 20140822
***/

!defined('EMLOG_ROOT') && exit('Fuck you !');


define("WEIBO_SYNC_ROOT", dirname(__FILE__));
define("WEIBO_SYNC_VERSION", 0.1);
define("WEIBO_SYNC_URL", BLOG_URL . 'content/plugins/weibo-sync/');
define("WEIBO_SYNC_CALLBACK", 'http://gouji.org/api/weibo-sync/?sync=sina&type=access_token&url='. urlencode(BLOG_URL .'?plugin=weib-sync'));

require_once WEIBO_SYNC_ROOT . '/lib/class.weibo.php';
require_once WEIBO_SYNC_ROOT . '/lib/weibo-sync_view.php';

file_exists(WEIBO_SYNC_ROOT . '/test.php') && require_once WEIBO_SYNC_ROOT . '/test.php';
file_exists(WEIBO_SYNC_ROOT . '/weibo-list.php') && require_once WEIBO_SYNC_ROOT . '/weibo-list.php';

define("WEIBO_SYNC_CONFIG", WEIBO_SYNC_ROOT ."/config.php");

if(file_exists(WEIBO_SYNC_CONFIG)) require_once(WEIBO_SYNC_CONFIG);


$GLOBALS['WEIBO_SYNC']['sina']['ip'] = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';

weibo::init(array('token' => $GLOBALS['WEIBO_SYNC']['sina']['access_token'],));


addAction('save_log', 'weibo_sync_put');
addAction('post_twitter', 'weibo_sync_put');

weibo_sync_callback();




function weibo_sync_put($a, $b=false){
  extract($GLOBALS['WEIBO_SYNC']['config']['sync']);
  if(!weibo_sync_sina_is_true()) return false;
  if($b){
    if($tw != 'y') return false;
    $text = $a;
    $link = BLOG_URL;
  }else{
    if($log != 'y') return false;
    global $title, $ishide, $action, $content;
    if($ishide == 'y' || ($action == 'autosave' && $ishide == 'n') || $action == 'edit')
      return false;
    $text = "$title | $content";
    $link = Url::log($a);
  }
  if($url == 'y'){
    $text = extractHtmlData($text, 136 - strlen($link) / 2) . " $link";
  }else{
    $text = extractHtmlData($text, 136);
  }
  $result = weibo::add($text);
}


function weibo_sync_config($a){
  file_put_contents(WEIBO_SYNC_CONFIG, "<?php\r\n# weibo-sync_setting.php\r\n\r\n\$GLOBALS['WEIBO_SYNC'] = ". var_export($a, true). ";");
}

function weibo_sync_sina_is_true(){
  if(time() > $GLOBALS['WEIBO_SYNC']['sina']['expire_at']) return false;
  return true;
}

function weibo_sync_tips($msg='',$s=3){
  /* 阉割 */
  return '';
}

function weibo_sync_callback(){
  if(!isset($_GET['sync']['expires_in']) || ROLE != ROLE_ADMIN) return;
  $token_info = $_GET['sync'];
  weibo::init(array('token'=>$_GET['sync']['access_token']));
  $user_info = weibo::user_info($token_info['uid']);

  global $CACHE;
  $U = $CACHE->readCache('user');

  $token_info['avatar']      = $U[UID]['avatar'];
  $token_info['location']    = "土星";
  $token_info['screen_name'] = $U[UID]['name'];
  $token_info['description'] = $U[UID]['des'] ."  /* 阉割版获取 EMLOG 信息 */";
  $token_info['expire_at']   = time() + $token_info['expires_in'] - 300;
  $GLOBALS['WEIBO_SYNC']['sina'] = $token_info;

  weibo_sync_config($GLOBALS['WEIBO_SYNC']);
  echo "<script>self.opener.location = '".
       BLOG_URL .'admin/plugin.php?plugin=weibo-sync'. weibo_sync_tips('登录授权成功 !',5) ."';window.close();</script>";
  die;
}

