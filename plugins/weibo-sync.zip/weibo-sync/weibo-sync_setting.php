<?php
# weibo-sync_setting.php

!defined('WEIBO_SYNC_ROOT') && exit('Fuck you !');

function plugin_setting_view(){
  $msg = '';
  if(isset($_GET['type']) && $_GET['type'] == 'logout'){
    weibo::logout(); unset($GLOBALS['WEIBO_SYNC']['sina']);
    $msg = '已成功注销登录';
  }elseif(isset($_POST['weibo_sync_form_on'])){
    $GLOBALS['WEIBO_SYNC']['config']['sync']['log'] = isset($_POST['weibo_sync_log']) ? $_POST['weibo_sync_log'] : 'n';
    $GLOBALS['WEIBO_SYNC']['config']['sync']['tw'] = isset($_POST['weibo_sync_tw']) ? $_POST['weibo_sync_tw'] : 'n';
    $GLOBALS['WEIBO_SYNC']['config']['sync']['url'] = isset($_POST['weibo_sync_url']) ? $_POST['weibo_sync_url'] : 'n';
    $GLOBALS['WEIBO_SYNC']['config']['sync']['url_preg'] = isset($_POST['weibo_sync_url_p']) ? $_POST['weibo_sync_url_p'] : 'n';
    $msg = '配置已保存';
  }else{
    weibo_sync_view();
    return;
  }
  weibo_sync_config($GLOBALS['WEIBO_SYNC']);
  weibo::go(BLOG_URL .'admin/plugin.php?plugin=weibo-sync'.weibo_sync_tips($msg)); die;
}

