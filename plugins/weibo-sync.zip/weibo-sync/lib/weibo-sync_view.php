<?php
# lib/weibo-sync_view.php
!defined('WEIBO_SYNC_ROOT') && exit('Fuck you !');

function weibo_sync_view(){
  extract($GLOBALS['WEIBO_SYNC']['sina']);
  $expire_at_date = date("Y-m-d H:i:s", $expire_at);

 $title='获取授权'; $img=''; $info=''; $logout='';
 if(weibo_sync_sina_is_true()){
    $title  = '重新登录';
    $img    = 'r';
    $info   = "当前用户: [$screen_name]<br>uid: $uid<br>有效期至: $expire_at_date";
    $logout = '<a href="'. BLOG_URL .'login/plugin.php?plugin=weibo-sync&type=logout"><img src="' . WEIBO_SYNC_URL . '/icon/240o.png" alt="'. $title .'" style="margin-right:5px;" /></a>';
  }

  $Button = '<a href="javascript:;" onclick=\'window.open("' . WEIBO_SYNC_CALLBACK . '", "SinaWeiboLogin","width=740,height=540,menubar=0,scrollbars=1, resizable=1,status=1,titlebar=0,toolbar=0,location=1");return false;\' style="font-size: 30px;" title="'. $title .'"><img src="' . WEIBO_SYNC_URL . '/icon/240'. $img .'.png" alt="'. $title .'" style="margin-right:5px;" /></a>';
  ?>
  <style>code{font-style:normal;font-weight:500;background-color:#F7F7F9;border:1px solid #E1E1E8;color:#DD1144;padding:2px 4px;border-radius:2px;font-family:Monaco,Consolas,Courier;font-size:12px}.oll li{list-style-type:decimal}</style>
  <div class="containertitle"><b>微博同步</b><?php echo (isset($_GET['weibo_sync_msg']) ? '<span class="actived">'. $_GET['weibo_sync_msg'] .'</span>' : ''); ?><div id="msg"></div>
  </div>
  <div class="line"></div>
  <?php if(function_exists('weibo_sync_test')) weibo_sync_test(); ?>
  <div style="margin-top:10px;"><?php weibo_sync_view_form(); ?></div>
  <div style="margin-top:10px;">
    欢迎 购买 微博同步插件正式版<br>
    正事版支持功能<br>
    <ol class="oll">
    	<li>同步 文章、 碎语 至 新浪微博 （后台可设置 是否 追加网址）</li>
    	<li>可以添加侧边栏 显示 新浪微博 以及 用户信息</li>
    	<li>PHP 调用 对于喜欢折腾的人 提供 EMLOG 钩子 <code>&lt;?php doAction('weibo-list-li', 10); ?&gt;</code> 获取 微博 &lt;li&gt; 列表不够折腾 还有 PHP 函数 <code>weibo_sync_getList</code> 获取缓存内容</li>
    	<li>JS 缓存，不止PHP ，JS 也有缓存 这个期待你的自己发现</li>
    	<li>同步 带图片的 文章、碎语  到新浪微博 (<code>该功能已测试完毕！</code> 开启前 请确认 已经申请 新浪 高级 API <code>upload_url_text</code>)</li>
    	<li>本插件 默认使用 作者 API ，如自己有申请 新浪 API 请后台 添加即可<code>使用值得 API 同步微博 将没有 来自 “简爱Blog” 字样</code></li>
    </ol>
    <br>
  
  </div>
  <div class="line"></div>
  <?php if(weibo_sync_sina_is_true()): ?>
  <div class="containertitle"><b>账户信息</b></div>
  <table id="adm_plugin_list" class="item_list">
    <thead>
      <tr width="400px">
        <th class="tdcenter" style="padding:5px;" width="100px"><img align="left" src="<?php echo BLOG_URL.$avatar; ?>" /></th>
        <th width="300px"><?php echo $location .'<br>'. $description; ?></th>
      </tr>
      <tr width="400px">
        <th class="tdcenter" width="100px">当前用户</th>
        <th width="300px"><?php echo $screen_name; ?></th>
      </tr>
      <tr>
        <th class="tdcenter">UID</th>
        <th><?php echo $uid; ?></th>
      </tr>
      <tr>
        <th class="tdcenter">有效期至</th>
        <th><?php echo $expire_at_date; ?></th>
      </tr>
      <tr>
        <th class="tdcenter">ACCESS TOKEN</th>
        <th><?php echo $access_token; ?></th>
      </tr>
    </thead>
  </table>
  <?php endif; ?>
  <div style="margin-top:10px;"><?php echo $Button ."  &nbsp; ". $logout; ?></div>
  <div class="line"></div>
  <div class="page"><?php echo '微博同步插件 v'. WEIBO_SYNC_VERSION .' <a title="简爱 的个人博客" href="http://blog.gouji.org" target="_blank">简爱</a> <a  title="插件页面" href="http://blog.gouji.org/?post=278" target="_blank">检测更新</a>'; ?></div>
  <script>$("#weibo_sync").addClass('sidebarsubmenu1');</script>
  <?php
}

function weibo_sync_view_form(){
  $log_ = $tw_ = $url_ = $url_p = ' checked="checked"';
  isset($GLOBALS['WEIBO_SYNC']['config']['sync']) && extract($GLOBALS['WEIBO_SYNC']['config']['sync']);
  if($log != 'y') $log_ = '';
  if($tw  != 'y') $tw_ = '';
  if($url != 'y') $url_ = '';
  if($url_preg != 'y') $url_p = '';
  echo '
  <div class="containertitle"><b>
  同步开关</b>
  <form action="'. BLOG_URL .'login/plugin.php?plugin=weibo-sync" method="post">
    <input value="y" name="weibo_sync_log" id="weibo_sync_log" type="checkbox"'. $log_ .'>
    <label for="weibo_sync_log"> 日志同步</label>
    <br>
    <input value="y" name="weibo_sync_tw" id="weibo_sync_tw" type="checkbox"'. $tw_ .'>
    <label for="weibo_sync_tw"> 碎语同步</label>
    <br>
    <input value="y" name="weibo_sync_url" id="weibo_sync_url" type="checkbox"'. $url_ .'>
    <label for="weibo_sync_url"> 追加网址</label>
    <!-- sina 自动转换 短链接 此选项 作废
    <br>
    <input value="y" name="weibo_sync_url_p" id="weibo_sync_url_p" type="checkbox"'. $url_p .'>
    <label for="weibo_sync_url_p"> 是否转换短网址</label>
    -->
    <br>
    <input value="y" name="weibo_sync_form_on" id="weibo_sync_form_on" type="hidden">
    <input value="保存设置" class="button" type="submit">
  </form>
  </div>
  <div class="line"></div>'.(isset($_GET['weibo_sync_msg']) ? '<script>setTimeout(hideActived,'. $_GET['sleep'] .');</script>' : '');
}

function weibo_sync_menu() {
  echo '<div class="sidebarsubmenu" id="weibo_sync"><a title="微博同步" href="./plugin.php?plugin=weibo-sync"><img src="' . WEIBO_SYNC_URL . '/icon/16x16.png" alt="微博同步" style="margin-right:5px;" /> 微博同步</a></div>';
}

addAction('adm_sidebar_ext', 'weibo_sync_menu');