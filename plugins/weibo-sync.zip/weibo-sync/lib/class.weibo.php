<?php
# lib/class.weibo.php

class weibo {
  static private $DATA = array();
  static private $URL   = array(
    'txt' => 'https://api.weibo.com/2/statuses/update.json',
    'user_info' => 'https://api.weibo.com/2/users/show.json',
    'logout' => 'https://api.weibo.com/oauth2/revokeoauth2',
  );

  static public function init($A){
    self::$DATA = array_merge(array('type' => 'token'), $A);
    !defined('WEIBO_SYNC_ROOT') && exit('Fuck you !');
  }

  static public function user_info($uid=false){
    return;
  }

  static public function add($arr){
    $A['status']       = $arr;
    $A['access_token'] = self::$DATA['token'];
    return self::POST('txt', $A);
  }

  static public function POST($a, $b=array()){
    $c = curl_init();
    curl_setopt($c, CURLOPT_URL, self::$URL[$a]);
    curl_setopt($c, CURLOPT_HEADER, false);
    !empty($b) && curl_setopt($c, CURLOPT_POSTFIELDS, http_build_query($b));
    curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($c, CURLOPT_SSL_VERIFYHOST, false);
    $t = curl_exec($c);
    curl_close($c);
    $Arr = json_decode($t, true);
    // function_exists("weibo_erLogs") && weibo_erLogs($Arr);
    return $Arr;
  }

  static public function logout(){
    die("<b>阉割 版不支持 此操作 !</b>");
  }

  static public function go($url){
    header("Location: $url");
  }
}