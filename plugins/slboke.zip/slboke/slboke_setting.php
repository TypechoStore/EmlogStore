<?php
!defined('EMLOG_ROOT') && exit('出错了！！！!');

function plugin_setting_view(){
require_once 'slboke_config.php';
?>
<div class="sl_slboke">
<span style=" font-size:18px; font-weight:bold;">配置文件</span><?php if(isset($_GET['setting'])){echo "<span class='actived'>设置保存成功!</span>";}?><br /><br />
<link href="<?php echo BLOG_URL;?>content/plugins/slboke/slboke.css" rel="stylesheet" type="text/css" />
<form action="plugin.php?plugin=slboke&action=setting" method="post">
<ul>
<li><h4>https访问</h4>
<div class="radio"><input type="radio" name="https" value="http:" <?php if($config["https"]=='http:'){echo 'checked="checked"';}?> /><label>未开启</label></div>
<div class="radio"><input type="radio" name="https" value="https:" <?php if($config["https"]=='https:'){echo 'checked="checked"';}?> /><label>已开启</label></div>
<p><b>网站是否开启https访问，如开启必须选择已开启，否则插件无法正常使用</b></p>
</li>

<li><h4>排列方式</h4>
<div class="radio"><input type="radio" name="px" value="date" <?php if($config["px"]=='date'){echo 'checked="checked"';}?> /><label>时间降序</label></div>
<div class="radio"><input type="radio" name="px" value="views" <?php if($config["px"]=='views'){echo 'checked="checked"';}?> /><label>浏览降序</label></div>
<div class="radio"><input type="radio" name="px" value="slzan" <?php if($config["px"]=='slzan'){echo 'checked="checked"';}?> /><label>关注降序</label></div>
<div class="radio"><input type="radio" name="px" value="rand" <?php if($config["px"]=='rand'){echo 'checked="checked"';}?> /><label>随机显示</label></div>
</li>

<li><h4>显示位置</h4>
<div class="radio"><input type="radio" name="sloff" value="no" <?php if($config["sloff"]=='no'){echo 'checked="checked"';}?> /><label>指定文章显示</label></div>
<div class="radio"><input type="radio" name="sloff" value="yes" <?php if($config["sloff"]=='yes'){echo 'checked="checked"';}?> /><label>所有文章显示</label></div>
<p><?php if($config["sloff"] == 'no'){echo '<b>请正确填写下面需要显示的文章ID</b>';}else{echo '所有文章页面将显示本排行榜';}?></p>
</li>

<li><h4>需要显示的文章ID</h4>
<div class="duo"><input type="text" class="wzid" name="wzid" value="<?php echo $config["wzid"];?>" size="1"/></div>
<div class="duo"><input type="text" class="wzid" name="wzid1" value="<?php echo $config["wzid1"];?>" size="1"/></div>
<div class="duo"><input type="text" class="wzid" name="wzid2" value="<?php echo $config["wzid2"];?>" size="1"/></div>
<div class="duo"><input type="text" class="wzid" name="wzid3" value="<?php echo $config["wzid3"];?>" size="1"/></div>
<div class="duo"><input type="text" class="wzid" name="wzid4" value="<?php echo $config["wzid4"];?>" size="1"/></div>
<p>每框仅限一个，不填写将不显示，选择所有文章显示时不比理会此项</p>
</li>

<div class="sl">
注意事项：<br />
1、文章页(echo_log.php)和页面(page.php)模板必须含有挂载点：&lt;?php doAction('log_related',$logData);?&gt;<br />
如果没有，请在文章页(echo_log.php)和页面(page.php)你想要放入的位置加入代码：&lt;?php doAction('log_related',$logData);?&gt;即可；<br /><br />
2、插件问题反馈地址(其他途径反馈将不受理)：<a href="http://www.shuyong.net/1040.html" target="_blank">http://www.shuyong.net/1040.html</a><br /></div></ul>
<input type="submit" class="button" name="submit" value="保存设置" />
</form>
</div>
<?php }?>
<?php 
function plugin_setting(){
	require_once 'slboke_config.php';
	$newConfig = '<?php
$config = array(
	"sloff" => "'.$_POST["sloff"].'",
	"wzid" => "'.$_POST["wzid"].'",
	"wzid1" => "'.$_POST["wzid1"].'",
	"wzid2" => "'.$_POST["wzid2"].'",
	"wzid3" => "'.$_POST["wzid3"].'",
	"wzid4" => "'.$_POST["wzid4"].'",
	"https" => "'.$_POST["https"].'",
	"px" => "'.$_POST["px"].'",
	"wzsl" => "'.$_POST["wzsl"].'",
);';
	echo $newConfig;
	@file_put_contents(EMLOG_ROOT.'/content/plugins/slboke/slboke_config.php', $newConfig);
}
?>