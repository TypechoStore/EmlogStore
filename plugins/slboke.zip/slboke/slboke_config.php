<?php
$config = array(
	"sloff" => "yes",
	"wzid" => "",
	"wzid1" => "",
	"wzid2" => "",
	"wzid3" => "",
	"wzid4" => "",
	"https" => "http:",
	"px" => "slzan",
	"wzsl" => "",
);