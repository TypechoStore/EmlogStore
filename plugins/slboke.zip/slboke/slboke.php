<?php
/*
Plugin Name:博客之家联盟
Version: 1.1
Plugin URL: http://www.shuyong.net/
Description:博客之家联盟
ForEmlog:5.3.x
Author: 舍力
Author URL: http://www.shuyong.net/
*/

!defined('EMLOG_ROOT') && exit('access deined!');
function slboke($logid){require_once 'slboke_config.php';
if($config["sloff"]=='yes'){//所有文章页显示
$dhurl=$config["https"].'//likinming.com';
?>
<?php if($config["px"]=='views'){?>
<script type="text/jscript" src="<?php echo $dhurl;?>/slboke/views.php"></script>
<?php }elseif($config["px"]=='rand'){?>
<script type="text/jscript" src="<?php echo $dhurl;?>/slboke/rand.php"></script>
<?php }elseif($config["px"]=='slzan'){?>
<script type="text/jscript" src="<?php echo $dhurl;?>/slboke/slzan.php"></script>
<?php }else{?>
<script type="text/jscript" src="<?php echo $dhurl;?>/slboke/date.php"></script>
<?php }?>

<?php }//指定文章显示
if($config["sloff"]=='no'){if(in_array($logid['logid'],array($config['wzid'],$config['wzid1'],$config['wzid2'],$config['wzid3'],$config['wzid4']))){
$dhurl=$config["https"].'//likinming.com';
?>
<?php if($config["px"]=='views'){?>
<script type="text/jscript" src="<?php echo $dhurl;?>/slboke/views.php"></script>
<?php }elseif($config["px"]=='rand'){?>
<script type="text/jscript" src="<?php echo $dhurl;?>/slboke/rand.php"></script>
<?php }elseif($config["px"]=='slzan'){?>
<script type="text/jscript" src="<?php echo $dhurl;?>/slboke/slzan.php"></script>
<?php }else{?>
<script type="text/jscript" src="<?php echo $dhurl;?>/slboke/date.php"></script>
<?php }?>

<?php }}}?>

<?php 
function slboke_menu(){
	echo '<div class="sidebarsubmenu"><a href="./plugin.php?plugin=slboke">博客之家联盟</a></div>';
}?>

<?php 
addAction('log_related','slboke');
addAction('adm_sidebar_ext', 'slboke_menu');
?>