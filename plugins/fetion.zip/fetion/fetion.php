<?php
/*
Plugin Name: Emlog评论飞信短信通知
Version: 1.2
Plugin URL: http://foxzld.com
Description: Emlog评论飞信短信通知
Author: 孤独的北极狐
Author Email: admin@foxzld.com
Author URL: http://foxzld.com
*/

!defined('EMLOG_ROOT') && exit('access deined!');
function fetion()
{
require_once(EMLOG_ROOT.'/content/plugins/fetion/PHPFetion.php');
require_once(EMLOG_ROOT.'/content/plugins/fetion/fetion_config.php');
$comname = isset($_POST['comname']) ? addslashes(trim($_POST['comname'])) : '';
$comment = $_POST['comment'];
$gid =$_POST['gid'];
$pid = $_POST['pid'];
$blogname = Option::get('blogname');
$Log_Model = new Log_Model();
$logData = $Log_Model->getOneLogForHome($gid);
$log_title = $logData['log_title'];
$fetion_sms='〖'.$comname.'〗评论了您的文章《'.$log_title.'》：'.$comment;
file_put_contents(EMLOG_ROOT.'/content/plugins/fetion/a.txt',$fetion_sms);
$fetion = new PHPFetion($fetion_me,$fetion_pw);// 手机号、飞信密码
$fetion->send($fetion_me,file_get_contents(EMLOG_ROOT.'/content/plugins/fetion/a.txt'));// 接收人手机号、飞信内容
}
addAction('comment_saved', 'fetion');
function fetion_menu()
{
	echo '<div class="sidebarsubmenu" id="fetion"><a href="./plugin.php?plugin=fetion">评论飞信通知</a></div>';
}
addAction('adm_sidebar_ext', 'fetion_menu');
?>