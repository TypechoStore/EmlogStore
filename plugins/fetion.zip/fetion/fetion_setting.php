﻿<?php
/*
Plugin Name: Emlog评论飞信短信通知
Version: 1.2
Plugin URL:
Description:Emlog评论飞信短信通知
Author: 孤独的北极狐
Author Email: admin@foxzld.com
Author QQ:876696862
Author URL: http://foxzld.com
*/

!defined('EMLOG_ROOT') && exit('error!');
function plugin_setting_view()
{
echo '<div class=containertitle><b>飞信通知插件设置</b>';
If(isset($_GET['setting']))
{
echo '<span class="actived">评论飞信通知插件设置完成</span>';
}
echo '</div><div class=line></div>';
echo '<form action="plugin.php?plugin=fetion&action=setting" method="post">';
echo '你的手机号：<input type="text" name="me"><p>
飞信的密码：<input type="text" name="pw"><p>
<input type="submit" value="保存" name="submit">
</form>';
echo '
<p>特别说明：</p>
<p>本插件是在飞信的基础是实现的，所以想要使用本插件请先开通飞信<br>
<B>开通方式</B> :
自己查询，关我鸟事<br>
';
echo '<p><font color="red" size="+1">本系统不检查飞信密码正确性，密码错误将导致无法发送短信</font>';
}
function plugin_setting()
{
$fetion_post_me=$_POST['me'];
$fetion_post_pw=$_POST['pw'];
echo $fetion_post_me;
$fetion_config='
<?php
$fetion_me="'.$fetion_post_me.'";
$fetion_pw="'.$fetion_post_pw.'";
?>';
@file_put_contents(EMLOG_ROOT.'/content/plugins/fetion/fetion_config.php',$fetion_config);
}
?>