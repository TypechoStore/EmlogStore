<?php
$tietuku_config = array(
	"accesskey" => "48763af4cdb15893afdb1e5a8c378f06280",
	"secretkey" => "5065352811dc61f8c6167baf6ec8db19d5ae",
	"album" => "1679624",
	"r_url" => "2",
	"wailian" => "1",
);