<?php
define('THEMESEDITOR_CTHEME','default');
define('THEMESEDITOR_CFILE','header.php');
define('CODEMIRROR_THEME','ambiance');
define('THEMESEDITOR_EDITOR_THEMES',"ambiance,blackboard,cobalt,eclipse,elegant,erlang-dark,lesser-dark,monokai,neat,night,rubyblue,twilight,vibrant-ink,xq-dark");
