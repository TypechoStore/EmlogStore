/* by 蓝叶 lanyes.org */
$(document).ready(function(){
$('.ke-toolbar span[data-name="about"]').before('<span class="ke-outline" title="百度音乐视频播放器" id="open_lanyebdplayer"><span class="ke-toolbar-icon" style="background:url(../../content/plugins/lanyebdplayer/play.png) no-repeat;width:16px;height:16px;"></span></span>').hide();
$('#open_lanyebdplayer').click(function(){
$('.lanyebdplayer').fadeIn();});
$("#cyplay_in").click(function(){
	if(typeof(contentLayUIEditor)!='undefined'&&typeof(layedit)!='undefined'){
		layedit.setContent(contentLayUIEditor,layedit.getContent(contentLayUIEditor)+"<p id='cyplayercontainer' cywidth='"+($('.lanyebdplayer input[name="play_width"]').val())+"' cyheight='"+($('.lanyebdplayer input[name="play_height"]').val())+"' cyauto='"+($('.lanyebdplayer select[name="play_auto"]').val())+"' cyrepeat='"+($('.lanyebdplayer select[name="play_repeat"]').val())+"' cytype='"+($('.lanyebdplayer select[name="play_type"]').val())+"' cyurl='"+($('.lanyebdplayer input[name="play_url"]').val())+"' cyimg='"+($('.lanyebdplayer input[name="play_img"]').val())+"'>百度音乐视频播放器</p><br />",false);
	}else{
		$($(".ke-edit-iframe:first").contents().find(".ke-content")).append("<p id='cyplayercontainer' cywidth='"+($('.lanyebdplayer input[name="play_width"]').val())+"' cyheight='"+($('.lanyebdplayer input[name="play_height"]').val())+"' cyauto='"+($('.lanyebdplayer select[name="play_auto"]').val())+"' cyrepeat='"+($('.lanyebdplayer select[name="play_repeat"]').val())+"' cytype='"+($('.lanyebdplayer select[name="play_type"]').val())+"' cyurl='"+($('.lanyebdplayer input[name="play_url"]').val())+"' cyimg='"+($('.lanyebdplayer input[name="play_img"]').val())+"'>百度音乐视频播放器</p><br />");
	}
$('.lanyebdplayer').fadeOut();});
});
