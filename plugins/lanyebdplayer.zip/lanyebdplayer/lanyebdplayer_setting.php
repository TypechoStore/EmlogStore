<?php
!defined('EMLOG_ROOT') && exit('access deined!');
function plugin_setting_view(){require_once 'lanyebdplayer_config.php';?>
<link href="<?php echo BLOG_URL;?>content/plugins/lanyebdplayer/admin.css" rel="stylesheet" type="text/css" />
<div class="containertitle"><b>百度音乐视频播放器设置</b><?php if(isset($_GET['setting'])):?><span class="actived">设置成功</span><?php endif;?></div>
<div class=line></div>
<div class="bdplayer_tips"><p>此插件采用百度的音乐视频播放器制作，请到bce.baidu.com注册登陆帐号后，在右上角点击用户名称进入安全认证页面，创建Access Key，把Access Key ID填写到下方。</p>
<p>去百度申请：<a href="https://console.bce.baidu.com/iam/#/iam/accesslist" target="_blank">https://console.bce.baidu.com/iam/#/iam/accesslist</a></p>
</div>
<form action="./plugin.php?plugin=lanyebdplayer&action=setting" method="POST">
<div class="bdplayer_set_box">
 <div class="set_name">填写您的百度用户Access Key ID</div>
 <div class="set_body"><input type="text" name="bdplayer_ak" value="<?php echo $config["bdplayer_ak"];?>"></div>
</div>
<div class="bdplayer_set_box">
 <div class="set_name">设置播放器默认声音大小</div>
 <div class="set_body"><input type="text" name="bdplayer_volume" value="<?php echo $config["bdplayer_volume"];?>"></div>
</div>
<div class="bdplayer_set_box">
 <div class="set_name">设置默认预览图片</div>
 <div class="set_body"><input type="text" name="bdplayer_img" value="<?php echo $config["bdplayer_img"];?>"></div>
</div>
<div class="bdplayer_set_submit"><input type="submit" value="保存设置" /></div>
</form>
<?php
}
function plugin_setting(){
	$newConfig = '<?php
$config = array(
 "bdplayer_ak" => "'.$_POST["bdplayer_ak"].'",
 "bdplayer_volume" => "'.$_POST["bdplayer_volume"].'",
 "bdplayer_img" => "'.$_POST["bdplayer_img"].'"
);';
	@file_put_contents(EMLOG_ROOT.'/content/plugins/lanyebdplayer/lanyebdplayer_config.php', $newConfig);
}?>