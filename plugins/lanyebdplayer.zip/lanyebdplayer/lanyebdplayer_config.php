<?php
$config = array(
 "bdplayer_ak" => "95c1bdd49b3b4bdcb852dd555c925a86",
 "bdplayer_volume" => "60",
 "bdplayer_img" => "http://a.lanyes.org/bg2.jpg"
);