<?php 
if(extension_loaded('zlib') && strstr($_SERVER['HTTP_ACCEPT_ENCODING'],'gzip')){
ob_start('ob_gzhandler');header("Content-type: text/javascript"); 
}else{exit('php zlib使用失败，请确认是否已加载zlib扩展');}require_once 'lanyebdplayer_config.php';?>
if($('#cyplayercontainer').length > 0){
if($('#cyplayercontainer').attr('cyimg')==''){var cyimgurl = '<?php echo $config['bdplayer_img'];?>'}else{var cyimgurl = $('#cyplayercontainer').attr('cyimg')}
var player = cyberplayer("cyplayercontainer").setup({width: $('#cyplayercontainer').attr('cywidth'),height: $('#cyplayercontainer').attr('cyheight'),stretching: "uniform",type: $('#cyplayercontainer').attr('cytype'),image: cyimgurl,file: $('#cyplayercontainer').attr('cyurl'),autostart: $('#cyplayercontainer').attr('cyauto'),repeat: $('#cyplayercontainer').attr('cyrepeat'),volume: <?php echo $config['bdplayer_volume'];?>,controls: "over",ak: '<?php echo $config['bdplayer_ak'];?>'});}
<?php if(extension_loaded('zlib')){ob_end_flush();}?>
