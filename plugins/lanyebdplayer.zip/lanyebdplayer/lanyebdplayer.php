<?php
/*
 Plugin Name: 百度音乐视频播放器
 Version: 1.0
 Plugin URL: http://lanyes.org
 Description: 百度音乐视频播放器，使用baidu t5player播放音乐和视频。
 ForEmlog:5.3.x
 Author: 蓝叶
 Author Email: w@lanyes.org
 Author URL: http://lanyes.org
*/
!defined('EMLOG_ROOT') && exit('access deined!');
function lanyebdplayer_menu()//写入插件导航
{echo '<div class="sidebarsubmenu" id="lanyebdplayer_menu"><a href="./plugin.php?plugin=lanyebdplayer">百度播放器设置</a></div>';}
addAction('adm_sidebar_ext', 'lanyebdplayer_menu');
function lanyebdplayer_admin(){?>
<link href="<?php echo BLOG_URL;?>content/plugins/lanyebdplayer/admin.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL;?>content/plugins/lanyebdplayer/admin.js" type="text/javascript"></script>
<div><!-- class="lanyebdplayer"-->
<p><label>播放类型</label><select name="play_type"><option value="mp4">视频模式</option><option value="mp3">音乐模式</option></select></p>
<p><label>自动播放</label><select name="play_auto"><option value="true">自动播放</option><option value="false">不自动播放</option></select></p>
<p><label>循环播放</label><select name="play_repeat"><option value="true">循环播放</option><option value="false">不循环播放</option></select></p>
<p><label>宽度设置</label><input name="play_width" value="auto" placeholder="设置播放器的宽度，100%为auto" /></p>
<p><label>高度设置</label><input name="play_height" value="400" placeholder="设置播放器的高度。" /></p>
<p><label>文件地址</label><input name="play_url" value="" placeholder="填写视频或音乐的地址。" /></p>
<p><label>预览图片</label><input name="play_img" value="" placeholder="填写视频或音乐的预览图片，可留空。" /></p>
<div class="lanyebdplayer_tool"><span id="cyplay_in">插入代码</span></div>
</div>
<?php }
addAction('adm_writelog_head', 'lanyebdplayer_admin');
function lanyebdplayer_fun(){
echo '<script src="'.BLOG_URL.'content/plugins/lanyebdplayer/player/cyberplayer.js" type="text/javascript"></script>';
echo '<script src="'.BLOG_URL.'content/plugins/lanyebdplayer/lanyebdplayer_js.php" type="text/javascript"></script>';
}
addAction('index_footer', 'lanyebdplayer_fun');