<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php if (blog_tool_ishome()) {?>
<div class="container">	
				<div class="flinks">
	<ul class="xoxo blogroll">
<li>
<?php 
			global $CACHE;
			$link_cache = $CACHE->readCache('link');
			foreach($link_cache as $value): ?>
<li><a href="<?php echo $value['url']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
<?php endforeach; ?>
</li>
	</ul>
			</div>		
			</div>
<?php }?>
<footer class="footer">
	<div class="container">
				<p>&copy; 2018 <a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a> &nbsp; 
				<p><a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> &nbsp; <?php echo $footer_info; ?>
				</p>
			</div>
</footer>
<script>
window.jsui={
	www: '<?php echo BLOG_URL; ?>',
	uri: '<?php echo TEMPLATE_URL; ?>',
	ver: '<?php echo THEME_VER;?>',
	logocode: '<?php echo Option::get('login_code');?>',
	is_fix:'<?php echo $navhide;?>',
	is_pjax:'<?php echo $pjax;?>',
	iasnum:'<?php echo $down_next; ?>',
	lazyload:'<?php echo $webcompress; ?>',
};
</script>
<?php include View::getView('inc/login_user');?>
<div class="rewards-popover-mask rewards-close" style="display: none;"></div>
<div class="rewards-popover" style="display: none;">
		<h3>觉得文章有用就打赏一下文章作者</h3>
						<div class="rewards-popover-item">
			<h4>支付宝扫一扫打赏</h4>
			<img src="<?php echo TEMPLATE_URL."img/alzf.png";?>">
		</div>
										<div class="rewards-popover-item">
			<h4>微信扫一扫打赏</h4>
			<img src="<?php echo TEMPLATE_URL."img/wxzf.png";?>">
		</div>
						<div class="rewards-popover-close rewards-close">×</div>
	</div>
	<?php doAction('index_footer'); ?>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>js/libs/jquery.min.js?ver=3.0'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>js/libs/bootstrap.min.js?ver=3.0'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>js/sign.js?ver=3.0'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>js/wow.min.js?ver=3.0'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>js/loader.js?ver=3.0'></script>
<script type='text/javascript' src='<?php echo TEMPLATE_URL; ?>js/wp-embed.min.js?ver=4.9.6'></script>
</body>
</html>