<?php
				 $timedate = '2016-8-12';
				 $timehide = '1';
				 $logo_url = 'https://ws4.sinaimg.cn/large/0072Lfvtly1fsi476jo04j303t00wt8k.jpg';
				 $bg_url = 'http://0d077ef9e74d8.cdn.sohucs.com/qzRPMPA_jpg';
				 $nexqq = '1444762288';
	 			 $new_log_num = '2018</br>FYS.V2版本';
				 $web_method = '4';
				 $navhide = '2';
				 $home_text = '<h2>FYSV2emlog模板<br><strong>免费下载</strong></h2><a class="btn btn-primary" href="https://f162.cn/post/276">点击查看详情</a>';
				 $dingzhi_text = '';
				 $rmwenzhang_text = '';
				 $dingbugg = '';
				 $zhanzhanglj = 'http://wpa.qq.com/msgrd?v=3&uin=972622982&site=qq&menu=yes';
				 $zhanzhangwz = 'Fys美化模板1.9.1版本增加手机PC不同自适应';
		         $radio_zhiding = '2';
		         $boke_url = '';
				 $weixinerweima = '';
				 $suijiwenzhangqiyong = '2';
		         $heightkeycolor = '';
		         $top_title = 'FYS模板V2版本 重写版以及修复若干bug';
		         $top_titleurl = 'https://f162.cn/post/276';				 
		         $top_content = '模板介绍: FYS2.0（V2）重写UI，重新排版了所有代码与文件重写代码以及修复V1版本的多个BUG，完全脱离DUX3.0与V1版本，增加了很多功能，是小编有屎以来动工程最大的模板之一，最值得大家关注的是它居然是免费的';
				 $heightkey = '[模板更新]';
				 $home_toptext = '<ul class="site-nav topmenu">
			<li><a href="http://www.17uw.cn/"><i class="fa fa-link"></i> 会飞的鱼</a></li>
				<li class="menusns">
					<a href="javascript:;"><i class="fa fa-comments-o"></i> 联系本站 <i class="fa fa-angle-down"></i></a>
					<ul class="sub-menu">
						<li><a class="sns-wechat" href="javascript:;" title="我的微信" data-src="http://0d077ef9e74d8.cdn.sohucs.com/qzM05EE_png"><i class="fa fa-wechat"></i> 微信交谈</a></li>				
						<li><a target="_blank" rel="external nofollow" href="http://wpa.qq.com/msgrd?v=3&uin=1444762288&site=qq&menu=yes"><i class="fa fa-qq"></i> QQ联系</a></li>						<li><a target="_blank" rel="external nofollow" href="#"><i class="fa fa-tencent-weibo"></i> 腾讯微博</a></li>																		<li><a target="_blank" href="#"><i class="fa fa-weibo"></i> 微博</a></li>					</ul>
				</li>
			</ul>';				 
				 $ppt_zhiding= '2';	
                 $Sorts= '1';
				 $cbads= '1';
                 $cbads= '1';						 
			     $ppt_picurl = 'https://ws2.sinaimg.cn/large/0072Lfvtly1fsi54zc4ehj30ms05kgmk.jpg';
			     $ppt_titleurl = 'https://f162.cn/post/276';
			 	 $ppt_picur2 = 'https://ws2.sinaimg.cn/large/0072Lfvtly1fsi54zc4ehj30ms05kgmk.jpg';
			 	 $ppt_titleur2 = 'https://f162.cn/post/276';
			     $ppt_titleur3 = 'https://f162.cn/post/276';
				 $cbbt1 = '这不是广告是什么';
				 $cbbt2 = '这不是广告是什么';
				 $cbbt3 = '这不是广告是什么';
				 $cbbt4 = '这不是广告是什么';
				 $cbts1 = '联系QQ1444762288';
				 $cbts2 = '联系QQ1444762288';
				 $cbts3 = '联系QQ1444762288';
				 $cbts4 = '联系QQ1444762288';
				 $cdurl1 = 'tencent://message/?uin=1444762288';
				 $cdurl2 = 'tencent://message/?uin=1444762288';
				 $cdurl3 = 'tencent://message/?uin=1444762288';
				 $cdurl4 = 'tencent://message/?uin=1444762288';
				 $Sorth1 = '相册图库';
				 $Sorth2 = '文章归档';
				 $Sorth3 = '微言碎语';
				 $Sorth4 = '留言互动';
				 $Sorth5 = '我的邻居';
				 $Sortp1 = '相册图库介绍';
				 $Sortp2 = '所有文章都搁着';
				 $Sortp3 = '网站的公告';
				 $Sortp4 = '不要打广告哦';
				 $Sortp5 = '我的小伙们';
				 $Sorta1 = '/album.html';
				 $Sorta2 = '/archives.html';
				 $Sorta3 = '/t';
				 $Sorta4 = '/links.html';
				 $Sorta5 = '/links.html';
				 $jinru1_text = '自定义';
				 $jinru2_text = '自定义';
				 $jinru3_text = '自定义';
				 $jinru4_text = '自定义';
				 $jinru5_text = '自定义';
			 	 $ppt_picur3 = 'http://0d077ef9e74d8.cdn.sohucs.com/qzMooc5_jpg';
				 $arr_navico = 'a:5:{i:24;s:0:"";i:1;s:0:"";i:2;s:0:"";i:25;s:0:"";i:3;s:0:"";}';
				 $arr_sortico = 'a:2:{i:1;s:0:"";i:9;s:0:"";}';
				 $side_title = 'a:20:{i:1;s:12:"友情链接";i:2;s:9:"留言板";i:3;s:9:"关于我";i:4;s:6:"微语";i:5;s:1:"-";i:6;s:6:"微语";i:7;s:12:"文章归档";i:8;s:0:"";i:9;s:0:"";i:10;s:0:"";i:11;s:0:"";i:12;s:0:"";i:13;s:0:"";i:14;s:0:"";i:15;s:0:"";i:16;s:0:"";i:17;s:0:"";i:18;s:0:"";i:19;s:0:"";i:20;s:0:"";}';
				 $side_url = 'a:20:{i:1;s:11:"/links.html";i:2;s:10:"/gust.html";i:3;s:11:"/about.html";i:4;s:3:"/t/";i:5;s:0:"";i:6;s:3:"/t/";i:7;s:9:"/?post=27";i:8;s:0:"";i:9;s:0:"";i:10;s:0:"";i:11;s:0:"";i:12;s:0:"";i:13;s:0:"";i:14;s:0:"";i:15;s:0:"";i:16;s:0:"";i:17;s:0:"";i:18;s:0:"";i:19;s:0:"";i:20;s:0:"";}';				 
				 $css = '';
				 $theme_skin = '';
				 $m_cms_pci = '2';
				 $m_cms_page = '1,2,3,4,5,6';
				 $imgnum_all = '40';
				 $pjax = '';
				 $tip = '墙上还没人，快抢沙发啦~';
				 $type_wall = 'week';
				 $ad_side = '';
				 $ad_page = '';
				 $ad_page_down = '';
				 $userhide = '1';
				 $firstblood = '1';
				 $webcompress = '0';				 
				 $module_thum = '0';				 
				 $down_next = '0';
				 $m_zazhi_config = '1,2,3,4,5,6,7';
				 $m_zazhi_config1 = '1';
				 $m_zazhi_config2 = '1';
				 $cdn_css = '0';
                 $m_gfs_tuijian = '0';
                 $m_gfs_div = '1,2,3,4,5,6,7,8,9';
	    ?>