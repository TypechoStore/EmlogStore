<ul class="pagemenu">
	<li><a href="<?php echo $Tconfig["side_url1"];?>"><?php echo $Tconfig["side_title1"];?></a></li>
	<li><a href="<?php echo $Tconfig["side_url2"];?>"><?php echo $Tconfig["side_title2"];?></a></li>
	<li><a href="<?php echo $Tconfig["side_url3"];?>"><?php echo $Tconfig["side_title3"];?></a></li>
	<li><a href="<?php echo $Tconfig["side_url4"];?>"><?php echo $Tconfig["side_title4"];?></a></li>
	<li><a href="<?php echo $Tconfig["side_url5"];?>"><?php echo $Tconfig["side_title5"];?></a></li>
	<li><a href="<?php echo $Tconfig["side_url6"];?>"><?php echo $Tconfig["side_title6"];?></a></li>
</ul>