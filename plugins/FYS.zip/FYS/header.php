<?php
/*
Template Name:FYS V2版
Description:<font color=red>＊</font>该主题为会飞的鱼原创主题<br><font color=red>＊</font>采用Bootstrap框架<br><font color=red>＊</font>重写全部代码，修复N个BUG。<br><font color=red>＊</font>自带会员中心,功能更强大！<br><font color=red>＊</font>如有BUG请联系我，还有欢迎各位来我博客留个脚印<br><a href="../?setting" target="_blank">设置</a>
Version:2.51
Author:会飞的鱼
Author Url:https://f162.cn
Sidebar Amount:2
Update_Version:SVIP
*/
define("THEME_VER","2.51");
//设置时区
ini_set('date.timezone','Asia/Shanghai');
//载入函数
require_once View::getView('inc/functions');
//载入站点配置
require_once View::getView('inc/config');
$Tconfig = unserialize($Tconfig);
$GLOBALS['Tconfig'] = $Tconfig;
if($_GET['do'] == 'save'&& ROLE == ROLE_ADMIN){plugin_setting();}
global $arr_navico1;
$arr_navico1 = unserialize($arr_navico);
global $arr_sortico1;
$arr_sortico1 = unserialize($arr_sortico);
require_once View::getView('module');
require_once View::getView('function');
//手机QQ打开跳转到浏览器
if($Tconfig['qqtz']== 1 ){
$scriptpath = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
$sitepath = substr($scriptpath, 0, strrpos($scriptpath, '/'));
$siteurl = ($_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $sitepath . '/';
if (strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== !1 ) {
	echo '<!DOCTYPE html>
	<html>
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>请使用浏览器打开</title>
	<script src="https://open.mobile.qq.com/sdk/qqapi.js?_bid=152"></script>
	<script type="text/javascript"> mqq.ui.openUrl({ target: 2,url: "' . $siteurl . '"}); </script>
	</head>
	<body></body>
	</html>';
 exit;
}}
?>

<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=11,IE=10,IE=9,IE=8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<meta name="apple-mobile-web-app-title" content="会飞的鱼">
<meta http-equiv="Cache-Control" content="no-siteapp">
<title><?php echo $site_title; ?>
</title>
<link rel='dns-prefetch' href='//s.w.org'/>
<link rel='stylesheet' id='_bootstrap-css' href='<?php echo TEMPLATE_URL; ?>css/bootstrap.min.css?ver=3.0' type='text/css' media='all' />
<link rel='stylesheet' id='_fontawesome-css' href='<?php echo TEMPLATE_URL; ?>css/font-awesome.min.css?ver=3.0' type='text/css' media='all' />
<link rel='stylesheet' id='_main-css' href='<?php echo TEMPLATE_URL; ?>css/main.css?ver=3.0' type='text/css' media='all' />
<meta name="keywords" content="<?php echo $site_key; ?>">
<meta name="description" content="<?php echo $site_description; ?>">
<link rel="shortcut icon" href="<?php echo TEMPLATE_URL; ?>favicon.ico">
<!--[if lt IE 9]>
<script src="<?php echo TEMPLATE_URL; ?>js/libs/html5.min.js"></script>
<![endif]-->
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="//libs.baidu.com/jquery/1.8.0/jquery.min.js"></script>
<?php doAction('index_head'); ?>
<?php include View::getView('inc/skin');?>
</head>
<?php if($logid){?>
<body class="post-template-default single single-post postid-3782 single-format-standard comment-open site-layout-2">
<?php }else{?>
<body class="home blog site-layout-2">
<?php }?>
<header class="header">
<div class="container">
	<h1 class="logo"><a href="<?php echo BLOG_URL; ?>" title="<?php echo $site_title; ?>"><img src="<?php echo TEMPLATE_URL."img/logo.png";?>">会飞的鱼</a></h1>
	<div class="brand">
		<?php echo $Tconfig['new_log_num'];?>
	</div>
	<ul class="site-nav site-navbar">
		<?php blog_navi();?>
		<li class="navto-search"><a href="javascript:;" class="search-show active"><i class="fa fa-search"></i></a></li>
		<?php if(!islogin()){ ?>
		<li class="login-actions">
		<a href="javascript:;" class="user-login" data-sign="0"><i class="fa fa-sign-in"></i></a>
		</li>
		<?php }else{ ?>
		<?php 
				global $userData;
			?>
		<li class="login-actions">
		<a class="user-on"><img src="<?php $imgavatar = empty($userData['photo']) ? BLOG_URL . 'admin/views/images/avatar.jpg' : BLOG_URL . substr($userData['photo'],3);echo myGravatar($userData["email"],$imgavatar);?>" class="avatar avatar-100" height="50" width="50"></a>
		</li>
		<?php }?>
	</ul>
	<?php if(!islogin()){ ?>
	<div class="topbar" id="header">
		<?php if($Tconfig['more']== 1 ){?>
		<?php echo $Tconfig['more_html'];?>
		<?php }?>
		<a href="javascript:;" class="user-login" data-sign="0">Hi, 请登录</a> 
		&nbsp; &nbsp;<a href="javascript:;" class="user-reg" data-sign="1">我要注册</a>
	</div>
	<i class="fa fa-bars m-icon-nav"></i>
	<?php }else{ ?>
	<div class="topbar" id="header">
		<?php if($Tconfig['more']== 1 ){?>
			<?php echo $Tconfig['more_html'];?>
		<?php }?>
		<?php 
				global $userData;
			?>
	Hi, 
		<?php if(empty($userData["nickname"])){echo $userData["username"];}else{echo $userData["nickname"];}?>
		&nbsp; &nbsp;<a href="?user&posts">进入会员中心</a>&nbsp; &nbsp;
		<a href="admin/?action=logout">退出</a>
	</div>
	<i class="fa fa-bars m-icon-nav"></i>
	<div class="m-wel">
		<section class="user-profile">
		<div class="user-img">
			<a target="_blank" href="/?user&posts"><img src="<?php $imgavatar = empty($userData['photo']) ? BLOG_URL . 'admin/views/images/avatar.jpg' : BLOG_URL . substr($userData['photo'],3);echo myGravatar($userData["email"],$imgavatar);?>" class="avatar avatar-100" height="50" width="50"></a>
		</div>
		<div class="user-name">
			<?php if(empty($userData["nickname"])){echo $userData["username"];}else{echo $userData["nickname"];}?>
			<br>
			<span><?php echo $userData["email"];?>
			</span>
		</div>
		<input type="hidden" id="user_logined">
		</section>
		<section class="user-listview">
		<div class="panel">
			<h2>常用功能</h2>
			<ul>
				<li><a href="<?php echo BLOG_URL;?>?user&post-new">
				<i class="fa fa-pencil-square-o"></i>
				<div>
          发布文章
				</div>
				</a></li>
				<li><a href="<?php echo BLOG_URL;?>?user&posts">
				<i class="fa fa-file-text-o"></i>
				<div>
          我的文章
				</div>
				</a></li>
				<li><a href="<?php echo BLOG_URL;?>?user&comments">
				<i class="fa fa-comments-o"></i>
				<div>
          我的评论
				</div>
				</a></li>
				<li><a href="<?php echo BLOG_URL;?>?user&password">
				<i class="fa fa-cogs"></i>
				<div>
          修改密码
				</div>
				</a></li>
			</ul>
		</div>
		<div class="panel">
			<h2>账户设置</h2>
			<ul>
				<li><a href="<?php echo BLOG_URL;?>?user&info">
				<i class="fa fa-smile-o"></i>
				<div>
          我的资料
				</div>
				</a></li>
				<li><a href="admin/?action=logout">
				<i class="fa fa-sign-out"></i>
				<div>
          注销登录
				</div>
				</a></li>
			</ul>
		</div>
		</section>
	</div>
	<?php }?>
</div>
</header>
<div class="site-search">
	<div class="container">
		<form method="get" class="site-search-form" action="<?php echo BLOG_URL; ?>
			index.php" >
			<input class="search-input" name="keyword" type="text" placeholder="输入关键字" value="">
			<button class="search-btn" type="submit"><i class="fa fa-search"></i></button>
		</form>
	</div>
</div>