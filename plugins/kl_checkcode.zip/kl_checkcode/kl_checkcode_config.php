<?php
/**
 * @name kl_checkcode_config.php
 * @author KLLER
 * @version 1.7
 */

define('KL_CHECKCODE_MODE','4');
define('KL_CHECKCODE_BIT','4');
define('KL_CHECKCODE_SIZE','1');
define('KL_CHECKCODE_COLOR','#996600');
define('KL_CHECKCODE_BGCOLOR','#E6E6E6');
define('KL_CHECKCODE_SHUFFLE','1');
define('KL_CHECKCODE_TIPS','弟子规');
define('KL_CUSTOM_CODE','弟子规|圣人训|首孝弟|次谨信|
泛爱众|而亲仁|有余力|则学文|');