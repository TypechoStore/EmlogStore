<?php
/*
Plugin Name: 验证码
Version: 1.8
Plugin URL: http://www.emlog.net/plugin/54
Description: 新奇好玩的验证码。
Author: KLLER&二呆
Author Email: kller@foxmail.com
Author URL: https://www.tongleer.com
*/
!defined('EMLOG_ROOT') && exit('access deined!');
emLoadJQuery();
if(isset($_GET['action']) && $_GET['action'] == 'addcom' && isset($_POST['kl_checkcode']))
{
	session_start();
	//if(implode('', $_POST['kl_checkcode']) == $_SESSION['code']) $_SESSION['code'] = '';
	session_write_close();
}

function kl_checkcode()
{
	echo '<div class="sidebarsubmenu" id="kl_checkcode"><a href="./plugin.php?plugin=kl_checkcode">验证码</a></div>';
}
addAction('adm_sidebar_ext', 'kl_checkcode');

function kl_checkcode_is_mobile()
{
	$ua = isset($_SERVER['HTTP_USER_AGENT']) ? strtolower($_SERVER['HTTP_USER_AGENT']) : '';
	$uachar = "/(nokia|sony|ericsson|mot|samsung|sgh|lg|philips|panasonic|alcatel|lenovo|cldc|midp|wap|mobile)/i";
	return (preg_match($uachar, $ua, $str)) || empty($ua);
}

function kl_checkcode_init()
{
	if(kl_checkcode_is_mobile()) return;
	if(Option::get('comment_code') != 'y') return;
	$path = '';
	if(isset($_SERVER['REQUEST_URI']))
	{
		$path = $_SERVER['REQUEST_URI'];
	}else{
		if(isset($_SERVER['argv']))
		{
			$path = $_SERVER['PHP_SELF'].'?'.$_SERVER['argv'][0];
		}else{
			$path = $_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
		}
	}
	//for ie6 header location
	$r = explode('#', $path, 2);
	$path = $r[0];
	//for iis6
	$path = str_replace('index.php', '', $path);
	//for subdirectory
	$t = parse_url(BLOG_URL);
	$path = str_replace($t['path'], '/', $path);
	if($path == '/t/') return;
	$reg_arr = array('|^.*/\?(post)=(\d+)$|', '|^.*/(post)-(\d+)\.html$|', '|^.*/(post)/(\d+)/?$|', '|^/([^\./\?=]+)(\.html)?/?$|');
	$isreturn = true;
	foreach($reg_arr as $reg)
	{
		if(preg_match($reg, $path))
		{
			$isreturn = false;
			break;
		}
	}
	if($isreturn) return;
	include_once(EMLOG_ROOT.'/content/plugins/kl_checkcode/kl_checkcode_config.php');
	$font_size = KL_CHECKCODE_SIZE >=0.5 && KL_CHECKCODE_SIZE <= 2 ? KL_CHECKCODE_SIZE : 1;
	$font_color = preg_match('/^#[0-9a-fA-F]{6}$/', trim(KL_CHECKCODE_COLOR)) ? KL_CHECKCODE_COLOR : '#1C94C4';
	$font_bgcolor = preg_match('/^#[0-9a-fA-F]{6}$/', trim(KL_CHECKCODE_BGCOLOR)) ? KL_CHECKCODE_BGCOLOR : '#E6E6E6';
	$active_plugins = Option::get('active_plugins');
	echo '<script type="text/javascript" src="'.BLOG_URL.'content/plugins/kl_checkcode/ui/jquery-ui.min.js"></script>
<script type="text/javascript">jQuery(function($){$("#kl_checkcode_ul").sortable().end().disableSelection();});</script>
<style type="text/css">
#kl_checkcode_ul {list-style-type: none; margin: 0; padding: 0;}
#kl_checkcode_ul li {background:'.$font_bgcolor.'; margin: 3px 3px 3px 0; padding: 0px 2px 0px 2px; float: left; font-size: '.$font_size.'em; text-align: center;  border: 1px solid #cccccc; font-weight: bold; color: '.$font_color.'; outline: none; cursor: move;}
</style>';
}
addAction('index_head', 'kl_checkcode_init');

function kl_checkcode_2_log()
{
	if(kl_checkcode_is_mobile()) return;
	if(Option::get('comment_code') != 'y') return;
	$data = ob_get_clean();
	include_once(EMLOG_ROOT.'/content/plugins/kl_checkcode/kl_checkcode_config.php');
	$cheackimg = '';
	session_start();
	$the_cn_mark = false;
	switch(KL_CHECKCODE_MODE){
		case 1:
			$char_arr_arr = array(range(0, 9));
			$the_title = '拖动数字按照0-9顺序排列就OK啦';
			break;
		case 2:
			$char_arr_arr = array(range('A', 'Z'));
			$the_title = '拖动字母按照A-Z顺序排列就OK啦';
			break;
		case 3:
			$char_arr_arr = array(range(0, 9), range('A', 'Z'));
			$the_title = '拖动数字或字母按照0-9或A-Z顺序排列就OK啦';
			break;
		case 4:
			$custom_code = preg_replace('/\s+/s', '', str_replace('　', '', KL_CUSTOM_CODE));
			if(empty($custom_code))
			{
				$char_arr_arr = array(range(0, 9), range('A', 'Z'));
				$the_title = '拖动数字或字母按照0-9或A-Z顺序排列就OK啦';
			}else{
				$custom_code_arr = explode('|', $custom_code);
				foreach($custom_code_arr as $key => $val)
				if($val === '') unset($custom_code_arr[$key]);
				shuffle($custom_code_arr);
				$checkcodebak = trim($custom_code_arr[0]);
				$checkcode = kl_checkcode_custom_shuffle($checkcodebak);
				$the_cn_mark = true;
				$_SESSION['code'] = $checkcodebak;
				$the_title = KL_CHECKCODE_TIPS;
			}
			break;
	}
	if($the_cn_mark !== true)
	{
		shuffle($char_arr_arr);
		$char_arr = $char_arr_arr[0];
		$checkcode = kl_checkcode_shuffle($char_arr);
		$checkcodebak = $checkcode;
		sort($checkcodebak);
		$_SESSION['code'] = implode('', $checkcodebak);
	}

	$cheackimg = '<ul id="kl_checkcode_ul">';
	foreach ($checkcode as $char)
	$cheackimg .= "<li title=\"$the_title\">{$char}<input type=\"hidden\" name=\"kl_checkcode[]\" value=\"{$char}\" /></li>";
	$cheackimg .= '<input id="imgcode" name="imgcode" type="hidden" value="" /></ul>';
	$data = preg_replace( "/<[img|IMG].*?src=[\'|\"](.*?)checkcode.php[\'|\"].*?[\/]?><input.*?name=[\'|\"]imgcode[\'|\"].*?[\/]?>/", $cheackimg, $data);
	//$data = str_replace('<img src="'.BLOG_URL.'include/lib/checkcode.php" align="absmiddle" /><input name="imgcode" type="text" class="input" size="5" tabindex="5" />', $cheackimg, $data);
	ob_start();
	echo $data.'<script>$("#imgcode").val("'.$_SESSION['code'].'");</script>';
}

function kl_checkcode_custom_shuffle($checkcodebak)
{
	$the_code_lenth = mb_strlen($checkcodebak, 'utf-8');
	$checkcode = array();
	for($i = 0; $i < $the_code_lenth; $i++)
	$checkcode[] = mb_substr($checkcodebak, $i ,1, 'utf-8');
	shuffle($checkcode);
	$new_checkcodebak = implode('', $checkcode);
	if(intval(KL_CHECKCODE_SHUFFLE) == 0 || $the_code_lenth < 2) return $checkcode;
	return $new_checkcodebak == $checkcodebak ? kl_checkcode_custom_shuffle($checkcodebak) : $checkcode;
}

function kl_checkcode_shuffle($char_arr)
{
	$new_char_arr = $char_arr;
	shuffle($char_arr);
	$max_i = KL_CHECKCODE_BIT > 10 ? 10 : KL_CHECKCODE_BIT;
	$max_i = $max_i < 2 ? 2 : $max_i;
	$chunk_char_arr = array_chunk($char_arr, $max_i);
	$checkcode = $chunk_char_arr[0];
	if(intval(KL_CHECKCODE_SHUFFLE) == 0) return $checkcode;
	$checkcodebak = $checkcode;
	sort($checkcodebak);
	return $checkcode == $checkcodebak ? kl_checkcode_shuffle($new_char_arr) : $checkcode;
}
addAction('index_footer', 'kl_checkcode_2_log');
