<?php
/**
 * @name kl_checkcode_setting.php
 * @author KLLER
 * @version 1.5
 */

!defined('EMLOG_ROOT') && exit('access deined!');

function plugin_setting_view()
{
	/*读取邮件配置信息*/
	include(EMLOG_ROOT.'/content/plugins/kl_checkcode/kl_checkcode_config.php');
	$kl_checkcode_mode_arr = array(1=>'纯数字', 2=>'纯字母', 3=>'纯数字或纯字母', 4=>'自定义模式');
	$kl_checkcode_mode_option_str = '';
	foreach($kl_checkcode_mode_arr as $k => $v){
		$selected = KL_CHECKCODE_MODE == $k ? ' selected' : '';
		$kl_checkcode_mode_option_str .= "<option value=\"{$k}\" {$selected}>{$v}</option>";
	}
	$kl_checkcode_bit_arr = range(2, 10);
	$kl_checkcode_bit_option_str = '';
	foreach($kl_checkcode_bit_arr as $v){
		$selected = KL_CHECKCODE_BIT == $v ? ' selected' : '';
		$kl_checkcode_bit_option_str .= "<option value=\"{$v}\" {$selected}>{$v}</option>";
	}
	$kl_checkcode_shuffle_arr = array('否', '是');
	$kl_checkcode_shuffle_option_str = '';
	foreach($kl_checkcode_shuffle_arr as $k => $v){
		$selected = KL_CHECKCODE_SHUFFLE == $k ? ' selected' : '';
		$kl_checkcode_shuffle_option_str .= "<option value=\"{$k}\" {$selected}>{$v}</option>";
	}
?>
<script>
$("#kl_checkcode").addClass('sidebarsubmenu1');
setTimeout(hideActived,2600);
</script>
<div class=containertitle><b>新奇好玩的验证码</b>
<?php if(isset($_GET['setting'])):?><span class="actived">插件设置完成</span><?php endif;?>
</div>
<div class=line></div>
<div>
	<form id="form1" name="form1" method="post" action="plugin.php?plugin=kl_checkcode&action=setting">

  		  <table width="650" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="120" height="30">验证码模式:</td>
              <td><select name="kl_checkcode_mode"><?php echo $kl_checkcode_mode_option_str; ?></select></td>
            </tr>
            <tr>
              <td width="120" height="30">验证码位数:</td>
              <td><select name="kl_checkcode_bit"><?php echo $kl_checkcode_bit_option_str; ?></select></td>
            </tr>
            <tr>
              <td height="30">验证码文字大小:</td>
              <td><input name="kl_checkcode_size" type="text" value="<?php echo KL_CHECKCODE_SIZE; ?>"/>（请设置为0.5到2之间的数字）</td>
            </tr>
            <tr>
              <td height="30">验证码文字颜色:</td>
              <td><input name="kl_checkcode_color" type="text" value="<?php echo KL_CHECKCODE_COLOR; ?>"/>（请设置为“#”加六位十六进制数组成的颜色代码，如#1C94C4）</td>
            </tr>
            <tr>
              <td height="30">验证码文字背景颜色:</td>
              <td><input name="kl_checkcode_bgcolor" type="text" value="<?php echo KL_CHECKCODE_BGCOLOR; ?>"/>（请设置为“#”加六位十六进制数组成的颜色代码，如#E6E6E6）</td>
            </tr>
            <tr>
              <td width="120" height="30">绝对乱序:</td>
              <td><select name="kl_checkcode_shuffle"><?php echo $kl_checkcode_shuffle_option_str; ?></select>（选择“是”，就不会出现类似“1245 ”，“ADEF ”这种不用排列-顺序就是正确的情况）</td>
            </tr>
            <tr>
              <td>自定义模式提示文字:</td>
              <td><input name="kl_checkcode_tips" type="text" style="width:300px;" value="<?php echo KL_CHECKCODE_TIPS; ?>"/></td>
            </tr>
            <tr>
              <td height="100">自定义验证码字符串:<br />（注：用 | 分隔）</td>
              <td><textarea name="kl_custom_code" rows="5" style="width:300px;"><?php echo KL_CUSTOM_CODE; ?></textarea></td>
            </tr>
            <tr>
              <td height="37">&nbsp;</td>
              <td><input name="Input" type="submit" value="保　存" /></td>
            </tr>
          </table>
	</form>
</div>
<div style="margin-top:20px; padding:5px; width:605px; border:1px dashed #CCC">
<p><font color="green"><b>温馨提示：</b></font>验证码位数只用于非自定义模式，自定义模式提示文字与自定义验证码字符串只用于自定义模式。 - -||</p>
</div>
<?php
}

function plugin_setting()
{
	//修改配置信息
	$fso = fopen(EMLOG_ROOT.'/content/plugins/kl_checkcode/kl_checkcode_config.php','r'); //获取配置文件内容
	$config = fread($fso,filesize(EMLOG_ROOT.'/content/plugins/kl_checkcode/kl_checkcode_config.php'));
	fclose($fso);

	$kl_checkcode_mode = htmlspecialchars($_POST['kl_checkcode_mode'], ENT_QUOTES);
	$kl_checkcode_bit = htmlspecialchars($_POST['kl_checkcode_bit'], ENT_QUOTES);
	$kl_checkcode_size = htmlspecialchars($_POST['kl_checkcode_size'], ENT_QUOTES);
	$kl_checkcode_color = htmlspecialchars($_POST['kl_checkcode_color'], ENT_QUOTES);
	$kl_checkcode_bgcolor = htmlspecialchars($_POST['kl_checkcode_bgcolor'], ENT_QUOTES);
	$kl_checkcode_shuffle = htmlspecialchars($_POST['kl_checkcode_shuffle'], ENT_QUOTES);
	$kl_checkcode_tips = htmlspecialchars($_POST['kl_checkcode_tips'], ENT_QUOTES);
	$kl_custom_code = htmlspecialchars($_POST['kl_custom_code'], ENT_QUOTES);

	$patt = array(
	"/define\('KL_CHECKCODE_MODE',(.*)\)/",
	"/define\('KL_CHECKCODE_BIT',(.*)\)/",
	"/define\('KL_CHECKCODE_SIZE',(.*)\)/",
	"/define\('KL_CHECKCODE_COLOR',(.*)\)/",
	"/define\('KL_CHECKCODE_BGCOLOR',(.*)\)/",
	"/define\('KL_CHECKCODE_SHUFFLE',(.*)\)/",
	"/define\('KL_CHECKCODE_TIPS',(.*)\)/",
	"/define\('KL_CUSTOM_CODE',(.*)\)/s",
	);

	$replace = array(
	"define('KL_CHECKCODE_MODE','".$kl_checkcode_mode."')",
	"define('KL_CHECKCODE_BIT','".$kl_checkcode_bit."')",
	"define('KL_CHECKCODE_SIZE','".$kl_checkcode_size."')",
	"define('KL_CHECKCODE_COLOR','".$kl_checkcode_color."')",
	"define('KL_CHECKCODE_BGCOLOR','".$kl_checkcode_bgcolor."')",
	"define('KL_CHECKCODE_SHUFFLE','".$kl_checkcode_shuffle."')",
	"define('KL_CHECKCODE_TIPS','".$kl_checkcode_tips."')",
	"define('KL_CUSTOM_CODE','".$kl_custom_code."')",
	);

	$new_config = preg_replace($patt, $replace, $config);
	$fso = fopen(EMLOG_ROOT.'/content/plugins/kl_checkcode/kl_checkcode_config.php','w'); //写入替换后的配置文件
	fwrite($fso,$new_config);
	fclose($fso);
}
?>