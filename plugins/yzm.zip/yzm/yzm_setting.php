<?php
!defined('EMLOG_ROOT') && exit('出错了！！！!');
function plugin_setting_view(){
		include_once(EMLOG_ROOT.'/content/plugins/yzm/yzm_config.php');

?>
<?php if(isset($_GET['setting'])):?><span class="actived">设置成功</span><?php endif;?>
<style>
.yzm {padding: 5px 5px;
margin: 10px 0 0px;
font-size: 15.5px;
border-left: 5px solid #51ADED;}
</style>

<h2>公众号获取验证码设置：</h2>
<a href="http://www.98efang.com" target="_blank">更多emlog插件访问易仿建站</a>

<form id="form1" name="form1" method="post" action="plugin.php?plugin=yzm&action=setting&changeinfo=1">
<div class="yzm">获取验证码提示信息</div>
<br>

<textarea name="tips" style="width:100%;height:150px;" type="text">
<?php echo tips;?>
</textarea>
<div class="yzm">公众号二维码 <a target="_blank" href="http://www.chuantu.biz/">图片上传</a></div>
<br>

<input name="ewm" type="text" id="tspeed" style="width:280px;" value="<?php echo ewm ?>"/>

<div class="yzm">文章查看验证码</div>
<br>

<input name="yzm" type="text" id="tspeed" style="width:280px;" value="<?php echo yzm ?>"/>
<br><br>
<input name="Input" type="submit" value="提交" /> <input name="Input" type="reset" value="取消" />
</form>
<?php }?>
<?php
function plugin_setting()
{

	if(isset($_GET['changeinfo']))
	{

	    $tag_cloud_fp = fopen(EMLOG_ROOT.'/content/plugins/yzm/yzm_config.php','r');
		$tag_cloud_config = fread($tag_cloud_fp,filesize(EMLOG_ROOT.'/content/plugins/yzm/yzm_config.php'));
		fclose($tag_cloud_fp);  
		$tips = htmlspecialchars($_POST['tips'], ENT_QUOTES);
		$ewm = htmlspecialchars($_POST['ewm'], ENT_QUOTES);
		$yzm = htmlspecialchars($_POST['yzm'], ENT_QUOTES);
		$tag_cloud_patt = array(
							  "/define\('tips',(.*)\)/",
							  "/define\('ewm',(.*)\)/",
							  "/define\('yzm',(.*)\)/",
	                                                   );
		$tag_cloud_replace = array(
								 "define('tips','".$tips."')",
								 "define('ewm','".$ewm."')",
								 "define('yzm','".$yzm."')",
								                                      );
		$tag_cloud_new_config = preg_replace($tag_cloud_patt, $tag_cloud_replace, $tag_cloud_config);
		$tag_cloud_fp = @fopen(EMLOG_ROOT.'/content/plugins/yzm/yzm_config.php','w');
		@fwrite($tag_cloud_fp,$tag_cloud_new_config);
		@fclose($tag_cloud_fp);
	}
}
?>