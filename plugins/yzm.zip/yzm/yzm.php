<?php
/**
 * Plugin Name: 微信验证码查看
 * Version: 1.0
 * Plugin URL: http://www.98efang.com
 * Description: 隐藏文章中的指定内容使其必须关注公众号回复只能内容才能查看。
 * Author: 易仿建站
 * Author URL: http://www.98efang.com
 */

!defined('EMLOG_ROOT') && exit ('access deined!');
 require_once 'yzm_config.php';
function yzm_list(){
	echo '
	';
	$commentview = ob_get_clean();
	$commentview = preg_replace("/\[yzm\](.*)\[\/yzm\]/Uims", '内容被隐藏', $commentview);
	ob_start();
	echo $commentview;
}

function yzm($logData){
	global $CACHE;
$user_cache = $CACHE->readCache('user'); //读取用户缓存
	$logid = $logData['logid'];
	$logurl = Url::log($logData['logid']);
	$commentview = ob_get_clean();
	$commentviews="";

if($_POST['yzm'] == yzm){
		$commentview = preg_replace("/\[yzm\](.*)\[\/yzm\]/Uims", '\1', $commentview);
	}else{
		$commentview = preg_replace("/\[yzm\](.*)\[\/yzm\]/Uims",'<div class="huoduan_hide_box" style="border:1px dashed #F60; padding:10px; margin:10px 0; line-height:200%; color:#F00; background-color:#FFF4FF; overflow:hidden; clear:both;">
		<img class="wxpic" src="'.ewm.'" style="width:150px;height:150px;margin-left:20px;display:inline;border:none" width="150" height="150" align="right">
		<span style="font-size:18px;">此处内容已经被作者隐藏，请输入验证码查看内容</span>
		<form method="post" style="margin:10px 0;">
		<span class="yzts" style="font-size:18px;float:left;">验证码：</span>
		<input name="yzm" id="verifycode" value="" style="border:none;float:left;width:80px; height:30px; line-height:30px; padding:0 5px; border:1px solid #FF6600;-moz-border-radius: 0px;  -webkit-border-radius: 0px;  border-radius:0px;" type="text">
		<input id="verifybtn" style="border:none;float:left;width:80px; height:32px; line-height:32px; padding:0 5px; background-color:#F60; text-align:center; border:none; cursor:pointer; color:#FFF;-moz-border-radius: 0px; font-size:14px;  -webkit-border-radius: 0px;  border-radius:0px;" name="" value="提交查看" type="submit">
		</form><div style="clear:left;"></div>
		
		<span style="color:#00BF30">'.tips.'</span><div class="cl"></div></div>
		', $commentview);
	}

	ob_start();
	echo $commentview;
}



function yzm_addButton(){
	echo '	<input type="button" id="addpp"  value="填写验证码查看内容"/>
		<script>
			$(document).ready(function(){
				$("#addpp").click(function(){
					if(typeof($("#markdownEditor_content").val())!="undefined"){
						$("#markdownEditor_content").val($("#markdownEditor_content").val()+"<p>[yzm] 输入vip可见内容 [/yzm]</p>");
					}else if(typeof(contentLayUIEditor)!="undefined"&&typeof(layedit)!="undefined"){
						layedit.setContent(contentLayUIEditor,"<p>[yzm] 输入vip可见内容 [/yzm]</p>",true);
					}else{
						$($(".ke-edit-iframe:first").contents().find(".ke-content")).append("<p>[yzm] 输入vip可见内容 [/yzm]</p>");  
					}
				});
			});
		</script>
	
	';	
}
function zd_menu(){
	echo '<div class="sidebarsubmenu" id="yjzd"><a href="./plugin.php?plugin=yzm">验证码设置</a></div>';
}
addAction('adm_sidebar_ext', 'zd_menu');
addAction('adm_writelog_head', 'yzm_addButton');
addAction('index_head','yzm_list');
addAction('log_related','yzm');
addAction('comment_saved', 'comment_views');