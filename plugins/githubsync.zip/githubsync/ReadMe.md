Advance Markdown Parser
---

###Project Ico
---
> ![image](images/ico.jpg)

###Useage
---
> You can see some introduction from the [Emlog-Forum](http://bbs.emlog.net/thread-35047-1-1.html)

