<?php
/**
 * kl_data_call_do.php
 * design by KLLER
 */
include_once('../../../init.php');
$output = isset($_GET['ID']) ? kl_data_call_for_internal_value(intval($_GET['ID'])) : '';
if(trim($output) != '')
{
	if(isset($_GET['callback']) && trim($_GET['callback']) == 'html') exit($output);
	$lineArr = explode("\n", $output);
	foreach($lineArr as $line)
	{
		if(substr($line, strlen($line)-1, strlen($line)) == "\n") $line = substr($line, 0, strlen($line)-1);
		echo 'document.write(\''.addslashes(trim($line)).'\');'."\n";
	}
}