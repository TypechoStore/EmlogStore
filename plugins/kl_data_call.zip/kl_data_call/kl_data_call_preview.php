<?php
/**
 * kl_data_call_preview.php
 * design by KLLER
 */
require_once('../../../init.php');
if (ROLE != 'admin') exit('access deined!');
header('content-type:text/html;charset=utf-8');
$moudle = array();
$kl_t = isset($_GET['kl_t']) ? intval($_GET['kl_t']) : 0;
if($kl_t == 1){
	$intval_argu_arr = array('kl_t', 'start_num', 'dis_rows', 'author','is_include_img', 'order_style', 'date_style');
}elseif($kl_t == 2){
	$intval_argu_arr = array('kl_t', 'start_num', 'dis_rows', 'em_album', 'order_style', 'date_style');
}else{
	$intval_argu_arr = array('kl_t', 'sort', 'start_num', 'dis_rows', 'author', 'filter', 'is_include_img', 'nopwd', 'link_style', 'order_style', 'date_style');
}
foreach($intval_argu_arr as $iaav) $moudle[$iaav] = intval($_GET[$iaav]);
if($kl_t != 2) $moudle['custom_tailor'] = addslashes(trim($_GET['custom_tailor']));
$output = kl_data_call_main_fun_for_preview($moudle, $_POST['code']);
if($output == '') $output = '<font color="red"><b>没有符合条件的记录！</b></font>';
echo $output;