<?php
/**
 * kl_data_call_setting.php
 * design by KLLER
 */
!defined('EMLOG_ROOT') && exit('access deined!');

function plugin_setting_view()
{
	global $CACHE;
	$options_cache = $CACHE->readCache('options');
	$data_call_moudle_config = array();
	foreach($options_cache as $ock=>$ocv){
		if(preg_match('/^kl_data_call_(\d+)$/', $ock, $didInfo)) $data_call_moudle_config[$didInfo[1]] = unserialize($ocv);
	}
	ksort($data_call_moudle_config);
	$kl_data_call_info = unserialize(Option::get('kl_data_call_info'));
	$dir_is_writable_msg = is_writable(KL_DATA_CALL_CACHE_DIR) ? '' : '<span class="error">kl_data_call/cache目录可能不可写，如果已经是可写状态，请忽略此信息。</span>';
	$kl_t_array = array('<font color="red">文章调用</font>', '<font color="green">微语调用</font>', '<font color="blue">EM相册调用</font>');
?>
<script src="../include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="../content/plugins/kl_data_call/res/jquery.zclip.min.js" type="text/javascript"></script>
<script type="text/javascript">$("#kl_data_call").addClass('sidebarsubmenu1');setTimeout(hideActived,2600);</script>
<style type="text/css">
.table_b{float:left;border-collapse: collapse;border-style: none; border:1px solid #ccc; width:100%;}
.table_b td{border:1px solid #e0e0e0; padding:2px 5px; line-height:22px;}
.error{margin:0px 20px;}
</style>
<div class=containertitle><b>数据调用</b><span style="font-size:12px;color:#999999;">（版本：<?php echo $kl_data_call_info['version']; ?>）</span><?php echo $dir_is_writable_msg;?></div>
<?php if(isset($_GET['act'])):?>
<script type="text/javascript">
jQuery.fn.onlyPressNum = function(){$(this).css('ime-mode','disabled');$(this).css('-moz-user-select','none');$(this).bind('keydown',function(event){var k=event.keyCode;if(!((k==13)||(k==9)||(k==35)||(k == 36)||(k==8)||(k==46)||(k>=48&&k<=57)||(k>=96&&k<=105)||(k>=37&&k<=40))){event.preventDefault();}})}
jQuery(function($){
	$('#internal_call_function, #external_html_call_function, #external_js_call_function').zclip({path:'../content/plugins/kl_data_call/res/ZeroClipboard.swf',copy:function(){return $(this).val();},afterCopy:function(){alert('调用地址已复制');}});
	$('input[name=start_num],input[name=dis_rows],input[name=cache_limit]').onlyPressNum();
	$('#save').click(function(){if($.trim($('#custom_tailor').val())!=''&&!/^\d(\d|,)*$/.test($.trim($('#custom_tailor').val()))){alert('"个人定制"那里只允许输入数字和半角逗号的组合');return false};});
	$('#preview_do').click(function(){
		var kl_t = $('#kl_t').val();
		if(kl_t == 1){
			if($.trim($('#custom_tailor').val())!=''&&!/^\d(\d|,)*$/.test($.trim($('#custom_tailor').val()))){alert('"个人定制"那里只允许输入数字和半角逗号的组合');return false};
			var arguArr = ['kl_t', 'start_num', 'dis_rows', 'custom_tailor', 'author', 'is_include_img', 'order_style', 'date_style'];
		}else if(kl_t == 2){
			var arguArr = ['kl_t', 'start_num', 'dis_rows', 'em_album', 'order_style', 'date_style'];
		}else{
			if($.trim($('#custom_tailor').val())!=''&&!/^\d(\d|,)*$/.test($.trim($('#custom_tailor').val()))){alert('"个人定制"那里只允许输入数字和半角逗号的组合');return false};
			var arguArr = ['kl_t', 'sort', 'start_num', 'dis_rows', 'custom_tailor', 'author', 'filter', 'is_include_img', 'nopwd', 'link_style', 'order_style', 'date_style'];
		}
		var ajaxUrl = $('#ajaxUrl').val();
		var arguStr = '';
		$.each(arguArr, function(){arguStr+=this+'='+$('#'+this).val()+'&'});
		ajaxUrl += '?' + arguStr.substring(0,arguStr.length-1);
		$('#preview').html("<div><span style=\"background-color:#FFFFE5; color:#666666;\">加载中...</span></div>");
		$.post(ajaxUrl,{code:$('#code').val()},function(data){$('#preview').html(data)});
	});
})
</script>
<?php else:?>
<style type="text/css">
input{font-size:12px;cursor:pointer;}
input.copy{border:1px solid #DEDEDE;background-color:whiteSmoke;color:#336699;}
input.copy:hover{border:1px solid #c2e1ef;background-color:#dff4ff;}
input.edit{border:1px solid #DEDEDE;background-color:whiteSmoke;color:#529214;}
input.edit:hover{border:1px solid #C6D880;background-color:#E6EFC2;}
input.del{border:1px solid #DEDEDE;background-color:whiteSmoke;color:#D12F19;}
input.del:hover{border:1px solid #fbc2c4;background:#fbe3e4;}
</style>
<?php endif;?>
<?php if(!isset($_GET['act'])){ ?>
<div class="containertitle2">
<a class="navi3" href="?plugin=kl_data_call">调用列表</a>
<a class="navi4" href="?plugin=kl_data_call&act=add">文章调用</a>
<a class="navi4" href="?plugin=kl_data_call&act=add&kl_t=1">微语调用</a>
<a class="navi4" href="?plugin=kl_data_call&act=add&kl_t=2">EM相册调用</a>
<?php if(isset($_GET['active_del'])):?><span class="actived">删除成功</span><?php endif;?>
<?php if(isset($_GET['active_update'])):?><span class="actived">更新缓存成功</span><?php endif;?>
<span style="float:right;"><form action="./plugin.php?plugin=kl_data_call&action=setting&update=true" method="POST"><input name="kl_data_call_do" class="copy" type="submit" value="一键更新所有数据调用缓存" /></form></span>
</div>
<script type="text/javascript">
function delmenu(id){if(confirm('确定删除此菜单栏目？')){document.location='./plugin.php?plugin=kl_data_call&action=setting&act=del&id=' + id;}}
jQuery(function($){$('input[id^=internal_call_function], input[id^=external_html_call_function], input[id^=external_js_call_function]').zclip({path:'../content/plugins/kl_data_call/res/ZeroClipboard.swf',copy:function(){return $(this).prev().val();},afterCopy:function(){alert('调用地址已复制');}});});
</script>
<table width="100%" id="kl_data_call_list" class="item_list">
	<thead>
		<tr>
			<th height="25" class="tdcenter"><b>自增序号</b></th>
			<th class="tdcenter"><b>调用ID</b></th>
			<th class="tdcenter"><b>调用类型</b></th>
			<th class="tdcenter"><b>模块描述</b></th>
			<th class="tdcenter"><b>内部地址</b></th>
			<th class="tdcenter"><b>外部html调用</b></th>
			<th class="tdcenter"><b>外部js调用</b></th>
			<th class="tdcenter"><b>操作</b></th>
		</tr>
	</thead>
	<tbody>
<?php
$i = 1;
if($data_call_moudle_config):
	foreach($data_call_moudle_config as $id => $moudle):
		$kl_t = isset($moudle['kl_t']) && in_array($moudle['kl_t'], array_keys($kl_t_array)) ? $moudle['kl_t'] : 0;
		$kl_t_str = $kl_t_array[$kl_t];
	?>  
		<tr>
			<td height="25" class="tdcenter"><?php echo $i; ?></td>
			<td class="tdcenter"><?php echo $moudle['did']; ?></td>
			<td class="tdcenter"><?php echo $kl_t_str; ?></td>
			<td class="tdcenter"><?php echo $moudle['description']; ?></td>
			<td class="tdcenter"><div style="position:relative;"><input type="hidden" value="kl_data_call_for_internal(<?php echo $moudle['did']; ?>)" /><input type="button" id="internal_call_function_<?php echo $moudle['did']; ?>" value="复制" class="copy" /></div></td>
			<td class="tdcenter"><div style="position:relative;"><input type="hidden" value="<?php echo BLOG_URL; ?>content/plugins/kl_data_call/kl_data_call_do.php?callback=html&ID=<?php echo $moudle['did']; ?>" /><input type="button" id="external_html_call_function_<?php echo $moudle['did']; ?>" value="复制" class="copy" /></div></td>
			<td class="tdcenter"><div style="position:relative;"><input type="hidden" value="<?php echo htmlspecialchars('<script charset="utf-8" type="text/javascript" src="'.BLOG_URL.'content/plugins/kl_data_call/kl_data_call_do.php?ID='.$moudle['did'].'"></script>');?>" /><input type="button" id="external_js_call_function_<?php echo $moudle['did']; ?>" value="复制" class="copy" /></div></td>
			<td class="tdcenter"><form action="./plugin.php?plugin=kl_data_call&action=setting&act=del&id=<?php echo $id; ?>" method="POST" onsubmit="javascript:if(!confirm('确定要删除？')) return false;"><input type="button" value="编辑" class="edit" onclick="location.href='./plugin.php?plugin=kl_data_call&act=edit&id=<?php echo $id; ?>'"> <input name="del" type="submit" class="del" value="删除" /></form></td>
		</tr>
	<?php $i++;endforeach;else:?>
		<tr><td class="tdcenter" colspan="6">还没有添加数据调用</td></tr>
	<?php endif;?>
	</tbody>
</table>
<script type="text/javascript">
$(document).ready(function(){
	$("#kl_data_call_list tbody tr:odd").addClass("tralt_b");
	$("#kl_data_call_list tbody tr").mouseover(function(){$(this).addClass("trover")}).mouseout(function(){$(this).removeClass("trover")})
});
</script>
<?php
		exit;
	}
	if(isset($_GET['act'])) $act = $_GET['act'];
	if(isset($_GET['id'])) $id = intval($_GET['id']);
	if(isset($id))
	{
		$moudle = $data_call_moudle_config[$id];
		$kl_t = isset($moudle['kl_t']) && in_array($moudle['kl_t'], array_keys($kl_t_array)) ? $moudle['kl_t'] : 0;
		$kl_t_str = $kl_t_array[$kl_t];
		$did = $moudle['did'];
	}else{
		$kl_t = isset($_GET['kl_t']) ? intval($_GET['kl_t']) : 0;
		$kl_t_str = $kl_t_array[$kl_t];
		$did = count($data_call_moudle_config) == 0 ? 1 : max(array_keys($data_call_moudle_config)) + 1;
	}
	if($kl_t == 1){
		$user_cache = $CACHE->readCache('user');
		$author_option_str = '<option value="0">全部</option>';
		foreach($user_cache as $uk=>$user){
			$selected = (isset($moudle['author']) && $uk == $moudle['author']) ? 'selected' : '';
			$author_option_str .= "<option value=\"{$uk}\" {$selected}>{$user['name']}</option>";
		}

		$is_include_img_arr = array('全部文章', '仅显示有图片的微语', '仅显示没有图片的微语');
		$is_include_img_option_str = '';
		foreach($is_include_img_arr as $value=>$is_include_img)
		{
			$selected = (isset($moudle['is_include_img']) && $value == $moudle['is_include_img']) ? 'selected' : '';
			$is_include_img_option_str .= "<option value=\"{$value}\" {$selected}>{$is_include_img}</option>";
		}

		$order_style_arr = array('发布时间倒序', '回复数倒序', '随机');
		$order_style_option_str = '';
		foreach($order_style_arr as $value=>$order_style)
		{
			$selected = (isset($moudle['order_style']) && $value == $moudle['order_style']) ? 'selected' : '';
			$order_style_option_str .= "<option value=\"{$value}\" {$selected}>{$order_style}</option>";
		}

		$date_style_arr = array('2010-1-1', '2010-01-01', '2010年1月1日', '2010年01月01日', '2010-1-1 0:00', '2010-01-01 00:00', '2010-1-1 0:00:00', '2010-01-01 00:00:00', '2010-1-1 0:00 Friday', '2010-01-01 00:00 Friday');
		$date_style_option_str = '';
		foreach($date_style_arr as $value=>$date_style)
		{
			$selected = (isset($moudle['date_style']) && $value == $moudle['date_style']) ? 'selected' : '';
			$date_style_option_str .= "<option value=\"{$value}\" {$selected}>{$date_style}</option>";
		}
?>
<div class="containertitle2">
<a class="navi1" href="?plugin=kl_data_call">调用列表</a>
<a class="navi4" href="?plugin=kl_data_call&act=add">文章调用</a>
<a class="navi3" href="?plugin=kl_data_call&act=add&kl_t=1">微语调用</a>
<a class="navi4" href="?plugin=kl_data_call&act=add&kl_t=2">EM相册调用</a>
<?php if(isset($_GET['active_save'])):?><span class="actived">保存成功</span><?php endif;?>
</div>
<form action="./plugin.php?plugin=kl_data_call&action=setting&act=<?php echo $act; ?>" method="POST">
<input type="hidden" id="kl_t" name="kl_t" value="1">
<table width="100%" border="0" cellpadding="0" cellspacing="1" class="table_b">
<tr><td align="left" width="120">ID1：</td><td><input id="did" name="did" style="padding:2px; border:1px solid; border-color:#666 #ccc #ccc #666; background:#F9F9F9; color:#333;" onFocus="this.blur()" type="text" value="<?php echo $did; ?>" /><font color="green"> * 此ID由系统自动分配。</font></td></tr>
<tr><td align="left">描述：</td><td><input id="description" name="description" type="text" value="<?php if(isset($moudle['description'])) echo $moudle['description']; ?>" /> <font color="green"> * 请输入适当的描述，以利于数据管理。</font></td></tr>
<tr><td align="left">个人定制：</td><td><input id="custom_tailor" name="custom_tailor" type="text" value="<?php echo isset($moudle['custom_tailor']) ? $moudle['custom_tailor'] : ''; ?>" /><font color="green"> * 此选项可以填入要调用的<strong>微语id</strong>,用<strong>半角的逗号(,)</strong>分隔即可，如(20,15,16,25)。</font><font color="red">(优先级：高)</font></td></tr>
<tr><td align="left">可用的变量：</td><td>自增ID{auto_id}, 微语内容{content}, 时间{date}, 作者{author}, 回复数{replaynum}, <br />微语中的图片地址(缩略){thum_imageurl}, 微语中的图片地址(原图){imageurl}</td></tr>
<tr><td align="left">数据调用模版：</td><td><textarea id="code" name="code" rows="5" style="width:500px;"><?php if(isset($moudle['code'])) echo base64_decode($moudle['code']); ?></textarea></td></tr>
<tr><td align="left">数据的起始行数：</td><td><input id="start_num" name="start_num" type="text" value="<?php echo isset($moudle['start_num']) ? $moudle['start_num'] : 0; ?>" /></td></tr>
<tr><td align="left">数据的显示条数：</td><td><input id="dis_rows" name="dis_rows" type="text" value="<?php echo isset($moudle['dis_rows']) ? $moudle['dis_rows'] : 10; ?>" /></td></tr>
<tr><td align="left">数据的缓存时间(秒)：</td><td><input id="cache_limit" name="cache_limit" type="text" value="<?php echo isset($moudle['cache_limit']) ? $moudle['cache_limit'] : 300; ?>" /></td></tr>
<tr><td align="left">作者：</td><td><select id="author" name="author"><?php echo $author_option_str; ?></select></td></tr>
<tr><td align="left">数据范围(图片)：</td><td><select id="is_include_img" name="is_include_img"><?php echo $is_include_img_option_str; ?></select></td></tr>
<tr><td align="left">排序方式：</td><td><select id="order_style" name="order_style"><?php echo $order_style_option_str; ?></select> * 设置随机时请将数据缓存时间设置为0</td></tr>
<tr><td align="left">时间样式：</td><td><select id="date_style" name="date_style"><?php echo $date_style_option_str; ?></select></td></tr>
<tr><td align="left">内部调用方法：</td><td><div style="position:relative;"><input type="text" id="internal_call_function" name="internal_call_function" value="kl_data_call_for_internal(<?php echo $did; ?>)" style="width:200px;padding:2px; border:1px solid; border-color:#666 #ccc #ccc #666; background:#F9F9F9; color:#333;" onfocus="this.select()" /></div></td></tr>
<tr><td align="left">外部html调用方法：</td><td><div style="position:relative;"><input type="text" id="external_html_call_function" name="external_html_call_function" value="<?php echo BLOG_URL; ?>content/plugins/kl_data_call/kl_data_call_do.php?callback=html&ID=<?php echo $did; ?>" style="width:500px;padding:2px; border:1px solid; border-color:#666 #ccc #ccc #666; background:#F9F9F9; color:#333;" onfocus="this.select()" /></div></td></tr>
<tr><td align="left">外部js调用方法：</td><td><div style="position:relative;"><textarea id="external_js_call_function" name="external_js_call_function" style="width:500px;padding:2px; border:1px solid; border-color:#666 #ccc #ccc #666; background:#F9F9F9; color:#333;" onfocus="this.select()"><script charset="utf-8" type="text/javascript" src="<?php echo BLOG_URL; ?>content/plugins/kl_data_call/kl_data_call_do.php?ID=<?php echo $did; ?>"></script></textarea></div></td></tr>
<tr><td align="left">预览区域：</td><td><div id="preview" style="width:485px; padding:10px; border:1px dashed #ccc; height:100px;overflow:auto;/*background-color:#bbd9e2;*/"></div></td></tr>
<tr><td align="left">操作：</td><td><input id="preview_do" type="button" value="预览" /> <input id="save" type="submit" value="确认提交" /><input type="hidden" id="ajaxUrl" name="ajaxUrl" value="<?php echo BLOG_URL; ?>content/plugins/kl_data_call/kl_data_call_preview.php"></td></tr>
</table>
</form>
<?php
	}elseif($kl_t == 2){
?>
<div class="containertitle2">
<a class="navi1" href="?plugin=kl_data_call">调用列表</a>
<a class="navi4" href="?plugin=kl_data_call&act=add">文章调用</a>
<a class="navi4" href="?plugin=kl_data_call&act=add&kl_t=1">微语调用</a>
<a class="navi3" href="?plugin=kl_data_call&act=add&kl_t=2">EM相册调用</a>
<?php if(isset($_GET['active_save'])):?><span class="actived">保存成功</span><?php endif;?>
</div>
<?php
		$active_plugins = Option::get('active_plugins');
		if(!in_array('kl_album/kl_album.php', $active_plugins)) exit('<div style="padding:5px;border:1px dashed #CCC"><span style="color:red;">提示信息：您没有安装或没有开启<a href="http://kller.cn/?post=33" target="_blank">EM相册插件</a>。</span></div>');
		$kl_album_info = Option::get('kl_album_info');
		if(is_null($kl_album_info)) exit('<div style="padding:5px;border:1px dashed #CCC"><span style="color:red;">提示信息：您的EM相册相关数据可能不完整，请尝试禁用再开启<a href="http://kller.cn/?post=33" target="_blank">EM相册插件</a>。</span></div>');
		$kl_album_info = unserialize($kl_album_info);
		if(empty($kl_album_info)) exit('<div style="padding:5px;border:1px dashed #CCC"><span style="color:red;">提示信息：您的EM相册貌似还没有相册哦，请先创建相册再进行调用。</span></div>');
		$kl_album_option_str = '<option value="0">全部相册</option>';
		foreach($kl_album_info as $kl_album){
			$selected = (isset($moudle['kl_album']) && $kl_album['addtime'] == $moudle['kl_album']) ? 'selected' : '';
			$kl_album_option_str .= "<option value=\"{$kl_album['addtime']}\" {$selected}>{$kl_album['name']}</option>";
		}

		$order_style_arr = array('与相册一致', '发布时间倒序', '随机');
		$order_style_option_str = '';
		foreach($order_style_arr as $value=>$order_style)
		{
			$selected = (isset($moudle['order_style']) && $value == $moudle['order_style']) ? 'selected' : '';
			$order_style_option_str .= "<option value=\"{$value}\" {$selected}>{$order_style}</option>";
		}

		$date_style_arr = array('2010-1-1', '2010-01-01', '2010年1月1日', '2010年01月01日', '2010-1-1 0:00', '2010-01-01 00:00', '2010-1-1 0:00:00', '2010-01-01 00:00:00', '2010-1-1 0:00 Friday', '2010-01-01 00:00 Friday');
		$date_style_option_str = '';
		foreach($date_style_arr as $value=>$date_style)
		{
			$selected = (isset($moudle['date_style']) && $value == $moudle['date_style']) ? 'selected' : '';
			$date_style_option_str .= "<option value=\"{$value}\" {$selected}>{$date_style}</option>";
		}
?>
<form action="./plugin.php?plugin=kl_data_call&action=setting&act=<?php echo $act; ?>" method="POST">
<input type="hidden" id="kl_t" name="kl_t" value="2">
<table width="100%" border="0" cellpadding="0" cellspacing="1" class="table_b">
<tr><td align="left" width="120">ID2：</td><td><input id="did" name="did" style="padding:2px; border:1px solid; border-color:#666 #ccc #ccc #666; background:#F9F9F9; color:#333;" onFocus="this.blur()" type="text" value="<?php echo $did; ?>" /><font color="green"> * 此ID由系统自动分配。</font></td></tr>
<tr><td align="left">描述：</td><td><input id="description" name="description" type="text" value="<?php if(isset($moudle['description'])) echo $moudle['description']; ?>" /> <font color="green"> * 请输入适当的描述，以利于数据管理。</font></td></tr>
<tr><td align="left">相册：</td><td><select id="em_album" name="em_album"><?php echo $kl_album_option_str; ?></select></td></tr>
<tr><td align="left">可用的变量：</td><td>自增ID{auto_id}, 相册名称{album_name}, 相册描述{album_description}, 相册创建时间{album_datetime}, 相册地址{album_url}<br />图片地址(缩略){thum_photo_url}, 图片地址(原图){photo_url}图片描述{photo_description}, 图片创建时间{photo_datetime}, 相册封面{album_cover}</td></tr>
<tr><td align="left">数据调用模版：</td><td><textarea id="code" name="code" rows="5" style="width:500px;"><?php if(isset($moudle['code'])) echo base64_decode($moudle['code']); ?></textarea></td></tr>
<tr><td align="left">数据的起始行数：</td><td><input id="start_num" name="start_num" type="text" value="<?php echo isset($moudle['start_num']) ? $moudle['start_num'] : 0; ?>" /></td></tr>
<tr><td align="left">数据的显示条数：</td><td><input id="dis_rows" name="dis_rows" type="text" value="<?php echo isset($moudle['dis_rows']) ? $moudle['dis_rows'] : 10; ?>" /></td></tr>
<tr><td align="left">数据的缓存时间(秒)：</td><td><input id="cache_limit" name="cache_limit" type="text" value="<?php echo isset($moudle['cache_limit']) ? $moudle['cache_limit'] : 300; ?>" /></td></tr>
<tr><td align="left">排序方式：</td><td><select id="order_style" name="order_style"><?php echo $order_style_option_str; ?></select> * 设置随机时请将数据缓存时间设置为0</td></tr>
<tr><td align="left">时间样式：</td><td><select id="date_style" name="date_style"><?php echo $date_style_option_str; ?></select></td></tr>
<tr><td align="left">内部调用方法：</td><td><div style="position:relative;"><input type="text" id="internal_call_function" name="internal_call_function" value="kl_data_call_for_internal(<?php echo $did; ?>)" style="width:200px;padding:2px; border:1px solid; border-color:#666 #ccc #ccc #666; background:#F9F9F9; color:#333;" onfocus="this.select()" /></div></td></tr>
<tr><td align="left">外部html调用方法：</td><td><div style="position:relative;"><input type="text" id="external_html_call_function" name="external_html_call_function" value="<?php echo BLOG_URL; ?>content/plugins/kl_data_call/kl_data_call_do.php?callback=html&ID=<?php echo $did; ?>" style="width:500px;padding:2px; border:1px solid; border-color:#666 #ccc #ccc #666; background:#F9F9F9; color:#333;" onfocus="this.select()" /></div></td></tr>
<tr><td align="left">外部js调用方法：</td><td><div style="position:relative;"><textarea id="external_js_call_function" name="external_js_call_function" style="width:500px;padding:2px; border:1px solid; border-color:#666 #ccc #ccc #666; background:#F9F9F9; color:#333;" onfocus="this.select()"><script charset="utf-8" type="text/javascript" src="<?php echo BLOG_URL; ?>content/plugins/kl_data_call/kl_data_call_do.php?ID=<?php echo $did; ?>"></script></textarea></div></td></tr>
<tr><td align="left">预览区域：</td><td><div id="preview" style="width:485px; padding:10px; border:1px dashed #ccc; height:100px;overflow:auto;/*background-color:#bbd9e2;*/"></div></td></tr>
<tr><td align="left">操作：</td><td><input id="preview_do" type="button" value="预览" /> <input type="submit" value="确认提交" /><input type="hidden" id="ajaxUrl" name="ajaxUrl" value="<?php echo BLOG_URL; ?>content/plugins/kl_data_call/kl_data_call_preview.php"></td></tr>
</table>
</form>
<?php
	}else{
		$user_cache = $CACHE->readCache('user');
		$author_option_str = '<option value="0">全部</option>';
		foreach($user_cache as $uk=>$user){
			$selected = (isset($moudle['author']) && $uk == $moudle['author']) ? 'selected' : '';
			$author_option_str .= "<option value=\"{$uk}\" {$selected}>{$user['name']}</option>";
		}

		$sort_cache = $CACHE->readCache('sort');
		$log_cache_tags = $CACHE->readCache('logtags');
		$sort_cache[0] = array('sortname'=>'未分类', 'sid'=>0);
		sort($sort_cache);
		$sort_option_str = '';
		foreach($sort_cache as $sort)
		{
			$selected = (isset($moudle['sort']) && $sort['sid'] == $moudle['sort']) ? 'selected' : '';
			$sort_option_str .= "<option value=\"{$sort['sid']}\" {$selected}>{$sort['sortname']}</option>";
		}

		$filter_arr = array('全部文章', '仅置顶文章', '非置顶文章');
		$filter_option_str = '';
		foreach($filter_arr as $value=>$filter)
		{
			$selected = (isset($moudle['filter']) && $value == $moudle['filter']) ? 'selected' : '';
			$filter_option_str .= "<option value=\"{$value}\" {$selected}>{$filter}</option>";
		}

		$is_include_img_arr = array('全部文章', '仅显示有图片的文章', '仅显示没有图片的文章');
		$is_include_img_option_str = '';
		foreach($is_include_img_arr as $value=>$is_include_img)
		{
			$selected = (isset($moudle['is_include_img']) && $value == $moudle['is_include_img']) ? 'selected' : '';
			$is_include_img_option_str .= "<option value=\"{$value}\" {$selected}>{$is_include_img}</option>";
		}

		$link_style_arr = array('<没有设置>', '新窗口(_blank)', '本窗口(_self)');
		$link_style_option_str = '';
		foreach($link_style_arr as $value=>$link_style)
		{
			$selected = (isset($moudle['link_style']) && $value == $moudle['link_style']) ? 'selected' : '';
			$link_style_option_str .= "<option value=\"{$value}\" {$selected}>{$link_style}</option>";
		}

		$order_style_arr = array('发布时间倒序', '评论数倒序', '浏览次数倒序排列', '随机');
		$order_style_option_str = '';
		foreach($order_style_arr as $value=>$order_style)
		{
			$selected = (isset($moudle['order_style']) && $value == $moudle['order_style']) ? 'selected' : '';
			$order_style_option_str .= "<option value=\"{$value}\" {$selected}>{$order_style}</option>";
		}

		$date_style_arr = array('2010-1-1', '2010-01-01', '2010年1月1日', '2010年01月01日', '2010-1-1 0:00', '2010-01-01 00:00', '2010-1-1 0:00:00', '2010-01-01 00:00:00', '2010-1-1 0:00 Friday', '2010-01-01 00:00 Friday');
		$date_style_option_str = '';
		foreach($date_style_arr as $value=>$date_style)
		{
			$selected = (isset($moudle['date_style']) && $value == $moudle['date_style']) ? 'selected' : '';
			$date_style_option_str .= "<option value=\"{$value}\" {$selected}>{$date_style}</option>";
		}
?>
<div class="containertitle2">
<a class="navi1" href="?plugin=kl_data_call">调用列表</a>
<a class="navi3" href="?plugin=kl_data_call&act=add">文章调用</a>
<a class="navi4" href="?plugin=kl_data_call&act=add&kl_t=1">微语调用</a>
<a class="navi4" href="?plugin=kl_data_call&act=add&kl_t=2">EM相册调用</a>
<?php if(isset($_GET['active_save'])):?><span class="actived">保存成功</span><?php endif;?>
</div>
<form action="./plugin.php?plugin=kl_data_call&action=setting&act=<?php echo $act; ?>" method="POST">
<input type="hidden" id="kl_t" name="kl_t" value="0">
<table width="100%" border="0" cellpadding="0" cellspacing="1" class="table_b">
<tr><td align="left" width="120">ID0：</td><td><input id="did" name="did" style="padding:2px; border:1px solid; border-color:#666 #ccc #ccc #666; background:#F9F9F9; color:#333;" onFocus="this.blur()" type="text" value="<?php echo $did; ?>" /><font color="green"> * 此ID由系统自动分配。</font></td></tr>
<tr><td align="left">描述：</td><td><input id="description" name="description" type="text" value="<?php if(isset($moudle['description'])) echo $moudle['description']; ?>" /> <font color="green"> * 请输入适当的描述，以利于数据管理。</font></td></tr>
<tr><td align="left">所在分类：</td><td>
<select name="sort" id="sort">
<option value="-1">所有分类</option><?php echo $sort_option_str ?></select></td></tr>
<tr><td align="left">个人定制：</td><td><input id="custom_tailor" name="custom_tailor" type="text" value="<?php echo isset($moudle['custom_tailor']) ? $moudle['custom_tailor'] : ''; ?>" /><font color="green"> * 此选项可以填入要调用的<strong>文章id</strong>,用<strong>半角的逗号(,)</strong>分隔即可，如(20,15,16,25)。</font><font color="red">(优先级：高)</font></td></tr>
<tr><td align="left">可用的变量：</td><td>文章链接{log_url}, 标题{title}, 不带链接的标题{title_without_link}, 摘要{excerpt}, 带阅读全文的摘要{excerpt_include_readmore}<br />自增ID{auto_id}, 时间{date}, 所属分类{sort}, 作者{author}, 浏览次数{views}, 评论数{comment_count}<br />文章中第一张图片：不带链接的{image}, 带链接的{image_include_link}, 图片地址{imageurl}</td></tr>
<tr><td align="left">数据调用模版：</td><td><textarea id="code" name="code" rows="5" style="width:500px;"><?php if(isset($moudle['code'])) echo base64_decode($moudle['code']); ?></textarea></td></tr>
<tr><td align="left">数据的起始行数：</td><td><input id="start_num" name="start_num" type="text" value="<?php echo isset($moudle['start_num']) ? $moudle['start_num'] : 0; ?>" /></td></tr>
<tr><td align="left">数据的显示条数：</td><td><input id="dis_rows" name="dis_rows" type="text" value="<?php echo isset($moudle['dis_rows']) ? $moudle['dis_rows'] : 10; ?>" /></td></tr>
<tr><td align="left">数据的缓存时间(秒)：</td><td><input id="cache_limit" name="cache_limit" type="text" value="<?php echo isset($moudle['cache_limit']) ? $moudle['cache_limit'] : 300; ?>" /></td></tr>
<tr><td align="left">作者：</td><td><select id="author" name="author"><?php echo $author_option_str; ?></select></td></tr>
<tr><td align="left">数据范围一(置顶)：</td><td><select id="filter" name="filter"><?php echo $filter_option_str; ?></select>　　　　　　<label><input id="nopwd" name="nopwd" type="checkbox" value="1" <?php if(isset($moudle['nopwd']) && $moudle['nopwd'] == 1) echo 'checked'; ?>/>不包含密码访问的文章</label></td></tr>
<tr><td align="left">数据范围二(图片)：</td><td><select id="is_include_img" name="is_include_img"><?php echo $is_include_img_option_str; ?></select></td></tr>
<tr><td align="left">链接打开方式：</td><td><select id="link_style" name="link_style"><?php echo $link_style_option_str; ?></select></td></tr>
<tr><td align="left">排序方式：</td><td><select id="order_style" name="order_style"><?php echo $order_style_option_str; ?></select> * 设置随机时请将数据缓存时间设置为0</td></tr>
<tr><td align="left">时间样式：</td><td><select id="date_style" name="date_style"><?php echo $date_style_option_str; ?></select></td></tr>
<tr><td align="left">内部调用方法：</td><td><div style="position:relative;"><input type="text" id="internal_call_function" name="internal_call_function" value="kl_data_call_for_internal(<?php echo $did; ?>)" style="width:200px;padding:2px; border:1px solid; border-color:#666 #ccc #ccc #666; background:#F9F9F9; color:#333;" onfocus="this.select()" /></div></td></tr>
<tr><td align="left">外部html调用方法：</td><td><div style="position:relative;"><input type="text" id="external_html_call_function" name="external_html_call_function" value="<?php echo BLOG_URL; ?>content/plugins/kl_data_call/kl_data_call_do.php?callback=html&ID=<?php echo $did; ?>" style="width:500px;padding:2px; border:1px solid; border-color:#666 #ccc #ccc #666; background:#F9F9F9; color:#333;" onfocus="this.select()" /></div></td></tr>
<tr><td align="left">外部js调用方法：</td><td><div style="position:relative;"><textarea id="external_js_call_function" name="external_js_call_function" style="width:500px;padding:2px; border:1px solid; border-color:#666 #ccc #ccc #666; background:#F9F9F9; color:#333;" onfocus="this.select()"><script charset="utf-8" type="text/javascript" src="<?php echo BLOG_URL; ?>content/plugins/kl_data_call/kl_data_call_do.php?ID=<?php echo $did; ?>"></script></textarea></div></td></tr>
<tr><td align="left">预览区域：</td><td><div id="preview" style="width:485px; padding:10px; border:1px dashed #ccc; height:100px;overflow:auto;/*background-color:#bbd9e2;*/"></div></td></tr>
<tr><td align="left">操作：</td><td><input id="preview_do" type="button" value="预览" /> <input id="save" type="submit" value="保存" /><input type="hidden" id="ajaxUrl" name="ajaxUrl" value="<?php echo BLOG_URL; ?>content/plugins/kl_data_call/kl_data_call_preview.php"></td></tr>
</table>
</form>
<?php
	}
}
function plugin_setting()
{
	$act = isset($_GET['act']) ? addslashes(trim($_GET['act'])) : '';
	if($act == 'add' || $act == 'edit')
	{
		$moudle = array();
		$moudle['kl_t'] = intval($_POST['kl_t']);
		if($moudle['kl_t'] == 1){
			$intval_argu_arr1 = array('did'=>'', 'start_num'=>0, 'dis_rows'=>10, 'cache_limit'=>300, 'author'=>0, 'is_include_img'=>0);
			$intval_argu_arr2 = array('order_style', 'date_style');
			foreach($intval_argu_arr1 as $iaak => $iaav) $moudle[$iaak] = trim($_POST[$iaak]) != '' ? intval($_POST[$iaak]) : $iaav;
			foreach($intval_argu_arr2 as $iaav) $moudle[$iaav] = isset($_POST[$iaav]) ? intval($_POST[$iaav]) : 0;
			$moudle['description'] = trim($_POST['description']) != '' ? addslashes($_POST['description']) : '';
			$moudle['code'] = isset($_POST['code']) ? base64_encode($_POST['code']) : '';
			$moudle['custom_tailor'] = trim($_POST['custom_tailor']) != '' ? addslashes(trim($_POST['custom_tailor'])) : '';
		}elseif($moudle['kl_t'] == 2){
			$intval_argu_arr1 = array('did'=>'', 'start_num'=>0, 'dis_rows'=>10, 'cache_limit'=>300, 'em_album'=>0);
			$intval_argu_arr2 = array('order_style', 'date_style');
			foreach($intval_argu_arr1 as $iaak => $iaav) $moudle[$iaak] = trim($_POST[$iaak]) != '' ? intval($_POST[$iaak]) : $iaav;
			foreach($intval_argu_arr2 as $iaav) $moudle[$iaav] = isset($_POST[$iaav]) ? intval($_POST[$iaav]) : 0;
			$moudle['description'] = trim($_POST['description']) != '' ? addslashes($_POST['description']) : '';
			$moudle['code'] = isset($_POST['code']) ? base64_encode($_POST['code']) : '';
		}else{
			$intval_argu_arr1 = array('did'=>'', 'start_num'=>0, 'dis_rows'=>10, 'cache_limit'=>300, 'filter'=>0, 'is_include_img'=>0);
			$intval_argu_arr2 = array('sort', 'nopwd', 'link_style', 'order_style', 'date_style');
			foreach($intval_argu_arr1 as $iaak => $iaav) $moudle[$iaak] = trim($_POST[$iaak]) != '' ? intval($_POST[$iaak]) : $iaav;
			foreach($intval_argu_arr2 as $iaav) $moudle[$iaav] = isset($_POST[$iaav]) ? intval($_POST[$iaav]) : 0;
			$moudle['description'] = trim($_POST['description']) != '' ? addslashes($_POST['description']) : '';
			$moudle['code'] = isset($_POST['code']) ? base64_encode($_POST['code']) : '';
			$moudle['custom_tailor'] = trim($_POST['custom_tailor']) != '' ? addslashes(trim($_POST['custom_tailor'])) : '';
		}
		$data = serialize($moudle);
		global $CACHE;
		$DB = MySql::getInstance();
		$CACHE->updateCache('options');
		$kl_data_call_info = Option::get('kl_data_call_'.$moudle['did']);
		if(is_null($kl_data_call_info)){
			$DB->query("INSERT INTO ".DB_PREFIX."options(option_name, option_value) VALUES('kl_data_call_{$moudle['did']}', '{$data}')");
		}else{
			$DB->query("UPDATE ".DB_PREFIX."options SET option_value='{$data}' WHERE option_name='kl_data_call_{$moudle['did']}'");
		}
		$CACHE->updateCache('options');
		kl_data_call_main_fun($moudle);
		emDirect("./plugin.php?plugin=kl_data_call&act=edit&id={$moudle['did']}&active_save=1");
	}elseif($act == 'del'){
		$id = intval($_GET['id']);
		$DB = MySql::getInstance();
		$DB->query("DELETE FROM ".DB_PREFIX."options WHERE option_name='kl_data_call_{$id}'");
		global $CACHE;
		$CACHE->updateCache('options');
		@unlink(KL_DATA_CALL_CACHE_DIR.'/'.$id.'.php');
		emDirect("./plugin.php?plugin=kl_data_call&active_del=1");
	}

	if(isset($_GET['update']) && $_GET['update'] == 'true')
	{
		global $CACHE;
		$options_cache = $CACHE->readCache('options');
		$data_call_moudle_config = array();
		foreach($options_cache as $ock=>$ocv){
			if(preg_match('/^kl_data_call_(\d+)$/', $ock)) kl_data_call_main_fun(unserialize($ocv));
		}
	}
	emDirect("./plugin.php?plugin=kl_data_call&active_update=1");
}
?>