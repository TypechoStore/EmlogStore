<?php
/**
 * kl_data_call_callback.php
 * design by KLLER
 */
function callback_init()
{
	global $CACHE;
	$CACHE->updateCache('options');
	$kl_data_call_info = Option::get('kl_data_call_info');
	if(is_null($kl_data_call_info)){
		$info = serialize(array('version'=>'2.0'));
		$DB = MySql::getInstance();
		$DB->query("INSERT INTO ".DB_PREFIX."options(option_name, option_value) VALUES('kl_data_call_info', '{$info}')");
		if($DB->affected_rows() > 0){
			$config_dir = EMLOG_ROOT.'/content/plugins/kl_data_call/config/';
			$cod = @opendir($config_dir);
			$didArr = array();
			while(($filename = readdir($cod)) !== false){
				$filename = str_replace('.php', '', $filename);
				if(is_numeric($filename)) $didArr[] = $filename;
			}
			@closedir($cod);
			if(empty($didArr)) return;
			foreach($didArr as $did){
				$kl_data_call_id = Option::get('kl_data_call_'.$did);
				if(is_null($kl_data_call_id)){
					$data = str_replace('<?php exit;//', '', @file_get_contents($config_dir.$did.'.php'));
					$DB->query("INSERT INTO ".DB_PREFIX."options(option_name, option_value) VALUES('kl_data_call_{$did}', '{$data}')");
				}
			}
		}
		$CACHE->updateCache('options');
	}
}

function callback_rm(){}