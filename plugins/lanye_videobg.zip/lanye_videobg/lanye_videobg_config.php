<?php
$config = array(
"videobg_jq" => "2",
"videobg_bg" => "1",
"videobg_tm" => "0.5",
"videobg_webm" => "http://localhost/content/plugins/lanye_videobg/images/videobg.webm",
"videobg_mp4" => "http://localhost/content/plugins/lanye_videobg/images/videobg.mp4"
);