<?php
session_start();
!defined('EMLOG_ROOT') && exit('access deined!');
include EMLOG_ROOT.'/init.php';
include EMLOG_ROOT.'/content/plugins/gbook/lib/function.php';
include EMLOG_ROOT.'/content/plugins/gbook/lib/option.class.php';
include EMLOG_ROOT.'/content/plugins/gbook/lib/gbook.class.php';

?>