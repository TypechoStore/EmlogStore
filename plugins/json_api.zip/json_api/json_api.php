<?php
/*
Plugin Name: JSON API
Version: 20150407 v1.0
Plugin URL: http://github.com/johnlui/JSON-API-for-Emlog
Description: 强大的 JSON 格式的数据输出插件，使用方法详见Github更多信息。
Author: JohnLui
Author Email: wenhanlv@gmail.com
Author URL: http://lvwenhan.com
*/
!defined('EMLOG_ROOT') && exit('access deined!');