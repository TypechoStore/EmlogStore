<?php
/**
* Option Model
*/
class Option extends Illuminate\Database\Eloquent\Model {
  public $timestamps = false;
}