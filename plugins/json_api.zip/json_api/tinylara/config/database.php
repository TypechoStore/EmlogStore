<?php

return [
  'driver'    => 'mysql',
  'host'      => DB_HOST,
  'database'  => DB_NAME,
  'username'  => DB_USER,
  'password'  => DB_PASSWD,
  'charset'   => 'utf8',
  'collation' => 'utf8_general_ci',
  'prefix'    => DB_PREFIX
  ];