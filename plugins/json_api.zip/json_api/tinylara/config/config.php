<?php

return [
  'base_url' => '/',
  'time_zone' => 'UTC', // China use 'Asia/Shanghai'
];