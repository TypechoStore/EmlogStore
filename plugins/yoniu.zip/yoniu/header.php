<?php
/*
Template Name:Yoniu
Description:双栏响应式清新个人模板，建议新手不要随便修改模板文件
Version:1.1
Author:小智
Author Url:http://www.200011.net
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
require_once View::getView('breadcrumb');
$sta_cache = Cache::getInstance()->readCache('sta');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link rel="stylesheet" href="<?php echo TEMPLATE_URL; ?>css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo TEMPLATE_URL; ?>css/prettify.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>yoniu.css?v1.1" rel="stylesheet" type="text/css" />
<script src="<?php echo TEMPLATE_URL; ?>js/prettify.js" type="text/javascript"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/jquery-1.9.1.min.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/bootstrap.min.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/jquery.ias.min.js" type="text/javascript"></script>
<script src="<?php echo TEMPLATE_URL; ?>js/jquery-migrate.min.js"></script>
<script>themeurl="<?php echo TEMPLATE_URL; ?>";</script>
<script src="<?php echo TEMPLATE_URL; ?>js/yoniu.js"></script>
<?php doAction('index_head'); ?>
</head>
<body>
	<nav class="navbar navbar-default">
		<div class="container">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="<?php echo BLOG_URL; ?>"><span id="navicospan" class="glyphicon glyphicon-globe" aria-hidden="true"></span><?php echo $blogname; ?></a>
			</div>
			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav navbar-right">
					<?php blog_navi();?>
				</ul>
			</div><!-- /.navbar-collapse -->
		</div><!-- /.container-fluid -->
	</nav>
<div class="container">
<div id="wrap">
	<div class="header-img">
		<div class="bloggerinfoimg">
			<?php index_blogger(); ?>
			<h3><?php echo $blogname; ?></h3>
			<span class="des"><?php echo $bloginfo; ?></span>
		</div>
	</div>
	<div class="sort-nav">
		<div class="row">
		<?php if(ROLE == ROLE_ADMIN){ ?>
			<div class="col-xs-4"><h4><a href="<?php echo BLOG_URL; ?>admin/write_log.php">发布文章</span></a></h4></div>
			<div class="col-xs-4"><h4><a href="<?php echo BLOG_URL; ?>admin/twitter.php">发布微语</span></a></h4></div>
			<div class="col-xs-4"><h4><a id="yoniu_setting" href="" data-toggle="modal" data-target="#setting">模板设置</a></h4></div>
			<div class="modal fade" id="setting" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<h4 class="modal-title" id="myModalLabel">模板设置</h4>
						</div>
						<div class="modal-body">
							<div class="input-group youyou">
								<label for="navico" class="input-group-addon">导航图标</label>
								<input type="text" id="navico" class="form-control" name="navico" value="" tabindex="1">
							</div>
								<samp>顶部导航条博客名称前的图标代码，格式（glyphicon glyphicon-globe）<br /><a href="https://v3.bootcss.com/components/#glyphicons">《Glyphicons 字体图标》</a><br /></samp>
							<div class="input-group youyou">
								<label for="header" class="input-group-addon">顶部图片</label>
								<input type="text" id="header" class="form-control" name="header" value="" tabindex="2">
							</div>
								<samp>顶部图片格式：<?php echo TEMPLATE_URL; ?>images/header.jpg<br /></samp>
							<div class="input-group youyou">
								<label for="background" class="input-group-addon">背景图片</label>
								<input type="text" id="background" class="form-control" name="background" value="" tabindex="3">
							</div>
								<samp>背景图片一般不设置，格式与顶部图片格式相同<br /></samp>
							<div class="input-group youyou">
								<label>
									<input id="ias" type="radio" name="ias" value="1" />使用ias  <input id="ias" type="radio" name="ias" value="0"/>关闭ias
								</label>
							</div>
								<samp><a href="https://www.200011.net/emlog/100.html">《EMLOG文章分页Ajax无限加载》</a></samp>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
							<button id="save_setting" type="button" class="btn btn-primary">保存设置</button>
						</div>
					</div>
				</div>
			</div>
<script>
$(document).ready(function(){
	$("#yoniu_setting").click(function(){
		$.getJSON("<?php echo TEMPLATE_URL; ?>setting.php?check=read",function(json){
			if(json.emMsg=="success"){
				$("#navico").val(json.navico);
				$("#header").val(json.header);
				$("#background").val(json.background);
				$(":radio[name='ias'][value='" + json.ias + "']").prop("checked", true);
			}else{
				$(".modal-body").append("<div class='alert alert-danger' role='alert'>加载失败（或配置文件不存在，第一次使用模板忽略）</div>");
			}
		});
	});
	$("#save_setting").click(function(){
		alert($("#ias:checked").val());
		$.post("<?php echo TEMPLATE_URL; ?>setting.php?check=save",
		{
			navico:$("#navico").val(),
			header:$("#header").val(),
			background:$("#background").val(),
			ias:$("#ias:checked").val()
		},
		function(data,status){
			if(status=="success"){
				obj = JSON.parse(data);
				if(obj.emMsg=="success"){
					$(".modal-body").append("<div class='alert alert-success' role='alert'>保存完成</div>");
				}else{
					$(".modal-body").append("<div class='alert alert-danger' role='alert'>保存失败</div>");
				}
			}else{$(".modal-body").append("<div class='alert alert-danger' role='alert'>保存失败</div>");}
		});
	});
});
</script>
		<?php }else{ ?>
			<div class="col-xs-4"><h4>文章<span class="label label-info"><?php echo $sta_cache['lognum'];?></span></h4></div>
			<div class="col-xs-4"><h4><a href="<?php echo BLOG_URL; ?>t">微语<span class="label label-success"><?php echo $sta_cache['twnum'];?></span></a></h4></div>
			<div class="col-xs-4"><h4>评论<span class="label label-warning"><?php echo $sta_cache['comnum_all'];?></span></h4></div>
		<?php } ?>
		</div>
	</div>