<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="row">
<div class="col-sm-8 blog-main">
<ol class="breadcrumb">
	<?php echo $breadcrumb; ?>
</ol>
<?php doAction('index_loglist_top'); ?>
<?php 
if (!empty($logs)):
foreach($logs as $value): 
$content_img = GetThumFromContent($value['content']);
?>
	<div class="list-article">
		<?php if($content_img):?><a href="<?php echo $value['log_url']; ?>"><div class="article-img" style="background-image: url('<?php echo $content_img; ?>');"><img src="<?php echo TEMPLATE_URL; ?>images/light.png" class="img-responsive"></div><div class="h-gradient"></div></a><div style="clear:both;"></div><?php endif; ?>
		<div class="article-content">
			<div class="article-title"><a href="<?php echo $value['log_url']; ?>"><?php echo $value['log_title']; ?></a></div>
			<div class="article-info">
				<?php blog_author($value['author']); ?> 
				<div class="article-others">发布于</div>
				<div class="article-time"><?php echo gmdate('Y-n-j', $value['date']); ?></div>
			</div>
			<div class="article-contents">
				<?php echo subString(str_replace('阅读全文&gt;&gt;', '', strip_tags(breakLog($value['content'], $value['gid']))),0,200);?>
			</div>
		</div>
	</div>
<?php 
endforeach;
else:
?>
	<div class="list-article">
		<div class="article-content">
			<div class="article-title"><a href="#">未找到</a></div>
			<div class="article-contents">
				抱歉，没有符合您查询条件的结果。
			</div>
		</div>
	</div>
<?php endif;?>

<div id="pagenavi">
<?php  
$page_loglist = my_page($lognum, $index_lognum, $page, $pageurl); 
echo $page_loglist; 
?>
</div>
</div><!-- end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>