<?php 
/**
 * 自建页面模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="row">
<div class="col-sm-8 blog-main">
	<ol class="breadcrumb">
	<?php echo $breadcrumb; ?>
	</ol>
	<div class="article-page">
		<div class="article-title"><?php echo $log_title; ?></div>
		<div class="article-info">
			<?php blog_author($author); ?> 
			<div class="article-others">发布于</div>
			<div class="article-time"><?php echo gmdate('Y-n-j', $date); ?></div>
			<?php blog_sort($logid); ?>
			<?php editflg($logid,$author); ?>
		</div>
		<div class="article-contents">
			<?php echo $log_content; ?>
		</div>
	</div>
	<?php if($allow_remark == 'y'):?>
	<div class="article-comments">
		<div class="article-title">评论(<?php echo $comnum;?>)</div>
		<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
		<?php blog_comments($comments); ?>
	</div>
	<?php endif;?>
</div><!--end #contentleft-->
<?php
 include View::getView('side');
 include View::getView('footer');
?>