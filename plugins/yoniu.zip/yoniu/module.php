<?php 
/**
 * 侧边栏组件、页面模块
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
function GetFaceImg(){
		$Face = array(array('url' => 'images/face/wx.png',
						'title' =>  "微笑") ,
				  array('url' => 'images/face/dy.png',
						'title' => "得意" ) ,
				  array('url' => 'images/face/fn.png',
						'title' =>"愤怒") ,
				  array('url' => 'images/face/dk.png',
						'title' => "大哭" ) ,
				  array('url' => 'images/face/h.png',
						'title' =>"汗"  ) ,
				  array('url' => 'images/face/bs.png',
						'title' => "鄙视" ) ,
				  array('url' => 'images/face/zb.png',
						'title' =>  "真棒") ,
				  array('url' => 'images/face/db.png',
						'title' => "大便" ) ,
				  array('url' => 'images/face/wcb.png',
						'title' => "我超棒" ) ,
				  array('url' => 'images/face/xk.png',
						'title' =>  "笑哭") ,
				  array('url' => 'images/face/t.png',
						'title' =>"吐") ,
				  array('url' => 'images/face/ka.png',
						'title' =>"可爱") ,
				  array('url' => 'images/face/hj.png',
						'title' => "滑稽" ) ,
				  array('url' => 'images/face/k.png',
						'title' => "酷") ,
				  array('url' => 'images/face/p.png',
						'title' => "喷") ,
				  array('url' => 'images/face/yw.png',
						'title' =>"疑问") ,
				  array('url' => 'images/face/cg.png',
						'title' => "吃瓜" ) ,
				  array('url' => 'images/face/tx.png',
						'title' => "调戏" ) ,
				  array('url' => 'images/face/ax.png',
						'title' => "爱心" ) ,
				  array('url' => 'images/face/xs.png',
						'title' => "心碎" )
				  );
	foreach ($Face as $key => $value) {
			$faceimg=TEMPLATE_URL.$value["url"];
			$tooltip='['.$value["title"].']';
			echo "<a href='javascript:;' title='$tooltip' data-title='$tooltip'><img width='24px' height='24px' src='{$faceimg}'></a>";
	}
}
?>
<?php
function comment2emoji($str) {
		$data = array(array('url' => 'images/face/wx.png',
						'title' =>  "微笑") ,
				  array('url' => 'images/face/dy.png',
						'title' => "得意" ) ,
				  array('url' => 'images/face/fn.png',
						'title' =>"愤怒") ,
				  array('url' => 'images/face/dk.png',
						'title' => "大哭" ) ,
				  array('url' => 'images/face/h.png',
						'title' =>"汗"  ) ,
				  array('url' => 'images/face/bs.png',
						'title' => "鄙视" ) ,
				  array('url' => 'images/face/zb.png',
						'title' =>  "真棒") ,
				  array('url' => 'images/face/db.png',
						'title' => "大便" ) ,
				  array('url' => 'images/face/wcb.png',
						'title' => "我超棒" ) ,
				  array('url' => 'images/face/xk.png',
						'title' =>  "笑哭") ,
				  array('url' => 'images/face/t.png',
						'title' =>"吐") ,
				  array('url' => 'images/face/ka.png',
						'title' =>"可爱") ,
				  array('url' => 'images/face/hj.png',
						'title' => "滑稽" ) ,
				  array('url' => 'images/face/k.png',
						'title' => "酷") ,
				  array('url' => 'images/face/p.png',
						'title' => "喷") ,
				  array('url' => 'images/face/yw.png',
						'title' =>"疑问") ,
				  array('url' => 'images/face/cg.png',
						'title' => "吃瓜" ) ,
				  array('url' => 'images/face/tx.png',
						'title' => "调戏" ) ,
				  array('url' => 'images/face/ax.png',
						'title' => "爱心" ) ,
				  array('url' => 'images/face/xs.png',
						'title' => "心碎" )
				  );
	foreach($data as $key=>$value) {
		$str = str_replace('['.$value['title'].']','<img width="24px" height="24px" class="comment_face" src="'.TEMPLATE_URL.$value['url'].'" title="'.$value['title'].'">',$str);
	}
	return $str;
}
?>
<?php 
//blog：自定义分页函数 
function my_page($count, $perlogs, $page, $url, $anchor = '') { 
 $pnums = @ceil($count / $perlogs); 
 $re = ''; 
 $urlHome = preg_replace("|[?&/][^./?&=]*page[=/-]|", "", $url); 
 if($page > 1) { 
  $i = $page - 1; 
  $re = ' <a class="button button--small" href="'.$url.$i.'">上一页</a> ' . $re; 
 } 
 if($page < $pnums) { 
  $i = $page + 1; 
  $re .= ' <a id="fynext" class="button button--small" id="fynext" href="'.$url.$i.'">下一页</a> '; 
 } 
 return $re; 
} 
?>
<?php
//header
function index_blogger(){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
	<?php if (!empty($user_cache[1]['photo']['src'])): ?>
	<img class="img-circle img-thumbnail" src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="128px" height="128px" alt="blogger" />
	<?php endif;?>
<?php }?>
<?php
function GetThumFromContent($content){
	/*图片和摘要*/
	preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $content, $img);
	if($imgsrc = !empty($img[1])){
		 $imgsrc = $img[1][0];}else{ 
			preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $content ,$img);
			if($imgsrc = !empty($img[1])){ $imgsrc = $img[1][0];  }else{
				$imgsrc = "";	
			}
	}
	return $imgsrc;
}
?>
<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['mail'] != '' ? "<a href=\"mailto:".$user_cache[1]['mail']."\">".$user_cache[1]['name']."</a>" : $user_cache[1]['name'];?>
	<li>
		<h3><span><?php echo $title; ?></span></h3>
		<div class="media">
			<div class="media-left media-middle">
				<img class="img-circle" src="<?php echo BLOG_URL.$user_cache[1]['photo']['src']; ?>" width="48px" height="48px" alt="blogger" />
			</div>
			<div class="media-body">
				<h4 class="media-heading"><?php echo $user_cache[1]['name']; ?></h4>
				<?php echo $user_cache[1]['des']; ?>
			</div>
		</div>
	</li>
<?php }?>
<?php
//widget：日历
function widget_calendar($title){ ?>
<?php }?>
<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="newcomment">
	<?php foreach($tag_cache as $value): ?>
		<span style="font-size:<?php echo $value['fontsize']; ?>pt; line-height:30px;">
		<a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇文章"><?php echo $value['tagname']; ?></a></span>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：最新微语
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="newcomment">
	<?php
	$mht=0;
	foreach($newtws_cache as $value): 
	$mht=$mht+1;
	?>
	<div class="media" id="<?php if($mht==1) echo 'first'; ?>">
		<div class="media-body">
			<h5 class="media-heading"><?php echo $value['t']; ?></h5>
			<time><?php echo smartDate($value['date']); ?><time>
		</div>
	</div>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="newcomment">
	<?php
	$mht=0;
	foreach($com_cache as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	$mht=$mht+1;
	?>
	<div class="media" id="<?php if($mht==1) echo 'first'; ?>">
		<div class="media-left media-middle">
			<img class="img-circle" src="<?php echo getGravatar($value['mail']); ?>" width="48px" height="48px" alt="blogger" />
		</div>
		<div class="media-body">
			<h5 class="media-heading"><?php echo $value['name']; ?></h5>
			<a href="<?php echo $url; ?>"><?php echo comment2emoji($value['content']); ?></a>
		</div>
	</div>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php //widget：最新文章
function widget_newlog($title){
$index_newlognum = Option::get('index_newlognum');?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="newcomment">
<?php 
	$db = MySql::getInstance();
	$sql = $db->query ("SELECT * FROM ".DB_PREFIX."blog WHERE hide='n' AND type='blog' AND top='n' order by date DESC limit 0,$index_newlognum");
	$mht=0;
	while($row = $db->fetch_array($sql)){
		$mht=$mht+1;
		$logpost = !empty($row['excerpt']) ? $row['excerpt'] : ''.$row['content'].'';
		if (!empty($row['excerpt'])){
			preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['excerpt'], $match);
			if(empty($match[1][0])) {
				preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i",$row['content'],$match);
			}
		}else{
			preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'],$match);
		}
		$date = gmdate('Y年m月d日', $row['date']);
		$content = strip_tags($logpost,'');
		$content_img = GetThumFromContent($row['content']);
		$content = mb_substr($content,0,100,'utf-8');//摘要字数修改本代码中的100这个即可
		$content = subString(str_replace('阅读全文&gt;&gt;', '', strip_tags(breakLog($row['content'], $row['gid']))),0,100);
		$gid = $row['gid'];
?>
		<div class="media" id="<?php if($mht==1) echo 'first'; ?>">
			<?php if($content_img) { ?>
			<div class="media-left">
				<a href="<?php echo Url::log($row['gid']);?>" title="<?php echo $row['title'];?>" /><img src="<?php echo $content_img; ?>" width="100px" height="80px" alt="blogger" /></a>
			</div>
			<?php } ?>
			<div class="media-body">
				<h4 class="media-heading"><a href="<?php echo Url::log($row['gid']);?>" title="<?php echo $row['title'];?>" /><?php echo $row['title'];?></a></h4>
				<?php echo $content;?>
			</div>
		</div>
<?php }?>
	</ul>
	</li>
<?php }?>
<?php //widget：热门文章
function widget_hotlog($title){
	$index_hotlognum = Option::get('index_hotlognum');
?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="newcomment">
<?php
	$db = MySql::getInstance();$db = MySql::getInstance();
	$time = time();
	$sql = $db->query ("SELECT * FROM ".DB_PREFIX."blog WHERE hide='n' AND type='blog' AND top='n' order by `views` DESC limit 0,$index_hotlognum");
	$mht=0;
	while($row = $db->fetch_array($sql)){
		$mht=$mht+1;
		$logpost = !empty($row['excerpt']) ? $row['excerpt'] :''.$row['content'].'';
		if (!empty($row['excerpt'])){
			preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i",$row['excerpt'],$match);
			if(empty($match[1][0])){
				preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i",$row['content'],$match);
			}
		}else{
			preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'],$match);
		}
		$img = isset($match[0][0]) ? $match[0][0]:'<img src="图片地址" />';//无图片时显示
		$date = gmdate('Y年m月d日', $row['date']);
		$content = strip_tags($logpost,'');
		$content = mb_substr($content,0,100,'utf-8');//摘要字数修改本代码中的100这个即可
		$content = subString(str_replace('阅读全文&gt;&gt;', '', strip_tags(breakLog($row['content'], $row['gid']))),0,100);
		$gid = $row['gid'];
		$content_img = GetThumFromContent($row['content']);
?>
		<div class="media" id="<?php if($mht==1) echo 'first'; ?>">
			<?php if($content_img) { ?>
			<div class="media-left">
				<a href="<?php echo Url::log($row['gid']);?>" title="<?php echo $row['title'];?>" /><img src="<?php echo $content_img; ?>" width="100px" height="80px" alt="blogger" /></a>
			</div>
			<?php } ?>
			<div class="media-body">
				<h4 class="media-heading"><a href="<?php echo Url::log($row['gid']);?>" title="<?php echo $row['title'];?>" /><?php echo $row['title'];?></a></h4>
				<?php echo $content;?>
			</div>
		</div>
<?php };?>
	</ul>
	</li>
<?php }?>
<?php
//widget：随机文章
function widget_random_log($title){
	$db = MySql::getInstance();
	$sj_num = Option::get('index_randlognum');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="newcomment">
<?php
	$sql = "SELECT gid,title,date,views,content FROM ".DB_PREFIX."blog WHERE hide='n' and checked='y' and type='blog' ORDER BY RAND() LIMIT $sj_num";
	$list = $db->query($sql);
	$mht=0;
	while($row = $db->fetch_array($list)){
		$mht=$mht+1;
		$logpost = !empty($row['excerpt']) ? $row['excerpt'] :''.$row['content'].'';
		if (!empty($row['excerpt'])){
			preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i",$row['excerpt'],$match);
			if(empty($match[1][0])){
				preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i",$row['content'],$match);
			}
		}else{
			preg_match_all("/\<img.*?src\=\"(.*?)\"[^>]*>/i", $row['content'],$match);
		}
		$content = strip_tags($logpost,'');
		$content = mb_substr($content,0,100,'utf-8');//摘要字数修改本代码中的100这个即可
		$content = subString(str_replace('阅读全文&gt;&gt;', '', strip_tags(breakLog($row['content'], $row['gid']))),0,100);
		$content_img = GetThumFromContent($row['content']);
	?> 	
		<div class="media" id="<?php if($mht==1) echo 'first'; ?>">
			<?php if($content_img) { ?>
			<div class="media-left">
				<a href="<?php echo Url::log($row['gid']);?>" title="<?php echo $row['title'];?>" /><img src="<?php echo $content_img; ?>" width="100px" height="80px" alt="blogger" /></a>
			</div>
			<?php } ?>
			<div class="media-body">
				<h4 class="media-heading"><a href="<?php echo Url::log($row['gid']);?>" title="<?php echo $row['title'];?>" /><?php echo $row['title'];?></a></h4>
				<?php echo $content;?>
			</div>
		</div>
	<?php }?>
	</ul>
	</li>
<?php }?>
<?php
//widget：搜索
function widget_search($title){ ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="record">
	<form name="keyform" class="search-form" method="get" action="<?php echo BLOG_URL; ?>index.php">
		<input name="keyword" class="form-control" class="search" type="text" />
		<input class="btn" type="submit" value="搜索">
	</form>
	</ul>
	</li>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="record" class="row">
	<?php foreach($record_cache as $value): ?>
	<li class="col-md-6"><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php } ?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<div id="sort" class="row">
	<?php
	foreach($sort_cache as $value):
		if ($value['pid'] != 0) continue;
	?>
	<div class="col-md-6">
	<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
	<?php if (!empty($value['children'])): ?>
		<div class="row">
		<?php
		$children = $value['children'];
		foreach ($children as $key):
			$value = $sort_cache[$key];
		?>
		<div class="col-md-6">
			<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
		</div>
		<?php endforeach; ?>
		</div>
	<?php endif; ?>
	</div>
	<?php endforeach; ?>
	</div>
	</li>
<?php }?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="record">
	<?php echo $content; ?>
	</ul>
	</li>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
    //if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="record" class="row">
	<?php foreach($link_cache as $value): ?>
	<li class="col-md-6"><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?> 
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	?>
	<?php
	foreach($navi_cache as $value):

        if ($value['pid'] != 0) {
            continue;
        }

		if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):
			?>
			<li><a href="<?php echo BLOG_URL; ?>admin/">管理站点</a></li>
			<li><a href="<?php echo BLOG_URL; ?>admin/?action=logout">退出</a></li>
			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
		?>
		<li <?php if (!empty($value['children'])) :?>class="dropdown"<?php endif;?> <?php if (!empty($value['childnavi'])) :?>class="dropdown"<?php endif;?>>
			<a <?php if (!empty($value['children'])) :?> class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"<?php endif;?><?php if (!empty($value['childnavi'])) :?> class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"<?php endif;?> href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?><?php if (!empty($value['children'])) :?><span class="caret"></span><?php endif;?><?php if (!empty($value['childnavi'])) :?><span class="caret"></span><?php endif;?></a>
			<?php if (!empty($value['children'])) :?>
            <ul class="dropdown-menu">
                <?php foreach ($value['children'] as $row){
                        echo '<li><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></li>';
                }?>
			</ul>
            <?php endif;?>

            <?php if (!empty($value['childnavi'])) :?>
            <ul class="dropdown-menu">
                <?php foreach ($value['childnavi'] as $row){
                        $newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';
                        echo '<li><a href="' . $row['url'] . "\" $newtab >" . $row['naviname'].'</a></li>';
                }?>
			</ul>
            <?php endif;?>

		</li>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：置顶
function topflg($top, $sortop='n', $sortid=null){
    if(blog_tool_ishome()) {
       echo $top == 'y' ? "<div class='article-top'>置顶</div>" : '';
    } elseif($sortid){
       echo $sortop == 'y' ? "<div class='article-top'>置顶</div>" : '';
    }
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
    <div class="article-sort">分类：<a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>"><?php echo $log_cache_sort[$blogid]['name']; ?></a></div>
	<?php endif;?>
<?php }?>
<?php
//blog：文章标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "<a id=\"a-tags\" href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
		}
		echo '<div class="article-tags">'.$tag.'</div>';
	}
}
?>
<?php
//blog：文章作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';
	echo '<div class="article-author"><a href="'.Url::author($uid)."\" >$author</a></div>";
}
?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<nav aria-label="...">
		<ul class="pager">
	<?php if($prevLog):?>
			<li class="previous"><a href="<?php echo Url::log($prevLog['gid']) ?>"><span class="glyphicon glyphicon-menu-left" aria-hidden="true"></span> <?php echo $prevLog['title'];?></a></li>
	<?php else: ?>
			<li class="previous"><a href="#"><span class="glyphicon glyphicon-menu-left" aria-hidden="true"></span> 没有了</a></li>	
	<?php endif;?>
	<?php if($nextLog):?>
			<li class="next"><a href="<?php echo Url::log($nextLog['gid']) ?>"><?php echo $nextLog['title'];?> <span class="glyphicon glyphicon-menu-right" aria-hidden="true"></span></a></li>
	<?php else: ?>
			<li class="next"><a href="#">没有了 <span class="glyphicon glyphicon-menu-right" aria-hidden="true"></span></a></li>	
	<?php endif;?>
		</ul>
	</nav>
<?php }?>
<?php
//blog：评论列表
function blog_comments($comments){
    extract($comments);
    if($commentStacks): ?>
	<a name="comments"></a>
	<p class="comment-header"></p>
	<div class="comment-list">
	<?php endif; ?>
	<?php
	$isGravatar = Option::get('isgravatar');
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<div class="comment comment-body" id="comment-<?php echo $comment['cid']; ?>">
		<a name="<?php echo $comment['cid']; ?>"></a>
		<div class="author">
			<div class="avatar"><img class="img-circle" src="<?php echo getGravatar($comment['mail']); ?>" /></div>
			<b><?php echo $comment['poster']; ?></b>
			<div class="comment-reply"><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a></div>
			<div class="comment-time"><?php echo $comment['date']; ?></div>
		</div>
		<div class="comment-info">
			<div class="comment-content"><?php echo comment2emoji($comment['content']); ?></div>
		</div>
		<?php blog_comments_children($comments, $comment['children']); ?>
	</div>
	<?php endforeach; ?>
    <?php if(empty($commentPageUrl)==FALSE): ?>
	<div class="comment-page">
	    <?php echo $commentPageUrl;?>
    </div>
	<?php endif; ?>
	<?php if($commentStacks): ?>
    </div>
	<?php endif; ?>
<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<div class="comment comment-children" id="comment-<?php echo $comment['cid']; ?>">
		<a name="<?php echo $comment['cid']; ?>"></a>
		<div class="author">
			<div class="avatar"><img class="img-circle" src="<?php echo getGravatar($comment['mail']); ?>" /></div>
			<b><?php echo $comment['poster']; ?></b>
			<?php if($comment['level'] < 4): ?><div class="comment-reply"><a href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">回复</a></div><?php endif; ?>
			<div class="comment-time"><?php echo $comment['date']; ?></div>
		</div>
		<div class="comment-info">
			<div class="comment-content"><?php echo comment2emoji($comment['content']); ?></div>
		</div>
		<?php blog_comments_children($comments, $comment['children']);?>
	</div>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
	<div id="comment-place">
	<div class="comment-post" id="comment-post">
		<p class="comment-header"><b></b><a name="respond"></a></p>
		<form method="post" name="commentform" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform">
			<div class="comment-face"><?php GetFaceImg(); ?></div>
			<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
			<textarea name="comment" id="comment" rows="10" tabindex="4" placeholder="听说你的评论可以一针见血"></textarea>
			<div class="comment-btn">
				<div class="cancel-reply" id="cancel-reply" style="display:none"><a class="btn btn-primary" href="javascript:void(0);" onclick="cancelReply()">取消回复</a></div>
				<?php if(ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER): ?>
				<input type="submit" id="comment_submit" value="提交评论" tabindex="6"  class="btn btn-primary"/>
				<?php else: ?>
				<button id="putin" type="button" class="btn btn-primary" data-toggle="modal" data-target="#info-box">提交评论</button>
				<?php endif; ?>
			</div>
			<div class="modal fade" id="info-box" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<h4 class="modal-title" id="exampleModalLabel">补充相关信息</h4>
						</div>
						<div class="modal-body">
							<?php if(ROLE == ROLE_VISITOR): ?>
								<div class="input-group youyou">
									<label for="author" class="input-group-addon">昵称（必填）</label>
									<input type="text" class="form-control" name="comname" maxlength="49" value="<?php echo $ckname; ?>" size="22" tabindex="1">
								</div>
								<div class="input-group youyou">
									<label for="email" class="input-group-addon">邮箱</label>
									<input type="text" class="form-control" name="commail"  maxlength="128"  value="<?php echo $ckmail; ?>" size="22" tabindex="2">
								</div>
								<div class="input-group">
									<label for="url" class="input-group-addon">网址</label>
									<input type="text" class="form-control" name="comurl" maxlength="128"  value="<?php echo $ckurl; ?>" size="22" tabindex="3">
								</div>
							<?php endif; ?>
							<?php if($verifyCode): ?>
								<div class="vcode">
									<?php echo $verifyCode; ?>
								</div>
								<script type="text/javascript">
									$(document).ready(function(){
										$("#putin").click(function(){
											$(".input").addClass("form-control");
										});
									});
									$('img[src*="checkcode.php"]')
										.attr('title', '单击刷新验证码')
										.click(function(){
											this.src = this.src.replace(/\?.*$/, "") +'?'+ new Date().getTime();
										});
								</script>
							<?php endif; ?>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">返回</button>
							<input type="submit" id="comment_submit" value="完成" tabindex="6"  class="btn btn-primary"/>
							<input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1"/>
						</div>
					</div>
				</div>
			</div>
		</form>
	</div>
	</div>
	<?php endif; ?>
<?php }?>
<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>
