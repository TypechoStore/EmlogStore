<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--end #content-->
</div><!--end #wrap-->
</div><!--end #container-->
<div id="footerbar">
	<div class="footerbar container">
	©&nbsp;2018&nbsp;&nbsp;<a href="<?php echo BLOG_URL; ?>" title="<?php echo $bloginfo; ?>"><?php echo $blogname; ?></a>
	<?php if(empty($icp)){}else{ ?> · <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a><?php } ?>
	&nbsp;·&nbsp;<a href="http://www.emlog.net" title="采用emlog系统" rel="nofollow">emlog</a>
	</br><?php echo $footer_info; ?>
	<?php doAction('index_footer'); ?>
	&nbsp;&nbsp;Design by <a href="http://www.200011.net" target="_blank" rel="nofollow">往记</a><!-- 版权已经添加nofollow不会影响seo，尊重设计者请保留 -->
	</div><!--end #footerbar-->
</div><!--end #footerbar-->
<p id="back-to-top"><a href="javascript:;"><span class="glyphicon glyphicon-circle-arrow-up"></span></a></p>
</body>
</html>