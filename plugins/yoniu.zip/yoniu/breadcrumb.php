<?php
/*!
* Emlog 面包屑导航 v1.0
* Copyright 2016 ThemesField
* http://themesfield.com.cn/emlog-add-a-breadcrumb
* 2018.2.12 修改 by 小智
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
error_reporting( E_ALL&~E_NOTICE );
$breadcrumb = '<li><a href="'.BLOG_URL.'">首页</a></li>';

if( $params[1]=='page' ){
    $breadcrumb .= '<li>第'.htmlspecialchars(urldecode($params[2])).'页</li>';//获取第某页
}

function __breadcrumb_Sort_Cache($id){
    global $CACHE;
    $sort_cache = $CACHE->readCache('sort');
    return $sort_cache[$id]['sortname'];
}

function __breadcrumb_User_Cache($id){
    global $CACHE;
    $user_cache = $CACHE->readCache('user');
    return $user_cache[$id]['name'];
}

function __breadcrumb_Blog_Sort_Cache_Check($blogid){
    global $CACHE; 
    $log_cache_sort = $CACHE->readCache('logsort');
    if(!empty($log_cache_sort[$blogid])){
        return true;
    }else{
        return false;
    }
}

function __breadcrumb_Blog_Sort_Cache($blogid){
    global $CACHE; 
    $log_cache_sort = $CACHE->readCache('logsort');
    if(!empty($log_cache_sort[$blogid])){
        //分类名称：$log_cache_sort[$blogid]['name']
        //分类链接：Url::sort($log_cache_sort[$blogid]['id'])
        return '<a href="'.Url::sort($log_cache_sort[$blogid]['id']).'">'.$log_cache_sort[$blogid]['name'].'</a>';
    }
}

if( $params[1]=='sort' ){//分类
    //分类名称：_cache_breadcrumb_Sort_Cache($sortid)
    //分类链接：$sort_url = Url::sort($sortid);
    $breadcrumb .= '<li><a href="'.Url::sort($sortid).'">'.__breadcrumb_Sort_Cache($sortid).'</a></li>';
    if( $params[4]=='page' ){
        $breadcrumb .= '<li>第'.htmlspecialchars(urldecode($params[5])).'页</li>';//获取第某页
    }
}elseif($params[1]=='record'){//归档
    $breadcrumb .= '<li>'.$params[2].'</li>';
    if( $params[4]=='page' ){
        $breadcrumb .= '<li>第'.htmlspecialchars(urldecode($params[5])).'页</li>';//获取第某页
    }
}elseif( $params[1] == 'author' ){//文章
    //作者名称：_cache_breadcrumb_User_Cache($params[2])
    //作者链接：$author_url = Url::author($params[2]);
    $breadcrumb .= '<li>'.__breadcrumb_User_Cache($params[2]).' 的文章</li>';
    if( $params[4]=='page' ){
        $breadcrumb .= '<li>第'.htmlspecialchars(urldecode($params[5])).'页</li>';//获取第某页
    }
}elseif( $params[1] == 'tag' ){//标签
    //标签名称：htmlspecialchars(urldecode($params[2]));
    //标签链接：$tag_url = Url::tag($params[2]);
    $breadcrumb .= '<li>'.htmlspecialchars(urldecode($params[2])).'</li>';
    if( $params[4]=='page' ){
        $breadcrumb .= '<li>第'.htmlspecialchars(urldecode($params[5])).'页</li>';//获取第某页
    }
}elseif( $params[1] == 'keyword' ){//搜索
    $breadcrumb .= '<li>关于"'.htmlspecialchars(urldecode($params[2])).'"的内容</li>';
    if( $params[4]=='page' ){
        $breadcrumb .= '<li>第'.htmlspecialchars(urldecode($params[5])).'页</li>';//获取第某页
    }
}elseif( $type=='blog' ){//自定义文章
    
    //判断文章是否存在分类
    if( __breadcrumb_Blog_Sort_Cache_Check($logid) ){
        $breadcrumb .= '<li>'.__breadcrumb_Blog_Sort_Cache($logid).'</li>';
    }
    
    //文章名称：$log_title
    //文章链接：Url::log($logid);
    $breadcrumb .= '<li>'.$log_title.'</li>';
}elseif( $type=='page' ){//自定义文章
    $breadcrumb .= '<li>'.$log_title.'</li>';
}elseif( $tws ){
    
    $breadcrumb .= '<li>'.'微语'.'</li>';
    preg_match_all('|^.*/\?(page)=(\d+)([\?&].*)?$|',Dispatcher::setPath(),$Preferred);
    if( $Preferred[1][0]=='page' ){
        $breadcrumb .= '<li>第'.htmlspecialchars(urldecode($Preferred[2][0])).'页</li>';
    }
}