<?php
/*
Plugin Name: 网站版权
Version: 1.1
Plugin URL: http://www.emlog.net/plugin/117
Description: 团团说工作室 网站版权 自定义开启版权提示 自定义开启禁止复制文章。使用方法：只需在合适地方加上&lt;?php doAction('ttjtg_taobaoke'); ?>即可。
Author: 团团说&二呆
Author Email: ttjtg@139.com
Author URL: https://www.tongleer.com/
*/

!defined('EMLOG_ROOT') && exit('access deined!');


function ttjtg_banquan_setting()
{
echo '<div class="sidebarsubmenu" id="ttjtg_banquan_setting"><a href="./plugin.php?plugin=ttjtg_banquan">本网站版权</a></div>';
}
addAction('adm_sidebar_ext', 'ttjtg_banquan_setting');

function ttjtg_banquan(){
$ttsurl=$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
$ttsurl=str_replace('index.php/','',$ttsurl);
require_once('ttjtg_banquan_config.php');
if(ttjtg_is_https()){
	$http="https://";
}else{
	$http="http://";
}
echo '
<fieldset style="border:1px dashed '.$bk_yanse.'; margin:15px;padding:10px;border-radius:8px;-moz-border-radius:8px;-webkit-border-radius:8px;font-size: 12px;">
<legend align="center" style="color:'.$zt_yanse.';width:200px;text-align:center;border-radius:8px;background-color:'.$bk_yanse.'">'.$mingcheng.'- 本站版权</legend>
<div style="float:left;">
1、本站所有主题由该文章作者发表，该文章作者与<a href="'.$http.$_SERVER['HTTP_HOST'].'" rel="nofollow"><font color="#FF6600">'.$mingcheng.'</font></a>享有文章相关版权<br />
2、其他单位或个人使用、转载或引用本文时必须同时征得该文章作者和<a href="'.$http.$_SERVER['HTTP_HOST'].'" rel="nofollow"><font color="#FF6600">'.$mingcheng.'</font></a>的同意<br />
3、本帖部分内容转载自其它媒体，但并不代表本站赞同其观点和对其真实性负责<br />
4、如本帖侵犯到任何版权问题，请立即告知本站，本站将及时予与删除并致以最深的歉意<br />
5、原文链接：<a href="'.$http.$ttsurl.'" rel="nofollow">'.$ttsurl.'</a>
</div>
<span style="float:right;"><img src="https://www.tongleer.com/api/web/?action=qrcode&url='.$http.$ttsurl.'" alt="二维码" style="margin:-10px 0;" width="100"  />
</span>
</fieldset>';


if($fz_kaiguan==1){
echo ('');   
}else{
echo '
<script> document.body.onselectstart=document.body.oncontextmenu=function(){return false;};</script>';
}
}
addAction('ttjtg_taobaoke', 'ttjtg_banquan');

function ttjtg_is_https() {
	if ( !empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off') {
		return true;
	} elseif ( isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https' ) {
		return true;
	} elseif ( !empty($_SERVER['HTTP_FRONT_END_HTTPS']) && strtolower($_SERVER['HTTP_FRONT_END_HTTPS']) !== 'off') {
		return true;
	}else{
		return false;
	}
}
?>