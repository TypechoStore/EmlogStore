<?php
$fz_kaiguan = '1';
$bk_yanse = '#000';
$zt_yanse = '#FFFFFF';
$mingcheng = '团团说';
?>