<?php 
/**
 * 网站版权
 * @copyright (c) Emlog All Rights Reserved
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
function plugin_setting_view(){
require_once('ttjtg_banquan_config.php');	 	 
?>
<script>$("#ttjtg_banquan").addClass('sidebarsubmenu1');</script>
<div class=containertitle><b>团团说工作室-网站版权设置</b>
<?php if(isset($_GET['setting'])):?><span class="actived">插件设置完成</span><?php endif;?>
</div>
<div class=line></div>
<form action="plugin.php?plugin=ttjtg_banquan&action=setting" method="post">
<div>



<p>是否开启禁止复制：                
<label>  
<input type="radio" name="fz_kaiguan" value="0" <?php if($fz_kaiguan=='0') echo "checked=\"checked\"";?> />是
<input type="radio" name="fz_kaiguan" value="1" <?php if($fz_kaiguan=='1') echo "checked=\"checked\"";?> />否</label>&nbsp;&nbsp;&nbsp;&nbsp;</p>


<p>网站名称或者昵称：
<input size="10" name="mingcheng" type="text" value="<?php echo $mingcheng; ?>" />&nbsp;&nbsp;&nbsp;&nbsp;（网站名称或者昵称，不要太长）</p>	
</p>
 
<p>输入边框颜色代码：
<input size="10" name="bk_yanse" type="text" value="<?php echo $bk_yanse; ?>" />&nbsp;&nbsp;&nbsp;&nbsp;（输入边框颜色，默认是红色#FF0000）</p>	
</p>

<p>输入版权申明颜色：
<input size="10" name="zt_yanse" type="text" value="<?php echo $zt_yanse; ?>" />&nbsp;&nbsp;&nbsp;&nbsp;（版权申明文字的颜色，默认是白色#ffffff）</p>	
</p>

<p><input type="submit" value="保 存" class="submit" /></p>
</div>
<script language="JavaScript" type="text/javascript" src="http://fx.51fkgo.com/include/gonggao.html">
</script>
</form>


<script>
$("#ttjtg_banquan_setting").addClass('sidebarsubmenu1');
</script>
<?php 
}
function plugin_setting()
{
$fz_kaiguan = isset($_POST['fz_kaiguan']) ? trim($_POST['fz_kaiguan']) : '';
$bk_yanse = isset($_POST['bk_yanse']) ? trim($_POST['bk_yanse']) : '';
$zt_yanse = isset($_POST['zt_yanse']) ? trim($_POST['zt_yanse']) : '';
$mingcheng = isset($_POST['mingcheng']) ? trim($_POST['mingcheng']) : '';
	
	print_r($_POST);
	 
$data = "<?php
\$fz_kaiguan = '".$fz_kaiguan."';
\$bk_yanse = '".$bk_yanse."';
\$zt_yanse = '".$zt_yanse."';
\$mingcheng = '".$mingcheng."';
?>";
	if($bk_yanse != '' && $fz_kaiguan != ''&& $zt_yanse != ''&& $mingcheng != '')
	{
		$file = EMLOG_ROOT.'/content/plugins/ttjtg_banquan/ttjtg_banquan_config.php';
		@ $fp = fopen($file, 'wb') OR emMsg('读取文件失败，如果您使用的是Unix/Linux主机，请修改文件/content/plugins/ttjtg_banquan/ttjtg_banquan_config.php的权限为777。如果您使用的是Windows主机，请联系管理员，将该文件设为everyone可写');
		@ $fw =	fwrite($fp,$data) OR emMsg('写入文件失败，如果您使用的是Unix/Linux主机，请修改文件/content/plugins/ttjtg_banquan/ttjtg_banquan_config.php的权限为777。如果您使用的是Windows主机，请联系管理员，将该文件设为everyone可写');
		fclose($fp);
	}
}
?>