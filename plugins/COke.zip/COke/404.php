<?php 
/**
 * 自定义404页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');}
include View::getView('header');
?>
<script>
document.title = "404 抱歉页面不存在或被删除"
</script>

<section class="container">
	<div align="center">

	<p align="left">  
</p>

<p>抱歉，页面不存在或被吃了，不如玩玩游戏吧</p>
<a href="<?php echo BLOG_URL;?>" class="btn btn-primary">返回首页</a>
</br></br></br>
<!-- 404和其他页面 -->
<p></p><font size="3" face="黑体">游戏一《圈小猫》
		<p>
	</p>
	玩法：点击小圆点，将小猫圈住！</font>
		<p>
	</p>
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" name="top10movie" width="640" height="480" id="top10movie">
											<param name="movie" value="http://game.10086.cn/Upload/attachment/flash/201011/30/4cf4cb527cf65.swf">
											<param name="quality" value="high">
											<param name="menu" value="false">
											<embed src="http://www.gamedesign.jp/flash/chatnoir/chatnoir.swf" width="640" height="480" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" id="top10movie" name="top10movie" menu="false">
										</object>
<p></p></br></br></br><font size="3" face="黑体">游戏二《2048数字组合》		
<p>
	</p>
	一款很有趣的益智小游戏。游戏中，你通过利用方向键来移动数字方块，让相同方块不断的叠加，最后让数字到达2048即可取得胜利，非常需要技巧的，喜欢的朋友快来挑战吧！ 
			<p>
	</p>
	玩法：加载完成点击Play开始游戏，↑↓←→操作。</font>
		<p>
	</p>
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" name="top10movie" width="480" height="570" id="top10movie">
											<param name="movie" value="http://files2.17173.com/yzflash/2014031805.swf">
											<param name="quality" value="high">
											<param name="menu" value="false">
											<embed src="http://files2.17173.com/yzflash/2014031805.swf" width="480" height="570" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" id="top10movie" name="top10movie" menu="false">
										</object>	
		<p>
	</p>
</div>
</section>
<?php 
include View::getView('footer');
?>
