<?php
@set_time_limit(0);
require_once('../../../init.php');
include_once EMLOG_ROOT . '/content/plugins/isaced_backup/isaced_backup_config.php';
//--------------------


	if(ISACED_BACKUP_LAST_BAK_FILE != '' && file_exists('../../../content/backup/'.ISACED_BACKUP_LAST_BAK_FILE))
	{
	
	$delay_time = time() - filemtime( '../../../content/backup/'.ISACED_BACKUP_LAST_BAK_FILE );
	$sites= date('i', $delay_time);  
	if(intval($sites) > intval(ISACED_BACKUP_DO_LOOP_TIME))
	{


		$blogname = Option::get('blogname');	
		  $timezone = 8;
		  if(Option::EMLOG_VERSION >= '6.1.1'){
			$tables = array('attachment', 'blog', 'comment', 'options', 'navi', 'reply', 'sort', 'link','tag','twitter','user','block','sortlink');
		  }else{
			$tables = array('attachment', 'blog', 'comment', 'options', 'navi' , 'reply', 'sort', 'link','tag','trackback','twitter','user'); //emlog原生所有表 (5.0.1)
		  }
		  $defname = 'emlog_'. date('Ymd', time() + $timezone * 3600) . '_' . substr(md5(date('YmdHis', time() + $timezone * 3600)),0,18);
		  doAction('data_prebakup');
		  $filename = $defname.'.sql';

			$fso = fopen('isaced_backup_config.php','r'); //获取配置文件内容
			$config = fread($fso,filesize('isaced_backup_config.php'));
			fclose($fso);

			$patt = array(
			"/define\('ISACED_BACKUP_LAST_BAK_FILE',(.*)\)/",
			);

			$replace = array(
			"define('ISACED_BACKUP_LAST_BAK_FILE','".$filename."')",
			);
			$new_config = preg_replace($patt, $replace, $config);
			$fso = fopen('isaced_backup_config.php','w'); //写入替换后的配置文件
			fwrite($fso,$new_config);
			fclose($fso);

		  $sqldump = '';
		  foreach($tables as $table)
		  {
		    $sqldump .= isaced_backup_dataBak(DB_PREFIX.$table);
		  }
		  $dumpfile = '#version:emlog '. Option::EMLOG_VERSION . "\n";
		  $dumpfile .= '#date:' . date('Y-m-d H:i', time() + $timezone * 3600) . "\n";
		  $dumpfile .= '#tableprefix:' . DB_PREFIX . "\n";
		  $dumpfile .= $sqldump;
		  $dumpfile .= "\n#the end of backup";

		  $filename = '../../../content/backup/'.$defname.'.sql';

		  @$fp = fopen($filename, 'w+');
		  if ($fp)
		  {
		    @flock($fp, 3);
		    if(@!fwrite($fp, $dumpfile))
		    {
		      @fclose($fp);
		      echo $filename;

		    }else{
		      @fclose($fp);
		    }
		  }
	}
}
function isaced_backup_dataBak($table)
{
  $DB = Database::getInstance();
  $sql = "DROP TABLE IF EXISTS $table;\n";
  $createtable = $DB->query("SHOW CREATE TABLE $table");
  $create = $DB->fetch_row($createtable);
  $sql .= $create[1].";\n\n";

  $rows = $DB->query("SELECT * FROM $table");
  $numfields = $DB->num_fields($rows);
  $numrows = $DB->num_rows($rows);
  while ($row = $DB->fetch_row($rows))
  {
    $comma = "";
    $sql .= "INSERT INTO $table VALUES(";
    for ($i = 0; $i < $numfields; $i++)
    {
      $sql .= $comma."'".mysql_escape_string($row[$i])."'";
      $comma = ",";
    }
    $sql .= ");\n";
  }
  $sql .= "\n";

  return $sql;
}



