<?php
/*
Plugin Name: 自动备份
Version: 0.1
ForEmlog:5.0.1
Plugin URL: http://www.isaced.com/post-193.html
Description: 自动整站备份，并同步至网盘。(更新中...欢迎前来提意见！)
Author: isaced
Author Email: isaced@163.com
Author URL: http://www.isaced.com
*/

!defined('EMLOG_ROOT') && exit('access deined!');

//后台菜单
function isaced_backup_menu()
{
	echo '<div class="sidebarsubmenu" id="isaced_backup"><a href="./plugin.php?plugin=isaced_backup">自动备份</a></div>';
}
addAction('adm_sidebar_ext', 'isaced_backup_menu');


function isaced_backup()
{
	echo "<script type=\"text/javascript\">XMLHttp.sendReq('GET','".DYNAMIC_BLOGURL."content/plugins/isaced_backup/isaced_backup_do.php','',function(obj){return;});</script>\r\n";
}
addAction('index_footer','isaced_backup');

?>