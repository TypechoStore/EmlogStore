<?php
/**
 * isaced_backup_setting.php
 * design by isaced
 */

!defined('EMLOG_ROOT') && exit('access deined!');

function plugin_setting_view() {
    include_once EMLOG_ROOT . '/content/plugins/isaced_backup/isaced_backup_config.php';

//$delay_time = time() - filemtime(ISACED_BACKUP_DO_LOOP_TIME);

$lastTime = @filemtime( '../content/backup/'.ISACED_BACKUP_LAST_BAK_FILE );

?>

  <style type="text/css">
  .button {
    position: relative;
    overflow: visible;
    display: inline-block;
    padding: 0.5em 1em;
    border: 1px solid #d4d4d4;
    margin: 0;
    text-decoration: none;
    text-align: center;
    text-shadow: 1px 1px 0 #fff;
    font:11px/normal sans-serif;
    color: #333;
    white-space: nowrap;
    cursor: pointer;
    outline: none;
    background-color: #ececec;
    background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#f4f4f4), to(#ececec));
    background-image: -moz-linear-gradient(#f4f4f4, #ececec);
    background-image: -ms-linear-gradient(#f4f4f4, #ececec);
    background-image: -o-linear-gradient(#f4f4f4, #ececec);
    background-image: linear-gradient(#f4f4f4, #ececec);
    -moz-background-clip: padding; /* for Firefox 3.6 */
    background-clip: padding-box;
    border-radius: 0.2em;
    /* IE hacks */
    zoom: 1;
    *display: inline;
}

.button:hover,
.button:focus,
.button:active,
.button.active {
    border-color: #3072b3;
    border-bottom-color: #2a65a0;
    text-decoration: none;
    text-shadow: -1px -1px 0 rgba(0,0,0,0.3);
    color: #fff;
    background-color: #3c8dde;
    background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#599bdc), to(#3072b3));
    background-image: -moz-linear-gradient(#599bdc, #3072b3);
    background-image: -o-linear-gradient(#599bdc, #3072b3);
    background-image: linear-gradient(#599bdc, #3072b3);
}

.button:active,
.button.active {
    border-color: #2a65a0;
    border-bottom-color: #3884cd;
    background-color: #3072b3;
    background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#3072b3), to(#599bdc));
    background-image: -moz-linear-gradient(#3072b3, #599bdc);
    background-image: -ms-linear-gradient(#3072b3, #599bdc);
    background-image: -o-linear-gradient(#3072b3, #599bdc);
    background-image: linear-gradient(#3072b3, #599bdc);
}

/* overrides extra padding on button elements in Firefox */
.button::-moz-focus-inner {
    padding: 0;
    border: 0;
}
</style>
    <img style="float:left;" src="../content/plugins/isaced_backup/images/isaced_backup.png">
    <div style="float:left; margin-left:30px; margin-top:20px;"><h1><?php if(!isset($_GET['set'])) {echo "自动备份 - 备份列表"; } else { echo "自动备份 - 插件设置";} ?></h1></div>
    <div style="float:right; margin-top:20px;">
      <a class="button" href="./plugin.php?plugin=isaced_backup">备份列表</a>
      <a class="button" href="./plugin.php?plugin=isaced_backup&set=y">插件设置</a>
    </div>

    <br/>

<?php if(isset($_GET['set'])) :?>
        <form action="./plugin.php?plugin=isaced_backup&set=y" method="POST">
    <table width="100%" border="1" id="adm_comment_list" class="item_list" >
        <thead>
          <tr>
            <th><b>选项</b></th>
            <th><b>设置</b></th>
            <th><b>说明</b></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>最后备份时间：</th>
            <td><?php echo  smartDate($lastTime,'Y-m-d H:i:s'); ?></td>
            <td>本插件距离现在最后一次备份并上传的时间。</td>
          </tr>
          <tr>
          <tr>
            <td>最后备份文件：<br />(首次设置成content/backup/目录下真实的临时文件，如：temp)</th>
            <td><input type="text" name="lastfile" value="<?php echo ISACED_BACKUP_LAST_BAK_FILE;?>" /></td>
            <td>本插件距离现在最后一次备份并上传的文件名。<span style="font-weight: bold;color:red;">(一般请不要改动)</span></td>
          </tr>
            <td>备份间隔时间：</th>
            <td><input type="text" name="looptime" value="<?php echo ISACED_BACKUP_DO_LOOP_TIME;?>" /></td>
            <td>设置数据备份的间隔时间，以<span style="font-weight: bold;color:blue;">分钟</span>表示！</td>
            </tr>
      </tbody>
    </table>
    
        <div>
        <p><input class="button" type="submit" value="保存" /></p>
        </div>
    <div><?php if (isset($_GET['save'])): ?><span class="actived">操作成功</span><?php endif;?></div>
    </form>
<br />
<p class="des">提示：目前正在逐步完善，并增加新功能，比如网盘同步等等，敬请期待！</p>

<?php else : ?>

    <table width="100%" id="adm_comment_list" class="item_list" >
        <thead>
          <tr>
            <th width="683"><b>备份文件</b></th>
            <th width="226"><b>备份时间</b></th>
            <th width="149"><b>文件大小</b></th>
            <th width="50"></th>
            <th width="100"></th>
          </tr>
        </thead>
        <tbody>
          <?php 
            $retval = glob('../content/backup/*.sql');
            $bakfiles = $retval ? $retval : array();

            if($bakfiles):
            foreach($bakfiles  as $value):
            $modtime = smartDate(filemtime($value),'Y-m-d H:i:s');
            $size =  changeFileSize(filesize($value));
            $bakname = substr(strrchr($value,'/'),1);
          ?>
          <tr>
            <td width="661"><a href="../content/backup/<?php echo $bakname; ?>"><?php echo $bakname; ?></a></td>
            <td><?php echo $modtime; ?></td>
            <td><?php echo $size; ?></td>
            <td><a href="javascript: em_confirm('<?php echo $value; ?>', 'backup');">导入</a></td>
            <td align="center"><img src="../content/plugins/isaced_backup/images/yes.png"></td>
          </tr>
          <?php endforeach;else:?>
            <tr><td class="tdcenter" colspan="5">还没有备份</td></tr>
          <?php endif;?>
      </tbody>
    </table>
    <br>
    <p class="des">提示：本插件和Emlog原生的数据查看、备份、恢复并不冲突，所以可以混合使用！<br />（删除备份暂时可以在左侧菜单“数据”页面操作）<br />本插件有任何不足、漏洞、意见或建议请即使反馈到我。&nbsp; - &nbsp; <a target="_blank" href="http://www.isaced.com/post-193.html">访问插件页面</a></p>

<?php endif; ?>

<?php 

  //更新设置

    if (!empty($_POST['looptime'])) {
          include_once EMLOG_ROOT . '/content/plugins/isaced_backup/isaced_backup_config.php';

          $map = array(
            'ISACED_BACKUP_DO_LOOP_TIME'   =>  'looptime',
            'ISACED_BACKUP_LAST_BAK_FILE'   =>  'lastfile',

          );
      
          $fso = @fopen(EMLOG_ROOT.'/content/plugins/isaced_backup/isaced_backup_config.php','w'); 
          if ($fso === false)
            emMsg(EMLOG_ROOT.'/content/plugins/isaced_backup/isaced_backup_config.php <br/>没有写权限，请修改文件属性');

          fwrite($fso, "<?php\n");
      
      
      foreach($map as $key => $value){
        $newValue = isset($_POST[$value]) ? $_POST[$value] : constant($key);
        fwrite($fso, "define('$key', '$newValue');\n");
      }
      fclose($fso);
      //刷新页面
        echo "<script>";
        echo  "window.location.href=window.location.href;";
        echo "</script>";
    }
}
?>
