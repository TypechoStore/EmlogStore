<?php
$config = array(
    "app_id" => "cc0d0478",
	"off" => "yes",
);